import copy
import hashlib
import json
import math
import re
import subprocess
from pathlib import Path

import yaml

BASE = '13e38dafce476286db7e673e7f21343d54416b56'
WORKFLOW = '.github/workflows/pytorch_tests.yml'
OUTPUT = 'evidence/2026-refresh/phase2-ci-budget-validation.json'
REPORT = 'evidence/2026-refresh/phase2c-feddyn-validation.json'
RECEIPT = 'evidence/2026-refresh/phase2c-feddyn-delivery-receipt.json'
AUDIT = Path('/Users/bli/Playground/plato/evidence/2026-refresh/phase2c-root-final-receipt-audit.json')
SCRATCH = Path('/tmp/plato-phase2c-feddyn-implementation')


def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()


def file_receipt(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


class WorkflowLoader(yaml.SafeLoader):
    pass


# Keep GitHub's unquoted `on` key as a string; only true/false are booleans.
WorkflowLoader.yaml_implicit_resolvers = {
    key: [(tag, pattern) for tag, pattern in values
          if tag != 'tag:yaml.org,2002:bool']
    for key, values in yaml.SafeLoader.yaml_implicit_resolvers.items()
}
WorkflowLoader.add_implicit_resolver(
    'tag:yaml.org,2002:bool',
    re.compile(r'^(?:true|True|TRUE|false|False|FALSE)$'),
    list('tTfF'),
)


def unique_mapping(loader, node):
    result = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node)
        assert key not in result, f'Duplicate YAML key: {key}'
        result[key] = loader.construct_object(value_node)
    return result


WorkflowLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, unique_mapping
)


def semantic_changes(before, after, path=()):
    if isinstance(before, dict) and isinstance(after, dict):
        assert before.keys() == after.keys(), path
        return [change for key in before
                for change in semantic_changes(before[key], after[key], (*path, key))]
    if isinstance(before, list) and isinstance(after, list):
        assert len(before) == len(after), path
        return [change for index, (left, right) in enumerate(zip(before, after))
                for change in semantic_changes(left, right, (*path, index))]
    if before == after and type(before) is type(after):
        return []
    return [{'path': list(path), 'old': before, 'new': after}]


assert git('rev-parse', 'HEAD') == BASE
assert git('branch', '--show-current') == 'maintenance/2026-phase2-ci-budget'
before_bytes = subprocess.check_output(['git', 'show', f'{BASE}:{WORKFLOW}'])
after_bytes = Path(WORKFLOW).read_bytes()
before = yaml.load(before_bytes, Loader=WorkflowLoader)
after = yaml.load(after_bytes, Loader=WorkflowLoader)
assert before['on'] == after['on'] == {
    'push': {'branches': ['main']},
    'pull_request': {'branches': ['main']},
    'workflow_dispatch': None,
}
assert True not in before and True not in after
job = after['jobs']['PyTorch-Tests']
old_job = before['jobs']['PyTorch-Tests']
assert len(job['steps']) == len(old_job['steps']) == 12
assert job['strategy']['fail-fast'] is False
assert job['steps'][0]['with']['persist-credentials'] is False

changes = semantic_changes(before, after)
expected_changes = [
    {'path': ['jobs', 'PyTorch-Tests', 'timeout-minutes'], 'old': 45, 'new': 90},
    {'path': ['jobs', 'PyTorch-Tests', 'steps', 6, 'timeout-minutes'], 'old': 12, 'new': 20},
    {'path': ['jobs', 'PyTorch-Tests', 'steps', 8, 'timeout-minutes'], 'old': 12, 'new': 20},
    {'path': ['jobs', 'PyTorch-Tests', 'steps', 9, 'timeout-minutes'], 'old': 12, 'new': 16},
]
assert changes == expected_changes, changes
expected_bytes = before_bytes.replace(b'    timeout-minutes: 45\n', b'    timeout-minutes: 90\n', 1)
for step_index in (6, 8, 9):
    name = job['steps'][step_index]['name']
    old = f'      - name: {name}\n        timeout-minutes: 12\n'.encode()
    new = f'      - name: {name}\n        timeout-minutes: {job["steps"][step_index]["timeout-minutes"]}\n'.encode()
    assert expected_bytes.count(old) == 1
    expected_bytes = expected_bytes.replace(old, new, 1)
assert after_bytes == expected_bytes
subprocess.run(['git', 'diff', '--check'], check=True)
assert git('diff', '--name-only') == WORKFLOW
untracked = git('ls-files', '--others', '--exclude-standard').splitlines()
assert not untracked or untracked == [OUTPUT], untracked

report_bytes = Path(REPORT).read_bytes()
r = json.loads(report_bytes)
receipt = json.loads(Path(RECEIPT).read_bytes())
audit = json.loads(AUDIT.read_bytes())
report_hash = hashlib.sha256(report_bytes).hexdigest()
assert receipt['evidence_files'][Path(REPORT).name]['sha256'] == report_hash
assert receipt['evidence_files'][Path(REPORT).name]['bytes'] == len(report_bytes)
assert receipt['evidence_files'][Path(REPORT).name]['git_blob'] == git('rev-parse', f'{BASE}:{REPORT}')
assert audit['candidate'] == BASE and audit['tree'] == git('rev-parse', f'{BASE}^{{tree}}')
assert audit['report_sha256'] == report_hash
assert audit['verified_count'] == len(audit['verified']) == len(r['raw_inventory']) == 154
assert not audit['missing'] and not audit['changed']
assert set(audit['verified']) == set(r['raw_inventory'])

protected = ['plato', 'tests', 'examples', 'configs', 'pyproject.toml', 'uv.lock']
assert not git('diff', '--name-only', r['implementation_commit'], BASE, '--', *protected)
assert not git('diff', '--name-only', r['final_production_commit'], r['implementation_commit'],
               '--', 'plato', 'examples', 'configs', 'tests/integration', 'pyproject.toml', 'uv.lock')
for path, item in r['sources'].items():
    assert git('rev-parse', f'{BASE}:{path}') == item['blob'], path
    assert file_receipt(path)['sha256'] == item['sha256'], path

measurements = []
for key, item in [*r['profiles'].items(),
                  *[(f'runtime-{version}', value) for version, value in r['runtime'].items()]]:
    paths = {
        'log': Path(item['log']),
        'wall_report': SCRATCH / (Path(item['log']).stem + '.json'),
        'junit': Path(item['junit']['path']),
    }
    raw_receipts = {}
    for kind, path in paths.items():
        actual = file_receipt(path)
        expected = r['raw_inventory'][path.name]
        assert actual['sha256'] == expected['sha256'], path
        assert actual['bytes'] == expected['bytes'], path
        raw_receipts[kind] = actual
    log = paths['log'].read_text()
    wall = json.loads(paths['wall_report'].read_bytes())
    assert item['summary'] in log
    assert raw_receipts['log']['sha256'] == item['sha256']
    assert raw_receipts['junit']['sha256'] == item['junit']['sha256']
    for field in ('head', 'command', 'shell', 'seconds', 'exit_code', 'summary'):
        assert wall[field] == item[field], (key, field)
    assert item['exit_code'] == 0
    seconds = float(re.search(r' in ([0-9.]+)s', item['summary'])[1])
    version = '3.13' if key.endswith('313') else '3.14'
    is_runtime = item['partition'] == 'runtime'
    assert ('51 passed, 1232 deselected' in item['summary']) if is_runtime else (item['counts']['tests'] == 1232)
    measurements.append({
        'report_key': ['runtime', version.replace('.', '')] if is_runtime else ['profiles', key],
        'python': version,
        'executed_commit': item['head'],
        'executed_tree': git('rev-parse', f'{item["head"]}^{{tree}}'),
        'profile': item['profile'],
        'partition': item['partition'],
        'cases': 51 if is_runtime else item['counts']['tests'],
        'summary': item['summary'],
        'pytest_seconds': seconds,
        'command_wall_seconds': item['seconds'],
        'old_step_timeout_seconds': 720,
        'exceeds_old_timeout_seconds': round(max(0, item['seconds'] - 720), 2),
        'old_timeout_remaining_seconds': round(max(0, 720 - item['seconds']), 2),
        'raw_receipts': raw_receipts,
    })

planning = []
for profile, partition, allowance, minutes, explanation in (
    ('base', 'not runtime', 120, 20,
     'Collection and mandatory missing-extra probe share this step with the full base suite.'),
    ('mandatory', 'not runtime', 120, 20,
     'Hosted command also enables coverage and -ra reporting; the measured author command does not enable coverage.'),
    ('mandatory', 'runtime', 60, 16,
     'The 51-case partition has little margin at 720 seconds; reserve additional hosted command/reporting overhead.'),
):
    slowest = max(m['command_wall_seconds'] for m in measurements
                  if m['profile'] == profile and m['partition'] == partition)
    planned = slowest * 1.25 + allowance
    assert math.ceil(planned / 60) == minutes
    planning.append({
        'profile': profile, 'partition': partition,
        'slowest_measured_command_wall_seconds': slowest,
        'runner_variance_multiplier': 1.25,
        'additional_workflow_overhead_allowance_seconds': allowance,
        'planning_seconds': round(planned, 2),
        'rounding': 'Ceiling to the next whole minute.',
        'new_timeout_minutes': minutes,
        'margin_over_slowest_measured_wall_seconds': round(minutes * 60 - slowest, 2),
        'rationale': explanation,
    })

action_allowances = {
    'Checkout pinned submodules': 2,
    'Set up Python': 2,
    'Set up uv': 1,
    'Upload qualification outputs': 1,
}
stages = []
for step in job['steps']:
    explicit = step.get('timeout-minutes')
    stages.append({
        'step': step['name'],
        'explicit_timeout_minutes': explicit,
        'job_planning_allowance_minutes': explicit if explicit is not None else action_allowances[step['name']],
        'basis': 'Existing/new finite step limit.' if explicit is not None else 'Planning reserve within the job limit; no action step timeout added.',
    })
explicit_sum = sum(s['explicit_timeout_minutes'] or 0 for s in stages)
action_sum = sum(action_allowances.values())
assert explicit_sum == 84 and action_sum == 6
assert sum(s['job_planning_allowance_minutes'] for s in stages) == job['timeout-minutes'] == 90

result = {
    'schema_version': 1,
    'status': 'LOCAL_STATIC_VALIDATION_PASSED_PENDING_INDEPENDENT_REVIEW_AND_ROOT_PHASE_GATE',
    'scope': 'Finite Phase 2 timeout adjustment only.',
    'source': {
        'base_commit': BASE,
        'base_tree': git('rev-parse', f'{BASE}^{{tree}}'),
        'branch': git('branch', '--show-current'),
        'workflow': {
            'path': WORKFLOW,
            'before': {'git_blob': git('rev-parse', f'{BASE}:{WORKFLOW}'),
                       'bytes': len(before_bytes), 'sha256': hashlib.sha256(before_bytes).hexdigest()},
            'after': {**file_receipt(WORKFLOW), 'git_blob': git('hash-object', WORKFLOW)},
        },
        'measurement_source': {
            'non_runtime_implementation_commit': r['implementation_commit'],
            'non_runtime_implementation_tree': r['implementation_tree'],
            'runtime_executed_commit': r['final_production_commit'],
            'runtime_executed_tree': git('rev-parse', f'{r["final_production_commit"]}^{{tree}}'),
            'implementation_to_base_protected_source_diff': [],
            'runtime_to_implementation_production_integration_config_diff': [],
            'report_source_blobs_and_sha256_verified_against_base': len(r['sources']),
            'runtime_carry_forward_attribution': r['source_identical_runtime_carry_forward'],
        },
        'evidence_commit_identity': 'Final adjustment commit/tree are delivered after commit to avoid self-reference.',
    },
    'inputs': {
        'author_validation_report': {**file_receipt(REPORT), 'git_blob': git('rev-parse', f'{BASE}:{REPORT}')},
        'author_delivery_receipt': {**file_receipt(RECEIPT), 'git_blob': git('rev-parse', f'{BASE}:{RECEIPT}')},
        'root_receipt_audit': {**file_receipt(AUDIT),
                               'scope': audit['scope'], 'verified_count': audit['verified_count'],
                               'missing': audit['missing'], 'changed': audit['changed']},
    },
    'reproduction': {
        'original_non_runtime_step_timeout_seconds': 720,
        'observed_non_runtime_pytest_seconds': {'3.13': {'base': 760.02, 'mandatory': 763.02},
                                               '3.14': {'base': 833.90, 'mandatory': 835.52}},
        'all_four_non_runtime_runs_exceed_original_limit': all(
            m['pytest_seconds'] > 720 for m in measurements if m['partition'] == 'not runtime'),
        'runtime_cases': {'total': 51, 'unchanged_startup': 48, 'feddyn_entrypoint': 3},
        'runtime_exceeds_original_limit': False,
        'runtime_reproduction': 'Measured proximity to 720 seconds motivates margin; no failing runtime run was performed or claimed.',
        'new_suite_runs_performed': False,
    },
    'measurements': measurements,
    'timeout_changes': changes,
    'step_budget_planning': planning,
    'job_budget_planning': {
        'old_timeout_minutes': 45, 'new_timeout_minutes': 90,
        'explicit_step_limits_sum_minutes': explicit_sum,
        'checkout_setup_and_upload_shared_allowance_minutes': action_sum,
        'total_planning_minutes': explicit_sum + action_sum,
        'stages_in_execution_order': stages,
        'rationale': 'The job envelope accommodates both non-runtime profiles, the runtime partition, both fresh syncs, zsh provisioning, provenance/lock checks, lint/typing, checkout, setup actions and artifact upload. Each matrix job has this budget; max-parallel stays 2.',
    },
    'validation': {
        'command': 'zsh -lc "/tmp/plato-phase2c-313/bin/python /tmp/plato-phase2-ci-budget-validation/validate.py"',
        'script': file_receipt('/tmp/plato-phase2-ci-budget-validation/validate.py'),
        'parser': {'name': 'PyYAML', 'version': yaml.__version__,
                   'module_path': yaml.__file__,
                   'loader': 'SafeLoader with true/false-only boolean resolution and duplicate mapping key rejection.'},
        'results': {
            'yaml_parse_and_unique_keys': 'PASS',
            'github_on_string_key_and_all_three_triggers_preserved': 'PASS',
            'false_boolean_semantics_preserved': 'PASS',
            'exactly_four_expected_timeout_semantic_changes': 'PASS',
            'byte_for_byte_workflow_preservation_except_four_timeout_values': 'PASS',
            'all_commands_markers_profiles_skip_guards_matrix_pins_permissions_environment_artifact_behavior_preserved': 'PASS',
            'finite_full_job_stage_accounting': 'PASS',
            'selected_raw_log_wall_report_and_junit_hashes': {'result': 'PASS', 'count': 18},
            'raw_summaries_wall_seconds_and_source_identities': 'PASS',
            'report_delivery_receipt_and_root_audit_consistency': 'PASS',
            'git_diff_check': {'command': 'zsh -lc "git diff --check"', 'exit_code': 0},
            'changed_tracked_files_before_evidence_write': [WORKFLOW],
        },
    },
    'limits_and_remaining_gates': {
        'measurement_platform': r['environments']['313']['platform'],
        'planning_status': 'Local measured durations are lower planning inputs, not Ubuntu runner measurements. Variance and overhead allowances are chosen budgets, not measured stage costs.',
        'hosted_linux_ci_pass_claimed': False,
        'remaining': ['Root-assigned fresh independent review.',
                      'Root full merged local profiles and exact-source Linux CI before acceptance/publication cleanup.'],
    },
    'changed_files': [WORKFLOW, OUTPUT],
}
assert result['reproduction']['all_four_non_runtime_runs_exceed_original_limit']
Path(OUTPUT).write_text(json.dumps(result, indent=2) + '\n')
assert json.loads(Path(OUTPUT).read_bytes()) == result
print(json.dumps({
    'result': 'PASS', 'timeout_changes': changes, 'parser': f'PyYAML {yaml.__version__}',
    'raw_hashes_verified': 18, 'source_blobs_verified': len(r['sources']),
    'explicit_step_minutes': explicit_sum, 'action_allowance_minutes': action_sum,
    'job_minutes': job['timeout-minutes'], 'workflow_after': file_receipt(WORKFLOW),
    'evidence': file_receipt(OUTPUT),
}, indent=2))
