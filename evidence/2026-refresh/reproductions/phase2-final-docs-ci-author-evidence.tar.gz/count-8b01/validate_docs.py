import hashlib, io, json, platform, re, shlex, subprocess, sys, tarfile, tomllib
from pathlib import Path
import markdown
ROOT=Path("/private/tmp/plato-refresh-worktrees/scaffold-docs")
OUT=Path("/tmp/plato-phase2c-scaffold-docs/count-8b01")
BASE="8b01bf47ca8bdf9232bffeb4e50f78d4f00c9e3b"
PRIOR="69d7d8a7841589205283f13f0e07771fb1e325bd"
PAGE="docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md"
DOCS=["examples/customized_client_training/"+a+"/README.md" for a in ("scaffold","feddyn")]+[PAGE]
checks={}
def shell(cmd,cwd=ROOT):
    return subprocess.run(["zsh","-lc",cmd],cwd=cwd,capture_output=True)
def git(*args):
    r=shell(shlex.join(["git",*args])); r.check_returncode(); return r.stdout
def run(name,cmd,cwd=ROOT):
    r=shell(cmd,cwd); log=OUT/(name+".log"); log.write_bytes(r.stdout+r.stderr)
    checks[name]={"command":cmd,"cwd":str(cwd),"exit_code":r.returncode,"log":str(log),"sha256":hashlib.sha256(log.read_bytes()).hexdigest()}
    return r
def section(text,name):
    a=text.index("### "+name+"\n")
    b=text.find("\n---\n",a)
    return text[a:b if b!=-1 else len(text)]
def unowned(text):
    for a in ("SCAFFOLD","FedDyn"): text=text.replace(section(text,a),"")
    return text
page=(ROOT/PAGE).read_text()
for ref in (BASE,PRIOR):
    assert unowned(page)==unowned(git("show",ref+":"+PAGE).decode()),ref
allowed=set(DOCS+["evidence/2026-refresh/phase2c-scaffold-docs-validation.json","evidence/2026-refresh/phase2c-algorithm-docs-validation.json","evidence/2026-refresh/phase2c-algorithm-docs-count-reconciliation.json"])
changes=set(git("diff","--name-only",BASE).decode().splitlines())
assert changes<=allowed,changes
blobs=0
for line in git("ls-tree","-r",BASE).decode().splitlines():
    metadata,path=line.split("\t",1)
    if path in allowed: continue
    kind,oid=metadata.split()[1:]
    if kind!="blob": continue
    data=(ROOT/path).read_bytes()
    assert hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()==oid,path
    blobs+=1
assert (ROOT/"evidence/2026-refresh/phase2c-scaffold-docs-validation.json").read_bytes()==git("show",PRIOR+":evidence/2026-refresh/phase2c-scaffold-docs-validation.json")
assert section(page,"SCAFFOLD")==section(git("show",PRIOR+":"+PAGE).decode(),"SCAFFOLD")
for p in ("examples/customized_client_training/scaffold/README.md","evidence/2026-refresh/phase2c-algorithm-docs-validation.json"):
    assert (ROOT/p).read_bytes()==git("show",PRIOR+":"+p)
commands=[]
rendered=[]
for path in DOCS:
    text=(ROOT/path).read_text()
    parts=[(Path(path).parent.name,text)] if path!=PAGE else [(a+"-section",section(text,a)) for a in ("SCAFFOLD","FedDyn")]
    for label,doc in parts:
        html=markdown.markdown(doc,extensions=["admonition","pymdownx.details","pymdownx.superfences","pymdownx.arithmatex"],extension_configs={"pymdownx.arithmatex":{"generic":True}})
        assert 'class="arithmatex"' in html and chr(96)*3 not in html
        assert ('1910.06378v4' if label.lower().startswith("scaffold") else '2111.04263v1') in html
        if "section" in label: assert 'class="admonition note"' in html
        (OUT/(label+".html")).write_text(html)
        rendered.append({"path":path,"part":label,"math_elements":html.count('class="arithmatex"'),"code_elements":html.count('<code>')})
        for block in re.findall(r"^"+chr(96)*3+r"bash\n(.*?)"+chr(96)*3,doc,re.M|re.S):
            cwd=ROOT
            for line in block.replace("\\\n"," ").splitlines():
                argv=shlex.split(line)
                if not argv: continue
                if argv[0]=="cd": cwd=cwd/argv[1]; assert cwd.is_dir()
                elif argv[:3]==["uv","run","python"]:
                    assert (cwd/argv[3]).is_file()
                    config=cwd/argv[argv.index("-c")+1]
                    assert config.is_file()
                    a=config.parent.name
                    data=tomllib.loads(config.read_text())
                    assert data["trainer"]["model_name"]=="lenet5" and data["data"]["dataset_name"]=="MNIST" and data["data"]["download"] is True
                    expected={"scaffold":(5,2,3,5,2,.01,.9),"feddyn":(1000,10,20,3,3,.03,0)}[a]
                    actual=(data["clients"]["total_clients"],data["clients"]["per_round"],data["trainer"]["epochs"],data["trainer"]["rounds"],data["trainer"]["max_concurrency"],data["parameters"]["optimizer"]["lr"],data["parameters"]["optimizer"]["momentum"])
                    assert expected==actual and data["parameters"]["optimizer"]["weight_decay"]==0
                    if a=="feddyn": assert data["algorithm"]["alpha_coef"]==.01 and data["algorithm"]["feddyn_weighting"]=="uniform"
                else: assert argv==["uv","sync"]
                commands.append({"cwd":str(cwd),"argv":argv})
env=shlex.join(["env","PYTHONDONTWRITEBYTECODE=1","PYTHONPATH="+str(ROOT),"UV_PROJECT_ENVIRONMENT="+"/tmp/plato-phase2c-scaffold-docs/final-13e/venv"])
for a in ("scaffold","feddyn"):
    cmd=env+" "+shlex.join(["uv","run","--no-sync","python",f"examples/customized_client_training/{a}/{a}.py","--help"])
    r=run(a+"-help",cmd); r.check_returncode()
    for flag in ("--config","--base","--cpu","--resume"): assert flag.encode() in r.stdout
    for where in ("root","examples"):
        cwd=ROOT if where=="root" else ROOT/"examples/customized_client_training"
        config=f"examples/customized_client_training/{a}/{a}_MNIST_lenet5.toml" if where=="root" else f"{a}/{a}_MNIST_lenet5.toml"
        probe="import json; from plato.config import Config; c=Config(); assert c.args.cpu and c.args.resume; assert c.trainer.model_name=='lenet5'; print(json.dumps({'config':c.args.config,'base':c.params['base_path'],'checkpoint':c.params['checkpoint_path'],'cpu':c.args.cpu,'resume':c.args.resume}))"
        if a=="feddyn":
            probe+="; from plato.trainers.strategies.algorithms.feddyn_strategy import settings_from_config; print(settings_from_config())"
        cmd=env+" "+shlex.join([sys.executable,"-c",probe,"-c",config,"--cpu","--resume","-b",str(OUT/"config-probes"/(a+"-"+where))])
        r=run(a+"-config-"+where,cmd,cwd); r.check_returncode()
baseline=OUT/"baseline"; baseline.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(git("archive",BASE,"docs"))) as t: t.extractall(baseline,filter="data")
warns=[]
for name,config in (("baseline",baseline/"docs/mkdocs.yml"),("candidate",ROOT/"docs/mkdocs.yml")):
    cmd=shlex.join([sys.executable,"-m","mkdocs","build","--strict","-f",str(config),"-d",str(OUT/(name+"-site"))])
    r=run("mkdocs-"+name,cmd)
    assert r.returncode==1
    warns.append([s for s in (r.stdout+r.stderr).decode().splitlines() if s.startswith("WARNING -")])
assert warns[0]==warns[1] and len(warns[0])==2 and all("Nanochat" in w for w in warns[0]),warns
r=run("diff-check","git diff --check"); r.check_returncode()
summary={"base":BASE,"base_tree":git("rev-parse",BASE+"^{tree}").decode().strip(),"merge":git("rev-parse","HEAD").decode().strip(),"python":platform.python_version(),"unchanged_pinned_blobs":blobs,"unrelated_sections_identical_to":[BASE,PRIOR],"prior_evidence_unchanged":True,"documented_commands":commands,"markdown_render":rendered,"executed_checks":checks,"strict_build_baseline_warnings":warns[0],"doc_sha256":{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in DOCS}}
(OUT/"checks.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps({k:summary[k] for k in ("base","python","unchanged_pinned_blobs","strict_build_baseline_warnings","doc_sha256")},indent=2))

