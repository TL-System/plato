import ast,datetime,hashlib,json,re,shlex,subprocess
from pathlib import Path
OUT=Path("/tmp/plato-phase2c-scaffold-docs/count-8b01")
BASE="8b01bf47ca8bdf9232bffeb4e50f78d4f00c9e3b"
PRIOR="69d7d8a7841589205283f13f0e07771fb1e325bd"
OLD="13e38dafce476286db7e673e7f21343d54416b56"
REPORT=Path("evidence/2026-refresh/phase2c-algorithm-docs-count-reconciliation.json")
def git(*args):
 r=subprocess.run(["zsh","-lc",shlex.join(["git",*args])],capture_output=True);r.check_returncode();return r.stdout
def sha(data):return hashlib.sha256(data).hexdigest()
def receipt(p):return {"path":str(p),"sha256":sha(Path(p).read_bytes())}
checks=json.loads((OUT/"checks.json").read_text())
review=Path("/Users/bli/Playground/plato/evidence/2026-refresh/phase2c-algorithm-docs-review.json")
inputs=[review]+[Path("evidence/2026-refresh")/n for n in ("phase2c-feddyn-count-fixes-facts.json","phase2c-feddyn-count-fixes-validation.json","phase2c-feddyn-count-fixes-delivery-receipt.json")]
expected=("add5e422b2be3799e857ce10fc52402a5b5bc50fa21a91b74da6ce97c7823076","2b8154918100e23f20ba27c2f9c269030b7bf54a2fb1675c5d678bae64247a8e","0352d54214cfdb32d7790f35a3071579a6bc75e1781b79d1af41bde6ca673458")
for p,h in zip(inputs,expected):assert sha(p.read_bytes())==h
facts=json.loads(inputs[1].read_text())
validation=json.loads(inputs[2].read_text())
# Static source preservation: these algorithm/state/RNG definitions did not change.
strategy="plato/trainers/strategies/algorithms/feddyn_strategy.py"
server="examples/customized_client_training/feddyn/feddyn_server.py"
stable={strategy:["effective_alpha","settings_from_config","FedDynLossStrategy","FedDynLossStrategyFromConfig"],server:["aggregate_weights","_snapshot","_validate_rng","_resume_from_checkpoint","start"]}
def node(text,name):
 return ast.dump(next(n for n in ast.walk(ast.parse(text)) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and n.name==name),include_attributes=False)
for p,names in stable.items():
 old=git("show",OLD+":"+p).decode();new=Path(p).read_text()
 for n in names:assert node(old,n)==node(new,n),(p,n)
for p in checks["doc_sha256"]:
 text=Path(p).read_text();old=git("show",PRIOR+":"+p).decode()
 assert re.findall(r"https?://[^\s)>\]]+",text)==re.findall(r"https?://[^\s)>\]]+",old),p
historical=["evidence/2026-refresh/phase2c-scaffold-docs-validation.json","evidence/2026-refresh/phase2c-algorithm-docs-validation.json"]
for p in historical:assert Path(p).read_bytes()==git("show",PRIOR+":"+p)
sources=["AGENTS.md","examples/customized_client_training/feddyn/feddyn_trainer.py",server,strategy,"plato/trainers/strategies/algorithms/__init__.py","tests/integration/test_feddyn_count_boundaries.py","tests/integration/feddyn_count_worker.py","plato/trainers/composable.py","examples/customized_client_training/feddyn/feddyn_MNIST_lenet5.toml","examples/customized_client_training/scaffold/scaffold_MNIST_lenet5.toml","plato/config.py","docs/mkdocs.yml"]
report={
 "schema_version":1,
 "written_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
 "status":"SOURCE_RECONCILED_DOC_L01_ADDRESSED_FRESH_BOUNDED_WRITING_VERIFICATION_PENDING",
 "identities":{"source_commit":BASE,"source_tree":"1cb086b9db386128ba6a965c198e8c07400ab9be","prior_reviewed_prose":PRIOR,"separate_dependency_merge":git("rev-parse","HEAD").decode().strip(),"dependency_merge_tree":git("rev-parse","HEAD^{tree}").decode().strip(),"conflicts":False,"candidate":"Containing commit; public prose hashes below. Final commit/tree supplied in clean handoff."},
 "inputs":[receipt(p) for p in inputs],
 "historical_reports":{"preserved":[receipt(p) for p in historical],"interpretation":"Previous writer execution/source and pending-review statements remain historical at their stated snapshots. This receipt reconciles current source8b01; neither old test totals nor the prior writing PASS qualify corrected FedDyn code."},
 "public_changes":{"DOC-L01":"Both FedDyn support paragraphs now say: Qualification covers CPU float32/float64 execution. Enforced dtype/optimizer constraints remain separate; no blanket GPU rejection or GPU support feature is stated.","DOC-L02":"Corrected overview docstring arrived in C's authorized dependency merge; writer did not edit source.","other_prose":"Unchanged from69d, including both SCAFFOLD prose locations, FedDyn equations/count modes/migration/resume, and all unrelated algorithms."},
 "source_reconciliation":[
  {"locations":["feddyn_trainer.realized_partition","Trainer._bind_attempt_partition","Trainer.train","Trainer.train_model","CountedLoader.create_train_loader"],"finding":"Parent resolves the partition once, binds positive actual cardinality before spawn and passes the same realized sampler. Direct training binds the same count; backing dataset size or a fresh partition draw is not authority."},
  {"locations":["FedDynUpdateStrategy.load_worker_state","Trainer._transaction"],"finding":"Worker count must match the independent current-attempt count even when first uniform dispatch has no historical expected count. Rejected handoff restores owned parent state and refuses outbound eligibility; existing guide's actual-count/current-handoff claims remain accurate."},
  {"locations":["Server._validate_bundle","Server._resume_from_checkpoint"],"finding":"Each nonzero saved history requires a saved positive native integer count. Complete validation precedes any live model/history/count/round/config or pending RNG installation.","limit":"A zero history does not always prove nonparticipation. Missing zero-history counts are not comprehensively detectable; no new participation ledger or generalized tamper-detection claim."},
  {"locations":["Server._process_reports","same_state"],"finding":"Receive and aggregation callbacks compare observed count maps with recursive type-sensitive key/value equality, including inactive clients; failure precedes commit. Existing owned-state callback/evaluation boundary remains unchanged."},
  {"locations":["tests/integration/test_feddyn_count_boundaries.py","tests/integration/feddyn_count_worker.py"],"finding":"Read actual assertions for first-uniform spawned count rejection/retry, single-draw sampler over larger backing data, nonzero-history missing-count rejection before live/pending mutation, and inactive count key/value type changes. Inspection only; writer executed no tests."}
 ],
 "unchanged_source_checks":{"AST_identical_to_13e":stable,"meaning":"Numerical loss/coefficient/server equations, configuration, bundle snapshot schema and full CPU RNG resume definitions are unchanged. Shared lifecycle/SCAFFOLD production is unchanged; wire metadata and migration paths have no semantic change."},
 "source_sha256":{p:sha(Path(p).read_bytes()) for p in sources},
 "prose_sha256":{"prior_69d":{p:sha(git("show",PRIOR+":"+p)) for p in checks["doc_sha256"]},"candidate":checks["doc_sha256"]},
 "writer_checks":{
  "shell":"zsh -lc for every shell command",
  "environment":"Reused writer-owned /tmp/plato-phase2c-scaffold-docs/final-13e/venv, Python "+checks["python"]+"; no environment/provisioning or manifest changes.",
  "runner":{"command":"/tmp/plato-phase2c-scaffold-docs/final-13e/venv/bin/python /tmp/plato-phase2c-scaffold-docs/count-8b01/validate_docs.py","exit_code":0,"script":receipt(OUT/"validate_docs.py"),"results":receipt(OUT/"checks.json")},
  "executed_commands":checks["executed_checks"],
  "commands_and_config":"Documented shell paths/options and shipped TOML values checked. Actual both-entrypoint --help and Config parsing from root/examples passed; --resume parsed without launching training or resume, with base directories in owned scratch.",
  "render_and_links":"Both READMEs and owned sections rendered with project math/code/admonition extensions. Primary URLs identical to reviewed69d; no new external links or research claims. No external link refetch needed for this wording-only change.",
  "strict_mkdocs":{"baseline_exit":1,"candidate_exit":1,"result":"FAIL in both, identical two pre-existing Phase5 Nanochat link warnings; no additional warning and no strict PASS claim.","warnings":checks["strict_build_baseline_warnings"]},
  "preservation":{"pinned_blobs_exact_source":checks["unchanged_pinned_blobs"],"all_production_tests_configs_manifests_preserved":True,"scaffold_prose_and_historical_evidence_unchanged":True,"unrelated_page_sections_unchanged":True,"diff_check_exit":0}
 },
 "author_execution_not_rerun":{"source":str(inputs[2]),"implementation_commit":facts["implementation_commit"],"source_carry_forward":"fac9c651 to8b01 changes only the three count-fix evidence files; writer verified diff.","affected_runs":{k:{"head":validation["executions"][k]["head"],"exit_code":validation["executions"][k]["exit_code"],"counts":validation["executions"][k]["counts"]} for k in ("affected-313","affected-314")},"attribution":"Author reports308passed,0skipped,0pytest warnings on each3.13/3.14 affected run, including actual spawned/socket coverage; not writer execution and not added to overlapping historical totals."},
 "limits":["Fresh independent FedDyn code reviewer2 is active per assignment; no acceptance asserted.","Prior69d writing review PASS is snapshot-bound; corrected-source bounded writing verification and root phase/integration gates remain.","CPU numerical/synthetic qualification only; no GPU, MNIST accuracy, convergence or in-flight recovery claim.","No training/pytest reruns, dataset downloads, new ledger, production/test/config/CI/manifest edits, push or cleanup."],
 "material_source_prose_mismatch_found":False
}
REPORT.write_text(json.dumps(report,indent=2)+"\n")
print("Wrote",REPORT)

