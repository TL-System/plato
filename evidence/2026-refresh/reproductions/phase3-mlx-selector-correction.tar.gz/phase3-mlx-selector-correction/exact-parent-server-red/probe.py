import importlib.util
import sys
from pathlib import Path
import pytest
sys.argv=['selector-final-red']
from tests.mlx_native.helpers import native_config
with native_config(Path('/tmp/plato-phase3-mlx/selector-final-red/config')):
    import plato.servers
    spec=importlib.util.spec_from_file_location('plato.servers.fedavg','/tmp/plato-phase3-mlx/selector-final-red/fedavg.py')
    module=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=module
    spec.loader.exec_module(module)
    plato.servers.fedavg=module
    raise SystemExit(pytest.main(['tests/mlx_native/test_phase3_dispatch.py','-q']))
