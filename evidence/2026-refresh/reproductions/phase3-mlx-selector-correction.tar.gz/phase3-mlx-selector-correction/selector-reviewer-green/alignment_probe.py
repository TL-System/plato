"""Demonstrate observable report/tree misalignment after the last preflight."""
import asyncio
import copy
import json
from pathlib import Path

import numpy as np

from plato.models.mlx.lenet5 import LeNet5
from plato.trainers.mlx import ComposableMLXTrainer
from tests.mlx_native.helpers import native_config, update
from tests.mlx_native.test_phase3_runtime import server_for


results = []
for kind in ('direct', 'delta', 'legacy'):
    with native_config(Path('/tmp/plato-phase3-mlx/selector-reviewer-green/alignment') / kind,
                       model_seed=17):
        trainer = ComposableMLXTrainer(model=LeNet5)
        server = server_for(trainer, kind)
        baseline = server.algorithm.extract_weights()
        first, second = copy.deepcopy(baseline), copy.deepcopy(baseline)
        first['fc3']['bias'] = np.full(10, 1, dtype=np.float32)
        second['fc3']['bias'] = np.full(10, 4, dtype=np.float32)
        server.updates = [update(1, 8, first), update(2, 24, second)]
        server.client_selection_strategy.on_reports_received = (
            lambda updates, context: updates.reverse())
        try:
            asyncio.run(server._process_reports())
            error = None
        except ValueError as exception:
            error = str(exception)
        results.append(dict(kind=kind, error=error,
                            arithmetic_called=bool(server.context.state.get(
                                'arithmetic_called')),
                            final_bias=server.algorithm.extract_weights()[
                                'fc3']['bias'].tolist(),
                            expected_bias=[3.25] * 10,
                            final_report_order=[u.client_id for u in server.updates]))
output = Path('/tmp/plato-phase3-mlx/selector-reviewer-green/alignment-results.json')
output.write_text(json.dumps(results, indent=2) + '\n')
print(output.read_text())
