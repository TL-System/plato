"""Independent probe of the hook between final ingress check and dispatch."""
import asyncio
import copy
import json
from pathlib import Path

import numpy as np

from plato.models.mlx.lenet5 import LeNet5
from plato.trainers.mlx import ComposableMLXTrainer
from tests.mlx_native.helpers import native_config, update
from tests.mlx_native.test_phase3_runtime import server_for


def main():
    results = []
    root = Path('/tmp/plato-mlx-native-review-artifacts/dispatch-runtime')
    for kind in ('direct', 'delta', 'legacy'):
        for reverse in (False, True):
            with native_config(root / f'{kind}-{reverse}', model_seed=17):
                trainer = ComposableMLXTrainer(model=LeNet5)
                server = server_for(trainer, kind)
                baseline = server.algorithm.extract_weights()
                good = copy.deepcopy(baseline)
                second = copy.deepcopy(baseline)
                good['fc3']['bias'] = np.ones(10, dtype=np.float32)
                second['fc3']['bias'] = np.full(10, 4, dtype=np.float32)
                server.updates = [update(1, 8, good), update(2, 24, second)]
                if reverse:
                    server.updates.reverse()

                def late_hook(updates, context):
                    second['fc3']['bias'] = np.full(1, 4, dtype=np.float32)

                server.client_selection_strategy.on_reports_received = late_hook
                try:
                    asyncio.run(server._process_reports())
                    error = None
                except ValueError as exception:
                    error = str(exception)
                final = server.algorithm.extract_weights()
                results.append(dict(
                    kind=kind, reverse=reverse, rejected=error is not None,
                    error=error, arithmetic_called=bool(
                        server.context.state.get('arithmetic_called')),
                    final_bias=final['fc3']['bias'].tolist(),
                    model_changed=not np.array_equal(
                        final['fc3']['bias'], baseline['fc3']['bias']),
                    received_bad_shape=list(second['fc3']['bias'].shape),
                    expected_shape=list(baseline['fc3']['bias'].shape)))
    output = Path('/tmp/plato-mlx-native-review-artifacts/dispatch-results.json')
    output.write_text(json.dumps(results, indent=2) + '\n')
    print(output.read_text())


if __name__ == '__main__':
    main()
