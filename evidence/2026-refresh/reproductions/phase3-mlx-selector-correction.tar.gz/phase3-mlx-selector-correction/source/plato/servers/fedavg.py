"""
A simple federated learning server using federated averaging.
"""

import logging
import os

from plato.algorithms import registry as algorithms_registry
from plato.config import Config
from plato.datasources import registry as datasources_registry
from plato.processors import registry as processor_registry
from plato.samplers import all_inclusive
from plato.servers import base, evaluation_logging
from plato.servers.strategies.aggregation import FedAvgAggregationStrategy
from plato.servers.strategies.aggregation.fedavg import validate_aggregation_inputs
from plato.trainers import registry as trainers_registry
from plato.utils import csv_processor, fonts


class Server(base.Server):
    """Federated learning server using federated averaging."""

    def __init__(
        self,
        model=None,
        datasource=None,
        algorithm=None,
        trainer=None,
        callbacks=None,
        aggregation_strategy=None,
        client_selection_strategy=None,
    ):
        super().__init__(
            callbacks=callbacks, client_selection_strategy=client_selection_strategy
        )

        self.custom_model = model
        self.model = None

        self.custom_algorithm = algorithm
        self.algorithm = None

        self.custom_trainer = trainer
        self.trainer = None

        self.custom_datasource = datasource
        self.datasource = None

        self.testset = None
        self.testset_sampler = None
        self.total_samples = 0

        self.total_clients = Config().clients.total_clients
        self.clients_per_round = Config().clients.per_round

        # Initialize aggregation strategy (default: FedAvg)
        self.aggregation_strategy = aggregation_strategy or FedAvgAggregationStrategy()

        logging.info(
            "[Server #%d] Started training on %d clients with %d per round.",
            os.getpid(),
            self.total_clients,
            self.clients_per_round,
        )

    def configure(self) -> None:
        """
        Booting the federated learning server by setting up the data, model, and
        creating the clients.
        """
        super().configure()

        total_rounds = Config().trainer.rounds
        target_accuracy = None
        target_perplexity = None

        if hasattr(Config().trainer, "target_accuracy"):
            target_accuracy = Config().trainer.target_accuracy
        elif hasattr(Config().trainer, "target_perplexity"):
            target_perplexity = Config().trainer.target_perplexity

        if target_accuracy:
            logging.info(
                "Training: %s rounds or accuracy above %.1f%%\n",
                total_rounds,
                100 * target_accuracy,
            )
        elif target_perplexity:
            logging.info(
                "Training: %s rounds or perplexity below %.1f\n",
                total_rounds,
                target_perplexity,
            )
        else:
            logging.info("Training: %s rounds\n", total_rounds)

        self.init_trainer()

        # Prepares this server for processors that processes outbound and inbound
        # data payloads
        self.outbound_processor, self.inbound_processor = processor_registry.get(
            "Server", server_id=os.getpid(), trainer=self.trainer
        )

        # Setup context for aggregation strategy
        self.context.trainer = self.trainer
        self.context.algorithm = self.algorithm

        # Setup aggregation strategy
        self.aggregation_strategy.setup(self.context)

        if not (hasattr(Config().server, "do_test") and not Config().server.do_test):
            if self.datasource is None and self.custom_datasource is None:
                self.datasource = datasources_registry.get(client_id=0)
            elif self.datasource is None and self.custom_datasource is not None:
                self.datasource = self.custom_datasource()

            datasource = self.require_datasource()
            self.testset = datasource.get_test_set()
            if hasattr(Config().data, "testset_size"):
                self.testset_sampler = all_inclusive.Sampler(datasource, testing=True)

        # Initialize the test accuracy csv file if clients compute locally
        if (
            hasattr(Config().clients, "do_test")
            and Config().clients.do_test
            and (
                hasattr(Config(), "results")
                and hasattr(Config().results, "record_clients_accuracy")
                and Config().results.record_clients_accuracy
            )
        ):
            accuracy_csv_file = (
                f"{Config().params['result_path']}/{os.getpid()}_accuracy.csv"
            )
            accuracy_headers = ["round", "client_id", "accuracy"]
            csv_processor.initialize_csv(
                accuracy_csv_file, accuracy_headers, Config().params["result_path"]
            )

    def init_trainer(self) -> None:
        """Setting up the global model, trainer, and algorithm."""
        if self.model is None and self.custom_model is not None:
            self.model = self.custom_model

        if self.trainer is None and self.custom_trainer is None:
            self.trainer = trainers_registry.get(model=self.model)
        elif self.trainer is None and self.custom_trainer is not None:
            self.trainer = self.custom_trainer(model=self.model)

        if self.algorithm is None and self.custom_algorithm is None:
            self.algorithm = algorithms_registry.get(trainer=self.trainer)
        elif self.algorithm is None and self.custom_algorithm is not None:
            self.algorithm = self.custom_algorithm(trainer=self.trainer)

    def _validate_aggregation_inputs(
        self, updates: list, payloads: list, baseline_weights=None
    ) -> None:
        """Validate ingress before dispatch; backends may extend tree validation."""
        validate_aggregation_inputs(updates, payloads)
        algorithm = self.algorithm
        validator = getattr(algorithm, "validate_weights", None)
        if callable(validator):
            baseline = (
                algorithm.extract_weights()
                if baseline_weights is None else baseline_weights
            )
            for update, payload in zip(updates, payloads, strict=True):
                if getattr(update.report, "type", "weights") != "features":
                    validator(payload, baseline, client_id=update.client_id)

    def _validate_original_positions(
        self, original: tuple, current: list, description: str
    ) -> None:
        """Reject observable reassociation within the positional hook contract."""
        positions = {}
        for index, item in enumerate(original):
            positions.setdefault(id(item), set()).add(index)
        for index, item in enumerate(current):
            original_positions = positions.get(id(item))
            if original_positions is not None and index not in original_positions:
                raise ValueError(
                    f"client {self.updates[index].client_id}: {description} "
                    "reordered the original client association."
                )

    async def aggregate_deltas(self, updates, deltas_received):
        """Aggregate weight updates from the clients using federated averaging.

        This method now delegates to the aggregation_strategy for extensibility.
        Subclasses can still override this method for backward compatibility.
        """
        self._validate_aggregation_inputs(updates, deltas_received)
        # Delegate to aggregation strategy
        self.context.updates = updates
        self.context.current_round = self.current_round

        avg_update = await self.aggregation_strategy.aggregate_deltas(
            updates, deltas_received, self.context
        )

        # Update total_samples for compatibility
        self.total_samples = sum(update.report.num_samples for update in updates)

        return avg_update

    async def _process_reports(self):
        """Process the client reports by aggregating their weights."""
        weights_received = [update.payload for update in self.updates]
        algorithm = self.require_algorithm()
        baseline_weights = (
            algorithm.extract_weights()
            if callable(getattr(algorithm, "validate_weights", None)) else None
        )
        self._validate_aggregation_inputs(
            self.updates, weights_received, baseline_weights
        )
        received_order = tuple(weights_received)
        if baseline_weights is not None:
            received_updates = tuple(self.updates)
            received_reports = tuple(update.report for update in self.updates)
            received_clients = tuple(update.client_id for update in self.updates)

        weights_received = self.weights_received(weights_received)
        self.callback_handler.call_event("on_weights_received", self, weights_received)
        self._validate_aggregation_inputs(
            self.updates, weights_received, baseline_weights
        )
        if baseline_weights is not None:
            self._validate_original_positions(
                received_order, weights_received, "transformed weights"
            )

        # Notify client selection strategy about received reports
        self.context.updates = self.updates
        self.context.current_round = self.current_round
        self.client_selection_strategy.on_reports_received(self.updates, self.context)

        if baseline_weights is not None:
            # The selector is the last mutable hook before aggregation dispatch.
            self._validate_aggregation_inputs(
                self.updates, weights_received, baseline_weights
            )
            self._validate_original_positions(
                received_order, weights_received, "transformed weights"
            )
            self._validate_original_positions(
                received_updates, self.updates, "received reports"
            )
            self._validate_original_positions(
                received_reports,
                [update.report for update in self.updates],
                "received reports",
            )
            for update, client_id in zip(self.updates, received_clients, strict=True):
                if update.client_id != client_id:
                    raise ValueError(
                        f"client {update.client_id}: report association changed "
                        f"from original client {client_id}."
                    )

        # Extract the current model weights as the baseline
        if baseline_weights is None:
            baseline_weights = algorithm.extract_weights()

        # Check if we should aggregate weights directly or use deltas
        # Try strategy's aggregate_weights first, fall back to aggregate_deltas
        strategy_weights = None
        if self._should_prefer_weight_aggregation():
            strategy_weights = await self.aggregation_strategy.aggregate_weights(
                self.updates, baseline_weights, weights_received, self.context
            )

        aggregate_weights_fn = getattr(self, "aggregate_weights", None)

        if strategy_weights is not None:
            # Strategy provided weight aggregation
            logging.info(
                "[Server #%d] Aggregating model weights directly rather than weight deltas.",
                os.getpid(),
            )
            updated_weights = strategy_weights
            # Loads the new model weights
            algorithm.load_weights(updated_weights)
        elif callable(aggregate_weights_fn):
            # Backward compatibility: subclass overrode aggregate_weights
            logging.info(
                "[Server #%d] Aggregating model weights directly rather than weight deltas.",
                os.getpid(),
            )
            updated_weights = await aggregate_weights_fn(
                self.updates, baseline_weights, weights_received
            )
            # Loads the new model weights
            algorithm.load_weights(updated_weights)
        else:
            # Use delta aggregation (default path)
            # Computes the weight deltas by comparing the weights received with
            # the current global model weights
            deltas_received = algorithm.compute_weight_deltas(
                baseline_weights, weights_received
            )
            # Runs a framework-agnostic server aggregation algorithm, such as
            # the federated averaging algorithm
            logging.info("[Server #%d] Aggregating model weight deltas.", os.getpid())
            deltas = await self.aggregate_deltas(self.updates, deltas_received)
            # Updates the existing model weights from the provided deltas
            updated_weights = algorithm.update_weights(deltas)
            # Loads the new model weights
            algorithm.load_weights(updated_weights)

        # The model weights have already been aggregated, now calls the
        # corresponding hook and callback
        self.weights_aggregated(self.updates)
        self.callback_handler.call_event("on_weights_aggregated", self, self.updates)

        # Testing the global model accuracy
        if hasattr(Config().server, "do_test") and not Config().server.do_test:
            # Compute the average accuracy from client reports
            self.accuracy, self.accuracy_std = self.get_accuracy_mean_std(self.updates)
            logging.info(
                "[%s] Average client accuracy: %.2f%%.", self, 100 * self.accuracy
            )
        else:
            # Testing the updated model directly at the server
            logging.info("[%s] Started model testing.", self)
            trainer = self.require_trainer()
            self.accuracy = trainer.test(self.testset, self.testset_sampler)

            # Extract CORE evaluation results if available (Nanochat CORE evaluation)
            if (
                hasattr(trainer, "context")
                and "nanochat_core_results" in trainer.context.state
            ):
                core_results = trainer.context.state["nanochat_core_results"]
                self._core_metric = core_results.get("core_metric", self.accuracy)

        # If CORE benchmark was run via a Nanochat testing strategy, report the specialized CORE metric instead of the generic 'Global model accuracy' label.
        core_metric = getattr(self, "_core_metric", None)

        if core_metric is not None:
            logging.info(
                fonts.colourize(
                    f"[{self}] Average Centered CORE benchmark metric: {100 * core_metric:.2f}%\n"
                )
            )
        elif hasattr(Config().trainer, "target_perplexity"):
            logging.info(
                fonts.colourize(
                    f"[{self}] Global model perplexity: {self.accuracy:.2f}\n"
                )
            )
        else:
            logging.info(
                fonts.colourize(
                    f"[{self}] Global model accuracy: {100 * self.accuracy:.2f}%\n"
                )
            )

        self.clients_processed()
        self.callback_handler.call_event("on_clients_processed", self)

    def _should_prefer_weight_aggregation(self) -> bool:
        """Return whether the strategy should use direct weight aggregation."""
        strategy_cls = type(self.aggregation_strategy)
        aggregate_weights_impl = getattr(strategy_cls, "aggregate_weights", None)
        aggregate_deltas_impl = getattr(strategy_cls, "aggregate_deltas", None)

        if aggregate_weights_impl is None:
            return False

        return not (
            aggregate_weights_impl is FedAvgAggregationStrategy.aggregate_weights
            and aggregate_deltas_impl is not FedAvgAggregationStrategy.aggregate_deltas
        )

    def clients_processed(self) -> None:
        """Additional work to be performed after client reports have been processed."""

    def get_logged_items(self) -> dict:
        """Get items to be logged by the LogProgressCallback class in a .csv file."""
        logged = {
            "round": self.current_round,
            "accuracy": self.accuracy,
            "core_metric": getattr(self, "_core_metric", None),
            "accuracy_std": self.accuracy_std,
            "elapsed_time": self.wall_time - self.initial_wall_time,
            "processing_time": max(
                update.report.processing_time for update in self.updates
            ),
            "comm_time": max(update.report.comm_time for update in self.updates),
            "round_time": max(
                update.report.training_time
                + update.report.processing_time
                + update.report.comm_time
                for update in self.updates
            ),
            "comm_overhead": self.comm_overhead,
        }

        # Add train_loss if available from client reports
        if self.updates and hasattr(self.updates[0].report, "train_loss"):
            # Compute weighted average of train_loss across clients
            total_samples = sum(
                update.report.num_samples
                for update in self.updates
                if update.report.train_loss is not None
            )
            if total_samples > 0:
                weighted_loss = sum(
                    update.report.train_loss * update.report.num_samples
                    for update in self.updates
                    if update.report.train_loss is not None
                )
                logged["train_loss"] = weighted_loss / total_samples
            else:
                logged["train_loss"] = None

        # Add core_metric if Nanochat CORE evaluation was performed
        if hasattr(self, "_core_metric"):
            logged["core_metric"] = self._core_metric

        logged.update(evaluation_logging.extract_logged_items(self.trainer))

        return logged

    @staticmethod
    def get_accuracy_mean_std(updates):
        """Compute the accuracy mean and standard deviation across clients."""
        # Get total number of samples
        total_samples = sum(update.report.num_samples for update in updates)
        if total_samples == 0:
            return 0.0, 0.0

        # Perform weighted averaging
        updates_accuracy = [update.report.accuracy for update in updates]
        weights = [update.report.num_samples / total_samples for update in updates]

        mean = sum(acc * weights[idx] for idx, acc in enumerate(updates_accuracy))
        variance = sum(
            (acc - mean) ** 2 * weights[idx] for idx, acc in enumerate(updates_accuracy)
        )
        std = variance**0.5

        return mean, std

    def weights_received(self, weights_received):
        """
        Method called after the updated weights have been received.
        """
        return weights_received

    def weights_aggregated(self, updates):
        """
        Method called after the updated weights have been aggregated.
        """
