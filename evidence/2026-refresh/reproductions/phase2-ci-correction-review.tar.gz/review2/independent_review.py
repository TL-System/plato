import ast
import copy
import hashlib
import importlib.util
import json
import os
import shlex
import subprocess
import sys
import time
from pathlib import Path

import yaml

sys.dont_write_bytecode = True
ROOT = Path('/tmp/plato-refresh-worktrees/phase2-ci-budget')
OUT = Path('/tmp/plato-ci-internal-review2')
HEAD = 'ae3d066664d1eb5715cd20e5792b9e9c3e605240'
TREE = 'ad96807bf04ee9b04f6973266e61fff36f20455e'
PARENT = '0ada82cca599310c40d4a6691aaa16a0e737f2fd'
BASE = '9ee92c52307cd3ecdce0c7416708c504bdb52137'
WF = '.github/workflows/pytorch_tests.yml'
HELPER = ROOT / '.github/scripts/stage_ci_artifacts.py'
AUTHOR = Path('/tmp/plato-phase2-ci-budget-validation')
OLD_REVIEW = Path('/tmp/plato-ci-internal-review')
RUNTIME = Path('/tmp/plato-phase2c-feddyn-implementation/combined-mandatory-runtime-313')
OUT.mkdir(exist_ok=True)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def receipt(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def git(*arguments):
    return subprocess.check_output(['git', '-C', str(ROOT), *arguments], text=True).strip()


def run(command, **kwargs):
    result = subprocess.run(command, capture_output=True, text=True, **kwargs)
    return result


class UniqueLoader(yaml.BaseLoader):
    pass


def unique_map(loader, node, deep=False):
    result = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        assert key not in result, ('duplicate YAML key', key)
        result[key] = loader.construct_object(value_node, deep=deep)
    return result


UniqueLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, unique_map)
before = yaml.load(git('show', BASE + ':' + WF), Loader=UniqueLoader)
prior = yaml.load(git('show', PARENT + ':' + WF), Loader=UniqueLoader)
current = yaml.load((ROOT / WF).read_text(), Loader=UniqueLoader)
assert git('rev-parse', 'HEAD') == HEAD
assert git('rev-parse', 'HEAD^{tree}') == TREE
assert git('rev-parse', 'HEAD^') == PARENT
assert not git('status', '--porcelain')
assert set(git('diff', '--name-only', BASE, HEAD).splitlines()) == {
    WF, '.github/scripts/stage_ci_artifacts.py',
    'evidence/2026-refresh/phase2-ci-budget-validation.json',
}
assert set(current['on']) == {'push', 'pull_request', 'workflow_dispatch'}
job = current['jobs']['PyTorch-Tests']
steps = job['steps']
stage = steps[-2]
upload = steps[-1]
assert stage['name'] == 'Stage qualification outputs without pytest aliases'
assert stage['if'] == upload['if'] == 'always()'
assert stage['env'] == {'QUALIFICATION_STATUS': '${{ job.status }}'}
assert upload['with']['path'] == 'ci-artifacts-upload/'
assert 'continue-on-error' not in job
assert all('continue-on-error' not in step for step in steps)
assert job['timeout-minutes'] == '110'
assert job['strategy']['matrix']['include'] == [
    {'python': '3.13', 'profile': 'supported-default'}
]
assert [steps[i]['timeout-minutes'] for i in [6, 8, 9, 11]] == ['25', '30', '16', '2']
assert sum(int(step.get('timeout-minutes', '0')) for step in steps) == 101
restored = copy.deepcopy(current)
restored_job = restored['jobs']['PyTorch-Tests']
old_job = before['jobs']['PyTorch-Tests']
restored_job['timeout-minutes'] = old_job['timeout-minutes']
restored_job['strategy']['matrix'] = old_job['strategy']['matrix']
for index in [6, 8]:
    restored_job['steps'][index]['timeout-minutes'] = old_job['steps'][index]['timeout-minutes']
restored_job['steps'].pop(11)
restored_job['steps'][-1]['with']['path'] = old_job['steps'][-1]['with']['path']
assert restored == before
correction_restored = copy.deepcopy(current)
correction_restored['jobs']['PyTorch-Tests']['steps'][-2] = prior['jobs']['PyTorch-Tests']['steps'][-2]
assert correction_restored == prior
old_helper = git('show', PARENT + ':.github/scripts/stage_ci_artifacts.py')
helper_text = HELPER.read_text()
assert helper_text.split('\ndef main(')[0] == old_helper.split('\ndef main(')[0]
assert helper_text.rstrip().endswith('raise SystemExit(main())')
compile(helper_text, str(HELPER), 'exec')
assert max(map(len, helper_text.splitlines())) <= 88
lint = {}
for name, command in {
    'ruff_import_order': ['/tmp/plato-phase2c-313/bin/ruff', 'check', str(HELPER), '--select', 'I', '--no-cache'],
    'ruff_format': ['/tmp/plato-phase2c-313/bin/ruff', 'format', '--check', '--no-cache', str(HELPER)],
    'ty_helper': ['/tmp/plato-phase2c-313/bin/ty', 'check', str(HELPER), '--output-format', 'concise'],
    'git_diff_check': ['git', '-C', str(ROOT), 'diff', '--check', BASE, HEAD],
}.items():
    result = run(command)
    lint[name] = {'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
    assert result.returncode == 0, lint[name]
syntax = []
for index, step in enumerate(steps):
    if 'run' not in step:
        continue
    if step.get('shell') == 'python {0}':
        compile(step['run'], '<workflow-python>', 'exec')
    else:
        script = OUT / ('workflow-step-' + str(index) + '.zsh')
        script.write_text(step['run'].replace('${{ matrix.python }}', '3.13'))
        result = run(['zsh', '-lc', 'zsh -n ' + shlex.quote(str(script))])
        assert result.returncode == 0, (step['name'], result.stderr)
    syntax.append(step['name'])

spec = importlib.util.spec_from_file_location('independent_stager', HELPER)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
complete = OUT / 'small-complete-source'
partial = OUT / 'small-partial-source'
complete.mkdir()
partial.mkdir()
for name in module.EXPECTED_RECORDS:
    data = ('Independent evidence for ' + name + '\n').encode()
    (complete / name).write_bytes(data)
    if name != 'coverage.json':
        (partial / name).write_bytes(data)
wrapper = OUT / 'inject_eio.py'
wrapper.write_text('''import os
import runpy
import sys
helper = sys.argv.pop(1)
real_open = os.open
def independent_eio(path, flags, mode=0o777, *, dir_fd=None):
    if path == 'coverage.json':
        raise OSError(5, 'Independent reviewer evidence I/O failure')
    return real_open(path, flags, mode, dir_fd=dir_fd)
os.open = independent_eio
runpy.run_path(helper, run_name='__main__')
''')
cases = {}


def verify_copies(source, destination, manifest):
    for record in manifest['included']:
        staged = destination / record['path']
        assert staged.is_file() and not staged.is_symlink()
        assert staged.stat().st_size == record['bytes']
        assert sha(staged) == record['sha256'] == sha(source / record['path'])
    assert not any(path.is_symlink() for path in destination.rglob('*'))


def cli(name, source, *, require=False, inject=False, expected=0, missing=()):
    destination = OUT / (name + '-staged')
    command = [sys.executable, '-B']
    if inject:
        command.append(str(wrapper))
    command += [str(HELPER), '--source', str(source), '--destination', str(destination)]
    if require:
        command.append('--require-complete')
    started = time.monotonic()
    result = run(command)
    seconds = time.monotonic() - started
    manifest_path = destination / module.MANIFEST
    assert result.returncode == expected, (name, result.returncode, result.stderr)
    assert manifest_path.is_file(), (name, result.stderr)
    manifest = json.loads(manifest_path.read_text())
    assert manifest['missing_expected_records'] == list(missing)
    assert json.loads(result.stdout)['read_issues'] == manifest['read_issues']
    if source.is_dir():
        verify_copies(source, destination, manifest)
    cases[name] = {
        'exit_code': result.returncode, 'expected_exit_code': expected,
        'require_complete': require, 'manifest_retained': True,
        'collection_status': manifest['collection_status'],
        'source_missing': manifest['source_missing'],
        'missing_expected_records': manifest['missing_expected_records'],
        'read_issues': manifest['read_issues'], 'summary': manifest['summary'],
        'manifest': receipt(manifest_path), 'seconds': seconds,
        'included_hashes_and_sizes_verified': True,
    }
    return manifest


cli('small-complete-required', complete, require=True)
cli('small-complete-optional', complete)
cli('missing-required', partial, require=True, expected=1, missing=['coverage.json'])
cli('expected-partial', partial, missing=['coverage.json'])
for required in [False, True]:
    failed = cli('eio-' + str(required).lower(), complete, require=required,
                 inject=True, expected=1, missing=['coverage.json'])
    assert failed['read_issues'] == [{
        'path': 'coverage.json', 'operation': 'open_file_without_following_links',
        'errno': 5, 'error': 'Independent reviewer evidence I/O failure',
    }]
    absent = cli('absent-source-' + str(required).lower(), OUT / 'absent-source',
                 require=required, expected=1, missing=module.EXPECTED_RECORDS)
    assert absent['source_missing'] and not absent['included']
    assert absent['read_issues'][0]['errno'] == 2

# Reuse the prior independent fixture, preserving its original manifest/proof.
runtime_fixture = OLD_REVIEW / 'complete-source'
manifest = cli('real-runtime-complete', runtime_fixture, require=True)
included = {record['path']: record for record in manifest['included']}
actual_files = []
for directory, dirs, files in os.walk(RUNTIME, followlinks=False):
    parent = Path(directory)
    dirs[:] = [name for name in dirs if not (parent / name).is_symlink()]
    for name in files:
        original = parent / name
        if original.is_symlink() or not original.is_file():
            continue
        relative = 'runtime-tmp/' + original.relative_to(RUNTIME).as_posix()
        assert included[relative]['sha256'] == sha(original)
        actual_files.append(relative)
assert len(actual_files) == 271
checkpoint = 'runtime-tmp/review-runtime/checkpoints/model.safetensors'
assert included[checkpoint]['bytes'] > 1024 * 1024
for name in ['payload.pkl', 'start.pkl', 'received.pkl', 'committed.pkl']:
    assert 'runtime-tmp/review-runtime/replay/' + name in included
assert manifest['summary']['omitted_reasons'] == {
    'not_a_regular_file': 1, 'symlink_not_followed': 3,
    'unit_diagnostic_exceeds_size_limit': 1, 'reproducible_unit_fixture': 1,
}
assert 'base-tmp/unit0/error.json' in included
assert 'mandatory-tmp/unit0/stderr.log' in included
linux_source = Path('/tmp/plato-phase2-linux/initial-313')
linux = cli('downloaded-linux-partial', linux_source, missing=[
    'mandatory.xml', 'coverage.json', 'runtime.log', 'runtime.xml', 'ruff.log', 'ty.log',
])
assert not linux['read_issues']
assert linux['summary']['included_files'] == 3650
assert linux['summary']['included_bytes'] == 1931284
assert linux['summary']['omitted_regular_bytes'] == 968770723
linux_top = {path.name for path in linux_source.iterdir()
             if path.is_file() and not path.is_symlink()}
assert linux_top <= {record['path'] for record in linux['included']}

workflow_cases = {}
for status, source, expected in [
    ('success', complete, 0), ('success', partial, 1),
    ('failure', partial, 0), ('cancelled', partial, 0),
]:
    name = status + '-' + source.name
    workspace = OUT / ('workflow-' + name)
    workspace.mkdir()
    # Link the read-only helper/source; the staging script never follows source symlinks.
    source_dir = workspace / 'ci-artifacts'
    source_dir.mkdir()
    for path in source.iterdir():
        (source_dir / path.name).write_bytes(path.read_bytes())
    helper_copy = workspace / '.github/scripts/stage_ci_artifacts.py'
    helper_copy.parent.mkdir(parents=True)
    helper_copy.write_bytes(HELPER.read_bytes())
    shim = workspace / 'bin'
    shim.mkdir()
    (shim / 'python').symlink_to(sys.executable)
    environment = os.environ.copy()
    environment['QUALIFICATION_STATUS'] = status
    environment['PATH'] = str(shim) + os.pathsep + environment['PATH']
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    result = run(['zsh', '-lc', stage['run']], cwd=workspace, env=environment)
    assert result.returncode == expected, (name, result.stderr)
    manifest_path = workspace / 'ci-artifacts-upload' / module.MANIFEST
    wf_manifest = json.loads(manifest_path.read_text())
    verify_copies(source_dir, workspace / 'ci-artifacts-upload', wf_manifest)
    assert wf_manifest['missing_expected_records'] == ([] if source == complete else ['coverage.json'])
    workflow_cases[name] = {
        'prior_status': status, 'staging_exit_code': result.returncode,
        'manifest_retained': True, 'manifest': receipt(manifest_path),
        'upload_if_always': upload['if'],
    }

evidence = json.loads((ROOT / 'evidence/2026-refresh/phase2-ci-budget-validation.json').read_text())
checked = []


def audit(value):
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and 'sha256' in value:
            path = Path(value['path'])
            if not path.is_absolute():
                path = ROOT / path
            assert path.is_file(), path
            assert sha(path) == value['sha256'], path
            if 'bytes' in value:
                assert path.stat().st_size == value['bytes'], path
            if 'git_blob' in value:
                assert git('hash-object', str(path)) == value['git_blob'], path
            checked.append(receipt(path))
        for item in value.values():
            audit(item)
    elif isinstance(value, list):
        for item in value:
            audit(item)


audit(evidence['artifact_failure_contract_correction'])
audit(evidence['linux_followup']['source']['workflow_after'])
audit(evidence['linux_followup']['source']['helper'])
audit(evidence['linux_followup']['artifact_selection'])
for name in ['staging-failure-contract-red.json', 'staging-failure-contract-green.json',
             'staging-failure-static-proof.json', 'staging-failure-delivery.json']:
    record = json.loads((AUTHOR / name).read_text())
    audit(record)
    checked.append(receipt(AUTHOR / name))
red = json.loads((AUTHOR / 'staging-failure-contract-red.json').read_text())
green = json.loads((AUTHOR / 'staging-failure-contract-green.json').read_text())
assert red['result'] == 'FAIL'
assert set(red['failed_cases']) == {'unexpected_read_failure', 'wholly_missing_source'}
assert all(case['exit_code'] == 0 for case in red['cases'].values())
assert green['result'] == 'PASS' and not green['failed_cases']
assert green['actual_runtime_retention']['regular_files_verified_byte_for_byte'] == 271
delivery = json.loads((AUTHOR / 'staging-failure-delivery.json').read_text())
assert delivery['source']['head'] == HEAD
assert delivery['source']['tree'] == TREE
assert delivery['source']['parent'] == PARENT
assert delivery['source']['clean_status'] == ''
assert not git('status', '--porcelain')
result = {
    'result': 'PASS',
    'source': {'head': HEAD, 'tree': TREE, 'parent': PARENT,
               'review_base': BASE, 'clean_status': git('status', '--porcelain')},
    'workflow': {
        'duplicate_yaml_keys_and_triggers': 'PASS',
        'full_diff_preserves_all_test_commands_assertions_profiles_pins_permissions_env': 'PASS',
        'correction_diff_preserves_every_preceding_step': 'PASS',
        'source_selection_function_imports_constants_unchanged_from_parent': 'PASS',
        'no_job_or_step_continue_on_error': True,
        'budget_minutes': {'base': 25, 'mandatory': 30, 'runtime': 16,
                           'staging': 2, 'explicit_steps_total': 101, 'job': 110},
        'setup_upload_reserve_minutes': 6,
        'zsh_python_syntax_checked_steps': syntax,
        'exact_staging_shell_cases': workflow_cases,
    },
    'quality': lint,
    'cli_cases': cases,
    'runtime_retention': {
        'actual_source': str(RUNTIME), 'independent_fixture_source': str(runtime_fixture),
        'actual_regular_files_verified': len(actual_files),
        'large_checkpoint_and_binary_payload_start_received_committed_preserved': True,
        'aliases_fifo_unit_bulk_and_oversized_diagnostics_excluded_non_failing': True,
    },
    'linux_failed_evidence': {'original_top_level_records_retained': sorted(linux_top),
                              'all_3650_hashes_and_sizes_verified': True,
                              'summary': linux['summary']},
    'author_receipts': {'verified_count': len(checked),
                        'unique_files_verified': len({record['path'] for record in checked}),
                        'checked': checked},
    'github_documentation': [
        {'url': 'https://docs.github.com/en/actions/reference/workflows-and-actions/contexts',
         'supports': 'job.status is current job status: success, failure, cancelled.'},
        {'url': 'https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax',
         'supports': 'continue-on-error is the explicit mechanism permitting failed steps to pass the job; it is absent.'},
        {'url': 'https://docs.github.com/en/actions/reference/workflows-and-actions/expressions',
         'supports': 'always() runs despite failed/cancelled prior steps; failure() reflects any prior failed step.'},
    ],
    'limits': ['No hosted upload, cancellation or runner execution was performed.',
               'No full suites rerun; exact-source hosted Linux qualification remains pending.'],
}
(OUT / 'independent-results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'result': result['result'], 'source': result['source'],
                  'cli_exit_codes': {name: case['exit_code'] for name, case in cases.items()},
                  'runtime_files': len(actual_files), 'author_receipts': len(checked),
                  'workflow_cases': {name: case['staging_exit_code'] for name, case in workflow_cases.items()}}, indent=2))
