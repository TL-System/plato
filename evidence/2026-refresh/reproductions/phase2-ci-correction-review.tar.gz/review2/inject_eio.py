import os
import runpy
import sys
helper = sys.argv.pop(1)
real_open = os.open
def independent_eio(path, flags, mode=0o777, *, dir_fd=None):
    if path == 'coverage.json':
        raise OSError(5, 'Independent reviewer evidence I/O failure')
    return real_open(path, flags, mode, dir_fd=dir_fd)
os.open = independent_eio
runpy.run_path(helper, run_name='__main__')
