import contextlib
import hashlib
import importlib.util
import io
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path('/tmp/plato-refresh-worktrees/phase2-ci-budget')
SCRATCH = Path('/tmp/plato-ci-internal-review')
HELPER = ROOT / '.github/scripts/stage_ci_artifacts.py'
spec = importlib.util.spec_from_file_location('review_stager', HELPER)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(source, name, data):
    path = source / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return path

def check_copies(source, target, manifest):
    for item in manifest['included']:
        path = target / item['path']
        assert not path.is_symlink()
        assert path.stat().st_size == item['bytes']
        assert digest(path) == item['sha256'] == digest(source / item['path'])
    assert not any(path.is_symlink() for path in target.rglob('*'))

source = SCRATCH / 'complete-source'
source.mkdir()
for name in module.EXPECTED_RECORDS:
    write(source, name, ('authentic-' + name + '\n').encode())
write(source, 'base-tmp/unit0/error.json', b'{"error":"diagnostic"}')
write(source, 'mandatory-tmp/unit0/stderr.log', b'worker stderr')
write(source, 'mandatory-tmp/unit0/unit-model.pth', b'bulk\0' * 100)
write(source, 'mandatory-tmp/unit0/too-large.json', b'j' * (module.DIAGNOSTIC_LIMIT + 1))
actual_runtime = Path('/tmp/plato-phase2c-feddyn-implementation/combined-mandatory-runtime-313')
runtime_target = source / 'runtime-tmp'
runtime_target.mkdir()
actual_files = []
actual_symlinks = []
for directory, dirs, files in os.walk(actual_runtime, followlinks=False):
    parent = Path(directory)
    dirs[:] = [name for name in dirs if not (parent / name).is_symlink()]
    for name in files:
        path = parent / name
        relative = path.relative_to(actual_runtime)
        if path.is_symlink():
            actual_symlinks.append(relative.as_posix())
        elif path.is_file():
            target = runtime_target / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
            actual_files.append(relative.as_posix())
write(source, 'runtime-tmp/review-runtime/checkpoints/model.safetensors', b'w' * (module.DIAGNOSTIC_LIMIT + 23))
for name in ['payload.pkl', 'start.pkl', 'received.pkl', 'committed.pkl']:
    write(source, 'runtime-tmp/review-runtime/replay/' + name, b'replay\0\xff' * 19)
outside = write(SCRATCH, 'outside-secret.txt', b'outside')
(source / 'runtime-tmp/outside').symlink_to(outside)
(source / 'mandatory-tmp/unitcurrent').symlink_to('unit0', target_is_directory=True)
(source / 'mandatory-tmp/danglingcurrent').symlink_to('missing', target_is_directory=True)
os.mkfifo(source / 'base-tmp/unit0/pipe.log')

target = SCRATCH / 'complete-staged'
start = time.monotonic()
process = subprocess.run([sys.executable, str(HELPER), '--source', str(source), '--destination', str(target)], capture_output=True, text=True)
elapsed = time.monotonic() - start
assert process.returncode == 0, process.stderr
manifest = json.loads((target / module.MANIFEST).read_text())
check_copies(source, target, manifest)
included = {item['path'] for item in manifest['included']}
assert not manifest['read_issues'] and not manifest['missing_expected_records']
assert all('runtime-tmp/' + name in included for name in actual_files)
assert 'runtime-tmp/review-runtime/checkpoints/model.safetensors' in included
assert all('runtime-tmp/review-runtime/replay/' + name in included for name in ['payload.pkl', 'start.pkl', 'received.pkl', 'committed.pkl'])
assert 'base-tmp/unit0/error.json' in included and 'mandatory-tmp/unit0/stderr.log' in included
assert 'mandatory-tmp/unit0/unit-model.pth' not in included
assert 'mandatory-tmp/unit0/too-large.json' not in included

linux_source = Path('/tmp/plato-phase2-linux/initial-313')
linux_target = SCRATCH / 'linux-failure-staged'
linux_start = time.monotonic()
linux = module.stage_artifacts(linux_source, linux_target)
check_copies(linux_source, linux_target, linux)
linux_elapsed = time.monotonic() - linux_start
linux_top = {p.name for p in linux_source.iterdir() if p.is_file() and not p.is_symlink()}
assert linux_top <= {item['path'] for item in linux['included']}
assert not linux['read_issues']

fault_target = SCRATCH / 'injected-read-failure-staged'
original_open = module.os.open
def failing_open(path, flags, mode=0o777, *, dir_fd=None):
    if path == 'coverage.json':
        raise OSError(5, 'Independent deterministic I/O failure')
    return original_open(path, flags, mode, dir_fd=dir_fd)
module.os.open = failing_open
previous_argv = sys.argv
sys.argv = [str(HELPER), '--source', str(source), '--destination', str(fault_target)]
stdout = io.StringIO()
fault_exit = 0
try:
    with contextlib.redirect_stdout(stdout):
        module.main()
except SystemExit as error:
    fault_exit = error.code
finally:
    module.os.open = original_open
    sys.argv = previous_argv
fault_manifest = json.loads((fault_target / module.MANIFEST).read_text())
assert fault_exit == 0
assert fault_manifest['collection_status'] == 'STAGED_WITH_READ_ISSUES'
assert fault_manifest['missing_expected_records'] == ['coverage.json']
assert len(fault_manifest['read_issues']) == 1
assert not (fault_target / 'coverage.json').exists()

missing_target = SCRATCH / 'missing-source-staged'
missing = subprocess.run([sys.executable, str(HELPER), '--source', str(SCRATCH / 'absent'), '--destination', str(missing_target)], capture_output=True, text=True)
assert missing.returncode == 0
missing_manifest = json.loads((missing_target / module.MANIFEST).read_text())
assert missing_manifest['source_missing'] and not missing_manifest['included']

result = {
    'helper': {'path': str(HELPER), 'sha256': digest(HELPER)},
    'complete_fixture': {'exit_code': process.returncode, 'seconds': elapsed, 'summary': manifest['summary'], 'actual_prior_runtime_source': str(actual_runtime), 'actual_prior_runtime_regular_files_verified': len(actual_files), 'all_actual_prior_runtime_records_retained': True, 'runtime_large_checkpoint_and_payload_start_received_committed_replay_retained': True, 'hash_and_size_checks': True, 'unit_bulk_and_aliases_omitted': True},
    'linux_failure': {'seconds': linux_elapsed, 'summary': linux['summary'], 'missing_expected_records': linux['missing_expected_records'], 'all_top_level_records_retained': sorted(linux_top), 'hash_and_size_checks': True},
    'fault': {'main_exit_code': fault_exit, 'collection_status': fault_manifest['collection_status'], 'missing_expected_records': fault_manifest['missing_expected_records'], 'read_issues': fault_manifest['read_issues'], 'coverage_payload_absent': not (fault_target / 'coverage.json').exists()},
    'missing_source': {'cli_exit_code': missing.returncode, 'manifest_records_missing_source': missing_manifest['source_missing'], 'included_files': len(missing_manifest['included'])},
}
(SCRATCH / 'probe-results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
