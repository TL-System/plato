import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

SCRATCH = Path('/tmp/plato-ci-internal-review')
static = json.loads((SCRATCH / 'static-results.json').read_text())
probes = json.loads((SCRATCH / 'probe-results.json').read_text())

def receipt(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

report = {
    'schema_version': 1,
    'written_at_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'CHANGES_REQUESTED',
    'review_role': 'Independent fresh read-only CI correction review; no source edits, new commits, PR changes or further agents.',
    'source': static['source'],
    'findings': [{
        'id': 'CI-ARTIFACT-FAILURE-01',
        'severity': 'P2',
        'title': 'Make failed evidence collection affect the CI result after successful qualification.',
        'source': {'path': '.github/scripts/stage_ci_artifacts.py', 'line': 241, 'related_path': '.github/workflows/pytorch_tests.yml', 'related_line': 161},
        'description': 'The CLI prints collection_status, missing_expected_records and read_issues but always returns normally. Thus a selected required record that cannot be read, a missing expected record, or even a missing source directory still yields a successful staging step and an uploadable manifest. If the prior qualification steps succeeded, GitHub reports a green job even though promised evidence is absent. The manifest makes the loss inspectable, but no workflow guard enforces completeness for a successful qualification job.',
        'reproduction': 'Create all EXPECTED_RECORDS as regular files and inject OSError(errno=5) only when opening coverage.json. Execute the exact candidate main(). It returns success, writes STAGED_WITH_READ_ISSUES, reports only coverage.json missing, and leaves no staged coverage.json. Separately, run the unmodified CLI against a nonexistent source: exit 0 with a manifest and no included files.',
        'evidence': [receipt(SCRATCH / 'review_probe.py'), receipt(SCRATCH / 'probe-results.json'), receipt(SCRATCH / 'injected-read-failure-staged/artifact-selection.json'), receipt(SCRATCH / 'missing-source-staged/artifact-selection.json')],
        'requested_change': 'Keep writing the manifest and keep the upload step under always(). Return nonzero for unexpected collection/read failure, and enforce presence of required top-level records when the preceding qualification job status was successful. Partial evidence after already failed or cancelled gates can remain explicitly partial. Expected pytest symlink and reproducible-unit-fixture exclusions must remain non-failing.',
        'validation_needed': 'CLI negative fixtures must exercise exit status for unreadable required evidence and missing required evidence after successful qualification; failed-suite partial evidence must still be uploaded. Confirm prior qualification failure cannot be masked.'
    }],
    'accepted_checks': {
        'exact_candidate_cleanliness': static['source'],
        'scope': 'Only workflow, new artifact helper and evidence receipt changed relative to parent9ee92; production/tests/config/lock/submodules unchanged.',
        'workflow': static,
        'artifact_selection': probes,
        'author_receipt_integrity': '25 followup path/hash receipts independently checked, including workflow/helper blobs, profile guard, original failed Linux logs/artifacts, fixture proof, fixture script and static-validation script.',
        'budget_review': 'Base25 and mandatory30 are finite conservative planning budgets based on actual Linux base1082s and mandatory timeout1207s; job110 accommodates101 explicit step minutes plus6 setup/upload reserve and3 remaining minutes. Runtime16 and per-case watchdogs unchanged. These are planning inputs, not proof of Linux completion.',
        'runtime_retention': '271 real regular files from prior macOS3.13 runtime tree, including socket payload/results/checkpoints and replay records, copied to an independent fixture and retained byte-for-byte. Separate checkpoint >1MiB and binary payload/start/received/committed records retained. These prove staging retention, not a new runtime pass.',
        'linux_failure_staging': 'All12 downloaded failed3.13 top-level records plus unit diagnostics retained. All3650 staged hashes/sizes match; staged payload1931284 bytes; bulk968770723 bytes omitted explicitly. Missing mandatory.xml/coverage/runtime/lint records remain declared, as expected from the original timed-out job.',
        'aliases_and_special_files': 'Live pytest directory alias, dangling alias, external file alias and FIFO excluded without following/blocking; unit checkpoint binary and >1MiB unit diagnostic excluded explicitly; no staged symlinks.'
    },
    'limits': [
        'No full training suite or new hosted Linux run performed.',
        'Current candidate still requires exact-source Python3.13 hosted base/mandatory/runtime/quality completion before merge.',
        'Author script was inspected and its referenced receipts verified; independent scripts supplied static and behavioral judgments.',
        'No acceptance claim for initial hosted run37129360804, which remains failed.'
    ],
    'review_evidence': [receipt(SCRATCH / name) for name in ['review_probe.py', 'probe-results.json', 'static_review.py', 'static-results.json']],
}
(SCRATCH / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'path': str(SCRATCH / 'review.json'), 'status': report['status'], 'findings': [{'severity': finding['severity'], 'title': finding['title']} for finding in report['findings']]}, indent=2))
