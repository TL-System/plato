import copy
import hashlib
import json
import re
import subprocess
from pathlib import Path

import yaml

ROOT = Path('/tmp/plato-refresh-worktrees/phase2-ci-budget')
SCRATCH = Path('/tmp/plato-ci-internal-review')
BASE = '9ee92c52307cd3ecdce0c7416708c504bdb52137'
HEAD = '0ada82cca599310c40d4a6691aaa16a0e737f2fd'
WORKFLOW = '.github/workflows/pytorch_tests.yml'

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args]).decode().strip()

class WorkflowLoader(yaml.SafeLoader):
    pass

WorkflowLoader.yaml_implicit_resolvers = copy.deepcopy(yaml.SafeLoader.yaml_implicit_resolvers)
for letter, resolvers in WorkflowLoader.yaml_implicit_resolvers.items():
    WorkflowLoader.yaml_implicit_resolvers[letter] = [record for record in resolvers if record[0] != 'tag:yaml.org,2002:bool']
WorkflowLoader.add_implicit_resolver('tag:yaml.org,2002:bool', re.compile(r'^(?:true|false)$', re.I), list('tTfF'))

def unique_map(loader, node, deep=False):
    result = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        assert key not in result, key
        result[key] = loader.construct_object(value_node, deep=deep)
    return result

WorkflowLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, unique_map)
before = yaml.load(git('show', BASE + ':' + WORKFLOW), Loader=WorkflowLoader)
after = yaml.load((ROOT / WORKFLOW).read_text(), Loader=WorkflowLoader)
assert 'on' in after and set(after['on']) == {'push', 'pull_request', 'workflow_dispatch'}
old_job = before['jobs']['PyTorch-Tests']
job = after['jobs']['PyTorch-Tests']
assert job['timeout-minutes'] == 110
assert job['strategy']['matrix']['include'] == [{'python': '3.13', 'profile': 'supported-default'}]
assert job['steps'][6]['timeout-minutes'] == 25
assert job['steps'][8]['timeout-minutes'] == 30
assert job['steps'][9]['timeout-minutes'] == 16
assert job['steps'][11] == {'name': 'Stage qualification outputs without pytest aliases', 'if': 'always()', 'timeout-minutes': 2, 'run': 'python .github/scripts/stage_ci_artifacts.py'}
restored = copy.deepcopy(after)
restored_job = restored['jobs']['PyTorch-Tests']
restored_job['timeout-minutes'] = old_job['timeout-minutes']
restored_job['strategy']['matrix'] = old_job['strategy']['matrix']
for index in [6, 8]:
    restored_job['steps'][index]['timeout-minutes'] = old_job['steps'][index]['timeout-minutes']
restored_job['steps'].pop(11)
restored_job['steps'][-1]['with']['path'] = old_job['steps'][-1]['with']['path']
assert restored == before
assert git('rev-parse', 'HEAD') == HEAD
assert git('rev-parse', 'HEAD^') == BASE
assert not git('status', '--porcelain')
assert set(git('diff', '--name-only', BASE, HEAD).splitlines()) == {WORKFLOW, '.github/scripts/stage_ci_artifacts.py', 'evidence/2026-refresh/phase2-ci-budget-validation.json'}
subprocess.run(['git', '-C', str(ROOT), 'diff', '--check', BASE, HEAD], check=True)

evidence = json.loads((ROOT / 'evidence/2026-refresh/phase2-ci-budget-validation.json').read_text())
followup = evidence['linux_followup']
checks = []
def verify(record):
    if isinstance(record, dict):
        if isinstance(record.get('path'), str) and 'sha256' in record:
            path = Path(record['path'])
            if not path.is_absolute():
                path = ROOT / path
            assert path.is_file(), path
            raw = path.read_bytes()
            assert hashlib.sha256(raw).hexdigest() == record['sha256'], path
            if 'bytes' in record:
                assert len(raw) == record['bytes'], path
            if 'git_blob' in record:
                assert git('hash-object', str(path)) == record['git_blob'], path
            checks.append(str(path))
        for value in record.values():
            verify(value)
    elif isinstance(record, list):
        for value in record:
            verify(value)
verify(followup)
job_metadata = json.loads(Path('/tmp/plato-phase2-root/linux-initial-failure-jobs.json').read_text())
base_step = next(step for step in job_metadata['jobs'][0]['steps'] if step['name'] == job['steps'][6]['name'])
assert base_step['conclusion'] == 'success'
assert '1082' in str(followup['budget_adjustment']) if 'budget_adjustment' in followup else True
explicit = sum(step.get('timeout-minutes', 0) for step in job['steps'])
assert explicit == 101
assert job['timeout-minutes'] >= explicit + 6
result = {'source': {'head': HEAD, 'tree': git('rev-parse', 'HEAD^{tree}'), 'parent': BASE, 'clean_status': git('status', '--porcelain')}, 'yaml_triggers_and_duplicate_keys': 'PASS', 'existing_test_commands_assertions_profiles_coverage_runtime_deadlines_pins_permissions_and_environment_preserved': 'PASS', 'changed_scope_exact_three_files': 'PASS', 'job_explicit_step_minutes': explicit, 'job_timeout_minutes': 110, 'setup_and_upload_allowance_minutes': 6, 'artifact_step_minutes': 2, 'linux_followup_receipts_verified': checks, 'github_initial_failure_evidence_not_new_qualification': True}
(SCRATCH / 'static-results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
