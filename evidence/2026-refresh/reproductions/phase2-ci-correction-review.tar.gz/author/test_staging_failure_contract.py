import argparse
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import yaml

sys.dont_write_bytecode = True
ROOT = Path('/tmp/plato-refresh-worktrees/phase2-ci-budget')
SCRATCH = Path('/tmp/plato-phase2-ci-budget-validation')
HELPER = ROOT / '.github/scripts/stage_ci_artifacts.py'
ACTUAL_RUNTIME = Path(
    '/tmp/plato-phase2c-feddyn-implementation/combined-mandatory-runtime-313'
)
parser = argparse.ArgumentParser()
parser.add_argument('--phase', choices=['red', 'green'], required=True)
parser.add_argument('--helper', type=Path, default=HELPER)
args = parser.parse_args()
HELPER = args.helper
spec = importlib.util.spec_from_file_location('failure_contract_stager', HELPER)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def receipt(path):
    data = path.read_bytes()
    return {
        'path': str(path), 'bytes': len(data),
        'sha256': hashlib.sha256(data).hexdigest(),
    }


def write(root, name, data):
    target = root / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    return target


def verify_copies(source, destination, manifest):
    for record in manifest['included']:
        staged = destination / record['path']
        original = source / record['path']
        assert not staged.is_symlink()
        assert staged.stat().st_size == record['bytes']
        assert hashlib.sha256(staged.read_bytes()).hexdigest() == record['sha256']
        assert hashlib.sha256(original.read_bytes()).hexdigest() == record['sha256']
    assert not any(path.is_symlink() for path in destination.rglob('*'))


results = {'phase': args.phase, 'helper': receipt(HELPER), 'cases': {}}
failures = []


def cli_case(name, source, destination, *, complete=False, inject=False,
             expected_code=0, missing=()):
    command = [sys.executable]
    if inject:
        command += [str(wrapper)]
    command += [str(HELPER), '--source', str(source),
                '--destination', str(destination)]
    if complete:
        command += ['--require-complete']
    result = subprocess.run(command, capture_output=True, text=True)
    manifest_path = destination / module.MANIFEST
    manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else None
    passed = result.returncode == expected_code and manifest is not None
    if manifest is not None:
        passed = passed and manifest['missing_expected_records'] == list(missing)
        if source.is_dir():
            verify_copies(source, destination, manifest)
    if not passed:
        failures.append(name)
    results['cases'][name] = {
        'exit_code': result.returncode,
        'expected_exit_code': expected_code,
        'manifest_retained': manifest is not None,
        'missing_expected_records': (
            manifest['missing_expected_records'] if manifest else None
        ),
        'read_issues': manifest['read_issues'] if manifest else None,
        'summary': manifest['summary'] if manifest else None,
        'manifest': receipt(manifest_path) if manifest else None,
        'passed': passed,
    }
    return manifest


directory = Path(tempfile.mkdtemp(prefix=f'failure-contract-{args.phase}-', dir=SCRATCH))
source = directory / 'complete-source'
for name in module.EXPECTED_RECORDS:
    write(source, name, ('evidence for ' + name + '\n').encode())
wrapper = write(directory, 'inject_io_failure.py', b'''import os
import runpy
import sys

helper = sys.argv.pop(1)
original_open = os.open

def failing_open(path, flags, mode=0o777, *, dir_fd=None):
    if path == "coverage.json":
        raise OSError(5, "Deterministic evidence I/O failure")
    return original_open(path, flags, mode, dir_fd=dir_fd)

os.open = failing_open
runpy.run_path(helper, run_name="__main__")
''')

cli_case('unexpected_read_failure', source, directory / 'read-failure',
         inject=True, expected_code=1, missing=['coverage.json'])
cli_case('wholly_missing_source', directory / 'absent', directory / 'missing-source',
         expected_code=1, missing=module.EXPECTED_RECORDS)

if args.phase == 'green':
    runtime_files = []
    for current, directories, files in os.walk(ACTUAL_RUNTIME, followlinks=False):
        parent = Path(current)
        directories[:] = [name for name in directories
                          if not (parent / name).is_symlink()]
        for name in files:
            original = parent / name
            if original.is_symlink() or not original.is_file():
                continue
            relative = original.relative_to(ACTUAL_RUNTIME)
            target = source / 'runtime-tmp' / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(original, target)
            runtime_files.append('runtime-tmp/' + relative.as_posix())
    assert runtime_files
    write(source, 'runtime-tmp/large-checkpoint/model.pth', b'w' * (1024 * 1024 + 1))
    for name in ['payload.pkl', 'start.pkl', 'received.pkl', 'committed.pkl']:
        write(source, 'runtime-tmp/replay/' + name, b'payload\0\xff' * 29)
    write(source, 'mandatory-tmp/unit0/worker.stderr', b'worker diagnostics\n')
    write(source, 'mandatory-tmp/unit0/model.pth', b'unit fixture\0' * 100)
    write(source, 'mandatory-tmp/unit0/oversized.json', b'j' * (1024 * 1024 + 1))
    (source / 'mandatory-tmp/unitcurrent').symlink_to('unit0', target_is_directory=True)
    (source / 'mandatory-tmp/danglingcurrent').symlink_to('missing', target_is_directory=True)
    outside = write(directory, 'outside.txt', b'outside evidence')
    (source / 'runtime-tmp/outside').symlink_to(outside)
    os.mkfifo(source / 'mandatory-tmp/unit0/pipe.log')
    complete_manifest = cli_case(
        'complete_qualification_with_exclusions', source, directory / 'complete-staged',
        complete=True,
    )
    selected = {record['path'] for record in complete_manifest['included']}
    assert set(runtime_files) <= selected
    assert 'runtime-tmp/large-checkpoint/model.pth' in selected
    assert all('runtime-tmp/replay/' + name in selected
               for name in ['payload.pkl', 'start.pkl', 'received.pkl', 'committed.pkl'])
    assert 'mandatory-tmp/unit0/model.pth' not in selected
    assert 'mandatory-tmp/unit0/oversized.json' not in selected
    assert 'mandatory-tmp/unit0/worker.stderr' in selected
    results['actual_runtime_retention'] = {
        'source': str(ACTUAL_RUNTIME),
        'regular_files_verified_byte_for_byte': len(runtime_files),
        'large_checkpoint_and_binary_replay_preserved': True,
        'no_staged_symlinks_or_bulk_unit_fixtures': True,
    }

    partial_source = directory / 'partial-source'
    shutil.copytree(source, partial_source, symlinks=True,
                    ignore=lambda parent, names: [name for name in names
                                                 if (Path(parent) / name).is_fifo()])
    (partial_source / 'coverage.json').unlink()
    cli_case('successful_qualification_missing_required_record', partial_source,
             directory / 'required-missing', complete=True,
             expected_code=1, missing=['coverage.json'])
    cli_case('failed_qualification_partial_evidence', partial_source,
             directory / 'partial-staged', missing=['coverage.json'])
    cli_case('unexpected_read_failure_even_for_failed_qualification', source,
             directory / 'read-failure-partial', inject=True,
             expected_code=1, missing=['coverage.json'])
    cli_case('unexpected_read_failure_with_completeness_required', source,
             directory / 'read-failure-required', inject=True, complete=True,
             expected_code=1, missing=['coverage.json'])

    # BaseLoader retains the GitHub `on` key as text and expression values verbatim.
    workflow = yaml.load((ROOT / '.github/workflows/pytorch_tests.yml').read_text(),
                         Loader=yaml.BaseLoader)
    steps = workflow['jobs']['PyTorch-Tests']['steps']
    stage = next(step for step in steps if step['name'].startswith('Stage qualification'))
    upload = next(step for step in steps if step['name'] == 'Upload qualification outputs')
    assert stage['if'] == upload['if'] == 'always()'
    assert stage['env']['QUALIFICATION_STATUS'] == '${{ job.status }}'
    assert all('continue-on-error' not in step for step in steps)
    workflow_cases = {}
    for prior_status, expected_code in [('success', 1), ('failure', 0), ('cancelled', 0)]:
        workspace = directory / f'workflow-{prior_status}'
        shutil.copytree(partial_source, workspace / 'ci-artifacts', symlinks=True)
        script = workspace / '.github/scripts/stage_ci_artifacts.py'
        script.parent.mkdir(parents=True)
        shutil.copyfile(HELPER, script)
        environment = os.environ.copy()
        environment['QUALIFICATION_STATUS'] = prior_status
        environment['PATH'] = str(Path(sys.executable).parent) + os.pathsep + environment['PATH']
        result = subprocess.run(['zsh', '-lc', stage['run']], cwd=workspace,
                                env=environment, capture_output=True, text=True)
        manifest_path = workspace / 'ci-artifacts-upload' / module.MANIFEST
        assert manifest_path.exists(), (result.returncode, result.stdout, result.stderr)
        manifest = json.loads(manifest_path.read_text())
        verify_copies(workspace / 'ci-artifacts', workspace / 'ci-artifacts-upload', manifest)
        assert result.returncode == expected_code, result.stderr
        assert manifest['missing_expected_records'] == ['coverage.json']
        workflow_cases[prior_status] = {
            'staging_exit_code': result.returncode,
            'partial_manifest_and_payload_retained': True,
            'always_upload_condition_preserved': True,
        }
    results['workflow'] = {
        'preceding_status_captured_by_job_status': True,
        'successful_preceding_qualification_requires_complete_evidence': True,
        'failed_and_cancelled_qualification_allow_expected_missing_records': True,
        'prior_failure_not_masked_by_continue_on_error': True,
        'exact_workflow_shell_executed': workflow_cases,
        'upload_execution': 'Static always() check only; no hosted upload performed.',
    }

results['failed_cases'] = failures
results['result'] = 'FAIL' if failures else 'PASS'
result_path = SCRATCH / f'staging-failure-contract-{args.phase}.json'
result_path.write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps({'result': results['result'], 'failed_cases': failures,
                  'receipt': str(result_path), 'fixture': str(directory)}, indent=2))
assert not failures, f'Failure contract did not hold: {failures}'
