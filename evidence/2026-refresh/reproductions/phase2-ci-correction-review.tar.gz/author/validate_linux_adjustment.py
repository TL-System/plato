import copy
import hashlib
import json
import math
import re
import subprocess
from collections import Counter
from datetime import datetime
from pathlib import Path
from xml.etree import ElementTree as ET

import yaml

BASE = '9ee92c52307cd3ecdce0c7416708c504bdb52137'
QUALIFIED = '204082f53d0fd335e57712ac981ad7d40bff19dd'
MERGE = 'af6cdb18fd25beee66014d9543e3f265f2643b81'
WORKFLOW = '.github/workflows/pytorch_tests.yml'
HELPER = '.github/scripts/stage_ci_artifacts.py'
OUTPUT = 'evidence/2026-refresh/phase2-ci-budget-validation.json'
SCRATCH = Path('/tmp/plato-phase2-ci-budget-validation')
ROOT = Path('/tmp/plato-phase2-root')
ARTIFACT = Path('/tmp/plato-phase2-linux/initial-313')


def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()


def receipt(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


class WorkflowLoader(yaml.SafeLoader):
    pass


WorkflowLoader.yaml_implicit_resolvers = {
    key: [(tag, pattern) for tag, pattern in values
          if tag != 'tag:yaml.org,2002:bool']
    for key, values in yaml.SafeLoader.yaml_implicit_resolvers.items()
}
WorkflowLoader.add_implicit_resolver(
    'tag:yaml.org,2002:bool', re.compile(r'^(?:true|True|TRUE|false|False|FALSE)$'),
    list('tTfF'),
)


def unique_mapping(loader, node):
    result = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node)
        assert key not in result, f'Duplicate YAML key: {key}'
        result[key] = loader.construct_object(value_node)
    return result


WorkflowLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
                               unique_mapping)
assert git('rev-parse', 'HEAD') == BASE
assert git('branch', '--show-current') == 'maintenance/2026-phase2-ci-budget'
assert git('rev-parse', f'{MERGE}^{{tree}}') == git('rev-parse', f'{BASE}^{{tree}}')
assert not git('diff', '--name-only', QUALIFIED, BASE, '--', '.', ':!evidence')
before_bytes = subprocess.check_output(['git', 'show', f'{BASE}:{WORKFLOW}'])
after_bytes = Path(WORKFLOW).read_bytes()
before = yaml.load(before_bytes, Loader=WorkflowLoader)
after = yaml.load(after_bytes, Loader=WorkflowLoader)
job = after['jobs']['PyTorch-Tests']
old_job = before['jobs']['PyTorch-Tests']
assert before['on'] == after['on']
assert list(after['on']) == ['push', 'pull_request', 'workflow_dispatch']
assert True not in before and True not in after
assert job['strategy']['fail-fast'] is False
assert job['steps'][0]['with']['persist-credentials'] is False
assert job['strategy']['matrix']['include'] == [
    {'python': '3.13', 'profile': 'supported-default'},
]
assert len(job['steps']) == 13 and len(old_job['steps']) == 12
stage = {'name': 'Stage qualification outputs without pytest aliases',
         'if': 'always()', 'timeout-minutes': 2,
         'run': 'python .github/scripts/stage_ci_artifacts.py'}
assert job['steps'][11] == stage
normalized = copy.deepcopy(after)
normalized_job = normalized['jobs']['PyTorch-Tests']
normalized_job['timeout-minutes'] = 90
normalized_job['steps'][6]['timeout-minutes'] = 20
normalized_job['steps'][8]['timeout-minutes'] = 20
normalized_job['strategy']['matrix']['include'] = old_job['strategy']['matrix']['include']
normalized_job['steps'].pop(11)
normalized_job['steps'][11]['with']['path'] = 'ci-artifacts/'
assert normalized == before
expected_bytes = before_bytes.replace(b'    timeout-minutes: 90\n', b'    timeout-minutes: 110\n', 1)
expected_bytes = expected_bytes.replace(
    b'          - python: "3.14"\n            profile: core-forward-compatibility\n', b'', 1)
for index in (6, 8):
    name = job['steps'][index]['name']
    old = f'      - name: {name}\n        timeout-minutes: 20\n'.encode()
    new = f'      - name: {name}\n        timeout-minutes: {job["steps"][index]["timeout-minutes"]}\n'.encode()
    assert expected_bytes.count(old) == 1
    expected_bytes = expected_bytes.replace(old, new, 1)
expected_bytes = expected_bytes.replace(
    b'      - name: Upload qualification outputs\n',
    b'      - name: Stage qualification outputs without pytest aliases\n'
    b'        if: always()\n        timeout-minutes: 2\n'
    b'        run: python .github/scripts/stage_ci_artifacts.py\n\n'
    b'      - name: Upload qualification outputs\n', 1)
expected_bytes = expected_bytes.replace(b'          path: ci-artifacts/\n',
                                       b'          path: ci-artifacts-upload/\n', 1)
assert after_bytes == expected_bytes

shell_checks = []
python_checks = []
for step in job['steps']:
    if 'run' not in step:
        continue
    run = step['run']
    if step.get('shell', '').startswith('python'):
        compile(run, step['name'], 'exec')
        python_checks.append(step['name'])
    else:
        script = re.sub(r'\$\{\{.*?\}\}', 'ci_placeholder', run)
        result = subprocess.run(['zsh', '-n'], input=script, text=True,
                                capture_output=True)
        assert result.returncode == 0, (step['name'], result.stderr)
        shell_checks.append(step['name'])
        for block in re.findall(r"<<'PY'\n(.*?)\nPY(?:\n|$)", script, flags=re.S):
            compile(block, step['name'], 'exec')
            python_checks.append(step['name'])
compile(Path(HELPER).read_text(), HELPER, 'exec')
assert all(len(line) <= 88 for line in Path(HELPER).read_text().splitlines())
subprocess.run(['/tmp/plato-phase2c-313/bin/ruff', 'check', HELPER, '--select', 'I'], check=True)
subprocess.run(['/tmp/plato-phase2c-313/bin/ruff', 'format', '--check', HELPER], check=True)
subprocess.run(['/tmp/plato-phase2c-313/bin/ty', 'check', HELPER,
                '--output-format', 'concise'], check=True)
subprocess.run(['git', 'diff', '--check'], check=True)
assert set(git('diff', '--name-only').splitlines()) <= {WORKFLOW, OUTPUT}
assert set(git('ls-files', '--others', '--exclude-standard').splitlines()) == {HELPER}

metadata = json.loads((ROOT/'linux-initial-failure-jobs.json').read_bytes())
assert metadata['status'] == 'completed' and metadata['conclusion'] == 'failure'
jobs = metadata['jobs']
assert [job['databaseId'] for job in jobs] == [111221201880, 111221201990]
step_times = []
for recorded_job in jobs:
    version = '3.13' if '3.13' in recorded_job['name'] else '3.14'
    timings = []
    for step in recorded_job['steps']:
        if step['startedAt'].startswith('0001') or step['completedAt'].startswith('0001'):
            continue
        seconds = (datetime.fromisoformat(step['completedAt']) -
                   datetime.fromisoformat(step['startedAt'])).total_seconds()
        timings.append({'name': step['name'], 'conclusion': step['conclusion'],
                        'started_at': step['startedAt'], 'completed_at': step['completedAt'],
                        'seconds': seconds})
    by_name = {item['name']: item for item in timings}
    assert by_name['Base collection, suite and missing-extra probe']['conclusion'] == 'success'
    assert by_name['Mandatory initialized core suite']['conclusion'] == 'failure'
    assert by_name['Fresh startup, real CPU socket round and failure containment']['conclusion'] == 'skipped'
    assert by_name['Ruff and classified typing baseline']['conclusion'] == 'skipped'
    step_times.append({'python': version, 'job_id': recorded_job['databaseId'],
                       'url': recorded_job['url'], 'conclusion': recorded_job['conclusion'],
                       'timings': timings})
assert (ARTIFACT/'commit.txt').read_text().strip() == MERGE
partial = (ARTIFACT/'mandatory.log').read_text()
assert 'collected 1303 items / 51 deselected / 1252 selected' in partial
visible = Counter()
module = None
module_counts = Counter()
for line in partial.splitlines():
    match = re.match(r'^(tests/\S+\.py)\s+(.+)$', line)
    if match:
        module, body = match.groups()
    else:
        body = line
    body = re.sub(r'\s*\[\s*\d+%\]\s*$', '', body).strip()
    if re.fullmatch(r'[.sFExX]+', body):
        visible.update(body)
        module_counts[module] += len(body)
assert dict(visible) == {'.': 1104, 's': 1}
assert module == 'tests/trainers/test_review_training_boundaries.py'
assert module_counts[module] == 16
assert partial.endswith('tests/trainers/test_review_training_boundaries.py ................')
assert 'Traceback' not in partial
assert not re.search(r'^(FAILED |ERROR |={3,}.*(?:FAILURES|ERRORS))', partial, re.M)
assert not (ARTIFACT/'mandatory.xml').exists()
assert not (ARTIFACT/'coverage.json').exists()
base_xml = ET.parse(ARTIFACT/'base.xml').getroot()
suite = list(base_xml.iter('testsuite'))[0]
assert suite.get('tests') == '1246' and suite.get('failures') == suite.get('errors') == '0'
assert suite.get('skipped') == '4'
cases = list(base_xml.iter('testcase'))
slowest = sorted(cases, key=lambda case: float(case.get('time', 0)), reverse=True)[:20]
active_class = 'tests.trainers.test_review_training_boundaries'
active_name = 'test_fedala_memory_only_return_matches_dedicated_rounds[True]'
active_index = next(i for i, case in enumerate(cases)
                    if case.get('classname') == active_class and case.get('name') == active_name)
assert float(cases[active_index].get('time')) == 37.391
assert (ARTIFACT/'missing-extra.log').read_text().strip() == "ERROR: mandatory prerequisite failed: No module named 'opacus'"
log313 = (ROOT/'linux-initial-313-job.log').read_text()
log314 = (ROOT/'linux-initial-314-job.log').read_text()
for log in (log313, log314):
    assert "The action 'Mandatory initialized core suite' has timed out after 20 minutes." in log
alias_error = "ENOENT: no such file or directory, stat '/home/runner/work/plato/plato/ci-artifacts/mandatory-tmp/test_actual_spawn_returns_perscurrent/feddyn-result.json'"
assert alias_error in log314
assert '134acc7c59651a41585fb645acf816ff1ec7f82e5aa6f9cd8aa46c7975f1571c' in log313
selection = json.loads((SCRATCH/'artifact-selection-proof.json').read_bytes())
assert selection['result'] == 'PASS'
assert selection['helper']['sha256'] == receipt(HELPER)['sha256']
assert selection['downloaded_linux_313']['summary']['included_bytes'] == 1931284
assert selection['downloaded_linux_313']['summary']['omitted_regular_bytes'] == 968770723
manifest_path = selection['downloaded_linux_313']['manifest']['path']
assert receipt(manifest_path) == selection['downloaded_linux_313']['manifest']

active_base_seconds = next(item['seconds'] for item in step_times[0]['timings']
                          if item['name'] == 'Base collection, suite and missing-extra probe')
elapsed_mandatory = next(item['seconds'] for item in step_times[0]['timings']
                         if item['name'] == 'Mandatory initialized core suite')
assert active_base_seconds == 1082 and elapsed_mandatory == 1207
completed_cases = sum(visible.values())
projected_core = elapsed_mandatory * 1252 / completed_cases
base_planning = active_base_seconds * 1.25
mandatory_planning = projected_core * 1.25 + 60
assert math.ceil(base_planning / 300) * 5 == 25
assert math.ceil(mandatory_planning / 300) * 5 == 30
action_allowances = {'Checkout pinned submodules': 2, 'Set up Python': 2,
                     'Set up uv': 1, 'Upload qualification outputs': 1}
stages = [{'name': step['name'], 'explicit_timeout_minutes': step.get('timeout-minutes'),
           'planning_minutes': step.get('timeout-minutes', action_allowances.get(step['name']))}
          for step in job['steps']]
explicit = sum(item['explicit_timeout_minutes'] or 0 for item in stages)
assert explicit == 101
assert sum(item['planning_minutes'] for item in stages) == 107
assert math.ceil(107 / 5) * 5 == job['timeout-minutes'] == 110

original_bytes = subprocess.check_output(['git', 'show', f'{BASE}:{OUTPUT}'])
evidence = json.loads(original_bytes)
evidence['initial_adjustment_status'] = evidence['status']
evidence['status'] = 'LINUX_TIMEOUT_ARTIFACT_AND_SINGLE_VERSION_ADJUSTMENT_STATIC_VALIDATION_PASSED_PENDING_REVIEW_AND_313_RERUN'
evidence['scope'] = 'Finite CI budgets, bounded artifact staging, and explicitly authorized Python 3.13-only matrix.'
evidence['changed_files'] = [WORKFLOW, HELPER, OUTPUT]
evidence['linux_followup'] = {
    'historical_evidence_note': 'All initial-adjustment fields remain historical evidence for the accepted 8d27c5c7 change; this followup describes the current candidate.',
    'authorization': {
        'artifact_collection': 'Root explicitly extended ownership to bounded CI artifact-selection/staging correction after the actual Linux upload failure.',
        'matrix': 'Proceed to simplify to 3.13 and revisit 3.14 later (CI work does not need it).',
        'matrix_source': 'Explicit user instruction relayed by root in the active task; supersedes the earlier two-version matrix-preservation requirement.',
        'active_ci_targets': ['3.13 / supported-default'],
        'historical_314_results_retained': True,
        'new_314_qualification_required': False,
        'python_upper_bound_added': False,
    },
    'source': {
        'clean_fast_forward_from': '8d27c5c7a205299537a2835358f1d5e91a7b51c3',
        'base_published_head': BASE, 'base_tree': git('rev-parse', f'{BASE}^{{tree}}'),
        'qualified_macos_source': QUALIFIED,
        'qualified_macos_tree': git('rev-parse', f'{QUALIFIED}^{{tree}}'),
        'qualified_to_published_non_evidence_diff': [],
        'original_linux_checkout': MERGE, 'original_linux_checkout_tree': git('rev-parse', f'{MERGE}^{{tree}}'),
        'published_and_linux_checkout_full_tree_equal': True,
        'workflow_before': {'bytes': len(before_bytes), 'sha256': hashlib.sha256(before_bytes).hexdigest(),
                            'git_blob': git('rev-parse', f'{BASE}:{WORKFLOW}')},
        'workflow_after': {**receipt(WORKFLOW), 'git_blob': git('hash-object', WORKFLOW)},
        'helper': {**receipt(HELPER), 'git_blob': git('hash-object', HELPER)},
        'initial_accepted_validation': {'bytes': len(original_bytes),
                                        'sha256': hashlib.sha256(original_bytes).hexdigest(),
                                        'git_blob': git('rev-parse', f'{BASE}:{OUTPUT}')},
        'guard_source': {'path': 'tests/conftest.py', 'git_blob': git('rev-parse', f'{BASE}:tests/conftest.py'),
                         'sha256': receipt('tests/conftest.py')['sha256']},
        'commit_identity_note': 'Final candidate head/tree are supplied in the delivery receipt after commit to avoid self-reference.',
    },
    'original_linux_run': {
        'run_id': 37129360804, 'attempt': 1,
        'url': 'https://github.com/TL-System/plato/actions/runs/37129360804',
        'published_head': BASE, 'checkout_commit': MERGE, 'conclusion': 'failure',
        'jobs': step_times,
        'inputs': [receipt(ROOT/name) for name in (
            'linux-initial-failure-jobs.json', 'linux-initial-313-job.log',
            'linux-initial-314-job.log', 'linux-merge-source-equivalence.json',
            'linux-initial-failure-audit.json')],
        'artifact_313': {
            'id': 11276668294, 'name': 'pytorch-3.13-1', 'compressed_bytes': 819526511,
            'uploaded_zip_sha256': '134acc7c59651a41585fb645acf816ff1ec7f82e5aa6f9cd8aa46c7975f1571c',
            'selected_raw_receipts': [receipt(ARTIFACT/name) for name in (
                'commit.txt', 'base-collection.log', 'base.log', 'base.xml', 'mandatory.log',
                'missing-extra.log', 'python.txt', 'lock.txt', 'submodules.txt',
                'base-packages.txt', 'mandatory-packages.txt', 'uv.txt')],
        },
        'artifact_314': {'upload_conclusion': 'failure', 'artifact_exists': False,
                         'error': alias_error,
                         'partial_pytest_output_available': False,
                         'base_result': 'GitHub step success at 1142 seconds; raw pytest/JUnit output unavailable.',
                         'mandatory_result': 'Timeout after configured 1200-second limit; partial outcomes unavailable.'},
    },
    'partial_progress_investigation': {
        'python': '3.13', 'selected_cases': 1252, 'runtime_deselected': 51,
        'visible_passing_outcomes': 1104, 'visible_expected_tokenizer_skips': 1,
        'visible_failure_or_error_outcomes': 0, 'traceback_or_failure_summary_present': False,
        'completed_visible_outcomes': completed_cases, 'unfinished_selected_cases': 1252-completed_cases,
        'last_completed_module_percent_display': 86,
        'last_in_progress_module': module, 'completed_outcomes_in_last_module': 16,
        'inferred_in_progress_case': active_class + '::' + active_name,
        'inference_basis': 'Partial module outcome count and base JUnit case order. No timestamped verbose mandatory case trace is available.',
        'same_case_in_base': {'outcome': 'passed', 'seconds': 37.391},
        'remaining_base_cases_from_inferred_case': len(cases)-active_index,
        'remaining_base_case_seconds_sum': round(sum(float(case.get('time', 0)) for case in cases[active_index:]), 3),
        'base_junit': {'tests': 1246, 'passed': 1242, 'failures': 0, 'errors': 0, 'skipped': 4,
                       'suite_seconds': float(suite.get('time'))},
        'base_slowest_cases': [{'case': case.get('classname')+'::'+case.get('name'),
                               'seconds': float(case.get('time'))} for case in slowest],
        'disposition': 'Substantial forward progress and no visible correctness failure support a finite budget adjustment. An unfinished-case stall or later correctness failure is not excluded by this snapshot.',
        'mandatory_full_pass_claimed': False, 'hang_excluded': False,
        'runtime_pass_claimed': False, 'final_profile_guard_execution_claimed': False,
        'mandatory_junit_or_coverage_completion_available': False,
    },
    'budget_adjustment': {
        'changes': {'base_minutes': {'old': 20, 'new': 25},
                    'mandatory_minutes': {'old': 20, 'new': 30},
                    'job_minutes': {'old': 90, 'new': 110}},
        'runtime_minutes': {'old': 16, 'new': 16},
        'new_artifact_staging_step_minutes': 2,
        'active_base_planning': {'measured_step_seconds': active_base_seconds,
                                 'variance_multiplier': 1.25, 'planning_seconds': base_planning,
                                 'rounding': 'Ceiling to the next five-minute budget.', 'new_minutes': 25},
        'mandatory_planning': {'interrupted_step_seconds_including_cancellation_grace': elapsed_mandatory,
                               'configured_original_limit_seconds': 1200,
                               'conditional_completed_case_projection_seconds': round(projected_core, 3),
                               'projection_formula': '1207 * 1252 / 1105; a planning estimate, not an observed suite completion.',
                               'variance_multiplier': 1.25,
                               'coverage_finalization_allowance_seconds': 60,
                               'planning_seconds': round(mandatory_planning, 3), 'new_minutes': 30,
                               'rounding': 'Ceiling to the next five-minute budget.'},
        'coverage_limit': 'Coverage remains enabled. Actual completed Linux coverage overhead has not been measured; remaining work and finalization allowances are conditional planning inputs.',
        'job': {'explicit_step_limits_minutes': explicit, 'setup_upload_reserve_minutes': 6,
                'planning_total_minutes': 107, 'rounded_job_minutes': 110,
                'stages': stages,
                'rationale': 'The former 90-minute job cannot accommodate the revised explicit step envelope (101 minutes) plus setup/upload reserve. Other existing step limits remain unchanged.'},
        'per_test_socket_and_watchdog_deadline_changes': [],
    },
    'artifact_selection': {
        'helper': HELPER, 'new_upload_path': 'ci-artifacts-upload/',
        'staging_manifest': 'artifact-selection.json',
        'policy': 'Preserve all top-level regular records and all regular runtime/other records. Within base-tmp/mandatory-tmp retain text diagnostics up to 1 MiB and explicitly list excluded fixtures. Never follow file or directory aliases; copy stable-size file snapshots via no-follow descriptors.',
        'missing_and_omitted_evidence': 'Manifest records each exclusion, each read issue, changed snapshots and every missing expected top-level record. Staging makes no assertion about test success.',
        'proof': selection,
        'proof_receipt': receipt(SCRATCH/'artifact-selection-proof.json'),
        'fixture_command': 'zsh -lc "/tmp/plato-phase2c-313/bin/python /tmp/plato-phase2-ci-budget-validation/test_artifact_selection.py"',
        'fixture_script': receipt(SCRATCH/'test_artifact_selection.py'),
    },
    'static_validation': {
        'command': 'zsh -lc "/tmp/plato-phase2c-313/bin/python /tmp/plato-phase2-ci-budget-validation/validate_linux_adjustment.py"',
        'script': receipt(SCRATCH/'validate_linux_adjustment.py'),
        'parser': 'PyYAML ' + yaml.__version__ + ', SafeLoader with true/false-only booleans and duplicate-key rejection.',
        'results': {
            'yaml_and_github_on_semantics': 'PASS',
            'exact_authorized_byte_changes_only': 'PASS',
            'structural_equality_after_reversing_only_budgets_matrix_removal_staging_and_upload_path': 'PASS',
            'existing_test_commands_markers_assertions_coverage_profile_guards_pins_permissions_environment_and_runtime_deadlines_preserved': 'PASS',
            'upload_action_pin_name_retention_and_always_condition_preserved': 'PASS',
            'zsh_n': {'result': 'PASS', 'steps': shell_checks},
            'embedded_python_compile': {'result': 'PASS', 'steps': python_checks},
            'helper_compile_and_line_lengths': 'PASS',
            'helper_ruff_import_order_and_format': 'PASS',
            'helper_focused_ty_check': 'PASS',
            'observed_missing_extra_guard_output': 'PASS',
            'finite_job_stage_accounting': 'PASS', 'git_diff_check': 'PASS',
        },
    },
    'remaining': ['Root fresh independent review and phase-gate addendum.',
                  'Full exact-source Python 3.13 Linux base/mandatory/runtime and quality checks before merge.'],
    'scope_exclusions': ['No production, test, dependency, lock, compatibility-fix, or standalone documentation edits.',
                         'No new macOS training suite execution or Python 3.14 qualification.',
                         'No Linux full mandatory/runtime pass claimed; no push, PR posting or merge performed.'],
}
Path(OUTPUT).write_text(json.dumps(evidence, indent=2)+'\n')
assert json.loads(Path(OUTPUT).read_bytes()) == evidence
print(json.dumps({'result': 'PASS', 'active_targets': job['strategy']['matrix']['include'],
                  'base_minutes': 25, 'mandatory_minutes': 30, 'runtime_minutes': 16,
                  'job_minutes': 110, 'explicit_step_minutes': explicit,
                  'helper': receipt(HELPER), 'workflow': receipt(WORKFLOW),
                  'evidence': receipt(OUTPUT)}, indent=2))
