import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

sys.dont_write_bytecode = True
HELPER = Path('.github/scripts/stage_ci_artifacts.py').resolve()
SCRATCH = Path('/tmp/plato-phase2-ci-budget-validation')
spec = importlib.util.spec_from_file_location('ci_artifacts', HELPER)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(root, path, data):
    target = root / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    return target


def verify_copies(source, target, manifest):
    for record in manifest['included']:
        original = source / record['path']
        staged = target / record['path']
        assert staged.is_file() and not staged.is_symlink()
        assert sha(original) == sha(staged) == record['sha256'], record
        assert staged.stat().st_size == record['bytes'], record
    assert not any(path.is_symlink() for path in target.rglob('*'))


with tempfile.TemporaryDirectory(prefix='artifact-fixture-', dir=SCRATCH) as directory:
    root = Path(directory)
    source = root / 'ci-artifacts'
    target = root / 'staged'
    regular = {
        'commit.txt': b'published-source\n',
        'mandatory.log': b'partial progress only\n',
        'base.xml': b'<testsuites/>\n',
        'coverage.json': b'{"coverage": "record"}\n',
        'base-packages.txt': b'pytest==9.1.1\n',
        'base-tmp/test_worker0/result.json': b'{"natural_success": true}\n',
        'mandatory-tmp/test_worker0/worker.stderr': b'worker diagnostic\n',
        'runtime-tmp/test_socket0/result.json': b'{"replay": "actual socket"}\n',
        'runtime-tmp/test_socket0/raw_payload.pkl': b'raw socket payload\x00\xff',
        'runtime-tmp/test_socket0/checkpoint/model.pth': b'runtime checkpoint\x00\xff',
        'runtime-tmp/test_socket0/checkpoint/model.safetensors': b'runtime weights\x00\xff',
    }
    for path, data in regular.items():
        write(source, path, data)
    bulk = {
        'base-tmp/test_worker0/model.pth': b'x' * 8192,
        'mandatory-tmp/test_worker0/model.safetensors': b'y' * 8192,
        'mandatory-tmp/test_worker0/cache.arrow': b'z' * 8192,
        'mandatory-tmp/test_worker0/large.json': b'j' * (module.DIAGNOSTIC_LIMIT + 1),
    }
    for path, data in bulk.items():
        write(source, path, data)
    outside = write(root, 'outside/secret.json', b'never copy this through an alias')
    (source / 'base-tmp/test_workercurrent').symlink_to('test_worker0', target_is_directory=True)
    (source / 'mandatory-tmp/test_actual_spawn_returns_perscurrent').symlink_to('missing-worker', target_is_directory=True)
    (source / 'runtime-tmp/socketcurrent').symlink_to('test_socket0', target_is_directory=True)
    (source / 'mandatory-tmp/outsidecurrent').symlink_to(outside.parent, target_is_directory=True)
    (source / 'mandatory-tmp/test_worker0/result.json').symlink_to('missing-result.json')
    os.mkfifo(source / 'mandatory-tmp/test_worker0/worker.pipe')
    try:
        (source / 'mandatory-tmp/test_actual_spawn_returns_perscurrent/feddyn-result.json').stat()
    except FileNotFoundError:
        old_alias_failure_reproduced = True
    else:
        raise AssertionError('Dangling pytest alias did not reproduce the old stat failure')
    completed = subprocess.run(
        [sys.executable, str(HELPER), '--source', str(source), '--destination', str(target)],
        check=True, capture_output=True, text=True,
    )
    manifest = json.loads((target / module.MANIFEST).read_bytes())
    included = {record['path'] for record in manifest['included']}
    assert included == set(regular), included
    omitted = {record['path']: record['reason'] for record in manifest['omitted']}
    assert all(path in omitted and path not in included for path in bulk)
    assert omitted['mandatory-tmp/test_worker0/large.json'] == 'unit_diagnostic_exceeds_size_limit'
    assert sum(reason == 'symlink_not_followed' for reason in omitted.values()) == 5
    assert omitted['mandatory-tmp/test_worker0/worker.pipe'] == 'not_a_regular_file'
    assert not manifest['read_issues']
    assert 'mandatory.xml' in manifest['missing_expected_records']
    assert 'mandatory.log' not in manifest['missing_expected_records']
    verify_copies(source, target, manifest)
    regular_result = {
        'cli_exit_code': completed.returncode,
        'old_dangling_alias_stat_failure_reproduced': old_alias_failure_reproduced,
        'top_level_logs_junit_coverage_and_packages_retained': True,
        'unit_worker_diagnostics_retained': True,
        'all_runtime_payloads_checkpoints_and_replay_records_retained': True,
        'all_selected_bytes_and_sha256_match_source': True,
        'bulk_unit_fixtures_and_oversized_diagnostic_explicitly_omitted': True,
        'five_aliases_not_followed_or_copied': True,
        'special_file_does_not_block_collection': True,
        'missing_expected_records_explicit': True,
        'summary': manifest['summary'],
    }

with tempfile.TemporaryDirectory(prefix='artifact-race-', dir=SCRATCH) as directory:
    root = Path(directory)
    source = root / 'source'
    target = root / 'staged'
    write(source, 'mandatory.log', b'keep diagnostics after interruption\n')
    for name in ('vanish.json', 'replace.json', 'pipe.json'):
        write(source, 'mandatory-tmp/' + name, b'original regular record')
    secret = write(root, 'secret.json', b'outside evidence must not be copied')
    original_open = module.os.open
    changed = set()

    def racing_open(path, flags, mode=0o777, *, dir_fd=None):
        if path in ('vanish.json', 'replace.json', 'pipe.json') and path not in changed:
            changed.add(path)
            record = source / 'mandatory-tmp' / path
            record.unlink()
            if path == 'replace.json':
                record.symlink_to(secret)
            elif path == 'pipe.json':
                os.mkfifo(record)
        return original_open(path, flags, mode, dir_fd=dir_fd)

    module.os.open = racing_open
    try:
        manifest = module.stage_artifacts(source, target)
    finally:
        module.os.open = original_open
    assert changed == {'vanish.json', 'replace.json', 'pipe.json'}
    assert {record['path'] for record in manifest['included']} == {'mandatory.log'}
    assert len(manifest['read_issues']) == 2
    assert manifest['collection_status'] == 'STAGED_WITH_READ_ISSUES'
    assert not list(target.rglob('*.json')) == []
    assert not (target / 'mandatory-tmp/replace.json').exists()
    assert not (target / 'mandatory-tmp/pipe.json').exists()
    race_result = {
        'disappearance_between_selection_and_open_reported': True,
        'replacement_with_symlink_never_followed': True,
        'replacement_with_fifo_does_not_block': True,
        'unaffected_diagnostics_still_retained': True,
        'read_issue_count': len(manifest['read_issues']),
    }

with tempfile.TemporaryDirectory(prefix='artifact-missing-', dir=SCRATCH) as directory:
    root = Path(directory)
    manifest = module.stage_artifacts(root / 'absent', root / 'staged')
    assert manifest['source_missing'] is True
    assert manifest['included'] == []
    assert manifest['missing_expected_records'] == list(module.EXPECTED_RECORDS)
    assert len(manifest['read_issues']) == 1
    missing_result = {'missing_source_produces_explicit_manifest': True}

actual_source = Path('/tmp/plato-phase2-linux/initial-313')
actual_target = Path(tempfile.mkdtemp(prefix='linux-initial-313-staged-', dir=SCRATCH)) / 'staged'
completed = subprocess.run(
    [sys.executable, str(HELPER), '--source', str(actual_source), '--destination', str(actual_target)],
    check=True, capture_output=True, text=True,
)
manifest = json.loads((actual_target / module.MANIFEST).read_bytes())
verify_copies(actual_source, actual_target, manifest)
actual_top_level = {path.name for path in actual_source.iterdir() if path.is_file()}
included = {record['path'] for record in manifest['included']}
assert actual_top_level <= included
assert not manifest['read_issues']
assert 'mandatory.xml' in manifest['missing_expected_records']
assert 'coverage.json' in manifest['missing_expected_records']
assert 'runtime.log' in manifest['missing_expected_records']
assert any(record['path'].endswith('result.json') for record in manifest['included'])
assert not any(Path(record['path']).suffix in ('.pth', '.safetensors', '.pkl', '.arrow')
               for record in manifest['included']
               if Path(record['path']).parts[0] in module.UNIT_PARTITIONS)

result = {
    'result': 'PASS',
    'helper': {'path': str(HELPER), 'sha256': sha(HELPER)},
    'fixture': regular_result,
    'interrupted_file_races': race_result,
    'missing_source': missing_result,
    'downloaded_linux_313': {
        'source': str(actual_source), 'destination': str(actual_target),
        'cli_exit_code': completed.returncode,
        'all_top_level_records_retained': sorted(actual_top_level),
        'summary': manifest['summary'],
        'read_issues': manifest['read_issues'],
        'missing_expected_records': manifest['missing_expected_records'],
        'manifest': {'path': str(actual_target / module.MANIFEST),
                     'bytes': (actual_target / module.MANIFEST).stat().st_size,
                     'sha256': sha(actual_target / module.MANIFEST)},
        'all_selected_bytes_and_hashes_verified': True,
        'no_staged_symlinks': True,
        'runtime_preservation_proof': 'Original Linux runtime step was skipped; actual runtime preservation is demonstrated by the realistic fixture.',
    },
}
(SCRATCH / 'artifact-selection-proof.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
