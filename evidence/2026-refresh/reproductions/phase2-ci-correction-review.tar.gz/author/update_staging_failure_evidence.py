import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/tmp/plato-refresh-worktrees/phase2-ci-budget')
SCRATCH = Path('/tmp/plato-phase2-ci-budget-validation')
BASE = '0ada82cca599310c40d4a6691aaa16a0e737f2fd'
WORKFLOW = '.github/workflows/pytorch_tests.yml'
HELPER = '.github/scripts/stage_ci_artifacts.py'
OUTPUT = ROOT / 'evidence/2026-refresh/phase2-ci-budget-validation.json'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def receipt(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


evidence = json.loads(OUTPUT.read_text())
followup = evidence['linux_followup']
red = json.loads((SCRATCH / 'staging-failure-contract-red.json').read_text())
green = json.loads((SCRATCH / 'staging-failure-contract-green.json').read_text())
static = json.loads((SCRATCH / 'staging-failure-static-proof.json').read_text())
selection = json.loads((SCRATCH / 'artifact-selection-proof.json').read_text())
review_path = SCRATCH / 'ci-review-before-failure-correction.json'
if not review_path.exists():
    review_path.write_bytes(Path('/tmp/plato-ci-internal-review/review.json').read_bytes())
review = json.loads(review_path.read_text())
assert review['status'] == 'CHANGES_REQUESTED'
assert review['source']['head'] == BASE
assert red['result'] == 'FAIL' and green['result'] == static['result'] == 'PASS'
assert green['helper']['sha256'] == selection['helper']['sha256'] == receipt(ROOT / HELPER)['sha256']
assert git('hash-object', str(SCRATCH / 'baseline-stage-ci-artifacts.py')) == git('rev-parse', f'{BASE}:{HELPER}')
evidence['status'] = 'CI_ARTIFACT_FAILURE_CONTRACT_VALIDATED_PENDING_FRESH_REVIEW_AND_313_LINUX_RERUN'
evidence['scope'] = 'Finite CI budgets, bounded artifact staging with failure propagation, and explicitly authorized Python 3.13-only matrix.'
followup['source']['workflow_after'] = {
    **receipt(ROOT / WORKFLOW), 'git_blob': git('hash-object', WORKFLOW),
}
followup['source']['helper'] = {
    **receipt(ROOT / HELPER), 'git_blob': git('hash-object', HELPER),
}
followup['artifact_selection']['missing_and_omitted_evidence'] = (
    'Manifest records each exclusion, each read issue, changed snapshots and every '
    'missing expected top-level record. Read issues fail staging after the manifest '
    'is written. Missing expected records fail staging only when the preceding '
    'qualification status was success; staging does not reinterpret pytest results.'
)
followup['artifact_selection']['proof'] = selection
followup['artifact_selection']['proof_receipt'] = receipt(SCRATCH / 'artifact-selection-proof.json')
followup['static_validation']['validated_candidate_head'] = BASE
followup['static_validation']['historical_validation_only'] = True
evidence['artifact_failure_contract_correction'] = {
    'written_at_utc': datetime.now(timezone.utc).isoformat(),
    'authorization': 'Root requested the bounded correction to internal review finding CI-ARTIFACT-FAILURE-01 using internal Codex work only; no nested agents or herdr processes.',
    'review': {
        'receipt': receipt(review_path),
        'original_review_path': '/tmp/plato-ci-internal-review/review.json',
        'finding_id': 'CI-ARTIFACT-FAILURE-01',
        'severity': 'P2',
        'problem': 'The prior CLI returned zero for unexpected read failures and wholly missing sources; expected-record gaps could leave successful qualification green.',
    },
    'source': {
        'base_candidate_head': BASE,
        'base_candidate_tree': git('rev-parse', f'{BASE}^{{tree}}'),
        'branch': git('branch', '--show-current'),
        'workflow_after': followup['source']['workflow_after'],
        'helper_after': followup['source']['helper'],
        'baseline_helper_snapshot': receipt(SCRATCH / 'baseline-stage-ci-artifacts.py'),
        'baseline_helper_git_blob_verified': True,
        'final_identity': 'Final candidate commit/tree supplied after commit to avoid self-reference.',
    },
    'behavior': {
        'cli': 'main() returns an integer exit status and __main__ propagates it through SystemExit. Recorded read issues always return 1. --require-complete also returns 1 for any missing expected record.',
        'workflow': 'The always() staging step captures preceding job.status. Its zsh command supplies --require-complete only for success, so failed or cancelled qualifications may retain expected partial evidence.',
        'manifest_on_failure': 'The existing manifest and readable files are retained before the CLI chooses its exit status.',
        'upload_on_failure': 'The pinned upload step retains its always() condition, staged path, retention period and other options.',
        'test_outcomes': 'Existing pytest commands, profile/typing assertions and failure propagation are unchanged; no continue-on-error is introduced.',
        'selection_policy': 'stage_artifacts(), imports and constants remain byte-identical to the original candidate. Expected aliases, special files, unit fixture bulk and oversized unit diagnostics remain non-failing exclusions.',
    },
    'red_green_regression': {
        'script': receipt(SCRATCH / 'test_staging_failure_contract.py'),
        'red_command': 'zsh -lc "/tmp/plato-phase2c-313/bin/python /tmp/plato-phase2-ci-budget-validation/test_staging_failure_contract.py --phase red --helper /tmp/plato-phase2-ci-budget-validation/baseline-stage-ci-artifacts.py"',
        'red_receipt': receipt(SCRATCH / 'staging-failure-contract-red.json'),
        'red_result': 'EXPECTED FAIL: both original CLI negative cases returned zero while the contract required one.',
        'green_command': 'zsh -lc "/tmp/plato-phase2c-313/bin/python /tmp/plato-phase2-ci-budget-validation/test_staging_failure_contract.py --phase green"',
        'green_receipt': receipt(SCRATCH / 'staging-failure-contract-green.json'),
        'green_result': green['result'],
        'cli_cases': {
            name: {key: result[key] for key in (
                'exit_code', 'expected_exit_code', 'manifest_retained',
                'missing_expected_records', 'passed',
            )}
            for name, result in green['cases'].items()
        },
        'actual_runtime_retention': green['actual_runtime_retention'],
        'workflow_shell_execution': green['workflow'],
    },
    'existing_selection_regression': {
        'command': followup['artifact_selection']['fixture_command'],
        'script': followup['artifact_selection']['fixture_script'],
        'result': selection['result'],
        'proof_receipt': followup['artifact_selection']['proof_receipt'],
        'downloaded_failed_linux_artifact': {
            'cli_exit_code': selection['downloaded_linux_313']['cli_exit_code'],
            'included_files': selection['downloaded_linux_313']['summary']['included_files'],
            'included_bytes': selection['downloaded_linux_313']['summary']['included_bytes'],
            'bulk_unit_bytes_excluded': selection['downloaded_linux_313']['summary']['omitted_regular_bytes'],
            'missing_expected_records': selection['downloaded_linux_313']['missing_expected_records'],
            'all_top_level_records_retained_and_all_selected_hashes_verified': True,
        },
    },
    'static_validation': {
        'command': 'zsh -lc "/tmp/plato-phase2c-313/bin/python /tmp/plato-phase2-ci-budget-validation/validate_staging_failure_correction.py"',
        'script': receipt(SCRATCH / 'validate_staging_failure_correction.py'),
        'proof_receipt': receipt(SCRATCH / 'staging-failure-static-proof.json'),
        'results': static['results'],
    },
    'scope': [WORKFLOW, HELPER, 'evidence/2026-refresh/phase2-ci-budget-validation.json'],
    'limits': [
        'No new hosted Linux run, complete mandatory/runtime result, or actual upload execution is claimed.',
        'Real runtime retention is a byte-preservation fixture using prior runtime artifacts, not a new training pass.',
        'No production, test, config, dependency, lock, root checkout or virtual environment edits.',
        'No push, pull request changes or merge performed; root handles fresh review and hosted qualification.',
    ],
    'remaining': [
        'Fresh independent review of the exact corrective commit.',
        'Exact-source Python 3.13 hosted Linux base/mandatory/runtime/quality completion before merge.',
    ],
}
OUTPUT.write_text(json.dumps(evidence, indent=2) + '\n')
print(json.dumps({'result': 'PASS', 'evidence': receipt(OUTPUT)}, indent=2))
