import ast
import copy
import hashlib
import json
import re
import subprocess
from pathlib import Path

import yaml

ROOT = Path('/tmp/plato-refresh-worktrees/phase2-ci-budget')
SCRATCH = Path('/tmp/plato-phase2-ci-budget-validation')
BASE = '0ada82cca599310c40d4a6691aaa16a0e737f2fd'
WORKFLOW = '.github/workflows/pytorch_tests.yml'
HELPER = '.github/scripts/stage_ci_artifacts.py'
EVIDENCE = 'evidence/2026-refresh/phase2-ci-budget-validation.json'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def receipt(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


class WorkflowLoader(yaml.SafeLoader):
    pass


WorkflowLoader.yaml_implicit_resolvers = {
    key: [(tag, pattern) for tag, pattern in values
          if tag != 'tag:yaml.org,2002:bool']
    for key, values in yaml.SafeLoader.yaml_implicit_resolvers.items()
}
WorkflowLoader.add_implicit_resolver(
    'tag:yaml.org,2002:bool', re.compile(r'^(?:true|True|TRUE|false|False|FALSE)$'),
    list('tTfF'),
)


def unique_mapping(loader, node):
    result = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node)
        assert key not in result, f'Duplicate YAML key: {key}'
        result[key] = loader.construct_object(value_node)
    return result


WorkflowLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
                               unique_mapping)
head = git('rev-parse', 'HEAD')
assert head == BASE or git('rev-parse', 'HEAD^') == BASE
assert git('branch', '--show-current') == 'maintenance/2026-phase2-ci-budget'
before_bytes = subprocess.check_output(['git', 'show', f'{BASE}:{WORKFLOW}'], cwd=ROOT)
after_bytes = (ROOT / WORKFLOW).read_bytes()
before = yaml.load(before_bytes, Loader=WorkflowLoader)
after = yaml.load(after_bytes, Loader=WorkflowLoader)
assert True not in before and True not in after
assert list(after['on']) == ['push', 'pull_request', 'workflow_dispatch']
job = after['jobs']['PyTorch-Tests']
steps = job['steps']
assert steps[11]['env']['QUALIFICATION_STATUS'] == '${{ job.status }}'
assert steps[11]['if'] == steps[12]['if'] == 'always()'
assert all('continue-on-error' not in step for step in steps)
normalized = copy.deepcopy(after)
normalized['jobs']['PyTorch-Tests']['steps'][11] = before['jobs']['PyTorch-Tests']['steps'][11]
assert normalized == before
old_stage = b'        run: python .github/scripts/stage_ci_artifacts.py\n'
new_stage = b'''        env:
          QUALIFICATION_STATUS: ${{ job.status }}
        run: |
          set -eu
          staging_flags=()
          if [[ "$QUALIFICATION_STATUS" == "success" ]]; then
            staging_flags+=(--require-complete)
          fi
          python .github/scripts/stage_ci_artifacts.py "${staging_flags[@]}"
'''
assert before_bytes.count(old_stage) == 1
assert after_bytes == before_bytes.replace(old_stage, new_stage, 1)
before_helper = subprocess.check_output(['git', 'show', f'{BASE}:{HELPER}'], cwd=ROOT).decode()
after_helper = (ROOT / HELPER).read_text()
assert before_helper.split('\ndef main()')[0] == after_helper.split('\ndef main()')[0]
compile(after_helper, HELPER, 'exec')
assert all(len(line) <= 88 for line in after_helper.splitlines())
before_ast = ast.parse(before_helper)
after_ast = ast.parse(after_helper)
assert ast.dump(ast.Module(before_ast.body[:-2], type_ignores=[])) == ast.dump(
    ast.Module(after_ast.body[:-2], type_ignores=[])
)
shell_checks = []
python_checks = []
for step in steps:
    if 'run' not in step:
        continue
    run = step['run']
    if step.get('shell', '').startswith('python'):
        compile(run, step['name'], 'exec')
        python_checks.append(step['name'])
    else:
        script = re.sub(r'\$\{\{.*?\}\}', 'ci_placeholder', run)
        result = subprocess.run(['zsh', '-lc', 'zsh -n'], input=script, text=True,
                                capture_output=True)
        assert result.returncode == 0, (step['name'], result.stderr)
        shell_checks.append(step['name'])
        for block in re.findall(r"<<'PY'\n(.*?)\nPY(?:\n|$)", script, flags=re.S):
            compile(block, step['name'], 'exec')
            python_checks.append(step['name'])
for command in (
    ['/tmp/plato-phase2c-313/bin/ruff', 'check', HELPER, '--select', 'I'],
    ['/tmp/plato-phase2c-313/bin/ruff', 'format', '--check', HELPER],
    ['/tmp/plato-phase2c-313/bin/ty', 'check', HELPER, '--output-format', 'concise'],
    ['git', 'diff', '--check'],
):
    subprocess.run(command, cwd=ROOT, check=True)
assert set(git('diff', '--name-only', BASE).splitlines()) <= {WORKFLOW, HELPER, EVIDENCE}
assert not git('ls-files', '--others', '--exclude-standard')
assert job['strategy']['matrix']['include'] == [
    {'python': '3.13', 'profile': 'supported-default'},
]
assert [steps[index]['timeout-minutes'] for index in (6, 8, 9)] == [25, 30, 16]
assert sum(step.get('timeout-minutes', 0) for step in steps) == 101
assert job['timeout-minutes'] == 110
red = json.loads((SCRATCH / 'staging-failure-contract-red.json').read_text())
green = json.loads((SCRATCH / 'staging-failure-contract-green.json').read_text())
assert red['result'] == 'FAIL' and green['result'] == 'PASS'
assert green['helper'] == receipt(ROOT / HELPER)
assert red['cases']['unexpected_read_failure']['exit_code'] == 0
assert red['cases']['wholly_missing_source']['exit_code'] == 0
assert green['cases']['unexpected_read_failure']['exit_code'] == 1
assert green['cases']['wholly_missing_source']['exit_code'] == 1
selection = json.loads((SCRATCH / 'artifact-selection-proof.json').read_text())
assert selection['result'] == 'PASS'
assert selection['helper']['sha256'] == receipt(ROOT / HELPER)['sha256']
result = {
    'result': 'PASS',
    'base_candidate': {'head': BASE, 'tree': git('rev-parse', f'{BASE}^{{tree}}')},
    'current_helper': {**receipt(ROOT / HELPER), 'git_blob': git('hash-object', HELPER)},
    'current_workflow': {**receipt(ROOT / WORKFLOW), 'git_blob': git('hash-object', WORKFLOW)},
    'results': {
        'yaml_github_on_and_duplicate_keys': 'PASS',
        'exact_workflow_byte_change_is_staging_status_capture_and_flag': 'PASS',
        'all_previous_steps_commands_assertions_pins_permissions_env_and_budgets_unchanged': 'PASS',
        'artifact_selection_function_and_constants_byte_identical': 'PASS',
        'upload_always_and_no_continue_on_error': 'PASS',
        'red_green_cli_failure_contract': 'PASS',
        'original_alias_race_and_downloaded_failure_selection_regression': 'PASS',
        'helper_ruff_import_order_format_typing_compile_and_line_lengths': 'PASS',
        'bounded_three_file_scope': 'PASS',
        'finite_job_stage_accounting': 'PASS',
        'zsh_syntax': {'result': 'PASS', 'steps': shell_checks},
        'embedded_python_compile': {'result': 'PASS', 'steps': python_checks},
        'git_diff_check': 'PASS',
    },
}
output = SCRATCH / 'staging-failure-static-proof.json'
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'result': 'PASS', 'receipt': receipt(output)}, indent=2))
