import hashlib
import json
from pathlib import Path

ROOT = Path('/tmp/plato-refresh-worktrees/phase2-ci-budget')
SCRATCH = Path('/tmp/plato-phase2-ci-budget-validation')
evidence = json.loads((ROOT / 'evidence/2026-refresh/phase2-ci-budget-validation.json').read_text())
verified = []


def audit(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            path = Path(value['path'])
            if not path.is_absolute():
                path = ROOT / path
            data = path.read_bytes()
            assert len(data) == value['bytes'], path
            assert hashlib.sha256(data).hexdigest() == value['sha256'], path
            verified.append(str(path))
        for item in value.values():
            audit(item)
    elif isinstance(value, list):
        for item in value:
            audit(item)


audit(evidence['artifact_failure_contract_correction'])
audit(evidence['linux_followup']['source']['workflow_after'])
audit(evidence['linux_followup']['source']['helper'])
audit(evidence['linux_followup']['artifact_selection'])
for name in ['staging-failure-contract-red.json', 'staging-failure-contract-green.json',
             'staging-failure-static-proof.json']:
    audit(json.loads((SCRATCH / name).read_text()))
print(json.dumps({'result': 'PASS', 'receipts_verified': len(verified),
                  'unique_files_verified': len(set(verified))}, indent=2))
