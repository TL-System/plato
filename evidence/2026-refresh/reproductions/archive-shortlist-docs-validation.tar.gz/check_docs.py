from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import unquote, urlsplit
import hashlib, json, re, shlex, subprocess, tomllib
import markdown

root=Path.cwd()
site=Path('/tmp/plato-model-search-docs-site')
baseline=json.loads(Path('/tmp/plato-model-search-docs-validation/before.json').read_text())['commit']
changed=subprocess.check_output(['git','diff','--name-only',baseline],text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
files=[Path(p) for p in changed+untracked if p.endswith('.md')]
class HTML(HTMLParser):
 def __init__(self, source):
  super().__init__();self.links=[];self.ids=set();self.feed(source)
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if a.get('id'):self.ids.add(a['id'])
  if tag=='a' and a.get('href'):self.links.append(a['href'])
def md(path):
 return HTML(markdown.markdown(path.read_text(),extensions=['extra','toc']))
errors=[];counts={'repository_local':0,'github_repository_targets':0,'rendered_local':0};commands=[]
def exists_case_exact(path):
 if not path.exists():return False
 try: rel=path.relative_to(root)
 except ValueError:return True
 current=root
 for part in rel.parts:
  if part not in {p.name for p in current.iterdir()}:return False
  current/=part
 return True
for file in files:
 for href in md(file).links:
  u=urlsplit(href)
  if u.netloc=='github.com' and u.path.startswith('/TL-System/plato/'):
   parts=u.path.split('/',5)
   if len(parts)==6 and parts[3] in {'tree','blob'} and parts[4]=='main':
    target=root/unquote(parts[5]);counts['github_repository_targets']+=1
    if not exists_case_exact(target):errors.append([str(file),href,'missing GitHub repository target'])
   continue
  if u.scheme or u.netloc:continue
  target=(file.parent/unquote(u.path)).resolve() if u.path else file.resolve()
  counts['repository_local']+=1
  if not exists_case_exact(target):errors.append([str(file),href,'missing repository target'])
  elif u.fragment and target.suffix=='.md' and unquote(u.fragment) not in md(target).ids:
   errors.append([str(file),href,'missing repository anchor'])
 if not str(file).startswith('docs/docs/'):continue
 page=site/file.relative_to('docs/docs').with_suffix('')/'index.html'
 if not page.exists():errors.append([str(file),'','missing built page']);continue
 for href in HTML(page.read_text()).links:
  u=urlsplit(href)
  if u.scheme or u.netloc:continue
  target=page if not u.path else (site/unquote(u.path).lstrip('/') if u.path.startswith('/') else page.parent/unquote(u.path))
  target=target.resolve()
  if target.is_dir():target/='index.html'
  counts['rendered_local']+=1
  if not target.exists():errors.append([str(page),href,'missing generated target'])
  elif u.fragment and target.suffix=='.html' and unquote(u.fragment) not in HTML(target.read_text()).ids:
   errors.append([str(page),href,'missing generated anchor'])
# Active chapter commands: only inspect paths and config selectors, never launch workloads.
chapter=Path('docs/docs/examples/algorithms/10. Algorithms based on Neural Architecture Search and Model Search.md')
for block in re.findall(r'```bash\n(.*?)```',chapter.read_text(),re.S):
 cwd=root
 for line in block.strip().splitlines():
  args=shlex.split(line)
  if args[0]=='cd':cwd=root/args[1]
  elif args[:2]==['uv','run']:
   script=next(v for v in args if v.endswith('.py'));config=args[args.index('-c')+1]
   assert (cwd/script).is_file() and (cwd/config).is_file()
   model=tomllib.loads((cwd/config).read_text())['trainer']['model_name']
   if 'sysheterofl' not in script:assert model=='resnet18'
   else:assert model=='resnet152' and '--with' in args and 'ptflops>=0.7.5' in args
   commands.append({'scope':'active','cwd':str(cwd.relative_to(root)),'command':line,'model_name':model,'targets_exist':True,'executed':False})
# Historical run commands in fences and tables must map to preserved originals.
for ident in ['fedtp','fedrlnas','anycostfl-vit','fedrolex-vit']:
 readme=Path('archives/retired')/ident/'README.md'
 for command in re.findall(r'^uv run .*$',readme.read_text(),re.M):
  args=shlex.split(command);script=args[2];config=args[args.index('-c')+1]
  family=ident.split('-')[0];directory=readme.parent/'original/examples/model_search'/family
  assert (directory/script).is_file() and (directory/config).is_file()
  tomllib.loads((directory/config).read_text())
  commands.append({'scope':'historical_unqualified','family':ident,'command':command,'targets_exist':True,'executed':False})
pfed=Path('archives/retired/pfedrlnas/README.md')
for directory,command in re.findall(r'\| `(examples/[^`]+)` \| `(uv run [^`]+)` \|',pfed.read_text()):
 args=shlex.split(command);cwd=pfed.parent/'original'/directory
 assert (cwd/args[2]).is_file() and (cwd/args[args.index('-c')+1]).is_file()
 tomllib.loads((cwd/args[args.index('-c')+1]).read_text())
 commands.append({'scope':'historical_unqualified','family':'pfedrlnas','cwd':directory,'command':command,'targets_exist':True,'executed':False})
before=json.loads(Path('/tmp/plato-model-search-docs-validation/before.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
protected={p:sha(p) for p in before['protected_sha256']}
assert protected==before['protected_sha256'],'Protected historical or MLX bytes changed'
# Check pre-retirement commit identity and every preserved original against manifests.
original_count=0
for readme in Path('archives/retired').glob('*/README.md'):
 if readme.parent.name in {'nanochat','lerobot'}:continue
 m=json.loads((readme.parent/'manifest.json').read_text())
 tree=subprocess.check_output(['git','rev-parse',m['pre_retirement_plato_commit']+'^{tree}'],text=True).strip()
 assert tree==m['pre_retirement_plato_tree']
 for f in m['files']:
  assert sha(f['archive_path'])==f['sha256'],f['archive_path']
  original_count+=1
result={'files_checked':[str(p) for p in files], 'link_counts':counts,'errors':errors,'commands':commands,
 'protected_before_after':{'files':len(protected),'all_byte_identical':True,'mapping_sha256':hashlib.sha256(json.dumps(protected,sort_keys=True).encode()).hexdigest()},
 'new_family_manifest_originals_verified':original_count,'limits':'No model workloads, historical restoration, network links, or CI/profile qualification executed.'}
Path('/tmp/plato-model-search-docs-validation/checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in {'files_checked','commands'}},indent=2))
assert not errors
