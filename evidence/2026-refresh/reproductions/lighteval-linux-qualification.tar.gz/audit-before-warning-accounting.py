"""Independently audit downloaded Phase 2 Linux artifacts and actual runtime payloads."""
import argparse
import hashlib
import json
import random
import math
import re
import xml.etree.ElementTree as ET
from fractions import Fraction
from pathlib import Path

import numpy as np
import torch

parser = argparse.ArgumentParser()
parser.add_argument("artifact", type=Path)
args = parser.parse_args()
root = args.artifact
mandatory = True
commit = (root/"commit.txt").read_text().strip()
assert re.fullmatch(r"[0-9a-f]{40}", commit)
assert (root/"lock.txt").read_text().split()[0] == "66a4e4442d7b1f26d220b44ca73c44ff4f1151a86857bb3f93a594819fd08126"
expected=json.loads(Path(__file__).with_name("expected-linux-test-ids.json").read_text())
python_version=".".join((root/"python.txt").read_text().split()[1].split(".")[:2])
profiles = []
for profile, passed, skipped in [("base",1558,1),("mandatory",1565,0),("runtime",51,0),("model-search",19,0)]:
    cases = list(ET.parse(root/(profile+".xml")).getroot().iter("testcase"))
    assert not any(c.find("failure") is not None or c.find("error") is not None for c in cases), profile
    actual_ids=sorted(c.attrib.get("classname","")+"::"+c.attrib["name"] for c in cases)
    assert actual_ids == expected[python_version][profile], (profile,
        sorted(set(actual_ids)-set(expected[python_version][profile])),
        sorted(set(expected[python_version][profile])-set(actual_ids)))
    skip_rows = [dict(case=c.attrib, reason=c.find("skipped").attrib)
                 for c in cases if c.find("skipped") is not None]
    assert len(cases)-len(skip_rows) == passed and len(skip_rows) == skipped, (profile,len(cases),skip_rows)
    log = (root/(profile+".log")).read_text()
    warning_counts = re.findall(r"(\d+) warnings?",log.split("short test summary info")[-1])
    count = int(warning_counts[-1]) if warning_counts else 0
    assert count == {"base":10,"mandatory":27,"runtime":0,"model-search":0}[profile], (profile,count)
    if profile in {"base", "mandatory"}:
        assert "70 deselected" in log
    profiles.append(dict(profile=profile,passed=passed,skips=skip_rows,warnings=count,
                         cases=[c.attrib for c in cases],
                         log_sha256=hashlib.sha256((root/(profile+".log")).read_bytes()).hexdigest()))
assert "mandatory prerequisite failed: No module named 'opacus'" in (root/"missing-extra.log").read_text()
assert "All checks passed!" in (root/"ruff.log").read_text()
coverage=json.loads((root/"coverage.json").read_text())
changed=set(json.loads(Path(__file__).with_name("lighteval-changed-paths.json").read_text()))
typing_rows=[]
for match in re.finditer(r"^(.+?):(\d+):(\d+): (?:error|warning)\[([^]]+)\] (.*)$",(root/"ty.log").read_text(),re.M):
    file,line,column,code,message=match.groups()
    if file.startswith(("plato/models/dvit/","plato/models/t2tvit/","external/")): group="pinned_vendor"
    elif file.startswith("archives/"): group="inactive_archive"
    elif file.startswith("evidence/"): group="retained_reproduction"
    elif file.startswith("tests/"): group="tests_changed" if file in changed else "tests_unchanged"
    else: group="active_source_changed" if file in changed else "active_source_unchanged"
    typing_rows.append(dict(file=file,line=int(line),column=int(column),code=code,message=message,group=group))
ty_report=re.search(r"^Found ([1-9][0-9]*) diagnostics?$",(root/"ty.log").read_text(),re.M)
assert (ty_report is not None and len(typing_rows)==int(ty_report[1])) or (not typing_rows and (root/"ty.log").read_text().strip()=="All checks passed!")
assert not any(row["group"] in {"active_source_changed", "tests_changed"} for row in typing_rows)
typing_groups={}
for row in typing_rows:
    typing_groups[row["group"]]=typing_groups.get(row["group"],0)+1
runtime_records=[]
runtime_duplicate_paths=[]
seen_runtime_hashes=set()
fedavg=None
for p in sorted((root/"runtime-tmp").rglob("result.json")):
    d=json.loads(p.read_text())
    if not isinstance(d,dict) or "processes" not in d or "events" not in d:
        continue
    digest=hashlib.sha256(p.read_bytes()).hexdigest()
    if digest in seen_runtime_hashes:
        runtime_duplicate_paths.append(str(p.relative_to(root)))
        continue
    seen_runtime_hashes.add(digest)
    assert not d["survivors"],p
    rec=dict(path=str(p.relative_to(root)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),case=d.get("case","feddyn_entrypoint"),returncode=d["returncode"],timed_out=d["timed_out"],forced=d["forced"],survivors=d["survivors"])
    if "case" not in d or d.get("case")=="socket_round":
        assert d["returncode"]==0 and not d["timed_out"] and not d["forced"],p
    if d.get("case")=="socket_round":
        received=[e for e in d["events"] if e["event"]=="server_received"]
        aggregate=next(e["weights"] for e in d["events"] if e["event"]=="server_aggregate")
        assert sorted(e["samples"] for e in received)==[2,6]
        errors={}
        for key,actual in aggregate.items():
            expected=sum(np.asarray(e["weights"][key],dtype=np.float64)*e["samples"] for e in received)/8
            error=float(np.max(np.abs(np.asarray(actual)-expected)))
            assert error<=1e-6,(key,error)
            errors[key]=error
        fedavg=dict(samples=[e["samples"] for e in received],max_absolute_error=max(errors.values()),per_key_error=errors,natural_completion=True)
    runtime_records.append(rec)
if mandatory:
    assert len(runtime_records)==55,len(runtime_records)
    assert sum(r["case"]=="feddyn_entrypoint" for r in runtime_records)==7
    assert fedavg is not None

def load(p):
    return torch.load(p,weights_only=True,map_location="cpu")
def equal(a,b):
    if type(a) is not type(b):
        return False
    if isinstance(a,torch.Tensor):
        return a.dtype==b.dtype and a.shape==b.shape and torch.equal(a,b)
    if isinstance(a,np.ndarray):
        return a.dtype==b.dtype and np.array_equal(a,b)
    if isinstance(a,dict):
        return a.keys()==b.keys() and all(equal(a[k],b[k]) for k in a)
    if isinstance(a,(list,tuple)):
        return len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
    return a==b
scalar=[]
for parent in sorted((root/"runtime-tmp").glob("test_actual_shipped_run_resume[0-9]*")):
    # Pytest parameter index0 is uniform, index1 sample; derive from saved bundle.
    first_bundle=load(parent/"control/run/committed-1.pth")
    mode=first_bundle["config"]["weighting"]
    assert first_bundle["config"]["base_alpha"]==0.1 and first_bundle["config"]["lr"]==0.1
    assert first_bundle["config"]["population"]==10 and first_bundle["config"]["per_round"]==2
    x=Fraction(2);history=[Fraction(0)]*10;selector=random.Random(17)
    rows=[]
    for round_id in range(1,5):
        selected=selector.sample(list(range(1,11)),2)
        endpoints={}
        for i in selected:
            y=x
            alpha=Fraction(1,10) if mode=="uniform" else Fraction(11,20*i)
            for _ in range(2):
                y-=Fraction(1,10)*(y-i+alpha*(y-x+history[i-1]))
            endpoints[i]=y
            history[i-1]+=y-x
        x=sum(endpoints.values())/2+sum(history)/10
        directories=[parent/"control/run",parent/("split/first" if round_id<=2 else "split/resumed")]
        for directory in directories:
            actual=load(directory/f"committed-{round_id}.pth")
            incoming=load(directory/f"received-{round_id}.pth")
            assert incoming["selected"]==selected
            assert abs(actual["model"]["theta"].item()-float(x))<=1e-12
            for i,h in enumerate(history,1):
                assert abs(actual["histories"][i]["theta"].item()-float(h))<=1e-12
            for payload in incoming["payloads"]:
                assert type(payload[1]["client_id"]) is int
                assert abs(payload[0]["theta"].item()-float(endpoints[payload[1]["client_id"]]))<=1e-12
        if round_id>=3:
            a,b=(load(directory/f"committed-{round_id}.pth") for directory in directories)
            assert all(equal(a[k],b[k]) for k in ("model","histories","counts","committed_round","rng"))
        rows.append(dict(round=round_id,selected=selected,cloud_exact=str(x),cloud=float(x),histories_exact=list(map(str,history))))
    saved=load(parent/"split/first/committed-2.pth")
    start=load(parent/"split/resumed/start.pth")
    assert start["round"]==2 and start["pending"] is None and equal(saved["rng"],start["rng"])
    scalar.append(dict(mode=mode,rows=rows,full_cpu_rng_resume_equal=True))
if mandatory:
    assert sorted(r["mode"] for r in scalar)==["sample","uniform"],scalar
records = []
seen = set()
for path in sorted((root / 'model-search-tmp').rglob('result.json')):
    data = json.loads(path.read_text())
    if not isinstance(data, dict) or 'family' not in data or 'events' not in data:
        continue
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest in seen:
        continue
    seen.add(digest)
    assert data['returncode'] == 0 and not data['timed_out'] and not data['forced'] and not data['survivors'], path
    assert data['lock_sha256'] == '66a4e4442d7b1f26d220b44ca73c44ff4f1151a86857bb3f93a594819fd08126'
    events = data['events']
    assert any(e['event'] == 'success' for e in events)
    if data['case'] == 'socket':
        assert [e['rate'] for e in events if e['event'] == 'selected_rate'] == [0.5, 1.0]
        assert sorted(e['samples'] for e in events if e['event'] == 'client_trained') == [2, 6]
        oracles = [e for e in events if e['event'] == 'aggregation_oracle']
        assert len(oracles) == 1
        assert oracles[0]['weighting'] == 'uniform channel average'
        assert math.isfinite(oracles[0]['max_error']) and oracles[0]['max_error'] <= 1e-5
    if data['case'] == 'budget':
        oracle = next(e for e in events if e['event'] == 'activated_budget')
        assert oracle['limitation_activated'] is True
        assert len(oracle['records']) == 2
        assert oracle['records'][1]['selected_rate'] < oracle['records'][0]['selected_rate']
        assert all(math.isfinite(q['macs']) and q['macs'] > 0 for q in oracle['queries'])
        for row in oracle['records']:
            assert math.isfinite(row['loss'])
            assert all(0 < v <= b for v, b in zip(row['selected_profile'], row['budget'], strict=True))
    records.append({'path':str(path.relative_to(root)), 'sha256':digest, **data})
assert len(records) == 19, len(records)
assert sum(r['case'] == 'socket' for r in records) == 3
assert sum(r['case'] == 'budget' for r in records) == 3

result=dict(status="PASS_ROOT_ARCHIVE_LINUX_ARTIFACT_AUDIT",merge_commit=commit,
            profiles=profiles,runtime_observations=runtime_records,runtime_upload_aliases=runtime_duplicate_paths,fedavg=fedavg,
            feddyn_scalar=scalar,retained_records=records,coverage_totals=coverage["totals"],typing=dict(total=len(typing_rows),groups=typing_groups,diagnostics=typing_rows),
            python=(root/"python.txt").read_text().strip(),
            submodules=(root/"submodules.txt").read_text(),
            limitations="Artifact provenance must additionally match the published qualified source; dependency/type logs and step timings are retained.")
(root/"root-audit.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(dict(status=result["status"],python=result["python"],
                     merge_commit=commit,profiles=[(p["profile"],p["passed"],p["warnings"]) for p in profiles],
                     coverage=result["coverage_totals"].get("percent_covered_display"))))
