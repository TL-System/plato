import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser()
parser.add_argument('artifact', type=Path)
parser.add_argument('--xml', default='llm-eval.xml')
args = parser.parse_args()
root = args.artifact
source = Path('/tmp/plato-refresh-worktrees/lighteval-final')
ledger = json.loads((source / 'tests/llm_eval/cases.json').read_text())['cases']
expected = Counter(row['nodeid'].split('::', 1)[1] for row in ledger)
cases = list(ET.parse(root / args.xml).getroot().iter('testcase'))
assert Counter(c.attrib['name'] for c in cases) == expected
assert not any(c.find(tag) is not None for c in cases for tag in ('skipped', 'error', 'failure'))
oracles = []
for case in cases:
    name = case.attrib['name']
    props = {p.attrib['name']: p.attrib['value'] for p in case.findall('properties/property')}
    if 'actual_runtime_rounds' in props:
        data = json.loads(props['actual_runtime_rounds'])
        assert len(data['normalized']) == len(data['cache_responses']) == 2
        observed = []
        for index, response_tasks in enumerate(data['cache_responses']):
            assert len(response_tasks) == 5
            scores = []
            for task, rows in response_tasks.items():
                assert {str(row['sample_id']) for row in rows} == {'0', '1', '2'}
                if task.startswith('arc:'):
                    predictions = []
                    for row in rows:
                        likelihoods = row['sample']['logprobs']
                        assert len(likelihoods) == 2 and likelihoods[0] != likelihoods[1]
                        predictions.append('A' if likelihoods[0] > likelihoods[1] else 'B')
                else:
                    assert all(len(row['sample']['text']) == 1 for row in rows)
                    predictions = [row['sample']['text'][0] for row in rows]
                assert predictions == ['AB'[index]] * 3
                correct = sum(prediction == ('A' if str(row['sample_id']) in {'0', '1'} else 'B') for row, prediction in zip(rows, predictions, strict=True))
                scores.append(correct / len(rows))
            assert len(set(scores)) == 1
            value = scores[0]
            normalized = data['normalized'][index]
            assert normalized['primary_value'] == value
            assert all(metric == value for metric in normalized['metrics'].values())
            observed.append(value)
        assert observed == [2 / 3, 1 / 3]
        oracles.append({'case': name, 'independent_sample_scores': observed, 'real_response_tasks': 5})
    elif 'actual_readonly_source' in props:
        data = json.loads(props['actual_readonly_source'])
        assert data['seeded_response_text'] == [['A']] * 3
        assert data['result']['primary_value'] == 1 / 3
        assert all(data[k] for k in ('source_unchanged', 'readonly_permission_enforced', 'owned_copies_and_cache_removed'))
        assert int(props['readonly_fixture_permissions_restored']) >= 12
        oracles.append({'case': name, 'stale_cache_ignored': True, 'source_unchanged': True, 'cleanup_and_fixture_restoration': True})
    elif 'actual_post_inference_failure' in props:
        data = json.loads(props['actual_post_inference_failure'])
        assert data['response_count_before_injected_failure'] == data['cache_files_before_injected_failure'] == 5
        assert all(data[k] for k in ('source_unchanged', 'owned_copies_and_cache_removed', 'stale_context_cleared'))
        oracles.append({'case': name, 'real_inference_then_failure_cleanup': True})
assert len(oracles) == 6
record = {'status': 'PASS_EXACT11_AND_RAW_RESPONSE_ORACLES', 'cases': 11, 'oracles': oracles,
    'xml_sha256': hashlib.sha256((root / args.xml).read_bytes()).hexdigest(),
    'limits': 'Tiny local controlled-model execution, not pretrained benchmark accuracy. CI interpreter/prerequisite/source acceptance must be verified separately.'}
(root / 'root-optional-audit.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
