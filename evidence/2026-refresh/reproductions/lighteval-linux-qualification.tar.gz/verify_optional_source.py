import hashlib
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
source = Path('/tmp/plato-refresh-worktrees/lighteval-final')
commit = (root / 'commit.txt').read_text().strip()
receipt = json.loads((root / 'llm-eval-acceptance.json').read_text())
ledger = json.loads((root / 'llm-eval-source-ledger.json').read_text())
identity = json.loads((root / 'llm-eval-interpreter.json').read_text())
prerequisites = json.loads((root / 'llm-eval-prerequisites.json').read_text())
assert prerequisites['preflight_passed']
assert prerequisites['interpreter'] == identity
assert prerequisites['packages']['xxhash'] == '3.8.1'
assert prerequisites['packages']['lighteval'] == '0.13.0'
assert set(prerequisites['resources']) == {'punkt', 'punkt_tab'}
assert all(r['sha256'] and r['origin'] == 'NLTK downloader official package index' for r in prerequisites['resources'].values())
assert receipt['accepted'] and not receipt['issues']
assert receipt['outcomes'] == {'passed': 11}
assert ledger['commit'] == commit
assert ledger['interpreter'] == identity
assert identity['python'].startswith('3.13.')
assert identity['prefix'] == identity['exec_prefix'] == identity['configured_environment']
assert identity['executable'].startswith(identity['configured_environment'] + '/bin/python')
assert receipt['sha256'] == ledger['sha256']
for name, digest in ledger['sha256'].items():
    assert hashlib.sha256((source / name).read_bytes()).hexdigest() == digest, name
expected = [r['nodeid'] for r in json.loads((source / 'tests/llm_eval/cases.json').read_text())['cases']]
assert receipt['expected_nodes'] == receipt['collected_nodes'] == receipt['junit_nodes'] == expected
assert 'All checks passed!' in (root / 'llm-eval-ty.log').read_text()
record = {'status': 'PASS_OPTIONAL_SOURCE_LEDGER_INTERPRETER', 'ci_commit': commit,
    'source_hashes': len(ledger['sha256']), 'expected_cases': len(expected),
    'interpreter': identity, 'prerequisites': prerequisites}
(root / 'root-optional-source-audit.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'status': record['status'], 'ci_commit': commit, 'expected_cases': len(expected)}))
