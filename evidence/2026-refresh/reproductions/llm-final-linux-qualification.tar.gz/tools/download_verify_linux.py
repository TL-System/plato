"""Download and verify PR418 qualification evidence after a successful job."""
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path("/tmp/plato-llm-linux")
ARTIFACT = ROOT / "313"
SOURCE = Path("/tmp/plato-refresh-worktrees/llm-publication")
HEAD = "1130ff0250ee26a49328e15cf5596f430c468c9d"
RUN = "37143836327"

def run(*args, cwd=None):
    return subprocess.check_output(args, cwd=cwd, text=True)

ROOT.mkdir(exist_ok=True)
metadata = json.loads(run("gh", "run", "view", RUN, "--json", "status,conclusion,jobs,headSha,url", cwd=SOURCE))
(ROOT / "run.json").write_text(json.dumps(metadata, indent=2) + "\n")
assert metadata["status"] == "completed" and metadata["conclusion"] == "success", metadata
assert metadata["headSha"] == HEAD, metadata["headSha"]
if not ARTIFACT.exists():
    subprocess.run(["gh", "run", "download", RUN, "--name", "pytorch-3.13-1", "--dir", str(ARTIFACT)], cwd=SOURCE, check=True)
manifest = json.loads((ARTIFACT / "artifact-selection.json").read_text())
assert manifest["collection_status"] == "STAGED" and not manifest["source_missing"]
assert not manifest["read_issues"] and not manifest["missing_expected_records"]
paths = set()
for row in manifest["included"]:
    relative = Path(row["path"])
    assert not relative.is_absolute() and ".." not in relative.parts
    assert row["path"] not in paths
    paths.add(row["path"])
    p = ARTIFACT / relative
    assert p.is_file() and not p.is_symlink(), p
    data = p.read_bytes()
    assert len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"], p
assert len(paths) == manifest["summary"]["included_files"]
subprocess.run(["git", "fetch", "origin", "refs/pull/418/merge"], cwd=SOURCE, check=True)
merge = run("git", "rev-parse", "FETCH_HEAD", cwd=SOURCE).strip()
assert (ARTIFACT / "commit.txt").read_text().strip() == merge
published_tree = run("git", "rev-parse", HEAD + "^{tree}", cwd=SOURCE).strip()
merge_tree = run("git", "rev-parse", merge + "^{tree}", cwd=SOURCE).strip()
assert published_tree == merge_tree, (published_tree, merge_tree)
receipt = dict(status="PASS_ARTIFACT_BYTES_AND_SOURCE_BINDING", published_head=HEAD, ci_merge=merge,
               tree=published_tree, run=int(RUN), artifact_files=len(paths), summary=manifest["summary"],
               manifest_sha256=hashlib.sha256((ARTIFACT / "artifact-selection.json").read_bytes()).hexdigest())
(ROOT / "artifact-verification.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt))
