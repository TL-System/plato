"""Assemble the bounded count-collection review after independent checks finish."""

import collections
import datetime
import hashlib
import json
import re
import subprocess
from pathlib import Path


SCRATCH = Path(__file__).resolve().parent
SOURCE = Path('/tmp/plato-refresh-worktrees/count-collection-review')
ROOT_REPORT = Path('/Users/bli/Playground/plato/evidence/2026-refresh/phase2-count-collection-review.json')
CANDIDATE = '0fbc1162994c05041105b1860fc8cb02582d21f3'
TREE = '55caefff33db4c0f41c3ac35d5ff661424f1fb88'


def read(name):
    return json.loads((SCRATCH / name).read_text())


def artifact(path):
    path = Path(path)
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def git(*args):
    return subprocess.check_output(
        ['git', '--no-optional-locks', *args], cwd=SOURCE, text=True
    ).strip()


def main():
    assert git('rev-parse', 'HEAD') == CANDIDATE
    assert git('rev-parse', 'HEAD^{tree}') == TREE
    assert git('status', '--porcelain', '--untracked-files=all') == ''
    preparation = read('preparation.json')
    preservation = read('source-preservation.json')
    harness = read('harness-isolation-audit.json')
    author = read('author-evidence-audit.json')
    interpreters = read('green-interpreters.json')
    full_baseline = read('baseline-full-suite-carry-forward.json')
    dp_records = read('root-dp-evidence-preservation-before.json')
    for record in dp_records.values():
        assert artifact(record['path'])['sha256'] == record['sha256']
        record['unchanged_after_review'] = True
    dp_acceptance = json.loads(Path(dp_records['phase2-dp-typing-acceptance.json']['path']).read_text())
    assert dp_acceptance['review_sha256'] == dp_records['phase2-dp-typing-review.json']['sha256']
    executions = {}
    observations = {}
    expected_count_names = {case['name'] for case in preparation['expected_test_cases']}
    for name in ['red-313', 'red-314', 'green-313', 'green-314']:
        run = SCRATCH / 'runs' / name
        receipt = json.loads((run / 'receipt.json').read_text())
        assert receipt['initial_source_status'] == receipt['final_source_status'] == ''
        assert receipt['final_head'] == receipt['commit']
        assert receipt['log_sha256'] == artifact(run / 'pytest.log')['sha256']
        assert receipt['xml_sha256'] == artifact(run / 'results.xml')['sha256']
        assert receipt['survivors'] == []
        outcomes = dict(collections.Counter(case['outcome'] for case in receipt['cases']))
        log = (run / 'pytest.log').read_text()
        warning_counts = re.findall(r'\b(\d+) warnings?\b', log)
        execution = {key: value for key, value in receipt.items()
                     if key != 'observed_processes'}
        execution['outcome_counts'] = outcomes
        execution['receipt'] = artifact(run / 'receipt.json')
        execution['raw_log'] = artifact(run / 'pytest.log')
        execution['raw_xml'] = artifact(run / 'results.xml')
        execution['pytest_warning_count_reported'] = int(warning_counts[-1]) if warning_counts else 0
        execution['warnings_scope'] = 'Counts warnings reported by the pytest log; successful helpers retain the existing capture_output behavior. No warning filter was added or changed.'
        execution['observed_descendant_processes'] = len(receipt['observed_processes'])
        execution['full_collection'] = {'root_argument': 'tests', 'total_collected': 1303,
                                        'selected': len(receipt['cases'])}
        if name.startswith('red'):
            assert receipt['commit'] == preparation['baseline_commit']
            assert receipt['exit_code'] == 1 and outcomes == {'passed': 1, 'failed': 1}
            assert "it's not the same object as feddyn_trainer.PlainSGD" in log
            assert '1301 deselected' in log
            execution['expected_failure'] = 'spawn=True fails before training at multiprocessing PlainSGD pickling after whole-suite collection; spawn=False passes.'
        else:
            assert receipt['commit'] == CANDIDATE and receipt['exit_code'] == 0
            assert outcomes == {'passed': 36} and '1267 deselected' in log
            count_cases = [case for case in receipt['cases']
                           if case['classname'] == 'tests.integration.test_feddyn_count_boundaries']
            assert len(count_cases) == 20
            assert {case['name'] for case in count_cases} == expected_count_names
            rejection = [case for case in receipt['cases'] if case['name'].startswith('test_actual_spawned_rejection_retry_and_logical_reuse[')]
            partial = [case for case in receipt['cases'] if case['name'].startswith('test_actual_spawn_reused_client_matches_partial_oracle[')]
            personal = [case for case in receipt['cases'] if case['name'] == 'test_actual_spawn_returns_personal_state_and_optimizer_across_rounds[feddyn]']
            assert (len(rejection), len(partial), len(personal)) == (13, 2, 1)
            execution['selected_case_groups'] = {'count_boundaries': 20, 'existing_rejection_retry_variants': 13, 'existing_partial_spawn_references': 2, 'existing_personal_state_spawn_path': 1}
            parent_dir = run / 'pytest-temp' / 'test_parent_realizes_partition1'
            parent_file = parent_dir / 'partition-result.json'
            worker_file = parent_dir / 'run' / 'worker-partition.json'
            result = json.loads(parent_file.read_text())
            epochs = json.loads(worker_file.read_text())
            assert result == {'calls': 1, 'report_count': 2, 'worker_count': 2,
                              'endpoint': 1.622, 'worker_epochs': 2, 'no_active_children': True}
            assert len(epochs) == 2 and epochs[0]['pid'] == epochs[1]['pid']
            for epoch in epochs:
                assert epoch['start_method'] == 'spawn' and epoch['indices'] == [7, 13]
                assert epoch['backing_items'] == 100 and epoch['count'] == 2
            processes = {row['pid']: row for row in receipt['observed_processes']}
            worker = processes[epochs[0]['pid']]
            assert 'spawn_main' in worker['command']
            helper = processes[worker['ppid']]
            assert 'tests.integration.feddyn_partition_worker' in helper['command']
            assert helper['pid'] != worker['pid']
            observations[name] = {
                'parent_result': result, 'worker_epochs': epochs,
                'parent_result_artifact': artifact(parent_file),
                'worker_observation_artifact': artifact(worker_file),
                'observed_helper_process': helper, 'observed_worker_process': worker,
                'completion_evidence': 'Helper returned successfully; unchanged production joins the child and rejects a nonzero exit before accepting worker state. Parent accepted count 2 and endpoint 1.622. Helper asserted mp.active_children() empty; independent ps descendant monitoring found no survivors after pytest completion.',
                'observed_worker_completion_and_no_survivors': True,
                'survivors': [],
            }
        executions[name] = execution
    preservation['final_source_status'] = git('status', '--porcelain', '--untracked-files=all')
    preservation['final_submodule_status'] = git('submodule', 'status', '--recursive')
    assert preservation['final_submodule_status'] == preservation['submodule_status'].strip()
    criteria = [{'criterion': criterion, 'status': 'PASS'} for criterion in preparation['required_checks']]
    report = {
        'schema_version': 1, 'finding_id': 'ROOT-2C-COLLECTION-01',
        'review_kind': 'Fresh independent immutable-candidate count-collection harness review',
        'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'verdict': 'PASS_BOUNDED', 'finding_status': 'CORRECTED_IN_REVIEWED_CANDIDATE',
        'material_findings': [],
        'summary': 'The guarded helper corrects the full-collection spawn identity failure while preserving all 20 count-boundary cases, all 18 original assertions, all state comparisons, real multiprocessing, and original numerical/deadline checks. Independent whole-suite collection plus selected execution passes 36 cases on each Python version. No tracked worker survivors. Approval is limited to the three-file count correction over accepted DP base f342.',
        'reviewer': {'independent_of_author': True, 'nested_agents': False,
                     'shell': 'zsh -lc', 'scratch': str(SCRATCH)},
        'candidate': {'source': str(SOURCE), 'commit': CANDIDATE, 'tree': TREE,
                      'implementation_commit': '05468d5db1632c525f7f3dc9ac11ab12cf2cb0cd',
                      'count_correction_base': 'f342a5a6021cee938e0b880eca5919e09ace1981',
                      'independent_red_baseline': preparation['baseline_commit'],
                      'author_validation_evidence': author['candidate_evidence'],
                      'exact_test_helper_diff': artifact(SCRATCH / 'reviewed-test-helper.diff'),
                      'exact_three_file_diff': artifact(SCRATCH / 'reviewed-count-correction.diff')},
        'criteria': criteria, 'source_DP_CI_preservation': preservation,
        'accepted_DP_review_and_acceptance_preservation': dp_records,
        'DP_scope': 'Protected DP test and validation evidence match f342 byte-for-byte. Existing root review/acceptance remain unchanged and their hash linkage validates. DP typing/runtime task was not repeated.',
        'harness_isolation_review': harness,
        'independent_interpreters': interpreters,
        'independent_full_collection_red_green': executions,
        'independent_actual_parent_child_observations': observations,
        'author_evidence_reconciliation': author,
        'baseline_full_suite_carry_forward': {
            key: value for key, value in full_baseline.items()
            if key != 'runtime_and_entrypoint_cases'
        },
        'review_receipts': [artifact(SCRATCH / name) for name in [
            'preparation.json', 'source-preservation.json', 'harness-isolation-audit.json',
            'author-evidence-audit.json', 'baseline-full-suite-carry-forward.json',
            'root-dp-evidence-preservation-before.json', 'green-interpreters.json',
            'run_selected.py', 'build_final_report.py']],
        'limits': [
            'Selected execution after full collection is not a full-suite or whole-phase acceptance claim.',
            'Original integrated 2633 full run remains FAILED: 1301 passed, 1 expected skip, 1 known count failure, 17 notices; 51 runtime/entrypoint cases passed. Fresh final full qualification remains required after integration.',
            'Review covers CPU/macOS arm64 harness behavior on Python 3.13.16 and 3.14.8, with torch 2.14.1; no GPU or unrelated production numerics claim.',
            preservation['integration_scope_note'],
            'Process sampling verifies observed descendants, and the specific helper/worker PIDs are independently matched. Worker success additionally follows unchanged production exit-code/acceptance guards and the helper active-child assertion.',
        ],
        'resource_and_write_scope': {
            'source_unchanged': True, 'historical_tracked_DViT_cache_files_untouched': 131,
            'environments_read_only': preparation['read_only_environments'],
            'all_generated_caches_and_test_artifacts_in_scratch': True,
            'project_bytecode_writes_disabled': True,
            'all_library_cold_bytecode_cache_policy': False,
            'source_edits_commits_pushes_cleanup': False,
            'only_root_write': str(ROOT_REPORT),
        },
        'whole_phase_acceptance_claimed': False,
        'handoff_state': 'RETURNED_FOR_ROOT_BOUNDED_ACCEPTANCE_AND_INTEGRATION; reviewer idle after report.',
    }
    encoded = (json.dumps(report, indent=2) + '\n').encode()
    local_report = SCRATCH / ROOT_REPORT.name
    local_report.write_bytes(encoded)
    ROOT_REPORT.write_bytes(encoded)
    assert ROOT_REPORT.read_bytes() == local_report.read_bytes()
    assert git('status', '--porcelain', '--untracked-files=all') == ''
    print(json.dumps({'report': str(ROOT_REPORT), 'sha256': hashlib.sha256(encoded).hexdigest(),
                      'bytes': len(encoded), 'verdict': report['verdict'],
                      'green_313': executions['green-313']['outcome_counts'],
                      'green_314': executions['green-314']['outcome_counts'],
                      'no_survivors': True, 'source_clean': True}))


if __name__ == '__main__':
    main()
