"""Read-only selected pytest runs with immutable-source and process receipts."""

import argparse
import hashlib
import json
import os
import re
import shlex
import subprocess
import time
import xml.etree.ElementTree as ET
from pathlib import Path


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def process_table():
    rows = {}
    output = subprocess.check_output(
        ["ps", "-axo", "pid=,ppid=,lstart=,command="], text=True
    )
    for line in output.splitlines():
        parts = line.split(None, 7)
        if len(parts) == 8:
            pid, ppid = map(int, parts[:2])
            rows[pid] = {
                "pid": pid,
                "ppid": ppid,
                "started": " ".join(parts[2:7]),
                "command": parts[7],
            }
    return rows


def git(source, *args):
    return subprocess.check_output(
        ["git", "--no-optional-locks", *args], cwd=source, text=True
    ).strip()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("commit")
    parser.add_argument("python", type=Path)
    parser.add_argument("name")
    parser.add_argument("keyword")
    parser.add_argument("--collect-only", action="store_true")
    args = parser.parse_args()
    scratch = Path(__file__).resolve().parent
    run = scratch / "runs" / args.name
    run.mkdir(parents=True, exist_ok=False)
    source = args.source.resolve()
    assert git(source, "rev-parse", "HEAD") == args.commit
    initial_status = git(source, "status", "--porcelain", "--untracked-files=all")
    env = os.environ.copy()
    for key in ("PYTHONPATH", "PYTEST_ADDOPTS", "PYTEST_PLUGINS", "config_file"):
        env.pop(key, None)
    env.update(PYTHONDONTWRITEBYTECODE="1", GIT_OPTIONAL_LOCKS="0")
    for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
        env[key] = "1"
    for key, directory in {
        "TMPDIR": "temp",
        "XDG_CACHE_HOME": "cache",
        "MPLCONFIGDIR": "matplotlib",
        "HF_HOME": "huggingface",
        "TORCH_HOME": "torch",
    }.items():
        path = run / directory
        path.mkdir()
        env[key] = str(path)
    origins_code = (
        "import importlib.util,json,pathlib,sys;"
        "names=['plato','tests','torch','numpy','pytest'];"
        "specs={n:importlib.util.find_spec(n) for n in names};"
        "out={n:s.origin for n,s in specs.items()};"
        "assert pathlib.Path(out['plato']).resolve().is_relative_to(pathlib.Path.cwd());"
        "assert pathlib.Path(out['tests']).resolve().is_relative_to(pathlib.Path.cwd());"
        "print(json.dumps({'python':sys.version,'executable':sys.executable,'origins':out}))"
    )
    origins = json.loads(subprocess.check_output(
        [str(args.python), "-B", "-c", origins_code], cwd=source, env=env, text=True
    ))
    argv = [str(args.python), "-B", "-m", "pytest", "tests", "-k", args.keyword]
    argv += ["-p", "no:cacheprovider", "-q", f"--basetemp={run / 'pytest-temp'}"]
    if args.collect_only:
        argv.append("--collect-only")
    else:
        argv.append(f"--junitxml={run / 'results.xml'}")
    launched = ["zsh", "-lc", shlex.join(argv)]
    started = time.monotonic()
    tracked = {}
    with (run / "pytest.log").open("w") as log:
        proc = subprocess.Popen(launched, cwd=source, env=env, stdout=log, stderr=log)
        tracked[proc.pid] = {"pid": proc.pid}
        while proc.poll() is None:
            table = process_table()
            changed = True
            while changed:
                changed = False
                for pid, row in table.items():
                    if row["ppid"] in tracked and pid not in tracked:
                        tracked[pid] = row
                        changed = True
            if proc.pid in table:
                tracked[proc.pid] = table[proc.pid]
            time.sleep(0.15)
    # Observe tracker/share-manager teardown without touching any external process.
    deadline = time.monotonic() + 5
    while True:
        table = process_table()
        survivors = [row for pid, row in table.items() if pid in tracked
                     and row.get("started") == tracked[pid].get("started")]
        if not survivors or time.monotonic() >= deadline:
            break
        time.sleep(0.15)
    log_text = (run / "pytest.log").read_text()
    junit = []
    if not args.collect_only and (run / "results.xml").exists():
        for case in ET.parse(run / "results.xml").iter("testcase"):
            junit.append({
                "classname": case.attrib["classname"],
                "name": case.attrib["name"],
                "outcome": "failed" if case.find("failure") is not None else
                           "error" if case.find("error") is not None else
                           "skipped" if case.find("skipped") is not None else "passed",
            })
    receipt = {
        "commit": args.commit,
        "tree": git(source, "rev-parse", "HEAD^{tree}"),
        "cwd": str(source), "argv": argv, "launcher": launched,
        "origins": origins,
        "environment_overrides": {key: env[key] for key in (
            "PYTHONDONTWRITEBYTECODE", "GIT_OPTIONAL_LOCKS", "TMPDIR",
            "XDG_CACHE_HOME", "MPLCONFIGDIR", "HF_HOME", "TORCH_HOME",
            "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
            "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS")},
        "exit_code": proc.returncode, "seconds": time.monotonic() - started,
        "log": str(run / "pytest.log"), "log_sha256": sha256(run / "pytest.log"),
        "xml_sha256": sha256(run / "results.xml") if junit else None,
        "summaries": [line for line in log_text.splitlines()
                      if re.search(r"\b(passed|failed|deselected|collected|selected)\b", line)][-4:],
        "cases": junit,
        "observed_processes": list(tracked.values()), "survivors": survivors,
        "initial_source_status": initial_status,
        "final_source_status": git(source, "status", "--porcelain", "--untracked-files=all"),
        "final_head": git(source, "rev-parse", "HEAD"),
        "scope": "Whole tests suite collected; keyword-selected checks only. No full-profile qualification claim.",
        "process_observation": "ps descendant sampling; completed worker acceptance is additionally checked by test assertions.",
    }
    (run / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"run": str(run), "exit_code": proc.returncode,
                      "summaries": receipt["summaries"], "survivors": survivors}))


if __name__ == "__main__":
    main()
