import datetime
import gzip
import hashlib
import json
from pathlib import Path
import tarfile

out = Path('/tmp/plato-archive-linux')
target = out / 'delivery'
target.mkdir(exist_ok=True)
files = [p for p in (out / '313').rglob('*') if p.is_file() and not p.is_symlink()]
files += [out / p for p in ('run.json', 'artifact-verification.json', 'merged-pr.json',
    'audit_linux_artifacts.py', 'download_verify_linux.py', 'expected-linux-test-ids.json',
    'archive-changed-paths.json', 'audit.log', 'download-verify.log', 'package_delivery.py')]
records, selected = [], {}
for path in sorted(files):
    data = path.read_bytes()
    name = str(path.relative_to(out))
    include = len(data) <= 2 * 1024 * 1024
    records.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'in_bundle': include})
    if include:
        selected[name] = path
manifest = target / 'archive-linux-evidence-manifest.json'
manifest.write_text(json.dumps({'files': records, 'raw_root': str(out),
    'policy': 'All downloaded regular records hashed; >2MiB records retained intact locally and in GitHub artifact, omitted from compact Git bundle. Original CI stager separately omits reproducible unit fixtures and symlink aliases as its committed policy describes.'}, indent=2) + '\n')
selected[manifest.name] = manifest
bundle = target / 'archive-linux-qualification.tar.gz'
assert not bundle.exists()
with bundle.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as archive:
    for name, path in sorted(selected.items()):
        info = archive.gettarinfo(str(path), arcname=name)
        info.uid = info.gid = info.mtime = 0
        info.uname = info.gname = ''
        with path.open('rb') as incoming:
            archive.addfile(info, incoming)
with tarfile.open(bundle) as archive:
    assert len(archive.getmembers()) == len(selected)
    for member in archive.getmembers():
        assert hashlib.sha256(archive.extractfile(member).read()).digest() == hashlib.sha256(selected[member.name].read_bytes()).digest()
record = {'status': 'ACCEPTED_AND_MERGED', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'pr': json.loads((out / 'merged-pr.json').read_text()),
    'artifact_verification': json.loads((out / 'artifact-verification.json').read_text()),
    'audit': json.loads((out / '313/root-audit.json').read_text()),
    'bundle': {'file': bundle.name, 'bytes': bundle.stat().st_size,
        'sha256': hashlib.sha256(bundle.read_bytes()).hexdigest(), 'members': len(selected)},
    'manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest(),
    'omitted_large_records': [r for r in records if not r['in_bundle']]}
(target / 'archive-final-linux-acceptance.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'bundle': record['bundle'], 'omitted_large_count': len(record['omitted_large_records'])}, indent=2))
