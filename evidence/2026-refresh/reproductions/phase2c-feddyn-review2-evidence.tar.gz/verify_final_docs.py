"""Bounded, source-bound final documentation verification; no prose authoring."""
import ast
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys

HERE = Path(__file__).resolve().parent
DOCS = Path("/tmp/plato-refresh-worktrees/algorithm-docs-count-review").resolve()
C = Path("/tmp/plato-refresh-worktrees/feddyn-count-review").resolve()
HEAD = "c199ebe02831a47351a10026e64721f77c9dfe9b"
TREE = "98bb9b178c65d39618e057a5cc5079f7ac7fe62e"
CHEAD = "8b01bf47ca8bdf9232bffeb4e50f78d4f00c9e3b"
PRIOR = "69d7d8a7841589205283f13f0e07771fb1e325bd"
MERGE = "d4a000c9d4cfbd475936cf1efc275955de94c10d"
PAGE = "docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md"
README = "examples/customized_client_training/feddyn/README.md"
SCAFFOLD = "examples/customized_client_training/scaffold/README.md"
RECON = "evidence/2026-refresh/phase2c-algorithm-docs-count-reconciliation.json"

def git(args, root=DOCS):
    return subprocess.check_output(["zsh", "-lc", shlex.join(["git", *args])], cwd=root, text=True).strip()

def content(commit, path):
    return subprocess.check_output(["zsh", "-lc", shlex.join(["git", "show", commit + ":" + path])], cwd=DOCS)

def receipt(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

assert git(["rev-parse", "HEAD", "HEAD^{tree}"]).splitlines() == [HEAD, TREE]
assert git(["status", "--porcelain=v1", "--untracked-files=all"]) == ""
assert git(["rev-parse", "HEAD", "HEAD^{tree}"], C).splitlines() == [CHEAD, "1cb086b9db386128ba6a965c198e8c07400ab9be"]
assert git(["show", "-s", "--format=%P", MERGE]).split() == [PRIOR, CHEAD]
assert git(["show", "-s", "--format=%P", HEAD]) == MERGE
assert git(["diff", "--name-only", MERGE, HEAD]).splitlines() == sorted([PAGE, RECON, README])
nano = DOCS / "external/nanochat"
assert git(["rev-parse", "HEAD"], nano) == git(["ls-tree", "HEAD", "external/nanochat"]).split()[2] == "c75fe54aa7c1fa881701c246f9427bcbe4eee5a4"
assert git(["status", "--porcelain=v1", "--untracked-files=all"], nano) == ""

files = {}
for relative in git(["ls-tree", "-r", "--name-only", HEAD]).splitlines():
    p = DOCS / relative
    if p.is_file():
        files[relative] = receipt(p)
        assert content(HEAD, relative) == p.read_bytes(), relative
initial_bytecode = [receipt(p) for p in sorted(DOCS.rglob("*.pyc"))]
# Docs handoff was tracked-clean, not claimed cache-free; preserve existing ignored caches.
allowed_docs_vs_C = {PAGE, README, SCAFFOLD, RECON, "evidence/2026-refresh/phase2c-algorithm-docs-validation.json", "evidence/2026-refresh/phase2c-scaffold-docs-validation.json"}
assert set(git(["diff", "--name-only", CHEAD, HEAD]).splitlines()) == allowed_docs_vs_C
production_files = []
for relative in git(["ls-tree", "-r", "--name-only", CHEAD]).splitlines():
    if relative not in allowed_docs_vs_C:
        if (DOCS / relative).is_file():
            assert content(CHEAD, relative) == (DOCS / relative).read_bytes(), relative
            if (C / relative).is_file():
                assert (C / relative).read_bytes() == (DOCS / relative).read_bytes(), relative
            production_files.append(relative)
    # Gitlink identity must also match, regardless of initialized directories.
    assert git(["rev-parse", f"{CHEAD}:{relative}"]) == git(["rev-parse", f"HEAD:{relative}"]) if relative not in allowed_docs_vs_C else True

old_readme = content(PRIOR, README).decode()
new_readme = (DOCS / README).read_text()
expected_readme = old_readme.replace(
    "can commit. It requires ordinary PyTorch training with finite, dense float32\n",
    "can commit. Qualification covers CPU float32/float64 execution.\nThe implementation requires ordinary PyTorch training with finite, dense float32\n",
)
assert expected_readme != old_readme and new_readme == expected_readme
old_page = content(PRIOR, PAGE).decode()
new_page = (DOCS / PAGE).read_text()
expected_page = old_page.replace(
    "The supported boundary is synchronous participation with a fixed population,",
    "Qualification covers CPU float32/float64 execution.\nThe supported boundary is synchronous participation with a fixed population,",
)
assert expected_page != old_page and new_page == expected_page
assert new_readme.count("Qualification covers CPU float32/float64 execution.") == new_page.count("Qualification covers CPU float32/float64 execution.") == 1
assert content(PRIOR, SCAFFOLD) == (DOCS / SCAFFOLD).read_bytes()
# The exact two replacements establish all prior equations, primary links,
# SCAFFOLD prose and unrelated page sections are preserved.
overview = "plato/trainers/strategies/algorithms/__init__.py"
assert (DOCS / overview).read_bytes() == (C / overview).read_bytes()
old_overview = ast.parse(content("13e38dafce476286db7e673e7f21343d54416b56", overview))
new_overview = ast.parse((DOCS / overview).read_text())
assert "Compatibility subclass using Option II" in ast.get_docstring(new_overview)
old_overview.body = old_overview.body[1:]
new_overview.body = new_overview.body[1:]
assert ast.dump(old_overview, include_attributes=False) == ast.dump(new_overview, include_attributes=False)

recon = json.loads((DOCS / RECON).read_text())
assert recon["identities"]["source_commit"] == CHEAD
assert recon["identities"]["separate_dependency_merge"] == MERGE
for path, expected in recon["source_sha256"].items():
    assert receipt(DOCS / path)["sha256"] == expected, path
for path, expected in recon["prose_sha256"]["candidate"].items():
    assert receipt(DOCS / path)["sha256"] == expected, path
for path, expected in recon["prose_sha256"]["prior_69d"].items():
    assert hashlib.sha256(content(PRIOR, path)).hexdigest() == expected, path
for item in recon["inputs"]:
    p = Path(item["path"])
    if not p.is_absolute():
        p = DOCS / p
    assert receipt(p)["sha256"] == item["sha256"], p
for item in recon["historical_reports"]["preserved"]:
    assert receipt(DOCS / item["path"])["sha256"] == item["sha256"]
for item in recon["writer_checks"]["executed_commands"].values():
    assert hashlib.sha256(Path(item["log"]).read_bytes()).hexdigest() == item["sha256"]
for item in (recon["writer_checks"]["runner"]["script"], recon["writer_checks"]["runner"]["results"]):
    assert receipt(Path(item["path"]))["sha256"] == item["sha256"]
strict = recon["writer_checks"]["strict_mkdocs"]
assert strict["baseline_exit"] == strict["candidate_exit"] == 1 and len(strict["warnings"]) == 2
assert recon["writer_checks"]["executed_commands"]["mkdocs-baseline"]["exit_code"] == recon["writer_checks"]["executed_commands"]["mkdocs-candidate"]["exit_code"] == 1
# Retain actual strict logs, distinguish deferred known failure from a PASS.
strict_receipts = [receipt(Path(recon["writer_checks"]["executed_commands"][key]["log"])) for key in ("mkdocs-baseline", "mkdocs-candidate")]
diff = git(["diff", PRIOR, HEAD, "--", PAGE, README, SCAFFOLD])
(HERE / "final-public-docs.diff").write_text(diff + "\n")
subprocess.check_call(["zsh", "-lc", shlex.join(["git", "diff", "--check", PRIOR, HEAD])], cwd=DOCS)

result = {
    "status": "PASS_BOUNDED_FINAL_SOURCE_BOUND_PROSE",
    "candidate": {"path": str(DOCS), "commit": HEAD, "tree": TREE, "dependency_merge": MERGE, "prior_prose": PRIOR},
    "corrected_C": {"path": str(C), "commit": CHEAD, "tree": "1cb086b9db386128ba6a965c198e8c07400ab9be"},
    "source_matches_C": True, "preserved_tracked_C_paths": len(production_files),
    "production_tests_configs_manifests_and_gitlinks_identical": True,
    "two_exact_public_replacements_only": True,
    "scaffold_and_unrelated_prose_identical_to_69d": True,
    "DOC_L01": "CLOSED: explicit CPU float32/float64 qualification in both support paragraphs",
    "DOC_L02": "CLOSED: authorized OptionII compatibility overview change is docstring-only",
    "reconciliation": receipt(DOCS / RECON),
    "prose": {p: receipt(DOCS / p) for p in (PAGE, README, SCAFFOLD)},
    "source_receipts": {p: receipt(DOCS / p) for p in ("examples/customized_client_training/feddyn/feddyn_trainer.py", "examples/customized_client_training/feddyn/feddyn_server.py", "plato/trainers/strategies/algorithms/feddyn_strategy.py", overview)},
    "strict_mkdocs": {"status": "FAIL_DEFERRED_PHASE5", "baseline_exit": 1, "candidate_exit": 1, "warnings": strict["warnings"], "strict_pass_claimed": False, "raw": strict_receipts},
    "public_diff": receipt(HERE / "final-public-docs.diff"),
    "all_tracked_docs_file_receipts": files,
    "preexisting_ignored_bytecode_cache_receipts": initial_bytecode,
    "manual_source_bound_assessment": [
        "Counts remain tied to actual nonempty partition samplers. Parent realization, direct/spawn count binding and sidecar validation now support the unchanged claims without backing-data fallback.",
        "Complete versioned resume description matches nonzero-history/count coherence; text makes no claim of comprehensive missing-count detection for all-zero histories or a new participation ledger.",
        "Receive and aggregation guard descriptions match type-sensitive count-map validation and existing owned-state rollback; postcommit evaluation boundary and external callback side-effect exclusion remain accurate.",
        "Equations, selected/population denominators, plain-SGD constraints, full CPU RNG continuation and portable read-only legacy migration are preserved.",
        "Qualification says CPU float32/float64, separate from implemented dtype/optimizer validation. It neither claims GPU qualification nor blanket rejection of every GPU execution.",
    ],
    "training_suite_repeated_for_prose": False,
    "script": receipt(Path(__file__)), "environment": {"executable": sys.executable, "python": sys.version},
}
assert initial_bytecode == [receipt(p) for p in sorted(DOCS.rglob("*.pyc"))]
(HERE / "final-docs-verification.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k not in {"all_tracked_docs_file_receipts", "manual_source_bound_assessment", "strict_mkdocs", "source_receipts", "prose"}}))
