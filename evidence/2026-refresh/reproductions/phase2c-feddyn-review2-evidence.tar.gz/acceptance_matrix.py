"""Bounded independent FedDyn count-state red/green matrix; no codec repair.

Run each case in a fresh interpreter using matrix_runner.py. A baseline red
requires observed unsafe production acceptance after all harness controls pass.
Unexpected exceptions/assertions are HARNESS_ERROR and never a defect verdict.
"""
import asyncio
import copy
import hashlib
import importlib.metadata
import json
import multiprocessing as mp
import os
from pathlib import Path
import pickle
import sys
import traceback

import torch
from torch.utils.data import TensorDataset

from plato.callbacks.server import ServerCallback
from plato.serialization.safetensor import deserialize_tree, serialize_tree
from tests.integration.test_feddyn_round_flow import (
    QuadraticTrainer, client, configuration, dispatch, server,
)
from tests.integration.utils import configure_environment

SOURCE = Path(os.environ["REVIEW_SOURCE"]).resolve()


def need(condition, message):
    if not condition:
        raise AssertionError(message)


def exact(actual, expected):
    """Independent type-sensitive snapshot comparison, including dictionary keys."""
    if isinstance(expected, torch.Tensor):
        return isinstance(actual, torch.Tensor) and actual.shape == expected.shape and actual.dtype == expected.dtype and torch.equal(actual.cpu(), expected.cpu())
    if isinstance(expected, dict):
        return isinstance(actual, dict) and {(type(k), k) for k in actual} == {(type(k), k) for k in expected} and all(exact(actual[k], value) for k, value in expected.items())
    if isinstance(expected, (list, tuple)):
        return type(actual) is type(expected) and len(actual) == len(expected) and all(exact(a, b) for a, b in zip(actual, expected))
    if isinstance(expected, set):
        return type(actual) is set and {(type(v), v) for v in actual} == {(type(v), v) for v in expected}
    return type(actual) is type(expected) and actual == expected


def close(actual, expected):
    need(abs(actual - expected) <= 1e-12, f"Expected {expected!r} +/- 1e-12; observed {actual!r}")


def native(meta):
    for key in ("version", "round", "client_id", "num_samples", "completed_steps"):
        if key in meta:
            need(type(meta[key]) is int, f"Non-native int metadata: {key}: {type(meta[key])}")
    for key in ("run_id", "dispatch_token"):
        need(type(meta[key]) is str, f"Non-native string metadata: {key}")
    for key in ("base_alpha", "effective_alpha"):
        if key in meta:
            need(type(meta[key]) is float, f"Non-native float metadata: {key}")


def origins():
    result = {}
    for name, module in tuple(sys.modules.items()):
        if name == "plato" or name.startswith("plato.") or name.startswith("tests.integration.") or name in {"feddyn_client", "feddyn_trainer", "feddyn_server"}:
            path = getattr(module, "__file__", None)
            if path:
                path = Path(path).resolve()
                need(path.is_relative_to(SOURCE), f"Foreign source: {name}: {path}")
                result[name] = {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    return result


class FixedPartition(torch.utils.data.Sampler):
    """A deterministic 2-item partition of a distinct 9-item backing dataset."""
    def __init__(self, count=2):
        self.count = count
        self.iterations = 0
        self.length_reads = 0
    def __iter__(self):
        self.iterations += 1
        return iter(range(self.count))
    def __len__(self):
        self.length_reads += 1
        return self.count


class SidecarCountWorker(QuadraticTrainer):
    corrupt = False
    def train_process(self, config, trainset, sampler, **kwargs):
        super().train_process(config, trainset, sampler, **kwargs)
        path = Path(self._training_state_path(config["run_id"]))
        envelope = pickle.loads(path.read_bytes())
        need(envelope["state"]["num_samples"] == len(sampler) == 2, "Child must actually train the 2-item partition")
        need(envelope["state"]["completed_steps"] == 2, "Child must complete exactly 2 optimizer steps")
        close(envelope["state"]["endpoint"]["theta"].item(), 1.622)
        close(envelope["state"]["history"]["theta"].item(), -0.378)
        observation = {
            "pid": os.getpid(), "process": mp.current_process().name,
            "actual_partition": len(sampler), "backing_dataset": len(trainset),
            "completed_steps": 2, "endpoint": 1.622,
            "sidecar_before": 2, "sidecar_after": 3 if self.corrupt else 2,
            "origins": origins(), "source_head": os.environ["REVIEW_HEAD"],
            "source_tree": os.environ["REVIEW_TREE"], "python": sys.version,
        }
        (path.parent / f"worker-{os.getpid()}.json").write_text(json.dumps(observation, indent=2) + "\n")
        if self.corrupt:
            envelope["state"]["num_samples"] = 3
            path.write_bytes(pickle.dumps(envelope))


class Capture:
    calls = 0
    async def send_report_and_payload(self, context, report, payload):
        self.calls += 1
        self.report, self.payload = report, deserialize_tree(payload)
        native(self.payload[1])


def bind(c, assignment):
    response, payload = assignment
    c.client_id = c._context.client_id = response["id"]
    c.current_round = c._context.current_round = response["current_round"]
    c.configure()
    c.lifecycle_strategy.process_server_response(c._context, response)
    c.training_strategy.load_payload(c._context, deserialize_tree(serialize_tree(payload)))


def attempt(c, assignment, target, count, capture, backing=None):
    bind(c, assignment)
    data_count = count if backing is None else backing
    c._context.trainset = TensorDataset(torch.ones(data_count, 1).double(), torch.full((data_count, 1), target, dtype=torch.double))
    c._context.sampler = FixedPartition(count)
    wire = serialize_tree(assignment[1])
    native(deserialize_tree(wire)[1])
    asyncio.run(c.payload_strategy.handle_server_payload(c._context, wire, training=c.training_strategy, reporting=c.reporting_strategy, communication=capture))
    return c._context.sampler


def update(c, assignment, target, count):
    capture = Capture()
    attempt(c, assignment, target, count, capture)
    need(capture.calls == 1, "Valid update must send exactly once")
    need(capture.report.num_samples == capture.payload[1]["num_samples"] == count, "Valid realized/report/payload counts disagree")
    return capture


def owned_server(s):
    state = s._snapshot()
    state.update(
        current_round=s.current_round, context_round=s.context.current_round,
        dispatches=copy.deepcopy(s.dispatches), pending=copy.deepcopy(s._pending),
        pending_seal=copy.deepcopy(s._pending_seal), pending_resume=copy.deepcopy(s._pending_resume_rng),
        committed_snapshot=copy.deepcopy(s._committed_snapshot),
        selected=list(s.selected_clients), resumed=getattr(s, "resumed_session", None),
    )
    return state


def count_case(root, mode, corrupt):
    with configure_environment(configuration(mode, (2, 2), True), runtime_root=root):
        s, c = server(), client(1, SidecarCountWorker)
        assignment = dispatch(s, [1])[1]
        need(assignment[1][1]["expected_count_or_null"] == (None if mode == "uniform" else 2), "Wrong first-dispatch control")
        bind(c, assignment)
        strategy = c.trainer.model_update_strategy
        model_before = copy.deepcopy(c.trainer.model.state_dict())
        dispatch_before = copy.deepcopy(strategy.dispatch)
        server_before = owned_server(s)
        s.save_to_checkpoint()
        path = Path(s.checkpoint_bundle_path())
        canonical = path.read_bytes()
        c.trainer.corrupt = corrupt
        capture = Capture()
        try:
            sampler = attempt(c, assignment, 0.0, 2, capture, backing=9)
        except ValueError as exc:
            need(corrupt, "Uncorrupted worker was rejected")
            observations = list(root.rglob("worker-*.json"))
            need(len(observations) == 1 and json.loads(observations[0].read_text())["sidecar_after"] == 3, "Expected real corrupted child evidence")
            need(capture.calls == 0, "Rejected worker sent outbound report/payload")
            need(exact(c.trainer.model.state_dict(), model_before), "Rejected worker changed parent model")
            need(exact(strategy.dispatch, dispatch_before), "Rejected worker changed parent dispatch")
            need(strategy.result is None and not strategy.accepted, "Rejected worker remained outbound eligible")
            need(c.trainer.model.theta.grad is None, "Rejected worker leaked a gradient")
            need(exact(owned_server(s), server_before), "Rejected worker changed server owned state")
            need(path.read_bytes() == canonical, "Rejected worker changed canonical checkpoint")
            try:
                strategy.get_update_payload(c.trainer.context)
            except ValueError:
                pass
            else:
                raise AssertionError("Rejected worker exposes an outbound update")
            c.trainer.corrupt = False
            retry = update(c, assignment, 0.0, 2)
            s.updates = [retry]
            asyncio.run(s._process_reports())
            close(s.trainer.model.theta.item(), 1.433)
            need(s.observed_counts == {1: 2} and s.committed_round == 1, "Valid retry count/round mismatch")
            return {"status": "GREEN_REJECTION_AND_RETRY", "rejection": str(exc), "outbound_before_retry": 0, "retry_cloud": 1.433}
        need(capture.calls == 1, "Successful worker must send once")
        need(exact(s._rng_snapshot(), server_before["rng"]), "Parent count binding consumed CPU/selection RNG streams")
        need(sampler.iterations == 0, "Parent must not enumerate/resample partition")
        expected_count = 3 if corrupt else 2
        need(capture.report.num_samples == strategy.result["num_samples"] == capture.payload[1]["num_samples"] == expected_count, "Sidecar count observation mismatch")
        s.updates = [capture]
        asyncio.run(s._process_reports())
        close(s.trainer.model.theta.item(), 1.433)
        need(s.observed_counts == {1: expected_count} and s.committed_round == 1, "Expected observed count/cache advance")
        if corrupt:
            return {"status": "EXPECTED_OLD_RED", "failed_acceptance_assertions": ["corrupted current worker count must reject before outbound", "parent result/report/server count must independently bind actual partition 2"], "actual_partition": 2, "backing_dataset": 9, "accepted_count": expected_count, "outbound_calls": capture.calls, "server_counts": s.observed_counts, "committed_round": s.committed_round, "cloud": s.trainer.model.theta.item()}
        return {"status": "VALID_CONTROL_PASS", "actual_partition": 2, "backing_dataset": 9, "parent_sampler_enumerations": sampler.iterations, "parent_length_reads": sampler.length_reads, "cloud": 1.433}


def checkpoint_case(root):
    with configure_environment(configuration(), runtime_root=root):
        s = server()
        first = update(client(1), dispatch(s, [1])[1], 0.0, 2)
        s.updates = [first]
        asyncio.run(s._process_reports())
        s.save_to_checkpoint()
        path = Path(s.checkpoint_bundle_path())
        sparse = torch.load(path, weights_only=True)
        need(sparse["counts"] == {1: 2} and sparse["histories"][2]["theta"].item() == 0, "Sparse valid control must retain never-trained client")
        sparse_resumed = server()
        sparse_resumed._resume_from_checkpoint()
        need(sparse_resumed.observed_counts == {1: 2} and sparse_resumed.committed_round == 1, "Valid sparse bundle rejected/changed")
        second = update(client(2), dispatch(s, [2])[2], 4.0, 2)
        s.updates = [second]
        asyncio.run(s._process_reports())
        s.save_to_checkpoint()
        valid_bytes = path.read_bytes()
        bundle = torch.load(path, weights_only=True)
        need(bundle["committed_round"] == 2 and bundle["counts"] == {1: 2, 2: 2}, "Wrong round-2 checkpoint setup")
        close(bundle["histories"][1]["theta"].item(), -0.378)
        valid = server()
        before_rng = copy.deepcopy(valid._rng_snapshot())
        valid._resume_from_checkpoint()
        need(exact(valid._rng_snapshot(), before_rng), "Coherent load mutates live RNG before startup")
        third = update(client(1), dispatch(valid, [1])[1], 0.0, 2)
        valid.updates = [third]
        asyncio.run(valid._process_reports())
        close(valid.trainer.model.theta.item(), 1.47705273425)
        del bundle["counts"][1]
        torch.save(bundle, path)
        malformed_bytes = path.read_bytes()
        victims = [server(), server()]
        # Verify both fresh state and an already staged coherent pending resume.
        path.write_bytes(valid_bytes)
        victims[1]._resume_from_checkpoint()
        path.write_bytes(malformed_bytes)
        results = []
        for victim in victims:
            before = owned_server(victim)
            try:
                victim._resume_from_checkpoint()
            except ValueError as exc:
                need(exact(owned_server(victim), before), "Rejected checkpoint changed live or pending state/RNG")
                need(path.read_bytes() == malformed_bytes, "Rejected checkpoint changed file bytes")
                results.append({"rejected": True, "error": str(exc)})
            else:
                need(victim.observed_counts == {2: 2} and victim.committed_round == 2, "Unexpected malformed bundle acceptance shape")
                close(victim.histories[1]["theta"].item(), -0.378)
                results.append({"rejected": False, "pending_was_changed": not exact(owned_server(victim), before)})
        if all(r["rejected"] for r in results):
            path.write_bytes(valid_bytes)
            for victim in victims:
                victim._resume_from_checkpoint()
                retry = update(client(1), dispatch(victim, [1])[1], 0.0, 2)
                victim.updates = [retry]
                asyncio.run(victim._process_reports())
                close(victim.trainer.model.theta.item(), 1.47705273425)
            return {"status": "GREEN_REJECTION_AND_RETRY", "loads": results, "coherent_round2_and_sparse_round1_pass": True}
        need(not any(r["rejected"] for r in results), "Inconsistent checkpoint rejection across fresh/pending controls")
        victim = victims[0]
        assignment = dispatch(victim, [1])[1]
        need(assignment[1][1]["expected_count_or_null"] is None, "Missing count must actually unbind later dispatch in red baseline")
        changed = update(client(1), assignment, 0.0, 3)
        victim.updates = [changed]
        asyncio.run(victim._process_reports())
        need(victim.observed_counts[1] == 3 and victim.committed_round == 3, "Expected changed-partition acceptance evidence")
        return {"status": "EXPECTED_OLD_RED", "failed_acceptance_assertions": ["nonzero stored history requires its count", "rejected bundle preserves live and prior pending state"], "loads": results, "nonzero_history": -0.378, "changed_partition_accepted": 3, "coherent_round2_and_sparse_round1_pass": True, "valid_continuation_cloud": 1.47705273425}


class CountCallback(ServerCallback):
    def __init__(self, mutation):
        self.mutation = mutation
        self.calls = 0
        self.actual_change = None
    def on_weights_received(self, s, weights):
        self.calls += 1
        before = copy.deepcopy(s.observed_counts)
        need(before == {1: 1}, "Callback must mutate inactive client1 at count1")
        if self.mutation == "value_bool":
            s.observed_counts[1] = True
        elif self.mutation == "value_float":
            s.observed_counts[1] = 1.0
        elif self.mutation == "key_bool":
            value = s.observed_counts.pop(1)
            s.observed_counts[True] = value
        elif self.mutation == "key_float":
            value = s.observed_counts.pop(1)
            s.observed_counts[1.0] = value
        elif self.mutation == "equal_key_assignment_control":
            s.observed_counts[1.0] = 1
        elif self.mutation != "ordinary":
            raise AssertionError(self.mutation)
        self.actual_change = not exact(s.observed_counts, before)
        need(s.observed_counts == before, "Equivalent mutation must exercise Python equality hole")
        need(self.actual_change == (self.mutation not in {"ordinary", "equal_key_assignment_control"}), "Key assignment must actually alter stored dictionary state to count as adversarial case")


def callback_case(root, mutation):
    with configure_environment(configuration(), runtime_root=root):
        s = server()
        s.updates = [update(client(1), dispatch(s, [1])[1], 0.0, 1)]
        asyncio.run(s._process_reports())
        s.save_to_checkpoint()
        path = Path(s.checkpoint_bundle_path())
        canonical = path.read_bytes()
        second = update(client(2), dispatch(s, [2])[2], 4.0, 1)
        s.updates = [second]
        before = owned_server(s)
        callback = CountCallback(mutation)
        s.callback_handler.add_callback(callback)
        adversarial = mutation not in {"ordinary", "equal_key_assignment_control"}
        try:
            asyncio.run(s._process_reports())
        except ValueError as exc:
            need(adversarial and callback.calls == 1 and callback.actual_change, "Unexpected callback rejection or invalid harness mutation")
            need(exact(owned_server(s), before), "Callback rejection failed owned-state rollback")
            need(s._pending is None and s._pending_seal is None, "Callback rejection leaked pending staging")
            need(path.read_bytes() == canonical, "Callback rejection changed canonical bytes")
            # Only remove the reviewer callback; no rollback of its external call counter.
            s.callback_handler.callbacks.remove(callback)
            s.updates = [second]
            asyncio.run(s._process_reports())
            close(s.trainer.model.theta.item(), 1.9717445)
            need(s.observed_counts == {1: 1, 2: 1} and all(type(k) is int and type(v) is int for k, v in s.observed_counts.items()), "Callback valid retry count mismatch")
            s.save_to_checkpoint()
            return {"status": "GREEN_REJECTION_AND_RETRY", "rejection": str(exc), "mutation_altered_dictionary_types": True, "external_callback_calls_preserved": callback.calls, "retry_cloud": 1.9717445}
        need(callback.calls == 1 and s.committed_round == 2, "Receive callback did not run/commit")
        close(s.trainer.model.theta.item(), 1.9717445)
        if not adversarial:
            s.save_to_checkpoint()
            need(all(type(k) is int and type(v) is int for k, v in s.observed_counts.items()), "Valid callback must leave canonical integer state")
            return {"status": "VALID_CONTROL_PASS", "stored_types_unchanged": not callback.actual_change, "cloud": 1.9717445}
        need(callback.actual_change, "Adversarial equivalent assignment did not alter dictionary state")
        try:
            s.save_to_checkpoint()
        except ValueError as exc:
            error = str(exc)
        else:
            raise AssertionError("Expected baseline malformed typed count checkpoint failure")
        need(path.read_bytes() == canonical, "Failed postcommit save changed canonical checkpoint")
        return {"status": "EXPECTED_OLD_RED", "failed_acceptance_assertions": ["receive callback owned count type mutation must reject before commit", "rejection restores integer keys and values"], "mutation_altered_dictionary_types": True, "count_types": [{"key": repr(k), "key_type": type(k).__name__, "value": repr(v), "value_type": type(v).__name__} for k, v in s.observed_counts.items()], "committed_round": 2, "later_checkpoint_error": error, "previous_canonical_unchanged": True}


def main():
    torch.set_num_threads(1)
    case, destination = sys.argv[1], Path(sys.argv[2]).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    row = {"case": case, "python": sys.version, "executable": sys.executable, "source": str(SOURCE), "head": os.environ["REVIEW_HEAD"], "tree": os.environ["REVIEW_TREE"], "packages": {name: importlib.metadata.version(name) for name in ("torch", "numpy", "safetensors", "pytest", "ty", "ruff")}}
    try:
        if case.startswith("count-"):
            _, mode, kind = case.split("-")
            result = count_case(destination, mode, kind == "corrupt")
        elif case == "checkpoint-missing":
            result = checkpoint_case(destination)
        elif case.startswith("callback-"):
            result = callback_case(destination, case.removeprefix("callback-"))
        else:
            raise AssertionError(case)
        row.update(result)
    except BaseException as exc:
        row.update(status="HARNESS_ERROR", error=repr(exc), traceback=traceback.format_exc())
    row["origins"] = origins()
    row["no_active_children"] = not mp.active_children()
    if not row["no_active_children"]:
        row["status"] = "HARNESS_ERROR"
    (destination / "result.json").write_text(json.dumps(row, indent=2) + "\n")
    print(json.dumps({k: v for k, v in row.items() if k not in {"origins", "traceback"}}))
    if row["status"] == "HARNESS_ERROR":
        print(row.get("traceback", "Active children remain"), file=sys.stderr)
        raise SystemExit(2)

if __name__ == "__main__":
    # Use the importable scratch module for actual spawn, preserving its source.
    from acceptance_matrix import main as guarded_main
    guarded_main()
