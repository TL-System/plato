"""Render only the two changed FedDyn prose locations with project extensions."""
import hashlib
import importlib.metadata
import json
from html.parser import HTMLParser
from pathlib import Path
import shlex
import subprocess
import sys
import markdown

HERE = Path(__file__).resolve().parent
DOCS = Path("/tmp/plato-refresh-worktrees/algorithm-docs-count-review").resolve()
PRIOR = "69d7d8a7841589205283f13f0e07771fb1e325bd"
PAGE = "docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md"
README = "examples/customized_client_training/feddyn/README.md"
PHRASE = "Qualification covers CPU float32/float64 execution."

class Observe(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links, self.visible = [], []
    def handle_starttag(self, tag, attrs):
        if tag == "a":
            self.links.extend(v for k,v in attrs if k == "href")
    def handle_data(self, data):
        self.visible.append(data)

def receipt(path):
    b = path.read_bytes()
    return {"path": str(path), "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()}

def section(text):
    return text.split("### FedDyn", 1)[1].split("### MOON", 1)[0]

rows = []
for label, path in (("feddyn-readme", README), ("feddyn-public", PAGE)):
    prior = subprocess.check_output(["zsh", "-lc", shlex.join(["git", "show", PRIOR + ":" + path])], cwd=DOCS, text=True)
    current = (DOCS / path).read_text()
    if label == "feddyn-public":
        prior, current = section(prior), section(current)
    observed = []
    for phase, text in (("prior", prior), ("candidate", current)):
        html = markdown.markdown(text, extensions=["admonition", "pymdownx.details", "pymdownx.superfences", "pymdownx.arithmatex"], extension_configs={"pymdownx.arithmatex": {"generic": True}})
        output = HERE / f"final-{label}-{phase}.html"
        output.write_text(html + "\n")
        parser = Observe()
        parser.feed(html)
        visible = " ".join(parser.visible)
        assert PHRASE in visible if phase == "candidate" else PHRASE not in visible
        assert html.count("arithmatex") > 0
        assert "<code>" in html or '<code class=' in html
        observed.append({"phase": phase, "html": receipt(output), "math_count": html.count("arithmatex"), "links": parser.links, "CPU_qualification_rendered": phase == "candidate"})
    assert observed[0]["links"] == observed[1]["links"]
    assert observed[0]["math_count"] == observed[1]["math_count"]
    rows.append({"label": label, "results": observed, "primary_links_and_equation_render_counts_preserved": True})
result = {"status": "PASS", "source": "c199ebe02831a47351a10026e64721f77c9dfe9b", "rows": rows, "environment": {"executable": sys.executable, "python": sys.version, "markdown": importlib.metadata.version("Markdown"), "pymdown_extensions": importlib.metadata.version("pymdown-extensions")}, "script": receipt(Path(__file__)), "limits": "Local HTML/project math-admonition-code extension verification; no browser/CDN/KaTeX runtime validation or strict MkDocs PASS claimed."}
(HERE / "final-docs-rendering.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result))
