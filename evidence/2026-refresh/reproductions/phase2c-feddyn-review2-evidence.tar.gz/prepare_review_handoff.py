"""Compile preparation receipt only after immutable baseline controls finish."""
import hashlib
import json
from pathlib import Path

SCRATCH = Path(__file__).resolve().parent

def record(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

before = json.loads((SCRATCH / "inventory-before.json").read_text())
after = json.loads((SCRATCH / "inventory-after.json").read_text())
assert before == after
commands = {v: json.loads((SCRATCH / f"baseline-{v}/commands.json").read_text()) for v in ("313", "314")}
assert all(len(rows) == 11 and all(r["baseline_control_match"] for r in rows) for rows in commands.values())
cases, guards, workers = {}, {}, {}
for version, rows in commands.items():
    base = SCRATCH / f"baseline-{version}"
    cases[version] = [json.loads((base / r["case"] / "result.json").read_text()) for r in rows]
    assert all(c["no_active_children"] for c in cases[version])
    starts, imports = [], []
    for path in sorted((base / "origins").glob("*.jsonl")):
        events = [json.loads(line) for line in path.read_text().splitlines()]
        assert not any("ERROR" in event["event"] for event in events)
        initial = [event for event in events if event["event"] == "python_start"]
        assert len(initial) == 1
        starts.extend(initial)
        imports.extend(event for event in events if event["event"] == "import")
    assert all(s["head"] == before["head"] and s["tree"] == before["tree"] and Path(s["source"]).resolve() == Path(before["source"]) for s in starts)
    for event in imports:
        relative = str(Path(event["origin"]).relative_to(Path(before["source"])))
        assert before["source_files"][relative]["sha256"] == event["sha256"], relative
    guards[version] = {"interpreters": len(starts), "import_records": len(imports), "all_exact_source_bound": True, "normal_library_caches": True}
    workers[version] = []
    for path in sorted(base.rglob("worker-*.json")):
        w = json.loads(path.read_text())
        assert w["process"] != "MainProcess" and w["actual_partition"] == 2 and w["completed_steps"] == 2
        assert w["source_head"] == before["head"] and w["source_tree"] == before["tree"]
        for identity in w["origins"].values():
            relative = str(Path(identity["path"]).relative_to(Path(before["source"])))
            assert identity["sha256"] == before["source_files"][relative]["sha256"]
        workers[version].append(record(path))
    assert len(workers[version]) == 5
    log = (SCRATCH / f"ty-baseline-{version}.log").read_text()
    assert log.count("error[invalid-argument-type]") == 5 and "Found 5 diagnostics" in log
    assert (SCRATCH / f"ty-baseline-{version}.exit").read_text().strip() == "1"

plan = []
for item in before["preserved_criteria"]:
    entry = {"criterion": item["id"], "preserved_baseline_status": item["status"], "preserved_evidence": item, "candidate_review": "Reconcile preserved numerical/native-codec evidence with exact frozen diff; rerun only checks affected by count binding, checkpoint or callback correction."}
    if item["id"] in {"FD-A05", "FD-A10"}:
        entry["targeted_matrix"] = ["count-uniform-corrupt", "count-uniform-valid", "count-sample-corrupt", "count-sample-valid"]
    if item["id"] == "FD-A11":
        entry["targeted_matrix"] = ["callback-value_bool", "callback-value_float", "callback-key_bool", "callback-key_float", "callback-ordinary", "callback-equal_key_assignment_control"]
    if item["id"] == "FD-A12":
        entry["targeted_matrix"] = ["checkpoint-missing"]
        entry["candidate_runtime_selection"] = ["tests/integration/test_feddyn_entrypoint.py::test_actual_shipped_run_resume_matches_four_round_control_and_rng[uniform]", "tests/integration/test_feddyn_entrypoint.py::test_actual_shipped_run_resume_matches_four_round_control_and_rng[sample]"]
    if item["id"] == "FD-A13":
        entry["candidate_runtime_selection"] = ["tests/integration/test_feddyn_entrypoint.py::test_shipped_mnist_shaped_lenet_spawn_and_real_socket_cloud"]
    if item["id"] == "FD-A14":
        entry["candidate_review"] = "Explicit --python ty in both existing environments; scoped Ruff; Sized and existing Module validation without suppression; source-bound final prose. Only docstring OptionII compatibility label correction is authorized in algorithms/__init__.py."
    plan.append(entry)

matrix = []
for case in cases["313"]:
    matrix.append({"case": case["case"], "baseline_expected": case["status"], "corrected_expected": "VALID_CONTROL_PASS" if case["status"] == "VALID_CONTROL_PASS" else "GREEN_REJECTION_AND_RETRY", "failed_baseline_assertions": case.get("failed_acceptance_assertions", []), "baseline_raw": [record(SCRATCH / f"baseline-{v}" / case["case"] / "result.json") for v in commands]})

receipt = {
    "status": "READY", "scope": "PREPARATION_ONLY", "corrected_candidate_reviewed": False,
    "baseline_source": {"path": before["source"], "commit": before["head"], "tree": before["tree"], "nanochat_gitlink": before["nanochat_gitlink"]},
    "immutable_inputs": before["evidence"], "root_instructions": before["root_agents"],
    "preservation": {"all_1060_project_file_bytes_unchanged": True, "project_cache_files_before_and_after": 0, "all_426_prior_reviewer_artifacts_unchanged": True, "author_changing_worktree_not_read": True, "no_checkout_or_root_writes": True, "no_installs_commits_pushes_agents": True},
    "baseline_matrix": matrix, "baseline_cases_each_version": 11,
    "expected_old_red_each_version": 6, "green_rejection_and_retry_each_version": 1, "valid_controls_each_version": 4, "harness_errors": [],
    "pilot": {"cases": 4, "all_controls_expected": True, "note": "Pilot script and runner preserved; finalized matrix adds explicit parent CPU/selection RNG nonconsumption assertion."},
    "typecheck": {"commands": [f"zsh -lc 'PYTHONDONTWRITEBYTECODE=1 /tmp/plato-phase2c-{v}/bin/ty check --python /tmp/plato-phase2c-{v}/bin/python examples/customized_client_training/feddyn plato/trainers/strategies/algorithms/feddyn_strategy.py'" for v in commands], "cwd": before["source"], "diagnostics_each_version": 5, "exit_each_version": 1, "raw": [record(SCRATCH / f"ty-baseline-{v}.log") for v in commands]},
    "source_provenance": guards, "real_spawn_child_observations": workers,
    "criterion_reconciliation_plan": plan,
    "accepted_scaffold_shared_lifecycle": "Preserved accepted13e implementation and review4 identity; no reopening or duplicate optional cleanup correction.",
    "review_limits": "No corrected-code verdict or root report; no rerun of242-case/full suites. No new numerical design, generalized participation ledger, external callback side-effect transaction, GPU/inflight replay, convergence or optional-stack qualification.",
    "incidental_console_errors": [
        {"purpose": "Read-only pilot result summary", "error": "Nested shell quoting stripped Python single quotes and caused NameError. Replaced with a literal heredoc; probes and source unaffected.", "production_defect_claim": False},
        {"purpose": "Create scratch receipt builder", "error": "Unescaped nested quotes caused zsh parse error before execution. Reissued with complete shell quoting; probes and source unaffected.", "production_defect_claim": False}
    ],
    "receipts": [record(SCRATCH / name) for name in ("inventory-before.json", "inventory-after.json", "acceptance_matrix.py", "acceptance_matrix.pilot.py", "matrix_runner.py", "matrix_runner.baseline-v1.py", "matrix_runner.pilot.py", "preparation_inventory.py", "source_guard/sitecustomize.py", "prepare_review_handoff.py", "baseline-run-313.log", "baseline-run-314.log", "pilot-run.log")],
    "command_manifests": [record(SCRATCH / f"baseline-{v}/commands.json") for v in commands],
}
(SCRATCH / "preparation-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
(SCRATCH / "acceptance-matrix.json").write_text(json.dumps(matrix, indent=2) + "\n")
print(json.dumps({"status": "READY", "matrix_cases_each_version": 11, "expected_old_red_each_version": 6, "valid_controls_each_version": 4, "green_rejection_and_retry_each_version": 1, "source_guards": guards, "receipt": record(SCRATCH / "preparation-receipt.json")}))
