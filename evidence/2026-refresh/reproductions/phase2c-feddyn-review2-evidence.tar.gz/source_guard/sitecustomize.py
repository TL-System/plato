"""Reviewer-owned parent/child source guard, with normal library caches."""
import atexit
import hashlib
import importlib.machinery
import json
import os
from pathlib import Path
import subprocess
import sys

SOURCE = Path(os.environ["REVIEW_SOURCE"]).resolve()
LOGS = Path(os.environ["REVIEW_ORIGINS"]).resolve()
LOGS.mkdir(parents=True, exist_ok=True)

def record(event, **values):
    with (LOGS / f"{os.getpid()}.jsonl").open("a") as stream:
        stream.write(json.dumps({"event": event, "pid": os.getpid(), **values}) + "\n")

def owned(name):
    return name == "plato" or name.startswith("plato.") or name == "tests" or name.startswith("tests.") or name == "nanochat" or name.startswith("nanochat.") or name in {"feddyn", "feddyn_client", "feddyn_server", "feddyn_trainer"}

def checked(name, origin):
    path = Path(origin).resolve()
    if not path.is_relative_to(SOURCE):
        record("FOREIGN_SOURCE_ERROR", module=name, origin=str(path))
        raise AssertionError((name, origin, str(SOURCE)))
    record("import", module=name, origin=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest())

class SourceGuard:
    def find_spec(self, fullname, path=None, target=None):
        if owned(fullname):
            spec = importlib.machinery.PathFinder.find_spec(fullname, path, target)
            if spec is not None and spec.origin not in (None, "built-in", "frozen"):
                checked(fullname, spec.origin)
            return spec
        return None

identity = subprocess.check_output(["zsh", "-lc", "git rev-parse HEAD HEAD^{tree}"], cwd=SOURCE, text=True).splitlines()
if identity != [os.environ["REVIEW_HEAD"], os.environ["REVIEW_TREE"]]:
    record("IDENTITY_ERROR", identity=identity)
    os._exit(97)
assert os.environ.get("PYTHONDONTWRITEBYTECODE") == "1"
assert "PYTHONPYCACHEPREFIX" not in os.environ
sys.meta_path.insert(0, SourceGuard())
record("python_start", source=str(SOURCE), head=identity[0], tree=identity[1], executable=sys.executable, python=sys.version, argv=sys.argv, cwd=str(Path.cwd().resolve()), pythonpath=os.environ.get("PYTHONPATH"))

@atexit.register
def finish():
    for name, module in tuple(sys.modules.items()):
        origin = getattr(module, "__file__", None)
        if owned(name) and origin:
            checked(name, origin)
    record("python_exit")
