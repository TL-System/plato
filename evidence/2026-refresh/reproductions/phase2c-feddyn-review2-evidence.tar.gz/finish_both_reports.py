"""Finalize the two authorized reports after bounded docs verification."""
import datetime
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path("/Users/bli/Playground/plato/evidence/2026-refresh")
CODE = ROOT / "phase2c-feddyn-code-review-2.json"
DOCS_REPORT = ROOT / "phase2c-algorithm-docs-final-review.json"
DOCS = Path("/tmp/plato-refresh-worktrees/algorithm-docs-count-review").resolve()

def receipt(p):
    data = p.read_bytes()
    return {"path": str(p), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

verified = json.loads((HERE / "final-docs-verification.json").read_text())
rendering = json.loads((HERE / "final-docs-rendering.json").read_text())
code = json.loads(CODE.read_text())
assert verified["status"] == "PASS_BOUNDED_FINAL_SOURCE_BOUND_PROSE" and rendering["status"] == "PASS"
assert verified["corrected_C"]["commit"] == code["reviewed_candidate"]["commit"]
assert code["verdict"] == "PASS_BOUNDED_CORRECTED_IMPLEMENTATION"
assert code["finding_counts"] == {"critical": 0, "high": 0, "medium": 0, "low": 0}
original_archive = HERE / "phase2c-feddyn-code-review-2.implementation-only.json"
assert not original_archive.exists()
original_archive.write_bytes(CODE.read_bytes())
receipt_archive = HERE / "final-review-receipt.implementation-only.json"
receipt_archive.write_bytes((HERE / "final-review-receipt.json").read_bytes())

docs_report = {
    "schema_version": 1,
    "written_at_utc": datetime.datetime.now(datetime.UTC).isoformat(),
    "role": "Fresh independent Sol xhigh reviewer2; source-bound bounded final writing verification, no prose authoring or nested agents",
    "verdict": "PASS_BOUNDED_FINAL_SOURCE_BOUND_DOCUMENTATION",
    "summary": "Exact c199 prose is bound to corrected C 8b01. Production/tests/configs match C, the public delta consists of two explicit CPU qualification additions, and unchanged count/transaction/resume/migration claims remain accurate. DOC-L01 and DOC-L02 are closed. Strict MkDocs remains a deferred failure on two unchanged Nanochat links, not a PASS.",
    "candidate": verified["candidate"],
    "corrected_C": verified["corrected_C"],
    "material_findings": [], "low_findings": [],
    "finding_counts": {"critical": 0, "high": 0, "medium": 0, "low": 0},
    "prior_writing_review": receipt(ROOT / "phase2c-algorithm-docs-review.json"),
    "prior_writing_source": {"docs_commit": "69d7d8a7841589205283f13f0e07771fb1e325bd", "source_commit": "13e38dafce476286db7e673e7f21343d54416b56", "interpretation": "Preserved prior bounded PASS; final source-binding is independently checked here, not silently inherited."},
    "writer_reconciliation": verified["reconciliation"],
    "source_preservation": {
        "all_production_tests_configs_manifests_and_gitlinks_match_C": True,
        "preserved_tracked_C_paths": verified["preserved_tracked_C_paths"],
        "exact_source_receipts": verified["source_receipts"],
        "prior_scaffold_prose_and_unrelated_sections_unchanged": True,
        "no_production_tests_configs_or_doc_source_edits_by_reviewer": True,
        "git_heads_trees_and_clean_tracked_bytes_verified": True,
        "preexisting_ignored_bytecode_files_preserved": len(verified["preexisting_ignored_bytecode_cache_receipts"]),
        "cache_note": "Docs handoff was tracked-clean with preexisting ignored caches. All received cache hashes remain unchanged. No project module imports or new bytecode were needed for this prose check; C review source remains cache-free.",
    },
    "public_delta": {
        "files": verified["prose"], "diff": verified["public_diff"],
        "exact_replacement_check": "README adds 'Qualification covers CPU float32/float64 execution.' and separates the following implementation-requirement sentence. The public guide adds the same CPU qualification before its existing support paragraph. No other public bytes change from 69d.",
        "unchanged": "Both SCAFFOLD locations, all FedDyn equations, coefficients/denominators, primary links, commands, configured defaults, callback commit boundaries, complete CPU RNG continuation and read-only legacy migration remain unchanged.",
    },
    "manual_reconciliation": [
        {
            "claim": "Actual partition counts and parent worker acceptance",
            "prose": ["examples/customized_client_training/feddyn/README.md:71", "docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md:165"],
            "source": ["examples/customized_client_training/feddyn/feddyn_trainer.py:35", "examples/customized_client_training/feddyn/feddyn_trainer.py:234", "plato/trainers/strategies/algorithms/feddyn_strategy.py:629"],
            "result": "PASS",
            "assessment": "Unchanged count wording is now independently supported by one parent get(), same actual Sized partition passed to the worker, sidecar/current-count comparison, no backing dataset fallback and unchanged sample-mode fixed-count contract.",
        },
        {
            "claim": "Checkpoint consistency and limits",
            "prose": ["examples/customized_client_training/feddyn/README.md:134", "docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md:190"],
            "source": ["examples/customized_client_training/feddyn/feddyn_server.py:617", "examples/customized_client_training/feddyn/feddyn_server.py:631", "examples/customized_client_training/feddyn/feddyn_server.py:653"],
            "result": "PASS",
            "assessment": "Complete version1 saved bundle and compatible partition/settings descriptions match nonzero-history/count coherence before live/pending installation. No claim of comprehensive deleted-count detection when histories are all zero, new ledger or inflight/GPU RNG replay.",
        },
        {
            "claim": "Receive/aggregation callback boundary",
            "prose": ["examples/customized_client_training/feddyn/README.md:116", "docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md:181"],
            "source": ["examples/customized_client_training/feddyn/feddyn_server.py:359", "examples/customized_client_training/feddyn/feddyn_server.py:440"],
            "result": "PASS",
            "assessment": "Type-sensitive count-map keys/values now validate at both hooks. Existing owned model/history/count/token rollback and postcommit evaluation semantics are preserved; external callback side effects remain excluded.",
        },
        {
            "claim": "CPU qualification and implemented constraints",
            "prose": ["examples/customized_client_training/feddyn/README.md:94", "docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md:172"],
            "result": "PASS",
            "assessment": "Explicit CPU float32/float64 qualification matches independent scalar float64 and real MNIST-shaped LeNet float32 execution. It is distinct from device-neutral dtype/SGD checks; no all-GPU rejection, GPU qualification or new support feature is stated.",
        },
        {
            "claim": "Accepted algebra, portable migration and CPU RNG handoff",
            "result": "PASS_PRESERVED_AND_SOURCE_BOUND",
            "assessment": "Numerical/config/transport/RNG definitions and prose are preserved. Exact C independent code review supplies the changed-boundary, real socket/run/--resume, scalar oracle and read-only legacy evidence; no training suite rerun for this prose delta.",
        },
    ],
    "low_dispositions": [
        {"id": "DOC-L01", "disposition": "CLOSED", "reason": "Explicit CPU float32/float64 qualification appears and renders in both support paragraphs."},
        {"id": "DOC-L02", "disposition": "CLOSED", "reason": "Authorized C dependency carries OptionII compatibility subclass wording in algorithms/__init__.py; executable AST/imports remain identical."},
    ],
    "validation": {
        "source_and_scope": receipt(HERE / "final-docs-verification.json"),
        "source_and_scope_script": receipt(HERE / "verify_final_docs.py"),
        "source_and_scope_log": receipt(HERE / "final-docs-verification.log"),
        "source_and_scope_command": "zsh -lc 'PYTHONDONTWRITEBYTECODE=1 /tmp/plato-phase2c-313/bin/python verify_final_docs.py'",
        "source_and_scope_cwd": str(HERE),
        "rendering": rendering,
        "render_script": receipt(HERE / "render_final_docs.py"),
        "render_log": receipt(HERE / "final-docs-rendering.log"),
        "render_command": "zsh -lc 'PYTHONDONTWRITEBYTECODE=1 /tmp/plato-phase2c-scaffold-docs/final-13e/venv/bin/python render_final_docs.py'",
        "strict_mkdocs": verified["strict_mkdocs"],
        "strict_build_pass_claimed": False,
        "strict_build_new_execution_by_reviewer": False,
        "strict_interpretation": "Writer differential strict builds both exited 1 with the same two Nanochat relative-link warnings. Raw hashes verified; exact unchanged links/config/other prose establish no new scope regression. Deferred Phase 5 failure remains visible.",
        "no_full_training_suite_rerun_for_prose": True,
    },
    "code_evidence": {
        "implementation_verdict_archive": receipt(original_archive),
        "corrected_source_commit": code["reviewed_candidate"]["commit"],
        "corrected_source_tree": code["reviewed_candidate"]["tree"],
        "unique_pytest_cases_each_version": 63,
        "independent_script_cases_each_version": 21,
        "actual_socket_process_groups_each_version": 7,
        "relationship": "Same production/tests/config bytes in docs candidate; code verdict remains in assigned phase2c-feddyn-code-review-2.json.",
    },
    "harness_limit": {
        "initial_docs_audit": "An initial scratch assertion assumed cache-free docs source and failed on preexisting ignored bytecode. Docs handoff promised tracked-clean source; revised audit preserves and verifies all existing cache bytes. No production/prose defect inferred.",
        "original_script": receipt(HERE / "verify_final_docs.v1.py"),
        "original_log": receipt(HERE / "final-docs-verification.v1.log"),
    },
    "limits": [
        "Bounded final prose PASS and corrected C CPU implementation verification; no whole C/Phase2, root merged profiles, hosted Linux CI or production acceptance.",
        "Strict MkDocs remains FAIL_DEFERRED_PHASE5 for two unchanged Nanochat links.",
        "Local generated HTML/math/admonition/code/link verification only; no live browser/CDN/KaTeX runtime validation.",
        "No GPU/inflight replay/convergence/MNIST accuracy/optional-stack/new provisioning claim.",
        "No comprehensive missing-count detection for histories that are all zero, and no arbitrary external callback transaction.",
    ],
    "workflow": {"nested_agents": False, "source_prose_authoring": False, "commits_pushes_installs": False, "writes": "Own reviewer2 scratch and the two explicitly assigned root review reports only."},
}
assert not DOCS_REPORT.exists(), "Preserve any prior final writing report before amendment"
docs_text = json.dumps(docs_report, indent=2) + "\n"
(HERE / DOCS_REPORT.name).write_text(docs_text)
DOCS_REPORT.write_text(docs_text)

code["written_at_utc"] = datetime.datetime.now(datetime.UTC).isoformat()
code["summary"] = "Exact 8b resolves all three medium count-state findings and low explicit typing finding. Accepted equations/native transport/CPU replay/legacy migration pass preserved and affected independent checks on 3.13/3.14. Final c199 source-bound documentation is now independently verified; root integration/whole-phase gates remain separate."
for criterion in code["criterion_mapping"]:
    if criterion["id"] == "FD-A14":
        criterion["status"] = "PASS_BOUNDED_SOURCE_TYPING_AND_FINAL_SOURCE_BOUND_PROSE"
        criterion["source_preservation_and_limits"] = "Explicit --python ty passes both environments without suppression; scoped Ruff passes; authorized overview change is docstring-only. Final c199 documentation matches C 8b production/tests/configs and has separate bounded source-bound PASS. Deferred strict MkDocs failure is not a PASS."
        criterion["final_writing_review"] = receipt(DOCS_REPORT)
code["writing_gate"] = {
    "prior_bounded_writing_review": code["writing_gate"]["prior_bounded_writing_review"],
    "prior_verdict": "PASS", "final_reconciled_candidate_supplied": True,
    "final_candidate": verified["candidate"], "corrected_C": verified["corrected_C"],
    "status": "PASS_BOUNDED_FINAL_SOURCE_BOUND_DOCUMENTATION",
    "final_review": receipt(DOCS_REPORT), "DOC_L01": "CLOSED", "DOC_L02": "CLOSED",
    "strict_mkdocs": "FAIL_DEFERRED_PHASE5; not claimed PASS",
}
code["limits_and_pending"] = [
    "Bounded corrected CPU implementation and final source-bound prose PASS only; root integration, merged profiles, hosted CI and whole phase/production acceptance remain separate.",
    *[item for item in code["limits_and_pending"] if not item.startswith("Bounded corrected CPU implementation PASS only;")],
]
code["workflow"]["writes"] = "Own reviewer2 scratch and explicitly assigned phase2c-feddyn-code-review-2.json plus phase2c-algorithm-docs-final-review.json; incidental generated tool caches preserved in scratch without deletion."
code["prior_implementation_only_report_preserved"] = receipt(original_archive)
code["final_doc_verification_receipts"] = [receipt(HERE / name) for name in ("verify_final_docs.py", "render_final_docs.py", "final-docs-verification.json", "final-docs-rendering.json", "final-public-docs.diff")]
code_text = json.dumps(code, indent=2) + "\n"
(HERE / "phase2c-feddyn-code-review-2.final.json").write_text(code_text)
CODE.write_text(code_text)
assert code["verdict"] == "PASS_BOUNDED_CORRECTED_IMPLEMENTATION"
assert all("PASS" in item["status"] for item in code["criterion_mapping"])
final = {
    "code_verdict": code["verdict"], "writing_verdict": docs_report["verdict"],
    "code_source": {"commit": code["reviewed_candidate"]["commit"], "tree": code["reviewed_candidate"]["tree"]},
    "docs_source": verified["candidate"], "code_report": receipt(CODE), "docs_report": receipt(DOCS_REPORT),
    "FD_A14": "PASS_BOUNDED_SOURCE_TYPING_AND_FINAL_SOURCE_BOUND_PROSE",
    "DOC_L01": "CLOSED", "DOC_L02": "CLOSED", "strict_mkdocs": "FAIL_DEFERRED_PHASE5",
    "material_findings": 0, "unique_pytest_each_version": 63, "independent_cases_each_version": 21,
}
(HERE / "final-review-receipt.json").write_text(json.dumps(final, indent=2) + "\n")
print(json.dumps(final))
