"""Run a coherent affected selection, retained deadlines and explicit source checks."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import shlex
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
SOURCE = Path("/tmp/plato-refresh-worktrees/feddyn-count-review").resolve()
version, kind = sys.argv[1:3]
exe = f"/tmp/plato-phase2c-{version}/bin/python"
run = HERE / f"{kind}-{version}"
run.mkdir(exist_ok=True)
env = dict(os.environ)
env.pop("PYTHONPYCACHEPREFIX", None)
env.update(PYTHONDONTWRITEBYTECODE="1", PYTHONPATH=os.pathsep.join([str(HERE / "source_guard"), str(HERE), str(SOURCE)]), TMPDIR=str(HERE / "tmp"), MPLCONFIGDIR=str(HERE / "mpl"), OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1", VECLIB_MAXIMUM_THREADS="1", NUMEXPR_NUM_THREADS="1", REVIEW_SOURCE=str(SOURCE), REVIEW_HEAD="8b01bf47ca8bdf9232bffeb4e50f78d4f00c9e3b", REVIEW_TREE="1cb086b9db386128ba6a965c198e8c07400ab9be", REVIEW_ORIGINS=str(run / "origins"), REVIEW_PYTEST_NODES=str(run / "pytest-nodes.json"))
tests = [
    "tests/integration/test_feddyn_count_boundaries.py",
    "tests/integration/test_feddyn_round_flow.py::test_consecutive_same_client_uses_current_cloud_and_dispatched_history",
    "tests/integration/test_feddyn_round_flow.py::test_three_round_actual_partial_participation",
    "tests/integration/test_feddyn_round_flow.py::test_multiple_participants_preserve_inactive_history_population_mean",
    "tests/integration/test_feddyn_round_flow.py::test_actual_full_participation_first_cloud",
    "tests/integration/test_feddyn_round_flow.py::test_actual_spawn_reused_client_matches_partial_oracle",
    "tests/integration/test_feddyn_round_flow.py::test_callback_and_partial_load_boundary[postcommit]",
    "tests/integration/test_feddyn_round_flow.py::test_accumulated_tail_and_skips_count_only_real_updates",
    "tests/integration/test_feddyn_round_flow.py::test_empty_or_all_skipped_attempt_refuses_outbound_and_valid_retry",
    "tests/integration/test_feddyn_round_flow.py::test_actual_local_schema_buffer_and_count_mutation_rolls_back[count]",
    "tests/integration/test_feddyn_round_flow.py::test_realized_partition_count_uses_sampler_not_global_backing_data",
    "tests/integration/test_feddyn_round_flow.py::test_optimizer_parameter_identity_and_static_full_state[reverse]",
    "tests/integration/test_feddyn_round_flow.py::test_complete_bundle_round_two_to_three_matches_rational_reference",
    "tests/trainers/test_feddyn_strategy.py::test_legacy_actual_writer_weight_bias_and_corruption_are_inspection_only",
    "tests/trainers/test_feddyn_strategy.py::test_loss_matches_independent_scalar_equation",
    "tests/trainers/test_feddyn_strategy.py::test_zero_alpha_is_exact_task_loss",
    "tests/integration/test_feddyn_entrypoint.py",
]
if kind == "affected":
    args = [exe, "-B", "-m", "pytest", "-p", "reviewer_pytest_provenance", *tests, "-q", "--basetemp", str(run / "runtime"), "--junitxml", str(run / "junit.xml")]
elif kind == "ty":
    args = [f"/tmp/plato-phase2c-{version}/bin/ty", "check", "--python", exe, "examples/customized_client_training/feddyn", "plato/trainers/strategies/algorithms/feddyn_strategy.py"]
elif kind == "ruff":
    args = [f"/tmp/plato-phase2c-{version}/bin/ruff", "check", "--select", "I", "examples/customized_client_training/feddyn", "plato/trainers/strategies/algorithms/feddyn_strategy.py", "plato/trainers/strategies/algorithms/__init__.py", "tests/integration/test_feddyn_count_boundaries.py", "tests/integration/feddyn_count_worker.py"]
else:
    raise ValueError(kind)
started = time.monotonic()
with (run / "stdout.log").open("w") as out, (run / "stderr.log").open("w") as err:
    completed = subprocess.run(["zsh", "-lc", shlex.join(args)], cwd=SOURCE, env=env, stdout=out, stderr=err)
def receipt(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
result = {"version": version, "kind": kind, "args": args, "command": ["zsh", "-lc", shlex.join(args)], "cwd": str(SOURCE), "environment": {key: env[key] for key in env if key.startswith("REVIEW_") or key in {"PYTHONDONTWRITEBYTECODE", "PYTHONPATH", "TMPDIR", "MPLCONFIGDIR", "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"}}, "exit_code": completed.returncode, "seconds": round(time.monotonic() - started, 3), "raw": [receipt(run / "stdout.log"), receipt(run / "stderr.log")], "runner": receipt(Path(__file__))}
if (run / "junit.xml").is_file():
    result["raw"].append(receipt(run / "junit.xml"))
if (run / "pytest-nodes.json").is_file():
    result["raw"].append(receipt(run / "pytest-nodes.json"))
(run / "command.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result), flush=True)
raise SystemExit(completed.returncode)
