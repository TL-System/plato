"""Deadline-bound all-zsh runner retaining commands, raw logs and classifications."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time

SCRATCH = Path(__file__).resolve().parent
CASES = ["count-uniform-corrupt", "count-uniform-valid", "count-sample-corrupt", "count-sample-valid", "checkpoint-missing", "callback-value_bool", "callback-value_float", "callback-key_bool", "callback-key_float", "callback-ordinary", "callback-equal_key_assignment_control"]
EXPECTED = {case: ("EXPECTED_OLD_RED" if case in {"count-uniform-corrupt", "checkpoint-missing"} or case.startswith("callback-") and case not in {"callback-ordinary", "callback-equal_key_assignment_control"} else "GREEN_REJECTION_AND_RETRY" if case == "count-sample-corrupt" else "VALID_CONTROL_PASS") for case in CASES}

def hash_file(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

parser = argparse.ArgumentParser()
parser.add_argument("version", choices=["313", "314"])
parser.add_argument("--cases", nargs="+", default=CASES)
parser.add_argument("--label", default="baseline")
args = parser.parse_args()
run_root = SCRATCH / (args.label + "-" + args.version)
run_root.mkdir(exist_ok=True)
env = dict(os.environ)
env.pop("PYTHONPYCACHEPREFIX", None)
env.update(PYTHONDONTWRITEBYTECODE="1", PYTHONPATH=os.pathsep.join([str(SCRATCH / "source_guard"), str(SCRATCH), "/tmp/plato-refresh-worktrees/training-final-review"]), TMPDIR=str(SCRATCH / "tmp"), MPLCONFIGDIR=str(SCRATCH / "mpl"), OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", REVIEW_SOURCE="/tmp/plato-refresh-worktrees/training-final-review", REVIEW_HEAD="13e38dafce476286db7e673e7f21343d54416b56", REVIEW_TREE="9fe8cfb039d0d97fc5b2c95a459de4c73c6d1b51", REVIEW_ORIGINS=str(run_root / "origins"))
rows = []
for case in args.cases:
    destination = run_root / case
    destination.mkdir(exist_ok=True)
    command = f"/tmp/plato-phase2c-{args.version}/bin/python"
    invocation = ["zsh", "-lc", shlex.join([command, str(SCRATCH / "acceptance_matrix.py"), case, str(destination)])]
    started = time.monotonic()
    stdout, stderr = destination / "stdout.log", destination / "stderr.log"
    with stdout.open("w") as out, stderr.open("w") as err:
        try:
            completed = subprocess.run(invocation, cwd=env["REVIEW_SOURCE"], env=env, stdout=out, stderr=err, timeout=60)
            code = completed.returncode
        except subprocess.TimeoutExpired:
            code = "TIMEOUT_60S"
    result_path = destination / "result.json"
    result = json.loads(result_path.read_text()) if result_path.is_file() else {"status": "HARNESS_ERROR_NO_RESULT"}
    row = {"case": case, "command_argv": invocation, "cwd": env["REVIEW_SOURCE"], "environment": {k: env[k] for k in ("PYTHONDONTWRITEBYTECODE", "PYTHONPATH", "TMPDIR", "MPLCONFIGDIR", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "REVIEW_SOURCE", "REVIEW_HEAD", "REVIEW_TREE", "REVIEW_ORIGINS")}, "exit_code": code, "deadline_seconds": 60, "elapsed_seconds": round(time.monotonic() - started, 3), "status": result["status"], "expected_baseline_status": EXPECTED[case], "baseline_control_match": code == 0 and result["status"] == EXPECTED[case], "raw": [hash_file(stdout), hash_file(stderr)] + ([hash_file(result_path)] if result_path.exists() else []), "script": hash_file(SCRATCH / "acceptance_matrix.py")}
    rows.append(row)
    (run_root / "commands.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps({k: row[k] for k in ("case", "exit_code", "elapsed_seconds", "status", "baseline_control_match")}), flush=True)
print(json.dumps({"cases": len(rows), "all_expected_baseline_controls_match": all(r["baseline_control_match"] for r in rows)}), flush=True)
sys.exit(0 if all(r["baseline_control_match"] for r in rows) else 2)
