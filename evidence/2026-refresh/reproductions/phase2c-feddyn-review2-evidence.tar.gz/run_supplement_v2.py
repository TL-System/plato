"""Source-bound runner for independent checks and their baseline controls."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time

here = Path(__file__).resolve().parent
version, phase, kind = sys.argv[1:4]
if phase == "corrected":
    source, head, tree = "/tmp/plato-refresh-worktrees/feddyn-count-review", "8b01bf47ca8bdf9232bffeb4e50f78d4f00c9e3b", "1cb086b9db386128ba6a965c198e8c07400ab9be"
else:
    source, head, tree = "/tmp/plato-refresh-worktrees/training-final-review", "13e38dafce476286db7e673e7f21343d54416b56", "9fe8cfb039d0d97fc5b2c95a459de4c73c6d1b51"
destination = here / f"supplement-v2-{phase}-{kind}-{version}"
destination.mkdir(exist_ok=True)
env = dict(os.environ)
env.pop("PYTHONPYCACHEPREFIX", None)
env.update(PYTHONDONTWRITEBYTECODE="1", PYTHONPATH=os.pathsep.join([str(here / "source_guard"), str(here), source]), TMPDIR=str(here / "tmp"), MPLCONFIGDIR=str(here / "mpl"), OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", REVIEW_SOURCE=source, REVIEW_HEAD=head, REVIEW_TREE=tree, REVIEW_ORIGINS=str(destination / "origins"))
args = [f"/tmp/plato-phase2c-{version}/bin/python", str(here / "supplemental_count_checks_v2.py"), str(destination / "runtime"), kind]
t = time.monotonic()
with (destination / "stdout.log").open("w") as out, (destination / "stderr.log").open("w") as err:
    result = subprocess.run(["zsh", "-lc", shlex.join(args)], env=env, cwd=source, stdout=out, stderr=err, timeout=60)
def receipt(p):
    b = p.read_bytes()
    return {"path": str(p), "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()}
raw = destination / "runtime/results.json"
check = json.loads(raw.read_text())
expected = "EXPECTED_OLD_RED" if phase == "baseline" else "GREEN_REJECTION_AND_RETRY" if kind == "callback" else "PASS"
valid = result.returncode == 0 and check["status"] == "PASS" and all(c["status"] == expected for c in check["checks"])
record = {"args": ["zsh", "-lc", shlex.join(args)], "cwd": source, "environment": {k: env[k] for k in ("PYTHONDONTWRITEBYTECODE", "PYTHONPATH", "TMPDIR", "REVIEW_SOURCE", "REVIEW_HEAD", "REVIEW_TREE", "REVIEW_ORIGINS")}, "exit_code": result.returncode, "seconds": round(time.monotonic() - t, 3), "expected_case_status": expected, "all_outcomes_expected": valid, "raw": [receipt(destination / "stdout.log"), receipt(destination / "stderr.log"), receipt(raw)], "script": receipt(here / "supplemental_count_checks_v2.py")}
(destination / "command.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"phase": phase, "kind": kind, "version": version, "expected": valid, "cases": len(check["checks"]), "exit": result.returncode}))
raise SystemExit(0 if valid else 2)
