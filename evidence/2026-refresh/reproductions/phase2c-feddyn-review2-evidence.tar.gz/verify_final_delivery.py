"""Read-only delivery audit for the two assigned reports and frozen sources."""
import hashlib
import json
import shlex
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
final = json.loads((HERE / 'final-review-receipt.json').read_text())
code = json.loads(Path(final['code_report']['path']).read_text())
docs = json.loads(Path(final['docs_report']['path']).read_text())

def verify(r):
    b=Path(r['path']).read_bytes()
    assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'],r['path']

def git(path,args):
    cmd='git -C '+shlex.quote(str(path))+' '+args
    return subprocess.check_output(['zsh','-lc',cmd],text=True).strip()

for r in (final['code_report'],final['docs_report']):
    verify(r)
assert Path(final['code_report']['path']).read_bytes()==(HERE/'phase2c-feddyn-code-review-2.final.json').read_bytes()
assert Path(final['docs_report']['path']).read_bytes()==(HERE/'phase2c-algorithm-docs-final-review.json').read_bytes()
verify(code['prior_implementation_only_report_preserved'])
assert code['prior_implementation_only_report_preserved']['sha256']=='57ca81ab1d4fed8d11015224e3a282da7073ab05fd99c2ab6b523cc38ca9a571'
assert code['verdict']=='PASS_BOUNDED_CORRECTED_IMPLEMENTATION'
assert docs['verdict']=='PASS_BOUNDED_FINAL_SOURCE_BOUND_DOCUMENTATION'
assert len(code['criterion_mapping'])==15 and all('PASS' in c['status'] for c in code['criterion_mapping'])
assert code['finding_counts']==docs['finding_counts']=={'critical':0,'high':0,'medium':0,'low':0}
assert not docs['validation']['strict_build_pass_claimed']
assert docs['validation']['strict_mkdocs']['status']=='FAIL_DEFERRED_PHASE5'
assert {c['id']:c['disposition'] for c in docs['low_dispositions']}=={'DOC-L01':'CLOSED','DOC-L02':'CLOSED'}

c_audit=json.loads((HERE/'candidate-audit-after.json').read_text())
d_audit=json.loads((HERE/'final-docs-verification.json').read_text())
for r in c_audit['candidate_files'].values():
    verify(r)
for r in d_audit['all_tracked_docs_file_receipts'].values():
    verify(r)
for r in d_audit['preexisting_ignored_bytecode_cache_receipts']:
    verify(r)
for r in docs['validation']['strict_mkdocs']['raw']:
    verify(r)
verify(docs['prior_writing_review'])
verify(docs['writer_reconciliation'])
identities=[]
for r in (code['reviewed_candidate'],d_audit['candidate'],json.loads((HERE/'preparation-receipt.json').read_text())['baseline_source']):
    path=Path(r['path'])
    assert git(path,'rev-parse HEAD')==r['commit']
    assert git(path,'rev-parse HEAD^{tree}')==r['tree']
    assert not git(path,'status --porcelain --untracked-files=no')
    identities.append({'path':str(path),'commit':r['commit'],'tree':r['tree'],'tracked_clean':True})
assert not list(Path(code['reviewed_candidate']['path']).rglob('*.pyc'))
result={'status':'PASS','reports':[final['code_report'],final['docs_report']],
        'frozen_source_identities':identities,'C_file_receipts_verified':len(c_audit['candidate_files']),
        'docs_tracked_receipts_verified':len(d_audit['all_tracked_docs_file_receipts']),
        'docs_preexisting_bytecode_receipts_preserved':len(d_audit['preexisting_ignored_bytecode_cache_receipts']),
        'source_bound_FD_A14':'PASS','DOC_L01':'CLOSED','DOC_L02':'CLOSED',
        'strict_mkdocs':'FAIL_DEFERRED_PHASE5','material_findings':0}
(HERE/'final-delivery-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
