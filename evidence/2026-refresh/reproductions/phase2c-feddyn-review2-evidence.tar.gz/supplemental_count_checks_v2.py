"""Independent realized-object/RNG binding and type-sensitive aggregation checks."""
import asyncio
import copy
import hashlib
import json
import multiprocessing as mp
import os
from pathlib import Path
import sys
import traceback

import numpy as np
import torch
from plato.callbacks.server import ServerCallback
from plato.config import Config
from acceptance_matrix import bind, close, exact, need, origins, owned_server, update
from tests.integration.test_feddyn_round_flow import QuadraticTrainer, client, configuration, dispatch, server
from tests.integration.utils import configure_environment

class PinnedSampler(torch.utils.data.Sampler):
    def __init__(self, token):
        self.indices = (1, 7)
        self.token = token
        self.created_pid = os.getpid()
        self.iterations = 0
    def __len__(self):
        return 2
    def __iter__(self):
        self.iterations += 1
        return iter(self.indices)

class OneGetPartition:
    def __init__(self):
        self.calls = 0
        self.realized = PinnedSampler("reviewer-pinned-attempt")
    def get(self):
        self.calls += 1
        need(self.calls == 1, "Partition get() must run exactly once, in the parent")
        need(os.getpid() == self.realized.created_pid, "Worker redrew the parent partition")
        return self.realized
    def num_samples(self):
        return 2

def rng():
    ns = np.random.get_state()
    return {"python": __import__("random").getstate(), "numpy": [ns[0], torch.from_numpy(ns[1].copy()), ns[2], ns[3], ns[4]], "torch": torch.get_rng_state().clone()}

class ObservedTrainer(QuadraticTrainer):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.binding_observations = []
    def _bind_attempt_partition(self, sampler):
        before = rng()
        realized = super()._bind_attempt_partition(sampler)
        need(exact(rng(), before), "Partition binding consumed Python/NumPy/Torch CPU RNG")
        need(isinstance(realized, PinnedSampler), "Parent did not preserve actual sampler type")
        need(realized is (sampler.realized if isinstance(sampler, OneGetPartition) else sampler), "Binding replaced the current realized partition object")
        need(realized.indices == (1, 7) and realized.token == "reviewer-pinned-attempt", "Partition identity/indices changed")
        self.binding_observations.append({"pid": os.getpid(), "input_type": type(sampler).__name__, "created_pid": realized.created_pid, "indices": realized.indices, "token": realized.token, "rng_unchanged": True})
        return realized
    def train_process(self, config, trainset, sampler, **kwargs):
        need(isinstance(sampler, PinnedSampler), "Real worker must receive the parent's realized sampler")
        need(sampler.indices == (1, 7), "Actual worker partition indices changed")
        super().train_process(config, trainset, sampler, **kwargs)
        result = self.model_update_strategy.result
        need(result["num_samples"] == 2 and result["completed_steps"] == 2, "Worker count/step mismatch")
        close(result["endpoint"]["theta"].item(), 1.622)
        close(result["history"]["theta"].item(), -0.378)
        path = Path(self._training_state_path(config["run_id"])).parent / f"partition-worker-{os.getpid()}.json"
        path.write_text(json.dumps({"pid": os.getpid(), "process": mp.current_process().name, "indices": sampler.indices, "token": sampler.token, "parent_pid": sampler.created_pid, "count": 2, "completed_steps": 2, "endpoint": 1.622, "history": -0.378, "bindings": self.binding_observations, "origins": origins(), "head": os.environ["REVIEW_HEAD"], "tree": os.environ["REVIEW_TREE"]}, indent=2) + "\n")

def partition_case(root, mode, path):
    root.mkdir(parents=True, exist_ok=True)
    with configure_environment(configuration(mode, (2, 2), spawn=path == "spawn"), runtime_root=root):
        s, c = server(), client(1, ObservedTrainer)
        assignment = dispatch(s, [1])[1]
        bind(c, assignment)
        # Direct trainer calls bypass DefaultTrainingStrategy.train, which
        # normally assigns this active trainer round before invocation.
        c.trainer.current_round = assignment[0]["current_round"]
        # A distinct loss on every backing-data index except the two partition
        # indices proves the worker used the current partition, not its length.
        targets = torch.full((9, 1), 1000.0, dtype=torch.double)
        targets[1] = targets[7] = 0
        data = torch.utils.data.TensorDataset(torch.ones(9, 1).double(), targets)
        partition = OneGetPartition()
        before_rng = rng()
        if path == "spawn":
            c.trainer.train(data, partition)
            need(exact(rng(), before_rng), "Spawn parent training/count check drifted CPU RNG")
            need(partition.realized.iterations == 0, "Parent enumerated the partition")
            worker_paths = list(root.rglob("partition-worker-*.json"))
            need(len(worker_paths) == 1, "Expected one actual spawned training worker")
            worker = json.loads(worker_paths[0].read_text())
            need(worker["pid"] != os.getpid() and worker["parent_pid"] == os.getpid(), "Parent/child partition handoff not real")
            need(worker["process"] != "MainProcess", "Expected actual worker process")
        else:
            config = Config().trainer._asdict()
            config["run_id"] = Config.params["run_id"]
            c.trainer.train_model(config, data, partition)
            worker = None
            need(c.trainer.train_loader.sampler is partition.realized, "Direct loader replaced bound sampler object")
            need(partition.realized.iterations == 2, "Direct worker must train two epochs of the current partition")
        strategy = c.trainer.model_update_strategy
        need(partition.calls == 1, "Partition get() was called more than once")
        need(strategy.accepted and strategy.result["num_samples"] == 2, "Valid bound partition was not accepted")
        close(c.trainer.model.theta.item(), 1.622)
        close(strategy.result["history"]["theta"].item(), -0.378)
        return {"case": f"independent_partition/{mode}/{path}", "status": "PASS", "get_calls_parent": 1, "partition_indices": [1, 7], "backing_dataset_count": 9, "actual_count": 2, "binding_observations": c.trainer.binding_observations, "real_worker": worker}

class MutateCount(ServerCallback):
    def __init__(self, event, mutation):
        self.event, self.mutation, self.calls = event, mutation, 0
    def mutate(self, s):
        before = copy.deepcopy(s.observed_counts)
        need(type(s.observed_counts[1]) is int, "Inactive count must be a native int")
        if self.mutation == "numpy_value":
            s.observed_counts[1] = np.int64(1)
        elif self.mutation == "bool_value":
            s.observed_counts[1] = True
        elif self.mutation == "float_value":
            s.observed_counts[1] = 1.0
        elif self.mutation == "bool_key":
            value = s.observed_counts.pop(1)
            s.observed_counts[True] = value
        elif self.mutation == "float_key":
            value = s.observed_counts.pop(1)
            s.observed_counts[1.0] = value
        else:
            raise AssertionError(self.mutation)
        need(s.observed_counts == before and not exact(s.observed_counts, before), "Mutation must actually change stored types through Python equality")
        self.calls += 1
    def on_weights_received(self, s, weights):
        if self.event == "receive":
            self.mutate(s)
    def on_weights_aggregated(self, s, updates):
        if self.event == "aggregation":
            self.mutate(s)

def callback_case(root, event, mutation):
    root.mkdir(parents=True, exist_ok=True)
    with configure_environment(configuration(), runtime_root=root):
        s = server()
        s.updates = [update(client(1), dispatch(s, [1])[1], 0, 1)]
        asyncio.run(s._process_reports())
        s.save_to_checkpoint()
        path = Path(s.checkpoint_bundle_path())
        canonical = path.read_bytes()
        valid = update(client(2), dispatch(s, [2])[2], 4, 1)
        s.updates = [valid]
        before = owned_server(s)
        callback = MutateCount(event, mutation)
        s.callback_handler.add_callback(callback)
        try:
            asyncio.run(s._process_reports())
        except ValueError as exc:
            need(callback.calls == 1, "Callback rejection must follow actual type mutation")
            after = owned_server(s)
            differences = [key for key in before if not exact(after[key], before[key])]
            # FedAvg sets context.current_round after receive. FedDyn rollback
            # owns model/history/count/token/dispatch and pending state; it does
            # not transact this generic context bookkeeping.
            need(set(differences) <= {"context_round"}, f"FedDyn owned rollback drift: {differences}")
            generic_context_change = {"before": before["context_round"], "after": after["context_round"]}
            before.pop("context_round")
            after.pop("context_round")
            need(exact(after, before), "Precommit count guard did not restore every FedDyn-owned field/live RNG")
            need(s._pending is None and s._pending_seal is None, "Rejected callback retained pending fields")
            need(path.read_bytes() == canonical, "Rejected callback changed canonical bytes")
            s.callback_handler.callbacks.remove(callback)
            s.updates = [valid]
            asyncio.run(s._process_reports())
            close(s.trainer.model.theta.item(), 1.9717445)
            need(s.observed_counts == {1: 1, 2: 1} and all(type(k) is int and type(v) is int for k, v in s.observed_counts.items()), "Valid retry failed native count state")
            s.save_to_checkpoint()
            need(torch.load(path, weights_only=True)["committed_round"] == 2, "Valid retry checkpoint failed")
            return {"case": f"independent_callback/{event}/{mutation}", "status": "GREEN_REJECTION_AND_RETRY", "rejection": str(exc), "external_callback_calls": callback.calls, "rollback_exact": True, "canonical_before_retry_unchanged": True, "retry_cloud": 1.9717445, "generic_context_round_observation": generic_context_change}
        need(callback.calls == 1 and s.committed_round == 2, "Baseline mutation not committed")
        return {"case": f"independent_callback/{event}/{mutation}", "status": "EXPECTED_OLD_RED", "failure_assertion": "typed count mutation must reject and roll back before commit", "committed_round": 2}

def main():
    torch.set_num_threads(1)
    root = Path(sys.argv[1]).resolve()
    kind = sys.argv[2]
    root.mkdir(parents=True, exist_ok=True)
    checks = []
    try:
        if kind == "partition":
            for mode in ("uniform", "sample"):
                for path in ("spawn", "direct_model"):
                    checks.append(partition_case(root / f"{mode}-{path}", mode, path))
        elif kind == "callback":
            for event, mutation in [("receive", "numpy_value"), ("aggregation", "numpy_value"), ("aggregation", "bool_value"), ("aggregation", "float_value"), ("aggregation", "bool_key"), ("aggregation", "float_key")]:
                checks.append(callback_case(root / f"{event}-{mutation}", event, mutation))
        else:
            raise AssertionError(kind)
        result = {"status": "PASS", "kind": kind, "checks": checks, "origins": origins(), "python": sys.version, "head": os.environ["REVIEW_HEAD"], "tree": os.environ["REVIEW_TREE"], "no_active_children": not mp.active_children()}
        need(result["no_active_children"], "Active children remained")
    except BaseException as exc:
        result = {"status": "HARNESS_ERROR", "kind": kind, "checks": checks, "error": repr(exc), "traceback": traceback.format_exc()}
    (root / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"kind": kind, "status": result["status"], "checks": len(checks), "outcomes": [c["status"] for c in checks]}))
    if result["status"] == "HARNESS_ERROR":
        print(result["traceback"], file=sys.stderr)
        raise SystemExit(2)

if __name__ == "__main__":
    from supplemental_count_checks_v2 import main as guarded_main
    guarded_main()
