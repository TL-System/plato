"""Validate exact-source traces, unique test accounting and author receipts."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import sys
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
CANDIDATE = Path("/tmp/plato-refresh-worktrees/feddyn-count-review").resolve()
BASELINE = Path("/tmp/plato-refresh-worktrees/training-final-review").resolve()
reviewed = json.loads((HERE / "candidate-audit-after.json").read_text())
before = json.loads((HERE / "inventory-before.json").read_text())

def receipt(p):
    data = p.read_bytes()
    return {"path": str(p), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

author = json.loads((CANDIDATE / "evidence/2026-refresh/phase2c-feddyn-count-fixes-validation.json").read_text())
for item in author["raw_scratch_inventory"]:
    assert Path(item["path"]).resolve().is_relative_to(Path("/tmp/plato-phase2c-feddyn-count-fixes").resolve())
    assert receipt(Path(item["path"])) == item
for name, execution in author["executions"].items():
    assert hashlib.sha256(Path(execution["log"]).read_bytes()).hexdigest() == execution["log_sha256"], name
    if "junit" in execution:
        assert receipt(Path(execution["junit"]["path"])) == execution["junit"], name
for version in ("313", "314"):
    assert author["executions"][f"affected-{version}"]["counts"] == {"tests": 308, "passed": 308, "failed": 0, "skipped": 0}
    assert author["executions"][f"red-{version}"]["counts"] == {"tests": 20, "passed": 1, "failed": 19, "skipped": 0}
    for item in author["actual_socket_shutdown_results"][version]:
        expected = {k: item[k] for k in ("path", "bytes", "sha256")}
        assert receipt(Path(item["path"])) == expected
    for relative, item in author["sources"].items():
        assert hashlib.sha256((CANDIDATE / relative).read_bytes()).hexdigest() == item["sha256"]

traces, tests, matrix, supplements = {}, {}, {}, {}
for version in ("313", "314"):
    tests[version] = json.loads((HERE / f"affected-{version}/pytest-nodes.json").read_text())
    collected = tests[version]["collected"]
    passed = [r["nodeid"] for r in tests[version]["reports"] if r["when"] == "call" and r["outcome"] == "passed"]
    assert len(collected) == len(set(collected)) == len(passed) == 63
    assert set(collected) == set(passed) and tests[version]["exitstatus"] == 0
    xml = ET.parse(HERE / f"affected-{version}/junit.xml")
    assert len(xml.findall(".//testcase")) == 63
    assert not xml.findall(".//failure") and not xml.findall(".//error") and not xml.findall(".//skipped")
    for kind in ("affected", "ty", "ruff") if version == "313" else ("affected", "ty"):
        command = json.loads((HERE / f"{kind}-{version}/command.json").read_text())
        assert command["exit_code"] == 0
        for item in command["raw"]:
            assert receipt(Path(item["path"])) == item
    matrix[version] = [json.loads((HERE / f"corrected-{version}" / c["case"] / "result.json").read_text()) for c in json.loads((HERE / f"corrected-{version}/commands.json").read_text())]
    assert len(matrix[version]) == 11 and all(r["status"] in {"VALID_CONTROL_PASS", "GREEN_REJECTION_AND_RETRY"} and r["no_active_children"] for r in matrix[version])
    supplements[version] = {}
    for kind in ("partition", "callback"):
        base = HERE / f"supplement-v2-corrected-{kind}-{version}"
        supplements[version][kind] = json.loads((base / "runtime/results.json").read_text())
        assert supplements[version][kind]["status"] == "PASS" and supplements[version][kind]["no_active_children"]
        assert json.loads((base / "command.json").read_text())["all_outcomes_expected"]
    logs = []
    for folder in (f"corrected-{version}", f"affected-{version}", f"supplement-v2-corrected-partition-{version}", f"supplement-v2-corrected-callback-{version}"):
        logs.extend(sorted((HERE / folder / "origins").glob("*.jsonl")))
    starts, imports = [], []
    for path in logs:
        rows = [json.loads(line) for line in path.read_text().splitlines()]
        assert not any("ERROR" in row["event"] for row in rows), path
        begin = [row for row in rows if row["event"] == "python_start"]
        assert len(begin) == 1
        starts.extend(begin)
        imports.extend(row for row in rows if row["event"] == "import")
    for row in starts:
        assert Path(row["source"]).resolve() == CANDIDATE and row["head"] == reviewed["head"] and row["tree"] == reviewed["tree"]
    for row in imports:
        relative = str(Path(row["origin"]).relative_to(CANDIDATE))
        assert row["sha256"] == reviewed["candidate_files"][relative]["sha256"], relative
    traces[version] = {"exact_bound_interpreter_start_records": len(starts), "verified_import_records": len(imports), "origin_logs": [receipt(p) for p in logs], "all_parent_child_source_hashes_match": True}
    baseline_extra = json.loads((HERE / f"supplement-baseline-callback-{version}/runtime/results.json").read_text())
    assert len(baseline_extra["checks"]) == 6 and all(c["status"] == "EXPECTED_OLD_RED" for c in baseline_extra["checks"])

assert tests["313"]["collected"] == tests["314"]["collected"]
author_ids = set(author["executions"]["affected-313"]["test_ids"])
reviewer_ids = {p.split("::", 1)[0].removesuffix(".py").replace("/", ".") + "::" + p.split("::", 1)[1] for p in tests["313"]["collected"]}
assert reviewer_ids <= author_ids and len(reviewer_ids) == 63
result = {
    "status": "PASS", "candidate": {"path": str(CANDIDATE), "head": reviewed["head"], "tree": reviewed["tree"]},
    "unique_pytest_cases_each_version": 63, "all_63_overlap_author_308": True,
    "author_308_raw_receipts_verified": True, "author_19_red_1_existing_guard_distinguished": True,
    "corrected_independent_matrix_cases_each_version": 11,
    "corrected_independent_supplement_cases_each_version": 10,
    "independent_categories_not_added_to_pytest_total": True,
    "baseline_original_242_not_relabelled": True,
    "source_provenance": traces,
    "test_nodes": tests["313"]["collected"],
    "matrix_results": matrix,
    "supplement_results": supplements,
    "author_evidence": receipt(CANDIDATE / "evidence/2026-refresh/phase2c-feddyn-count-fixes-validation.json"),
}
(HERE / "review-evidence-audit.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k not in {"source_provenance", "test_nodes", "matrix_results", "supplement_results"}}))
