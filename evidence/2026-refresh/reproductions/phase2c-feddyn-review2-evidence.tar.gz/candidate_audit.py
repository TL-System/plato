"""Exact read-only candidate/baseline and preservation audit."""
import ast
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys

HERE = Path(__file__).resolve().parent
CANDIDATE = Path("/tmp/plato-refresh-worktrees/feddyn-count-review").resolve()
BASELINE = Path("/tmp/plato-refresh-worktrees/training-final-review").resolve()
HEAD = "8b01bf47ca8bdf9232bffeb4e50f78d4f00c9e3b"
TREE = "1cb086b9db386128ba6a965c198e8c07400ab9be"

def git(command, cwd=CANDIDATE):
    return subprocess.check_output(["zsh", "-lc", "git " + command], cwd=cwd, text=True).strip()

def record(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

def inventory(root):
    return {str(p.relative_to(root)): record(p) for p in sorted(root.rglob("*")) if p.is_file() and ".git" not in p.relative_to(root).parts}

def node(tree, qualified):
    current = ast.parse(tree)
    for part in qualified.split("."):
        current = next(n for n in current.body if isinstance(n, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == part)
    return ast.dump(current, include_attributes=False)

assert git("rev-parse HEAD") == HEAD and git("rev-parse HEAD^{tree}") == TREE
assert git("status --porcelain=v1 --untracked-files=all") == ""
assert git("rev-parse HEAD", BASELINE) == "13e38dafce476286db7e673e7f21343d54416b56"
assert git("status --porcelain=v1 --untracked-files=all", BASELINE) == ""
nano = CANDIDATE / "external/nanochat"
nano_id = git("ls-tree HEAD external/nanochat").split()[2]
assert git("rev-parse HEAD", nano) == nano_id == "c75fe54aa7c1fa881701c246f9427bcbe4eee5a4"
assert git("status --porcelain=v1 --untracked-files=all", nano) == ""
candidate_files, baseline_files = inventory(CANDIDATE), inventory(BASELINE)
assert not any(p.endswith(".pyc") or "__pycache__" in p for p in candidate_files)
prepared = json.loads((HERE / "inventory-before.json").read_text())
assert baseline_files == prepared["source_files"]
source_changed = [p for p in baseline_files if p in candidate_files and baseline_files[p]["sha256"] != candidate_files[p]["sha256"]]
allowed = [
    "examples/customized_client_training/feddyn/feddyn_server.py",
    "examples/customized_client_training/feddyn/feddyn_trainer.py",
    "plato/trainers/strategies/algorithms/__init__.py",
    "plato/trainers/strategies/algorithms/feddyn_strategy.py",
]
assert sorted(source_changed) == sorted(allowed)
new = sorted(set(candidate_files) - set(baseline_files))
assert new == sorted([
    "evidence/2026-refresh/phase2c-feddyn-count-fixes-delivery-receipt.json",
    "evidence/2026-refresh/phase2c-feddyn-count-fixes-facts.json",
    "evidence/2026-refresh/phase2c-feddyn-count-fixes-validation.json",
    "tests/integration/feddyn_count_worker.py",
    "tests/integration/test_feddyn_count_boundaries.py",
])
assert set(baseline_files) <= set(candidate_files)
ast_preserved = {}
nodes = {
    "plato/trainers/strategies/algorithms/feddyn_strategy.py": ["effective_alpha", "settings_from_config", "FedDynLossStrategy", "FedDynLossStrategyFromConfig", "positive_integer", "same_state", "validate_dispatch", "validate_endpoint", "FedDynUpdateStrategy.get_update_payload"],
    "examples/customized_client_training/feddyn/feddyn_server.py": ["Server.aggregate_weights", "Server._snapshot", "Server._validate_rng", "Server._resume_from_checkpoint", "Server.start", "Server._validate_batch", "Server.save_to_checkpoint"],
}
for path, names in nodes.items():
    for name in names:
        assert node((BASELINE / path).read_text(), name) == node((CANDIDATE / path).read_text(), name), name
        ast_preserved[path + ":" + name] = True
overview = allowed[2]
old_ast, new_ast = ast.parse((BASELINE / overview).read_text()), ast.parse((CANDIDATE / overview).read_text())
old_doc, new_doc = ast.get_docstring(old_ast), ast.get_docstring(new_ast)
assert "Alternative implementation (Option 1)" in old_doc
assert "Compatibility subclass using Option II" in new_doc
old_ast.body = old_ast.body[1:]
new_ast.body = new_ast.body[1:]
assert ast.dump(old_ast, include_attributes=False) == ast.dump(new_ast, include_attributes=False)
evidence = {}
for name, expected in {
    "phase2c-feddyn-count-fixes-validation.json": "0352d54214cfdb32d7790f35a3071579a6bc75e1781b79d1af41bde6ca673458",
    "phase2c-feddyn-count-fixes-facts.json": "2b8154918100e23f20ba27c2f9c269030b7bf54a2fb1675c5d678bae64247a8e",
    "phase2c-feddyn-count-fixes-delivery-receipt.json": "bda69c691d9253e200ec6407d4db83ab654b00ed30db78eb1d1492928a13ef23",
}.items():
    item = record(CANDIDATE / "evidence/2026-refresh" / name)
    assert item["sha256"] == expected
    evidence[name] = item
docs = Path("/Users/bli/Playground/plato/evidence/2026-refresh/phase2c-algorithm-docs-review.json")
assert record(docs)["sha256"] == "add5e422b2be3799e857ce10fc52402a5b5bc50fa21a91b74da6ce97c7823076"
prior_hashes = prepared["prior_reviewer_artifacts"]
prior_root = Path("/tmp/plato-phase2c-feddyn-code-review")
assert all(record(prior_root / p) == item for p, item in prior_hashes.items())
for item in json.loads((HERE / "preparation-receipt.json").read_text())["receipts"]:
    assert record(Path(item["path"])) == item
diff_path = HERE / "candidate.diff"
diff = git("diff 13e38dafce476286db7e673e7f21343d54416b56 HEAD")
diff_path.write_text(diff + "\n") if sys.argv[1] == "before" else None
assert diff_path.read_text() == diff + "\n"
result = {"head": HEAD, "tree": TREE, "nanochat_gitlink": nano_id, "source_changed": source_changed, "added_files": new, "all_other_project_bytes_identical": True, "project_bytecode_files": 0, "candidate_files": candidate_files, "baseline_preserved": True, "prior_reviewer_preserved": True, "preparation_scripts_receipts_preserved": True, "ast_preserved": ast_preserved, "module_overview_docstring_only": True, "evidence": evidence, "bounded_docs_review": record(docs), "diff": record(diff_path), "lock": record(CANDIDATE / "uv.lock")}
destination = HERE / f"candidate-audit-{sys.argv[1]}.json"
if sys.argv[1] == "after":
    assert result == json.loads((HERE / "candidate-audit-before.json").read_text())
destination.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"destination": str(destination), "head": HEAD, "tree": TREE, "changed_existing": len(source_changed), "new_files": len(new), "project_files": len(candidate_files), "bytecode_files": 0, "all_assertions_passed": True}))
