"""Propagate immutable-source guard through existing real subprocess harnesses."""
import os
from pathlib import Path
import subprocess
import sys
import json

SOURCE = Path(os.environ["REVIEW_SOURCE"]).resolve()
GUARD = str(Path(__file__).resolve().parent / "source_guard")
ORIGINAL = subprocess.Popen.__init__
COLLECTED = []
REPORTS = []

def launch(self, *args, **kwargs):
    env = dict(kwargs.get("env") or os.environ)
    paths = env.get("PYTHONPATH", "").split(os.pathsep)
    assert SOURCE in [Path(p).resolve() for p in paths if p]
    if GUARD not in paths:
        paths.insert(0, GUARD)
    env["PYTHONPATH"] = os.pathsep.join(paths)
    kwargs["env"] = env
    return ORIGINAL(self, *args, **kwargs)

def verify():
    for name, module in tuple(sys.modules.items()):
        if name == "plato" or name.startswith("plato.") or name.startswith("tests.") or name in {"feddyn", "feddyn_client", "feddyn_server", "feddyn_trainer"}:
            path = getattr(module, "__file__", None)
            if path:
                assert Path(path).resolve().is_relative_to(SOURCE), (name, path)

def pytest_sessionstart(session):
    verify()
    subprocess.Popen.__init__ = launch

def pytest_collection_finish(session):
    COLLECTED.extend(item.nodeid for item in session.items)

def pytest_runtest_logreport(report):
    REPORTS.append({"nodeid": report.nodeid, "when": report.when, "outcome": report.outcome})

def pytest_sessionfinish(session, exitstatus):
    verify()
    subprocess.Popen.__init__ = ORIGINAL
    Path(os.environ["REVIEW_PYTEST_NODES"]).write_text(json.dumps({"collected": COLLECTED, "reports": REPORTS, "exitstatus": int(exitstatus)}, indent=2) + "\n")
