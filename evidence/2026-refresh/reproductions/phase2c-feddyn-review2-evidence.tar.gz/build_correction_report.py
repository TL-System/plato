"""Write only the authorized reviewer2 report and own scratch receipts."""
import datetime
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path("/Users/bli/Playground/plato/evidence/2026-refresh")
TARGET = ROOT / "phase2c-feddyn-code-review-2.json"
SOURCE = Path("/tmp/plato-refresh-worktrees/feddyn-count-review").resolve()
audit = json.loads((HERE / "candidate-audit-after.json").read_text())
evidence = json.loads((HERE / "review-evidence-audit.json").read_text())
prior = json.loads((ROOT / "phase2c-feddyn-code-review.json").read_text())
design = json.loads((ROOT / "phase2c-feddyn-design.json").read_text())
prepared = json.loads((HERE / "preparation-receipt.json").read_text())
author = json.loads((SOURCE / "evidence/2026-refresh/phase2c-feddyn-count-fixes-validation.json").read_text())
docs = json.loads((ROOT / "phase2c-algorithm-docs-review.json").read_text())

def receipt(path):
    b = path.read_bytes()
    return {"path": str(path), "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()}

def selected(function):
    return [node for node in evidence["test_nodes"] if function in node]

def execution(path):
    obj = json.loads(path.read_text())
    return {"receipt": receipt(path), "record": obj}

criteria = []
titles = {item["id"]: item["title"] for item in design["testacceptance"]}
for original in prior["criterion_mapping"]:
    criterion = original["id"]
    functions = {item["function"] for item in original.get("actual_test_functions", [])}
    matched = {node for function in functions for node in selected(function)}
    matrix = []
    extra = []
    if criterion in {"FD-A05", "FD-A10"}:
        extra += ["test_actual_spawn_wrong_first_count_rejected_and_retry", "test_parent_realizes_partition_once_without_using_backing_length"]
        matrix += ["count-uniform-corrupt", "count-uniform-valid", "count-sample-corrupt", "count-sample-valid"]
    if criterion == "FD-A05":
        extra += ["test_nonzero_history_requires_saved_observed_count"]
    if criterion == "FD-A09":
        extra += ["test_consecutive_same_client_uses_current_cloud_and_dispatched_history", "test_actual_spawn_wrong_first_count_rejected_and_retry"]
    if criterion == "FD-A11":
        extra += ["test_inactive_callback_count_types_rejected_before_commit", "test_callback_and_partial_load_boundary[postcommit]"]
        matrix += [row["case"] for row in evidence["matrix_results"]["313"] if row["case"].startswith("callback-")]
    if criterion == "FD-A12":
        extra += ["test_nonzero_history_requires_saved_observed_count", "test_actual_shipped_run_resume_matches_four_round_control_and_rng"]
        matrix += ["checkpoint-missing"]
    if criterion == "FD-A13":
        extra += ["test_actual_shipped_run_resume_matches_four_round_control_and_rng", "test_shipped_mnist_shaped_lenet_spawn_and_real_socket_cloud"]
    matched |= {node for function in extra for node in selected(function)}
    status = "PASS_IN_REVIEWED_CPU_SCOPE"
    note = "Historical13e numerical/native-codec evidence remains historical. Exact diff/AST preservation plus current affected checks reconcile this criterion; no unrelated suite rerun claimed."
    if criterion == "FD-A06":
        note += " settings_from_config/effective_alpha and configuration/profile guards are byte/AST-identical; author affected receipts cover the unchanged invalid settings cases."
    if criterion == "FD-A14":
        status = "IMPLEMENTATION_SOURCE_AND_TYPING_PASS_FINAL_SOURCE_BOUND_WRITING_PENDING"
        note = "Explicit --python ty passes both actual environments without suppression; scoped Ruff passes; overview change is docstring-only. Prior69d prose PASS is bound to13e and is not final-source acceptance. Root has not yet supplied the reconciled writing candidate."
    criteria.append({
        "id": criterion, "title": titles[criterion], "status": status,
        "preserved_historical_evidence": original,
        "current_reviewer_pytest_ids": sorted(matched),
        "current_reviewer_pytest_unique_matches_each_version": len(matched),
        "independent_matrix_cases": matrix,
        "source_preservation_and_limits": note,
        "overlap_policy": "A test may support several criteria. FD-A12/13 share the two real uniform/sample run/--resume cases. Criterion matches are not summed as unique executions.",
    })
assert len(criteria) == 15

findings_disposed = [
    {
        "id": "FD-C-R01", "prior_severity": "medium", "disposition": "RESOLVED",
        "source_locations": [
            {"path": "examples/customized_client_training/feddyn/feddyn_trainer.py", "line": 35},
            {"path": "examples/customized_client_training/feddyn/feddyn_trainer.py", "line": 220},
            {"path": "examples/customized_client_training/feddyn/feddyn_trainer.py", "line": 234},
            {"path": "examples/customized_client_training/feddyn/feddyn_trainer.py", "line": 249},
            {"path": "plato/trainers/strategies/algorithms/feddyn_strategy.py", "line": 629},
        ],
        "mechanism": "Parent resolves get() once, validates the actual Sized partition and any declaration, binds its count before the real worker launch, and passes that realized sampler onward. Worker state num_samples is checked against this preexisting parent authority before result installation. Direct train_model binds the actual sampler too. feddyn_num_samples remains a validated output; it is not the parent provenance source.",
        "independent_red": "Exact13e real worker trained2 of9 backing items; changing only sidecar count to3 was accepted/sent and cached3. Sample mode already rejected and passed retry.",
        "independent_green": "Same frozen probe now rejects uniform and sample sidecar corruption before outbound, restores parent model/dispatch/gradient/result and server state/file bytes, refuses update eligibility, and accepts exact retry. Actual worker proof includes count2, two steps, endpoint1.622 and history-.378.",
        "partition_proof": "Both modes: one parent get(), indices[1,7] of a9-item backing dataset with a distinct1000-target distraction, unchanged global CPU RNG during binding, exact object preservation in direct loaders, and same token/indices received by a real spawned worker. No parent partition enumeration, backing-data count fallback or duplicate untrusted worker-count authority. Actual reused and consecutive same/returning logical-client tests remain green.",
        "evidence": ["corrected-313", "corrected-314", "supplement-v2-corrected-partition-313", "supplement-v2-corrected-partition-314", "affected-313", "affected-314"],
    },
    {
        "id": "FD-C-R02", "prior_severity": "medium", "disposition": "RESOLVED",
        "source_locations": [{"path": "examples/customized_client_training/feddyn/feddyn_server.py", "line": 631}],
        "mechanism": "Validated full-population nonzero history requires its observed count in the existing version1 bundle. The check runs inside complete bundle validation before any model/history/count/round/config or pending resume RNG installation.",
        "independent_red": "Exact13e round2 history1=-.378 with deleted count1 loaded into fresh and already-pending objects, unbound next count expectation, and accepted a changed3-item partition.",
        "independent_green": "Same bundle rejects for fresh and prior-pending objects with exact live/pending/RNG/file preservation. Coherent round2 and sparse never-trained zero-history round1 bundles load; coherent retry reaches exact round3 cloud1.47705273425. New8 tests cover both modes, either missing client, and fresh/prior-pending states.",
        "bounded_rule": "Zero histories cannot prove prior participation. No detection of deleted counts whose histories are all zero is claimed; no new participation ledger, protocol key or schema change.",
        "evidence": ["corrected-313/checkpoint-missing", "corrected-314/checkpoint-missing", "affected-313", "affected-314"],
    },
    {
        "id": "FD-C-R03", "prior_severity": "medium", "disposition": "RESOLVED",
        "source_locations": [{"path": "examples/customized_client_training/feddyn/feddyn_server.py", "line": 359}, {"path": "examples/customized_client_training/feddyn/feddyn_server.py", "line": 440}],
        "mechanism": "Both receive and aggregation guards compare the existing complete observed-count map using recursive type-sensitive same_state, including stored key types. Guard rejection precedes accepted commit and triggers the existing owned-state rollback.",
        "independent_red": "Exact13e accepted equivalent bool/float values and pop/reinsert bool/float keys at receive; supplemental baseline accepted NumPy integer values and equivalent value/key mutations at aggregation.",
        "independent_green": "Same mutations reject, restore model/history/count/token/dispatch/committed snapshot and RNG, clear pending fields, preserve canonical bytes, and accept valid retry/checkpoint. Equivalent assignment to an existing float-equal key that leaves the stored int key unchanged passes as a meaningful valid control. Ordinary callback passes.",
        "boundary_preservation": "Unchanged postcommit evaluation/reporting exception still leaves accepted round1/cloud1.433 committed. Arbitrary callback side effects are not transacted. Generic context.current_round bookkeeping is outside this bounded owned-state rollback; the corrected independent snapshot explicitly retains all FedDyn-owned assertions.",
        "evidence": ["corrected-313", "corrected-314", "supplement-baseline-callback-313", "supplement-baseline-callback-314", "supplement-v2-corrected-callback-313", "supplement-v2-corrected-callback-314", "affected-313", "affected-314"],
    },
    {
        "id": "FD-C-L01", "prior_severity": "low", "disposition": "RESOLVED",
        "mechanism": "Actual Sized narrowing and existing context_model Module validation replace the five un-narrowed call sites; existing validation is reused without suppressions.",
        "baseline": "Explicit --python ty reported exactly5 invalid-argument-type diagnostics in each preparation environment.",
        "corrected": "Identical owned-source --python command passes in both actual environments, no skipped sources or ignored diagnostics. Scoped Ruff import check also passes.",
        "evidence": ["ty-313", "ty-314", "ruff-313"],
    },
]

executions = {}
for version in ("313", "314"):
    executions[f"affected-{version}"] = execution(HERE / f"affected-{version}/command.json")
    executions[f"ty-{version}"] = execution(HERE / f"ty-{version}/command.json")
    executions[f"matrix-{version}"] = execution(HERE / f"corrected-{version}/commands.json")
    for kind in ("partition", "callback"):
        executions[f"supplement-{kind}-{version}"] = execution(HERE / f"supplement-v2-corrected-{kind}-{version}/command.json")
    executions[f"supplement-baseline-callback-{version}"] = execution(HERE / f"supplement-baseline-callback-{version}/command.json")
executions["ruff-313"] = execution(HERE / "ruff-313/command.json")
runtimes = {version: json.loads((HERE / f"runtime-capture-validation-{version}.json").read_text()) for version in ("313", "314")}

script_names = [
    "acceptance_matrix.py", "matrix_runner.py", "source_guard/sitecustomize.py",
    "candidate_audit.py", "reviewer_pytest_provenance.py", "run_corrected_review.py",
    "supplemental_count_checks.py", "supplemental_count_checks_v2.py", "run_supplement.py", "run_supplement_v2.py",
    "validate_runtime_captures.py", "audit_review_evidence.py", "audit_review_evidence.v1.py", "audit_review_evidence.v2.py", "build_correction_report.py",
]
raw_paths = [
    HERE / name for name in ("preparation-receipt.json", "candidate.diff", "candidate-audit-before.json", "candidate-audit-after.json", "review-evidence-audit.json", "automatic-cache-relocation-receipt.json", "runtime-capture-validation-313.json", "runtime-capture-validation-314.json")
]
for version in ("313", "314"):
    for phase in ("baseline", "corrected"):
        base = HERE / f"{phase}-{version}"
        raw_paths.extend(sorted(base.rglob("result.json")))
        raw_paths.extend(sorted(base.rglob("stdout.log")))
        raw_paths.extend(sorted(base.rglob("stderr.log")))
    for folder in (f"supplement-corrected-partition-{version}", f"supplement-corrected-callback-{version}", f"supplement-baseline-callback-{version}", f"supplement-v2-corrected-partition-{version}", f"supplement-v2-corrected-callback-{version}"):
        raw_paths.extend(sorted((HERE / folder).rglob("results.json")))
        raw_paths.extend(sorted((HERE / folder).glob("stdout.log")))
        raw_paths.extend(sorted((HERE / folder).glob("stderr.log")))

report = {
    "schema_version": 1,
    "written_at_utc": datetime.datetime.now(datetime.UTC).isoformat(),
    "role": "Fresh independent Sol xhigh FedDyn correction reviewer2; no nested agents",
    "verdict": "PASS_BOUNDED_CORRECTED_IMPLEMENTATION",
    "summary": "Exact8b resolves all three medium count-state findings and low explicit typing finding. Accepted equations/native transport/CPU replay/legacy migration are preserved and changed boundaries pass independently on3.13/3.14. Final source-bound writing and root integration gates remain pending.",
    "finding_counts": {"critical": 0, "high": 0, "medium": 0, "low": 0},
    "material_findings": [], "low_findings": [],
    "reviewed_candidate": {
        "path": str(SOURCE), "commit": audit["head"], "tree": audit["tree"],
        "implementation_commit": "fac9c65161f699fd94c7d264a519715fedd2bc4c",
        "implementation_tree": "05b9c7a27e90ef10334af85041dd5a8d5cb28616",
        "baseline_path": str(Path("/tmp/plato-refresh-worktrees/training-final-review").resolve()),
        "baseline_commit": "13e38dafce476286db7e673e7f21343d54416b56",
        "baseline_tree": "9fe8cfb039d0d97fc5b2c95a459de4c73c6d1b51",
        "nanochat_gitlink": audit["nanochat_gitlink"],
        "source_inventory_before_after_equal": True, "tracked_clean_at_end": True, "project_bytecode_files": 0,
    },
    "accepted_inputs": {**prepared["immutable_inputs"], **audit["evidence"]},
    "source_diff": {
        "receipt": audit["diff"], "changed_existing_paths": audit["source_changed"],
        "added_paths": audit["added_files"], "all_other_project_bytes_identical": True,
        "exact_changed_source_receipts": {p: audit["candidate_files"][p] for p in audit["source_changed"]},
        "unchanged_semantic_ast_checks": audit["ast_preserved"],
        "module_overview": "Only the leading docstring changed: SCAFFOLDUpdateStrategyV2 is a compatibility subclass using OptionII. Imports and executable AST are identical.",
        "accepted_A_B_D_scaffold_lifecycle": "All existing files outside the four explicitly changed FedDyn/docstring files are byte-identical to13e. Accepted shared lifecycle and SCAFFOLD review4 are retained without reopening; optional duplicate idempotent cleanup recommendation requires no fix.",
        "production_codec": "plato.serialization.safetensor and actual client/transport files are byte-identical. Independent direct/socket observations retain native scalar metadata; no test-only coercion or codec repair.",
        "lock": audit["lock"],
    },
    "finding_dispositions": findings_disposed,
    "criterion_mapping": criteria,
    "execution_accounting": {
        "historical_original_reviewer_13e": {"unique_pytest_cases_each_version": 242, "basis": "222 focused +20 compatibility; preserved historical receipts, never relabelled"},
        "author_correction": {"unique_affected_pytest_cases_each_version": 308, "new_regression_cases": 20, "baseline_red_regressions": 19, "baseline_existing_sample_guard_passes": 1, "raw_receipts_verified": True, "source_identity": "fac9c651"},
        "current_independent_reviewer": {"unique_pytest_cases_each_version": 63, "passed": 63, "failed": 0, "skipped": 0, "pytest_warnings": 0, "all_63_overlap_author_308": True, "prepared_matrix_cases_each_version": 11, "additional_independent_partition_cases_each_version": 4, "additional_independent_callback_cases_each_version": 6, "supplement_baseline_callback_old_red_cases_each_version": 6},
        "counting_rule": "Do not add author308 to reviewer63, historic242 to correction counts, criterion matches to unique test counts, or independent script cases to pytest cases. Uniform/sample actual resume cases support both FD-A12 andFD-A13 but execute once each per version.",
        "unique_current_pytest_ids": evidence["test_nodes"],
        "no_full_suite_or_unrelated_48_startup_rerun_claimed": True,
    },
    "environments": {v: {"python": evidence["matrix_results"][v][0]["python"], "executable": evidence["matrix_results"][v][0]["executable"], "packages": evidence["matrix_results"][v][0]["packages"], "additional_native_runtime_packages": {name: author["environments"][v]["packages"].get(name) for name in ()}, "platform": author["environments"][v]["platform"], "reuse": "Existing read-only /tmp/plato-phase2c environments; no installs/provisioning", "pyproject": receipt(SOURCE / "pyproject.toml"), "lock": audit["lock"]} for v in ("313", "314")},
    "executions": executions,
    "independent_red_green": {
        "original_prepared_baseline": prepared["baseline_matrix"],
        "current_matrix": evidence["matrix_results"],
        "supplemental_partition_and_callback_results": evidence["supplement_results"],
        "original_failure_assertions_retained": True,
        "all_expected_six_prepared_old_red_become_rejection_retry": True,
        "source_identity_origin_guard": evidence["source_provenance"],
    },
    "actual_runtime_capture_validation": runtimes,
    "runtime_semantics": "Real inherited listeners, shipped main/run/--resume and actual max_concurrency workers run. Server normal close uses os._exit(0); child entrypoints return normally. Seven process groups per version have no forced shutdown or survivors. Independent Fraction arithmetic checks every selected endpoint and all10 histories at atol1e-12,rtol0; complete live/context/global CPU RNG start snapshots and later progression equal uninterrupted controls; MNIST-shaped LeNet changes parameters and matches independent corrected-cloud algebra at1e-6 tolerances. This is CPU synthetic qualification, not benchmark accuracy or CUDA qualification.",
    "harness_attempts": {
        "first_supplemental_failures_retained": [
            {"kind": "partition", "versions": ["313", "314"], "classification": "HARNESS_ERROR", "cause": "Direct trainer invocation omitted current_round assignment normally made by DefaultTrainingStrategy. Fixed only in newv2 scratch script."},
            {"kind": "aggregation callback", "versions": ["313", "314"], "classification": "HARNESS_ERROR_OVERBROAD_ASSERTION", "cause": "Snapshot compared generic context.current_round bookkeeping that FedAvg updates after receive. Newv2 compares all FedDyn-owned state/RNG and separately records this generic1->2 change. No production defect claimed."}
        ],
        "evidence_builder_failures": "Read-only receipt audit initially compared resolved/private/tmp to an unresolved/tmp prefix, then normalized slash characters inside parameter IDs. Versioned scripts retained; corrected path/module-only normalization verifies all receipts and exact63-ID overlap.",
        "automatic_tool_caches": execution(HERE / "automatic-cache-relocation-receipt.json"),
        "cache_note": "Pytest/Ruff created new ignored caches in the candidate. All9 cache files were preserved byte-for-byte in own scratch and exact1065-file inventory restored. No source bytecode generated; no evidence or original cache deleted. Initial audit/pytest-only relocation assertion stopped before mutation.",
        "no_deadline_or_assertion_weakening": "Existing subprocess deadlines, profile guards and numerical/type/owned-state assertions retained. Scope correction applies only to erroneous generic context bookkeeping assertion in own supplementary probe.",
    },
    "writing_gate": {
        "prior_bounded_writing_review": audit["bounded_docs_review"],
        "prior_verdict": docs["verdict"], "prior_candidate": docs["candidate"],
        "final_reconciled_candidate_supplied": False,
        "status": "PENDING_FINAL_SOURCE_BOUND_REVIEW",
        "explanation": "Prior bounded writing PASS was tied to69d/13e. Concurrent author reconciliation/CPU paragraphs were not inspected. Do not treat that PASS as final prose acceptance for8b; root will supply the final writing candidate.",
    },
    "limits_and_pending": [
        "Bounded corrected CPU implementation PASS only; root integration, final source-bound prose and whole phase/production acceptance are separate.",
        "Checkpoint coherence covers nonzero histories; zero-history prior participation cannot be inferred without an unauthorized new ledger.",
        "Callback rollback covers existing FedDyn-owned state, not arbitrary external callback side effects.",
        "No GPU/inflight replay, convergence, downloads/benchmark accuracy, Linux/new provisioning, complete optional stack or unrelated CI timeout review.",
    ],
    "workflow": {
        "nested_agents": False, "author_contact": False, "evolving_author_source_read": False,
        "writes": "Own reviewer2 scratch and assigned phase2c-feddyn-code-review-2.json only; incidental generated tool caches relocated into scratch without deletion.",
        "original_sources_tests_docs_evidence": "Preserved exact baseline/candidate bytes and all prior reviewer artifacts/preparation receipts.",
        "installs_commits_pushes_or_manual_process_cleanup": False,
    },
    "script_receipts": [receipt(HERE / name) for name in script_names],
    "raw_receipts": [receipt(p) for p in sorted(set(raw_paths))],
}
assert report["verdict"] == "PASS_BOUNDED_CORRECTED_IMPLEMENTATION"
assert len(report["criterion_mapping"]) == 15 and report["criterion_mapping"][13]["id"] == "FD-A14"
text = json.dumps(report, indent=2) + "\n"
assert not TARGET.exists(), "Assigned new report already exists; preserve it before amendment"
(HERE / "phase2c-feddyn-code-review-2.json").write_text(text)
TARGET.write_text(text)
assert TARGET.read_bytes() == (HERE / TARGET.name).read_bytes()
final = {"status": "PASS_BOUNDED_CORRECTED_IMPLEMENTATION", "source": report["reviewed_candidate"], "report": receipt(TARGET), "scratch_copy": receipt(HERE / TARGET.name), "unique_pytest_each_version": 63, "independent_cases_each_version": 21, "material_findings": 0, "typing": "PASS_BOTH", "final_writing_gate": "PENDING"}
(HERE / "final-review-receipt.json").write_text(json.dumps(final, indent=2) + "\n")
print(json.dumps(final))
