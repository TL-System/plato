"""Read-only inventory for the immutable FedDyn correction-review baseline."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

SCRATCH = Path(__file__).resolve().parent
SOURCE = Path("/tmp/plato-refresh-worktrees/training-final-review").resolve()
ROOT_EVIDENCE = Path("/Users/bli/Playground/plato/evidence/2026-refresh")
PRIOR = Path("/tmp/plato-phase2c-feddyn-code-review")
EXPECTED_HEAD = "13e38dafce476286db7e673e7f21343d54416b56"
EXPECTED_TREE = "9fe8cfb039d0d97fc5b2c95a459de4c73c6d1b51"
EXPECTED_HASHES = {
    "phase2c-feddyn-code-review.json": "c0455ca53f730e9696719d1312e9913ef62dc3064911cca475aa6247faa68c0b",
    "phase2c-feddyn-design.json": "62c5d61805c49ccc06f99776d0da820c5b27cffeb5916754ddb16bb3135c1d5b",
    "phase2c-scaffold-code-review-4.json": "ecded9d6b645910a5c2b1149181593ab131fd0e404c4bc59a03db18c75cb8d42",
}

def git(command, cwd=SOURCE):
    return subprocess.check_output(["zsh", "-lc", "git " + command], cwd=cwd, text=True).strip()

def receipt(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

def inventory():
    assert git("rev-parse HEAD") == EXPECTED_HEAD
    assert git("rev-parse HEAD^{tree}") == EXPECTED_TREE
    assert git("status --porcelain=v1 --untracked-files=all") == ""
    sub = SOURCE / "external/nanochat"
    expected_link = git("ls-tree HEAD external/nanochat").split()[2]
    assert git("rev-parse HEAD", sub) == expected_link
    assert git("status --porcelain=v1 --untracked-files=all", sub) == ""
    paths = [p for p in SOURCE.rglob("*") if p.is_file() and ".git" not in p.relative_to(SOURCE).parts]
    files = {str(p.relative_to(SOURCE)): receipt(p) for p in sorted(paths)}
    prior = {str(p.relative_to(PRIOR)): receipt(p) for p in sorted(PRIOR.rglob("*")) if p.is_file()}
    evidence = {}
    for name in (*EXPECTED_HASHES, "phase2c-feddyn-acceptance.json", "phase2c-scaffold-implementation-acceptance.json"):
        item = receipt(ROOT_EVIDENCE / name)
        if name in EXPECTED_HASHES:
            assert item["sha256"] == EXPECTED_HASHES[name], name
        evidence[name] = item
    reviewed = json.loads((ROOT_EVIDENCE / "phase2c-feddyn-code-review.json").read_text())
    design = json.loads((ROOT_EVIDENCE / "phase2c-feddyn-design.json").read_text())
    assert len(design["testacceptance"]) == len(reviewed["criterion_mapping"]) == 15
    return {
        "source": str(SOURCE), "head": EXPECTED_HEAD, "tree": EXPECTED_TREE,
        "nanochat_gitlink": expected_link,
        "source_files": files, "project_cache_files": [p for p in files if p.endswith(".pyc") or "__pycache__" in p],
        "evidence": evidence, "root_agents": receipt(Path("/Users/bli/Playground/plato/AGENTS.md")),
        "prior_reviewer_artifacts": prior,
        "preserved_criteria": reviewed["criterion_mapping"],
        "accepted_test_contract": design["testacceptance"],
        "prior_findings": reviewed["findings"] + reviewed["low_findings"],
        "phase": "PREPARATION_ONLY_NO_CORRECTED_CANDIDATE_VERDICT",
    }

if __name__ == "__main__":
    state = inventory()
    target = SCRATCH / ("inventory-before.json" if sys.argv[1] == "before" else "inventory-after.json")
    if sys.argv[1] != "before":
        before = json.loads((SCRATCH / "inventory-before.json").read_text())
        for key in ("source_files", "prior_reviewer_artifacts", "evidence", "root_agents", "head", "tree", "nanochat_gitlink", "project_cache_files"):
            assert state[key] == before[key], key + " changed during preparation"
    target.write_text(json.dumps(state, indent=2) + "\n")
    print(json.dumps({"target": str(target), "source_files": len(state["source_files"]), "cache_files": len(state["project_cache_files"]), "prior_artifacts": len(state["prior_reviewer_artifacts"]), "verified": True}))
