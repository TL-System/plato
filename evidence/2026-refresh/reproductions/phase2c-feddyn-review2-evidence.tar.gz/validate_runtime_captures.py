"""Independent Fraction/socket/startup audit of retained actual runtime captures."""
import hashlib
import json
from fractions import Fraction
from pathlib import Path
import psutil
import random
import sys
import torch

HERE = Path(__file__).resolve().parent

def need(condition, message):
    if not condition:
        raise AssertionError(message)

def receipt(p):
    b = p.read_bytes()
    return {"path": str(p), "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()}

def load(path):
    return torch.load(path, weights_only=True, map_location="cpu")

def exact(a, b):
    if isinstance(b, torch.Tensor):
        return isinstance(a, torch.Tensor) and a.dtype == b.dtype and a.shape == b.shape and torch.equal(a, b)
    if isinstance(b, dict):
        return isinstance(a, dict) and {(type(k), k) for k in a} == {(type(k), k) for k in b} and all(exact(a[k], v) for k, v in b.items())
    if isinstance(b, (list, tuple)):
        return type(a) is type(b) and len(a) == len(b) and all(exact(x, y) for x, y in zip(a, b))
    return type(a) is type(b) and a == b

def close(tensor, expected):
    need(tensor.dtype == torch.float64 and tensor.shape == (1,), "Expected exact scalar schema")
    need(abs(tensor.item() - float(expected)) <= 1e-12, f"Independent rational mismatch {tensor.item()} vs {expected}")

def next_round(x, h, selected, mode):
    endpoints, next_h = {}, list(h)
    for client_id in selected:
        alpha = Fraction(1, 10) if mode == "uniform" else Fraction(11, 20 * client_id)
        y = x
        for _ in range(2):
            y -= Fraction(1, 10) * (y - client_id + alpha * (y - x + h[client_id - 1]))
        endpoints[client_id] = y
        next_h[client_id - 1] += y - x
    cloud = sum(endpoints.values()) / len(selected) + sum(next_h) / 10
    return cloud, next_h, endpoints

choices_rng = random.Random(17)
choices = [choices_rng.sample(list(range(1, 11)), 2) for _ in range(4)]
need(choices == [[9, 7], [5, 6], [5, 3], [9, 5]], "Selection oracle mismatch")
version = sys.argv[1]
runtime = HERE / f"affected-{version}/runtime"
socket_results = []
for p in sorted(runtime.rglob("result.json")):
    if p.parent.name not in {"run", "first", "resumed", "lenet-run"} or not any("test_actual_shipped" in part or "test_shipped_mnist" in part for part in p.parts):
        continue
    d = json.loads(p.read_text())
    need(d["returncode"] == 0 and not d["timed_out"] and not d["forced"] and not d["survivors"], "Real socket run did not naturally finish")
    events = d["events"]
    need(sum(e["event"] == "custom_server" for e in events) == 1, "Shipped custom server was not instantiated once")
    need(any(e["event"] == "custom_client" for e in events), "Shipped custom client factory was not used")
    need(any(e["event"] == "server_will_close" for e in events) and any(e["event"] == "child_returned" for e in events), "Missing inherited server-close/normal child-return evidence")
    text = d["stdout"] + d["stderr"]
    need("Starting a server at address 127.0.0.1 and port " in text and "Connecting to the server at http://127.0.0.1:" in text, "Real listener/connection evidence missing")
    need(any(e["event"] == "child_started" for e in events), "No actual launched worker observed")
    current_survivors = []
    for pid, created in d["processes"].items():
        try:
            proc = psutil.Process(int(pid))
            if proc.create_time() == created and proc.status() != psutil.STATUS_ZOMBIE:
                current_survivors.append(int(pid))
        except psutil.NoSuchProcess:
            pass
    need(not current_survivors, "Captured process identity survived after the run")
    socket_results.append({**receipt(p), "processes_observed": len(d["processes"]), "real_listener_and_shipped_wiring": True, "natural_close_child_return": True, "forced": False, "survivors_at_capture": [], "survivors_now": []})
need(len(socket_results) == 7, "Expected seven real entrypoint process groups")

modes = []
for test_root in sorted(runtime.glob("test_actual_shipped_run_resume*")):
    cfg = __import__("tomllib").loads((test_root / "control/run/config.toml").read_text())
    mode = cfg["algorithm"]["feddyn_weighting"]
    need(mode in {"uniform", "sample"}, "Unexpected runtime weighting")
    expected_x, expected_h = Fraction(2), [Fraction(0)] * 10
    expected_counts = {}
    expected_rows = []
    for round_id, ids in enumerate(choices, 1):
        x_before = expected_x
        h_before = list(expected_h)
        expected_x, expected_h, endpoints = next_round(expected_x, expected_h, ids, mode)
        expected_counts.update({i: i for i in ids})
        for directory in (test_root / "control/run", test_root / ("split/first" if round_id <= 2 else "split/resumed")):
            received = load(directory / f"received-{round_id}.pth")
            committed = load(directory / f"committed-{round_id}.pth")
            need(received["selected"] == ids and all(type(i) is int for i in received["selected"]), "Actual selector differs from independent choice")
            close(received["baseline"]["theta"], x_before)
            for i in range(1, 11):
                close(received["before"][i]["theta"], h_before[i - 1])
                close(committed["histories"][i]["theta"], expected_h[i - 1])
            need(len(received["payloads"]) == 2, "Missing actual received endpoint")
            for endpoint, metadata in received["payloads"]:
                need(all(type(metadata[k]) is int for k in ("version", "round", "client_id", "num_samples", "completed_steps")), "Socket metadata is not native integer state")
                need(all(type(metadata[k]) is str for k in ("run_id", "dispatch_token")), "Socket token/run is not native string state")
                i = metadata["client_id"]
                need(i in ids and metadata["round"] == round_id and metadata["num_samples"] == i and metadata["completed_steps"] == 2, "Actual worker report count/step/identity mismatch")
                close(endpoint["theta"], endpoints[i])
            close(committed["model"]["theta"], expected_x)
            need(committed["counts"] == expected_counts and all(type(k) is int and type(v) is int for k, v in committed["counts"].items()), "Committed counts do not match actual current partitions")
            need(committed["committed_round"] == round_id and len(committed["accepted_tokens"]) == round_id * 2, "Committed round/token ledger mismatch")
        control = load(test_root / "control/run" / f"committed-{round_id}.pth")
        split = load(test_root / ("split/first" if round_id <= 2 else "split/resumed") / f"committed-{round_id}.pth")
        for field in ("model", "histories", "counts", "committed_round", "rng"):
            need(exact(control[field], split[field]), f"Uninterrupted/split differs at {field}")
        expected_rows.append({"round": round_id, "selected": ids, "cloud_exact": str(expected_x), "cloud": float(expected_x), "all_histories_exact": [str(h) for h in expected_h]})
    saved = load(test_root / "split/first/committed-2.pth")
    start = load(test_root / "split/resumed/start.pth")
    need(start["pending"] is None and start["round"] == 2 and exact(start["rng"], saved["rng"]), "Complete pending CPU RNG handoff did not precede real startup")
    need(saved["rng"]["python"] != saved["rng"]["selection"], "Distinct saved global/selection streams required")
    fresh = load(test_root / "control/run/start.pth")
    need(fresh["pending"] is None and fresh["round"] == 0 and fresh["rng"]["selection"] == random.Random(17).getstate(), "Fresh seed/start boundary changed")
    resumed_result = json.loads((test_root / "split/resumed/result.json").read_text())
    need("--resume" in resumed_result["command"], "Real --resume entrypoint required")
    modes.append({"mode": mode, "independent_fraction_rows": expected_rows, "complete_live_context_rng_before_real_start": True, "later_selection_and_rng_progression_equal": True, "fresh_seed_preserved": True})
need({r["mode"] for r in modes} == {"uniform", "sample"}, "Both actual weighting modes must execute")

lenet_root = next(runtime.glob("test_shipped_mnist_shaped_lene*")) / "lenet-run"
histories = None
parameter_change = False
for round_id in range(1, 4):
    received = load(lenet_root / f"received-{round_id}.pth")
    committed = load(lenet_root / f"committed-{round_id}.pth")
    if histories is None:
        histories = {i: {k: v.clone() for k, v in h.items()} for i, h in received["before"].items()}
    for endpoint, metadata in received["payloads"]:
        i = metadata["client_id"]
        need(type(i) is int and type(metadata["num_samples"]) is int, "LeNet socket metadata must be native")
        for key, value in endpoint.items():
            delta = value - received["baseline"][key]
            parameter_change |= bool(torch.any(delta != 0))
            histories[i][key] += delta
    for key, value in committed["model"].items():
        expected = sum(p[0][key] for p in received["payloads"]) / len(received["payloads"]) + sum(h[key] for h in histories.values()) / 2
        torch.testing.assert_close(value, expected, atol=1e-6, rtol=1e-6)
        need(bool(torch.isfinite(value).all()), "Nonfinite LeNet cloud")
    for i, h in histories.items():
        for key, expected in h.items():
            torch.testing.assert_close(committed["histories"][i][key], expected, atol=1e-6, rtol=1e-6)
need(parameter_change, "Actual MNIST-shaped LeNet local training must change parameters")

result = {"version": version, "python": sys.version, "status": "PASS", "real_entrypoint_process_groups": socket_results, "scalar_controls": modes, "lenet_independent_equations_parameter_change": True, "tolerances": {"scalar": {"atol": 1e-12, "rtol": 0}, "float32": {"atol": 1e-6, "rtol": 1e-6}}}
(HERE / f"runtime-capture-validation-{version}.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"version": version, "status": "PASS", "actual_process_groups": 7, "uniform_sample_fraction_oracles": True, "complete_CPU_rng": True, "lenet_algebra": True, "no_survivors": True}))
