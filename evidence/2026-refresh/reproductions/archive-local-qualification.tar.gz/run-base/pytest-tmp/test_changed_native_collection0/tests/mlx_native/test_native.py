from pathlib import Path
with (Path(__file__).parents[2] / 'events').open('a') as stream:
    stream.write('native-import\n')
import pytest
@pytest.mark.parametrize('value', [1], ids=['one'])
def test_native(value):
    assert value > 0
