"""Policy harness dependency stand-in."""
