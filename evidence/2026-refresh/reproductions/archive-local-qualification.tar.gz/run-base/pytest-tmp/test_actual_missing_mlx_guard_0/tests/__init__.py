"""Inert test package."""
