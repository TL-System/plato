"""Inert native package."""
