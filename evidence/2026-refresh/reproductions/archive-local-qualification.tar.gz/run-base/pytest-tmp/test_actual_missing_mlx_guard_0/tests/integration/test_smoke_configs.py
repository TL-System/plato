def test_mpc_training_smoke():
    pass

