def test_dp_strategy_handles_plato_sampler_get():
    pass

def test_dp_strategy_handles_torch_sampler_directly():
    pass

