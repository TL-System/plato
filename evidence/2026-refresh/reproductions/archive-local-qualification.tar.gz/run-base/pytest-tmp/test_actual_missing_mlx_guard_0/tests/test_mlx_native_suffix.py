def test_core_name():
    pass
