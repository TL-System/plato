"""Recheck retained runtime outputs without repeating expensive experiments."""
import hashlib
import json
import math
from pathlib import Path
import random
from fractions import Fraction
import xml.etree.ElementTree as ET

import numpy as np
import torch

root = Path('/tmp/plato-archive-integration/run-mandatory')
mandatory = True
prior = Path('/tmp/plato-mlx-final/audit_linux_artifacts.py')
text = prior.read_text()
segment = text[text.index('runtime_records=[]'):text.index('result=dict(status=')]
segment = segment.replace('root/"runtime-tmp"', 'root/"pytest-tmp"')
exec(compile(segment, str(prior) + ':reused-runtime-oracles', 'exec'))

cases = list(ET.parse(root / 'tests.xml').getroot().iter('testcase'))
assert len(cases) == 1551
assert not any(c.find(t) is not None for c in cases for t in ('failure','error','skipped'))
retained_cases = [c.attrib for c in cases if c.get('classname') == 'tests.integration.test_retained_model_search']
assert len(retained_cases) == 19
records = []
seen = set()
for path in sorted((root / 'pytest-tmp').rglob('result.json')):
    data = json.loads(path.read_text())
    if not isinstance(data, dict) or 'family' not in data or 'events' not in data:
        continue
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest in seen:
        continue
    seen.add(digest)
    assert data['returncode'] == 0 and not data['timed_out'] and not data['forced'] and not data['survivors'], path
    assert data['lock_sha256'] == 'e2a53aaae9a0dd49f5446b490bb3071e86aa3a9a20d6271c9dd30b4ae2dcbff9'
    events = data['events']
    assert any(e['event'] == 'success' for e in events)
    if data['case'] == 'socket':
        assert [e['rate'] for e in events if e['event'] == 'selected_rate'] == [0.5, 1.0]
        assert sorted(e['samples'] for e in events if e['event'] == 'client_trained') == [2, 6]
        oracles = [e for e in events if e['event'] == 'aggregation_oracle']
        assert len(oracles) == 1
        assert oracles[0]['weighting'] == 'uniform channel average'
        assert math.isfinite(oracles[0]['max_error']) and oracles[0]['max_error'] <= 1e-5
    if data['case'] == 'budget':
        oracle = next(e for e in events if e['event'] == 'activated_budget')
        assert oracle['limitation_activated'] is True
        assert len(oracle['records']) == 2
        assert oracle['records'][1]['selected_rate'] < oracle['records'][0]['selected_rate']
        assert all(math.isfinite(q['macs']) and q['macs'] > 0 for q in oracle['queries'])
        for row in oracle['records']:
            assert math.isfinite(row['loss'])
            assert all(0 < v <= b for v, b in zip(row['selected_profile'], row['budget'], strict=True))
    records.append({'path':str(path.relative_to(root)), 'sha256':digest, **data})
assert len(records) == 19, len(records)
assert sum(r['case'] == 'socket' for r in records) == 3
assert sum(r['case'] == 'budget' for r in records) == 3
result = {'source':'6bf8836d06072c7946cdfb5499a09e4bce459805','mandatory_cases':1551, 'runtime_oracle_source_sha256':hashlib.sha256(prior.read_bytes()).hexdigest(), 'core_runtime_records':runtime_records, 'fedavg':fedavg, 'feddyn':scalar, 'retained_cases':retained_cases, 'retained_records':records, 'limits':'Recomputed core FedAvg and FedDyn numerical oracles from saved payloads; retained model-search event assertions are checked against already reviewed worker numerical oracles. No broader family qualification implied.'}
(root / 'root-runtime-audit.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({'core_records':len(runtime_records),'retained_records':len(records),'fedavg':fedavg,'feddyn_modes':[s['mode'] for s in scalar]}))
