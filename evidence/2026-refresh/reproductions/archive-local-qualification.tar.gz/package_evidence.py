"""Keep complete raw evidence locally and package compact reviewable records."""
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import tarfile

root = Path('/tmp/plato-archive-integration')
out = root / 'delivery'
out.mkdir(exist_ok=True)
for profile, expected, skips in [('mandatory',1551,0),('base',1474,1),('mlx-native',383,0)]:
    receipt = json.loads((root / ('run-'+profile) / 'receipt.json').read_text())
    assert receipt['head'] == '6bf8836d06072c7946cdfb5499a09e4bce459805'
    assert receipt['passed'] == expected and receipt['junit_counts'] == {'failure':0,'error':0,'skipped':skips}
    assert not receipt['tracked_source_changes']
    assert all(r['returncode'] == 0 for r in receipt['results'])

roots = [root / ('run-'+p) for p in ('mandatory','base','mlx-native')]
roots += [root / 'final-checks']
single_files = ['run_profile.py','audit_runtime.py','final_static.py','check_wheel_import.py',
    'distribution-and-docs-check.json','check_distributions.py','wheel-import-receipt.json',
    'sync.log','base-sync.log','docs-sync.log','docs-build.log','package-build.log',
    'wheel-runtime-requirements.txt','wheel-export.log','wheel-install.log','wheel-pip-check.log',
    'wheel-venv.log','package_evidence.py','runtime-environments.json']
paths = [root / p for p in single_files]
aliases = []
for directory in roots:
    for current, directories, files in os.walk(directory, followlinks=False):
        parent = Path(current)
        for name in list(directories):
            if (parent/name).is_symlink():
                aliases.append(str((parent/name).relative_to(root)))
                directories.remove(name)
        for name in files:
            path=parent/name
            if path.is_symlink(): aliases.append(str(path.relative_to(root)))
            else: paths.append(path)

records = []
selected = {}
for path in sorted(paths):
    data = path.read_bytes()
    name = str(path.relative_to(root))
    # All large files remain untouched at their recorded local paths; final CI
    # independently uploads complete runtime payloads via the reviewed stager.
    include = len(data) <= 2*1024*1024
    records.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
        'in_compact_bundle':include,'omission_reason':None if include else 'Large raw fixture/payload retained locally; final Linux runtime artifact is separate.'})
    if include: selected[name]=path
manifest = out / 'archive-local-evidence-manifest.json'
manifest.write_text(json.dumps({'source':'6bf8836d06072c7946cdfb5499a09e4bce459805',
    'raw_root':str(root),'files':records,'ignored_symlink_aliases':aliases,
    'policy':'Hash every regular raw record. Compact Git bundle retains files <=2MiB; omitted raw payloads remain locally intact and are explicitly listed. Exact final Linux artifacts qualify separately.'},indent=2)+'\n')
selected['archive-local-evidence-manifest.json']=manifest
bundle = out / 'archive-local-qualification.tar.gz'
assert not bundle.exists(), 'Preserve previous bundles.'
with bundle.open('wb') as raw, gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as zipped, tarfile.open(fileobj=zipped,mode='w') as archive:
    for name,path in sorted(selected.items()):
        info=archive.gettarinfo(str(path),arcname=name)
        info.uid=info.gid=0; info.uname=info.gname=''; info.mtime=0
        with path.open('rb') as incoming: archive.addfile(info,incoming)
with tarfile.open(bundle,'r:gz') as archive:
    assert len(archive.getmembers()) == len(selected)
    for name,path in selected.items():
        assert hashlib.sha256(archive.extractfile(name).read()).digest() == hashlib.sha256(path.read_bytes()).digest()
receipt={'status':'LOCAL_QUALIFICATION_COMPLETE_PENDING_DELIVERY_GATE_AND_LINUX',
    'source':'6bf8836d06072c7946cdfb5499a09e4bce459805',
    'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'profiles':{'mandatory':1551,'base':1474,'base_expected_optional_DP_skip':1,'mlx_native':383},
    'bundle':{'file':bundle.name,'sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'bytes':bundle.stat().st_size,'files':len(selected)},
    'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),
    'raw_records':len(records),'omitted_large_records':[r for r in records if not r['in_compact_bundle']],
    'limits':'Compact bundle is not all raw payload bytes. Complete originals remain untouched at raw_root; exact-source Linux qualification and artifact audit are required before merge. Global historical typing debt remains.'}
(out/'archive-local-qualification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='omitted_large_records'},indent=2))
