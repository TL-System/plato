import hashlib
import importlib.metadata as metadata
import importlib.util
import json
from pathlib import Path
import sys

import plato
from plato.models import registry
from plato.utils.retired_backends import raise_if_retired

prefix = Path('/tmp/plato-archive-integration/wheel-env').resolve()
assert Path(sys.prefix).resolve() == prefix
assert sys.version_info[:2] == (3, 13)
for module in (plato, registry):
    assert Path(module.__file__).resolve().is_relative_to(prefix), module.__file__
for module in ('plato.models.vit', 'plato.models.dvit', 'plato.models.t2tvit', 'plato.models.nanochat', 'plato.models.lerobot'):
    assert importlib.util.find_spec(module) is None, module
assert 'vit' not in registry.registered_factories
assert {'resnet', 'huggingface', 'torch_hub'} <= registry.registered_factories.keys()
assert 'mlx_lenet5' in registry.registered_mlx_models
diagnostics = {}
for name in ('vit', 'nanochat', 'lerobot', 'smolvla'):
    try:
        raise_if_retired(name, category='model')
    except ValueError as exc:
        assert 'archives/retired/' in str(exc)
        diagnostics[name] = str(exc)
    else:
        raise AssertionError(name)
distribution = metadata.distribution('plato-learn')
direct_url = json.loads(distribution.read_text('direct_url.json'))
assert direct_url['url'].endswith('plato_learn-1.4.3-py3-none-any.whl')
assert not direct_url.get('dir_info', {}).get('editable', False)
receipt = {'head': '6bf8836d06072c7946cdfb5499a09e4bce459805', 'python':sys.version, 'cwd':str(Path.cwd()), 'prefix':str(prefix), 'plato_path':plato.__file__, 'registry_path':registry.__file__, 'version': distribution.version, 'direct_url':direct_url, 'retirement_diagnostics':diagnostics}
assert 'plato-refresh-worktrees' not in str(Path.cwd())
Path('/tmp/plato-archive-integration/wheel-import-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt, indent=2))
