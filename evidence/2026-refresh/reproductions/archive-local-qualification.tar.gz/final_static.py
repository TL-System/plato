import ast
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

root = Path('/tmp/plato-refresh-worktrees/archive-integration')
out = Path('/tmp/plato-archive-integration/final-checks')
out.mkdir(exist_ok=True)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
python = '/tmp/plato-archive-integration/env/bin/python'
commands = {
    'lock': ['uv', 'lock', '--check'],
    'ruff': [python, '-m', 'ruff', 'check', '.', '--select', 'I'],
    'ty': [python, '-m', 'ty', 'check', '--output-format', 'concise'],
    'ty-stager': [python, '-m', 'ty', 'check', '.github/scripts/stage_ci_artifacts.py', '--output-format', 'concise', '--error-on-warning'],
}
results = {}
for name, command in commands.items():
    p = subprocess.run(command, cwd=root, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
    (out / (name + '.log')).write_text(p.stdout)
    results[name] = {'command': command, 'returncode': p.returncode, 'log_sha256': hashlib.sha256(p.stdout.encode()).hexdigest()}
    assert p.returncode in ({0, 1} if name == 'ty' else {0}), (name, p.stdout)
workflow = (root / '.github/workflows/pytorch_tests.yml').read_text()
owned = ast.literal_eval('{' + workflow.split('          owned = {', 1)[1].split('\n          }', 1)[0] + '}')
allowed = ast.literal_eval('{' + workflow.split('          allowed = {', 1)[1].split('\n          }', 1)[0] + '}')
log = (out / 'ty.log').read_text()
matches = list(re.finditer(r'^(.+?):(\d+):(\d+): (?:error|warning)\[([^]]+)\]', log, re.M))
report = re.search(r'^Found ([1-9][0-9]*) diagnostics?$', log, re.M)
assert (report and len(matches) == int(report[1])) or (not matches and log.strip() == 'All checks passed!')
violations = [m.groups() for m in matches if m[1] in owned and m.groups() not in allowed]
assert not violations, violations
result = {'head': subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(), 'commands': results, 'typing_diagnostics': len(matches), 'owned_paths': sorted(owned), 'allowed_preexisting_diagnostics': [m.groups() for m in matches if m.groups() in allowed], 'owned_violations': violations}
(out / 'receipt.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
