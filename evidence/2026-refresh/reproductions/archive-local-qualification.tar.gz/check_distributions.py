import hashlib,json,pathlib,tarfile,tomllib,zipfile
root=pathlib.Path("/tmp/plato-refresh-worktrees/archive-integration");out=pathlib.Path("/tmp/plato-archive-integration")
lock=tomllib.loads((root/"uv.lock").read_text())
records=[]
for path in sorted(p for p in (out/"dist").iterdir() if p.name.endswith((".whl", ".tar.gz"))):
 if path.suffix==".whl":
  with zipfile.ZipFile(path) as archive:
   names=archive.namelist();generator=next(archive.read(n).decode() for n in names if n.endswith(".dist-info/WHEEL"))
  canonical=names
 else:
  with tarfile.open(path) as archive:names=archive.getnames()
  canonical=["/".join(n.split("/")[1:]) for n in names];generator=None
 for name in canonical:
  assert not name.startswith(("archives/retired/","plato/models/dvit/","plato/models/t2tvit/","evidence/2026-refresh/reproductions/")),name
  assert name!="plato/models/vit.py",name
 for required in ["plato/models/registry.py","plato/models/mlx/lenet5.py","plato/utils/retired_backends.py"]:
  assert required in canonical,(path.name,required)
 records.append({"file":path.name,"bytes":path.stat().st_size,"sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"members":len(names),"wheel_metadata":generator})
record={"head":"6bf8836d06072c7946cdfb5499a09e4bce459805","lock_sha256":hashlib.sha256((root/"uv.lock").read_bytes()).hexdigest(),"locked_hatchling":next(p["version"] for p in lock["package"] if p["name"]=="hatchling"),"distributions":records,"retired_and_vendor_sources_absent":True,"retained_registry_native_model_and_retirement_diagnostics_present":True,"strict_docs_log_sha256":hashlib.sha256((out/"docs-build.log").read_bytes()).hexdigest(),"source_unchanged_binding":"Final profile runners independently snapshot all tracked source before/after. This check does not replace those snapshots."}
(out/"distribution-and-docs-check.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record,indent=2))
