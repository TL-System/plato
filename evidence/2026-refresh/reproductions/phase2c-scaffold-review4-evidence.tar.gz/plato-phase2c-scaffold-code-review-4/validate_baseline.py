"""Validate probe discrimination on known RED 15e, never accept 15e as code."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import source_adapter as adapter

BASE_COMMIT = "15e0cebd78ec6752b9aae1e922b33e22e168387f"
BASE_TREE = "9c9ce313f88552968b487388d681eda82384abfc"


def close(value, expected):
    assert math.isclose(value, expected, rel_tol=0, abs_tol=1e-12), (value, expected)


def validate(path):
    data = json.loads(path.read_text())
    execution = json.loads((path.parent / "execution.json").read_text())
    manifest = json.loads((path.parent / "source-before.json").read_text())
    assert manifest["commit"] == BASE_COMMIT and manifest["tree"] == BASE_TREE
    assert execution["source_unchanged"]
    assert execution["exit_code"] == 1, "Expected actual acceptance RED exit1"
    assert not data["harness_errors"]
    assert len(data["cases"]) == 24
    assert data["required_red_cases"] == 4 and data["required_green_cases"] == 20
    assert data["low_recommendation_cases"] == 8
    rows = []
    keys = set()
    for case in data["cases"]:
        interface = case["interface"]
        existing, end, cleanup = case["existing"], case["end_failure"], case["cleanup_failure"]
        keys.add((interface, existing, end, cleanup))
        observed = case["observed"]
        failures = case["required_failures"]
        direct_defect = interface == "train_model" and cleanup and not end
        direct_order = interface == "train_model" and not cleanup and not end
        assert bool(failures) == bool(direct_defect or direct_order), case["id"]
        if direct_order:
            assert failures == ["Accepted before fallible local cleanup returned"]
        low = interface in ("train_process", "spawn") and end
        assert bool(case["recommendation_failures"]) == bool(low), case["id"]
        if direct_defect:
            assert SECONDARY in case["error"]
            assert not observed["canonical_preserved"] and observed["canonical_exists"]
            assert observed["outbound"]["eligible"]
            close(observed["ci"], 0.9)
            close(observed["persisted_ci"], 0.9)
            close(case["fresh_ci"], 0.9)
            close(case["reuse"][-1]["ci"], 0.9)
            close(case["retry"]["y"], 0.601)
            close(case["retry"]["ci"], 0.895)
            close(case["retry"]["delta"], -0.005)
        elif end or cleanup:
            assert observed["canonical_preserved"]
            assert observed["canonical_exists"] is existing
            assert not observed["outbound"]["eligible"]
            assert observed["ci"] == 1.0
            assert case["fresh_ci"] == (1.0 if existing else None)
            close(case["retry"]["y"], 0.62)
            close(case["retry"]["ci"], 0.9)
            close(case["retry"]["delta"], -0.1)
        else:
            close(observed["model"], 0.62)
            close(observed["ci"], 0.9)
            close(observed["outbound"]["delta"], -0.1)
            close(case["retry"]["y"], 0.601)
            close(case["retry"]["ci"], 0.895)
            close(case["retry"]["delta"], -0.005)
        assert not observed["step_handle_present"]
        assert not observed["strategy_optimizer_present"]
        assert observed["optimizer_pre_hooks"] == 0
        assert not observed["complete_optimizer_step_present"]
        assert not observed["optimizer_step_hooks_handled_present"]
        calls = [event["successful"] for event in case["post_run_cleanup"]]
        if not end and cleanup and interface != "train_model":
            assert calls == [True, False], calls
            assert not case["recommendation_failures"]
        if low:
            assert calls == [False, False], calls
        if end and cleanup:
            exceptions = json.dumps({"caller": case["exception_chain"],
                                    "events": case["events"]})
            assert PRIMARY in exceptions and SECONDARY in exceptions
        displayed = (case["formatted_exception"] or "") + "\n".join(
            event["formatted"] for event in case["events"]
            if event["event"] == "process_exception"
        )
        if end:
            assert PRIMARY in displayed, "Primary error hidden from real formatted traceback"
        if cleanup:
            assert SECONDARY in displayed, "Cleanup error hidden from real formatted traceback"
        if interface == "spawn":
            enters = [event for event in case["events"] if event["event"] == "process_enter"]
            assert len(enters) == 1 and enters[0]["token"]
            assert enters[0]["source_cwd"] == data["source"]
            assert enters[0]["source_pythonpath"] == data["source"]
        rows.append({"id": case["id"], "required_acceptance": "RED" if failures else "GREEN",
                     "functional_result": "RED" if direct_defect else "GREEN",
                     "acceptance_order": "RED" if direct_order or direct_defect else "GREEN",
                     "low_duplicate_cleanup": bool(case["recommendation_failures"]),
                     "post_run_cleanup": calls, "initialization_calls_excluded": case["initialization_cleanup_count"],
                     "canonical_preserved": observed["canonical_preserved"],
                     "outbound_eligible": observed["outbound"]["eligible"],
                     "ci": observed["ci"], "reconstructed_ci": case["fresh_ci"],
                     "retry": case["retry"], "required_failures": failures})
    assert len(keys) == 24
    return {"python": data["python"], "source": data["source"],
            "manifest_sha256": manifest["manifest_sha256"],
            "tracked_file_count": manifest["tracked_file_count"],
            "preexisting_ignored_file_count": len(manifest["preexisting_ignored_files"]),
            "acceptance_exit_code": execution["exit_code"],
            "required_red_cases": 4, "required_green_cases": 20,
            "functional_red_cases": 2, "functional_green_cases": 22,
            "low_recommendation_cases": 8, "source_unchanged": True,
            "duration_seconds": execution["duration_seconds"], "cases": rows,
            "artifacts": [{"path": str(p), "bytes": p.stat().st_size, "sha256": adapter.digest(p)}
                          for p in (path, path.parent / "execution.json", path.parent / "raw.log",
                                    path.parent / "source-before.json", path.parent / "source-after.json")]}


PRIMARY = "reviewer4 primary training-step end failure"
SECONDARY = "reviewer4 secondary after-real-cleanup failure"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", nargs=2, type=Path, required=True)
    args = parser.parse_args()
    own = Path(__file__).resolve().parent
    result = {"status": "READY", "purpose": "Harness preparation only",
              "baseline": {"commit": BASE_COMMIT, "tree": BASE_TREE,
                           "known_failing_source": True},
              "harness_validation": "Expected baseline red/green discrimination confirmed",
              "implementation_acceptance": "Known baseline RED; no completed candidate supplied",
              "implementation_verdict_issued": False,
              "profiles": [validate(path.resolve()) for path in args.results],
              "matrix_dimensions": {"interfaces": ["train_model", "train_process", "spawn"],
                                    "prior_canonical": ["absent", "present-ci1"],
                                    "axes": ["success", "end-only", "cleanup-only", "end-and-cleanup"]}}
    (own / "baseline-matrix.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": "READY", "harness_validation_exit": 0,
                      "implementation_acceptance_exits": [1, 1],
                      "total_cases": 48, "functional_red": 4, "ordering_red": 4,
                      "mandatory_green": 40, "low_recommendation_cases": 16,
                      "matrix": str(own / "baseline-matrix.json")}, indent=2))


if __name__ == "__main__":
    main()
