"""Read-only environment receipt under exact immutable source bindings."""
import importlib.metadata as metadata
import json
import platform
import sys

import source_adapter as adapter

source, root = adapter.bind()
from plato.config import Config
from plato.trainers.composable import ComposableTrainer
from plato.trainers.strategies.algorithms.scaffold_strategy import SCAFFOLDUpdateStrategy

packages = {}
for name in (
    "torch", "numpy", "pytest", "ruff", "opacus", "safetensors", "torchvision",
    "transformers", "accelerate", "datasets", "aiohttp", "python-socketio",
    "tomli", "tomli-w", "lightning", "timm", "peft",
):
    try:
        packages[name] = metadata.version(name)
    except metadata.PackageNotFoundError:
        packages[name] = None
receipt = {
    "python": sys.version,
    "executable": sys.executable,
    "prefix": sys.prefix,
    "platform": platform.platform(),
    "packages": packages,
    "source": str(source),
    "origins": adapter.provenance(source, [Config, ComposableTrainer, SCAFFOLDUpdateStrategy]),
    "profile_limit": "Supplied existing environments; Opacus installed. No fresh minimal base provisioning claimed.",
    "writes": "Owned scratch only; no installation or environment change.",
}
(root / "environment.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
