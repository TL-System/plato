"""Independent final supplements; frozen reviewer4 files remain unchanged."""
import asyncio
import json
import os
import pickle
import traceback
from collections import OrderedDict
from fractions import Fraction as F
from pathlib import Path
from types import SimpleNamespace

import lifecycle_probe as p
import scaffold_server
import torch
from plato.callbacks.server import ServerCallback
from plato.trainers.strategies.algorithms.scaffold_strategy import (
    SCAFFOLDUpdateStrategy,
    SCAFFOLDUpdateStrategyV2,
)
from plato.trainers.strategies.base import TrainingContext

ROOT = p.RUN_ROOT


def exception_tree(exc):
    entries, seen = [], set()
    def walk(value, relation):
        if value is None or id(value) in seen:
            return
        seen.add(id(value))
        entries.append({"type": type(value).__name__, "message": str(value),
                        "relation": relation, "suppress_context": value.__suppress_context__,
                        "notes": getattr(value, "__notes__", [])})
        if isinstance(value, BaseExceptionGroup):
            for index, member in enumerate(value.exceptions):
                walk(member, f"member-{index}")
        walk(value.__cause__ or value.__context__, "cause-or-context")
    walk(exc, "raised")
    return entries


class InterruptEnd(p.TracedEnd):
    def on_train_end(self, context):
        self.end_calls += 1
        context.state["reviewer4_stage"] = "step_end"
        p.record(self.trace_path, "step_end_enter", calls=self.end_calls)
        p.GradientAccumulationStepStrategy.on_train_end(self, context)
        raise KeyboardInterrupt(p.PRIMARY)


def group_checks():
    original = p.TracedEnd
    p.exception_evidence = exception_tree
    rows = []
    for interrupt in (False, True):
        p.TracedEnd = InterruptEnd if interrupt else original
        p.RUN_ROOT = ROOT / f"groups-interrupt{int(interrupt)}"
        for interface in ("train_model", "train_process"):
            for existing in (False, True):
                row = p.run_case(interface, existing, True, True)
                assert not row["required_failures"], row["required_failures"]
                assert not row["recommendation_failures"]
                assert row["exception_chain"][0]["type"] == (
                    "BaseExceptionGroup" if interrupt else "ExceptionGroup"
                )
                members = [e for e in row["exception_chain"] if e["relation"].startswith("member-")]
                assert len(members) == 2
                assert members[0]["message"] == p.PRIMARY
                assert members[1]["message"] == p.SECONDARY
                assert p.PRIMARY in row["formatted_exception"]
                assert p.SECONDARY in row["formatted_exception"]
                rows.append(row)
    p.TracedEnd, p.RUN_ROOT = original, ROOT
    return rows


def math_checks():
    rows = []
    for cls in (SCAFFOLDUpdateStrategy, SCAFFOLDUpdateStrategyV2):
        for gradients in ([0], [3, 1]):
            root = ROOT / "math" / f"{cls.__name__}-{len(gradients)}"
            with p.adapter.configured(p.config(False), root):
                context = TrainingContext()
                context.model, context.client_id = p.Scalar(), 1
                strategy = cls()
                strategy.setup(context)
                strategy.client_control_variate = p.controls(1)
                context.state["server_control_variate"] = p.controls(2)
                strategy.on_train_start(context)
                optimizer = torch.optim.SGD(context.model.parameters(), lr=0.1)
                context.state["optimizer"] = optimizer
                strategy.before_step(context)
                y = F(1)
                for gradient in gradients:
                    (context.model.theta * gradient).sum().backward()
                    optimizer.step()
                    strategy.after_step(context)
                    optimizer.zero_grad()
                    y -= F(1, 10) * (F(gradient) - 1 + 2)
                strategy.on_train_end(context)
                strategy.on_train_cleanup(context, True)
                strategy.on_train_result_accepted(context)
                actual = {"y": context.model.theta.item(),
                          "ci": strategy.client_control_variate["theta"].item(),
                          "delta": strategy.get_update_payload(context)["control_variate_delta"]["theta"].item()}
                reference = {"y": str(y), "ci": str(sum(map(F, gradients)) / len(gradients)),
                             "delta": str(sum(map(F, gradients)) / len(gradients) - 1)}
                assert not p.numeric_checks(actual, reference, "math")
                assert strategy.local_steps == len(gradients)
                rows.append({"strategy": cls.__name__, "gradients": gradients,
                             "actual": actual, "independent_fraction_reference": reference})
    return rows


def replay_fresh(interface, existing, replace_failure=False):
    name = f"fresh-{interface}-prior{int(existing)}-replace{int(replace_failure)}"
    root = ROOT / name
    with p.adapter.configured(p.config(interface == "spawn"), root) as cfg:
        client = p.create_client(1)
        trainer, strategy = client.trainer, client.trainer.model_update_strategy
        strategy.client_control_variate = p.controls(1)
        trainer.context.state["server_control_variate"] = p.controls(2)
        canonical = Path(strategy.client_control_variate_path)
        if existing:
            canonical.write_bytes(pickle.dumps(p.controls(1)))
        before = canonical.read_bytes() if canonical.exists() else None
        strategy.trace_path = str(root / "events.jsonl")
        trainer.training_step_strategy = p.TracedEnd(strategy.trace_path, False)
        strategy.cleanup_failure = not replace_failure
        original_replace = os.replace
        def reject_replace(src, dst):
            if Path(dst) == canonical:
                raise OSError("Independent canonical replace failure")
            return original_replace(src, dst)
        if replace_failure:
            os.replace = reject_replace
        capture = p.Capture()
        try:
            try:
                if interface == "spawn":
                    p.train_round(client, 1, capture)
                else:
                    data = torch.utils.data.TensorDataset(torch.ones(2, 1).double(), torch.zeros(2, 1).double())
                    getattr(trainer, interface)({**cfg["trainer"], "run_id": name}, data, [0, 1])
            except BaseException as error:
                raised = exception_tree(error)
                displayed = traceback.format_exc()
            else:
                raise AssertionError("Injected failure accepted")
        finally:
            os.replace = original_replace
        snapshot = p.state_snapshot(strategy, trainer.context)
        assert snapshot["ci"] == 1.0
        assert not p.outbound(trainer)["eligible"]
        assert (canonical.read_bytes() if canonical.exists() else None) == before
        assert not snapshot["step_handle_present"] and not snapshot["strategy_optimizer_present"]
        assert not snapshot["complete_optimizer_step_present"] and not snapshot["optimizer_step_hooks_handled_present"]
        events = [json.loads(line) for line in (root / "events.jsonl").read_text().splitlines()]
        postrun = [e["successful"] for e in events if e["event"] == "cleanup_enter" and e["scope"] == "post_run"]
        strategy.trace_path = None
        strategy.cleanup_failure = False
        trainer.training_step_strategy = p.GradientAccumulationStepStrategy(1)
        trainer.context.state.pop("reviewer4_stage", None)
        for cid in (2, 1):
            client.client_id = client._context.client_id = cid
            client.configure()
        fresh = p.create_client(1)
        fresh_strategy = fresh.trainer.model_update_strategy
        assert fresh_strategy.client_control_variate is not None if existing else fresh_strategy.client_control_variate is None
        if not existing:
            strategy.client_control_variate = p.controls(1)
            fresh_strategy.client_control_variate = p.controls(1)
        else:
            assert fresh_strategy.client_control_variate["theta"].item() == 1.0
        retries = []
        # Both objects reconstructed their pre-failure state before either retry.
        for label, retry_client in (("reconstructed", fresh), ("reused", client)):
            cap = p.Capture()
            p.train_round(retry_client, 2, cap)
            actual = {"y": retry_client.trainer.model.theta.item(),
                      "ci": retry_client.trainer.model_update_strategy.client_control_variate["theta"].item(),
                      "delta": cap.payload[1]["theta"].item()}
            assert not p.numeric_checks(actual, p.scalar_oracle(1), label)
            assert cap.calls == 1 and cap.report.num_samples == 2
            retries.append({"kind": label, **actual})
        return {"id": name, "error_tree": raised, "formatted_exception": displayed,
                "prior_bytes_or_absence_preserved": True, "snapshot": snapshot,
                "post_run_cleanup_flags": postrun, "retry": retries,
                "events": events, "replace_failure": replace_failure}


class ServerFailure(ServerCallback):
    def __init__(self, mode):
        self.mode = mode
    def on_weights_received(self, server, weights):
        if self.mode == "post-receive-model":
            weights[1]["theta"].fill_(float("nan"))
    def on_weights_aggregated(self, server, updates):
        if self.mode == "aggregation-callback":
            raise RuntimeError("Independent aggregation callback failure")


def server_checks():
    rows = []
    for mode in ("raw-model", "post-receive-model", "aggregation-callback", "evaluation"):
        cfg = p.config(False)
        cfg["server"]["do_test"] = mode == "evaluation"
        with p.adapter.configured(cfg, ROOT / "server" / mode):
            server = scaffold_server.Server(model=p.Scalar, trainer=p.ProbeTrainer)
            server.init_trainer()
            server.context.trainer, server.context.algorithm = server.trainer, server.algorithm
            server.server_control_variate = p.controls(2)
            server.updates = [SimpleNamespace(
                report=SimpleNamespace(client_id=cid, num_samples=2, accuracy=0.0,
                                       training_time=0.0, comm_time=0.0),
                payload=[p.controls(y), p.controls(delta)])
                for cid, y, delta in ((1, 7, 3), (2, 9, 4))]
            if mode == "raw-model":
                server.updates[1].payload[0]["theta"].fill_(float("nan"))
            callback = ServerFailure(mode)
            server.callback_handler.add_callback(callback)
            handler = server.callback_handler
            raw = [p.serialize_tree(update.payload) for update in server.updates]
            if mode == "evaluation":
                def failed_evaluation(*args, **kwargs):
                    raise RuntimeError("Independent postcommit evaluation failure")
                server.trainer.test = failed_evaluation
            try:
                asyncio.run(server._process_reports())
            except (ValueError, RuntimeError) as error:
                raised = str(error)
            else:
                raise AssertionError("Injected server failure accepted")
            expected_x = F(8) if mode == "evaluation" else F(1)
            expected_c = F(13, 3) if mode == "evaluation" else F(2)
            assert abs(server.trainer.model.theta.item() - float(expected_x)) < 1e-12
            assert abs(server.server_control_variate["theta"].item() - float(expected_c)) < 1e-12
            assert server._pending_control_variate is None and server.received_client_control_variates is None
            assert server.callback_handler is handler
            assert raw == [p.serialize_tree(update.payload) for update in server.updates]
            rows.append({"mode": mode, "error": raised, "x": server.trainer.model.theta.item(),
                         "c": server.server_control_variate["theta"].item(),
                         "staging_cleared": True, "raw_inputs_unchanged": True})
    return rows


if __name__ == "__main__":
    result = {"source": str(p.SOURCE), "python": p.sys.version,
              "groups": group_checks(), "math": math_checks(), "fresh_retries": [],
              "server": server_checks()}
    for interface in ("train_model", "train_process", "spawn"):
        for existing in (False, True):
            result["fresh_retries"].append(replay_fresh(interface, existing))
    for interface in ("train_model", "train_process"):
        for existing in (False, True):
            result["fresh_retries"].append(replay_fresh(interface, existing, True))
    (ROOT / "supplement-results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"groups": len(result["groups"]), "math": len(result["math"]),
                      "fresh_retries": len(result["fresh_retries"]), "server": len(result["server"]),
                      "acceptance": "GREEN"}), flush=True)
