"""Read-only source binding for the reviewer4 standalone lifecycle probe."""

from __future__ import annotations

import contextlib
import copy
import hashlib
import inspect
import json
import os
import shlex
import subprocess
import sys
from pathlib import Path


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def git(source, *args):
    result = subprocess.run(
        ["zsh", "-lc", shlex.join(["git", "--no-optional-locks", *args])],
        cwd=source, capture_output=True, text=True, check=True,
    )
    return result.stdout.strip()


def manifest(source, commit, tree):
    source = Path(source).resolve(strict=True)
    actual_commit = git(source, "rev-parse", "HEAD")
    actual_tree = git(source, "rev-parse", "HEAD^{tree}")
    if (actual_commit, actual_tree) != (commit, tree):
        raise RuntimeError("Exact requested source commit/tree mismatch")
    tracked_status = git(source, "status", "--porcelain")
    if tracked_status:
        raise RuntimeError(f"Requested source has changes: {tracked_status}")
    status = git(source, "status", "--porcelain", "--ignored")
    ignored_names = git(source, "ls-files", "--others", "--ignored", "--exclude-standard", "-z").split("\0")
    ignored = [{"path": name, "sha256": digest(source / name)}
               for name in ignored_names if name and (source / name).is_file()]
    names = git(source, "ls-files", "-z").split("\0")
    entries = []
    for name in names:
        if not name:
            continue
        path = source / name
        if path.is_file():
            entries.append({"path": name, "bytes": path.stat().st_size,
                            "sha256": digest(path)})
    content_hash = hashlib.sha256(
        json.dumps(entries, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    return {"source": str(source), "commit": actual_commit, "tree": actual_tree,
            "status_including_ignored": status, "tracked_status": tracked_status,
            "preexisting_ignored_files": ignored, "tracked_file_count": len(entries),
            "manifest_sha256": content_hash, "files": entries}


def bind():
    """Called on initial import and real multiprocessing spawn re-import."""
    source = Path(os.environ["PLATO_PROBE_SOURCE"]).resolve(strict=True)
    run_root = Path(os.environ["PLATO_PROBE_RUN_ROOT"]).resolve(strict=True)
    if Path.cwd().resolve() != source:
        raise RuntimeError("Source cwd was not explicitly bound")
    if os.environ.get("PYTHONPATH") != str(source):
        raise RuntimeError("PYTHONPATH must name only the requested source")
    if os.environ.get("PYTHONDONTWRITEBYTECODE") != "1":
        raise RuntimeError("Read-only source requires disabled bytecode writes")
    cache_prefix = Path(os.environ["PYTHONPYCACHEPREFIX"]).resolve()
    if run_root not in cache_prefix.parents:
        raise RuntimeError("Bytecode reads must use only owned cache prefix")
    if source == run_root or source in run_root.parents:
        raise RuntimeError("Runtime scratch must be outside source")
    sys.path.insert(0, str(source))
    sys.path.insert(0, str(source / "examples/customized_client_training/scaffold"))
    config_path = Path(os.environ["config_file"])
    if run_root not in config_path.resolve().parents:
        raise RuntimeError("Configuration must remain under owned runtime scratch")
    sys.argv = [sys.argv[0], "-b", str(config_path.parent), "--cpu"]
    return source, run_root


def provenance(source, objects):
    result = []
    for obj in objects:
        path = Path(inspect.getfile(obj)).resolve(strict=True)
        if source not in path.parents:
            raise RuntimeError(f"Production import escaped source: {path}")
        result.append({"name": obj.__name__, "path": str(path),
                       "sha256": digest(path)})
    return result


@contextlib.contextmanager
def configured(config_dict, root):
    """Own Config sandbox; uses the real portable writer, no repo test helper."""
    from plato.config import Config
    from plato.utils import toml_writer

    def state(name, value):
        return not name.startswith("__") and not (
            callable(value) or isinstance(value, (classmethod, staticmethod))
        )

    previous = {name: value for name, value in vars(Config).items()
                if state(name, value)}
    old_config = os.environ.get("config_file")
    old_argv = sys.argv[:]
    root.mkdir(parents=True, exist_ok=False)
    cfg = copy.deepcopy(config_dict)
    cfg.setdefault("data", {})["data_path"] = "data"
    cfg["server"].update(model_path="models", checkpoint_path="checkpoints",
                         mpc_data_path="mpc")
    cfg.setdefault("results", {})["result_path"] = "results"
    config_path = root / "config.toml"
    toml_writer.dump(cfg, config_path)
    try:
        for name in previous:
            delattr(Config, name)
        Config._instance = None
        Config._cli_overrides = {}
        Config.client_sleep_times = None
        os.environ["config_file"] = str(config_path)
        sys.argv = [old_argv[0], "-b", str(root), "--cpu"]
        Config()
        Config.args.id = 0
        Path(Config.params["data_path"]).mkdir(parents=True, exist_ok=True)
        yield cfg
    finally:
        for name, value in list(vars(Config).items()):
            if state(name, value):
                delattr(Config, name)
        for name, value in previous.items():
            setattr(Config, name, value)
        if old_config is None:
            os.environ.pop("config_file", None)
        else:
            os.environ["config_file"] = old_config
        sys.argv = old_argv
