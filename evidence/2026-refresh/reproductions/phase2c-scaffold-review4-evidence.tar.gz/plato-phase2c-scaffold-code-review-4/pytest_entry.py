"""Bind Config/import origins before running a guarded focused pytest subset."""
import json
import os
from pathlib import Path

import source_adapter as adapter

SOURCE, RUN_ROOT = adapter.bind()

import pytest
from plato.config import Config
from plato.trainers.composable import ComposableTrainer
from plato.trainers.strategies.algorithms.scaffold_strategy import SCAFFOLDUpdateStrategy

Config()
origins = adapter.provenance(SOURCE, [Config, ComposableTrainer, SCAFFOLDUpdateStrategy])
(RUN_ROOT / "import-origins.json").write_text(json.dumps(origins, indent=2) + "\n")

if __name__ == "__main__":
    arguments = json.loads(os.environ["REVIEW4_PYTEST_ARGS"])
    raise SystemExit(pytest.main(arguments))
