"""Exercise unchanged mandatory prerequisite guards without repeating tests."""
import json
from pathlib import Path

import source_adapter as adapter

SOURCE, RUN_ROOT = adapter.bind()
import pytest
from plato.config import Config

Config()
arguments = ["tests/trainers/test_scaffold_strategy.py", "--test-profile", "mandatory",
             "--collect-only", "-q", "-o", f"cache_dir={RUN_ROOT / 'cache/pytest'}"]
code = pytest.main(arguments)
if code == 0:
    import nanochat.gpt
    path = Path(nanochat.gpt.__file__).resolve()
    assert path == SOURCE / "external/nanochat/nanochat/gpt.py"
    record = {"source": str(SOURCE), "nanochat_origin": str(path),
              "nanochat_sha256": adapter.digest(path), "mandatory_guard_exit_code": code,
              "qualification": "Prerequisite/collection validation only; tests not repeated"}
    (RUN_ROOT / "mandatory-guard.json").write_text(json.dumps(record, indent=2) + "\n")
raise SystemExit(code)
