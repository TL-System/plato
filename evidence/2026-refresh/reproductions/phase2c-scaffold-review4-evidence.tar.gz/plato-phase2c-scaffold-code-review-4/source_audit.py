"""Exact immutable source, accepted dependencies, fixtures and receipt audit."""
import hashlib
import json
import os
import shlex
import subprocess
from pathlib import Path

import source_adapter as adapter

SOURCE = Path("/tmp/plato-refresh-worktrees/training-final-review").resolve()
OWN = Path(__file__).resolve().parent
COMMIT = "13e38dafce476286db7e673e7f21343d54416b56"
TREE = "9fe8cfb039d0d97fc5b2c95a459de4c73c6d1b51"


def command(*args, cwd=SOURCE):
    return subprocess.run(["zsh", "-lc", shlex.join(list(args))], cwd=cwd,
                          capture_output=True, check=True).stdout


def entries(revision, *paths):
    result = {}
    for item in command("git", "--no-optional-locks", "ls-tree", "-rz", revision, "--", *paths).split(b"\0"):
        if item:
            meta, name = item.split(b"\t", 1)
            result[name.decode()] = meta.decode()
    return result


def artifact(path):
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": adapter.digest(path)}


def main():
    manifest = adapter.manifest(SOURCE, COMMIT, TREE)
    (OWN / "final-source-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    all_entries = entries(COMMIT)
    checked, errors = [], []
    for name, meta in all_entries.items():
        mode, kind, blob = meta.split()
        if kind == "commit":
            continue
        path = SOURCE / name
        data = os.readlink(path).encode() if mode == "120000" else path.read_bytes()
        calculated = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        if calculated != blob:
            errors.append(name)
        checked.append({"path": name, "git_entry": meta, "sha256": hashlib.sha256(data).hexdigest()})
    assert not errors, errors
    preserved = {}
    for label, baseline, revision in (
        ("A", "fda60becedfa6236c11d415b87a868b52789a41e", "79da1f97d8a12fe97402750cc32c7b3e8f5cdf6e"),
        ("D", "00eeb9dcdd2b513e64db9408969356037e09bb8e", "96323afa094a37584844275cc04bf1e1eedfaa0d"),
    ):
        names = command("git", "diff", "--name-only", "--no-renames", baseline, revision).decode().splitlines()
        names = [name for name in names if not name.startswith("evidence/")]
        reference = entries(revision)
        differences = [name for name in names if reference.get(name) != all_entries.get(name)]
        assert not differences, (label, differences)
        preserved[label] = {"revision": revision, "comparison_base": baseline,
                            "owned_non_evidence_paths": len(names), "paths": names,
                            "differences": differences}
    diffs = {}
    for label, revision in (
        ("baseline15e", "15e0cebd78ec6752b9aae1e922b33e22e168387f"),
        ("general-f977", "f9772f61d52dfe0f4a3281252d23b8303ec237d2"),
        ("B-resume", "a058a2ef8d230ca2e34dbf1c91e6eaac0b0205ac"),
        ("implementation7d", "7d310b90d698a7be4aa9a184dc415f7dbb401e5b"),
    ):
        path = OWN / f"candidate-vs-{label}.diff"
        path.write_bytes(command("git", "diff", "--binary", revision, COMMIT))
        diffs[label] = artifact(path)
    last_names = command("git", "diff", "--name-only", "7d310b90", COMMIT).decode().splitlines()
    assert all(name.startswith("evidence/") for name in last_names)
    general_paths = ["plato/trainers/base.py", "plato/trainers/strategies/training_step.py",
                     "plato/trainers/strategies/optimizer.py", "plato/trainers/strategies/algorithms/fedala_strategy.py",
                     "plato/trainers/strategies/algorithms/scaffold_strategy.py",
                     "examples/customized_client_training/scaffold/scaffold_server.py",
                     "examples/customized_client_training/scaffold/scaffold_callback.py",
                     "examples/customized_client_training/scaffold/scaffold_client.py",
                     "examples/customized_client_training/scaffold/scaffold_trainer.py",
                     "examples/customized_client_training/scaffold/scaffold_MNIST_lenet5.toml",
                     "plato/trainers/strategies/algorithms/fedprox_strategy.py"]
    # Server callback fix is already in 15e; remaining accepted sources in f977.
    general_reference = entries("f9772f61d52dfe0f4a3281252d23b8303ec237d2")
    scaffold_reference = entries("15e0cebd78ec6752b9aae1e922b33e22e168387f")
    for name in general_paths:
        reference = scaffold_reference if name.endswith("scaffold_server.py") else general_reference
        assert reference[name] == all_entries[name], name
    runtime_before = entries("05a9f00b8a4d54c233c1a9c00ef9ce2c4467480c", "plato", "examples", "configs", "tests/integration")
    runtime_after = entries(COMMIT, "plato", "examples", "configs", "tests/integration")
    assert runtime_before == runtime_after
    fixture = SOURCE / "tests/fixtures/feddyn_accepted_b.py"
    provenance = json.loads((SOURCE / "tests/fixtures/feddyn_accepted_b.provenance.json").read_text())
    historical = command("git", "show", "00eeb9dcdd2b513e64db9408969356037e09bb8e:plato/trainers/strategies/algorithms/feddyn_strategy.py")
    assert fixture.read_bytes() == historical
    assert adapter.digest(fixture) == provenance["source_sha256"]
    assert adapter.digest(SOURCE / "tests/fixtures/feddyn_accepted_b.LICENSE") == provenance["license_sha256"]
    receipt = json.loads((SOURCE / "evidence/2026-refresh/phase2c-feddyn-delivery-receipt.json").read_text())
    bound_evidence = []
    for name, expected in receipt["evidence_files"].items():
        path = SOURCE / "evidence/2026-refresh" / name
        assert path.stat().st_size == expected["bytes"] and adapter.digest(path) == expected["sha256"]
        assert all_entries["evidence/2026-refresh/" + name].split()[-1] == expected["git_blob"]
        bound_evidence.append(artifact(path))
    validation = json.loads((SOURCE / "evidence/2026-refresh/phase2c-feddyn-validation.json").read_text())
    log_receipts = []
    for section in (validation["profiles"], validation["runtime"]):
        values = list(section.values()) if isinstance(section, dict) else section
        pending = values[:]
        while pending:
            value = pending.pop()
            if isinstance(value, dict):
                if "log" in value and "sha256" in value:
                    path = Path(value["log"])
                    assert adapter.digest(path) == value["sha256"]
                    log_receipts.append(artifact(path))
                    if "junit" in value:
                        junit = value["junit"]
                        jp = Path(junit["path"])
                        assert adapter.digest(jp) == junit["sha256"]
                        log_receipts.append(artifact(jp))
                else:
                    pending.extend(value.values())
            elif isinstance(value, list):
                pending.extend(value)
    nanochat = SOURCE / "external/nanochat"
    pin = adapter.git(nanochat, "rev-parse", "HEAD")
    assert pin == "c75fe54aa7c1fa881701c246f9427bcbe4eee5a4"
    assert not adapter.git(nanochat, "status", "--porcelain")
    nano_manifest = []
    for name in adapter.git(nanochat, "ls-files", "-z").split("\0"):
        if name and (nanochat / name).is_file():
            nano_manifest.append({"path": name, "sha256": adapter.digest(nanochat / name)})
    result = {"commit": COMMIT, "tree": TREE, "source": str(SOURCE),
              "tracked_git_blobs_verified": len(checked), "git_blob_differences": errors,
              "manifest": artifact(OWN / "final-source-manifest.json"),
              "preserved_dependencies": preserved, "preserved_general_and_scaffold_paths": general_paths,
              "runtime_production_integration_paths_identical_since_05a9": len(runtime_before),
              "final_vs_7d_only_evidence": last_names, "diffs": diffs,
              "historical_fixture": artifact(fixture), "historical_fixture_git_blob": provenance["source_git_blob"],
              "bound_author_evidence": bound_evidence, "verified_author_logs_and_junits": log_receipts,
              "nanochat": {"pin": pin, "setup_transition": "Root initialized the unchanged gitlink during this review; earlier top-level source manifests did not include submodule content.",
                           "tracked_files": nano_manifest},
              "qualification_limit": "Author evidence hash/source attribution audit; no independent full-suite or fresh minimal-environment provisioning claim."}
    (OWN / "source-audit.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"blob_count": len(checked), "preserved": {k: v["owned_non_evidence_paths"] for k, v in preserved.items()},
                      "runtime_paths": len(runtime_before), "author_log_receipts": len(log_receipts), "nanochat": pin}, indent=2))


if __name__ == "__main__":
    main()
