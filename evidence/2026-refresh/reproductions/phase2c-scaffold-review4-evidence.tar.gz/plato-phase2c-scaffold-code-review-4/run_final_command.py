"""Source-verified, contained command receipts for this final bounded review."""
import argparse
import json
import os
import shlex
import signal
import subprocess
import time
import uuid
from pathlib import Path

import source_adapter as adapter

COMMIT = "13e38dafce476286db7e673e7f21343d54416b56"
TREE = "9fe8cfb039d0d97fc5b2c95a459de4c73c6d1b51"
SOURCE = Path("/tmp/plato-refresh-worktrees/training-final-review").resolve()
OWN = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--python", required=True)
    parser.add_argument("--label", required=True)
    parser.add_argument("--script", default=str(OWN / "pytest_entry.py"))
    parser.add_argument("--nodes", type=Path)
    parser.add_argument("--deadline", type=int, default=600)
    parser.add_argument("--archive-source", type=Path)
    parser.add_argument("--library-bytecode", action="store_true")
    args = parser.parse_args()
    source = args.archive_source.resolve() if args.archive_source else SOURCE
    root = OWN / "final-runs" / f"{args.label}-{uuid.uuid4().hex}"
    root.mkdir(parents=True)
    temporary = OWN / "t" / uuid.uuid4().hex[:8]
    temporary.mkdir()
    before = adapter.manifest(SOURCE, COMMIT, TREE)
    (root / "source-before.json").write_text(json.dumps(before, indent=2) + "\n")
    for directory in ("cache", "bootstrap", "mpl"):
        (root / directory).mkdir()
    bootstrap = root / "bootstrap/config.toml"
    bootstrap.write_bytes((source / "examples/customized_client_training/scaffold/scaffold_MNIST_lenet5.toml").read_bytes())
    overrides = {
        "PYTHONPATH": str(source), "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONPYCACHEPREFIX": str(root / "cache/pycache"), "TMPDIR": str(temporary),
        "XDG_CACHE_HOME": str(root / "cache"), "MPLCONFIGDIR": str(root / "mpl"),
        "TORCH_HOME": str(root / "cache/torch"), "HF_HOME": str(root / "cache/hf"),
        "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1",
        "VECLIB_MAXIMUM_THREADS": "1", "NUMEXPR_NUM_THREADS": "1", "PYTEST_ADDOPTS": "",
        "config_file": str(bootstrap), "PLATO_PROBE_SOURCE": str(source),
        "PLATO_PROBE_RUN_ROOT": str(root),
    }
    if args.library_bytecode:
        # Read-only installed-library caches are permitted. The dedicated
        # entrypoint requires zero source .pyc files before/after execution.
        overrides["PYTHONPYCACHEPREFIX"] = ""
    if args.nodes:
        nodes = json.loads(args.nodes.read_text())
        overrides["REVIEW4_PYTEST_ARGS"] = json.dumps([
            *nodes, "--test-profile", "base", "-q", "--basetemp", str(root / "pytest"),
            "--junitxml", str(root / "junit.xml"), "-o", f"cache_dir={root / 'cache/pytest'}",
        ])
    command = shlex.join([args.python, "-B", args.script])
    start = time.monotonic()
    print(json.dumps({"label": args.label, "root": str(root), "source": str(source),
                      "command": command}), flush=True)
    with open(root / "raw.log", "w") as stream:
        proc = subprocess.Popen(["zsh", "-lc", command], cwd=source,
                                env={**os.environ, **overrides}, stdout=stream,
                                stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = proc.wait(timeout=args.deadline)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
            code = 124
    after = adapter.manifest(SOURCE, COMMIT, TREE)
    (root / "source-after.json").write_text(json.dumps(after, indent=2) + "\n")
    unchanged = before == after
    receipt = {"label": args.label, "command": command, "shell": ["zsh", "-lc"],
               "cwd": str(source), "env_overrides": overrides, "exit_code": code,
               "duration_seconds": time.monotonic() - start, "deadline_seconds": args.deadline,
               "source_unchanged": unchanged, "source_manifest_sha256": before["manifest_sha256"],
               "script": {"path": args.script, "sha256": adapter.digest(args.script)},
               "raw_log": {"path": str(root / "raw.log"), "sha256": adapter.digest(root / "raw.log")}}
    receipt["library_bytecode_reads"] = args.library_bytecode
    if args.nodes:
        receipt["selected_nodes"] = nodes
        receipt["pytest_profile"] = "base focused subset in supplied existing environment"
        receipt["nodes_sha256"] = adapter.digest(args.nodes)
    (root / "execution.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"label": args.label, "exit_code": code, "source_unchanged": unchanged,
                      "duration_seconds": receipt["duration_seconds"], "root": str(root)}), flush=True)
    return code if unchanged else 3


if __name__ == "__main__":
    raise SystemExit(main())
