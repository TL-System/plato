import json
from pathlib import Path

for filename in ("preparation-receipt.json", "baseline-matrix.json", "source-audit.json", "portable-source-receipt.json"):
    d = json.loads(Path(filename).read_text())
    print(filename, list(d))
    for k, v in d.items():
        if k not in {"files", "profiles", "script_receipts", "runs", "bound_inputs", "accepted_dependency_preservation", "verified_author_logs_and_junits", "ignored_caches", "baseline_receipts"} and len(str(v)) < 1600:
            print(k, v)
d = json.loads(Path("final-runs/independent313-f0a2ccb285f6409aba794c60fd3960cf/supplement-results.json").read_text())
print("supplements", {k: len(v) if isinstance(v, list) else v for k, v in d.items()})
for k in ("groups", "math", "fresh_retries", "server"):
    if k in d:
        print(k, [v.get("id", v.get("mode")) for v in d[k]])
