"""Write only the authorized reviewer4 root report from verified own receipts."""
import json
from datetime import datetime, timezone
from pathlib import Path

import source_adapter as adapter
from qualify_receipts import COMMIT, OWN, SOURCE, TREE, artifact, read

ROOT = Path("/Users/bli/Playground/plato/evidence/2026-refresh")
DESTINATION = ROOT / "phase2c-scaffold-code-review-4.json"


def main():
    q = read(OWN / "final-qualification-receipt.json")
    prep = read(OWN / "preparation-receipt.json")
    audit = read(OWN / "source-audit.json")
    matrix = read(OWN / "final-lifecycle-matrix.json")
    baseline = read(OWN / "baseline-matrix.json")
    assert q["status"] == "QUALIFIED_BOUNDED"
    assert q["commit"] == COMMIT and q["tree"] == TREE
    assert adapter.manifest(SOURCE, COMMIT, TREE) == read(OWN / "final-source-manifest.json")
    assert not DESTINATION.exists(), "Preserve any existing root report instead of overwriting it."

    inputs = prep["inputs_verified"][:4] + [artifact(ROOT / name) for name in (
        "phase2c-scaffold-code-review.json", "phase2c-scaffold-code-review-2.json",
        "phase2c-general-acceptance.json", "phase2b-resume-acceptance.json",
    )]
    inputs += [artifact(SOURCE / "evidence/2026-refresh" / name) for name in (
        "phase2c-feddyn-validation.json", "phase2c-feddyn-facts.json",
        "phase2c-feddyn-delivery-receipt.json", "phase2c-validation.json",
    )]
    scripts = [artifact(OWN / name) for name in (
        "source_adapter.py", "lifecycle_probe.py", "run_probe.py", "validate_baseline.py",
        "write_receipt.py", "run_final_command.py", "pytest_entry.py",
        "pytest_library_cache_entry.py", "final_lifecycle_checks.py",
        "validate_final_matrix.py", "mandatory_guard_entry.py", "environment_entry.py",
        "source_audit.py", "qualify_receipts.py", "write_final_report.py",
    )]
    baseline_runs = []
    for name in (
        "plato-phase2c-313-20261003T092409Z-7229f56f429e4b0195b350a4dac026c5",
        "plato-phase2c-314-20261003T092409Z-1cb0cb24556a4c158c66452cdd2bfaa4",
    ):
        directory = OWN / "runs" / name
        baseline_runs.append({"execution": read(directory / "execution.json"),
                              "receipts": [artifact(directory / n) for n in ("execution.json", "raw.log", "acceptance-results.json", "source-before.json", "source-after.json")]})
    frozen_runs = []
    for profile in matrix["profiles"]:
        directory = Path(profile["source_results"]).parent
        frozen_runs.append({"execution": read(directory / "execution.json"),
                            "receipts": [artifact(directory / n) for n in ("execution.json", "raw.log", "acceptance-results.json", "source-before.json", "source-after.json")]})

    criteria_notes = {
        "A01": "Preserved corrected core/V2 source plus four new independent float64 real-SGD Fraction checks per version: g=0 gives y=.9, ci=0, delta=-1; g=[3,1] gives y=.4, ci=2, delta=1. Existing equation regressions pass. Baseline15e already has corrected math; its new red control is the cleanup acceptance boundary, not the pre-correction equation source.",
        "A02": "Actual shipped Config/optimizer factory tests at .1/.025, next-round LR, invalid rates/groups, scheduler boundaries and captured executed LR pass; unchanged SCAFFOLD rate-validation source reconciled with accepted review3.",
        "A03": "Parameter/buffer/frozen/excluded ownership, schema and finite-value tests pass; exact accepted SCAFFOLD strategy blob preserved. No source helper supplies the independent numeric expected values.",
        "A04": "Accumulation tails, real completed/skipped updates, empty rounds and V2 pass. Real CPU GradScaler success/overflow and clipping boundary tests pass; unscale-before-clip source preserved. No GPU qualification claimed.",
        "A05": "Independent canonical-present/absent end/cleanup and atomic replace failures retain prior bytes or absence and ci ownership; ordinary1->2->1 and fresh reconstruction remain correct. Ten additional cases per version execute successful retries on both reconstructed and reused trainers against .62/.9/-.1. Existing two-round ownership, path, historical-control and failure tests pass.",
        "A06": "Real inbound/train/outbound paths and actual multiprocessing spawn pass. Source orders end and successful cleanup before model save/export; child retains provisional controls, exports current token, parent validates token/client ID, loads model and controls, then accepts. Existing actual missing/stale/model-save/parent-commit failure subprocess tests pass and refuse stale outbound deltas. Frozen successful spawn event traces prove save/export/load/parent-accept order.",
        "A07": "Existing shipped public TOML two-round unequal/equal-count rational-oracle tests and actual processor/server wiring pass, including the same unchanged 60-second spawn test on3.14 after ordinary read-only installed-library cache use. Exact accepted SCAFFOLD model/client/server/oracle behavior preserved; independent additional scalar retry reference uses Fraction arithmetic.",
        "A08": "Fixed server raw/post-callback checks are byte-identical to15e. Existing malformed payload/sample/buffer/callback tests pass. Four new independent server cases each version reject raw NaN and post-receive NaN, restore known x=1/c=2 on aggregation callback failure, and retain committed x=8/c=13/3 on postcommit evaluation failure. Input tensors and staging/handler ownership checked.",
        "A09": "Existing real raw-optimizer momentum/Adam and V2 composition tests pass; source and shipped momentum=.9 TOML preserved. No optimizer-specific mean-gradient or convergence claim added.",
        "A10": "Exact commit/tree, actual imports, main/submodule hashes, preserved-source diffs, raw commands/versions/durations/configuration and focused JUnit inventories retained.186 distinct selected affected IDs have passing evidence each version;3.14 is185 original passes plus one unchanged passing retry. Scoped source Ruff import policy passes. Prior design/docs acceptance carried by source reconciliation; final prose/root acceptance remains root-owned.",
    }
    report = {
        "schema_version": 1,
        "date": datetime.now(timezone.utc).isoformat(),
        "role": "Fresh independent SCAFFOLD reviewer4; requested Sol xhigh; no nested agents.",
        "decision": "PASS",
        "acceptance": "PASS_BOUNDED",
        "finding": "F27",
        "summary": "Exact13e closes medium F27-R3-01: otherwise-successful direct training now completes fallible training-step end and real model-update cleanup before final acceptance. Independent present/absent canonical probes, actual direct/process/spawn flows and reconstructed/reused retries are green on3.13/3.14. Accepted SCAFFOLD and shared generic contracts are preserved within this review scope. No material finding; one optional low recommendation concerns repeated idempotent rejection cleanup after canonical-write failure.",
        "finding_counts": {"critical": 0, "high": 0, "medium": 0, "low": 1},
        "findings": [],
        "low_recommendations": [{
            "id": "F27-R4-L01", "severity": "low", "status": "OPTIONAL_RECOMMENDATION",
            "title": "Canonical acceptance-write failure dispatches rejection cleanup twice.",
            "accepted_criterion_fails": False,
            "primary_location": {"file": "plato/trainers/strategies/algorithms/scaffold_strategy.py", "line": 332},
            "supporting_locations": [{"file": "plato/trainers/composable.py", "line": 478}, {"file": "plato/trainers/composable.py", "line": 435}],
            "observed": "Inject OSError at actual os.replace for the canonical control file after otherwise-successful train/end/True cleanup. Strategy acceptance catches it and runs False cleanup; direct train_model or no-token train_process catches the same error and runs False cleanup again. Post-run flags are[True,False,False] in all four direct/process x present/absent cases each version. Initialization cleanup is excluded.",
            "impact": "No observed control corruption or accepted failure: exact prior canonical bytes/absence survive, ci returns to1, outbound is refused, optimizer/context handles are released, original OSError remains visible, and both reconstructed/reused retries equal .62/.9/-.1. This is redundant public cleanup dispatch, not a material lifecycle rejection failure.",
            "recommendation": "Consider assigning one owner for rejection after acceptance-write failure while retaining the same idempotent control discard and original error visibility. No broader transaction framework is requested.",
            "reproduction": {
                "script": artifact(OWN / "final_lifecycle_checks.py"),
                "command": "zsh -lc '/tmp/plato-phase2c-313/bin/python -B /tmp/plato-phase2c-scaffold-code-review-4/run_final_command.py --python /tmp/plato-phase2c-313/bin/python --label reproduce-rejection-owner --script /tmp/plato-phase2c-scaffold-code-review-4/final_lifecycle_checks.py'",
                "second_interpreter": "/tmp/plato-phase2c-314/bin/python",
                "case_ids": ["fresh-train_model-prior0-replace1", "fresh-train_model-prior1-replace1", "fresh-train_process-prior0-replace1", "fresh-train_process-prior1-replace1"],
                "evidence_runs": [q["runs"]["independent313"], q["runs"]["independent314"]],
            },
        }],
        "review_scope": {
            "included": ["Accepted F27 A01-A10 preservation", "Shared local end/cleanup/direct acceptance lifecycle", "Deferred worker/model-save/export/current-token/parent-load acceptance", "SCAFFOLD server raw and postcallback validation/known-state rollback boundary", "Four accepted general corrections and B selection-owned persistence/codec handoff preservation", "Portable actual historical FedDyn writer to explicit read-only migration reader contract"],
            "excluded": ["FedDyn full numerical algorithm, assigned to a separate reviewer", "Final source/prose or whole Phase2C acceptance, owned by root", "Fresh minimal base provisioning/full mandatory or runtime suite", "GPU, full optional stack, privacy-budget, convergence, full server/optimizer restart", "Killed process, arbitrary composed-plugin/external callback side effects, arbitrary custom code throwing after its own irreversible commit"],
        },
        "candidate": {
            "source": str(SOURCE), "commit": COMMIT, "tree": TREE,
            "tracked_status": "clean", "tracked_git_blobs_verified": audit["tracked_git_blobs_verified"],
            "source_manifest_sha256": q["source_manifest_sha256"],
            "manifest_file": audit["manifest"], "exact_diffs": audit["diffs"],
            "implementation_change": "Cleanup correction e33adcba7b5ca9fdee6fadfda395ab4d13d22e0a; final13e differs from7d310 only in four evidence JSON files.",
            "key_import_hashes": read(q["runs"]["environment313"]["receipts"]["environment.json"]["path"])["origins"],
            "initialized_submodule": {"path": str(SOURCE / "external/nanochat"), "gitlink": audit["nanochat"]["pin"], "tracked_files_verified": len(audit["nanochat"]["tracked_files"]), "known_setup_transition": audit["nanochat"]["setup_transition"], "qualification": "Final guards and receipt reconciliation bind initialized exact pin; HEAD/tree/tracked implementation unchanged; final submodule manifest preserved."},
        },
        "baseline_red_and_final_green": {
            "baseline": prep["baseline"],
            "preparation_receipt": artifact(OWN / "preparation-receipt.json"),
            "baseline_matrix": artifact(OWN / "baseline-matrix.json"),
            "frozen_matrix_definition": artifact(OWN / "acceptance-matrix.json"),
            "baseline_controls": prep["baseline_control_result"],
            "baseline_interpretation": "24 cases per version: otherwise-successful direct cleanup fails both prior-present/absent cases; direct success-order diagnostics also red. Deferred process/spawn and end-only rejection controls are green. Baseline implementation exits1; validate_baseline exit0 means expected red/green discrimination only, never a passing implementation.",
            "baseline_critical_observation": "After cleanup ran then raised, old direct train_model had already persisted ci1->.9 and enabled outbound; ordinary1->2->1/fresh reconstruction retained.9 and retry was .601/.895/-.005 instead of .62/.9/-.1. Raw model from the failed run was measured; this review does not require arbitrary model/plugin rollback beyond the demonstrated control/eligibility boundary.",
            "final_critical_observation": "Each direct/process/spawn cleanup-only case retains prior bytes or absence, returns ci1, denies outbound and releases optimizer/context handles. Ordinary1->2->1 and fresh reconstruction preserve only the pre-failure canonical state. Both reconstructed/reused successful retry probes yield .62/.9/-.1. Successful controls legitimately retain.9 and the next-round success reference is .601/.895/-.005.",
            "final_matrix": artifact(OWN / "final-lifecycle-matrix.json"),
            "final_required_green_per_interpreter": 24, "final_required_red_per_interpreter": 0,
            "axes": {"interfaces": ["train_model", "train_process", "real spawn"], "prior_canonical": ["absent", "present-ci1"], "faults": ["none", "end-only", "cleanup-only", "end-and-cleanup"]},
            "frozen_raw_exit_codes": [1, 1],
            "frozen_harness_limitation": "The original frozen exception collector follows cause/context but not ExceptionGroup members. Only direct end+cleanup present/absent falsely report secondary invisibility, two cases per version. Original script and raw exit1 evidence are preserved. Actual formatted tracebacks show both errors; strict validate_final_matrix accepts only those exact two collector errors and exits0. Eight additional actual group-member cases per version independently verify RuntimeError/KeyboardInterrupt primaries, secondary error, group identity and both public messages.",
            "exception_visibility": "Train-model and handoff rejection preserve primary/secondary errors through BaseExceptionGroup (auto ExceptionGroup when all members are Exceptions). Ordinary multiprocessing parent error remains a failed-worker ValueError; actual child traceback/events retain details. No demand for arbitrary external-side-effect rollback.",
            "cleanup_owner_disposition": "Original F27-R3-L01 end failure duplication is resolved: post-run end-only/both faults dispatch one False. Cleanup-only fault legitimately attempts one True then one False. Distinct initialization False is excluded. Residual acceptance-write duplication is optional F27-R4-L01, separately recorded.",
            "baseline_runs": baseline_runs, "final_frozen_runs": frozen_runs,
            "supplemental_live_checks_per_interpreter": q["supplements"],
        },
        "source_review": {
            "direct_acceptance": {"locations": [{"file": "plato/trainers/composable.py", "line": 457}, {"file": "plato/trainers/composable.py", "line": 461}, {"file": "plato/trainers/composable.py", "line": 465}, {"file": "plato/trainers/composable.py", "line": 467}], "finding": "Successful local training, exactly one fallible end attempt and successful model-update cleanup precede final direct acceptance. Exception path attempts rejection and finally clears step-dispatch context handles. Deferred flag skips acceptance while retaining provisional controls."},
            "process_owner": {"location": {"file": "plato/trainers/composable.py", "line": 430}, "finding": "model_finished differentiates failed train_model (which owns rejection) from later save/export/direct handoff failures (which train_process owns); useful primary/secondary errors grouped."},
            "worker_acceptance": {"location": {"file": "plato/trainers/composable.py", "line": 884}, "finding": "Require actual clean worker completion, current token and client identity, then model load, strategy state load, then parent acceptance. Failure paths refuse current-round outbound data; accepted files/controls survive failed-save/stale/missing/parent-commit tests."},
            "server_boundary": {"locations": [{"file": "examples/customized_client_training/scaffold/scaffold_server.py", "line": 70}, {"file": "examples/customized_client_training/scaffold/scaffold_server.py", "line": 138}, {"file": "examples/customized_client_training/scaffold/scaffold_server.py", "line": 170}, {"file": "examples/customized_client_training/scaffold/scaffold_server.py", "line": 175}], "finding": "Raw weights/controls validated before staging, postcallback batch checks run after receive/aggregation events. Commit is marked only after aggregation callbacks and final validation. Precommit exception restores known model/control tensors; evaluation/reporting after commit retains the committed round."},
        },
        "accepted_criteria": [{"id": key, "status": "PRESERVED_AND_AFFECTED_CHECKS_PASS", "evidence": value} for key, value in criteria_notes.items()],
        "preserved_generic_contracts": {
            "source_audit": artifact(OWN / "source-audit.json"),
            "A_and_D": {"audit": audit["preserved_dependencies"], "method_note": "Own git-diff comparison sets (A61,D45) include a broader set than root's named47A/44D preservation subsets; every path in each stated own set has identical exact git entry. No replacement of root's subset counts implied."},
            "four_general_f977": [
                {"contract": "AMP unscale before clip/overflow", "source": "plato/trainers/strategies/training_step.py", "result": "Exact accepted blob preserved; real CPU AMP clipping-success/overflow parameterized tests pass each version."},
                {"contract": "Complete owned suffix worker cleanup", "source": "plato/trainers/base.py", "result": "Exact accepted blob preserved; slash/long and unrelated-owner worker cleanup tests pass each version."},
                {"contract": "Actual old FedDyn writer compatibility", "source": "plato/trainers/strategies/algorithms/feddyn_strategy.py:662", "result": "Deliberately reconciled to explicit read_legacy_history reader. Byte-identical accepted00e writer fixture and license/provenance validated; four old writer/reader cases pass each version including no-Git source archive. Canonical precedence/same-client fallback/original bytes/read-only behavior preserved. No FedDyn numerical algorithm verdict."},
                {"contract": "Per-client FedALA save_state=False", "source": "plato/trainers/strategies/algorithms/fedala_strategy.py", "result": "Exact accepted blob preserved; real direct/spawn reused-versus-dedicated multiround memory-only tests pass each version."},
            ],
            "B_resume": "Accepted a058 shared server production diff contains authorized checkpoint filename/path codec handoff and related filename naming only; selector persistence/startup semantics are preserved. Whole tests/servers/test_server_resume_rng.py plus merged checkpoint runtime agreement pass on both versions. ROOT-2BC-01 now uses independent Random(9) reference and unrelated global draws, checks five resumed selections and separate NumPy persistence; no production RNG persistence redesign.",
            "portable_fixture": {"provenance": audit["historical_fixture"], "git_blob": audit["historical_fixture_git_blob"], "source_archive": artifact(OWN / "portable-source-receipt.json"), "post_test_reconciliation": q["portable_after_tests"], "cases_per_version": 4, "runs": [q["runs"]["portable313"], q["runs"]["portable314"]]},
        },
        "independent_affected_tests": {
            "selected_nodes": read(OWN / "affected-nodes.json"),
            "affected_test_ids": q["test_inventory"]["ids"],
            "counts": {"distinct_selected_ids_per_version": 186, "python313": q["test_inventory"]["python313"], "python314": q["test_inventory"]["python314"]},
            "runs": [q["runs"][name] for name in ("affected313", "affected314", "isolated-spawn314", "library-cache-spawn314")],
            "timeout_results_and_resolution": q["timeout_interpretation"],
            "warning_classification": q["notices"],
            "ruff": {"command": "zsh -lc '/tmp/plato-phase2c-313/bin/python -B -m ruff check --select I --cache-dir /tmp/plato-phase2c-scaffold-code-review-4/ruff-final plato/trainers/composable.py plato/servers/base.py tests/integration/test_scaffold_callback_lifecycle.py tests/integration/scaffold_cleanup_worker.py tests/integration/test_checkpoint_runtime_agreement.py tests/trainers/test_review_training_boundaries.py'", "cwd": str(SOURCE), "exit_code": 0, "receipt": artifact(OWN / "final-source-ruff.log"), "scope": "Repository import-order policy on changed shared/correction paths; no --fix/source mutation."},
        },
        "environment_receipts": [q["runs"]["environment313"], q["runs"]["environment314"]],
        "profile_limits": {
            "supplied_environments": "Existing3.13.16/3.14.8 macOS ARM64 CPU; torch2.14.1, numpy2.5.3, pytest9.1.1, Opacus1.6.0 installed. Full package versions and origins in hashed environment receipts. No installs/upgrades/profile guard weakening; SSL environments not used.",
            "base": "Focused --test-profile base affected subset in supplied existing environments, not freshly provisioned minimal base; root owns fresh true-base omission qualification.",
            "mandatory": "Unchanged mandatory startup prerequisite/profile guard and32-case collection checked on both versions after root initialized exact nanochat gitlink. Collection is not32 executed tests or a full mandatory-stack claim.",
            "mandatory_guard_runs": [q["runs"]["mandatory-guard313"], q["runs"]["mandatory-guard314"]],
            "author_carry_forward": {"attribution_only": True, "bound_evidence": audit["bound_author_evidence"], "verified_logs_and_junits": audit["verified_author_logs_and_junits"], "production_examples_configs_integration_git_entries_identical_05a9_to_final": audit["runtime_production_integration_paths_identical_since_05a9"], "description": "Receipt binds author final evidence; own broader768-entry source comparison contains author238-blob runtime subset. Author51 runtime cases each ran05a9 and full non-runtime reruns ran7d; final13e changes evidence only. These are carried author results, not independent reruns, not fresh minimal provisioning and not a whole-phase verdict."},
        },
        "receipts": {
            "inputs": inputs, "scratch_scripts": scripts,
            "prior_reviewer_scripts_preserved": prep["inputs_verified"][4:],
            "qualification": artifact(OWN / "final-qualification-receipt.json"),
            "qualification_log": artifact(OWN / "final-qualification.log"),
            "matrix_validation_log": artifact(OWN / "final-matrix-validation.log"),
            "scratch_root": str(OWN),
            "source_binding": "Every parent/worker command records exact immutable cwd/PYTHONPATH/import source origins. -B and disabled bytecode writes; caches/logs/configuration/short TMPDIR under owned unique roots. Final source and initialized nanochat tracked hashes preserved. Portable archive matches all1006 tracked files with no.git.",
        },
        "workflow": {"all_shell_commands": "zsh -lc", "nested_agents": 0, "agent_polling": 0, "author_live_worktree_reads": 0, "production_test_doc_edits": 0, "dependency_or_environment_mutations": 0, "commits_or_pushes": 0, "root_write": str(DESTINATION), "scratch_and_preparation_preserved": True},
        "bounded_verdict": "Independent SCAFFOLD/shared lifecycle correction and stated preservation scope PASS at exact13e/9fe8. F27-R3-01 closed by this review; original end/cleanup-owner low duplication corrected. One optional acceptance-write duplicate-cleanup recommendation remains without an accepted-criterion failure. Root owns final source/prose/phase acceptance; FedDyn numerical review is separate.",
    }
    DESTINATION.write_text(json.dumps(report, indent=2) + "\n")
    assert read(DESTINATION) == report
    receipt = {"status": "REPORT_WRITTEN", "report": artifact(DESTINATION),
               "decision": report["decision"], "acceptance": report["acceptance"],
               "commit": COMMIT, "tree": TREE, "finding_counts": report["finding_counts"]}
    (OWN / "final-report-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
