"""Reconcile preserved evidence, exact source, and distinct affected test IDs."""
import json
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

import source_adapter as adapter

OWN = Path(__file__).resolve().parent
SOURCE = Path("/tmp/plato-refresh-worktrees/training-final-review").resolve()
COMMIT = "13e38dafce476286db7e673e7f21343d54416b56"
TREE = "9fe8cfb039d0d97fc5b2c95a459de4c73c6d1b51"


def read(path):
    return json.loads(Path(path).read_text())


def artifact(path):
    path = Path(path).resolve()
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": adapter.digest(path)}


def run(label):
    matches = list((OWN / "final-runs").glob(label + "-*/execution.json"))
    assert len(matches) == 1, (label, matches)
    path = matches[0]
    receipt = read(path)
    assert receipt["source_unchanged"]
    assert adapter.digest(receipt["raw_log"]["path"]) == receipt["raw_log"]["sha256"]
    artifacts = {}
    for name in ("execution.json", "raw.log", "junit.xml", "import-origins.json", "source-before.json", "source-after.json", "supplement-results.json", "bytecode-policy.json", "environment.json", "mandatory-guard.json"):
        if (path.parent / name).is_file():
            artifacts[name] = artifact(path.parent / name)
    return {"label": label, "root": str(path.parent), "exit_code": receipt["exit_code"],
            "duration_seconds": receipt["duration_seconds"], "receipts": artifacts,
            "command": receipt["command"], "source_unchanged": True}


def junit(run_receipt):
    path = run_receipt["receipts"]["junit.xml"]["path"]
    root = ET.parse(path).getroot()
    rows = []
    for case in root.iter("testcase"):
        identity = case.attrib["classname"].replace(".", "/") + ".py::" + case.attrib["name"]
        state = "failed" if case.find("failure") is not None else "error" if case.find("error") is not None else "skipped" if case.find("skipped") is not None else "passed"
        rows.append({"id": identity, "status": state, "seconds": float(case.attrib["time"])})
    assert len({r["id"] for r in rows}) == len(rows)
    return rows


def main():
    prep = read(OWN / "preparation-receipt.json")
    for receipt in prep["inputs_verified"] + prep["own_scripts"] + prep["results"]:
        assert adapter.digest(receipt["path"]) == receipt["sha256"], receipt["path"]
    assert adapter.digest(OWN / "preparation-receipt.json") == "332062a1482758e9d28950a8e23de0c94e91d8d0e1a11e7a0e18cf567ad2d538"
    previous = read(OWN / "final-source-manifest.json")
    current = adapter.manifest(SOURCE, COMMIT, TREE)
    assert current == previous
    audit = read(OWN / "source-audit.json")
    nanochat = SOURCE / "external/nanochat"
    assert adapter.git(nanochat, "rev-parse", "HEAD") == audit["nanochat"]["pin"]
    assert not adapter.git(nanochat, "status", "--porcelain")
    for receipt in audit["nanochat"]["tracked_files"]:
        assert adapter.digest(nanochat / receipt["path"]) == receipt["sha256"]
    portable = read(OWN / "portable-source-receipt.json")
    portable_root = Path(portable["root"])
    assert not (portable_root / ".git").exists()
    assert not list(portable_root.rglob(".git"))
    assert adapter.digest(portable["archive"]) == portable["archive_sha256"]
    for entry in current["files"]:
        assert adapter.digest(portable_root / entry["path"]) == entry["sha256"], entry["path"]
    labels = ("affected313", "affected314", "isolated-spawn314", "library-cache-spawn314", "independent313", "independent314", "portable313", "portable314", "mandatory-guard313", "mandatory-guard314", "environment313", "environment314")
    runs = {label: run(label) for label in labels}
    rows313, rows314 = junit(runs["affected313"]), junit(runs["affected314"])
    retry = junit(runs["library-cache-spawn314"])
    assert len(rows313) == len(rows314) == 186
    assert all(r["status"] == "passed" for r in rows313)
    failures = [r for r in rows314 if r["status"] != "passed"]
    assert len(failures) == len(retry) == 1
    assert failures[0]["status"] == "failed"
    assert retry[0]["status"] == "passed" and failures[0]["id"] == retry[0]["id"]
    assert len(junit(runs["isolated-spawn314"])) == 1
    assert junit(runs["isolated-spawn314"])[0]["status"] == "failed"
    assert {r["id"] for r in rows313} == {r["id"] for r in rows314}
    policy = read(runs["library-cache-spawn314"]["receipts"]["bytecode-policy.json"]["path"])
    assert policy["source_bytecode_files_before_and_after"] == 0 and policy["dont_write_bytecode"] and policy["test_exit_code"] == 0
    for label in ("portable313", "portable314"):
        rows = junit(runs[label])
        assert len(rows) == 4 and all(r["status"] == "passed" for r in rows)
    supplements = {}
    for label in ("independent313", "independent314"):
        assert runs[label]["exit_code"] == 0
        d = read(runs[label]["receipts"]["supplement-results.json"]["path"])
        assert [len(d[k]) for k in ("groups", "math", "fresh_retries", "server")] == [8, 4, 10, 4]
        assert all(not r["required_failures"] and not r["recommendation_failures"] for r in d["groups"])
        replacements = [r for r in d["fresh_retries"] if r["replace_failure"]]
        assert len(replacements) == 4
        assert all(r["post_run_cleanup_flags"] == [True, False, False] for r in replacements)
        supplements[label] = {"groups": 8, "math": 4, "fresh_retries": 10, "server": 4,
                              "total": 26, "green": 26, "low_duplicate_replace_cleanup_cases": 4}
    matrix = read(OWN / "final-lifecycle-matrix.json")
    assert matrix["status"] == "GREEN"
    assert all(p["required_green"] == 24 and p["required_red"] == 0 for p in matrix["profiles"])
    for profile in matrix["profiles"]:
        data = read(profile["source_results"])
        assert adapter.digest(profile["source_results"]) == profile["source_results_sha256"]
        for case in data["cases"]:
            for event in case["events"]:
                if event["event"] == "process_enter":
                    assert event["source_cwd"] == event["source_pythonpath"] == str(SOURCE)
    result = {
        "timestamp": datetime.now(timezone.utc).isoformat(), "status": "QUALIFIED_BOUNDED",
        "commit": COMMIT, "tree": TREE, "source": str(SOURCE),
        "source_manifest_sha256": current["manifest_sha256"],
        "source_and_initialized_submodule_unchanged": True,
        "preparation_and_prior_reviewer_scripts_preserved": True,
        "portable_after_tests": {"all_tracked_files_match": len(current["files"]), "git_metadata_absent": True},
        "test_inventory": {
            "distinct_selected_ids_per_version": 186,
            "python313": {"single_run": {"passed": 186, "failed": 0, "skipped": 0}},
            "python314": {"initial_run": {"passed": 185, "failed": 1, "skipped": 0},
                           "isolated_cold_library_retry": {"passed": 0, "failed": 1},
                           "readonly_library_cache_retry": {"passed": 1, "failed": 0},
                           "distinct_ids_with_passing_evidence": 186, "unresolved_selected_ids": []},
            "ids": [r["id"] for r in rows313],
            "raw_rows313": rows313, "raw_rows314": rows314, "retry314": retry,
        },
        "supplements": supplements, "lifecycle_required_green_per_version": 24,
        "runs": runs,
        "timeout_interpretation": "Two 3.14 failures are retained: the same 60-second delivered spawn test timed out with all installed-library bytecode reads forced through an empty reviewer cache. It passed unchanged with ordinary read-only installed-library bytecode, no source bytecode, same immutable source/profile/assertions/deadline. This supports a harness cache-policy cost; it is not proof of blanket platform performance.",
        "notices": "One PytestAssertRewriteWarning about already-imported anyio per pytest run; reviewer bootstrap imports production before plugin startup. No warning filter or profile guard changed.",
    }
    (OWN / "final-qualification-receipt.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "distinct_affected_cases_per_version": 186,
                      "lifecycle_green_per_version": 24, "supplement_green_per_version": 26,
                      "source_unchanged": True, "portable_files": len(current["files"])}))


if __name__ == "__main__":
    main()
