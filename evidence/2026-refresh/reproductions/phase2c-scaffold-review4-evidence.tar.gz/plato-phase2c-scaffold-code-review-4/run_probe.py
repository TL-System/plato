"""Replay independent lifecycle assertions on an exact immutable source."""

from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import os
import shlex
import subprocess
import time
import uuid
from pathlib import Path

import source_adapter as adapter


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--commit", required=True)
    parser.add_argument("--tree", required=True)
    parser.add_argument("--python", required=True, type=Path)
    parser.add_argument("--scratch", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--deadline", type=int, default=600)
    parser.add_argument("--interfaces", nargs="+", choices=("train_model", "train_process", "spawn"),
                        default=["train_model", "train_process", "spawn"])
    args = parser.parse_args()
    source = args.source.resolve(strict=True)
    own = Path(__file__).resolve().parent
    scratch = args.scratch.resolve(strict=True)
    if source == scratch or source in scratch.parents:
        parser.error("Scratch must be outside source")
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    root = scratch / "runs" / f"{args.python.parent.parent.name}-{stamp}-{uuid.uuid4().hex}"
    root.mkdir(parents=True)
    # PyTorch's shared-memory manager uses an AF_UNIX path under TMPDIR.
    # Keep it short and unique while retaining it entirely in owned scratch.
    temp_root = scratch / "t" / uuid.uuid4().hex[:8]
    temp_root.mkdir(parents=True)
    before = adapter.manifest(source, args.commit, args.tree)
    (root / "source-before.json").write_text(json.dumps(before, indent=2) + "\n")
    for directory in ("tmp", "cache", "mpl", "ruff", "bootstrap"):
        (root / directory).mkdir()
    bootstrap = root / "bootstrap/config.toml"
    bootstrap.write_bytes((source / "examples/customized_client_training/scaffold/scaffold_MNIST_lenet5.toml").read_bytes())
    overrides = {
        "PYTHONDONTWRITEBYTECODE": "1", "PYTHONPATH": str(source),
        "PYTHONPYCACHEPREFIX": str(root / "cache/pycache"),
        "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "PYTEST_ADDOPTS": "",
        "TMPDIR": str(temp_root), "XDG_CACHE_HOME": str(root / "cache"),
        "MPLCONFIGDIR": str(root / "mpl"), "RUFF_CACHE_DIR": str(root / "ruff"),
        "config_file": str(bootstrap), "PLATO_PROBE_SOURCE": str(source),
        "PLATO_PROBE_RUN_ROOT": str(root), "PLATO_PROBE_INTERFACES": json.dumps(args.interfaces),
    }
    env = {**os.environ, **overrides}
    command = shlex.join([str(args.python), "-B", str(own / "lifecycle_probe.py")])
    start = time.monotonic()
    print(json.dumps({"runtime_root": str(root), "source": str(source), "command": command}), flush=True)
    with open(root / "raw.log", "w") as log:
        proc = subprocess.Popen(["zsh", "-lc", command], cwd=source, env=env,
                                stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            code = proc.wait(timeout=args.deadline)
        except subprocess.TimeoutExpired:
            import signal
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
            code = 124
    after = adapter.manifest(source, args.commit, args.tree)
    (root / "source-after.json").write_text(json.dumps(after, indent=2) + "\n")
    unchanged = before == after
    execution = {"command": command, "shell": ["zsh", "-lc"], "cwd": str(source),
                 "env_overrides": overrides, "exit_code": code,
                 "duration_seconds": time.monotonic() - start,
                 "deadline_seconds": args.deadline, "source_unchanged": unchanged,
                 "source_manifest_sha256": before["manifest_sha256"],
                 "script_hashes": {name: adapter.digest(own / name) for name in (
                     "source_adapter.py", "lifecycle_probe.py", "run_probe.py")},
                 "raw_log": str(root / "raw.log"), "raw_log_sha256": adapter.digest(root / "raw.log"),
                 "acceptance_results": str(root / "acceptance-results.json")}
    if (root / "acceptance-results.json").exists():
        execution["acceptance_results_sha256"] = adapter.digest(root / "acceptance-results.json")
    (root / "execution.json").write_text(json.dumps(execution, indent=2) + "\n")
    print(json.dumps(execution, indent=2))
    return code if unchanged else 3


if __name__ == "__main__":
    raise SystemExit(main())
