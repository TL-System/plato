"""Produce the bounded reviewer4 preparation receipt in owned scratch only."""

from __future__ import annotations

import datetime
import json
import platform
from pathlib import Path

import source_adapter as adapter


def artifact(path):
    path = Path(path).resolve(strict=True)
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": adapter.digest(path)}


def main():
    own = Path(__file__).resolve().parent
    root_evidence = Path("/Users/bli/Playground/plato/evidence/2026-refresh")
    inputs = [
        (Path("/Users/bli/Playground/plato/AGENTS.md"),
         "b50f87f31ea3d87076952d8b7d2d8af067132fbf877d80f8780c208fb45527ec"),
        (root_evidence / "phase2c-scaffold-design.json",
         "f323f3aa9d824df44a1043b2d6aff9c8a963c42964f6e6685108c59b25fc3a89"),
        (root_evidence / "phase2c-scaffold-acceptance.json",
         "40b202708a4cfdbe6f299e75249c1a19921e410ec4ab7b5e3c6323f536ca8d37"),
        (root_evidence / "phase2c-scaffold-code-review-3.json",
         "63d4969b6bff08e51bde979eb3d8ac61289ca539e1332b3ac96a8ceeda6010dd"),
        (Path("/tmp/plato-phase2c-scaffold-code-review-3/reproduce_cleanup_failure.py"),
         "fc554616f81a72ac11d0f85e9c040481678f4a4c3d5196865fb6e59464f675ea"),
        (Path("/tmp/plato-phase2c-scaffold-code-review-3/cleanup_acceptance_probe.py"),
         "b70a501db6c586bab917ac6541afc3d08e016697b210ff099db42a9b6a0399a7"),
        (Path("/tmp/plato-phase2c-scaffold-code-review-3/independent_checks.py"),
         "720e78a5cf4e04bf4278f5eb5495bdfe5f1b93b36ab0a8ebe663964f875f1651"),
    ]
    input_artifacts = []
    for path, expected in inputs:
        value = artifact(path)
        assert value["sha256"] == expected, path
        input_artifacts.append(value)
    matrix = json.loads((own / "baseline-matrix.json").read_text())
    profiles = []
    grouped = {}
    for profile in matrix["profiles"]:
        result_path = Path(profile["artifacts"][0]["path"])
        execution = json.loads((result_path.parent / "execution.json").read_text())
        for name, recorded_hash in execution["script_hashes"].items():
            assert adapter.digest(own / name) == recorded_hash, name
        profiles.append({key: profile[key] for key in (
            "python", "duration_seconds", "acceptance_exit_code", "source_unchanged",
            "tracked_file_count", "preexisting_ignored_file_count", "manifest_sha256",
            "required_red_cases", "required_green_cases", "functional_red_cases",
            "functional_green_cases", "low_recommendation_cases", "artifacts")})
        for case in json.loads(result_path.read_text())["cases"]:
            key = (case["interface"], case["end_failure"], case["cleanup_failure"])
            grouped.setdefault(key, []).append(case)
    rows = []
    for (interface, end, cleanup), cases in grouped.items():
        assert len(cases) == 4
        calls = [[event["successful"] for event in c["post_run_cleanup"]] for c in cases]
        assert all(sequence == calls[0] for sequence in calls)
        axes = "end-and-cleanup" if end and cleanup else "end-only" if end else "cleanup-only" if cleanup else "success"
        first = cases[0]
        rows.append({"interface": interface, "axes": axes,
                     "prior_file_states": ["absent", "present-ci1"], "interpreters": ["3.13.16", "3.14.8"],
                     "cases": 4, "required_red": sum(bool(c["required_failures"]) for c in cases),
                     "low_duplicate_cleanup": sum(bool(c["recommendation_failures"]) for c in cases),
                     "post_run_cleanup_flags": calls[0],
                     "initialization_cleanup_excluded": True,
                     "baseline_ci": round(first["observed"]["ci"], 12),
                     "baseline_outbound_eligible": first["observed"]["outbound"]["eligible"],
                     "baseline_prior_bytes_or_absence_preserved": first["observed"]["canonical_preserved"],
                     "baseline_retry": {k: round(first["retry"][k], 12) for k in ("y", "ci", "delta")},
                     "expected_retry": first["retry_reference"],
                     "baseline_summary": (
                         "RED F27-R3-01: failed direct cleanup persisted .9 and contaminated retry"
                         if interface == "train_model" and cleanup and not end else
                         "GREEN success math/persistence; RED direct acceptance before cleanup"
                         if interface == "train_model" and not end and not cleanup else
                         "GREEN required acceptance; LOW F27-R3-L01 duplicate post-run False cleanup"
                         if interface != "train_model" and end else
                         "GREEN required acceptance")})
    compact = {"status": "READY", "purpose": "Preparation; baseline controls only",
               "baseline_commit": matrix["baseline"]["commit"],
               "baseline_tree": matrix["baseline"]["tree"], "rows": rows,
               "total_cases": 48, "required_red": 8, "required_green": 40,
               "functional_red": 4, "ordering_only_red": 4, "low_recommendation_cases": 16,
               "harness_errors": 0, "acceptance_exit_codes": [1, 1],
               "harness_validation_exit_code": 0,
               "interpretation": "Validation exit0 confirms expected red/green discrimination; it does not accept the implementation."}
    (own / "acceptance-matrix.json").write_text(json.dumps(compact, indent=2) + "\n")
    failed_spawn_runs = []
    for path in sorted((own / "runs").glob("*091602*/execution.json")):
        evidence = json.loads(path.read_text())
        failed_spawn_runs.append({"execution": artifact(path), "exit_code": evidence["exit_code"],
                                  "result": "8 harness errors before child training; AF_UNIX TMPDIR too long"})
    receipt = {
        "schema_version": 1, "status": "READY", "stage": "Bounded reviewer4 harness preparation",
        "date": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "completed_candidate_supplied": False, "final_code_verdict_issued": False,
        "root_report_written": False,
        "baseline": {**matrix["baseline"], "source": profiles and matrix["profiles"][0]["source"],
                     "cwd_and_pythonpath_explicitly_bound": True,
                     "all_tracked_files_and_preexisting_ignored_caches_unchanged": True},
        "inputs_verified": input_artifacts,
        "own_scripts": [artifact(own / name) for name in (
            "source_adapter.py", "lifecycle_probe.py", "run_probe.py", "validate_baseline.py", "write_receipt.py")],
        "results": [artifact(own / name) for name in (
            "acceptance-matrix.json", "baseline-matrix.json", "baseline-validation.log", "ruff-check.log")],
        "profiles": profiles,
        "baseline_control_result": {
            "cases_per_interpreter": 24, "implementation_acceptance_exit_per_interpreter": 1,
            "otherwise_successful_direct_cleanup_red_per_interpreter": 2,
            "direct_success_ordering_red_per_interpreter": 2,
            "required_green_per_interpreter": 20,
            "low_duplicate_post_run_false_cleanup_per_interpreter": 8,
            "known_defect_retry": [0.601, 0.895, -0.005], "required_rejection_retry": [0.62, 0.9, -0.1],
            "success_reference": "31/50, 9/10, -1/10 from independent Fraction arithmetic",
            "visible_primary_and_secondary_errors": "Both messages verified in real formatted caller/child tracebacks; ordinary multiprocessing parent errors remain generic.",
            "harness_validation_exit_code": 0, "harness_errors_in_final_runs": 0,
            "ruff_import_check": "exit0, target-version py313"},
        "harness_adaptations": {
            "preexisting_baseline_bytecode": "Initial guard rejected ignored preexisting caches. Preserve and hash them; read imports through a unique empty PYTHONPYCACHEPREFIX with -B.",
            "spawn_tmpdir": "Initial long TMPDIR failed before training. Short unique own t/<uuid8> roots resolved it; all original failed attempts are retained.",
            "failed_spawn_runs": failed_spawn_runs,
            "scratch_import_formatting": "Preserved pre-format script copies, sorted scratch imports, reran all24 cases on each interpreter on the frozen final script hashes."},
        "replay": {
            "entrypoint": str(own / "run_probe.py"),
            "arguments": "--source IMMUTABLE_PATH --commit FULL_COMMIT --tree FULL_TREE --python /tmp/plato-phase2c-313/bin/python",
            "second_interpreter": "/tmp/plato-phase2c-314/bin/python",
            "shell": ["zsh", "-lc"], "deadline_seconds": 600,
            "exit_semantics": {"0": "All required lifecycle acceptance assertions green",
                               "1": "Required lifecycle acceptance assertions red",
                               "2": "Harness/runtime error", "3": "Source changed", "124": "Deadline exceeded"},
            "low_recommendations": "Recorded separately; do not manufacture a medium defect from duplicate idempotent rejection cleanup.",
            "source_adapter": "Checks exact clean commit/tree, import provenance, cwd/PYTHONPATH and before/after manifests; writes only unique owned scratch."},
        "limits": [
            "Preparation validates known-failing 15e only. No completed C source has been read or reviewed.",
            "macOS ARM64 CPU, scalar float64 quadratic, two real SGD updates, actual direct/train_process and spawned client processor/report paths. No network, download, GPU, benchmark or convergence qualification.",
            "End-only and cleanup-only axes are independent. Cleanup fault runs actual public cleanup then raises once; prior canonical bytes and absent canonical state both exercised.",
            "Raw local model values are measured; rejected update eligibility/control durability is asserted. No arbitrary callback/plugin external side-effect or irreversible custom-commit rollback is required.",
            "No killed-process atomicity, full server/optimizer restart, broader transaction framework or persistence redesign.",
            "Model-save/current-token/parent-load failure ordering, server callback preservation, portable historical writer and accepted general/shared contracts await final source reconciliation and a coherent affected subset. The 282-test suite was not rerun.",
            "FedDyn is another reviewer's scope. Accepted A01-A10/math and prior resolved findings are not reopened here; ROOT-2BC-01 selection-owned RNG alignment is final generic preservation scope."],
        "needed_followup": [
            "Exact committed completed C candidate full commit and tree plus immutable checkout path or exact archive path/hash.",
            "Integration base/diff and correction receipts identifying the lifecycle fix and merged B resume supplement/general fixes, so final preservation can be reconciled."],
        "workflow": {"nested_agents": 0, "agent_polling": 0, "repository_source_test_doc_edits": 0,
                     "root_writes": 0, "environment_installs_or_mutations": 0,
                     "prior_reviewer_scripts_unchanged": True, "scratch_retained": True,
                     "all_shell_commands": "zsh -lc"},
    }
    destination = own / "preparation-receipt.json"
    destination.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"status": "READY", "receipt": artifact(destination),
                      "probe": artifact(own / "lifecycle_probe.py"),
                      "adapter": artifact(own / "source_adapter.py"),
                      "matrix": artifact(own / "acceptance-matrix.json")}, indent=2))


if __name__ == "__main__":
    main()
