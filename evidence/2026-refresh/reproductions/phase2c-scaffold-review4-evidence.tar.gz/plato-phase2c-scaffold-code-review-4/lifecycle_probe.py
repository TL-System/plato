"""Independent F27 lifecycle acceptance assertions; never a final code verdict.

Run via run_probe.py to bind an exact source, contained scratch, and a deadline.
The only fault injection runs the REAL cleanup and then raises once. No source
or delivered test helper is patched or imported. Instrumentation is spawn-safe.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import math
import os
import pickle
import sys
import tomllib
import traceback
from collections import OrderedDict
from fractions import Fraction
from pathlib import Path

import source_adapter as adapter

SOURCE, RUN_ROOT = adapter.bind()

import scaffold_callback
import scaffold_client
import scaffold_trainer
import torch
from plato.config import Config
from plato.serialization.safetensor import deserialize_tree, serialize_tree
from plato.trainers.composable import ComposableTrainer
from plato.trainers.strategies.algorithms.scaffold_strategy import (
    SCAFFOLDUpdateStrategy,
)
from plato.trainers.strategies.loss_criterion import DefaultLossCriterionStrategy
from plato.trainers.strategies.training_step import GradientAccumulationStepStrategy

PRIMARY = "reviewer4 primary training-step end failure"
SECONDARY = "reviewer4 secondary after-real-cleanup failure"


def controls(value):
    return OrderedDict(theta=torch.tensor([value], dtype=torch.float64))


class Scalar(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.theta = torch.nn.Parameter(torch.tensor([1.0], dtype=torch.float64))

    def forward(self, inputs):
        return inputs * self.theta


def quadratic(outputs, labels):
    return ((outputs - labels) ** 2).mean() / 2


def scalar_oracle(old_ci):
    """Exact independent Algorithm1/Eqs3-5, quadratic target0, x1/c2/K2."""
    x = y = Fraction(1)
    c, ci, eta = Fraction(2), Fraction(str(old_ci)), Fraction(1, 10)
    gradients = []
    for _ in range(2):
        gradient = y
        gradients.append(gradient)
        y -= eta * (gradient - ci + c)
    new_ci = ci - c + (x - y) / (2 * eta)
    assert new_ci == sum(gradients) / 2
    return {"y": str(y), "ci": str(new_ci), "delta": str(new_ci - ci),
            "K": 2, "eta": str(eta), "gradients": list(map(str, gradients))}


def exception_evidence(exc):
    result, seen = [], set()
    while exc is not None and id(exc) not in seen:
        seen.add(id(exc))
        result.append({"type": type(exc).__name__, "message": str(exc),
                       "suppress_context": exc.__suppress_context__,
                       "notes": getattr(exc, "__notes__", [])})
        exc = exc.__cause__ or exc.__context__
    return result


def record(trace_path, event, **data):
    if trace_path is not None:
        with open(trace_path, "a") as stream:
            stream.write(json.dumps({"pid": os.getpid(), "event": event,
                                     **data}, sort_keys=True) + "\n")


def state_snapshot(strategy, context):
    path = Path(strategy.client_control_variate_path)
    optimizer = context.state.get("optimizer")
    value = strategy.client_control_variate
    return {
        "ci": None if value is None else value["theta"].item(),
        "model": context.model.theta.item(),
        "canonical_exists": path.exists(),
        "canonical_sha256": adapter.digest(path) if path.exists() else None,
        "delta_present": "client_control_variate_delta" in context.state,
        "result_accepted": getattr(strategy, "_result_accepted", None),
        "pending_controls": getattr(strategy, "_has_pending_controls", None),
        "step_handle_present": getattr(strategy, "_step_hook", None) is not None,
        "strategy_optimizer_present": getattr(strategy, "_optimizer", None) is not None,
        "optimizer_pre_hooks": len(optimizer._optimizer_step_pre_hooks)
            if optimizer is not None else 0,
        "complete_optimizer_step_present": "complete_optimizer_step" in context.state,
        "optimizer_step_hooks_handled_present": "optimizer_step_hooks_handled" in context.state,
    }


class TracedControls(SCAFFOLDUpdateStrategy):
    def __init__(self):
        super().__init__()
        self.trace_path = None
        self.cleanup_failure = False
        self.cleanup_faults = 0

    def on_train_start(self, context):
        context.state["reviewer4_stage"] = "initialization"
        record(self.trace_path, "model_start")
        return super().on_train_start(context)

    def on_train_end(self, context):
        context.state["reviewer4_stage"] = "model_end"
        record(self.trace_path, "model_end_enter")
        result = super().on_train_end(context)
        record(self.trace_path, "model_end_return", state=state_snapshot(self, context))
        return result

    def on_train_cleanup(self, context, successful):
        stage = context.state.get("reviewer4_stage", "initialization")
        scope = "post_run" if stage in ("model_end", "step_end") else "initialization"
        record(self.trace_path, "cleanup_enter", scope=scope,
               successful=successful, stage=stage)
        result = super().on_train_cleanup(context, successful)
        record(self.trace_path, "cleanup_real_return", scope=scope,
               successful=successful, state=state_snapshot(self, context))
        if scope == "post_run" and self.cleanup_failure and self.cleanup_faults == 0:
            self.cleanup_faults += 1
            record(self.trace_path, "cleanup_injected_exception", successful=successful)
            raise RuntimeError(SECONDARY)
        record(self.trace_path, "cleanup_return", scope=scope, successful=successful)
        return result

    def on_train_result_accepted(self, context):
        record(self.trace_path, "accept_enter", state=state_snapshot(self, context))
        result = super().on_train_result_accepted(context)
        record(self.trace_path, "accept_return", state=state_snapshot(self, context))
        return result

    def get_worker_state(self, context):
        record(self.trace_path, "worker_state_export")
        return super().get_worker_state(context)

    def load_worker_state(self, state, context):
        record(self.trace_path, "worker_state_load")
        return super().load_worker_state(state, context)


class TracedEnd(GradientAccumulationStepStrategy):
    def __init__(self, trace_path, end_failure):
        super().__init__(1)
        self.trace_path = trace_path
        self.end_failure = end_failure
        self.end_calls = 0

    def on_train_start(self, context):
        record(self.trace_path, "step_start")
        return super().on_train_start(context)

    def on_train_end(self, context):
        self.end_calls += 1
        context.state["reviewer4_stage"] = "step_end"
        record(self.trace_path, "step_end_enter", calls=self.end_calls)
        result = super().on_train_end(context)
        if self.end_failure:
            record(self.trace_path, "step_end_injected_exception")
            raise RuntimeError(PRIMARY)
        record(self.trace_path, "step_end_return")
        return result


class ProbeTrainer(scaffold_trainer.Trainer):
    def __init__(self, model=None, callbacks=None):
        super().__init__(model=model, callbacks=callbacks)
        self.loss_strategy = DefaultLossCriterionStrategy(quadratic)
        self.loss_strategy.setup(self.context)
        self.model_update_strategy = TracedControls()
        self.model_update_strategy.setup(self.context)

    def save_model(self, filename=None, location=None):
        trace_path = self.model_update_strategy.trace_path
        record(trace_path, "save_enter")
        result = super().save_model(filename, location)
        record(trace_path, "save_return")
        return result

    def train_process(self, config, trainset, sampler, **kwargs):
        strategy = self.model_update_strategy
        record(strategy.trace_path, "process_enter", token=config.get("worker_state_token"),
               source_cwd=str(Path.cwd()), source_pythonpath=os.environ.get("PYTHONPATH"))
        try:
            result = super().train_process(config, trainset, sampler, **kwargs)
        except BaseException as exc:
            record(strategy.trace_path, "process_exception",
                   chain=exception_evidence(exc), formatted=traceback.format_exc())
            raise
        else:
            record(strategy.trace_path, "process_return")
            return result
        finally:
            record(strategy.trace_path, "process_final", state=state_snapshot(strategy, self.context))


class Capture:
    def __init__(self):
        self.calls = 0
        self.report = self.payload = None

    async def send_report_and_payload(self, context, report, payload):
        self.calls += 1
        self.report, self.payload = report, deserialize_tree(payload)


def create_client(cid):
    client = scaffold_client.create_client(
        model=Scalar, trainer=ProbeTrainer, callbacks=[scaffold_callback.ScaffoldCallback]
    )
    client.client_id = client._context.client_id = cid
    client.configure()
    return client


def train_round(client, round_id, capture):
    client.current_round = client._context.current_round = round_id
    data = torch.utils.data.TensorDataset(
        torch.ones(2, 1, dtype=torch.float64), torch.zeros(2, 1, dtype=torch.float64)
    )
    client._context.trainset = data
    client._context.sampler = torch.utils.data.SequentialSampler(data)
    asyncio.run(client.payload_strategy.handle_server_payload(
        client._context, serialize_tree([controls(1), controls(2)]),
        training=client.training_strategy, reporting=client.reporting_strategy,
        communication=capture,
    ))


def config(spawn):
    path = SOURCE / "examples/customized_client_training/scaffold/scaffold_MNIST_lenet5.toml"
    cfg = tomllib.loads(path.read_text())
    cfg["clients"].update(total_clients=3, per_round=2)
    cfg["server"].update(do_test=False, random_seed=29)
    cfg["trainer"].update(model_name="reviewer4/org/model", batch_size=6, epochs=2)
    if not spawn:
        cfg["trainer"].pop("max_concurrency")
    cfg["parameters"]["optimizer"].update(lr=0.1, momentum=0.0)
    return cfg


def outbound(trainer):
    processor = scaffold_callback.SendControlVariateProcessor(1, trainer)
    try:
        payload = processor.process(trainer.model.state_dict())
        return {"eligible": True, "delta": payload[1]["theta"].item(), "error": None}
    except Exception as exc:
        return {"eligible": False, "delta": None, "error": str(exc)}


def numeric_checks(observed, reference, prefix):
    issues = []
    for key in ("y", "ci", "delta"):
        if observed.get(key) is None or not math.isclose(
            observed[key], float(Fraction(reference[key])), rel_tol=0, abs_tol=1e-12
        ):
            issues.append(f"{prefix}.{key}: expected {reference[key]}, got {observed.get(key)}")
    return issues


def run_case(interface, existing, end_failure, cleanup_failure):
    name = f"{interface}-prior{int(existing)}-end{int(end_failure)}-cleanup{int(cleanup_failure)}"
    root = RUN_ROOT / "cases" / name
    trace_path = root / "events.jsonl"
    expected_failure = end_failure or cleanup_failure
    with adapter.configured(config(interface == "spawn"), root) as cfg:
        client = create_client(1)
        trainer, strategy = client.trainer, client.trainer.model_update_strategy
        strategy.client_control_variate = controls(1)
        trainer.context.state["server_control_variate"] = controls(2)
        canonical = Path(strategy.client_control_variate_path)
        if existing:
            canonical.write_bytes(pickle.dumps(controls(1)))
        before = canonical.read_bytes() if canonical.exists() else None
        before_hash = adapter.digest(canonical) if canonical.exists() else None
        strategy.trace_path = str(trace_path)
        strategy.cleanup_failure = cleanup_failure
        trainer.training_step_strategy = TracedEnd(str(trace_path), end_failure)
        capture, chain, formatted = Capture(), [], None
        error = None
        try:
            if interface == "spawn":
                train_round(client, 1, capture)
            else:
                data = torch.utils.data.TensorDataset(
                    torch.ones(2, 1, dtype=torch.float64), torch.zeros(2, 1, dtype=torch.float64)
                )
                getattr(trainer, interface)(
                    {**cfg["trainer"], "run_id": name}, data,
                    torch.utils.data.SequentialSampler(data),
                )
        except BaseException as exc:
            error = f"{type(exc).__name__}: {exc}"
            chain, formatted = exception_evidence(exc), traceback.format_exc()
        observed = state_snapshot(strategy, trainer.context)
        observed["outbound"] = outbound(trainer)
        observed["canonical_preserved"] = (
            canonical.read_bytes() if canonical.exists() else None
        ) == before
        observed["persisted_ci"] = (
            pickle.loads(canonical.read_bytes())["theta"].item() if canonical.exists() else None
        )
        events = [json.loads(line) for line in trace_path.read_text().splitlines()]
        postrun = [event for event in events if event["event"] == "cleanup_enter"
                   and event["scope"] == "post_run"]
        init = [event for event in events if event["event"] == "cleanup_enter"
                and event["scope"] == "initialization"]
        process_errors = [event for event in events if event["event"] == "process_exception"]
        exception_text = json.dumps({"caller": chain, "process": process_errors})
        required, recommendation = [], []

        def require(condition, message):
            if not condition:
                required.append(message)

        require(bool(error) == bool(expected_failure), "Caller failure/success differs from injected axes")
        require(sum(event["event"] == "step_end_enter" for event in events) == 1,
                "Training-step end hook must run once")
        require(sum(event["event"] == "model_end_return" for event in events) == 1,
                "Real model-update end must finish once before injected failure")
        if expected_failure:
            require(observed["ci"] == 1.0, "Rejected call advanced memory ci")
            require(observed["canonical_preserved"], "Rejected call changed prior canonical bytes/absence")
            require(not observed["outbound"]["eligible"], "Rejected call remains outbound eligible")
            require(not observed["pending_controls"], "Rejected call retained pending controls")
            require(not observed["delta_present"], "Rejected call retained outbound delta")
            require(not any(event["event"] == "accept_enter" for event in events),
                    "Local failed end/cleanup reached canonical acceptance")
            if end_failure:
                require(PRIMARY in exception_text, "Primary end error is not visible")
            if cleanup_failure:
                require(SECONDARY in exception_text, "Secondary cleanup error is not visible")
            if interface == "spawn":
                require(capture.calls == 0, "Failed spawned training sent a report/payload")
        else:
            required.extend(numeric_checks(
                {"y": observed["model"], "ci": observed["ci"],
                 "delta": observed["outbound"]["delta"]}, scalar_oracle(1), "success"
            ))
            require(observed["outbound"]["eligible"], "Successful call is not outbound eligible")
            require(observed["canonical_exists"], "Successful call did not persist canonical controls")
            require(observed["persisted_ci"] == observed["ci"], "Persisted and memory ci differ")
            names = [event["event"] for event in events]
            require(names.count("accept_return") == 1, "Successful result must be accepted once")
            if "accept_enter" in names:
                require(names.index("step_end_return") < names.index("accept_enter"),
                        "Accepted before training-step end returned")
                cleanup_returns = [i for i, event in enumerate(events)
                                   if event["event"] == "cleanup_return"
                                   and event["scope"] == "post_run"]
                require(bool(cleanup_returns) and max(cleanup_returns) < names.index("accept_enter"),
                        "Accepted before fallible local cleanup returned")
            if interface == "spawn":
                require(capture.calls == 1 and capture.report.num_samples == 2,
                        "Successful real spawn did not send exactly one two-sample report")
                worker_pids = {event["pid"] for event in events if event["event"] == "process_enter"}
                require(worker_pids and os.getpid() not in worker_pids, "Spawn did not use a real child")
                require(any(event["event"] == "worker_state_export" for event in events),
                        "Spawn did not export provisional controls")
                require(any(event["event"] == "worker_state_load" for event in events),
                        "Parent did not load worker controls")

        require(not observed["step_handle_present"] and not observed["strategy_optimizer_present"]
                and observed["optimizer_pre_hooks"] == 0, "Optimizer hook/strategy handle leaked")
        require(not observed["complete_optimizer_step_present"]
                and not observed["optimizer_step_hooks_handled_present"], "Transient context handles leaked")
        for event in events:
            if event["event"] == "process_final":
                state = event["state"]
                require(not state["step_handle_present"] and not state["strategy_optimizer_present"]
                        and state["optimizer_pre_hooks"] == 0, "Child optimizer handles leaked")
                require(not state["complete_optimizer_step_present"]
                        and not state["optimizer_step_hooks_handled_present"], "Child context handles leaked")
        false_counts = {}
        for event in postrun:
            if not event["successful"]:
                false_counts[event["pid"]] = false_counts.get(event["pid"], 0) + 1
        if any(count > 1 for count in false_counts.values()):
            recommendation.append("F27-R3-L01: repeated post-run False cleanup for the same local failure")

        # Disable observation/fault injection before ordinary configure/retry.
        strategy.trace_path = None
        strategy.cleanup_failure = False
        trainer.context.state.pop("reviewer4_stage", None)
        reuse = []
        for cid in (2, 1):
            client.client_id = client._context.client_id = cid
            client.configure()
            value = strategy.client_control_variate
            reuse.append({"client_id": cid, "ci": None if value is None else value["theta"].item()})
        fresh = create_client(1).trainer.model_update_strategy.client_control_variate
        fresh_ci = None if fresh is None else fresh["theta"].item()
        expected_ci = 1.0 if expected_failure else float(Fraction(scalar_oracle(1)["ci"]))
        if expected_failure and not existing:
            require(fresh_ci is None and reuse[-1]["ci"] is None,
                    "Absent rejected state contaminated reuse/reconstruction")
        else:
            require(fresh_ci is not None and math.isclose(fresh_ci, expected_ci, abs_tol=1e-12),
                    "Fresh reconstruction adopted unexpected accepted controls")
            require(reuse[-1]["ci"] is not None and math.isclose(reuse[-1]["ci"], expected_ci, abs_tol=1e-12),
                    "Ordinary 1->2->1 reuse adopted unexpected accepted controls")
        # An absent file cannot remember manually supplied unaccepted ci=1.
        # Only restore the original manual ci when ordinary reuse found no file.
        if strategy.client_control_variate is None:
            strategy.client_control_variate = controls(1)
        trainer.training_step_strategy = GradientAccumulationStepStrategy(1)
        retry_capture = Capture()
        train_round(client, 2, retry_capture)
        retry = {"y": trainer.model.theta.item(),
                 "ci": strategy.client_control_variate["theta"].item(),
                 "delta": retry_capture.payload[1]["theta"].item(),
                 "report_samples": retry_capture.report.num_samples,
                 "send_calls": retry_capture.calls}
        retry_reference = scalar_oracle(1 if expected_failure else "0.9")
        required.extend(numeric_checks(retry, retry_reference, "retry"))
        require(retry_capture.calls == 1 and retry_capture.report.num_samples == 2,
                "Successful retry did not send exactly one two-sample report")
        return {"id": name, "interface": interface, "existing": existing,
                "end_failure": end_failure, "cleanup_failure": cleanup_failure,
                "expected_failure": bool(expected_failure), "error": error,
                "exception_chain": chain, "formatted_exception": formatted,
                "prior_sha256": before_hash, "observed": observed,
                "initialization_cleanup_count": len(init),
                "post_run_cleanup": [{"pid": e["pid"], "successful": e["successful"]} for e in postrun],
                "post_run_false_counts_per_pid": false_counts,
                "reuse": reuse, "fresh_ci": fresh_ci, "retry": retry,
                "retry_reference": retry_reference, "events": events,
                "required_failures": required, "recommendation_failures": recommendation,
                "configured_overrides": cfg}


def main():
    provenance = adapter.provenance(SOURCE, [
        Config, ComposableTrainer, SCAFFOLDUpdateStrategy,
        scaffold_trainer.Trainer, scaffold_client.create_client,
        scaffold_callback.ScaffoldCallback, serialize_tree, GradientAccumulationStepStrategy,
    ])
    cases, harness_errors = [], []
    interfaces = json.loads(os.environ.get("PLATO_PROBE_INTERFACES", '["train_model", "train_process", "spawn"]'))
    for interface in interfaces:
        for existing in (False, True):
            for end, cleanup in ((False, False), (True, False), (False, True), (True, True)):
                try:
                    case = run_case(interface, existing, end, cleanup)
                    cases.append(case)
                    print(json.dumps({"case": case["id"],
                                      "required_failures": len(case["required_failures"]),
                                      "recommendations": len(case["recommendation_failures"])}), flush=True)
                except BaseException as exc:
                    harness_errors.append({"interface": interface, "existing": existing,
                                           "end_failure": end, "cleanup_failure": cleanup,
                                           "error": str(exc), "traceback": traceback.format_exc()})
                    print(json.dumps(harness_errors[-1]), flush=True)
    result = {"purpose": "Bounded acceptance probe, not final source review", "python": sys.version,
              "executable": sys.executable, "source": str(SOURCE), "cwd": str(Path.cwd()),
              "pythonpath": os.environ["PYTHONPATH"], "runtime_root": str(RUN_ROOT),
              "provenance": provenance, "independent_reference": scalar_oracle(1),
              "success_next_round_reference": scalar_oracle("0.9"),
              "cases": cases, "harness_errors": harness_errors,
              "required_red_cases": sum(bool(c["required_failures"]) for c in cases),
              "required_green_cases": sum(not c["required_failures"] for c in cases),
              "low_recommendation_cases": sum(bool(c["recommendation_failures"]) for c in cases)}
    (RUN_ROOT / "acceptance-results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in (
        "required_red_cases", "required_green_cases", "low_recommendation_cases")}), flush=True)
    return 2 if harness_errors else 1 if result["required_red_cases"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
