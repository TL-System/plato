"""Re-evaluate frozen evidence using public ExceptionGroup traceback visibility."""
import argparse
import json
from pathlib import Path

import source_adapter as adapter

PRIMARY = "reviewer4 primary training-step end failure"
SECONDARY = "reviewer4 secondary after-real-cleanup failure"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", nargs=2, type=Path, required=True)
    args = parser.parse_args()
    profiles = []
    for path in args.results:
        data = json.loads(path.read_text())
        execution = json.loads((path.parent / "execution.json").read_text())
        assert data["source"] == str(Path("/tmp/plato-refresh-worktrees/training-final-review").resolve())
        assert len(data["cases"]) == 24 and not data["harness_errors"]
        assert execution["source_unchanged"]
        evaluated, corrected = [], []
        for case in data["cases"]:
            visible = (case["formatted_exception"] or "") + "\n".join(
                event["formatted"] for event in case["events"] if event["event"] == "process_exception"
            )
            remaining = case["required_failures"][:]
            if remaining:
                # Accept only this demonstrated collector defect, using the
                # actual public formatted traceback and actual group identity.
                assert case["interface"] == "train_model"
                assert case["end_failure"] and case["cleanup_failure"]
                assert remaining == ["Secondary cleanup error is not visible"]
                assert case["exception_chain"][0]["type"] == "ExceptionGroup"
                assert PRIMARY in visible and SECONDARY in visible
                remaining = []
                corrected.append(case["id"])
            if case["end_failure"]:
                assert PRIMARY in visible
            if case["cleanup_failure"]:
                assert SECONDARY in visible
            assert not remaining, (case["id"], remaining)
            assert not case["recommendation_failures"]
            evaluated.append({"id": case["id"], "required_acceptance": "GREEN",
                              "cleanup_flags": [e["successful"] for e in case["post_run_cleanup"]],
                              "canonical_preserved": case["observed"]["canonical_preserved"],
                              "ci": case["observed"]["ci"], "outbound_eligible": case["observed"]["outbound"]["eligible"],
                              "fresh_ci": case["fresh_ci"], "retry": case["retry"]})
        assert len(corrected) == 2
        profiles.append({"python": data["python"], "frozen_raw_exit_code": execution["exit_code"],
                         "frozen_collector_false_positive_ids": corrected,
                         "public_traceback_assertion_exit_code": 0,
                         "required_green": 24, "required_red": 0, "duplicate_end_cleanup_cases": 0,
                         "source_results": str(path), "source_results_sha256": adapter.digest(path),
                         "cases": evaluated})
    result = {"status": "GREEN", "interpretation": "All original lifecycle criteria satisfied; only group-member visibility collection was corrected.",
              "preserved_frozen_probe_sha256": adapter.digest(Path(__file__).parent / "lifecycle_probe.py"),
              "live_group_member_checks": "8 additional actual direct/process cases each Python verify RuntimeError and KeyboardInterrupt members and both displayed messages.",
              "profiles": profiles}
    destination = Path(__file__).resolve().parent / "final-lifecycle-matrix.json"
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": "GREEN", "cases_per_python": 24,
                      "raw_frozen_exit_codes": [p["frozen_raw_exit_code"] for p in profiles],
                      "evaluated_assertion_exit_codes": [0, 0], "matrix": str(destination)}, indent=2))


if __name__ == "__main__":
    main()
