"""Read installed bytecode, forbid source bytecode, retain every profile guard."""
import json
import os
import sys
from pathlib import Path

import source_adapter as adapter

SOURCE = Path(os.environ["PLATO_PROBE_SOURCE"]).resolve()
RUN_ROOT = Path(os.environ["PLATO_PROBE_RUN_ROOT"]).resolve()
assert Path.cwd().resolve() == SOURCE
assert os.environ["PYTHONPATH"] == str(SOURCE)
assert sys.dont_write_bytecode and sys.pycache_prefix is None
assert not list(SOURCE.rglob("*.pyc")), "Cannot read cached source bytecode"
sys.path.insert(0, str(SOURCE))
sys.path.insert(0, str(SOURCE / "examples/customized_client_training/scaffold"))
config_path = Path(os.environ["config_file"]).resolve()
assert RUN_ROOT in config_path.parents
sys.argv = [sys.argv[0], "-b", str(config_path.parent), "--cpu"]

import pytest
from plato.config import Config
from plato.trainers.composable import ComposableTrainer
from plato.trainers.strategies.algorithms.scaffold_strategy import SCAFFOLDUpdateStrategy

Config()
origins = adapter.provenance(SOURCE, [Config, ComposableTrainer, SCAFFOLDUpdateStrategy])
(RUN_ROOT / "import-origins.json").write_text(json.dumps(origins, indent=2) + "\n")
code = pytest.main(json.loads(os.environ["REVIEW4_PYTEST_ARGS"]))
assert not list(SOURCE.rglob("*.pyc")), "Source bytecode was created"
(RUN_ROOT / "bytecode-policy.json").write_text(json.dumps({
    "source_bytecode_files_before_and_after": 0, "installed_library_caches": "read-only",
    "source_cwd": str(SOURCE), "pythonpath": os.environ["PYTHONPATH"],
    "dont_write_bytecode": sys.dont_write_bytecode, "test_exit_code": code,
}, indent=2) + "\n")
raise SystemExit(code)
