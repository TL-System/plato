"""Independent actual trainer cleanup acceptance and duplicate-call probe."""
import json,pickle,sys
from pathlib import Path
import independent_checks as p
import torch
from plato.trainers.strategies.training_step import GradientAccumulationStepStrategy

class Ending(GradientAccumulationStepStrategy):
    def __init__(self, fail):
        super().__init__(1); self.calls=0; self.fail=fail
    def on_train_end(self,ctx):
        self.calls+=1; super().on_train_end(ctx)
        if self.fail: raise RuntimeError('Primary end failure')

def run(root,interface,existing,end_failure,cleanup_failure):
    with p.configure_environment(p.config(),runtime_root=root):
        client=p.client(1); tr=client.trainer; st=tr.model_update_strategy
        st.client_control_variate=p.controls(1)
        tr.context.state['server_control_variate']=p.controls(2)
        canonical=Path(st.client_control_variate_path)
        if existing: canonical.write_bytes(pickle.dumps(p.controls(1)))
        before=canonical.read_bytes() if existing else None
        ending=tr.training_step_strategy=Ending(end_failure)
        cleanup=st.on_train_cleanup; calls=[]
        def recording_cleanup(ctx,successful):
            calls.append(dict(successful=successful,end_calls=ending.calls))
            cleanup(ctx,successful)
            if cleanup_failure and ending.calls: raise RuntimeError('Secondary cleanup failure')
        st.on_train_cleanup=recording_cleanup
        data=torch.utils.data.TensorDataset(torch.ones(2,1,dtype=torch.float64),torch.zeros(2,1,dtype=torch.float64))
        error=None; chain=[]
        try: getattr(tr,interface)({**p.config()['trainer'],'run_id':'independent-cleanup'},data,torch.utils.data.SequentialSampler(data))
        except Exception as exc:
            error=f'{type(exc).__name__}: {exc}'
            cursor=exc
            while cursor:
                chain.append(f'{type(cursor).__name__}: {cursor}')
                cursor=cursor.__cause__ or cursor.__context__
        try:
            payload=st.get_update_payload(tr.context); outbound_error=None
        except Exception as exc:
            payload=None;outbound_error=str(exc)
        persisted=pickle.loads(canonical.read_bytes())['theta'].item() if canonical.exists() else None
        record=dict(interface=interface,existing=existing,end_failure=end_failure,cleanup_failure=cleanup_failure,error=error,exception_chain=chain,ci=st.client_control_variate['theta'].item(),persisted_ci=persisted,canonical_preserved=(canonical.read_bytes() if canonical.exists() else None)==before,outbound_eligible=payload is not None,outbound_error=outbound_error,end_calls=ending.calls,cleanup_calls=calls,optimizer_hook_registered=bool(tr.optimizer._optimizer_step_pre_hooks),context_clean=all(k not in tr.context.state for k in ['complete_optimizer_step','optimizer_step_hooks_handled']))
        st.on_train_cleanup=cleanup
        for cid in [2,1]:
            client.client_id=client._context.client_id=cid;client.configure()
        fresh=p.client(1).trainer.model_update_strategy.client_control_variate
        record['reconstructed_ci']=fresh['theta'].item() if fresh else None
        if fresh is None:st.client_control_variate=p.controls(1)
        tr.training_step_strategy=GradientAccumulationStepStrategy(1)
        retry=p.train_round(client,[p.controls(1),p.controls(2)],2,0.,2)
        record['retry']=dict(y=tr.model.theta.item(),ci=st.client_control_variate['theta'].item(),delta=retry.payload[1]['theta'].item())
        return record

if __name__=='__main__':
    v=f'{sys.version_info.major}{sys.version_info.minor}'
    records=[]
    for interface in ['train_model','train_process']:
        for existing in [False,True]:
            for end_failure,cleanup_failure in [(False,True),(True,False),(True,True)]:
                root=p.SCRATCH/f'cleanup-{v}'/f'{interface}-{existing}-{end_failure}-{cleanup_failure}'
                root.mkdir(parents=True,exist_ok=True)
                records.append(run(root,interface,existing,end_failure,cleanup_failure))
    result=dict(python=sys.version,cases=records,interpretation='Observations recorded without defect-as-pass assertions.')
    (p.SCRATCH/f'cleanup-{v}.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
