"""Independent numerical oracles and live example wiring; no production edits."""
import asyncio
import copy
import json
import logging
import os
import pickle
import platform
import sys
import tomllib
from collections import OrderedDict
from fractions import Fraction as F
from pathlib import Path
from types import SimpleNamespace

REQUESTED_MODE=sys.argv[1] if len(sys.argv)>1 and sys.argv[1] in ('normal','spawn') else 'normal'
if len(sys.argv)>1 and sys.argv[1] in ('normal','spawn'):
    sys.argv.pop(1)
CANDIDATE = Path('/private/tmp/plato-refresh-worktrees/scaffold-review3')
SCRATCH = Path('/tmp/plato-phase2c-scaffold-code-review-3')
BOOTSTRAP=SCRATCH/('bootstrap-'+''.join(platform.python_version_tuple()[:2]))
BOOTSTRAP.mkdir(parents=True,exist_ok=True)
(BOOTSTRAP/'config.toml').write_text((CANDIDATE/'examples/customized_client_training/scaffold/scaffold_MNIST_lenet5.toml').read_text())
if not os.environ.get('config_file'):
    os.environ['config_file']=str(BOOTSTRAP/'config.toml')
    sys.argv=[sys.argv[0],'-b',str(BOOTSTRAP),'--cpu']

import torch
from torch.utils.data import TensorDataset

sys.path.insert(0, str(CANDIDATE/'examples/customized_client_training/scaffold'))
import scaffold_callback
import scaffold_client
import scaffold_server
import scaffold_trainer
from plato.config import Config
from plato.serialization.safetensor import deserialize_tree, serialize_tree
from plato.trainers.composable import ComposableTrainer
from plato.trainers.strategies.algorithms.scaffold_strategy import (
    SCAFFOLDUpdateStrategy, SCAFFOLDUpdateStrategyV2,
)
from plato.trainers.strategies.base import TrainingContext, TrainingStepStrategy
from plato.trainers.strategies.loss_criterion import DefaultLossCriterionStrategy
from plato.trainers.strategies.training_step import GradientAccumulationStepStrategy
from tests.integration.utils import configure_environment

TRACE=[]
class Scalar(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.theta = torch.nn.Parameter(torch.tensor([1.0],dtype=torch.float64))
    def forward(self,x):
        return x*self.theta

def controls(v):
    return OrderedDict(theta=torch.tensor([v],dtype=torch.float64))

def quadratic(outputs, labels):
    TRACE.append(float((outputs.detach()-labels).mean()))
    return ((outputs-labels)**2).mean()/2

class RecordingTrainer(scaffold_trainer.Trainer):
    def __init__(self,model=None,callbacks=None):
        super().__init__(model=model,callbacks=callbacks)
        self.loss_strategy=DefaultLossCriterionStrategy(quadratic)
        self.loss_strategy.setup(self.context)
    def train_process(self,config,trainset,sampler,**kwargs):
        TRACE.clear()
        super().train_process(config,trainset,sampler,**kwargs)
        p=Path(Config().params['model_path'])/f'gradient-trace-{self.client_id}-{self.current_round}.json'
        p.write_text(json.dumps(dict(gradients=TRACE,worker_token=config.get('worker_state_token'),
            ci=self.model_update_strategy.client_control_variate['theta'].item(),
            delta=self.context.state['client_control_variate_delta']['theta'].item(),
            K=self.model_update_strategy.local_steps,eta=self.model_update_strategy.learning_rate,
            y=self.model.theta.item()),indent=2)+'\n')

def config(spawn=False, rate=.1):
    p=CANDIDATE/'examples/customized_client_training/scaffold/scaffold_MNIST_lenet5.toml'
    cfg=tomllib.loads(p.read_text())
    cfg['clients'].update(total_clients=3,per_round=2)
    cfg['server'].update(do_test=False,random_seed=29)
    cfg['trainer'].update(model_name='org/model',batch_size=6,epochs=2)
    if not spawn: cfg['trainer'].pop('max_concurrency')
    cfg['parameters']['optimizer'].update(lr=rate,momentum=0.0)
    return cfg

class Capture:
    async def send_report_and_payload(self,context,report,payload):
        self.report,self.payload=report,deserialize_tree(payload)

def client(cid):
    c=scaffold_client.create_client(model=Scalar,trainer=RecordingTrainer,
                                   callbacks=[scaffold_callback.ScaffoldCallback])
    c.client_id=c._context.client_id=cid
    c.configure()
    return c

def train_round(c,payload,rid,target,count):
    c.current_round=c._context.current_round=rid
    c._context.trainset=TensorDataset(torch.ones(count,1,dtype=torch.float64),
                                    torch.full((count,1),target,dtype=torch.float64))
    c._context.sampler=torch.utils.data.SequentialSampler(c._context.trainset)
    cap=Capture()
    asyncio.run(c.payload_strategy.handle_server_payload(c._context,serialize_tree(payload),
        training=c.training_strategy,reporting=c.reporting_strategy,communication=cap))
    assert cap.report.num_samples==count
    return SimpleNamespace(report=cap.report,payload=cap.payload)

def server():
    s=scaffold_server.Server(model=Scalar,trainer=RecordingTrainer)
    s.init_trainer()
    s.context.trainer,s.context.algorithm=s.trainer,s.algorithm
    return s

def oracle(equal=False):
    x,c,eta=F(1),F(2),F(1,10)
    ci={1:F(1),2:F(3),3:F(2)}
    target={1:F(0),2:F(2),3:F(-1)}
    counts={1:2,2:2 if equal else 6,3:2 if equal else 4}
    rounds=[]
    for selected in ((1,2),(1,3)):
        local={}
        for cid in selected:
            y=x; gradients=[]
            for _ in range(2):
                g=y-target[cid]; gradients.append(g)
                y-=eta*(g-ci[cid]+c)
            new=ci[cid]-c+(x-y)/(2*eta)
            assert new==sum(gradients)/2
            local[cid]=dict(y=y,ci=new,delta=new-ci[cid],gradients=gradients)
        uniform=sum(local[cid]['y'] for cid in selected)/len(selected)
        x=sum(counts[cid]*local[cid]['y'] for cid in selected)/sum(counts[cid] for cid in selected)
        c+=sum(local[cid]['delta'] for cid in selected)/3
        for cid in selected: ci[cid]=local[cid]['ci']
        assert c==sum(ci.values())/3
        rounds.append(dict(selected=selected,locals=local,x=x,c=c,uniform=uniform,all_ci=ci.copy()))
    return rounds,counts,target

def close(a,b):
    assert abs(float(a)-float(b))<1e-12,(a,b)

def live(root,spawn=False,equal=False):
    root.mkdir(parents=True,exist_ok=True)
    rounds,counts,targets=oracle(equal)
    cfg=config(spawn)
    observed=[]
    with configure_environment(cfg,runtime_root=root):
        torch.manual_seed(29)
        s=server(); s.server_control_variate=controls(2)
        cs={cid:client(cid) for cid in (1,2,3)}
        for cid,value in ((1,1),(2,3),(3,2)):
            cs[cid].trainer.model_update_strategy.client_control_variate=controls(value)
        for rid,ref in enumerate(rounds,1):
            payload=s.customize_server_payload(s.algorithm.extract_weights())
            results=[]
            for cid in ref['selected']:
                u=train_round(cs[cid],payload,rid,float(targets[cid]),counts[cid])
                st=cs[cid].trainer.model_update_strategy
                trace=json.loads((root/f'models/gradient-trace-{cid}-{rid}.json').read_text())
                values=(cs[cid].trainer.model.theta.item(),st.client_control_variate['theta'].item(),u.payload[1]['theta'].item())
                for val,key in zip(values,('y','ci','delta')): close(val,ref['locals'][cid][key])
                close(st.local_steps,2); close(st.learning_rate,.1)
                for g,rg in zip(trace['gradients'],ref['locals'][cid]['gradients']): close(g,rg)
                assert len(trace['gradients'])==2
                close(values[1],sum(trace['gradients'])/2)
                if spawn: assert trace['worker_token']
                results.append(dict(client=cid,samples=u.report.num_samples,y=values[0],ci=values[1],delta=values[2],trace=trace))
                if cid==ref['selected'][0]: updates=[]
                updates.append(u)
            s.updates=updates
            # Actual server report dispatch, including model/control commit.
            asyncio.run(s._process_reports())
            next_payload=s.customize_server_payload(s.algorithm.extract_weights())
            close(s.trainer.model.theta.item(),ref['x']); close(next_payload[1]['theta'].item(),ref['c'])
            allci=[cs[cid].trainer.model_update_strategy.client_control_variate['theta'].item() for cid in (1,2,3)]
            for actual,rational in zip(allci,ref['all_ci'].values()): close(actual,rational)
            observed.append(dict(round=rid,locals=results,x=s.trainer.model.theta.item(),c=next_payload[1]['theta'].item(),all_ci=allci,uniform_for_local_models=str(ref['uniform'])))
    return dict(spawn=spawn,equal_counts=equal,overrides=cfg,rounds=observed)

def scalar_equations(root):
    root.mkdir(parents=True,exist_ok=True)
    results=[]
    with configure_environment(config(),runtime_root=root):
        for cls in (SCAFFOLDUpdateStrategy,SCAFFOLDUpdateStrategyV2):
            for gs in ([0.],[3.,1.]):
                ctx=TrainingContext();ctx.model=Scalar();ctx.client_id=1
                st=cls(save_path=str(root/cls.__name__))
                st.setup(ctx);st.client_control_variate=controls(1)
                ctx.state['server_control_variate']=controls(2)
                st.on_train_start(ctx)
                opt=torch.optim.SGD(ctx.model.parameters(),lr=.1)
                ctx.state['optimizer']=opt;st.before_step(ctx)
                rational=F(1)
                for g in gs:
                    rational-=F(1,10)*(F(g)-1+2)
                    (ctx.model.theta*g).sum().backward()
                    opt.step();st.after_step(ctx);opt.zero_grad()
                st.on_train_end(ctx)
                close(ctx.model.theta.item(),rational)
                close(st.client_control_variate['theta'].item(),sum(gs)/len(gs))
                close(ctx.state['client_control_variate_delta']['theta'].item(),sum(gs)/len(gs)-1)
                results.append(dict(strategy=cls.__name__,gradients=gs,y=ctx.model.theta.item(),ci=st.client_control_variate['theta'].item(),delta=ctx.state['client_control_variate_delta']['theta'].item()))
                st.on_train_cleanup(ctx,True)
    return results

def malformed_models(root):
    out=[]
    for case,malformed in [('nan',controls(float('nan'))),('missing',{}),
                           ('broadcast',OrderedDict(theta=torch.tensor(9.,dtype=torch.float64)))]:
        (root/case).mkdir(parents=True,exist_ok=True)
        with configure_environment(config(),runtime_root=root/case):
            s=server();s.server_control_variate=controls(2)
            report=SimpleNamespace(num_samples=2,accuracy=0.,training_time=0.,comm_time=0.,client_id=1)
            s.updates=[SimpleNamespace(report=report,payload=[controls(7),controls(3)]),
                       SimpleNamespace(report=copy.copy(report),payload=[malformed,controls(4)])]
            error=None
            try: asyncio.run(s._process_reports())
            except Exception as exc:error=f'{type(exc).__name__}: {exc}'
            out.append(dict(case=case,expected='Reject before aggregation; x=1,c=2 unchanged',
                actual_x=s.trainer.model.theta.item(),actual_c=s.server_control_variate['theta'].item(),
                raised=error,pending_controls=s._pending_control_variate is not None))
    return out

def accumulation(root):
    out=[]
    for cls in (SCAFFOLDUpdateStrategy,SCAFFOLDUpdateStrategyV2):
        for n in (1,3,4):
            cfg=config();cfg['trainer'].update(batch_size=1,epochs=1)
            (root/f'{cls.__name__}-{n}').mkdir(parents=True,exist_ok=True)
            with configure_environment(cfg,runtime_root=root/f'{cls.__name__}-{n}'):
                st=cls();tr=ComposableTrainer(model=Scalar(),model_update_strategy=st,
                    loss_strategy=DefaultLossCriterionStrategy(quadratic),
                    training_step_strategy=GradientAccumulationStepStrategy(2))
                tr.set_client_id(1);st.client_control_variate=controls(1)
                tr.context.state['server_control_variate']=controls(2)
                targets=torch.arange(n,dtype=torch.float64).reshape(n,1)
                data=TensorDataset(torch.ones(n,1,dtype=torch.float64),targets)
                y=F(1); used=[]
                for start in range(0,n,2):
                    g=sum(y-F(t) for t in range(start,min(n,start+2)))/min(2,n-start)
                    used.append(g);y-=F(1,10)*(g+1)
                tr.train_model({**cfg['trainer'],'run_id':'independent'},data,torch.utils.data.SequentialSampler(data))
                close(tr.model.theta.item(),y);close(st.local_steps,len(used))
                close(st.client_control_variate['theta'].item(),sum(used)/len(used))
                ci=st.client_control_variate['theta'].item()
                empty=TensorDataset(torch.empty(0,1,dtype=torch.float64),torch.empty(0,1,dtype=torch.float64))
                tr.train_model({**cfg['trainer'],'run_id':'empty'},empty,[])
                close(st.local_steps,0);close(st.client_control_variate['theta'].item(),ci)
                close(st.get_update_payload(tr.context)['control_variate_delta']['theta'].item(),0)
                out.append(dict(strategy=cls.__name__,microbatches=n,expected_y=str(y),updates=len(used),mean_used_gradient=str(sum(used)/len(used)),empty_delta=0))
    return out

if __name__=='__main__':
    version=''.join(platform.python_version_tuple()[:2])
    mode=REQUESTED_MODE
    root=SCRATCH/f'independent-{version}-{mode}'
    root.mkdir(parents=True,exist_ok=True)
    if mode=='spawn':
        result=dict(live=live(root,spawn=True))
    else:
        result=dict(equations=scalar_equations(root/'equations'),
            accumulation=accumulation(root/'accumulation'),
            live=live(root/'unequal'),equal=live(root/'equal',equal=True),
            malformed_model_results=malformed_models(root/'malformed'))
    result['python']=sys.version;result['torch']=torch.__version__
    result['source_files']={m.__name__:m.__file__ for m in (scaffold_callback,scaffold_client,scaffold_trainer,scaffold_server)}
    (SCRATCH/f'independent-{version}-{mode}.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
