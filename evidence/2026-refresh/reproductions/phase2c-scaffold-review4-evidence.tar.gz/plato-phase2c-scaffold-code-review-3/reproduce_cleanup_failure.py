"""Assert rejection after a fallible cleanup through actual direct/process calls."""
import json,sys,uuid
import cleanup_acceptance_probe as c

v=f'{sys.version_info.major}{sys.version_info.minor}'
run_root=c.p.SCRATCH/f'cleanup-replay-{v}'/uuid.uuid4().hex
records=[];failures=[]
for interface in ['train_model','train_process']:
    for existing in [False,True]:
        root=run_root/f'{interface}-{existing}'
        root.mkdir(parents=True,exist_ok=True)
        r=c.run(root,interface,existing,False,True);records.append(r)
        try:
            assert r['error'] is not None
            assert r['ci']==1., f"Caller received failure but memory ci advanced: {r['ci']}"
            assert r['canonical_preserved'], 'Caller received failure but canonical controls advanced'
            assert not r['outbound_eligible'], 'Caller received failure but outbound accepted'
            c.p.close(r['retry']['y'],.62)
            c.p.close(r['retry']['ci'],.9)
            c.p.close(r['retry']['delta'],-.1)
        except AssertionError as exc:
            failures.append(dict(interface=interface,existing=existing,error=str(exc)))
result=dict(runtime_root=str(run_root),python=sys.version,assertion_cases=len(records),failed=len(failures),passed=len(records)-len(failures),failures=failures,cases=records)
(c.p.SCRATCH/f'cleanup-replay-{v}.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2));raise SystemExit(1 if failures else 0)
