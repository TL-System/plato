from pathlib import Path
import json
import pytest
import sys

source=Path("/tmp/plato-refresh-worktrees/mlx-integration").resolve()
out=Path("/tmp/plato-mlx-docs-review-artifacts")
code=pytest.main(["tests","--collect-only","-q","-o",f"cache_dir={out/'default-core-cache'}"])
result={
 "returncode":int(code),
 "pytest_file":pytest.__file__,
 "cwd":str(Path.cwd()),
 "core_conftest_file":sys.modules["tests.conftest"].__file__,
 "imported_mlx_modules":sorted(name for name in sys.modules if name=="mlx" or name.startswith("mlx.")),
 "imported_native_test_modules":sorted(name for name in sys.modules if name=="tests.mlx_native" or name.startswith("tests.mlx_native.")),
 "semantics":"Default core collection in environment with mlx/metal installed. Presence-only metadata queries are permitted and not traced here."
}
(out/"default-core-import-observation.json").write_text(json.dumps(result,indent=2)+"\n")
print("DOCS_IMPORT_OBSERVATION",json.dumps(result))
raise SystemExit(int(code) or bool(result["imported_mlx_modules"] or result["imported_native_test_modules"]))
