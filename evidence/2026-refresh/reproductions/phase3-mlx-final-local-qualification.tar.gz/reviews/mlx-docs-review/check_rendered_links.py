from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit
import json

root=Path("/tmp/plato-mlx-docs-review-artifacts/site").resolve()
class Page(HTMLParser):
    def __init__(self, path):
        super().__init__()
        self.hrefs=[]
        self.ids=set()
        self.feed(path.read_text())
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if "id" in attrs: self.ids.add(attrs["id"])
        if tag=="a" and "href" in attrs: self.hrefs.append(attrs["href"])

pages={p.resolve():Page(p) for p in root.rglob("*.html")}
errors=[]
checked=0
per_page={}
for path, page in pages.items():
    number=0
    for href in page.hrefs:
        split=urlsplit(href)
        if split.scheme or split.netloc: continue
        if not split.path:
            target=path
        else:
            target=(root/unquote(split.path).lstrip("/")) if split.path.startswith("/") else (path.parent/unquote(split.path))
        target=target.resolve()
        if target.is_dir(): target=(target/"index.html").resolve()
        checked+=1
        number+=1
        if not target.is_relative_to(root):
            errors.append({"page":str(path.relative_to(root)),"href":href,"error":"escapes site"})
        elif not target.exists():
            errors.append({"page":str(path.relative_to(root)),"href":href,"error":"missing target"})
        elif split.fragment and target.suffix==".html":
            if unquote(split.fragment) not in pages[target].ids:
                errors.append({"page":str(path.relative_to(root)),"href":href,"error":"missing anchor"})
    per_page[str(path.relative_to(root))]=number
result={"pages_checked":len(pages),"local_links_checked":checked,"per_page":per_page,"errors":errors,"external_links_fetched":False}
Path("/tmp/plato-mlx-docs-review-artifacts/rendered-links.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
raise SystemExit(bool(errors))
