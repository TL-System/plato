"""Independent fresh-process import and collection observer; production hooks unchanged."""
import importlib.abc
import json
import sys
import traceback
from collections import Counter
from pathlib import Path

import pytest

out, mode, *args = sys.argv[1:]
events = []
class Observer(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == "mlx" or fullname.startswith("mlx."):
            stack = traceback.extract_stack()
            in_preflight = any(f.name == "_native_prerequisites" and Path(f.filename).name == "conftest.py" for f in stack)
            upstream_presence = any(f.name == "_is_package_available" and f.filename.endswith("/transformers/utils/import_utils.py") for f in stack) and fullname == "mlx"
            events.append({
                "module": fullname, "in_preflight": in_preflight,
                "transformers_presence": upstream_presence,
                "relevant_stack": [{"file":f.filename,"line":f.lineno,"function":f.name} for f in stack if ("plato" in f.filename or "transformers" in f.filename) and "importlib" not in f.filename],
            })
            if mode == "sentinel" and not upstream_presence:
                raise RuntimeError("Independent backend sentinel encountered")
        return None
sys.meta_path.insert(0, Observer())
class Collection:
    def __init__(self):
        self.nodes=[]
        self.marker=[]
    def pytest_collection_finish(self, session):
        self.nodes=[item.nodeid for item in session.items]
        self.marker=[item.nodeid for item in session.items if item.get_closest_marker("runtime")]
collector=Collection()
code=int(pytest.main([*args,"-p","no:cacheprovider","-q"],plugins=[collector]))
native=[n for n in collector.nodes if n.startswith("tests/mlx_native/")]
ledger=Counter(c["nodeid"] for c in json.loads(Path("tests/mlx_native/cases.json").read_text())["cases"])
record={
 "exit_status":code,"nodes":collector.nodes,"node_count":len(collector.nodes),
 "native_node_count":len(native),"native_counter_equals_frozen_383":Counter(native)==ledger if native else None,
 "startup_count":sum(n.startswith("tests/integration/test_event_loop_startup.py::") for n in collector.nodes),
 "runtime_count":len(collector.marker),
 "backend_resolution_events":events,
 "backend_modules":[n for n in sys.modules if n=="mlx" or n.startswith("mlx.")],
 "native_test_modules":[n for n in sys.modules if "test_phase3_" in n],
 "production_conftest_loaded":"tests.conftest" in sys.modules,
}
Path(out).write_text(json.dumps(record,indent=2)+"\n")
raise SystemExit(code)
