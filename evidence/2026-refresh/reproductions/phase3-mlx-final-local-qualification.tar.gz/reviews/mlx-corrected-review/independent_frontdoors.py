import copy
import importlib.metadata
import json
import os
import random
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT=Path("/tmp/plato-mlx-corrected-independent-review")
output=Path(sys.argv[1])
bootstrap=ROOT/"frontdoor-bootstrap"
bootstrap.mkdir(exist_ok=True)
os.environ["config_file"]=str(ROOT/"checkout/configs/MNIST/fedavg_lenet5.toml")
sys.argv=[sys.argv[0],"-b",str(bootstrap),"--cpu"]

import numpy as np
import torch
from plato.algorithms import registry as algorithms
from plato.models import registry as models
from plato.serialization.safetensor import deserialize_tree, serialize_tree
from plato.utils import tree
from tests.integration.utils import configure_environment, build_minimal_config

def no_native():
    assert not [n for n in sys.modules if n=="mlx" or n.startswith("mlx.")]

no_native()
builtin_model_factory=models.registered_mlx_models["mlx_lenet5"]
builtin_algorithm_factory=algorithms.registered_algorithms["mlx_fedavg"]
assert callable(builtin_model_factory) and callable(builtin_algorithm_factory)
config=build_minimal_config()
core=ROOT/"frontdoor-core"
core.mkdir(exist_ok=True)
with configure_environment(config,runtime_root=core):
    actual_torch_model=models.get()
    assert isinstance(actual_torch_model,torch.nn.Module)
    no_native()
    marker=object()
    models.registered_models["review_core"]=lambda **kwargs: marker
    assert models.get(model_type="review_core",model_params={}) is marker
    algorithms.registered_algorithms["review_core"]=lambda trainer: marker
    previous_Config=algorithms.Config
    algorithms.Config=lambda: SimpleNamespace(algorithm=SimpleNamespace(type="review_core"))
    assert algorithms.get() is marker
    algorithms.Config=previous_Config
    no_native()
record={"backend_absent_until_explicit_native":True,"core_torch_and_custom_factories_preserved":True}
try:
    version=importlib.metadata.version("mlx")
except importlib.metadata.PackageNotFoundError:
    version=None
record["mlx_distribution_version"]=version
if version is None:
    cfg=SimpleNamespace(trainer=SimpleNamespace(model_name="lenet5",framework="mlx"))
    models.Config=lambda:cfg
    try:
        models.get()
    except ImportError as error:
        assert "optional mlx dependency" in str(error) and isinstance(error.__cause__,ImportError)
        record["native_model_explicit_missing_diagnostic"]=str(error)
    else:
        raise AssertionError("model dependency missing was accepted")
    algorithms.Config=lambda:SimpleNamespace(algorithm=SimpleNamespace(type="mlx_fedavg",framework="mlx"))
    try:
        algorithms.get()
    except ImportError as error:
        assert "MLX is not installed" in str(error) and isinstance(error.__cause__,ImportError)
        record["native_algorithm_explicit_missing_diagnostic"]=str(error)
    else:
        raise AssertionError("algorithm dependency missing was accepted")
    no_native()
else:
    from tests.conftest import _native_prerequisites
    no_native()
    _native_prerequisites()
    import mlx.core as mx
    from plato.algorithms.mlx_fedavg import Algorithm
    from plato.models.mlx.lenet5 import LeNet5,Model
    from plato.trainers.mlx import ComposableMLXTrainer
    from tests.mlx_native.helpers import configuration
    native=mx.array([[1.0,2.0],[3.0,4.0]],dtype=mx.float16)
    source={
        "mlx":native,"numpy":np.arange(12,dtype=np.float32).reshape(3,4)[:,::-1],
        "torch":torch.arange(6,dtype=torch.float32).reshape(2,3).t(),
        "nested":(None,"wire",b"bytes",torch.tensor([1.25,2.5],dtype=torch.bfloat16),7)
    }
    flat,metadata=tree.flatten_tree(source)
    assert metadata["mlx"].backend=="mlx"
    restored=deserialize_tree(serialize_tree(source))
    assert isinstance(restored["mlx"],np.ndarray) and restored["mlx"].dtype==np.float16
    np.testing.assert_array_equal(restored["mlx"],np.array(native))
    np.testing.assert_array_equal(restored["numpy"],source["numpy"])
    assert torch.equal(restored["torch"],source["torch"])
    assert restored["nested"][:3]==source["nested"][:3]
    assert isinstance(restored["nested"],tuple) and restored["nested"][-1]==7
    assert restored["nested"][3].dtype==torch.bfloat16 and torch.equal(restored["nested"][3],source["nested"][3])
    record["mixed_numpy_torch_mlx_serialization"]=True
    record["tree_loaded_before_native_detects_later_arrays"]=True
    def state():
        return {
            "device":mx.default_device(),
            "streams":tuple(mx.default_stream(d) for d in (mx.cpu,mx.gpu)),
            "python":random.getstate(),"numpy":np.random.get_state(),
            "torch":torch.get_rng_state().clone(),
            "mlx":[np.array(a,copy=True) for a in mx.random.state]
        }
    def unchanged(before):
        after=state()
        assert before["device"]==after["device"] and before["streams"]==after["streams"], {"before_device":str(before["device"]),"after_device":str(after["device"]),"before_streams":[str(x) for x in before["streams"]],"after_streams":[str(x) for x in after["streams"]]}
        assert before["python"]==after["python"]
        for a,b in zip(before["numpy"],after["numpy"],strict=True):np.testing.assert_array_equal(a,b)
        assert torch.equal(before["torch"],after["torch"])
        for a,b in zip(before["mlx"],after["mlx"],strict=True):np.testing.assert_array_equal(a,b)
    observed=[]
    def custom_factory(**kwargs):
        observed.append(mx.default_device())
        random.random();np.random.random();torch.rand(2);mx.eval(mx.random.uniform(shape=(2,)))
        return LeNet5(**kwargs)
    # Override before first selection; lazy loading must not overwrite this factory.
    models.registered_mlx_models["mlx_lenet5"]=custom_factory
    native_root=ROOT/"frontdoor-native"
    native_root.mkdir(exist_ok=True)
    with configure_environment(configuration(model_seed=37),runtime_root=native_root):
        modes=[("normal",False,False,None),("cpu",True,False,mx.cpu),("metal",False,True,mx.gpu),("both",True,True,mx.cpu)]
        placements=[]
        before=state()
        for label,cpu,mps,expected in modes:
            from plato.config import Config
            Config.args.cpu=cpu
            Config.args.mps=mps
            checkpoint=state()
            model=models.get()
            assert isinstance(model,LeNet5)
            assert models.registered_mlx_models["mlx_lenet5"] is custom_factory
            assert observed[-1]==(checkpoint["device"] if expected is None else expected)
            unchanged(checkpoint)
            placements.append({"mode":label,"observed":str(observed[-1])})
        custom_stream=mx.new_stream(mx.cpu)
        with mx.stream(custom_stream):
            Config.args.cpu=False
            Config.args.mps=False
            checkpoint=state()
            model=models.get()
            assert observed[-1]==mx.cpu
            unchanged(checkpoint)
        # The caller's own cross-device stream context has upstream MLX semantics.
        # Native calls above restore each checkpoint taken inside the caller scope.
        control_stream=mx.new_stream(mx.cpu)
        control_before=state()
        with mx.stream(control_stream):
            pass
        control_after=state()
        record["upstream_caller_context_control"]={
            "cpu_stream_before":str(control_before["streams"][0]),
            "cpu_stream_after":str(control_after["streams"][0]),
            "device_restored":control_before["device"]==control_after["device"],
            "no_plato_operation_in_control":True,
        }
        Config.args.cpu=True
        Config.args.mps=False
        def fails(**kwargs):
            random.random();np.random.random();torch.rand(2);mx.eval(mx.random.uniform(shape=(2,)))
            raise RuntimeError("review native factory failure")
        models.registered_mlx_models["mlx_lenet5"]=fails
        checkpoint=state()
        try:
            models.get()
        except RuntimeError as error:
            assert str(error)=="review native factory failure"
        else:
            raise AssertionError("factory exception vanished")
        unchanged(checkpoint)
        models.registered_mlx_models["mlx_lenet5"]=custom_factory
        trainer=ComposableMLXTrainer(model=model)
        marker=object()
        def custom_algorithm(trainer_arg):
            assert trainer_arg is trainer
            return marker
        algorithms.registered_algorithms["mlx_fedavg"]=custom_algorithm
        assert algorithms.get(trainer) is marker
        assert algorithms.registered_algorithms["mlx_fedavg"] is custom_algorithm
        # Calling a captured built-in wrapper resolves native objects without overwriting overrides.
        actual=builtin_algorithm_factory(trainer)
        assert type(actual) is Algorithm
        assert algorithms.registered_algorithms["mlx_fedavg"] is custom_algorithm
        actual_model=builtin_model_factory(num_classes=10)
        assert type(actual_model) is LeNet5
        assert models.registered_mlx_models["mlx_lenet5"] is custom_factory
        # Restore reviewed placeholders in this private process and check exact builtin cache entries.
        models.mlx_lenet5=models._MLX_UNLOADED
        models.registered_mlx_models["mlx_lenet5"]=builtin_model_factory
        actual_model=models.get()
        assert type(actual_model) is LeNet5
        assert models.registered_mlx_models["mlx_lenet5"] is Model
        algorithms.registered_algorithms["mlx_fedavg"]=builtin_algorithm_factory
        actual=algorithms.get(trainer)
        assert type(actual) is Algorithm
        assert algorithms.registered_algorithms["mlx_fedavg"] is Algorithm
        try:
            algorithms.get()
        except TypeError as error:
            assert "native MLX trainer" in str(error)
        else:
            raise AssertionError("missing native trainer accepted")
        record["custom_native_factories_not_overwritten"]=True
        record["captured_lazy_wrappers_preserve_custom_registry_entries"]=True
        record["native_builtin_exact_constructor_cache"]=True
        record["native_model_device_placements"]=placements
        record["native_seeded_success_and_failure_restore_all_rngs_streams_devices"]=True
        record["native_trainer_type_guard"]=True
output.write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record,indent=2))
