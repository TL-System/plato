import concurrent.futures
import json
import os
import subprocess
from pathlib import Path
ROOT=Path("/tmp/plato-mlx-corrected-independent-review")
PY="/tmp/plato-mlx-integration/env/bin/python"
env=os.environ.copy()
env.update(PYTHONPATH=str(ROOT/"checkout"),PYTHONDONTWRITEBYTECODE="1",PYTEST_DISABLE_PLUGIN_AUTOLOAD="1")
env.pop("PYTEST_ADDOPTS",None)
cases=[
 ("default-tests",["tests","--collect-only"],"observe",0),
 ("default-testpaths",["--collect-only"],"observe",0),
 ("sentinel-core",["tests","--collect-only","--test-profile=base"],"sentinel",0),
 ("runtime-core",["tests","--test-profile=mandatory","--collect-only","-m","runtime"],"observe",0),
 ("canonical-pyargs",["--pyargs","tests.mlx_native.test_phase3_controls","--collect-only"],"observe",4),
 ("full-native",["tests/mlx_native","--test-profile=mlx-native","--collect-only"],"observe",0),
 ("native-filter",["tests/mlx_native","--test-profile=mlx-native","--collect-only","-k","tree"],"observe",4),
 ("focused-native",["tests/mlx_native/test_phase3_tree_contract.py::test_extracted_host_weights_own_snapshots","--collect-only"],"observe",0),
]
def run(case):
 name,args,mode,expected=case
 result=subprocess.run([PY,str(ROOT/"independent_import.py"),str(ROOT/(name+".json")),mode,*args],cwd=ROOT/"checkout",env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
 (ROOT/(name+".log")).write_text(result.stdout)
 assert result.returncode==expected,(name,result.returncode,result.stdout[-2000:])
 record=json.loads((ROOT/(name+".json")).read_text())
 assert record["production_conftest_loaded"],name
 if name not in ("full-native","focused-native"):
  assert record["backend_modules"]==[],name
  assert record["native_test_modules"]==[],name
  assert all(e["module"]=="mlx" and e["transformers_presence"] for e in record["backend_resolution_events"]),name
 else:
  backend=[e for e in record["backend_resolution_events"] if not e["transformers_presence"]]
  assert backend and backend[0]["in_preflight"],name
 if name in ("default-tests","default-testpaths","sentinel-core"):
  assert record["startup_count"]==48 and record["native_node_count"]==0,name
 if name=="runtime-core":
  assert record["runtime_count"]==51 and record["startup_count"]==48,name
 if name=="full-native":
  assert record["native_node_count"]==383 and record["native_counter_equals_frozen_383"],name
 return {"name":name,"exit_status":result.returncode,"node_count":record["node_count"],"native_node_count":record["native_node_count"],"startup_count":record["startup_count"],"runtime_count":record["runtime_count"],"metadata_only_mlx_queries":sum(e["transformers_presence"] for e in record["backend_resolution_events"]),"backend_modules":len(record["backend_modules"]),"first_native_backend_resolution_inside_preflight":True if name in ("full-native","focused-native") else None}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 results=list(pool.map(run,cases))
(ROOT/"independent-import-results.json").write_text(json.dumps(results,indent=2)+"\n")
print(json.dumps(results,indent=2))
