import asyncio
import copy
import json
from pathlib import Path
from types import SimpleNamespace
import os
import sys
bootstrap = Path("/tmp/plato-mlx-corrected-independent-review/bootstrap")
bootstrap.mkdir(exist_ok=True)
os.environ["config_file"] = "/tmp/plato-mlx-corrected-independent-review/checkout/configs/MNIST/fedavg_lenet5_mlx.toml"
sys.argv = [sys.argv[0], "-b", str(bootstrap), "--cpu"]

import mlx.core as mx
import numpy as np

from plato.algorithms.mlx_fedavg import Algorithm
from plato.models.mlx.lenet5 import LeNet5
from plato.servers.fedavg import Server
from plato.servers.strategies.aggregation import FedAvgAggregationStrategy
from plato.trainers.mlx import ComposableMLXTrainer
from tests.integration.utils import configure_environment
from tests.mlx_native.helpers import configuration

ROOT = Path("/tmp/plato-mlx-corrected-independent-review")
rows = []


def identical(a, b):
    if isinstance(b, dict):
        assert type(a) is type(b) and a.keys() == b.keys()
        for k in b:
            identical(a[k], b[k])
    elif isinstance(b, (tuple, list)):
        assert type(a) is type(b) and len(a) == len(b)
        for x, y in zip(a, b, strict=True):
            identical(x, y)
    elif isinstance(b, np.ndarray):
        assert a.dtype == b.dtype and a.shape == b.shape
        np.testing.assert_array_equal(a, b)
    elif isinstance(b, float) and np.isnan(b):
        assert np.isnan(a)
    else:
        assert a == b


def updates_snapshot(updates):
    return [
        {
            "client_id": u.client_id,
            "count": u.report.num_samples,
            "payload": copy.deepcopy(u.payload),
            "report_id": id(u.report),
            "update_id": id(u),
        }
        for u in updates
    ]


class Direct(FedAvgAggregationStrategy):
    async def aggregate_weights(self, updates, baseline, weights, context):
        context.state["dispatch"] = True
        return await super().aggregate_weights(updates, baseline, weights, context)


class Delta(FedAvgAggregationStrategy):
    async def aggregate_deltas(self, updates, weights, context):
        context.state["dispatch"] = True
        return await super().aggregate_deltas(updates, weights, context)


class Legacy(Server):
    async def aggregate_weights(self, updates, baseline, weights):
        self.context.state["dispatch"] = True
        return await FedAvgAggregationStrategy().aggregate_weights(
            updates, baseline, weights, self.context
        )


def ready(kind, reverse, zero):
    trainer = ComposableMLXTrainer(model=LeNet5)
    server = (Legacy if kind == "legacy" else Server)(
        aggregation_strategy=Direct() if kind == "direct" else Delta()
    )
    server.trainer = trainer
    server.algorithm = Algorithm(trainer)
    server.context.trainer = trainer
    server.context.algorithm = server.algorithm
    server.context.server = server
    server.clients_processed = lambda: None
    baseline = server.algorithm.extract_weights()
    first = copy.deepcopy(baseline)
    second = copy.deepcopy(baseline)
    first["fc3"]["bias"] = np.full(10, 1, dtype=np.float32)
    second["fc3"]["bias"] = np.full(10, 4, dtype=np.float32)
    def update(client_id, count, payload):
        return SimpleNamespace(
            client_id=client_id,
            payload=payload,
            report=SimpleNamespace(
                num_samples=count, accuracy=0.0, training_time=0.0,
                processing_time=0.0, comm_time=0.0, type="weights"
            )
        )
    server.updates = [update(1, 8, first), update(2, 0 if zero else 24, second)]
    if reverse:
        server.updates.reverse()
    compute = server.algorithm.compute_weight_deltas
    load = server.algorithm.load_weights
    def subtract(*args):
        server.context.state["subtract"] = True
        return compute(*args)
    def load_observed(*args):
        server.context.state["load"] = True
        return load(*args)
    server.algorithm.compute_weight_deltas = subtract
    server.algorithm.load_weights = load_observed
    return server, baseline


damages = [
    "weights_swap",
    "reports_swap",
    "updates_swap",
    "copied_updates_original_reports_swap",
    "copied_reports_changed_labels",
    "broadcast",
    "tuple_container",
    "nan_count",
    "overflow_total",
    "short_reports",
]
with configure_environment(configuration(model_seed=17), runtime_root=ROOT/"independent-runtime"):
    for kind in ("direct", "delta", "legacy"):
        for reverse in (False, True):
            for zero in (False, True):
                for damage in damages:
                    server, baseline = ready(kind, reverse, zero)
                    retained = copy.deepcopy(baseline)
                    state = {}
                    server.weights_received = lambda weights: state.setdefault("weights", weights)
                    def mutate(updates, context):
                        if damage == "weights_swap":
                            state["weights"].reverse()
                        elif damage == "reports_swap":
                            updates[0].report, updates[1].report = updates[1].report, updates[0].report
                        elif damage == "updates_swap":
                            updates.reverse()
                        elif damage == "copied_updates_original_reports_swap":
                            originals = [u.report for u in updates]
                            updates[:] = copy.deepcopy(updates)
                            updates[0].report, updates[1].report = originals[1], originals[0]
                        elif damage == "copied_reports_changed_labels":
                            updates[:] = copy.deepcopy(updates)
                            updates[0].client_id, updates[1].client_id = updates[1].client_id, updates[0].client_id
                        elif damage == "broadcast":
                            next(u for u in updates if u.client_id == 2).payload["fc3"]["bias"] = np.ones(1, dtype=np.float32)
                        elif damage == "tuple_container":
                            u = next(u for u in updates if u.client_id == 2)
                            u.payload["fc3"] = tuple(u.payload["fc3"].values())
                        elif damage == "nan_count":
                            next(u for u in updates if u.client_id == 2).report.num_samples = float("nan")
                        elif damage == "overflow_total":
                            for u in updates:
                                u.report.num_samples = 1e308
                        elif damage == "short_reports":
                            updates.pop()
                        state["after_weights"] = copy.deepcopy(state["weights"])
                        state["after_updates"] = updates_snapshot(updates)
                    server.client_selection_strategy.on_reports_received = mutate
                    before_device = mx.default_device()
                    before_streams = tuple(mx.default_stream(d) for d in (mx.cpu,mx.gpu))
                    try:
                        asyncio.run(server._process_reports())
                    except ValueError as error:
                        result = str(error)
                    else:
                        raise AssertionError((kind,reverse,zero,damage,"accepted"))
                    assert not any(server.context.state.get(k) for k in ("dispatch","subtract","load"))
                    identical(server.algorithm.extract_weights(),retained)
                    identical(baseline,retained)
                    identical(state["weights"],state["after_weights"])
                    identical(updates_snapshot(server.updates),state["after_updates"])
                    assert mx.default_device()==before_device
                    assert tuple(mx.default_stream(d) for d in (mx.cpu,mx.gpu))==before_streams
                    rows.append({"kind":kind,"reverse":reverse,"zero_weight_client2":zero,"damage":damage,"error":result,"rejected_before_subtraction_dispatch_load":True,"model_and_post_hook_caller_state_unchanged":True})
    controls=[]
    for kind in ("direct","delta","legacy"):
        for reverse in (False,True):
            server, baseline = ready(kind, reverse, False)
            server.weights_received = copy.deepcopy
            server.client_selection_strategy.on_reports_received = lambda updates,context: updates.__setitem__(slice(None),copy.deepcopy(updates))
            asyncio.run(server._process_reports())
            np.testing.assert_allclose(server.algorithm.extract_weights()["fc3"]["bias"],np.full(10,3.25),rtol=1e-5,atol=1e-6)
            controls.append({"kind":kind,"reverse":reverse,"valid_positional_copies_bias":3.25})
    # Deliberately unlabeled same-schema deep copies carry the established positional contract.
    server, baseline=ready("direct",False,False)
    server.weights_received=lambda weights: copy.deepcopy(list(reversed(weights)))
    asyncio.run(server._process_reports())
    np.testing.assert_allclose(server.algorithm.extract_weights()["fc3"]["bias"],np.full(10,1.75),rtol=1e-5,atol=1e-6)
    positional_limit={"accepted_unlabeled_deep_copied_semantic_swap":True,"result_bias":1.75,"interpretation":"Caller must preserve positional correspondence; shape and identity checks cannot infer copied semantic provenance."}
    zero_controls=[]
    for kind in ("direct","delta"):
        for reverse in (False,True):
            server, baseline=ready(kind,reverse,False)
            def zero_counts(updates,context):
                for u in updates:
                    u.report.num_samples=0
            server.client_selection_strategy.on_reports_received=zero_counts
            asyncio.run(server._process_reports())
            identical(server.algorithm.extract_weights(),baseline)
            zero_controls.append({"kind":kind,"reverse":reverse,"baseline_preserved":True})
record={"invalid_cases":rows,"valid_controls":controls,"all_zero_controls":zero_controls,"accepted_positional_limit":positional_limit}
(ROOT/"independent-dispatch-results.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({"invalid_cases":len(rows),"valid_controls":len(controls),"all_zero_controls":len(zero_controls),"accepted_positional_limit":positional_limit}))
