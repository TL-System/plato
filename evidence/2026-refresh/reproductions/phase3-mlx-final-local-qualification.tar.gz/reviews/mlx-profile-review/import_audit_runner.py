import importlib.abc
import json
import sys
from pathlib import Path
import pytest

lookups=[]
class Audit(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname=="mlx" or fullname.startswith("mlx."):
            lookups.append(fullname)
        return None
sys.meta_path.insert(0, Audit())
code=pytest.main(sys.argv[2:])
record={"exit_status":int(code),"backend_spec_lookups":lookups,"backend_modules":[n for n in sys.modules if n=="mlx" or n.startswith("mlx.")],"native_test_modules":[n for n in sys.modules if ".test_phase3_" in n or n.startswith("test_phase3_")],"inert_native_packages":[n for n in sys.modules if n in ("tests.mlx_native","mlx_native")]}
Path(sys.argv[1]).write_text(json.dumps(record,indent=2)+"\n")
print("INDEPENDENT IMPORT AUDIT",json.dumps(record))
sys.exit(code)
