import importlib.abc
import sys
import traceback
import pytest

class Audit(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname=="mlx":
            print("FIRST MLX IMPORT STACK",flush=True)
            traceback.print_stack(limit=85)
        return None
sys.meta_path.insert(0, Audit())
sys.exit(pytest.main(["--pyargs","tests.mlx_native.test_phase3_controls","-q","-p","no:cacheprovider"]))
