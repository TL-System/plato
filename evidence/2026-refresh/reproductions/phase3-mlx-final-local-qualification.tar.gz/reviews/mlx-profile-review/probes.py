"""Independent miniature projects exercising exact committed profile hooks."""
import ast
import hashlib
import json
import os
import subprocess
import sys
from collections import Counter
from pathlib import Path

SOURCE = Path("/tmp/plato-refresh-worktrees/mlx-profile/tests/conftest.py")
SCRATCH = Path("/tmp/plato-mlx-profile-independent-review")
source = SOURCE.read_text()
tree = ast.parse(source)
segments = []
for node in tree.body:
    include = isinstance(node, (ast.Assign, ast.AnnAssign, ast.ClassDef))
    if isinstance(node, ast.FunctionDef):
        include = node.name in {"_full_suite", "_native_prerequisites", "_load_native_ledger", "pytest_addoption", "pytest_configure"}
    if include:
        segments.append(ast.get_source_segment(source, node))
hooks = "import importlib\nimport importlib.metadata\nimport importlib.util\nimport json\nimport math\nimport platform\nimport re\nfrom collections import Counter\nfrom pathlib import Path\nimport pytest\n\n" + "\n\n".join(segments) + "\n"
ns = {"__name__": "reviewed_policy"}
exec(compile(hooks, str(SOURCE), "exec"), ns)
results = []

def setup(name, preflight="simulated", native_source=None, native_ledger=None):
    root = SCRATCH / "projects" / name
    native = root / "tests/mlx_native"
    native.mkdir(parents=True, exist_ok=True)
    (root / "pytest.ini").write_text("[pytest]\ntestpaths = tests\naddopts = --strict-markers\nmarkers =\n    runtime: retained runtime marker\n    mlx_native: registered native marker\n")
    (root / "tests/__init__.py").write_text("\"\"\"Inert review test package.\"\"\"\n")
    (native / "__init__.py").write_text("\"\"\"Inert review native package.\"\"\"\n")
    for dep in ("opacus", "kazoo", "gymnasium"):
        (root / f"{dep}.py").write_text(f"from pathlib import Path\nwith Path(__file__).with_name(\"events\").open(\"a\") as out:\n    out.write(\"mandatory-{dep}\\n\")\n")
    (root / "tests/test_plain.py").write_text("def test_plain():\n    pass\n")
    for nodeid in ns["_REQUIRED"]:
        filename, function = nodeid.split("::")
        path = root / filename
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a") as out:
            out.write(f"def {function}():\n    pass\n\n")
    startup = root / ns["_STARTUP"].split("::")[0]
    with startup.open("w") as out:
        out.write("import pytest\npytestmark = pytest.mark.runtime\n")
        for function, count in ns["_STARTUP_CASES"].items():
            if count == 1:
                out.write(f"def {function}():\n    pass\n\n")
            else:
                out.write(f"@pytest.mark.parametrize(\"variant\", range({count}))\ndef {function}(variant):\n    pass\n\n")
    sentinel = "from pathlib import Path\nwith (Path(__file__).parents[2] / \"events\").open(\"a\") as out:\n    out.write(\"native-test-import\\n\")\n"
    if native_source is None:
        native_source = "import pytest\n@pytest.mark.parametrize(\"sample\", [11, 19], ids=[\"first\", \"second\"])\ndef test_scalar(sample):\n    assert sample > 10\n"
    (native / "test_scalar.py").write_text(sentinel + native_source)
    cases = [{"nodeid": f"tests/mlx_native/test_scalar.py::test_scalar[{label}]", "criteria": ["E1", "E3"]} for label in ("first", "second")]
    (native / "cases.json").write_text(json.dumps(native_ledger or {"schema_version": 1, "cases": cases}))
    copied = hooks
    if preflight == "simulated":
        copied += "\ndef _native_prerequisites():\n    with (Path(__file__).parents[1] / \"events\").open(\"a\") as out:\n        out.write(\"simulated-native-preflight\\n\")\n"
    elif preflight == "poisoned":
        copied += "\ndef _native_prerequisites():\n    raise AssertionError(\"default core must never request native preflight\")\n"
    copied += "\ndef pytest_pycollect_makemodule(module_path, parent):\n    if module_path.resolve().is_relative_to((Path(__file__).parent / \"mlx_native\").resolve()):\n        with (Path(__file__).parents[1] / \"events\").open(\"a\") as out:\n            out.write(\"native-module-collector\\n\")\n"
    (root / "tests/conftest.py").write_text(copied)
    return root

def run(name, arguments, expect, required=(), forbidden=(), preflight="simulated", cwd_relative=".", module_search=(), prepare=None, **kwargs):
    root = setup(name, preflight=preflight, **kwargs)
    if prepare:
        prepare(root)
    env = os.environ.copy()
    env.pop("PYTEST_ADDOPTS", None)
    env["PYTHONPATH"] = os.pathsep.join([str(root), str(root / "tests"), *map(str, module_search)])
    env["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    cmd = [sys.executable, "-m", "pytest", "-p", "no:cacheprovider", "-q", *arguments]
    result = subprocess.run(cmd, cwd=root / cwd_relative, env=env, text=True, capture_output=True, timeout=30)
    output = result.stdout + result.stderr
    logfile = SCRATCH / f"{name}.log"
    logfile.write_text(output)
    events_path = root / "events"
    events = events_path.read_text().splitlines() if events_path.exists() else []
    checks = [result.returncode in expect, *[s in output for s in required], *[s not in output for s in forbidden]]
    record = {"name": name, "command": cmd, "cwd": str(root / cwd_relative), "exit_status": result.returncode, "expected_status": expect, "required": list(required), "forbidden": list(forbidden), "events": events, "expectation_met": all(checks), "log": str(logfile), "log_sha256": hashlib.sha256(output.encode()).hexdigest()}
    results.append(record)
    print(json.dumps(record), flush=True)
    return record

if __name__ == "__main__":
    for name, args in [("default-testpaths", []), ("default-tests", ["tests"]), ("default-dot", ["."]), ("base-core", ["tests", "--test-profile=base"]), ("mandatory-core", ["tests", "--test-profile=mandatory"]), ("core-pyargs", ["--pyargs", "tests.test_plain"]), ("core-package-pyargs", ["--pyargs", "tests"])]:
        run(name, args, [0], required=["core scope (native excluded)"], preflight="poisoned")
    run("focused-native-auto-marker", ["tests/mlx_native", "-m", "mlx_native"], [0], required=["2 passed", "native focused execution"], forbidden=["native complete qualification"])
    run("focused-native-marker-negation", ["tests/mlx_native", "-m", "not mlx_native"], [5], required=["2 deselected"], forbidden=["native complete qualification"])
    run("focused-native-runtime-filter", ["tests/mlx_native", "-m", "not runtime"], [0], required=["2 passed", "native focused execution"])
    run("full-native-exact", ["tests/mlx_native", "--test-profile=mlx-native"], [0], required=["2 passed", "native complete qualification"])
    run("full-combined-exact", ["tests", "--test-profile=mlx-native"], [0], required=["native complete qualification"])
    run("canonical-pyargs-node", ["--pyargs", "tests.mlx_native.test_scalar::test_scalar[first]"], [4], required=["mlx-native selector unsupported"], forbidden=["native complete qualification"])
    run("package-alias-pyargs", ["--pyargs", "mlx_native.test_scalar"], [2, 4], required=["mlx-native selector unsupported"], cwd_relative="tests")
    run("bare-alias-pyargs", ["--pyargs", "test_scalar"], [2, 4], required=["mlx-native selector unsupported"], cwd_relative="tests/mlx_native")
    run("focused-param-subset", ["tests/mlx_native/test_scalar.py::test_scalar[second]"], [0], required=["1 passed", "native focused execution"], forbidden=["native complete qualification"])
    run("profile-param-subset", ["tests/mlx_native/test_scalar.py::test_scalar[second]", "--test-profile=mlx-native"], [1], required=["native ledger missing", "native qualification failed"], forbidden=["native complete qualification"])
    run("profile-keyword-filter", ["tests/mlx_native", "--test-profile=mlx-native", "-k", "second"], [4], required=["qualification does not permit"], forbidden=["native complete qualification"])
    run("profile-collect-only", ["tests/mlx_native", "--test-profile=mlx-native", "--collect-only"], [0], required=["native collection-only validation"], forbidden=["native complete qualification"])
    run("profile-empty-collection", ["tests/test_plain.py", "--test-profile=mlx-native"], [1], required=["native ledger missing"], forbidden=["native complete qualification"])
    run("focused-collectskip", ["tests/mlx_native"], [5, 1], required=["unexpected skip"], native_source="import pytest\npytest.skip(\"import omitted\", allow_module_level=True)\n")
    run("profile-keyboardinterrupt", ["tests/mlx_native", "--test-profile=mlx-native"], [2], required=["native qualification failed"], forbidden=["native complete qualification"], native_source="def test_interrupt():\n    raise KeyboardInterrupt(\"review interrupt\")\n", native_ledger={"schema_version":1,"cases":[{"nodeid":"tests/mlx_native/test_scalar.py::test_interrupt","criteria":["E7"]}]})
    Path(SCRATCH / "results.json").write_text(json.dumps({"source":str(SOURCE),"source_sha256":hashlib.sha256(source.encode()).hexdigest(),"results":results},indent=2)+"\n")
