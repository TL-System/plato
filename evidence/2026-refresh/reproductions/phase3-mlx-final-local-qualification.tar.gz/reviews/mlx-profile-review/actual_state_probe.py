"""Real native preflight preserves nondefault caller scopes on every exit."""
import ast
import hashlib
import importlib
import importlib.metadata
import json
import math
import platform
import random
import sys
from pathlib import Path
from types import SimpleNamespace

import mlx.core as mx
import numpy as np
import pytest
import torch

source_path=Path("/tmp/plato-refresh-worktrees/mlx-profile/tests/conftest.py")
source=source_path.read_text()
function=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=="_native_prerequisites")
ns={"platform":platform,"importlib":importlib,"math":math,"pytest":pytest}
exec(compile(ast.get_source_segment(source,function),str(source_path),"exec"),ns)

def snapshot():
    nr=np.random.get_state()
    return {"device":str(mx.default_device()),"streams":[str(mx.default_stream(d)) for d in (mx.cpu,mx.gpu)],"mlx_rng":[np.array(a).tobytes().hex() for a in mx.random.state],"python_rng":repr(random.getstate()),"numpy_rng":[nr[0],nr[1].tobytes().hex(),nr[2],nr[3],nr[4]],"torch_rng":torch.get_rng_state().numpy().tobytes().hex()}

random.seed(93)
np.random.seed(731)
torch.manual_seed(319)
mx.random.seed(192)
mx.set_default_device(mx.cpu)
cpu=mx.new_stream(mx.cpu)
gpu=mx.new_stream(mx.gpu)
results=[]
for failure in (None,"cpu-result","gpu-result"):
    with mx.stream(gpu), mx.stream(cpu):
        before=snapshot()
        count=[0]
        def check(value):
            count[0]+=1
            if (failure=="cpu-result" and count[0]==1) or (failure=="gpu-result" and count[0]==2):
                return False
            return math.isfinite(value)
        ns["math"]=SimpleNamespace(isfinite=check)
        outcome="passed"
        cause=None
        try:
            ns["_native_prerequisites"]()
        except pytest.UsageError as exc:
            outcome=str(exc)
            cause=type(exc.__cause__).__name__
        after=snapshot()
        assert before==after,(failure,[key for key in before if before[key]!=after[key]])
        if failure is None:
            assert outcome=="passed" and count[0]==2
        else:
            assert "arithmetic returned" in outcome and cause=="RuntimeError"
        results.append({"failure_injection":failure,"outcome":outcome,"cause":cause,"arithmetic_checks":count[0],"caller_device":before["device"],"caller_streams":before["streams"],"all_caller_device_streams_and_rngs_preserved":True})
record={"schema_version":1,"scope":"Exact production MLX prerequisite only; actual CPU/Metal arithmetic with simulated result rejection; not E1-E7 qualification","source":str(source_path),"source_sha256":hashlib.sha256(source.encode()).hexdigest(),"python":sys.version,"platform":platform.platform(),"versions":{name:importlib.metadata.version(name) for name in ("mlx","mlx-metal","pytest")},"results":results}
Path("/tmp/plato-mlx-profile-independent-review/actual_state_probe.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record,indent=2))
