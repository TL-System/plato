import json
from pathlib import Path
import probes

probes.run("nonroot-full-runtime-base", ["..", "--test-profile=base", "-m", "runtime"], [0], required=["48 passed", "core scope (native excluded)"], preflight="poisoned", cwd_relative="tests")
probes.run("nonroot-full-nonruntime-mandatory", ["..", "--test-profile=mandatory", "-m", "not runtime"], [0], required=["7 passed", "core scope (native excluded)"], preflight="poisoned", cwd_relative="tests")
probes.run("focused-native-keyword", ["tests/mlx_native", "-k", "second"], [0], required=["1 passed", "1 deselected", "native focused execution"], forbidden=["native complete qualification"])
probes.run("native-duplicate-selector", ["tests/mlx_native/test_scalar.py", "tests/mlx_native/test_scalar.py", "--keep-duplicates", "--test-profile=mlx-native", "--collect-only"], [1], required=["native ledger extra", "native ledger duplicate collection"], forbidden=["native complete qualification"])
probes.run("qualified-empty-ledger", ["tests/mlx_native", "--test-profile=mlx-native"], [4], required=["cases must be a nonempty list"], forbidden=["native complete qualification"],native_ledger={"schema_version":1,"cases":[]})
probes.run("qualified-renamed-parameter", ["tests/mlx_native", "--test-profile=mlx-native", "--collect-only"], [1], required=["native ledger missing", "native ledger extra"], forbidden=["native complete qualification"],native_source="import pytest\n@pytest.mark.parametrize(\"sample\", [11, 19], ids=[\"first\", \"renamed\"])\ndef test_scalar(sample):\n    pass\n")
probes.run("qualified-core-ledger-omission", ["tests", "--test-profile=mlx-native", "--collect-only"], [1], required=["required tests omitted"], forbidden=["native complete qualification"],prepare=lambda root:(root/"tests/mpc/test_mpc.py").unlink())
probes.run("qualified-nonstrict-xpass", ["tests/mlx_native", "--test-profile=mlx-native"], [1], required=["unexpected xfail/xpass"], forbidden=["native complete qualification"],native_source="import pytest\n@pytest.mark.xfail(strict=False)\n@pytest.mark.parametrize(\"sample\", [11, 19], ids=[\"first\", \"second\"])\ndef test_scalar(sample):\n    pass\n")
probes.run("focused-teardown-failure", ["tests/mlx_native"], [1], forbidden=["native complete qualification"],native_source="import pytest\n@pytest.fixture(autouse=True)\ndef teardown():\n    yield\n    pytest.fail(\"review teardown\")\n@pytest.mark.parametrize(\"sample\", [11, 19], ids=[\"first\", \"second\"])\ndef test_scalar(sample):\n    pass\n")
Path(probes.SCRATCH/"extra_results.json").write_text(json.dumps(probes.results,indent=2)+"\n")
