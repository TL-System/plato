import importlib.abc
import json
import sys
from pathlib import Path
import pytest

lookups=[]
class Blocker(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname=="mlx.core":
            lookups.append(fullname)
            raise RuntimeError("independent backend sentinel reached before native preflight")
        return None
sys.meta_path.insert(0,Blocker())
code=pytest.main(["tests","--collect-only","-q","-p","no:cacheprovider"])
record={"exit_status":int(code),"blocked_backend_lookups":lookups,"scope":"Full exact committed conftest default collection, native backend sentinel substituted by import finder; not an actual broken MLX claim"}
Path("/tmp/plato-mlx-profile-independent-review/backend_import_blocker.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record))
sys.exit(code)
