import datetime
import importlib.metadata
import json
import platform
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('/tmp/plato-refresh-worktrees/mlx-final')
OUT = Path('/tmp/plato-mlx-final-independent-review')
sys.path.insert(0, str(OUT))
from run_checks import sha


def read(name):
    return json.loads((OUT / name).read_text())


def external(path):
    p = Path(path)
    return {'path': str(p), 'sha256': sha(p)}


def xml_summary(name):
    suites = list(ET.parse(OUT / f'{name}.xml').getroot().iter('testsuite'))
    assert len(suites) == 1
    counts = dict(suites[0].attrib)
    assert counts['errors'] == counts['failures'] == counts['skipped'] == '0'
    return counts


names = ['typing-installed', 'typing-absent-linux', 'ruff-required',
         'native-focused', 'profile-installed', 'profile-absent',
         'dispatch-independent', 'frontdoors-installed', 'frontdoors-absent',
         'collection-default', 'collection-sentinel', 'collection-runtime',
         'collection-full-native', 'socket-instrumentation']
statuses = [read(name + '-status.json') for name in names]
assert all(s['exit_status'] == 0 for s in statuses)
source = read('source-audit.json')
assert source['commit'] == '6311960cdd00955d4777e269ebee460be591065e'
assert subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=ROOT, text=True) == ''
source['tree'] = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip()
for p in ['pyproject.toml', '.github/workflows/pytorch_tests.yml',
          'uv.lock', 'tests/mlx_native/cases.json']:
    source['source_sha256'][p] = sha(ROOT / p)
dispatch = read('independent-dispatch-results.json')
collections = []
for name in ['collection-default', 'collection-sentinel', 'collection-runtime', 'collection-full-native']:
    record = read(name + '.json')
    collections.append({'name': name, 'exit_status': record['exit_status'],
        'node_count': record['node_count'], 'native_node_count': record['native_node_count'],
        'startup_count': record['startup_count'], 'runtime_count': record['runtime_count'],
        'backend_modules': len(record['backend_modules']),
        'allowed_metadata_presence_queries': sum(e['transformers_presence'] for e in record['backend_resolution_events']),
        'native_counter_matches_frozen_ledger': record['native_counter_equals_frozen_383']})
case_ledger = json.loads((ROOT / 'tests/mlx_native/cases.json').read_text())
handoff = json.loads((ROOT / 'evidence/2026-refresh/mlx-profile-typing/native-typing-node-handoff.json').read_text())
assert {c['nodeid']: c['criteria'] for c in case_ledger['cases']} == handoff['experiments']
assert len(handoff['nodes']) == len(set(handoff['nodes'])) == handoff['node_count'] == 383
assert set(handoff['nodes']) == {c['nodeid'] for c in case_ledger['cases']}
root_full_log = Path('/tmp/plato-mlx-final/checks/base-linux-full-typing.log')
root_summary = json.loads(Path('/tmp/plato-mlx-final/checks/base-linux-typing-summary.json').read_text())
diagnostics = list(re.finditer(r'^(.+?):(\d+):(\d+): (?:error|warning)\[([^]]+)\]', root_full_log.read_text(), re.M))
assert len(diagnostics) == root_summary['total'] == 661
assert not [m.groups() for m in diagnostics if m[1] in source['source_sha256']]
socket_result = json.loads((OUT / 'socket-instrumentation-tmp/test_real_native_lenet_two_cli0/socket/result.json').read_text())
report = {
    'schema_version': 1,
    'reviewer': '/root/mlx_final_review',
    'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'decision': 'ACCEPTED_BOUNDED_REVIEW',
    'summary': 'No critical, high, or medium findings. All57 required changed-path typing diagnostics are closed on final6311 without runtime or numerical assertion weakening. Native/profile corrections, CI owned-path expansion, and reproduction-only manifest exclusion are accepted in this bounded scope.',
    'findings': [],
    'advisory_observations': [{
        'severity': 'low', 'acceptance_blocking': False,
        'path': 'plato/utils/tree.py', 'line': 16,
        'title': 'Three unchanged unused typing aliases under optional expanded RuffF scope',
        'details': 'Dict, List and Tuple at columns40,46,52 yield F401 only under extra reviewer --select I,F. tree.py is byte-identical to0929; required existing RuffI policy passes. No source cleanup requested in this correction.',
        'evidence': external(OUT / 'ruff.log')}],
    'scope': 'Independent final correction review of immutable combined6311 against semantic-reviewed0929. Exact 24 active Python paths, source receipts, assertions/fixtures/signatures, optional algorithm behavior, real-valued CPU/Metal prerequisite, lazy/import boundary, native ledger, CI typing classifier, and bounded packaging delta. No source edits, nested agents, environment sync/install, long full-core duplication, benchmarks, PR or merge actions.',
    'implementation': source,
    'reviewed_prior_context': [external(p) for p in [
        '/tmp/plato-mlx-corrected-review.json', '/tmp/plato-mlx-native-review.json',
        '/tmp/plato-mlx-profile-review.json', '/tmp/plato-mlx-profile-contract-clarification.json',
        '/tmp/plato-mlx-docs-review.json']],
    'correction_assessment': {
        'optional_algorithm_narrowing': 'Exactly adds algorithm is not None to callable-validator branch. Generic validation remains first; absent algorithm accepts valid generic inputs and rejects negative samples; provided baseline avoids extra extraction. No unconditional require_algorithm change.',
        'preflight': 'Exact final production function AST tested independently with CPU and GPU real3.0 controls, complex3+0j/3+1j,NaN,infinity,wrong4.0,None.14rows:2valid controls,12cause-bearing UsageError rejects with stream restored. Real float32 array construction, eval,synchronize,finite/equal3.0 checks remain unchanged.',
        'native_fixture_casts': 'typing.cast returns original model/loss/RNG-state/duck-typed trainer/sampler objects. Every changed native assertion and NumPy testing call has identical AST after erasing identity casts and substituting the explicitly assigned model alias. Native test names/parameter decorators retained.',
        'method_overrides_and_observers': 'Default callback **kwargs and aggregation parameter names now match base contracts. Fixture clients_processed lambda is an equivalent no-op subclass method. Client observer exactly matches plato.client.run seven-parameter signature and forwards all seven; Process.start observer receives BaseProcess and retains original start plus identity recording. Actual revised socket instrumentation independently executed successfully.',
        'benchmark_API': 'Only converted receives a tuple[mx.array,mx.array] annotation; no API call, arithmetic, timing loop, barrier or numerical assertion changes. The six-argument training_step interface matches model,optimizer,*two_arrays,loss,context. No benchmark execution or new timing claim.',
        'policy_helpers': 'Frozen _PytestResult preserves subprocess status and exact stdout+stderr string; AST module-name optional guard is safe; one additional plugin-presence assert is added. All prior policy assertions and test decorators retained.',
        'CI': 'Exact old owned set union24 changed active Python paths; classifier AST outside owned-set expression identical; two existing datasource allowances unchanged. No new typing suppression or dependency/config changes.',
        'manifest': 'Parsed pyproject equality after restoring solely previous hatch exclude list. uv.lock unchanged; active source/test/config/docs/workflow and ordinary evidence members remain in reviewed isolated package pair.',
        'source_binding_limit': 'Eight native changed files and four profile files exactly match correction receipt hashes. Final fedavg full-file SHA differs from native-author SHA only because preaccepted Nanochat retirement was already combined in0929; exact validation method AST matches and0929-to6311 delta is solely optional narrowing. Historical/native-author hashes are preserved as historical, not silently relabeled.'},
    'independent_checks': {
        'environments': read('environments.json'),
        'statuses': statuses,
        'pytest': {name: xml_summary(name) for name in ['native-focused','profile-installed','profile-absent','socket-instrumentation']},
        'total_executed_pytest_cases': 660,
        'all_tests_zero_skip_failure_error': True,
        'typing': 'All24paths ty0 in real installed native Python3.13 and genuine absent-MLX base Python3.13 with static Linux target; required RuffI0.',
        'collections': collections,
        'dispatch': {'invalid_cases': len(dispatch['invalid_cases']),
            'valid_8_24_controls': len(dispatch['valid_controls']),
            'zero_total_controls': len(dispatch['all_zero_controls']),
            'details': '120 late-hook invalid shape/container/count/order/identity cases reject before subtraction/aggregation/load; global model, retained baseline and post-hook caller objects remain unchanged. Six valid copied positional controls produce3.25; four zero-total direct/delta controls preserve baseline.',
            'accepted_positional_limit': dispatch['accepted_positional_limit']},
        'frontdoors_installed': read('frontdoors-installed.json'),
        'frontdoors_absent': read('frontdoors-absent.json'),
        'preflight_optional_algorithm': read('preflight-and-optional-algorithm.json'),
        'assertion_audit': read('assertion-audit.json'),
        'packaging': read('package-audit.json'),
        'native_evidence_archive': read('native-archive-audit.json'),
        'frozen_native_handoff': {'383_node_IDs_and_all_E1_E7_criteria_exactly_match_final_ledger': True,
                                 'handoff_sha256': sha(ROOT / 'evidence/2026-refresh/mlx-profile-typing/native-typing-node-handoff.json')},
        'socket_result': socket_result,
        'root_full_typing_receipt_independently_classified': {
            'log': external(root_full_log), 'summary': root_summary,
            'all661_diagnostics_parsed': True, 'zero24_changed_paths': True,
            'exact_final_CI_classifier_execution': read('CI-classifier-execution.json'),
            'limitation': 'Root-produced full log independently classified, not a reviewer full-repository rerun or whole-repository typing-clean claim.'}},
    'historical_evidence_and_limits': {
        'E8': 'Historical E8 timings remain bound to measured original source. Final-hook/lazy/typing corrections were not remeasured; no new performance, compiled-benefit or full-round claim; eager remains default.',
        'preflight_semantics': 'Rejection adds no mutations after intentional mutable hook side effects; it does not promise rollback of hook actions. Copied unlabeled same-schema trees retain positional correspondence contract, so schema/identity cannot infer copied semantic association.',
        'platform': 'Only Python3.13 used. Native probes execute actual Apple arm64 CPU/Metal. Absent-MLX Linux static target is run on macOS base environment, not actual Linux runtime qualification.',
        'full_qualification': 'Root-final383 native execution receipt read and retained separately; reviewer ran445focused native/server plus1real socket and214profile cases, not the complete profile execution. Old0929 full-core/DP/runtime qualification remains historical-source-bound. Final actual Linux CI gate remains root-owned and pending; this bounded acceptance does not approve merging or complete delivery.',
        'docs': 'Prior docs review remains separately accepted; all final delta paths inspected and no documentation changes introduced.',
        'other_limits': 'Float32 training/float16 host transport/bfloat16 limit, weight-only checkpoint, same-environment replay, and prebuilt caller lazy-graph placement limits remain unchanged.'},
    'harness_notes': [
        'Initial source-audit hash equality intentionally exposed the native-author full fedavg file retaining retired Nanochat code; bounded correction-method binding and exact root delta were then verified. No source mutation or failure suppressed.',
        'Copied independent dispatch harness first lacked its task-owned runtime directory. Initial failure log/status retained; creating only that directory produced120valid rejects/6valid controls/4zero controls. No production/assertion change.',
        'Fresh dispatch/frontdoor/import probes adapt previous independent reviewer harness only by changing task-owned artifacts/bootstrap and final source configuration paths; assertions remain unchanged. Adaptation provenance retained.'
    ],
    'source_integrity': {'worktree': str(ROOT), 'clean_before_and_after': True,
                         'no_source_edits': True, 'read_only_environments': True},
    'artifacts': [{'path': str(p), 'sha256': sha(p)} for p in sorted(OUT.iterdir())
                  if p.is_file() and p.suffix in {'.py','.json','.log','.xml'}],
    'root_native_execution_receipt': external('/tmp/plato-mlx-final/run-mlx-native/receipt.json'),
    'completion': {'bounded_review_complete': True, 'original_author_correction_required': False,
                   'root_delivery_gates_remain': True}
}
destination = Path('/tmp/plato-mlx-final-review.json')
destination.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'path':str(destination),'sha256':sha(destination),'decision':report['decision'],
                  'findings':len(report['findings']),'pytest_cases':report['independent_checks']['total_executed_pytest_cases']}))
