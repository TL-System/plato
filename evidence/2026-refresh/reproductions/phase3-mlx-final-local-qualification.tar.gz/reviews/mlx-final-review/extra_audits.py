import ast
import contextlib
import hashlib
import json
import os
import subprocess
import sys
import tarfile
from pathlib import Path
from types import SimpleNamespace

ROOT = Path('/tmp/plato-refresh-worktrees/mlx-final')
OUT = Path('/tmp/plato-mlx-final-independent-review')
sys.path.insert(0, str(OUT))
from run_checks import run, sha


def packaging():
    receipt = json.loads((ROOT / 'evidence/2026-refresh/mlx-profile-typing/package-member-audit.json').read_text())['root_frozen_sdist']
    def members(path):
        with tarfile.open(path, 'r:gz') as archive:
            data = {}
            for member in archive.getmembers():
                if member.isfile():
                    relative = '/'.join(Path(member.name).parts[1:])
                    data[relative] = hashlib.sha256(archive.extractfile(member).read()).hexdigest()
            return data
    verified = {}
    for label in ['before', 'after']:
        entry = receipt[label]
        assert Path(entry['path']).stat().st_size == entry['bytes']
        assert sha(entry['path']) == entry['sha256']
        verified[label] = entry
    old, new = members(receipt['before']['path']), members(receipt['after']['path'])
    removed = sorted(set(old) - set(new))
    added = sorted(set(new) - set(old))
    changed = sorted(p for p in set(old) & set(new) if old[p] != new[p])
    assert len(removed) == 80 and all(p.startswith('evidence/2026-refresh/reproductions/') for p in removed)
    assert removed == receipt['removed_paths']
    assert not added and changed == ['pyproject.toml']
    assert len(old) == receipt['before_members'] and len(new) == receipt['after_members']
    for side in ['before', 'after']:
        entry = receipt['wheel'][side]
        assert Path(entry['path']).stat().st_size == entry['bytes']
        assert sha(entry['path']) == entry['sha256']
    assert receipt['wheel']['before']['sha256'] == receipt['wheel']['after']['sha256']
    record = {'raw_sdist_hashes_and_sizes_verified': verified,
              'before_members': len(old), 'after_members': len(new),
              'removed_members': removed, 'added_members': added,
              'changed_retained_members': changed,
              'unchanged_retained_members': len(set(old) & set(new)) - len(changed),
              'retained_wheels_byte_identical': True,
              'wheel_sha256': receipt['wheel']['before']['sha256'],
              'source_limit': 'Package pair isolates only manifest exclusion on frozen0929; it does not bind all final6311 Python changes.'}
    (OUT / 'package-audit.json').write_text(json.dumps(record, indent=2))
    print('package member audit passed', flush=True)


def preflight():
    os.environ['config_file'] = str(ROOT / 'configs/MNIST/fedavg_lenet5.toml')
    bootstrap = OUT / 'bootstrap'
    bootstrap.mkdir(exist_ok=True)
    sys.argv = [sys.argv[0], '-b', str(bootstrap), '--cpu']
    from tests import conftest
    import pytest
    assert not any(n == 'mlx' or n.startswith('mlx.') for n in sys.modules)
    actual_globals = conftest._native_prerequisites.__globals__
    namespace = dict(actual_globals)
    definition = next(n for n in ast.parse((ROOT / 'tests/conftest.py').read_text()).body
                      if isinstance(n, ast.FunctionDef) and n.name == '_native_prerequisites')
    exec(compile(ast.Module(body=[definition], type_ignores=[]), str(ROOT / 'tests/conftest.py'), 'exec'), namespace)
    records = []
    for target in ['cpu', 'gpu']:
        for label, scalar in [('real', 3.0), ('complex', 3+0j), ('imaginary', 3+1j),
                              ('nan', float('nan')), ('infinite', float('inf')),
                              ('wrong', 4.0), ('none', None)]:
            state = {'active': 'caller', 'evaluated': [], 'synchronized': []}
            @contextlib.contextmanager
            def stream(device):
                original = state['active']
                state['active'] = device
                try:
                    yield
                finally:
                    state['active'] = original
            def item():
                return scalar if state['active'] == target else 3.0
            def evaluate(_result):
                state['evaluated'].append(state['active'])
            core = SimpleNamespace(cpu='cpu', gpu='gpu', float32='float32',
                stream=stream, array=lambda values, dtype: values,
                sum=lambda values: SimpleNamespace(item=item), eval=evaluate,
                synchronize=lambda device: state['synchronized'].append(device),
                metal=SimpleNamespace(is_available=lambda: True))
            imports = {'mlx.core': core, 'mlx.nn': object(), 'mlx.optimizers': object()}
            namespace['importlib'] = SimpleNamespace(import_module=lambda name: imports[name],
                metadata=SimpleNamespace(version=lambda name: '0.32.3'))
            namespace['platform'] = SimpleNamespace(system=lambda: 'Darwin', machine=lambda: 'arm64')
            try:
                namespace['_native_prerequisites']()
            except pytest.UsageError as error:
                assert label != 'real'
                assert error.__cause__ is not None
                if label in ('complex', 'imaginary', 'none'):
                    assert isinstance(error.__cause__, TypeError)
                else:
                    assert isinstance(error.__cause__, RuntimeError)
                assert 'mlx-native prerequisite failed (Darwin arm64)' in str(error)
                outcome = str(error)
            else:
                assert label == 'real'
                assert state['evaluated'] == ['cpu', 'gpu']
                outcome = 'pass'
            assert state['active'] == 'caller'
            records.append({'device': target, 'value_kind': label, 'outcome': outcome,
                            'state': state.copy()})
    from plato.servers.fedavg import Server
    update = SimpleNamespace(client_id=1, report=SimpleNamespace(num_samples=2, type='weights'))
    missing = SimpleNamespace(algorithm=None)
    Server._validate_aggregation_inputs(missing, [update], [{'w': [1]}])
    update.report.num_samples = -1
    try:
        Server._validate_aggregation_inputs(missing, [update], [{'w': [1]}])
    except ValueError:
        pass
    else:
        raise AssertionError('Missing algorithm must not bypass generic negative sample count check')
    calls = []
    algorithm = SimpleNamespace(extract_weights=lambda: calls.append('extract') or {'w': 0},
                                validate_weights=lambda weights, baseline, **kwargs: calls.append((weights, baseline, kwargs)))
    update.report.num_samples = 2
    Server._validate_aggregation_inputs(SimpleNamespace(algorithm=algorithm), [update], [{'w': 1}], {'w': 9})
    assert len(calls) == 1 and calls[0][1] == {'w': 9}
    (OUT / 'preflight-and-optional-algorithm.json').write_text(json.dumps({
        'preflight_rows': records, 'exact_final_production_function_AST': True,
        'production_import_did_not_load_backend': True,
        'missing_algorithm_valid_behavior_preserved': True,
        'missing_algorithm_negative_count_still_rejected': True,
        'provided_baseline_avoids_extra_extraction': True}, indent=2))
    print('preflight and optional algorithm probes passed', flush=True)


def adapted_probes():
    previous = Path('/tmp/plato-mlx-corrected-independent-review')
    for name in ['independent_dispatch.py', 'independent_frontdoors.py', 'independent_import.py']:
        code = (previous / name).read_text()
        code = code.replace(str(previous), str(OUT))
        code = code.replace(str(OUT / 'checkout'), str(ROOT))
        code = code.replace('ROOT/"checkout/configs/', 'Path("' + str(ROOT) + '")/"configs/')
        (OUT / name).write_text(code)
    (OUT / 'adapted-probes-provenance.json').write_text(json.dumps({
        'from': str(previous), 'changes': 'Only task-owned output/bootstrap paths and final source configuration paths changed.',
        'previous_review': '/tmp/plato-mlx-corrected-review.json',
        'final_PYTHONPATH_and_cwd': str(ROOT)}, indent=2))
    run('dispatch-independent', ['/tmp/plato-mlx-final/env/bin/python', '-B', str(OUT/'independent_dispatch.py')])
    run('frontdoors-installed', ['/tmp/plato-mlx-final/env/bin/python', '-B', str(OUT/'independent_frontdoors.py'), str(OUT/'frontdoors-installed.json')])
    run('frontdoors-absent', ['/tmp/plato-llm-integration/base-313/bin/python', '-B', str(OUT/'independent_frontdoors.py'), str(OUT/'frontdoors-absent.json')])
    cases = [
        ('collection-default', 'observe', ['tests', '--collect-only'], 0),
        ('collection-sentinel', 'sentinel', ['tests', '--collect-only', '--test-profile=base'], 0),
        ('collection-runtime', 'observe', ['tests', '--collect-only', '--test-profile=mandatory', '-m', 'runtime'], 0),
        ('collection-full-native', 'observe', ['tests/mlx_native', '--collect-only', '--test-profile=mlx-native'], 0),
    ]
    for name, mode, arguments, expected in cases:
        status = run(name, ['/tmp/plato-mlx-final/env/bin/python', '-B', str(OUT/'independent_import.py'), str(OUT/f'{name}.json'), mode, *arguments])
        assert status['exit_status'] == expected
        record = json.loads((OUT/f'{name}.json').read_text())
        assert record['production_conftest_loaded']
        if name != 'collection-full-native':
            assert record['backend_modules'] == [] and record['native_test_modules'] == []
            assert all(e['module'] == 'mlx' and e['transformers_presence'] for e in record['backend_resolution_events'])
            assert record['startup_count'] == 48
            if name == 'collection-runtime':
                assert record['runtime_count'] == 51
            else:
                assert record['node_count'] == 1440
        else:
            assert record['native_node_count'] == 383 and record['native_counter_equals_frozen_383']
            backend = [e for e in record['backend_resolution_events'] if not e['transformers_presence']]
            assert backend and backend[0]['in_preflight']


if __name__ == '__main__':
    {'package': packaging, 'preflight': preflight, 'adapted': adapted_probes}[sys.argv[1]]()
