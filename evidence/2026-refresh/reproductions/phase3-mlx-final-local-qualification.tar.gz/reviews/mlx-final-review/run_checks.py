import ast
import hashlib
import json
import os
import subprocess
import sys
import tomllib
from pathlib import Path

ROOT = Path('/tmp/plato-refresh-worktrees/mlx-final')
OUT = Path('/tmp/plato-mlx-final-independent-review')
OLD = '0929b5a527c766be59bfff7fb2ea2749c02f3f2e'
PYTHON = '/tmp/plato-mlx-final/env/bin/python'
BASE = '/tmp/plato-llm-integration/base-313/bin/python'
OUT.mkdir(exist_ok=True)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def old_text(path):
    return subprocess.check_output(
        ['git', 'show', f'{OLD}:{path}'], cwd=ROOT, text=True
    )


def run(name, args, timeout=180):
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(ROOT),
               PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', OMP_NUM_THREADS='1',
               MKL_NUM_THREADS='1')
    env.pop('PYTEST_ADDOPTS', None)
    result = subprocess.run(args, cwd=ROOT, env=env, capture_output=True,
                            text=True, timeout=timeout)
    (OUT / f'{name}.log').write_text(result.stdout + result.stderr)
    record = {'name': name, 'command': args, 'exit_status': result.returncode,
              'log': str(OUT / f'{name}.log'),
              'log_sha256': sha(OUT / f'{name}.log')}
    (OUT / f'{name}-status.json').write_text(json.dumps(record, indent=2))
    print(json.dumps(record), flush=True)
    return record


def workflow_classifier(text):
    start = text.index('          import re\n')
    end = text.index('          PY\n', start)
    code = '\n'.join(line[10:] for line in text[start:end].splitlines())
    return ast.parse(code)


def audit():
    paths = json.loads((ROOT / 'evidence/2026-refresh/mlx-profile-typing/changed-active-python.json').read_text())
    hashes = {p: sha(ROOT / p) for p in paths}
    before = workflow_classifier(old_text('.github/workflows/pytorch_tests.yml'))
    after = workflow_classifier((ROOT / '.github/workflows/pytorch_tests.yml').read_text())
    def assignments(tree):
        return {n.targets[0].id: n for n in tree.body if isinstance(n, ast.Assign)
                and isinstance(n.targets[0], ast.Name)}
    old_assigns, new_assigns = assignments(before), assignments(after)
    old_owned = ast.literal_eval(old_assigns['owned'].value)
    new_owned = ast.literal_eval(new_assigns['owned'].value)
    assert len(paths) == 24 and len(set(paths)) == 24
    assert new_owned == old_owned | set(paths)
    assert ast.dump(old_assigns['allowed']) == ast.dump(new_assigns['allowed'])
    new_assigns['owned'].value = old_assigns['owned'].value
    assert ast.dump(before) == ast.dump(after)
    old_manifest = tomllib.loads(old_text('pyproject.toml'))
    new_manifest = tomllib.loads((ROOT / 'pyproject.toml').read_text())
    assert new_manifest['tool']['hatch']['build']['exclude'] == [
        'archives/retired/**', 'evidence/2026-refresh/reproductions/**']
    new_manifest['tool']['hatch']['build']['exclude'] = old_manifest['tool']['hatch']['build']['exclude']
    assert new_manifest == old_manifest
    for path in ['tests/mlx_native/cases.json', 'uv.lock',
                 'plato/algorithms/mlx_fedavg.py', 'plato/algorithms/registry.py',
                 'plato/models/registry.py', 'plato/trainers/mlx.py',
                 'plato/trainers/registry.py', 'plato/utils/tree.py',
                 'tests/mlx_native/test_phase3_dispatch.py',
                 'tests/mlx_native/test_phase3_selection.py',
                 'tests/mlx_import_audit_runner.py', 'tests/test_mlx_import_contract.py']:
        assert (ROOT / path).read_text() == old_text(path), path
    native = json.loads((ROOT / 'evidence/2026-refresh/phase3-mlx-typing-correction.json').read_text())
    profile = json.loads((ROOT / 'evidence/2026-refresh/mlx-profile-typing/receipt.json').read_text())
    source_binding = {}
    for label, receipt, key in [('native', native['source'], 'after_sha256'),
                                ('profile', profile, 'source_sha256')]:
        source_binding[label] = {p: {'actual': sha(ROOT / p), 'author': expected,
                                   'matches': sha(ROOT / p) == expected}
                                 for p, expected in receipt[key].items()}
        for path, item in source_binding[label].items():
            if item['matches']:
                continue
            assert label == 'native' and path == 'plato/servers/fedavg.py'
            author_text = subprocess.check_output(
                ['git', 'show', f"{native['source']['commit']}:{path}"],
                cwd=ROOT, text=True)
            def validation_method(text):
                return next(n for n in ast.walk(ast.parse(text))
                            if isinstance(n, ast.FunctionDef)
                            and n.name == '_validate_aggregation_inputs')
            assert ast.dump(validation_method(author_text)) == ast.dump(
                validation_method((ROOT / path).read_text()))
            item['bounded_binding'] = ('Native validation method AST identical; '
                'full-file difference is preaccepted Nanochat retirement retained '
                'from0929. Root0929-to-final diff is exactly the optional narrowing.')
    for item in profile['artifacts']:
        assert sha(ROOT / item['path']) == item['sha256'], item['path']
    archive = native['archive']
    assert sha(ROOT / archive['path']) == archive['sha256']
    for path in ['tests/conftest.py', 'tests/mlx_native/test_phase3_controls.py',
                 'tests/mlx_native/test_phase3_rng.py',
                 'tests/mlx_native/test_phase3_runtime.py',
                 'tests/mlx_native/test_phase3_tree_contract.py',
                 'tests/test_mlx_profile_contract.py']:
        prior, final = ast.parse(old_text(path)), ast.parse((ROOT / path).read_text())
        def test_defs(tree):
            return {n.name: [ast.dump(d) for d in n.decorator_list]
                    for n in tree.body if isinstance(n, ast.FunctionDef)
                    and n.name.startswith('test_')}
        assert test_defs(prior) == test_defs(final), path
        prior_count = sum(isinstance(n, ast.Assert) for n in ast.walk(prior))
        final_count = sum(isinstance(n, ast.Assert) for n in ast.walk(final))
        assert final_count >= prior_count, path
    result = {'commit': subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT, text=True).strip(),
              'source_sha256': hashes, 'CI_owned_paths': sorted(old_owned | set(paths)),
              'CI_classifier_AST_unchanged': True, 'datasource_allowances_unchanged': True,
              'manifest_only_authorized_exclusion': True,
              'case_ledger_and_runtime_frontdoors_byte_unchanged': True,
              'test_names_decorators_preserved_and_assert_counts_not_reduced': True,
              'source_binding': source_binding, 'all_profile_artifact_hashes_verified': True,
              'native_typing_archive_sha_verified': True}
    (OUT / 'source-audit.json').write_text(json.dumps(result, indent=2))
    print('source audit passed', flush=True)
    return paths


if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'static':
        paths = audit()
        run('typing-installed', ['/tmp/plato-mlx-final/env/bin/ty', 'check', *paths,
             '--python', PYTHON, '--python-version', '3.13', '--output-format', 'concise'])
        run('typing-absent-linux', ['/tmp/plato-mlx-final/env/bin/ty', 'check', *paths,
             '--python', BASE, '--python-version', '3.13', '--python-platform', 'linux',
             '--output-format', 'concise'])
        run('ruff', ['/tmp/plato-mlx-final/env/bin/ruff', 'check', *paths, '--select', 'I,F'])
    elif mode in ('installed', 'absent'):
        run(f'profile-{mode}', [PYTHON if mode == 'installed' else BASE, '-B', '-m',
            'pytest', 'tests/test_mlx_profile_contract.py',
            'tests/test_mlx_import_contract.py', '-q', '-p', 'no:cacheprovider',
            f'--basetemp={OUT}/profile-{mode}-tmp',
            f'--junitxml={OUT}/profile-{mode}.xml'])
    elif mode == 'native':
        run('native-focused', [PYTHON, '-B', '-m', 'pytest',
            'tests/mlx_native/test_phase3_dispatch.py',
            'tests/mlx_native/test_phase3_runtime.py',
            'tests/mlx_native/test_phase3_tree_contract.py',
            'tests/mlx_native/test_phase3_controls.py',
            'tests/mlx_native/test_phase3_rng.py',
            'tests/servers/test_fedavg_strategy.py', '-q', '-p', 'no:cacheprovider',
            f'--basetemp={OUT}/native-focused-tmp',
            f'--junitxml={OUT}/native-focused.xml'])
