import ast
import copy
import json
import subprocess
from pathlib import Path

ROOT = Path('/tmp/plato-refresh-worktrees/mlx-final')
OUT = Path('/tmp/plato-mlx-final-independent-review')
OLD = '0929b5a527c766be59bfff7fb2ea2749c02f3f2e'


class Normalize(ast.NodeTransformer):
    def __init__(self, aliases):
        self.aliases = aliases

    def visit_Call(self, node):
        if isinstance(node.func, ast.Name) and node.func.id == 'cast':
            return self.visit(copy.deepcopy(node.args[1]))
        return self.generic_visit(node)

    def visit_Name(self, node):
        if node.id in self.aliases:
            return self.visit(copy.deepcopy(self.aliases[node.id]))
        return node


def assertions(text):
    tree = ast.parse(text)
    data = {}
    for function in tree.body:
        if not isinstance(function, ast.FunctionDef):
            continue
        aliases = {}
        for node in ast.walk(function):
            if isinstance(node, ast.Assign) and len(node.targets) == 1:
                target, value = node.targets[0], node.value
                if (isinstance(target, ast.Name) and isinstance(value, ast.Call)
                    and isinstance(value.func, ast.Name) and value.func.id == 'cast'):
                    aliases[target.id] = value.args[1]
        normalizer = Normalize(aliases)
        values = []
        for node in ast.walk(function):
            if isinstance(node, ast.Assert):
                values.append(ast.dump(normalizer.visit(copy.deepcopy(node))))
            if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                and isinstance(node.func.value, ast.Attribute)
                and isinstance(node.func.value.value, ast.Name)
                and node.func.value.value.id == 'np'
                and node.func.value.attr == 'testing'):
                values.append(ast.dump(normalizer.visit(copy.deepcopy(node))))
        if values:
            data[function.name] = values
    return data


results = {}
for path in ['tests/mlx_native/test_phase3_controls.py',
             'tests/mlx_native/test_phase3_rng.py',
             'tests/mlx_native/test_phase3_runtime.py',
             'tests/mlx_native/test_phase3_tree_contract.py',
             'tests/test_mlx_profile_contract.py']:
    prior = assertions(subprocess.check_output(['git','show',f'{OLD}:{path}'], cwd=ROOT, text=True))
    final = assertions((ROOT / path).read_text())
    assert prior.keys() == final.keys()
    for name in prior:
        if path == 'tests/test_mlx_profile_contract.py' and name == 'test_native_manual_configure_does_not_probe':
            new_presence = ast.dump(ast.parse('assert checks is not None').body[0])
            assert final[name].count(new_presence) == 1
            final[name].remove(new_presence)
        assert prior[name] == final[name], (path, name, prior[name], final[name])
    results[path] = {'all_assertions_and_numpy_testing_calls_AST_preserved_after_identity_cast_and_alias_normalization': True,
                     'functions_checked': len(prior)}
(OUT / 'assertion-audit.json').write_text(json.dumps(results, indent=2))
print('Assertion and numerical-check AST preservation verified')
