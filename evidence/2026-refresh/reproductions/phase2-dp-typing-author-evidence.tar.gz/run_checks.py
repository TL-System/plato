import hashlib,json,shlex,subprocess,sys,time
from pathlib import Path
scratch=Path('/tmp/plato-phase2c-dp-typing-fix')
name,version,kind=sys.argv[1:4]
venv=Path('/tmp/plato-phase2c-'+version)
file='tests/trainers/test_dp_data_loader_strategy.py'
if kind=='ty':args=[str(venv/'bin/ty'),'check','--python',str(venv/'bin/python'),'--output-format','concise',file]
elif kind=='tests':args=[str(venv/'bin/python'),'-m','pytest',file,'-q','--basetemp',str(scratch/name),'--junitxml',str(scratch/(name+'.xml'))]
elif kind=='ruff':args=[str(venv/'bin/ruff'),'check',file,'--select','I']
else:raise ValueError(kind)
command='OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 '+shlex.join(args)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
source=Path(file).read_bytes();t=time.monotonic()
with (scratch/(name+'.log')).open('w') as log:r=subprocess.run(['zsh','-lc',command],stdout=log,stderr=subprocess.STDOUT)
d={'name':name,'command':command,'shell':'zsh -lc','head':head,'file_sha256':hashlib.sha256(source).hexdigest(),'python_environment':str(venv),'exit_code':r.returncode,'seconds':time.monotonic()-t,'log':str(scratch/(name+'.log')),'log_sha256':hashlib.sha256((scratch/(name+'.log')).read_bytes()).hexdigest()}
(scratch/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));sys.exit(r.returncode)
