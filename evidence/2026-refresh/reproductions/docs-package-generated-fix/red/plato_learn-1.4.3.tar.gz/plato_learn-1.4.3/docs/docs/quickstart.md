# Quick Start

## Running Plato Directly Using `uv`

To start a federated learning training workload with only a configuration file, run `uv run [Python file] -c [configuration file] ...`. For example:

```bash
uv run plato.py -c configs/MNIST/fedavg_lenet5.toml
```

The following command-line parameters are supported:

- `-c`: the path to the configuration file to be used. The default is `config.toml` in the project's home directory.

- `-b`: the base path, to be used to contain all models, datasets, checkpoints, and results (defaults to `./runtime`).

- `-r`: resume a previously interrupted training session (only works correctly in synchronous training sessions).

- `--cpu`: use the CPU as the device only.

Datasets required by an example are downloaded automatically the first time it runs; subsequent executions reuse the cached copies stored under the chosen base path.

_Plato_ uses the TOML format for its configuration files to manage runtime configuration parameters. Example configuration files have been provided in the `configs/` directory.

In `examples/`, a number of federated learning algorithms have been included. To run them, just run the main Python program in each of the directories with a suitable configuration file. For example, to run the `basic` example located at `examples/basic/`, run the command:

```bash
uv run examples/basic/basic.py -c configs/MNIST/fedavg_lenet5.toml
```

## Running Server-side Lighteval Evaluation

If your config uses:

```toml
[evaluation]
type = "lighteval"
```

install the optional evaluator stack first:

```bash
uv sync --extra llm_eval
```

Then run the reference SmolLM2 configuration:

```bash
uv run python plato.py --config configs/HuggingFace/fedavg_smol_smoltalk_smollm2_135m.toml
```

This configuration performs Hugging Face training locally while the server evaluates the aggregated global model with Lighteval after each round.

See [Evaluation](configurations/evaluation.md) for the available evaluator options and [Server-side Lighteval for SmolLM2](examples/case-studies/4. Server-side Lighteval for SmolLM2.md) for the full example.

## Running Qwen3 Federated LoRA

The bounded Qwen3 example fine-tunes LoRA adapters on a small local text fixture:

```bash
uv run python plato.py --config configs/HuggingFace/fedavg_qwen3_06b_lora.toml --cpu
```

Run from the repository root. The model and tokenizer download from a fixed
Hugging Face revision on first use. See
[Qwen3 Federated LoRA](examples/case-studies/6. Qwen3 Federated LoRA.md)
for setup, memory considerations, and the distinction between offline tests
and pretrained-model qualification.

## Using MLX as a Backend

Run the native LeNet-5/MNIST FedAvg reference on Apple Silicon with Python 3.13:

```bash
uv sync --python 3.13 --extra mlx
uv run --extra mlx python plato.py --config configs/MNIST/fedavg_lenet5_mlx.toml
```

Add `--cpu` for Apple CPU execution; without a device flag the trainer preserves
MLX's native default, normally Metal. The shipped config uses simulated payload
communication and one physical client worker. See [Native MLX](mlx.md) for
socket opt-in, seeds, clipping, optimizer options, checkpoint limits, and the
explicit native qualification command.

## Running Plato in a Docker Container

To build such a Docker image, use the provided `Dockerfile`:

```bash
docker build -t plato -f Dockerfile .
```

To run the docker image that was just built, use the command:

```bash
./dockerrun.sh
```

To remove all the containers after they are run, use the command:

```bash
docker rm $(docker ps -a -q)
```

To remove the `plato` Docker image, use the command:

```bash
docker rmi plato
```

The provided `Dockerfile` helps to build a Docker image running Ubuntu 24.04, with a virtual environment called `plato` pre-configured to run Plato.

## Running Plato in a Docker Container with GPU Support

First, the [NVIDIA Container Toolkit](https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/install-guide.html) will need to be installed on the host machine. On Ubuntu 24.04, follow these steps:

1. Configure the production repository:

```bash
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg \
  && curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
    sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
    sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list
```

2. Update the packages list from the repository:

```bash
sudo apt-get update
```

3. Install the NVIDIA Container Toolkit packages (where `1.17.8-1` is the latest version as of October 2025):

```bash
export NVIDIA_CONTAINER_TOOLKIT_VERSION=1.17.8-1
  sudo apt-get install -y \
      nvidia-container-toolkit=${NVIDIA_CONTAINER_TOOLKIT_VERSION} \
      nvidia-container-toolkit-base=${NVIDIA_CONTAINER_TOOLKIT_VERSION} \
      libnvidia-container-tools=${NVIDIA_CONTAINER_TOOLKIT_VERSION} \
      libnvidia-container1=${NVIDIA_CONTAINER_TOOLKIT_VERSION}
```

4. Configure the Docker runtime for GPU support:

```bash
sudo nvidia-ctk runtime configure --runtime=docker
```

5. Restart Docker:

```bash
sudo systemctl restart docker
```

For more information about installing the NVIDIA Container Toolkit, refer to its [official documentation](https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/latest/install-guide.html).

The following command can be used to verify that GPU access is available in Docker containers:

```bash
docker run --gpus all --rm nvidia/cuda:13.0.1-cudnn-devel-ubuntu24.04 nvidia-smi
```

This should output a table listing your GPUs, confirming that GPU access works.

The following command can be used to enter GPU-enabled Docker container with Plato built-in:

```bash
./dockerrun_gpu.sh
```

## Formatting the Code and Fixing Linter Errors

It is strongly recommended that new additions and revisions of the codebase conform to [Ruff](https://docs.astral.sh/ruff/)'s formatting and linter guidelines. To format the entire codebase automatically, run:

```bash
uvx ruff format
```

To fix all linter errors automatically, run:

```bash
uvx ruff check --fix
```

## Type Checking

It is also strongly recommended that new additions and revisions of the code base to pass Astral's [ty](https://docs.astral.sh/ty/) type checker cleanly. To install `ty` globally using `uv`, run:

```bash
uv tool install ty@latest
```

To check the codebase on any sub-directory in Plato, such as `plato`, run:

```bash
ty check plato
```
