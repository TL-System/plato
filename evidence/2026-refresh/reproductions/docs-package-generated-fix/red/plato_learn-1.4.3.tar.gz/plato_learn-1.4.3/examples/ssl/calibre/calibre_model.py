"""
Implementation of Net used in calibre.
"""

from collections.abc import Sequence
from typing import Any, cast

import torch
from lightly.models.modules.heads import SimCLRProjectionHead

from plato.config import Config
from plato.models.cnn_encoder import Model as encoder_registry


class CalibreNet(torch.nn.Module):
    """The model structure of Calibre."""

    def __init__(self, encoder: torch.nn.Module | None = None) -> None:
        super().__init__()

        # extract hyper-parameters
        encoder_name = Config().trainer.encoder_name
        params: dict[str, Any] = Config().params
        encoder_params_obj = params.get("encoder")
        if isinstance(encoder_params_obj, dict):
            encoder_params: dict[str, Any] = dict(encoder_params_obj)
        else:
            encoder_params = {}

        # define the encoder based on the model_name in config
        self.encoder = (
            encoder
            if encoder is not None
            else encoder_registry.get(model_name=encoder_name, **encoder_params)
        )

        encoding_dim = cast(int, getattr(self.encoder, "encoding_dim"))

        self.projector = SimCLRProjectionHead(
            encoding_dim,
            Config().trainer.projection_hidden_dim,
            Config().trainer.projection_out_dim,
        )

    def forward(self, multiview_samples):
        """
        Forward pass for both SSL (multi-view) and personalization (single-view) phases.
        """
        if isinstance(multiview_samples, torch.Tensor):
            # Personalization phase: a single batch of images.
            return self.encoder(multiview_samples)

        # SSL phase: expect a sequence of at least two augmented views.
        if isinstance(multiview_samples, Sequence):
            views = list(multiview_samples)
        else:
            # Fallback for datatypes like UserList.
            views = list(multiview_samples)

        if len(views) < 2:
            raise ValueError(
                "CalibreNet expects at least two views for SSL training, "
                f"but received {len(views)}."
            )

        # Use the first two views even if additional crops are present.
        sample1, sample2 = views[0], views[1]
        encoded_sample1 = self.encoder(sample1)
        encoded_sample2 = self.encoder(sample2)

        projected_sample1 = self.projector(encoded_sample1)
        projected_sample2 = self.projector(encoded_sample2)
        return (encoded_sample1, encoded_sample2), (
            projected_sample1,
            projected_sample2,
        )

    @staticmethod
    def get():
        """Get the defined CalibreNet model."""
        return CalibreNet()
