"""
Federated averaging utilities for MLX-based models.

This mirrors the PyTorch implementation but operates on MLX parameter trees,
allowing MLX trainers to participate in the same algorithm orchestration.
"""

from __future__ import annotations

import importlib
from collections.abc import Callable, Iterable
from types import ModuleType
from typing import TYPE_CHECKING, Any, cast

import numpy as np

from plato.algorithms import base

if TYPE_CHECKING:
    import mlx.core as mx  # pragma: no cover
else:  # pragma: no cover - optional dependency
    try:
        mx = cast(ModuleType, importlib.import_module("mlx.core"))
    except ImportError:
        mx = None

from plato.trainers import mlx as mlx_trainer


def _tree_binary_map(
    func: Callable[[Any, Any], Any],
    tree_a: Any,
    tree_b: Any,
) -> Any:
    """Apply a function to paired leaves of two trees."""
    if isinstance(tree_a, dict) and isinstance(tree_b, dict):
        return {key: _tree_binary_map(func, tree_a[key], tree_b[key]) for key in tree_a}
    if isinstance(tree_a, (list, tuple)) and isinstance(tree_b, (list, tuple)):
        mapped = [
            _tree_binary_map(func, item_a, item_b)
            for item_a, item_b in zip(tree_a, tree_b, strict=True)
        ]
        return type(tree_a)(mapped)
    return func(tree_a, tree_b)


def _to_numpy(value: Any) -> np.ndarray | None:
    """Ensure leaves are numpy arrays for transport."""
    if value is None:
        return None
    if isinstance(value, np.ndarray):
        return value
    if mx is not None:
        array_type = getattr(mx, "array", None)
        if array_type is not None and isinstance(value, array_type):
            return np.array(value)
    if hasattr(value, "__array__"):
        return np.asarray(value)
    return np.array(value)


class Algorithm(base.Algorithm):
    """Federated averaging helper for MLX parameter trees."""

    def validate_weights(
        self, weights: Any, baseline: Any, client_id: Any = None
    ) -> None:
        """Validate a full tree before aggregation; identify the logical client."""
        label = "weights" if client_id is None else f"client {client_id}.weights"
        mlx_trainer._validate_parameter_tree(weights, baseline, label)

    def compute_weight_deltas(
        self,
        baseline_weights: Any,
        weights_received: Iterable[Any],
    ):
        """
        Compute deltas between the baseline and received weights.

        Args:
            baseline_weights: Nested structure of numpy arrays capturing baseline.
            weights_received: Iterable of nested structures matching baseline.

        Returns:
            List of nested structures representing parameter updates.
        """

        def difference(current, baseline):
            current_np = _to_numpy(current)
            baseline_np = _to_numpy(baseline)
            if current_np is None or baseline_np is None:
                return None
            return current_np - baseline_np

        received = list(weights_received)
        for weights in received:
            self.validate_weights(weights, baseline_weights)
        deltas = []
        for weights in received:
            deltas.append(_tree_binary_map(difference, weights, baseline_weights))
        return deltas

    def update_weights(self, deltas: Any):
        """Apply parameter deltas to the current model weights."""
        baseline = self.extract_weights()
        self.validate_weights(deltas, baseline)

        def add_delta(baseline_leaf, delta_leaf):
            baseline_np = _to_numpy(baseline_leaf)
            delta_np = _to_numpy(delta_leaf)
            if baseline_np is None or delta_np is None:
                return None
            return baseline_np + delta_np

        updated = _tree_binary_map(add_delta, baseline, deltas)
        return updated

    def extract_weights(self, model=None):
        """Extract MLX model parameters as numpy-backed trees."""
        source_model = model or self.model
        if source_model is None:
            raise RuntimeError("MLX algorithm requires an initialized model.")
        if not hasattr(source_model, "parameters"):
            raise AttributeError("The provided model does not expose 'parameters'.")
        params = source_model.parameters()
        return mlx_trainer._tree_map(mlx_trainer._to_host_array, params)

    def load_weights(self, weights):
        """Load weights into the MLX model."""
        if self.model is None:
            raise RuntimeError("MLX algorithm requires an initialized model.")
        self.validate_weights(weights, self.model.parameters())
        context = getattr(self.trainer, "context", None)
        stream = getattr(context, "stream", None)
        if stream is None:
            stream = mlx_trainer._resolve_device()
        mlx_trainer._apply_parameters(self.model, weights, stream)
