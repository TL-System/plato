"""MLX-native model definitions."""
