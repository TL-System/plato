"""
Having a registry of all available classes is convenient for retrieving an instance
based on a configuration at run-time.
"""

import logging

from plato.config import Config
from plato.trainers import (
    basic,
    composable,
    fedprox,
    gan,
    pfedgraph,
    split_learning,
)
from plato.utils.retired_backends import raise_if_retired

registered_trainers = {
    "composable": composable.ComposableTrainer,
    "basic": basic.Trainer,
    "fedprox": fedprox.Trainer,
    "timm_basic": basic.TrainerWithTimmScheduler,
    "gan": gan.Trainer,
    "pfedgraph": pfedgraph.Trainer,
    "split_learning": split_learning.Trainer,
}


def _resolve_trainer_name(trainer_config) -> str:
    """Resolve trainer type supporting framework shortcuts."""
    trainer_type_attr = getattr(trainer_config, "type", None)
    trainer_type = trainer_type_attr if isinstance(trainer_type_attr, str) else None
    framework = getattr(trainer_config, "framework", "")
    if (framework.lower() == "mlx" and trainer_type not in (None, "mlx")) or (
        trainer_type == "mlx" and framework and framework.lower() != "mlx"
    ):
        raise ValueError("MLX trainer type and framework must select the same backend.")

    if not trainer_type and framework:
        if framework.lower() == "mlx":
            return "mlx"
    if not trainer_type:
        raise ValueError("Trainer type must be specified in the configuration.")
    return trainer_type


def get(model=None, callbacks=None):
    """Get the trainer with the provided name."""
    config = Config().trainer
    trainer_name = _resolve_trainer_name(config)
    raise_if_retired(trainer_name, category="trainer")
    logging.info("Trainer: %s", trainer_name)

    if trainer_name == "diff_privacy":
        from plato.trainers import diff_privacy

        return diff_privacy.Trainer(model=model, callbacks=callbacks)
    elif trainer_name == "HuggingFace":
        from plato.trainers import huggingface

        return huggingface.Trainer(model=model, callbacks=callbacks)
    elif trainer_name == "self_supervised_learning":
        from plato.trainers import self_supervised_learning

        return self_supervised_learning.Trainer(model=model, callbacks=callbacks)
    elif trainer_name == "mlx":
        from plato.trainers import mlx

        return mlx.ComposableMLXTrainer(model=model, callbacks=callbacks)
    elif trainer_name in registered_trainers:
        return registered_trainers[trainer_name](model=model, callbacks=callbacks)
    else:
        raise ValueError(f"No such trainer: {trainer_name}")
