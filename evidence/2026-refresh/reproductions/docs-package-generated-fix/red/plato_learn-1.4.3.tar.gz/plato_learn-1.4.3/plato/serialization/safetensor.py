"""
Helpers for serialising nested parameter trees with Safetensors.
"""

from __future__ import annotations

import io
import json
from typing import Any, Dict

import numpy as np
from safetensors.numpy import load, save

from plato.utils.tree import TreeMetadata, flatten_tree, unflatten_tree


def _metadata_to_json(metadata: dict[str, TreeMetadata]) -> str:
    serialisable = {
        path: {
            "type": value.type,
            "children": value.children,
            "container": value.container,
            "backend": value.backend,
            "dtype": value.dtype,
        }
        for path, value in metadata.items()
    }
    return json.dumps(serialisable)


def _metadata_from_json(payload: str) -> dict[str, TreeMetadata]:
    data = json.loads(payload)
    return {
        path: TreeMetadata(
            type=value["type"],
            children=value.get("children"),
            container=value.get("container"),
            backend=value.get("backend"),
            dtype=value.get("dtype"),
        )
        for path, value in data.items()
    }


def serialize_tree(tree: Any) -> bytes:
    """
    Serialise a nested tree of tensors/arrays into Safetensors bytes.
    """
    flat, metadata = flatten_tree(tree)
    if "_tree_metadata" in flat:
        raise ValueError("The tensor path '_tree_metadata' is reserved.")
    # Safetensors expects C-order bytes; strided buffers can otherwise be saved
    # in storage order while retaining the logical shape, silently reordering values.
    tensors = {
        path: np.ascontiguousarray(array) if array.ndim else array
        for path, array in flat.items()
    }
    metadata_json = _metadata_to_json(metadata).encode("utf-8")
    tensors["_tree_metadata"] = np.frombuffer(metadata_json, dtype=np.uint8)
    return save(tensors)


def deserialize_tree(buffer: bytes | bytearray | memoryview) -> Any:
    """
    Restore a nested tree of numpy arrays from Safetensors bytes.
    """
    if isinstance(buffer, (bytearray, memoryview)):
        buffer = bytes(buffer)
    tensors = load(buffer)
    metadata_blob = tensors.pop("_tree_metadata", None)

    if metadata_blob is None:
        # Fallback: treat as a flat dict
        return tensors

    metadata_json = metadata_blob.tobytes().decode("utf-8")
    metadata = _metadata_from_json(metadata_json)
    flat = dict(tensors.items())
    return unflatten_tree(flat, metadata)
