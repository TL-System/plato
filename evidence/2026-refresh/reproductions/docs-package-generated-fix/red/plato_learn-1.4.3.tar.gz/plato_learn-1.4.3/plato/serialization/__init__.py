"""
Serialization helpers for Plato.
"""
