"""
Obtaining a model from HuggingFace with optional parameter-efficient fine-tuning.
"""

from __future__ import annotations

import logging
from typing import Any

import torch
from transformers import AutoConfig, AutoModelForCausalLM

from plato.config import Config
from plato.utils.huggingface import artifact_identity, pretrained_kwargs

try:
    from peft import LoraConfig, get_peft_model
except ImportError:  # pragma: no cover - handled at runtime with friendly message.
    LoraConfig = None
    get_peft_model = None


def _lora_config_dict(lora_config: Any) -> dict[str, Any]:
    """Convert various config objects (namedtuple, SimpleNamespace, dict)."""
    if lora_config is None:
        return {}
    if isinstance(lora_config, dict):
        return dict(lora_config)
    if hasattr(lora_config, "_asdict"):
        return dict(lora_config._asdict())
    if hasattr(lora_config, "__dict__"):
        return {
            key: value
            for key, value in lora_config.__dict__.items()
            if not key.startswith("_")
        }
    raise TypeError("Unsupported LoRA configuration format.")


class Model:
    """The CausalLM model loaded from HuggingFace."""

    @staticmethod
    def get(model_name=None, **kwargs):  # pylint: disable=unused-argument
        """Returns a named model from HuggingFace."""
        resolved_model_name = (
            model_name
            if isinstance(model_name, str) and model_name
            else getattr(getattr(Config(), "trainer", None), "model_name", None)
        )
        if not isinstance(resolved_model_name, str) or not resolved_model_name:
            raise ValueError("A valid HuggingFace model name must be provided.")

        identity = artifact_identity(resolved_model_name)
        seed = getattr(Config().trainer, "random_seed", None)
        if seed is not None:
            torch.manual_seed(int(seed))
        load_kwargs = pretrained_kwargs(
            revision=identity["model_revision"],
            cache_dir=Config().params["model_path"] + "/huggingface",
        )
        config = AutoConfig.from_pretrained(resolved_model_name, **load_kwargs)
        dtype = getattr(Config().trainer, "model_dtype", None)
        model_kwargs = dict(load_kwargs)
        if dtype is not None:
            supported_dtypes = {
                "float32": torch.float32,
                "float16": torch.float16,
                "bfloat16": torch.bfloat16,
            }
            if dtype not in supported_dtypes:
                raise ValueError(f"Unsupported HuggingFace model_dtype: {dtype}")
            model_kwargs["dtype"] = supported_dtypes[dtype]

        model = AutoModelForCausalLM.from_pretrained(
            resolved_model_name,
            config=config,
            **model_kwargs,
        )

        lora_params = getattr(getattr(Config(), "parameters", None), "lora", None)
        if lora_params is not None:
            if get_peft_model is None or LoraConfig is None:
                raise ImportError(
                    "The 'peft' package is required for LoRA fine-tuning. "
                    "Install it by running `uv add peft`."
                )

            params_dict = _lora_config_dict(lora_params)
            logging.info("Configuring LoRA with parameters: %s", params_dict)
            lora_cfg = LoraConfig(**params_dict)
            model = get_peft_model(model, lora_cfg, revision=identity["model_revision"])
            model.print_trainable_parameters()

        if hasattr(model, "loss_type"):
            setattr(model, "loss_type", "ForCausalLM")

        return model
