"""
Implements a generalized Processor for applying operations onto PyTorch features.
"""

from collections.abc import Callable
from typing import Any

import torch

from plato.processors import base


class Processor(base.Processor):
    """
    Implements a generalized Processor for applying operations onto PyTorch features.
    """

    def __init__(
        self,
        method: Callable = lambda x, y: (x, y),
        client_id=None,
        use_numpy=True,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)

        self.client_id = client_id
        self.method = method
        self.use_numpy = use_numpy

    def process(self, data: Any) -> Any:
        """
        Implements a generalized Processor for applying operations onto PyTorch features.
        """

        output = []
        trainer = getattr(self, "trainer", None)
        device = getattr(trainer, "device", "cpu") if trainer is not None else "cpu"

        for logits, targets in data:
            if self.use_numpy:
                logits = logits.detach().cpu().numpy()

            logits, targets = self.method(logits, targets)

            if self.use_numpy:
                if torch.device(device).type != "cpu":
                    logits = torch.from_numpy(logits.astype("float16"))
                else:
                    logits = torch.from_numpy(logits.astype("float32"))

            output.append((logits, targets))

        return output
