"""Retain one independent run of the frozen candidate's existing DP tests."""
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import time
import xml.etree.ElementTree as ET

SCRATCH = Path('/tmp/plato-phase2-dp-typing-review')
SOURCE = Path('/tmp/plato-refresh-worktrees/dp-typing-review')
COMMIT = 'f342a5a6021cee938e0b880eca5919e09ace1981'
TREE = '3d0aebd30e1d4adfcdf835bad758eb72d3179c1e'
TEST = 'tests/trainers/test_dp_data_loader_strategy.py'
RECEIPT = SCRATCH / 'scoped-execution-receipt.json'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(
        ['git', '-C', str(SOURCE), *args],
        env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}, text=True,
    ).strip()


def source_inventory():
    return sorted(str(p.relative_to(SOURCE)) for p in SOURCE.rglob('*'))


assert git('rev-parse', 'HEAD') == COMMIT
assert git('rev-parse', 'HEAD^{tree}') == TREE
initial_status = git('status', '--porcelain', '--untracked-files=all', '--ignore-submodules=all')
assert not initial_status, initial_status
initial_inventory = source_inventory()
test_digest = digest(SOURCE / TEST)
assert test_digest == '3f95d8d7942f173290852ab6c3f803b41c01831f4e008b285b473d7962df93bc'
assert not RECEIPT.exists(), RECEIPT
preparation = json.loads((SCRATCH / 'preparation-receipt.json').read_text())
expected_tests = preparation['baseline_inventory']['test_names']
controls = {k: v for k, v in preparation['planned_environment_controls'].items() if not v.startswith('<')}
controls.update({
    'PYTHONPATH': str(SOURCE), 'PYTHONNOUSERSITE': '1',
    'PYTHONDONTWRITEBYTECODE': '1', 'OPENBLAS_NUM_THREADS': '1',
    'VECLIB_MAXIMUM_THREADS': '1', 'NUMEXPR_NUM_THREADS': '1',
    'NO_COLOR': '1',
})
unsets = [
    'PYTHONPYCACHEPREFIX', 'PYTHONOPTIMIZE', 'PYTHONHOME',
    'PYTEST_ADDOPTS', 'PYTEST_PLUGINS', 'PYTEST_DISABLE_PLUGIN_AUTOLOAD',
    'TY_CONFIG_FILE', 'TY_OUTPUT_FORMAT', 'VIRTUAL_ENV', 'CONDA_PREFIX',
    'COVERAGE_PROCESS_START', 'config_file',
]
for value in controls.values():
    if value.startswith(str(SCRATCH)):
        p = Path(value)
        (p.parent if p.name == '.coverage' else p).mkdir(parents=True, exist_ok=True)

receipt = {
    'finding': 'ROOT-2C-TYPING-01', 'status': 'RUNNING',
    'candidate_commit': COMMIT, 'candidate_tree': TREE,
    'source': str(SOURCE), 'test_sha256': test_digest,
    'environment_controls': controls, 'unset_environment_variables': unsets,
    'shell': '/bin/zsh -lc', 'commands': [],
    'profile': 'selected existing DP tests; no full mandatory-profile claim',
    'profile_selection_reason': 'Optional pinned submodules are uninitialized. The selected DP tests do not need them; the unchanged profile plugin otherwise checks unrelated prerequisites when mandatory is explicitly selected.',
    'source_status_before': initial_status,
    'initial_source_entry_count': len(initial_inventory),
}


def save():
    RECEIPT.write_text(json.dumps(receipt, indent=2) + '\n')


def execute(name, argv, environment, timeout=240):
    log = SCRATCH / 'results' / (name + '.log')
    log.parent.mkdir(parents=True, exist_ok=True)
    env_argv = ['env']
    for name_to_unset in unsets:
        env_argv.extend(['-u', name_to_unset])
    env_argv.extend(k + '=' + v for k, v in sorted(controls.items()))
    env_argv.extend(argv)
    entry = {
        'name': name, 'argv': argv, 'cwd': str(SOURCE),
        'shell_argv': ['/bin/zsh', '-lc', shlex.join(env_argv)],
        'environment': environment, 'candidate_commit': COMMIT,
        'test_sha256': test_digest, 'log': str(log),
    }
    receipt['commands'].append(entry)
    save()
    started = time.monotonic()
    with log.open('wb') as output:
        result = subprocess.run(entry['shell_argv'], cwd=SOURCE, stdout=output,
                                stderr=subprocess.STDOUT, timeout=timeout)
    entry.update({'exit_code': result.returncode, 'seconds': round(time.monotonic() - started, 4),
                  'log_sha256': digest(log), 'log_bytes': log.stat().st_size})
    save()
    print(json.dumps({k: entry[k] for k in ('name', 'exit_code', 'seconds', 'log')}), flush=True)
    assert result.returncode == 0, log.read_text()[-12000:]
    assert git('rev-parse', 'HEAD') == COMMIT
    assert digest(SOURCE / TEST) == test_digest
    return entry, log.read_text()


origin_code = r'''
import importlib.metadata as metadata
import importlib.util
import json
from pathlib import Path
import sys
source = Path('/tmp/plato-refresh-worktrees/dp-typing-review').resolve()
origins = {}
for name in ('plato', 'tests'):
    spec = importlib.util.find_spec(name)
    assert spec is not None and spec.origin is not None, name
    origin = Path(spec.origin).resolve()
    assert origin.is_relative_to(source), (name, str(origin))
    origins[name] = str(origin)
for name in ('plato.trainers.diff_privacy', 'torch', 'opacus', 'pytest'):
    spec = importlib.util.find_spec(name)
    assert spec is not None and spec.origin is not None, name
    origin = Path(spec.origin).resolve()
    origins[name] = str(origin)
    if name.startswith('plato.'):
        assert origin.is_relative_to(source), (name, str(origin))
    else:
        assert origin.is_relative_to(Path(sys.prefix).resolve()), (name, str(origin))
assert sys.flags.optimize == 0
assert sys.dont_write_bytecode
print(json.dumps({'executable': sys.executable, 'version': sys.version,
                  'prefix': sys.prefix, 'base_prefix': sys.base_prefix,
                  'origins': origins, 'optimize': sys.flags.optimize,
                  'dont_write_bytecode': sys.dont_write_bytecode,
                  'packages': {name: metadata.version(name) for name in
                               ('torch', 'opacus', 'pytest', 'ruff', 'ty')}} , indent=2))
'''

try:
    save()
    for version, environment in (
        ('3.13', '/tmp/plato-phase2-integration/mandatory-313'),
        ('3.14', '/tmp/plato-phase2c-314'),
    ):
        suffix = version.replace('.', '')
        python = environment + '/bin/python'
        origin_entry, origin_output = execute('origins-' + suffix,
                                              [python, '-B', '-c', origin_code], environment)
        origin_entry['origin_evidence'] = json.loads(origin_output)
        assert origin_entry['origin_evidence']['version'].startswith(version + '.')
        save()
        ty_entry, ty_output = execute('ty-' + suffix, [
            environment + '/bin/ty', 'check', '--project', str(SOURCE),
            '--python', python, '--python-version', version,
            '--extra-search-path', str(SOURCE), '--output-format', 'concise',
            '--color', 'never', TEST,
        ], environment)
        assert ty_output.strip() == 'All checks passed!', ty_output
        ty_entry['diagnostics'] = 0
        ty_entry['owned_dp_gate_result'] = 'PASS: zero owned-file diagnostics; unchanged CI allows none for this file'
        ruff_entry, ruff_output = execute('ruff-' + suffix, [
            environment + '/bin/ruff', 'check', TEST, '--select', 'I',
            '--no-fix', '--no-cache', '--cache-dir', str(SCRATCH / 'cache/ruff'),
        ], environment)
        assert ruff_output.strip() == 'All checks passed!', ruff_output
        result_path = SCRATCH / 'results' / ('dp-' + suffix + '.xml')
        test_entry, test_output = execute('dp-' + suffix, [
            python, '-B', '-m', 'pytest', TEST, '-ra', '-vv',
            '-o', 'cache_dir=' + str(SCRATCH / 'cache' / ('pytest-' + suffix)),
            '--basetemp=' + str(SCRATCH / 'runtime-temp' / ('dp-' + suffix)),
            '--junitxml=' + str(result_path),
        ], environment, timeout=240)
        xml = ET.parse(result_path)
        cases = list(xml.getroot().iter('testcase'))
        case_names = [case.attrib['name'] for case in cases]
        nonpassing = [{'case': case.attrib, 'outcome': node.tag, 'text': node.text}
                      for case in cases for node in case if node.tag in ('failure', 'error', 'skipped')]
        summary = re.findall(r'(?m)^=+ (\d+) passed, (\d+) warnings in ([0-9.]+)s =+$', test_output)
        assert len(cases) == 7 and case_names == expected_tests and not nonpassing, (case_names, nonpassing)
        assert len(summary) == 1 and summary[0][0] == '7', test_output[-1000:]
        assert re.search(r'collected 7 items', test_output)
        test_entry.update({
            'junit': {'path': str(result_path), 'sha256': digest(result_path), 'bytes': result_path.stat().st_size},
            'test_names': case_names, 'counts': {'passed': len(cases), 'failed': 0, 'errors': 0,
                                               'skipped': 0, 'deselected': 0, 'xfail': 0,
                                               'xpass': 0, 'warnings': int(summary[0][1])},
            'pytest_seconds': float(summary[0][2]), 'nonpassing_cases': nonpassing,
        })
        save()
    receipt['final_commit'] = git('rev-parse', 'HEAD')
    receipt['final_tree'] = git('rev-parse', 'HEAD^{tree}')
    receipt['final_test_sha256'] = digest(SOURCE / TEST)
    receipt['source_status_after'] = git('status', '--porcelain', '--untracked-files=all', '--ignore-submodules=all')
    final_inventory = source_inventory()
    receipt['source_entries_added'] = sorted(set(final_inventory) - set(initial_inventory))
    receipt['source_entries_removed'] = sorted(set(initial_inventory) - set(final_inventory))
    assert not receipt['source_status_after'], receipt['source_status_after']
    assert not receipt['source_entries_added'] and not receipt['source_entries_removed']
    assert receipt['final_commit'] == COMMIT and receipt['final_tree'] == TREE
    assert receipt['final_test_sha256'] == test_digest
    receipt['status'] = 'EXECUTION_PASS_REQUIRES_INDEPENDENT_SOURCE_REVIEW'
except Exception as exc:
    receipt['status'] = 'FAIL'
    receipt['error'] = str(exc)
    raise
finally:
    save()
    print(json.dumps({'status': receipt['status'], 'receipt': str(RECEIPT)}), flush=True)
