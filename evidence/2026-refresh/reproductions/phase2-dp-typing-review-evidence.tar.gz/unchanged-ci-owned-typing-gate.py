import re
import sys
from pathlib import Path
owned = {
    "tests/conftest.py", "tests/integration/utils.py",
    "tests/test_nanochat_integration.py",
    "tests/trainers/test_dp_data_loader_strategy.py",
    "tests/clients/test_feddf_strategy.py",
    "tests/servers/test_feddf_server_strategy.py",
    "tests/datasources/test_huggingface_datasource.py",
    "tests/integration/test_event_loop_startup.py",
}
allowed = {
    ("tests/datasources/test_huggingface_datasource.py", "99", "5", "invalid-assignment"),
    ("tests/datasources/test_huggingface_datasource.py", "100", "5", "invalid-assignment"),
}
log = Path("ci-artifacts/ty.log").read_text()
status = int(sys.argv[1])
assert status in (0, 1), f"ty exited with status {status}: {log}"
matches = list(re.finditer(r"^(.+?):(\d+):(\d+): (?:error|warning)\[([^]]+)\]", log, re.M))
if status == 0:
    assert log.strip() == "All checks passed!" and not matches, log
else:
    report = re.search(r"^Found ([1-9][0-9]*) diagnostics?$", log, re.M)
    assert report is not None and len(matches) == int(report[1]), log
for match in matches:
    assert match[1] not in owned or match.groups() in allowed, match[0]
