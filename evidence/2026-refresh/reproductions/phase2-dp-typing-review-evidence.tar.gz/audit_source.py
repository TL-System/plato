"""Independently reconcile the narrow correction and the retained author evidence."""
import ast
from collections import Counter
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess

SCRATCH = Path('/tmp/plato-phase2-dp-typing-review')
SOURCE = Path('/tmp/plato-refresh-worktrees/dp-typing-review')
BASE = '8b01bf47ca8bdf9232bffeb4e50f78d4f00c9e3b'
INTEGRATED_BASE = '2633f8394c142ec04db13743b54a427e04c2aed7'
CANDIDATE = 'f342a5a6021cee938e0b880eca5919e09ace1981'
IMPLEMENTATION = '9b083c0e923e760c7003c66fdf4da3db86f8758b'
TEST = 'tests/trainers/test_dp_data_loader_strategy.py'
AUTHOR_RECEIPT = 'evidence/2026-refresh/phase2c-dp-typing-gate-validation.json'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args, binary=False):
    result = subprocess.check_output(['git', '-C', str(SOURCE), *args],
                                     env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})
    return result if binary else result.decode().strip()


def blob(revision, path):
    return git('show', revision + ':' + path, binary=True)


def dump(node):
    return ast.dump(node, include_attributes=False)


def indexed_inventory(tree, text):
    parents = {}
    for node in ast.walk(tree):
        for child in ast.iter_child_nodes(node):
            parents[child] = node

    def ancestors(node):
        result = []
        while node in parents:
            node = parents[node]
            result.append(node)
        return list(reversed(result))

    out = []
    for node in sorted(ast.walk(tree), key=lambda n: (getattr(n, 'lineno', 0), getattr(n, 'col_offset', 0))):
        if not isinstance(node, ast.Assert):
            continue
        ancestry = ancestors(node)
        scope = '.'.join(n.name for n in ancestry if isinstance(n, (ast.FunctionDef, ast.ClassDef)))
        control = []
        for item in ancestry:
            if isinstance(item, ast.For):
                control.append('for ' + ast.unparse(item.target) + ' in ' + ast.unparse(item.iter))
            elif isinstance(item, ast.If):
                control.append('if ' + ast.unparse(item.test))
            elif isinstance(item, ast.With):
                control.append('with ' + ', '.join(ast.unparse(i.context_expr) for i in item.items))
        out.append({'scope': scope, 'control_context': control, 'ast': dump(node),
                    'line': node.lineno, 'source': ast.get_source_segment(text, node)})
    return out


original_bytes = blob(BASE, TEST)
corrected_bytes = blob(CANDIDATE, TEST)
assert original_bytes == blob(INTEGRATED_BASE, TEST)
assert corrected_bytes == blob(IMPLEMENTATION, TEST) == (SOURCE / TEST).read_bytes()
original_text, corrected_text = original_bytes.decode(), corrected_bytes.decode()
original_tree, corrected_tree = ast.parse(original_text), ast.parse(corrected_text)
original_asserts = indexed_inventory(original_tree, original_text)
corrected_asserts = indexed_inventory(corrected_tree, corrected_text)
assert len(original_asserts) == 35 and len(corrected_asserts) == 54

matched = []
added = []
index = 0
for item in corrected_asserts:
    expected = original_asserts[index] if index < len(original_asserts) else None
    if expected and all(item[key] == expected[key] for key in ('scope', 'control_context', 'ast')):
        matched.append({'original_line': expected['line'], 'corrected_line': item['line'],
                        'scope': item['scope'], 'source': item['source'],
                        'control_context_unchanged': True, 'ast_unchanged': True})
        index += 1
    else:
        added.append(item)
assert index == 35 and len(added) == 19
remove_lines = {item['line'] for item in added}


class NormalizeApprovedChanges(ast.NodeTransformer):
    def __init__(self):
        self.device_pairs = 0
        self.private_results = 0
        self.callback_signatures = 0
        self.imports = 0

    def visit_Assert(self, node):
        return None if node.lineno in remove_lines else node

    def visit_ImportFrom(self, node):
        if node.module == 'plato.trainers.diff_privacy' and any(alias.name == 'DPOptimizerStrategy' for alias in node.names):
            assert [alias.name for alias in node.names] == ['DPDataLoaderStrategy', 'DPOptimizerStrategy']
            node.names = node.names[:1]
            self.imports += 1
        elif node.module == 'opacus':
            assert [alias.name for alias in node.names] == ['GradSampleModule', 'PrivacyEngine']
            node.names = node.names[1:]
            self.imports += 1
        return node

    def visit_FunctionDef(self, node):
        if node.name in ('on_train_step_start', 'on_train_step_end'):
            extras = ['batch'] if node.name.endswith('start') else ['batch', 'loss']
            assert [arg.arg for arg in node.args.args] == ['self', 'trainer', 'config', *extras]
            assert all(isinstance(default, ast.Constant) and default.value is None
                       for default in node.args.defaults)
            assert len(node.args.defaults) == len(extras)
            node.args.args = node.args.args[:3]
            node.args.defaults = []
            self.callback_signatures += 1
        return self.generic_visit(node)

    def generic_visit(self, node):
        node = super().generic_visit(node)
        for field, value in ast.iter_fields(node):
            if not isinstance(value, list) or not value or not all(isinstance(v, ast.stmt) for v in value):
                continue
            replacement = []
            position = 0
            while position < len(value):
                first = value[position]
                second = value[position + 1] if position + 1 < len(value) else None
                if isinstance(first, ast.Assign) and isinstance(second, ast.Assign):
                    if ([ast.unparse(t) for t in first.targets] == ['trainer.device']
                            and ast.unparse(first.value) == "'cpu'"
                            and [ast.unparse(t) for t in second.targets] == ['trainer.context.device']
                            and ast.unparse(second.value) == "torch.device('cpu')"):
                        replacement.append(ast.Assign(targets=first.targets + second.targets, value=second.value))
                        self.device_pairs += 1
                        position += 2
                        continue
                    if ([ast.unparse(t) for t in first.targets] == ['private_result']
                            and isinstance(first.value, ast.Call)
                            and ast.unparse(first.value.func) == 'engine.make_private'
                            and [ast.unparse(t) for t in second.targets] == ['(private_model, optimizer, loader)']
                            and ast.unparse(second.value) == 'private_result'):
                        replacement.append(ast.Assign(targets=second.targets, value=first.value))
                        self.private_results += 1
                        position += 2
                        continue
                replacement.append(first)
                position += 1
            setattr(node, field, replacement)
        return node


normalizer = NormalizeApprovedChanges()
normalized = normalizer.visit(copy.deepcopy(corrected_tree))
assert (normalizer.device_pairs, normalizer.private_results,
        normalizer.callback_signatures, normalizer.imports) == (4, 1, 2, 2)
assert dump(normalized) == dump(original_tree), 'Unexpected AST change beyond the approved additions/device representations/signatures/result binding'

def selected_calls(tree, names):
    return [dump(node) for node in sorted(ast.walk(tree), key=lambda n: (getattr(n, 'lineno', 0), getattr(n, 'col_offset', 0)))
            if isinstance(node, ast.Call) and ast.unparse(node.func) in names]

call_sets = {
    'numerical_assert_close': {'torch.testing.assert_close'},
    'exception_expectation': {'pytest.raises'},
    'real_opacus_make_private': {'engine.make_private'},
    'real_batch_memory_manager': {'BatchMemoryManager'},
    'public_train_checkpoint_and_client_calls': {'trainer.train', 'trainer.train_model', 'trainer.save_model',
                                                'trainer.load_model', 'trainer.obtain_model_at_time',
                                                'trainer.set_client_id'},
}
call_results = {}
for name, calls in call_sets.items():
    before, after = selected_calls(original_tree, calls), selected_calls(corrected_tree, calls)
    assert before == after
    call_results[name] = {'count': len(before), 'exact_call_ast_preserved': True}
baseline_guard = next(n for n in original_tree.body if isinstance(n, ast.If))
corrected_guard = next(n for n in corrected_tree.body if isinstance(n, ast.If))
assert dump(baseline_guard) == dump(corrected_guard)

scope = git('diff', '--name-status', BASE, CANDIDATE).splitlines()
assert scope == ['A\t' + AUTHOR_RECEIPT, 'M\t' + TEST], scope
assert git('rev-parse', IMPLEMENTATION + '^') == BASE
assert git('rev-parse', CANDIDATE + '^') == IMPLEMENTATION
assert git('diff', '--name-only', BASE, IMPLEMENTATION).splitlines() == [TEST]
assert git('diff', '--name-only', IMPLEMENTATION, CANDIDATE).splitlines() == [AUTHOR_RECEIPT]
diff = git('diff', BASE, CANDIDATE, '--', TEST, binary=True)
(SCRATCH / 'exact-owned-file-correction.diff').write_bytes(diff)
author = json.loads((SOURCE / AUTHOR_RECEIPT).read_text())
assert author['source']['sha256'] == sha(corrected_bytes)
assert author['source']['git_blob'] == git('rev-parse', CANDIDATE + ':' + TEST)
assert author['full_diff'].encode() == diff

raw_evidence = []
for entry in author['raw_inventory']:
    path = Path(entry['path'])
    assert path.resolve().is_relative_to(Path('/tmp/plato-phase2c-dp-typing-fix').resolve()), path
    data = path.read_bytes()
    assert len(data) == entry['bytes'] and sha(data) == entry['sha256'], path
    raw_evidence.append({**entry, 'independently_hash_verified': True})
root_failure = json.loads(Path('/tmp/plato-phase2-integration/typing-owned-gate-failure.json').read_text())
red_reconciliation = []
for suffix in ('313', '314'):
    path = Path('/tmp/plato-phase2c-dp-typing-fix/red-ty-' + suffix + '.log')
    entries = path.read_text().splitlines()
    assert entries[:-1] == root_failure['diagnostics'] and entries[-1] == 'Found 23 diagnostics'
    red_reconciliation.append({'path': str(path), 'sha256': sha(path.read_bytes()),
                               'root_23_diagnostics_match_exactly': True,
                               'evidence_type': 'hash-verified retained author red log; no baseline tests or ty rerun'})

prep = json.loads((SCRATCH / 'preparation-receipt.json').read_text())
integration_comparison = []
for path, baseline in prep['baseline']['critical_files'].items():
    current = blob(CANDIDATE, path)
    integration_comparison.append({'file': path, 'baseline_sha256': baseline['sha256'],
                                   'candidate_sha256': sha(current),
                                   'identical_to_integrated_baseline': sha(current) == baseline['sha256']})
production_diff_from_integrated_baseline = git('diff', '--name-only', INTEGRATED_BASE, CANDIDATE, '--', 'plato').splitlines()
tests_before = [n.name for n in original_tree.body if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
tests_after = [n.name for n in corrected_tree.body if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
assert tests_before == tests_after
assert not git('status', '--porcelain', '--untracked-files=all', '--ignore-submodules=all')
report = {
    'finding': 'ROOT-2C-TYPING-01', 'status': 'SOURCE_AUDIT_PASS',
    'baseline_component_commit': BASE, 'integrated_baseline_commit': INTEGRATED_BASE,
    'candidate_commit': CANDIDATE, 'candidate_tree': git('rev-parse', CANDIDATE + '^{tree}'),
    'implementation_commit': IMPLEMENTATION, 'implementation_tree': git('rev-parse', IMPLEMENTATION + '^{tree}'),
    'candidate_parent': IMPLEMENTATION, 'implementation_parent': BASE,
    'changed_paths': scope, 'correction_diff': {'path': str(SCRATCH / 'exact-owned-file-correction.diff'),
                                              'sha256': sha(diff), 'bytes': len(diff)},
    'owned_file': {'path': TEST, 'original_sha256': sha(original_bytes), 'corrected_sha256': sha(corrected_bytes),
                   'original_git_blob': git('rev-parse', BASE + ':' + TEST),
                   'corrected_git_blob': git('rev-parse', CANDIDATE + ':' + TEST),
                   'baseline_component_and_integrated_file_identical': True,
                   'candidate_and_implementation_file_identical': True, 'matches_committed_source': True},
    'preservation': {'original_assertions': 35, 'original_assertions_retained_exact_ast_and_control_context': 35,
                     'new_runtime_assertions': 19, 'corrected_assertions': 54,
                     'assertion_line_mapping': matched, 'added_assertions': added,
                     'call_preservation': call_results, 'test_names': tests_before,
                     'test_count': len(tests_before), 'absence_skip_guard_exact_ast_preserved': True,
                     'full_module_ast_equal_after_only_enumerated_approved_changes': True,
                     'normalized_ast_sha256': sha(dump(normalized).encode()),
                     'original_ast_sha256': sha(dump(original_tree).encode()),
                     'normalized_changes': {'new_runtime_assertions': 19, 'CPU_device_assignment_pairs': 4,
                                            'callback_argument_extensions': 2, 'runtime_type_import_extensions': 2,
                                            'make_private_result_binding': 1},
                     'production_files_changed_from_component_base': [],
                     'CI_guard_configuration_and_other_tests_changed_from_component_base': [],
                     'new_ignores_allowances_casts_filters_mocks_or_fixtures': False},
    'integrated_baseline_comparison': integration_comparison,
    'production_path_differences_candidate_vs_integrated_baseline': production_diff_from_integrated_baseline,
    'author_receipt': {'path': str(SOURCE / AUTHOR_RECEIPT), 'sha256': sha((SOURCE / AUTHOR_RECEIPT).read_bytes()),
                        'bytes': (SOURCE / AUTHOR_RECEIPT).stat().st_size, 'source_and_diff_match': True},
    'author_raw_evidence': raw_evidence, 'retained_red_reconciliation': red_reconciliation,
    'whole_phase_acceptance_claimed': False,
}
path = SCRATCH / 'source-audit-receipt.json'
assert not path.exists(), path
path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'receipt': str(path), 'original_assertions_preserved': 35,
                  'new_runtime_assertions': 19, 'full_ast_reconciled': True,
                  'author_raw_artifacts_hash_verified': len(raw_evidence),
                  'integrated_critical_file_differences': [entry['file'] for entry in integration_comparison
                                                           if not entry['identical_to_integrated_baseline']],
                  'production_paths_differing_from_integrated_baseline': production_diff_from_integrated_baseline}, indent=2))
