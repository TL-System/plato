"""Independent comparisons and bounded adversarial probes of immutable FedDyn."""
import asyncio
import copy
from fractions import Fraction
import json
import multiprocessing as mp
import os
from pathlib import Path
import pickle
import sys

import numpy as np
import torch
from torch.utils.data import TensorDataset

from plato.serialization.safetensor import deserialize_tree, serialize_tree
from plato.trainers.strategies.algorithms.feddyn_strategy import (
    FedDynUpdateStrategy, same_state,
)
from tests.integration.test_feddyn_round_flow import (
    QuadraticTrainer, ZeroTrainer, client, configuration, dispatch, local, server,
)
from tests.integration.utils import configure_environment

HERE = Path('/tmp/plato-phase2c-feddyn-code-review')
CANDIDATE = Path('/private/tmp/plato-refresh-worktrees/training').resolve()
REFERENCE = json.loads((HERE / 'reference.json').read_text())


def close(value, rational):
    np.testing.assert_allclose(value, float(Fraction(rational)), atol=1e-12,
                               rtol=0, equal_nan=False)


def native_metadata(meta):
    expected = {'version': int, 'round': int, 'client_id': int,
                'run_id': str, 'dispatch_token': str}
    for key, kind in expected.items():
        assert type(meta[key]) is kind, (key, type(meta[key]))
    for key in ('num_samples', 'completed_steps'):
        if key in meta:
            assert type(meta[key]) is int, (key, type(meta[key]))
    for key in ('base_alpha', 'effective_alpha'):
        if key in meta:
            assert type(meta[key]) is float, (key, type(meta[key]))


class Capture:
    async def send_report_and_payload(self, context, report, payload):
        self.report = report
        self.payload = deserialize_tree(payload)


def actual_attempt(c, assignment, target, count):
    response, payload = assignment
    c.client_id = c._context.client_id = response['id']
    c.current_round = c._context.current_round = response['current_round']
    c.configure()
    context = c._context
    c.lifecycle_strategy.process_server_response(context, response)
    context.trainset = TensorDataset(torch.ones(count, 1).double(),
                                    torch.full((count, 1), target).double())
    context.sampler = torch.utils.data.SequentialSampler(context.trainset)
    capture = Capture()
    wire = serialize_tree(payload)
    native_metadata(deserialize_tree(wire)[1])
    asyncio.run(c.payload_strategy.handle_server_payload(
        context, wire, training=c.training_strategy, reporting=c.reporting_strategy,
        communication=capture))
    native_metadata(capture.payload[1])
    return capture


class CorruptPositiveCount(QuadraticTrainer):
    """A real spawned child changes only its otherwise valid saved count."""
    def train_process(self, config, trainset, sampler, **kwargs):
        super().train_process(config, trainset, sampler, **kwargs)
        path = Path(self._training_state_path(config['run_id']))
        envelope = pickle.loads(path.read_bytes())
        assert envelope['state']['num_samples'] == len(sampler) == 2
        envelope['state']['num_samples'] = 3
        path.write_bytes(pickle.dumps(envelope))


def trajectory_probe(root, name, counts, spawn):
    root.mkdir(parents=True, exist_ok=True)
    mode = 'sample' if name in ('sample', 'equal_counts_sample') else 'uniform'
    with configure_environment(configuration(mode, counts, spawn), runtime_root=root):
        s, c = server(), client(1)
        rows = []
        for expected in REFERENCE['three_round'][name]:
            i = expected['selected'][0]
            assignment = dispatch(s, [i])[i]
            captured = actual_attempt(c, assignment, (0.0, 4.0)[i - 1], counts[i - 1])
            close(captured.payload[0]['theta'].item(), expected['endpoints'][str(i)])
            strategy = c.trainer.model_update_strategy
            close(strategy.result['history']['theta'].item(),
                  expected['histories_after'][i - 1])
            assert captured.report.num_samples == counts[i - 1]
            assert strategy.result['completed_steps'] == 2 and strategy.accepted
            s.updates = [captured]
            asyncio.run(s._process_reports())
            close(s.trainer.model.theta.item(), expected['cloud'])
            for j, exact in enumerate(expected['histories_after'], 1):
                close(s.histories[j]['theta'].item(), exact)
            rows.append({'round': s.committed_round, 'cloud': s.trainer.model.theta.item(),
                         'all_histories': {j: h['theta'].item() for j, h in s.histories.items()},
                         'count': captured.report.num_samples, 'steps': strategy.completed_steps})
        return {'case': 'strict_trajectory/' + name, 'spawn': spawn,
                'status': 'PASS', 'states': rows}


def count_probe(root, mode):
    root.mkdir(parents=True, exist_ok=True)
    with configure_environment(configuration(mode, (2, 2), True), runtime_root=root):
        s, c = server(), client(1, CorruptPositiveCount)
        assignment = dispatch(s, [1])[1]
        s.save_to_checkpoint()
        before = Path(s.checkpoint_bundle_path()).read_bytes()
        try:
            captured = actual_attempt(c, assignment, 0.0, 2)
        except ValueError as exc:
            assert not c.trainer.model_update_strategy.accepted
            assert s.committed_round == 0
            assert Path(s.checkpoint_bundle_path()).read_bytes() == before
            return {'case': 'spawn_positive_count_corruption/' + mode,
                    'status': 'REJECTED', 'error': str(exc)}
        s.updates = [captured]
        asyncio.run(s._process_reports())
        return {'case': 'spawn_positive_count_corruption/' + mode,
                'status': 'ACCEPTED_WRONG_COUNT', 'actual_partition_count': 2,
                'reported_count': captured.report.num_samples,
                'parent_result_count': c.trainer.model_update_strategy.result['num_samples'],
                'server_observed_counts': s.observed_counts,
                'server_committed_round': s.committed_round,
                'cloud': s.trainer.model.theta.item()}


def bundle_count_probe(root):
    root.mkdir(parents=True, exist_ok=True)
    with configure_environment(configuration(), runtime_root=root):
        s = server()
        for i in (1, 2):
            captured = actual_attempt(client(i), dispatch(s, [i])[i], (0.0, 4.0)[i - 1], 2)
            s.updates = [captured]
            asyncio.run(s._process_reports())
        s.save_to_checkpoint()
        path = Path(s.checkpoint_bundle_path())
        bundle = torch.load(path, weights_only=True)
        before_count = dict(bundle['counts'])
        assert bundle['histories'][1]['theta'].item() != 0
        del bundle['counts'][1]
        torch.save(bundle, path)
        resumed = server()
        try:
            resumed._resume_from_checkpoint()
        except ValueError as exc:
            return {'case': 'bundle_missing_observed_count', 'status': 'REJECTED',
                    'error': str(exc)}
        assignment = dispatch(resumed, [1])[1]
        assert assignment[1][1]['expected_count_or_null'] is None
        captured = actual_attempt(client(1), assignment, 0.0, 3)
        resumed.updates = [captured]
        asyncio.run(resumed._process_reports())
        return {'case': 'bundle_missing_observed_count', 'status': 'CHANGED_PARTITION_ACCEPTED',
                'original_counts': before_count, 'removed_count_client': 1,
                'restored_nonzero_history': bundle['histories'][1]['theta'].item(),
                'accepted_changed_count': resumed.observed_counts[1],
                'committed_round': resumed.committed_round}


def cleanup_probe(root):
    root.mkdir(parents=True, exist_ok=True)
    with configure_environment(configuration(), runtime_root=root):
        s, c = server(), client(1)
        assignment = dispatch(s, [1])[1]
        original = FedDynUpdateStrategy.on_train_cleanup
        def fail_success(self, context, successful):
            if successful:
                raise RuntimeError('reviewer successful cleanup failure')
            return original(self, context, successful)
        FedDynUpdateStrategy.on_train_cleanup = fail_success
        try:
            try:
                actual_attempt(c, assignment, 0.0, 2)
            except RuntimeError as exc:
                assert 'cleanup failure' in str(exc)
                assert not c.trainer.model_update_strategy.accepted
                assert c.trainer.model_update_strategy.result is None
                assert c.trainer.model.theta.item() == 2
                assert c.trainer.model.theta.grad is None
            else:
                raise AssertionError('Cleanup failure exposed an accepted result')
        finally:
            FedDynUpdateStrategy.on_train_cleanup = original
        captured = actual_attempt(c, assignment, 0.0, 2)
        close(captured.payload[0]['theta'].item(), '811/500')
        return {'case': 'direct_success_cleanup_failure_and_retry', 'status': 'PASS'}


def main():
    torch.set_num_threads(1)
    root = Path(sys.argv[1])
    root.mkdir(parents=True, exist_ok=True)
    checks = []
    checks.append(count_probe(root / 'count-uniform', 'uniform'))
    checks.append(count_probe(root / 'count-sample', 'sample'))
    checks.append(bundle_count_probe(root / 'bundle-count'))
    assert [c['status'] for c in checks] == ['REJECTED'] * 3, checks
    origins = {}
    for name, module in tuple(sys.modules.items()):
        if name == 'plato' or name.startswith('plato.') or name.startswith('feddyn'):
            origin = getattr(module, '__file__', None)
            if origin:
                assert Path(origin).resolve().is_relative_to(CANDIDATE), (name, origin)
                origins[name] = origin
    result = {'python': sys.version, 'candidate': str(CANDIDATE),
              'checks': checks, 'origins': origins,
              'no_active_children': not mp.active_children()}
    assert result['no_active_children']
    (root / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'checks': len(checks), 'statuses': [c['status'] for c in checks]}))


if __name__ == '__main__':
    main()
