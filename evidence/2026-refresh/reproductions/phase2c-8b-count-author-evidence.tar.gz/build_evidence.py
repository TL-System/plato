import ast,datetime,hashlib,json,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
root=Path.cwd();scratch=Path('/tmp/plato-phase2c-feddyn-count-fixes');out=root/'evidence/2026-refresh'
base='13e38dafce476286db7e673e7f21343d54416b56'
def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
def receipt(path):
 p=Path(path);return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def execution(name):
 p=scratch/(name+'.json');d=json.loads(p.read_text());log=Path(d['log'])
 assert d['log_sha256']==receipt(log)['sha256']
 if (scratch/(name+'.xml')).exists():
  xml=scratch/(name+'.xml');tree=ET.parse(xml);cases=list(tree.iter('testcase'))
  failed=sum(c.find('failure') is not None or c.find('error') is not None for c in cases)
  skipped=sum(c.find('skipped') is not None for c in cases)
  d['junit']=receipt(xml);d['counts']={'tests':len(cases),'passed':len(cases)-failed-skipped,'failed':failed,'skipped':skipped}
  d['test_ids']=[c.attrib.get('classname','')+'::'+c.attrib['name'] for c in cases]
 d['log_tail']=log.read_text().splitlines()[-20:]
 return d
impl=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}')
assert impl=='fac9c65161f699fd94c7d264a519715fedd2bc4c'
executions={name:execution(name) for name in ('red-313','red-314','red-ty-313','red-ty-314','green-new-313','green-new-314','committed-ty-313','committed-ty-314','corrected-reviewer-count-313','corrected-reviewer-count-314','corrected-reviewer-callback-313','corrected-reviewer-callback-314','affected-313','affected-314')}
for n,d in executions.items():
 assert d['exit_code']==(1 if n.startswith('red-') else 0),(n,d)
for v in ('313','314'):
 assert executions['red-'+v]['counts']=={'tests':20,'passed':1,'failed':19,'skipped':0}
 assert executions['green-new-'+v]['counts']=={'tests':20,'passed':20,'failed':0,'skipped':0}
 assert executions['affected-'+v]['counts']['failed']==0
 assert executions['affected-'+v]['head']==impl
 assert 'All checks passed!' in Path(executions['committed-ty-'+v]['log']).read_text()
source_paths=git('diff','--name-only',base,impl).splitlines()
source_receipts={p:{**receipt(root/p),'git_blob':git('rev-parse',impl+':'+p)} for p in source_paths}
# Verify every original tracked file outside the six explicit changes,
# including all historical reports and all accepted A/B/D/SC/generic source.
allpaths=git('ls-tree','-r','--name-only',base).splitlines();unchanged=[]
for p in allpaths:
 if p in source_paths:continue
 if not (root/p).is_file():continue  # existing vendor gitlink directories
 assert subprocess.check_output(['git','show',base+':'+p])==(root/p).read_bytes(),p
 unchanged.append(p)
old_reports={p:receipt(root/p) for p in ('evidence/2026-refresh/phase2c-feddyn-validation.json','evidence/2026-refresh/phase2c-feddyn-facts.json','evidence/2026-refresh/phase2c-feddyn-delivery-receipt.json','evidence/2026-refresh/phase2c-validation.json')}
review=Path('/Users/bli/Playground/plato/evidence/2026-refresh/phase2c-feddyn-code-review.json')
assert receipt(review)['sha256']=='c0455ca53f730e9696719d1312e9913ef62dc3064911cca475aa6247faa68c0b'
for name in ('reviewer_candidate_probes.py','reviewer_callback_count_probe.py'):
 assert (Path('/tmp/plato-phase2c-feddyn-code-review')/name).read_bytes()==(scratch/('original-'+name)).read_bytes()
preservation=json.loads((scratch/'source-preservation.json').read_text())
# Actual entrypoint cases must have run in the affected invocation, not only
# direct-method references. Collect their natural shutdown reports separately.
entrypoint=[]
for v in ('313','314'):
 cases=[n for n in executions['affected-'+v]['test_ids'] if 'test_feddyn_entrypoint' in n]
 assert len(cases)==3,cases
 entrypoint.append({'environment':v,'executed_test_ids':cases,'qualification':'Real shipped main/run/--resume sockets and actual max_concurrency trainer workers, uniform/sample scalar oracle plus synthetic MNIST-shaped LeNet, with all existing numerical/RNG/shutdown assertions retained.'})
socket_results={}
for v in ('313','314'):
 paths=sorted({p.resolve() for p in (scratch/('affected-'+v)).rglob('result.json') if p.parent.name in ('run','first','resumed','lenet-run') and any('test_actual_shipped' in part or 'test_shipped_mnist' in part for part in p.parts)})
 assert len(paths)==7,(v,len(paths))
 results=[]
 for p in paths:
  d=json.loads(p.read_text())
  assert d['returncode']==0 and not d['timed_out'] and not d['forced'] and not d['survivors'],p
  results.append({**receipt(p),'returncode':d['returncode'],'timed_out':d['timed_out'],'forced':d['forced'],'survivors':d['survivors']})
 socket_results[v]=results
facts={
 'schema_version':1,'status':'IMPLEMENTATION_FACTS_FOR_FRESH_REVIEW_AND_ASTRA_RECONCILIATION',
 'implementation_commit':impl,'implementation_tree':tree,'base':base,
 'prior_facts':old_reports['evidence/2026-refresh/phase2c-feddyn-facts.json'],
 'supersedes_only':['First-uniform worker sample-count provenance','Complete bundle nonzero-history/count cache coherence','Receive/aggregation callback count-state type preservation','Owned-source explicit ty result','SCAFFOLD V2 overview docstring description'],
 'count_provenance':'The dedicated Trainer resolves sampler.get() once in the parent for this attempt, validates a Sized positive realized partition (including declared count agreement), and passes that same realized sampler to actual worker training. The current parent count is bound before spawn; a worker sidecar cannot replace it. Direct train_model binds the current actual sampler too. Backing dataset length, redrawing partitions and another worker count copy are not the authority.',
 'rejection':'Worker/result count must match the independently bound current partition count as well as configured/previous server counts. A failed handoff restores known parent model/dispatch state, retains no accepted result and refuses outbound eligibility; retry with the same current dispatch is valid.',
 'checkpoint_coherence':'Existing version1 complete bundles require a valid positive native integer count for each nonzero full-population history. Validation completes before live model/history/config/round/count or pending RNG mutation. Missing counts for zero histories remain possible; this bounded correction does not add a generalized participation ledger or claim detection of deleted counts whose histories are all zero.',
 'callback_coherence':'Receive and aggregation guards use existing recursive type-sensitive same_state comparisons of all observed count keys and values, including inactive entries. bool/int, float/int, NumPy integer/native integer and float/integer key equivalences are rejected before accepted commit and roll back known owned state. Postcommit evaluation boundary is unchanged.',
 'unchanged_contracts':['Accepted objective J=F+alpha_i<h,w>+alpha_i/2||w-x||²','h_next=h+y-x','Unweighted selected endpoints plus updated full-population history mean','Uniform and full-population sample weighting','Metadata wire keys/version and complete checkpoint bundle schema','Canonical collision-safe state paths and read-only legacy reader','Actual ComposableClient/default native production transport','All global/selector/NumPy/Torch CPU resume handshake semantics','Shared lifecycle/SCAFFOLD implementation and callbacks/evaluation boundary','Existing TOML values and supported bounded optimizer/model configuration'],
 'doc_l02':'Only the strategies overview now describes SCAFFOLDUpdateStrategyV2 as a compatibility subclass using Option II; imports and executable AST are unchanged.',
 'qualification':{v:executions['affected-'+v]['counts'] for v in ('313','314')},
 'source_check':'Reviewer explicit owned-source ty command with --python pointing at each actual environment passes; no diagnostics ignored or sources skipped.',
 'warnings':'See new validation evidence for actual warning output; no global filters or blanket suppression added.',
 'limits':['CPU numerical/synthetic fixtures and macOS arm64 only; no CUDA/native GPU claims','No new ledger or generalized transaction protocol','Historical 13e full profile/startup totals remain historical, never relabelled as correction runs','No whole C acceptance; fresh independent implementation review and final source-bound prose reconciliation/root gates remain'],
 'public_prose_owner':'Original Astra writer; no standalone prose changed by implementer.',
 'evidence':'phase2c-feddyn-count-fixes-validation.json',
}
fp=out/'phase2c-feddyn-count-fixes-facts.json';fp.write_text(json.dumps(facts,indent=2)+'\n')
report={
 'schema_version':1,'status':'IMPLEMENTED_DUAL_VERSION_AFFECTED_QUALIFIED_FRESH_REVIEW_PENDING',
 'written_at_utc':datetime.datetime.now(datetime.UTC).isoformat(),
 'starting_commit':base,'starting_tree':git('rev-parse',base+'^{tree}'),
 'implementation_commit':impl,'implementation_tree':tree,'implementation_parent':git('show','-s','--format=%P',impl),
 'implementation_subject':git('show','-s','--format=%s',impl),
 'evidence_identity':'Pinned in a subsequent receipt commit to avoid self-referential commit identities.',
 'review_input':receipt(review),'scaffold_acceptance':receipt('/Users/bli/Playground/plato/evidence/2026-refresh/phase2c-scaffold-implementation-acceptance.json'),
 'findings':{
  'FD-C-R01':{'status':'FIXED_AUTHOR_VALIDATED_REVIEW_PENDING','mechanism':facts['count_provenance'],'tests':['test_actual_spawn_wrong_first_count_rejected_and_retry','test_parent_realizes_partition_once_without_using_backing_length'],'original':'First uniform corrupted count accepted; sample guard already rejected. Regression uniform fails on13e and succeeds on corrected actual child/parent path. Retry1->2->1 matches independent Fraction equations.'},
  'FD-C-R02':{'status':'FIXED_AUTHOR_VALIDATED_REVIEW_PENDING','mechanism':facts['checkpoint_coherence'],'tests':['test_nonzero_history_requires_saved_observed_count'],'cases':'Modes uniform/sample, missing logical client1/2, fresh/previous pending resume; 8 boundary cases, exact live/pending/RNG/authority and canonical read-only preservation, corrected bundle retry then changed3-item rejection and valid2-item commit.'},
  'FD-C-R03':{'status':'FIXED_AUTHOR_VALIDATED_REVIEW_PENDING','mechanism':facts['callback_coherence'],'tests':['test_inactive_callback_count_types_rejected_before_commit'],'cases':'Inactive integer count becomes bool/float/NumPy integer or integer key becomes float, both receive and aggregation hooks: 8cases; exact known-owned rollback, prior file bytes, pending release, valid retry/checkpoint round2.'},
  'FD-C-L01':{'status':'FIXED_EXPLICIT_SOURCE_CHECK_GREEN','mechanism':'Sized sampler narrowing and existing context_model Module validation helper; no annotation-only tests. Explicit scoped command reports original5 diagnostics and now passes on both actual environments.'},
  'DOC-L02':{'status':'FIXED_DOCSTRING_ONLY','mechanism':facts['doc_l02'],'validation':'Diff and executable AST check; no prose-only tests added.'},
 },
 'supersession':{'historical_reports_preserved':old_reports,'applicable_prior_claims_superseded':facts['supersedes_only'],'prior_counts':'The13e profile/51runtime totals and 242reviewer focused cases remain historical. No current full base/mandatory or unchanged48startup rerun claimed.'},
 'sources':source_receipts,'preservation':{**preservation,'all_other_existing_tracked_files_byte_identical':len(unchanged)},
 'source_preservation_receipt':receipt(scratch/'source-preservation.json'),
 'environments':{v:json.loads((scratch/('environment-'+v+'.json')).read_text()) for v in ('313','314')},
 'executions':executions,
 'red_green_interpretation':{'red_production':'Exact13e tracked production; only untracked regression draft files overlaid. Original19failed/1passed each. Red is a defect-asserting failure run, not a pass claim. Draft bytes/source receipts retained.','precommit_green':'20passed each on corrected production before commit; those runs record HEAD13e with dirty corrected source. Final affected runs execute exactfac9c651 committed source and the strengthened final test assertions.','explicit_ty':'Original5 invalid-argument-type diagnostics each; committed explicit scoped checks pass each. Both original logs match independent review diagnostic hash.','reviewer_replays':'Immutable originals retained untouched. Own copies scope the candidate probe to three count cases, use this worktree/source-origin assertions, and require REJECTED outcomes. Own callback copy requires rejection and previous round/history/count/file preservation. Both variants pass each version; do not sum replay executions with pytest unique counts.'},
 'actual_entrypoint_coverage':entrypoint,
 'actual_socket_shutdown_results':socket_results,
 'natural_shutdown_contract':'Server normal inherited close uses os._exit(0); success is real normal server-close process exit plus child return/no forced shutdown/no survivors, not a claim that the server main Python function returns.',
 'ruff':{'command':'zsh -lc /tmp/plato-phase2c-313/bin/ruff check . --select I','exit_code':0,'log':receipt(scratch/'ruff-imports.log')},
 'warning_policy':'Actual pytest warnings/log output retained. No global warning filters or blanket suppression, no CI/conftest change.',
 'facts':receipt(fp),
 'owned_scratch':{'root':str(scratch),'preserved_original_implementation_scratch':'/tmp/plato-phase2c-feddyn-implementation','reviewer_scratch':'/tmp/plato-phase2c-feddyn-code-review read-only; no original script/raw evidence edits','environments':['/tmp/plato-phase2c-313','/tmp/plato-phase2c-314'],'cleanup':'None'},
 'raw_scratch_inventory':[receipt(p) for p in sorted(scratch.iterdir()) if p.is_file()],
 'limits':facts['limits'],
 'next_gates':['Fresh independent reviewer assigned by root, not review1','Final source-bound Astra prose reconciliation','Root full combined qualification/phase gate and eventual integration/push'],
 'whole_phase_acceptance_claimed':False,
}
(out/'phase2c-feddyn-count-fixes-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'implementation':impl,'tree':tree,'affected_counts':facts['qualification'],'historical_and_shared_files_preserved':len(unchanged),'facts':receipt(fp)},indent=2))
