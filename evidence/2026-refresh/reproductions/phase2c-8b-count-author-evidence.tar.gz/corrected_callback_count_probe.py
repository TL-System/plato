"""Type-changing mutation of FedDyn-owned inactive count state at receive hook."""
import asyncio
import copy
import json
from pathlib import Path
import sys
import torch

from plato.callbacks.server import ServerCallback
from tests.integration.test_feddyn_round_flow import client, configuration, dispatch, local, server
from tests.integration.utils import configure_environment


class MutateInactiveCount(ServerCallback):
    def on_weights_received(self, server, weights):
        assert server.observed_counts[2] == 1
        server.observed_counts[2] = True


def main():
    root = Path(sys.argv[1])
    root.mkdir(parents=True, exist_ok=True)
    with configure_environment(configuration(), runtime_root=root):
        s = server()
        s.updates = [local(client(2), dispatch(s, [2])[2], 4.0, 1)]
        asyncio.run(s._process_reports())
        s.save_to_checkpoint()
        canonical = Path(s.checkpoint_bundle_path()).read_bytes()
        prior = copy.deepcopy(s.histories)
        valid = local(client(1), dispatch(s, [1])[1], 0.0, 1)
        s.updates = [valid]
        s.callback_handler.add_callback(MutateInactiveCount())
        try:
            asyncio.run(s._process_reports())
        except ValueError as exc:
            result = {'status': 'REJECTED', 'error': str(exc)}
        else:
            error = None
            try:
                s.save_to_checkpoint()
            except ValueError as exc:
                error = str(exc)
            result = {'status': 'INVALID_INACTIVE_COUNT_COMMITTED',
                      'committed_round_before': 1, 'committed_round_after': s.committed_round,
                      'count_before': 1, 'count_after': s.observed_counts[2],
                      'count_after_type': type(s.observed_counts[2]).__name__,
                      'later_checkpoint_error': error,
                      'previous_canonical_unchanged': Path(s.checkpoint_bundle_path()).read_bytes() == canonical}
        assert result['status'] == 'REJECTED', result
        assert s.committed_round == 1 and type(s.observed_counts[2]) is int
        assert s.observed_counts[2] == 1
        assert all(torch.equal(v, prior[i][k]) for i, h in s.histories.items() for k,v in h.items())
        assert Path(s.checkpoint_bundle_path()).read_bytes() == canonical
        (root/'results.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result))


if __name__ == '__main__':
    main()
