import hashlib,json,re,shlex,subprocess,sys,time
from pathlib import Path
repo=Path('/private/tmp/plato-refresh-worktrees/training')
scratch=Path('/tmp/plato-phase2c-feddyn-implementation')
version,profile,partition=sys.argv[1:4]
env=Path('/tmp/plato-phase2c-'+version)
label=(sys.argv[4] if len(sys.argv)>4 else 'combined')+'-'+profile+'-'+partition.replace(' ','-')+'-'+version
command=[str(env/'bin/python'),'-m','pytest','tests','--test-profile',profile,'-m',partition,'-q','--basetemp',str(scratch/label),'--junitxml',str(scratch/(label+'.xml'))]
shell='OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 '+shlex.join(command)
head=subprocess.check_output(['zsh','-lc','git rev-parse HEAD'],cwd=repo,text=True).strip()
started=time.monotonic(); log=scratch/(label+'.log')
with log.open('w') as output:
 result=subprocess.run(['zsh','-lc',shell],cwd=repo,stdout=output,stderr=subprocess.STDOUT)
text=log.read_text(); record={'head':head,'command':shell,'shell':'zsh -lc','profile':profile,'partition':partition,'python_environment':str(env),'exit_code':result.returncode,'seconds':time.monotonic()-started,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'summary':text.splitlines()[-1] if text else 'empty'}
(scratch/(label+'.json')).write_text(json.dumps(record,indent=2)); print(json.dumps(record,indent=2));sys.exit(result.returncode)
