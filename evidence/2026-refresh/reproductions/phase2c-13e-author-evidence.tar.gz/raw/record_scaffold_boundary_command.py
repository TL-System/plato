"""Record final committed SCAFFOLD bounded qualification commands."""
import hashlib,json,subprocess,sys,time
from pathlib import Path
ROOT=Path('/private/tmp/plato-refresh-worktrees/training')
SCRATCH=Path('/tmp/plato-phase2c-feddyn-implementation')
label,version=sys.argv[1:3]
python=f'/tmp/plato-phase2c-{version}/bin/python'
if label in ('probe', 'probe-clean'):
    probe_dir='scaffold-review2-committed-probes' if label=='probe-clean' else 'scaffold-review2-probes'
    command=f'OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONPATH={ROOT} {python} {SCRATCH}/{probe_dir}/corrected_callback_lifecycle_probe.py'
elif label=='checks':
    command=f'/tmp/plato-phase2c-{version}/bin/ruff check . --select I && /tmp/plato-phase2c-{version}/bin/ty check plato/trainers/composable.py examples/customized_client_training/scaffold/scaffold_server.py --output-format concise && git diff --check'
elif label in ('archive', 'archive-qualified'):
    command=f'OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 {python} -m pytest tests/trainers/test_review_training_boundaries.py -k actual_accepted_b_feddyn_writer_migration -q --basetemp {SCRATCH}/archive-temp-{version}'
else:
    raise ValueError(label)
cwd=ROOT if not label.startswith('archive') else SCRATCH/'source-archive-0f177'
logfile=SCRATCH/f'scaffold-review2-committed-{label}-{version}.log'
start=time.monotonic()
with logfile.open('w') as log:
    r=subprocess.run(['zsh','-lc',command],cwd=cwd,stdout=log,stderr=subprocess.STDOUT,timeout=120)
receipt={'source_commit':'0f17708afefde13eeba1fd71578258b68c5911ee','label':label,'version':version,'command':command,'cwd':str(cwd),'shell':'zsh -lc','seconds':time.monotonic()-start,'exit_code':r.returncode,'log':str(logfile),'sha256':hashlib.sha256(logfile.read_bytes()).hexdigest()}
(SCRATCH/f'scaffold-review2-committed-{label}-{version}.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
raise SystemExit(r.returncode)
