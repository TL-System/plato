"""Preserve defect probes and assert corrected outcomes in owned copies."""
from pathlib import Path

original = Path("/tmp/plato-phase2c-scaffold-code-review-2")
owned = Path("/tmp/plato-phase2c-feddyn-implementation/scaffold-review2-probes")
owned.mkdir(exist_ok=True)
for name in ("callback_lifecycle_probe.py", "independent_checks.py"):
    (owned / ("original_" + name)).write_bytes((original / name).read_bytes())
helper = (original / "independent_checks.py").read_text()
helper = helper.replace(
    "CANDIDATE = Path('/private/tmp/plato-refresh-worktrees/training-review2')",
    "CANDIDATE = Path('/private/tmp/plato-refresh-worktrees/training')",
).replace("SCRATCH = Path('/tmp/plato-phase2c-scaffold-code-review-2')",
          f"SCRATCH = Path({str(owned)!r})")
(owned / "independent_checks.py").write_text(helper)
probe = (original / "callback_lifecycle_probe.py").read_text()
probe = probe.replace("assert record['pending_after_later_bad_metadata']",
                      "assert not record['pending_after_later_bad_metadata']")
start = probe.index("            if mode in ['received', 'metadata']:")
end = probe.index("            records.append(record)", start)
probe = probe[:start] + """            assert error is not None
            p.close(x, 1.)
            p.close(record['actual_c'], 2.)
            assert not record['pending_controls']
            assert not record['retained_received_controls']
            assert record['raw_inputs_unchanged']
""" + probe[end:]
start = probe.index("                if interface == 'train_model':")
end = probe.index("                for cid in [2,1]:", start)
probe = probe[:start] + """                p.close(record['actual_ci'],1.)
                assert persisted == (1. if existing else None)
                assert outbound_error is not None
                assert not record['optimizer_hook_still_registered']
""" + probe[end:]
start = probe.index("                if interface == 'train_model':")
end = probe.index("                records.append(record)", start)
probe = probe[:start] + """                if existing:
                    p.close(record['after_reconstruction_ci'],1.)
                    p.close(record['successful_retry']['y'],.62)
                    p.close(record['successful_retry']['ci'],.9)
                    p.close(record['successful_retry']['delta'],-.1)
                else:
                    assert record['after_reconstruction_ci'] is None
                    # The original probe reconfigures with no accepted file:
                    # fresh initialization is zero, not manual unsaved ci=1.
                    p.close(record['successful_retry']['y'],.43)
                    p.close(record['successful_retry']['ci'],.85)
                    p.close(record['successful_retry']['delta'],.85)
""" + probe[end:]
probe = probe.replace(
    "Exit zero asserts the remaining defects and direct-process comparison; not an acceptance pass.",
    "Exit zero asserts corrected callback/end-hook rejection; original-author replay, not fresh independent acceptance.",
)
(owned / "corrected_callback_lifecycle_probe.py").write_text(probe)
