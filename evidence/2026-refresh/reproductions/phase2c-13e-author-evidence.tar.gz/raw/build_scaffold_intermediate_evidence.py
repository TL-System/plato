"""Freeze the bounded SCAFFOLD review-2 correction evidence."""
import hashlib,json,subprocess,sys,importlib.metadata
from pathlib import Path
ROOT=Path('/private/tmp/plato-refresh-worktrees/training')
SCRATCH=Path('/tmp/plato-phase2c-feddyn-implementation')
REVIEWS=Path('/Users/bli/Playground/plato/evidence/2026-refresh')
BASE='f9772f61d52dfe0f4a3281252d23b8303ec237d2'
IMPL='0f17708afefde13eeba1fd71578258b68c5911ee'
def git(command):
    return subprocess.check_output(['zsh','-lc',command],cwd=ROOT,text=True).strip()
def artifact(path):
    p=Path(path)
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def read(name):
    p=SCRATCH/name
    return json.loads(p.read_text())
assert git('git rev-parse HEAD')==IMPL
assert git('git status --porcelain')==''
assert git(f'git rev-parse {BASE}:plato/servers/base.py')==git(f'git rev-parse {IMPL}:plato/servers/base.py')
source_paths=git(f'git diff --name-only {IMPL}^ {IMPL}').splitlines()
assert source_paths==['examples/customized_client_training/scaffold/scaffold_server.py','plato/trainers/composable.py','tests/integration/test_scaffold_callback_lifecycle.py']
sources=[artifact(ROOT/p) for p in source_paths]
a_merge=read('dependency-merge.json')
for a in a_merge['accepted_a_blobs_unchanged']:
    assert artifact(ROOT/a['path'])['sha256']==a['sha256']
commands=[]
for version in ('313','314'):
    for label in ('red-final','committed-green','committed-probe-clean','committed-checks','committed-archive-qualified'):
        r=read(f'scaffold-review2-{label}-{version}.json')
        assert artifact(r['log'])['sha256']==r['sha256']
        if label=='red-final':
            assert r['exit_code']==1 and r['summary'].startswith('16 failed, 4 passed')
        else:
            assert r['exit_code']==0 and r['source_commit']==IMPL
        if label=='committed-green':
            assert r['summary'].startswith('174 passed, 17 warnings')
        r['log_summary']=Path(r['log']).read_text().splitlines()[-1]
        commands.append(r)
reviews=[artifact(REVIEWS/n) for n in ('phase2c-scaffold-code-review-2.json','phase2c-training-review-2.json','phase2c-general-acceptance.json','phase2c-root-source-archive-probe.json','phase2a-acceptance.json')]
assert reviews[0]['sha256']=='aa00c76f5e3fbe3eb2f419ed277620c32f382b8dabb99f4a3e5c190308162eb1'
assert reviews[1]['sha256']=='2712a8b892cf3a65b684dfb4470ab293b1d3c4ceedeb0ba7e4613c372e6c8ca1'
probe=SCRATCH/'scaffold-review2-probes'
for name in ('callback_lifecycle_probe.py','independent_checks.py'):
    assert (probe/('original_'+name)).read_bytes()==(Path('/tmp/plato-phase2c-scaffold-code-review-2')/name).read_bytes()
original_probe=artifact(probe/'original_callback_lifecycle_probe.py')
assert original_probe['sha256']=='3f2f01caced400601f6b5f717bf7e721aac8d883df01821f236364355b3f9e05'
preserved=read('preserved-feddyn-test-draft.json')
assert artifact(preserved['preserved_path'])['sha256']==preserved['sha256']
assert not (ROOT/preserved['original_path']).exists()
assert git(f'git diff {BASE} {IMPL} -- plato/trainers/strategies/algorithms/feddyn_strategy.py examples/customized_client_training/feddyn')==''
failed=[]
for name in ('scaffold-review2-committed-probe-313.json','scaffold-review2-committed-probe-314.json','scaffold-review2-committed-archive-313.json'):
    r=read(name)
    assert artifact(r['log'])['sha256']==r['sha256']
    failed.append(r)
environments=[]
for version in ('313','314'):
    cmd=f"/tmp/plato-phase2c-{version}/bin/python -c \"import json,sys,importlib.metadata;print(json.dumps({{'python':sys.version,'packages':{{k:importlib.metadata.version(k) for k in ['torch','opacus','pytest','ruff','ty']}}}}))\""
    environments.append({'root':f'/tmp/plato-phase2c-{version}','command':cmd,'shell':'zsh -lc','metadata':json.loads(git(cmd))})
# The complete scratch inventory is external retained evidence; generated test
# partitions and extracted archives remain owned and are never removed here.
entries=[]
for path in sorted(SCRATCH.rglob('*')):
    if path.is_file() and not path.is_symlink() and path.name!='scaffold-intermediate-scratch-inventory.json':
        entries.append(artifact(path))
inventory=SCRATCH/'scaffold-intermediate-scratch-inventory.json'
inventory.write_text(json.dumps({'root':str(SCRATCH),'entries':entries},indent=2)+'\n')
report={
 'schema_version':1,'scope':'Intermediate original-author SCAFFOLD review-2 fixes and portable historical writer; not whole Phase2C acceptance.',
 'status':'IMPLEMENTED_AND_DUAL_VERSION_QUALIFIED_PENDING_FRESH_SCAFFOLD_REVIEW_3',
 'identities':{'reviewed_base':BASE,'initial_base':'fda60becedfa6236c11d415b87a868b52789a41e','branch':git('git branch --show-current'),'accepted_b':'00eeb9dcdd2b513e64db9408969356037e09bb8e','pre_a_merge':BASE,'accepted_a':a_merge['accepted_a'],'a_merge':a_merge['merge'],'a_merge_parents':a_merge['parents'],'a_merge_tree':a_merge['tree'],'accepted_a_blobs_verified_unchanged':len(a_merge['accepted_a_blobs_unchanged']),'portable_fixture_commit':'79a42ab4cfb3cb087fe64de9e4e2778cae52b969','implementation':IMPL,'implementation_tree':git(f'git rev-parse {IMPL}^{{tree}}'),'implementation_parent':git(f'git rev-parse {IMPL}^'),'evidence_commit_contract':'A subsequent receipt commit records the exact evidence-body commit and its SHA256; final head/tree are reported externally to avoid self-reference.','servers_base_blob_unchanged_from_f977':git(f'git rev-parse {IMPL}:plato/servers/base.py')},
 'reviews':reviews,'source_and_test_identities':sources,
 'findings':[
 {'id':'F27-R2-01','disposition':'Corrected, pending fresh review 3','change':'Example-local report boundary clears controls on every abort, validates actual post-receive-callback models/control state, restores known model/control tensors if arithmetic, partial model load, or aggregation callbacks fail. Callback handler restored in finally.','oracle':'x=1,c=2 must survive rejected y=7/9,delta=3/4,counts=2/2 batch; successful retry x=8,c=13/3. Raw inbound tensors unchanged.','boundary':'Commit after on_weights_aggregated callbacks succeed and resulting model/control validation passes; later evaluation/reporting failures retain committed state. External callback side effects are outside the bounded rollback.'},
 {'id':'F27-R2-02','disposition':'Corrected, pending fresh review 3','change':'Shared ComposableTrainer executes the fallible training-step end hook exactly once before direct acceptance. Nested finally guarantees model-update cleanup and context hook removal even when end or cleanup hooks raise. Deferred worker acceptance preserved.','oracle':'Failed end hook retains prior ci=1 and canonical bytes/absence, refuses outbound delta and leaves no optimizer pre-hook. Same-client reuse and reconstruction preserve accepted state. Explicit ci=1 retry y=.62,ci=.9,delta=-.1.'},
 {'id':'ROOT-2C-02','disposition':'Portable fixture implemented; final FedDyn explicit read-only migration API remains pending','change':'Historical accepted-B source and license retained byte-for-byte with provenance. Four default/custom root/trailing-slash migration cases execute the actual old writer without Git at runtime.','archive_result':'4 passed, 13 deselected each Python version from exact0f177 source archive without .git.'}
 ],
 'qualification':{'environments':environments,'commands':commands,'red':'20 tracked boundary cases:16 fail,4 pass on immutablef977 each Python version. Red wrapper records actual pytest exit1 despite outer intentional wrapper exit0.','green':'174 affected tests passed each Python version, zero skips, including all20 new regressions, shipped configuration two-round rational oracles, actual spawned SCAFFOLD success and failed-worker retries. Separate4 archive migration cases and adapted original-author probe replays are distinct executions, not additional unique cases.','warnings':{'green_total_each':17,'policy':'Visible and unsuppressed; no blanket filters or global warning policy changes.','categories':{'Opacus experimental nonsecure RNG':5,'RDP largest-order notice':3,'PyTorch full backward hook for inputs without gradients':4,'Repeated make_private_with_epsilon spent-budget notice':2,'New subset dataset object accounting notice':3},'privacy_scope':'Retained accounting lifecycle is checked; no global privacy accounting guarantee.','red_notice':'One PytestAssertRewriteWarning from preloading immutable production/helper before pytest in the isolated red harness, each version; harness import-order notice, not hidden.'},'tooling':'Repository Ruff I and scoped ty on both changed production modules pass using each owned environment. Global404-classified baseline not represented as globally clean.','not_rerun_here':'48 runtime startup/socket cases are intentionally not rerun solely for this intermediate boundary; final combined qualification still requires them.'},
 'original_reviewer_probe':{'original':original_probe,'original_helper':artifact(probe/'original_independent_checks.py'),'corrected_owned_copy':artifact(SCRATCH/'scaffold-review2-committed-probes/corrected_callback_lifecycle_probe.py'),'owned_helper':artifact(SCRATCH/'scaffold-review2-committed-probes/independent_checks.py'),'adaptation':'Only candidate/scratch location and explicit corrected outcome assertions changed. Original defect-asserting source retained untouched. Replay is original-author evidence, not fresh independent acceptance.','absence_case':'Original probe reconstructs with no accepted canonical file, so fresh ci is unset and later zero-initialized retry gives y=.43,ci=.85,delta=.85. Tracked regression explicitly restores manual caller ci=1 before independent .62/.9/-.1 retry.'},
 'retained_failed_harness_attempts':{'receipts':failed,'explanation':'Initial committed probe rerun reused old owned scratch canonical files; assertion for absent prior canonical correctly failed. Corrected replay uses a new owned scratch root and unchanged success assertions. Initial source-archive selector matched no tests (17 deselected, exit5); corrected exact test name runs4 cases. An initial ty --output-format json invocation was rejected by installed CLI (exit2); supported concise output reruns pass. Earlier draft fault-injection and source-binding red attempts remain in raw scratch; only exact final red and committed green receipts qualify this candidate.'},
 'public_facts_for_astra_reconciliation':{'math_config_paths':'No SCAFFOLD equations, TOML values, control-state filenames, learning-rate accounting, supported optimizer constraints, or F20 unsquared FedProx equations changed.','changed_semantics':['Direct result acceptance now follows successful training-step end hook.','Failed report batches discard staging and preserve committed model/control through aggregation callbacks.','Successful aggregation callback boundary defines commit; postcommit evaluation/reporting failure keeps it.'],'standalone_prose':'Astra/root-owned standalone SCAFFOLD/FedDyn prose untouched; root should reconcile these lifecycle facts before final prose review.'},
 'preserved_feddyn_work':preserved,
 'dependencies_and_limits':['General review2 accepts only four earlier production corrections on immutablef977; preserved here.','FedDyn accepted revised design remains authorized future implementation work; this intermediate candidate does not implement/close2C-11 or claim its full acceptance criteria.','Reviewed B resume supplement still pending explicit handoff; no merge or servers/base.py edits.','Fresh SCAFFOLD review3, accepted FedDyn implementation plus fresh code/prose reviews, eventual B integration, final combined C/runtime qualification and root acceptance remain.','CPU fixtures only for this boundary; no new CUDA/native GPU execution or convergence claim.'],
 'historical_evidence':'Existing phase2c-validation/facts evidence is retained as historical f977 qualification, not retroactively claimed as post-fix results.',
 'owned_scratch':{'root':str(SCRATCH),'inventory':artifact(inventory),'files':len(entries),'keep_raw':'All original logs/probes, generated owned partitions, archive and preserved FedDyn draft retained for review/resume; no cleanup.'}
}
output=ROOT/'evidence/2026-refresh/phase2c-scaffold-review2-fixes-validation.json'
output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'report':artifact(output),'implementation':IMPL,'red_each':'16failed4passed','green_each':'174passed17warnings','scratch_files':len(entries)},indent=2))
