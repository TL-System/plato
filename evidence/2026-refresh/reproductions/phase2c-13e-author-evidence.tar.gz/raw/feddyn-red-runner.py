import sys
sys.path.insert(0,'/tmp/plato-phase2c-feddyn-implementation/old-source')
sys.argv=['pytest']
import pytest
raise SystemExit(pytest.main(['/tmp/plato-phase2c-feddyn-implementation/preserved-feddyn-test-draft.py','-q','--basetemp=/tmp/plato-phase2c-feddyn-implementation/numerical-red-'+sys.version[:4]]))
