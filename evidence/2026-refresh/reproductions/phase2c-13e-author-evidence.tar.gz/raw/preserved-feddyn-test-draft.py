"""Independent corrected FedDyn objective and bounded local-state contracts."""

import pytest
import torch

from plato.trainers.strategies.algorithms.feddyn_strategy import FedDynLossStrategy
from plato.trainers.strategies.base import TrainingContext
from tests.integration.utils import build_minimal_config, configure_environment


def scalar_context(w, x, h):
    model = torch.nn.Linear(1, 1, bias=False).double()
    model.weight.data.fill_(w)
    context = TrainingContext()
    context.model, context.client_id = model, 1
    context.state["feddyn_global_weights"] = {"weight": torch.tensor([[x]]).double()}
    context.state["feddyn_cumulative_grad"] = {"weight": torch.tensor([[h]]).double()}
    return model, context


@pytest.mark.parametrize("w,x,h,gradient,y,h_next", [
    (2.0, 2.0, 0.0, 0.0, 2.0, 0.0),
    (1.0, 2.0, 0.5, -.05, 1.005, -.495),
    (3.0, 3.0, 0.5, .05, 2.995, .495),
])
def test_loss_matches_independent_scalar_equation(tmp_path, w, x, h, gradient, y, h_next):
    with configure_environment(build_minimal_config(), runtime_root=tmp_path):
        model, context = scalar_context(w, x, h)
        loss = FedDynLossStrategy(alpha=.1, adaptive_alpha=False,
                                  base_loss_fn=lambda output, labels: output.sum() * 0)
        loss.setup(context)
        optimizer = torch.optim.SGD(model.parameters(), lr=.1)
        loss.compute_loss(model(torch.ones(2, 1).double()),
                          torch.zeros(2).long(), context).backward()
        assert model.weight.grad.item() == pytest.approx(gradient, abs=1e-12)
        optimizer.step()
        assert model.weight.item() == pytest.approx(y, abs=1e-12)
        assert h + model.weight.item() - x == pytest.approx(h_next, abs=1e-12)


@pytest.mark.parametrize("alpha", [-1, float("nan"), float("inf"),
                                   -float("inf"), True, "0.1"])
def test_invalid_alpha_is_an_actionable_error(alpha):
    with pytest.raises(ValueError, match="alpha"):
        FedDynLossStrategy(alpha=alpha)


def test_zero_alpha_is_exact_task_loss(tmp_path):
    with configure_environment(build_minimal_config(), runtime_root=tmp_path):
        model, context = scalar_context(2, 3, .5)
        strategy = FedDynLossStrategy(alpha=0,
                                     base_loss_fn=lambda outputs, labels:
                                     .5 * outputs.square().mean())
        strategy.setup(context)
        strategy.compute_loss(model(torch.ones(2, 1).double()),
                              torch.zeros(2).long(), context).backward()
        assert model.weight.grad.item() == 2


@pytest.mark.parametrize("labels", [[0, 0], [0, 1], [1, 1], [17, 93], [93, 17]])
def test_sample_alpha_uses_population_counts_never_labels(tmp_path, labels):
    with configure_environment(build_minimal_config(), runtime_root=tmp_path):
        model, context = scalar_context(2, 2, .5)
        context.state["feddyn_count_metadata"] = {
            "population": 2, "sample_counts": [1, 3], "client_id": 1,
        }
        strategy = FedDynLossStrategy(alpha=.1, adaptive_alpha=True,
                                      base_loss_fn=lambda outputs, labels:
                                      outputs.sum() * 0)
        strategy.setup(context)
        strategy.compute_loss(model(torch.ones(2, 1).double()),
                              torch.tensor(labels), context).backward()
        assert model.weight.grad.item() == pytest.approx(.1, abs=1e-12)


def test_adaptive_alpha_requires_authoritative_metadata(tmp_path):
    with configure_environment(build_minimal_config(), runtime_root=tmp_path):
        model, context = scalar_context(2, 2, .5)
        strategy = FedDynLossStrategy(alpha=.1, adaptive_alpha=True)
        strategy.setup(context)
        with pytest.raises(ValueError, match="count|metadata"):
            strategy._get_alpha_coefficient(torch.tensor([0, 1]), context)
