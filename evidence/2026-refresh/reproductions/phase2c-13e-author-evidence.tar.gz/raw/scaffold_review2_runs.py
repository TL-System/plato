"""Retain exact immutable red and current dual-version lifecycle receipts."""
import hashlib
import json
import shlex
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path("/private/tmp/plato-refresh-worktrees/training")
SCRATCH = Path("/tmp/plato-phase2c-feddyn-implementation")
IMMUTABLE = Path("/tmp/plato-refresh-worktrees/training-review2")
version, mode = sys.argv[1:3]
python = f"/tmp/plato-phase2c-{version}/bin/python"
targets = (
    "tests/trainers/test_scaffold_strategy.py "
    "tests/trainers/test_training_update_contract.py "
    "tests/trainers/test_dp_data_loader_strategy.py "
    "tests/trainers/test_personalized_state_ownership.py "
    "tests/trainers/test_review_training_boundaries.py "
    "tests/integration/test_scaffold_round_flow.py "
    "tests/integration/test_scaffold_callback_lifecycle.py"
)
if mode.startswith("red"):
    assert subprocess.check_output(["zsh", "-lc", "git rev-parse HEAD"], cwd=IMMUTABLE, text=True).strip() == "f9772f61d52dfe0f4a3281252d23b8303ec237d2"
    red_test = SCRATCH / "test_scaffold_callback_lifecycle.py"
    red_test.write_bytes((ROOT / "tests/integration/test_scaffold_callback_lifecycle.py").read_bytes())
    source = (
        "import pytest,plato.trainers.composable;"
        "import tests.integration.test_scaffold_round_flow as reference;"
        + f"assert plato.trainers.composable.__file__.startswith({str(IMMUTABLE)!r});"
        + f"assert reference.__file__.startswith({str(IMMUTABLE)!r});"
        + "raise SystemExit(pytest.main(["
        + repr(str(red_test))
        + ", '--import-mode=importlib','-p','no:cacheprovider','-q','--confcutdir',"
        + repr(str(SCRATCH)) + ",'--basetemp',"
        + repr(str(SCRATCH / f"scaffold-exact-f977-red{version}")) + "]))"
    )
    command = f"config_file={IMMUTABLE}/examples/customized_client_training/scaffold/scaffold_MNIST_lenet5.toml PYTHONDONTWRITEBYTECODE=1 PYTHONPATH={IMMUTABLE} OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 {python} -c {shlex.quote(source)}"
    cwd = SCRATCH
    source_commit = "f9772f61d52dfe0f4a3281252d23b8303ec237d2"
else:
    command = f"OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 {python} -m pytest {targets} -q --basetemp {SCRATCH}/scaffold-review2-green{version}"
    cwd = ROOT
    source_commit = subprocess.check_output(["zsh", "-lc", "git rev-parse HEAD"], cwd=ROOT, text=True).strip()
logfile = SCRATCH / f"scaffold-review2-{mode}-{version}.log"
start = time.monotonic()
with logfile.open("w") as log:
    result = subprocess.run(["zsh", "-lc", command], cwd=cwd, stdout=log, stderr=subprocess.STDOUT, timeout=300)
receipt = {"source_commit": source_commit, "mode": mode, "command": command, "cwd": str(cwd), "shell": "zsh -lc", "seconds": time.monotonic()-start, "exit_code": result.returncode, "summary": logfile.read_text().splitlines()[-1], "log": str(logfile), "sha256": hashlib.sha256(logfile.read_bytes()).hexdigest()}
(SCRATCH / f"scaffold-review2-{mode}-{version}.json").write_text(json.dumps(receipt, indent=2))
print(json.dumps(receipt, indent=2))
sys.exit(result.returncode if not mode.startswith("red") else 0)
