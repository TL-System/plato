import hashlib
import json
import re
from pathlib import Path

ROOT = Path('/tmp/plato-refresh-worktrees/qwen-reference')
SCRATCH = Path('/tmp/plato-qwen-validation')
PYTHON = '/tmp/plato-phase2-integration/final-mandatory-313/bin/python'
FILES = [
    'plato/algorithms/lora.py', 'plato/models/huggingface.py',
    'plato/datasources/lora.py', 'plato/datasources/huggingface.py',
    'plato/trainers/huggingface.py', 'plato/utils/huggingface.py',
    'tests/test_huggingface_artifacts.py', 'tests/test_utils/qwen3.py',
    'tests/integration/test_qwen3_lora.py',
    'tests/trainers/test_huggingface_accumulation.py',
    'examples/huggingface/qualify_qwen3.py',
    'configs/HuggingFace/fedavg_qwen3_06b_lora.toml',
    'tests/fixtures/qwen3/train.json', 'tests/fixtures/qwen3/validation.json',
    'tests/fixtures/qwen3/PROVENANCE.txt',
]

def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()

qualification = json.loads((SCRATCH / 'real-pretrained/qualification.json').read_text())
cli = json.loads((SCRATCH / 'cli-transport/cli-result.json').read_text())
cli_text = (SCRATCH / 'cli-transport/plato.log').read_text()
qual_text = (SCRATCH / 'real-pretrained.log').read_text()
focus_text = (SCRATCH / 'focused.log').read_text()
assert '47 passed' in focus_text and not re.search(r'\d+ failed', focus_text)
assert (SCRATCH / 'typecheck-all.log').read_text().strip() == 'All checks passed!'
assert cli['natural_exit'] and not cli['survivors_after_exit']
assert ' (simulated)' not in cli_text
assert '/resolve/main/' not in cli_text + qual_text
assert '/revision/main' not in cli_text + qual_text
collection = [line for line in (SCRATCH / 'new-tests-collection.log').read_text().splitlines()
              if line.startswith('tests/') and '::' in line]
assert len(collection) == 24
snapshot = Path(qualification['resolved_checkpoint_directory'])
artifacts = {}
for filename in ('config.json', 'model.safetensors'):
    path = snapshot / filename
    artifacts[filename] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
receipt = {
    'schema_version': 1,
    'date': '2026-10-03',
    'status': 'PASS',
    'baseline_commit': '9ee92c52307cd3ecdce0c7416708c504bdb52137',
    'branch': 'maintenance/2026-qwen-reference',
    'approved_plan': {
        'sha256': 'c2a5a34a32bc3f41228efb61e542e575fcd863861c68ead856b5d6453208b62e',
        'review': 'ACCEPT_DESIGN; /tmp/plato-llm-retirement-plan-review.json',
    },
    'scope': 'R2 HF/LoRA runtime, bounded Qwen3 reference and owned R3 validation. '
             'Retirement, shared registries/conftest/packaging/docs and full integration are root-owned.',
    'source_sha256': {name: sha(ROOT / name) for name in FILES},
    'pretrained_qualification': qualification,
    'official_checkpoint_artifacts': artifacts,
    'pretrained_qualification_command': {
        'argv': [PYTHON, 'examples/huggingface/qualify_qwen3.py', '--output',
                 '/tmp/plato-qwen-validation/real-pretrained'],
        'cwd': str(ROOT),
        'env': {'PYTHONPATH': str(ROOT),
                'HF_HOME': '/tmp/plato-qwen-validation/huggingface'},
        'log_sha256': sha(SCRATCH / 'real-pretrained.log'),
    },
    'normal_entrypoint_actual_transport': {
        **cli,
        'status': 'PASS',
        'clients_comm_simulation': False,
        'server_comm_simulation': False,
        'logical_clients': 2,
        'rounds': 1,
        'server_perplexity_logged': 131.19,
        'transport': 'Actual socket payloads using safetensor_encode/safetensor_decode.',
        'payload_size_logged_mb_each_direction_each_client': 2.22,
        'actual_transfer_log_lines': [line for line in cli_text.splitlines()
                                      if 'payload data' in line],
        'env': {'PYTHONPATH': str(ROOT),
                'HF_HOME': '/tmp/plato-qwen-validation/huggingface',
                'OMP_NUM_THREADS': '4', 'MKL_NUM_THREADS': '4',
                'TOKENIZERS_PARALLELISM': 'false'},
        'rss_scope': 'Observed sum of RSS for the CLI process group at 0.5s intervals, '
                     'including server/client/worker/tracker processes. Not an exact global peak.',
        'log_sha256': sha(SCRATCH / 'cli-transport/plato.log'),
        'wrapper_sha256': sha(SCRATCH / 'run_cli_transport.py'),
    },
    'preliminary_simulated_payload_run': {
        **json.loads((SCRATCH / 'cli-final/cli-result.json').read_text()),
        'scope': 'Earlier seeded run had comm_simulation=true. Superseded for shipped '
                 'scenario acceptance by the actual-transport run above.',
    },
    'offline_regression': {
        'scope': 'Network-free local native random Qwen3 + real WordLevel tokenizer + real PEFT; '
                 'architecture/runtime coverage, not official pretrained-model qualification.',
        'env': {'PYTHONPATH': str(ROOT), 'HF_HUB_OFFLINE': '1', 'HF_DATASETS_OFFLINE': '1'},
        'argv': [PYTHON, '-m', 'pytest', 'tests/test_huggingface_artifacts.py',
                 'tests/trainers/test_huggingface_trainer.py',
                 'tests/datasources/test_huggingface_datasource.py',
                 'tests/integration/test_qwen3_lora.py',
                 'tests/trainers/test_huggingface_accumulation.py',
                 'tests/integration/test_huggingface_smollm_smoke.py',
                 'tests/algorithms/test_fedavg_algorithm.py', '-q'],
        'result': '47 passed; 10 warnings; no skips, deselections or xfails.',
        'subsequent_owned_helper_invariant_check': '8 Qwen3 tests passed after explicit '
                                                     'all-non-LoRA-base-parameters-frozen assertion.',
        'focused_log_sha256': sha(SCRATCH / 'focused.log'),
        'collection_ledger': {
            'new_nodes': len(collection), 'removed_nodes_owned_here': 0,
            'nodes': collection,
            'retired_test_removal_ledger': 'Owned separately by retirement/root integration.',
        },
    },
    'red_green': {
        'partial_accumulation': {
            'baseline_red': '4 failed, 2 passed: 3/5 microbatch windows under-normalized '
                            'at both is_last_batch and finalize paths.',
            'red_log_sha256': sha(SCRATCH / 'accumulation-red.log'),
            'green': '6 numerical full/tail cases plus 2 actual HF trainer '
                     'callback/control/scheduler cases passed.',
            'contract': 'Mean of per-microbatch losses in each actual window. '
                        'Tail gradients rescaled by configured_steps/actual_steps; '
                        'no new sample/token-weighted loss contract.',
        },
        'cpu_adapter_alias': {
            'red': 'Actual PEFT CPU snapshot regression failed with original tensor.cpu() '
                   'extraction restored temporarily; mutable payload hash changed.',
            'red_log_sha256': sha(SCRATCH / 'adapter-alias-red.log'),
            'green': 'Same test passed after restoring detached cloned transport tensors.',
            'green_log_sha256': sha(SCRATCH / 'adapter-alias-green.log'),
            'original_probe': {
                'sha256': 'eac9bb092accf3ab713511e734e84960b3df01031c6913206c3d4c6f55ee7af6',
                'finding': 'Four live CPU adapter-storage aliases; prior load round-trip worked.',
            },
        },
    },
    'checkpoint_contract': {
        'save': 'Actual PEFT PeftModel.save_pretrained export, converted to Plato single-file '
                'safetensor tree plus existing .pkl history; no frozen base tensors for Qwen.',
        'load': 'Supported set_peft_model_state_dict restores the existing PEFT wrapper in place.',
        'metadata': '<checkpoint>.hf JSON holds exact model_name/model_revision, '
                    'tokenizer_name/tokenizer_revision and native adapter_config.',
        'mismatch': 'Different artifact identity or adapter keys/shapes rejected before loading.',
        'embedding_compatibility': 'Explicit modules_to_save/trainable tokens/embedding adapters '
                                   'and tokenizer vocabulary expansion remain preserved. '
                                   'Qwen padded vocabulary is retained without shrinking.',
        'full_optimizer_resume_claimed': False,
    },
    'static_checks': {
        'ruff': 'All 11 owned Python source/test/example files: import order passed; formatted.',
        'ty': 'All 11 owned Python source/test/example files passed without diagnostics.',
        'ty_log_sha256': sha(SCRATCH / 'typecheck-all.log'),
        'git_diff_check': 'PASS',
        'revision_trace': 'No /resolve/main/ or /revision/main entries in final real '
                          'qualification or actual-transport CLI logs.',
    },
    'licenses': {
        'official_model': 'Qwen/Qwen3-0.6B-Base Apache-2.0; weights cached outside repository.',
        'local_fixture': 'Original Plato prose under repository Apache-2.0; no copied dataset text.',
    },
    'limitations': [
        'Fixture metrics establish integration behavior only; no benchmark/convergence/quality claim.',
        'Single-process numerical qualification and normal CLI RSS are different measurement scopes.',
        'CLI logs contain one multiprocessing resource_tracker semaphore-cleanup warning at shutdown. '
        'No process survivors or forced containment. Changed HF/LoRA sources allocate no semaphore/queue; '
        'the warning cause is not conclusively attributed and is not suppressed.',
        'Two explicit tied-embedding compatibility tests emit PEFT tied-weight warnings; '
        'corpus mapping emits multiprocess fork deprecation warnings. Tests passed without masking.',
        'Full integrated repository suites and packaging/CI checks remain root integration work.',
        'Python 3.13 is qualified here; no Python 3.14 probe or CI-matrix claim.',
    ],
    'retained_reproduction_paths': [
        '/tmp/plato-phase2-integration/final-mandatory-313',
        '/tmp/plato-qwen-validation',
        '/tmp/plato-llm-model-evidence',
    ],
}
destination = ROOT / 'evidence/2026-refresh/qwen-reference-validation.json'
destination.parent.mkdir(parents=True, exist_ok=True)
destination.write_text(json.dumps(receipt, indent=2) + '\n')
print(destination)
