import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/tmp/plato-refresh-worktrees/qwen-reference')
SCRATCH = Path('/tmp/plato-qwen-validation')
ORIGINAL = 'd3569ec98e64fb83ef43c2b50db4543cfe6a3bc6'
PYTHON = '/tmp/plato-phase2-integration/final-mandatory-313/bin/python'

def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()

original_path = ROOT / 'evidence/2026-refresh/qwen-reference-validation.json'
original = json.loads(original_path.read_text())
original_receipt_git = subprocess.check_output(
    ['git', 'show', ORIGINAL + ':evidence/2026-refresh/qwen-reference-validation.json'],
    cwd=ROOT,
)
assert original_path.read_bytes() == original_receipt_git
qualification_path = SCRATCH / 'preexpanded-fix-real/qualification.json'
fresh = json.loads(qualification_path.read_text())
previous = original['pretrained_qualification']
compared = ['configured_artifacts', 'seed', 'dtype', 'device', 'trainable_parameters',
            'total_parameters', 'optimizer_updates', 'client_sample_counts',
            'before_adapter_sha256', 'after_adapter_sha256', 'frozen_base_sha256',
            'before_perplexity', 'global_perplexity', 'weighted_oracle_all_tensors',
            'payloads_independent', 'adapter_only_checkpoint', 'reload_logits_match',
            'frozen_base_unchanged']
assert all(fresh[key] == previous[key] for key in compared)
source_hashes = {name: sha(ROOT / name) for name in original['source_sha256']}
changed = [name for name, digest in source_hashes.items()
           if digest != original['source_sha256'][name]]
assert changed == ['plato/trainers/huggingface.py', 'tests/integration/test_qwen3_lora.py']
assert '48 passed' in (SCRATCH / 'preexpanded-fix-focused.log').read_text()
assert (SCRATCH / 'preexpanded-fix-typecheck.log').read_text().strip() == 'All checks passed!'
assert '2 passed' in (SCRATCH / 'preexpanded-green.log').read_text()
assert '1 failed' in (SCRATCH / 'preexpanded-red.log').read_text()
assert '/resolve/main/' not in (SCRATCH / 'preexpanded-fix-real.log').read_text()
assert '/revision/main' not in (SCRATCH / 'preexpanded-fix-real.log').read_text()
config = json.loads((Path(fresh['resolved_checkpoint_directory']) / 'config.json').read_text())
receipt = {
    'schema_version': 1,
    'date': '2026-10-03',
    'status': 'PASS',
    'baseline_candidate': ORIGINAL,
    'branch': 'maintenance/2026-qwen-reference',
    'review_finding': {
        'id': 'QWEN-01', 'severity': 'medium',
        'review_path': '/tmp/plato-qwen-review/qwen-reference-review-d3569ec.json',
        'review_sha256': sha(Path('/tmp/plato-qwen-review/qwen-reference-review-d3569ec.json')),
        'trigger': 'Caller expands a supplied PEFT model before constructing Trainer(model=model).',
        'old_behavior': 'Input/output embedding matrices were omitted from adapter payload and checkpoint.',
        'new_behavior': 'Trainer compares the current embedding size against the already pinned '
                        'original AutoConfig vocabulary, retaining resized input/output embedding state '
                        'even when the caller performed the resize.',
        'additional_hub_lookups': 0,
    },
    'source_sha256': source_hashes,
    'changed_source_paths': changed,
    'red_green': {
        'new_test': 'tests/integration/test_qwen3_lora.py::'
                    'test_supplied_preexpanded_peft_model_preserves_embedding_snapshots_and_logits',
        'red': '1 failed on d3569ec: missing embed_tokens payload key.',
        'red_log_sha256': sha(SCRATCH / 'preexpanded-red.log'),
        'green': 'New supplied-model regression and existing in-trainer expansion regression: 2 passed.',
        'green_log_sha256': sha(SCRATCH / 'preexpanded-green.log'),
        'actual_peft_checks': [
            'Original pinned config remains vocabulary256 while supplied model config becomes257.',
            'Both input and output embedding matrices occur in actual payload and checkpoint.',
            'Payload hash stays unchanged after mutations of live added-token embedding rows.',
            'Algorithm.load_weights restores logits exactly after row mutations.',
            'Trainer.load_model restores logits exactly after row mutations.',
            'PEFT extraction/save/load cannot reread base configuration implicitly.',
        ],
    },
    'focused_validation': {
        'env': {'PYTHONPATH': str(ROOT), 'HF_HUB_OFFLINE': '1', 'HF_DATASETS_OFFLINE': '1'},
        'argv': original['offline_regression']['argv'],
        'result': '48 passed,10 visible warnings; no skips,xfails,deselections.',
        'log_sha256': sha(SCRATCH / 'preexpanded-fix-focused.log'),
        'ledger': {'new_nodes_relative_to_d3569ec': 1, 'removed_nodes': 0,
                   'total_new_nodes_relative_to_preimplementation_baseline': 25},
        'ruff': 'All11 owned Python files pass import-order checks.',
        'ty': 'All11 owned Python files pass without diagnostics.',
        'ty_log_sha256': sha(SCRATCH / 'preexpanded-fix-typecheck.log'),
    },
    'fresh_real_pretrained_qualification': {
        'result': fresh,
        'argv': [PYTHON, 'examples/huggingface/qualify_qwen3.py', '--output',
                 '/tmp/plato-qwen-validation/preexpanded-fix-real'],
        'env': {'PYTHONPATH': str(ROOT), 'HF_HOME': '/tmp/plato-qwen-validation/huggingface'},
        'qualification_sha256': sha(qualification_path),
        'log_sha256': sha(SCRATCH / 'preexpanded-fix-real.log'),
        'network_trace': 'No /resolve/main/ or /revision/main entries.',
    },
    'unchanged_shipped_reference': {
        'reference_config_sha256': source_hashes['configs/HuggingFace/fedavg_qwen3_06b_lora.toml'],
        'reference_config_and_other12_source_hashes_match_original_candidate': True,
        'original_vocabulary_size': config['vocab_size'],
        'predicate': 'Unmodified Qwen input embeddings have the original vocabulary size '
                     '151936; embedding_size != original_vocab_size is false, so the '
                     'correction does not add embedding tensors to the reference.',
        'fresh_qualification_fields_exactly_equal_original': compared,
        'before_and_after_adapter_hashes_exactly_equal_original': True,
        'frozen_base_hash_exactly_equal_original': True,
        'finite_perplexity_and_optimizer_updates_exactly_equal_original': True,
    },
    'historical_d3569ec_observations': {
        'original_receipt_path': 'evidence/2026-refresh/qwen-reference-validation.json',
        'original_receipt_sha256': sha(original_path),
        'original_receipt_and_original_run_files_modified': False,
        'actual_transport_cli': original['normal_entrypoint_actual_transport'],
        'cli_rerun_for_correction': False,
        'scope': 'Actual transport CLI observations remain bound to d3569ec. The '
                 'reference config,transport/checkpoint interfaces and all other source '
                 'hashes are unchanged; the correction condition is false for the shipped '
                 'pretrained vocabulary. Fresh actual qualification confirms exact tensor '
                 'hashes/metrics, preserving the applicability of the historical observation '
                 'without presenting it as a new CLI run.',
    },
    'limitations': original['limitations'] + [
        'This is the author correction receipt; fresh independent review remains root-owned.',
        'Source changes are limited to Trainer embedding-preservation detection and one actual '
        'PEFT regression. No integrated checkout,shared registry,packaging,docs or retired '
        'archive files were edited.',
    ],
}
destination = ROOT / 'evidence/2026-refresh/qwen-reference-expanded-embeddings-validation.json'
destination.write_text(json.dumps(receipt, indent=2) + '\n')
print(destination)
