import json
import os
import signal
import socket
import subprocess
import time
from pathlib import Path

root = Path("/tmp/plato-refresh-worktrees/qwen-reference")
runtime = Path("/tmp/plato-qwen-validation/cli")
runtime.mkdir(parents=True, exist_ok=True)
(runtime / "models").mkdir(exist_ok=True)
cache = runtime / "models/huggingface"
if not cache.exists():
    cache.symlink_to("/tmp/plato-qwen-validation/real-pretrained/models/huggingface", target_is_directory=True)
with socket.socket() as sock:
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
command = ["/tmp/plato-phase2-integration/final-mandatory-313/bin/python", "plato.py",
           "--config", "configs/HuggingFace/fedavg_qwen3_06b_lora.toml", "--cpu",
           "--base", str(runtime), "--port", str(port)]
env = dict(os.environ, PYTHONPATH=str(root), HF_HOME="/tmp/plato-qwen-validation/huggingface",
           OMP_NUM_THREADS="4", MKL_NUM_THREADS="4", TOKENIZERS_PARALLELISM="false")
started = time.monotonic()
peak = 0
max_processes = 0
contained = False
with (runtime / "plato.log").open("w") as log:
    process = subprocess.Popen(command, cwd=root, env=env, stdout=log,
                               stderr=subprocess.STDOUT, start_new_session=True)
    while process.poll() is None and time.monotonic() - started < 240:
        stats = subprocess.check_output(["ps", "-axo", "pid,pgid,rss"], text=True)
        group = []
        for line in stats.splitlines()[1:]:
            parts = line.split()
            if len(parts) == 3 and int(parts[1]) == process.pid:
                group.append(int(parts[2]) * 1024)
        peak = max(peak, sum(group))
        max_processes = max(max_processes, len(group))
        time.sleep(0.5)
    if process.poll() is None:
        contained = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=5)
    stats = subprocess.check_output(["ps", "-axo", "pid,pgid,rss,args"], text=True)
    survivors = [line for line in stats.splitlines()[1:]
                 if len(line.split()) >= 3 and int(line.split()[1]) == process.pid]
    if survivors:
        os.killpg(process.pid, signal.SIGKILL)
result = {"command": command, "cwd": str(root), "port": port,
          "returncode": process.returncode, "watchdog_containment": contained,
          "natural_exit": not contained and process.returncode == 0,
          "elapsed_seconds": time.monotonic() - started,
          "peak_combined_rss_bytes_observed": peak, "rss_sampling_seconds": 0.5,
          "maximum_group_processes": max_processes, "survivors_after_exit": survivors,
          "log": str(runtime / "plato.log")}
(runtime / "cli-result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
raise SystemExit(0 if result["natural_exit"] and not survivors else 1)
