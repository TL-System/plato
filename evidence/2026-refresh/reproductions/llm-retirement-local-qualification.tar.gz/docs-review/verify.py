"""Independent, read-only verification for the retirement documentation review."""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
import tarfile
import tomllib
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit

DOCS = Path('/tmp/plato-refresh-worktrees/llm-retirement-docs')
ARCHIVE = Path('/tmp/plato-refresh-worktrees/retire-llm-backends')
QWEN = Path('/tmp/plato-refresh-worktrees/qwen-reference')
SCRATCH = Path('/tmp/plato-llm-docs-review')
SITE = SCRATCH / 'site'
BASE = '9ee92c52307cd3ecdce0c7416708c504bdb52137'
HEAD = 'f4898e5f8cbf3a8a92c28d1227c4b03c17429773'
SOURCE = '489b54439e343aa7a22d21c18f2f9bc9c0f1a16b'
PIN = 'da87bfb608c14b7cf20ba1ce41287e8de496c0cd'


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(root: Path, *args: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(root), *args])


class Page(HTMLParser):
    def __init__(self, path: Path):
        super().__init__()
        self.hrefs: list[str] = []
        self.ids: set[str] = set()
        self.feed(path.read_text())

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if values.get('id'):
            self.ids.add(values['id'])
        if tag == 'a':
            if values.get('href'):
                self.hrefs.append(values['href'])
            if values.get('name'):
                self.ids.add(values['name'])


receipt_path = DOCS / 'evidence/2026-refresh/llm-retirement-docs-validation.json'
receipt = json.loads(receipt_path.read_text())
changed = git(DOCS, 'diff', '--name-only', BASE, HEAD).decode().splitlines()
hashes = {name: sha(DOCS / name) for name in changed}
hash_mismatches = [
    name for name, recorded in receipt['changed_files_sha256'].items()
    if hashes[name] != recorded
]
source_delta = git(DOCS, 'diff', '--name-only', SOURCE, HEAD).decode().splitlines()
assert source_delta == ['evidence/2026-refresh/llm-retirement-docs-validation.json']
assert git(DOCS, 'rev-parse', 'HEAD').decode().strip() == HEAD
assert not git(DOCS, 'status', '--porcelain').strip()

pages = {path: Page(path) for path in SITE.rglob('*.html')}
missing_paths = []
missing_fragments = []
relative_paths = 0
local_fragments = 0
for path, page in pages.items():
    for href in page.hrefs:
        url = urlsplit(href)
        if url.scheme or url.netloc:
            continue
        if not url.path and not url.fragment:
            continue
        if url.path:
            relative_paths += 1
            target = ((SITE / unquote(url.path).lstrip('/')) if url.path.startswith('/')
                      else path.parent / unquote(url.path)).resolve()
            if target.is_dir():
                target /= 'index.html'
        else:
            target = path
        if not target.exists():
            missing_paths.append({'from': str(path.relative_to(SITE)), 'href': href})
            continue
        if url.fragment and target.suffix == '.html':
            local_fragments += 1
            target_page = pages.get(target) or Page(target)
            if unquote(url.fragment) not in target_page.ids:
                missing_fragments.append({
                    'from': str(path.relative_to(SITE)), 'href': href,
                })

repository_links = []
for name in (
    'docs/third_party.md', 'archives/retired/nanochat/README.md',
    'archives/retired/lerobot/README.md',
):
    for match in re.finditer(r'\[[^\]]+\]\((<[^>]+>|[^)]+)\)', (DOCS / name).read_text()):
        destination = match.group(1).strip('<>')
        url = urlsplit(destination)
        if url.scheme or url.netloc or not url.path:
            continue
        resolved = ((DOCS / name).parent / unquote(url.path)).resolve()
        target_name = resolved.relative_to(DOCS.resolve())
        candidates = [root / target_name for root in (DOCS, ARCHIVE, QWEN)]
        found = next((path for path in candidates if path.exists()), None)
        repository_links.append({
            'from': name, 'target': str(target_name),
            'resolved': str(found) if found else None,
            'sha256': sha(found) if found and found.is_file() else None,
        })

archive_checks = []
for backend in ('nanochat', 'lerobot'):
    manifest_path = ARCHIVE / 'archives/retired' / backend / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    bad = []
    for entry in manifest['files']:
        path = ARCHIVE / entry['archive_path']
        baseline = git(ARCHIVE, 'show', f"{BASE}:{entry['original_path']}")
        if (path.read_bytes() != baseline
                or sha(path) != entry['sha256']
                or path.stat().st_size != entry['bytes']):
            bad.append(entry['original_path'])
    archive_checks.append({
        'backend': backend, 'manifest_sha256': sha(manifest_path),
        'historical_commit': manifest['pre_retirement_plato_commit'],
        'files_verified_against_baseline': len(manifest['files']), 'mismatches': bad,
    })

nano = json.loads((ARCHIVE / 'archives/retired/nanochat/manifest.json').read_text())
upstream = nano['upstream']
tar_path = ARCHIVE / upstream['archive_path']
upstream_errors = []
with tarfile.open(tar_path) as bundle:
    members = {m.name.removeprefix('./'): m for m in bundle.getmembers() if m.isfile()}
    for entry in upstream['files']:
        member = members.get(entry['path'])
        data = bundle.extractfile(member).read() if member else None
        if data is None or hashlib.sha256(data).hexdigest() != entry['sha256']:
            upstream_errors.append(entry['path'])
    license_data = bundle.extractfile(members['LICENSE']).read()
upstream_license = ARCHIVE / upstream['license_path']
assert license_data == upstream_license.read_bytes()
assert b'Andrej Karpathy' in license_data and b'MIT License' in license_data
assert len(members) == len(upstream['files']) == 54
assert sha(tar_path) == upstream['archive_sha256']
assert sha(upstream_license) == upstream['license_sha256']
assert git(ARCHIVE, 'ls-tree', BASE, 'external/nanochat').decode().split()[2] == upstream['gitlink_pin']

qual_path = Path('/tmp/plato-qwen-validation/real-pretrained/qualification.json')
qualification = json.loads(qual_path.read_text())
assert sha(qual_path) == receipt['pretrained_qualification']['sha256']
assert qualification == receipt['pretrained_qualification']['result']
config_path = QWEN / 'configs/HuggingFace/fedavg_qwen3_06b_lora.toml'
config = tomllib.loads(config_path.read_text())
assert config['trainer']['model_revision'] == config['trainer']['tokenizer_revision'] == PIN
assert config['trainer']['model_name'] == config['trainer']['tokenizer_name'] == 'Qwen/Qwen3-0.6B-Base'
assert config['trainer']['target_perplexity'] == {'null': True}
assert config['trainer']['rounds'] == config['trainer']['max_concurrency'] == 1
assert config['trainer']['model_dtype'] == 'float32'
splits = {name: json.loads((QWEN / f'tests/fixtures/qwen3/{name}.json').read_text())
          for name in ('train', 'validation')}
assert len(splits['train']) == 5 and len(splits['validation']) == 2
assert not ({r['text'] for r in splits['train']} & {r['text'] for r in splits['validation']})
peer_hashes = {name: sha(QWEN / name)
               for name in receipt['reviewed_implementation_sources']['sha256']}
peer_source_changes = [name for name, old_hash
                       in receipt['reviewed_implementation_sources']['sha256'].items()
                       if peer_hashes[name] != old_hash]

old_pages = []
for filename, marker in (
    ('3. SmolVLA Trainer with LeRobot', 'LeRobot and SmolVLA integration retired'),
    ('5. Nanochat in Plato', 'Nanochat integration retired'),
):
    html_path = SITE / 'examples/case-studies' / filename / 'index.html'
    rendered = html_path.read_text()
    assert marker in rendered
    old_pages.append(str(html_path.relative_to(SITE)))
nav = (DOCS / 'docs/mkdocs.yml').read_text()
assert 'Qwen3 Federated LoRA:' in nav
assert 'SmolVLA Trainer with LeRobot:' not in nav and 'Nanochat in Plato:' not in nav

cli_path = Path('/tmp/plato-qwen-validation/cli-final/cli-result.json')
cli_result = json.loads(cli_path.read_text())
cli_log = Path(cli_result['log'])
cli_text = cli_log.read_text()
assert cli_result['returncode'] == 0 and cli_result['natural_exit']
assert not cli_result['watchdog_containment'] and not cli_result['survivors_after_exit']
assert 'Global model perplexity: 131.47' in cli_text
assert 'Target number of training rounds reached.' in cli_text
assert 'There appear to be 1 leaked semaphore objects to clean up at shutdown' in cli_text

result = {
    'documentation_head': HEAD, 'documentation_source_commit': SOURCE,
    'baseline_commit': BASE, 'archive_commit': git(ARCHIVE, 'rev-parse', 'HEAD').decode().strip(),
    'qwen_worktree_head': git(QWEN, 'rev-parse', 'HEAD').decode().strip(),
    'qwen_worktree_is_uncommitted': bool(git(QWEN, 'status', '--porcelain').strip()),
    'documentation_changed_files_sha256': hashes,
    'author_receipt_sha256': sha(receipt_path),
    'author_documentation_hash_mismatches': hash_mismatches,
    'strict_build': {'exit_code': 0, 'log_sha256': sha(SCRATCH / 'mkdocs-build.log')},
    'rendered_links': {'html_pages': len(pages), 'relative_path_hrefs': relative_paths,
                       'missing_paths': missing_paths, 'local_fragment_hrefs': local_fragments,
                       'missing_fragments': missing_fragments},
    'old_url_pages_built_as_notices': old_pages,
    'retired_case_studies_absent_from_active_nav': True,
    'repository_provenance_links': repository_links,
    'archive_originals': archive_checks,
    'nanochat_upstream': {'tarball_sha256': sha(tar_path), 'files_verified': len(members),
                         'mismatches': upstream_errors, 'license_sha256': sha(upstream_license)},
    'qualification': {'sha256': sha(qual_path), 'recorded_result_matches_receipt': True,
                      'scope': qualification['peak_rss_scope'],
                      'elapsed_seconds': qualification['elapsed_seconds'],
                      'peak_rss_bytes': qualification['peak_rss_bytes']},
    'reference_config_sha256': sha(config_path),
    'config_null_perplexity_setting': config['trainer']['target_perplexity'],
    'local_fixture_splits_disjoint': True,
    'qwen_peer_current_file_sha256': peer_hashes,
    'qwen_peer_changes_since_docs_author_receipt': peer_source_changes,
    'subsequent_cli_observation': {'receipt_sha256': sha(cli_path), 'log_sha256': sha(cli_log),
                                  'result': cli_result,
                                  'logged_perplexity': 131.47,
                                  'one_resource_tracker_semaphore_warning': True},
}
(SCRATCH / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({
    'docs_hash_mismatches': hash_mismatches, 'links': result['rendered_links'],
    'repository_links_checked': len(repository_links),
    'repository_links_missing': [entry for entry in repository_links if not entry['resolved']],
    'archive_originals': archive_checks, 'upstream': result['nanochat_upstream'],
    'qwen_peer_changes_since_author': peer_source_changes,
}, indent=2))
