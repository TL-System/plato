"""Read-only factual checks for the Qwen CLI documentation addendum."""

from __future__ import annotations

import hashlib
import json
import subprocess
import tomllib
from pathlib import Path

DOCS = Path('/tmp/plato-refresh-worktrees/llm-retirement-docs')
QWEN = Path('/tmp/plato-refresh-worktrees/qwen-reference')
SCRATCH = Path('/tmp/plato-llm-docs-review')
PARENT = 'f4898e5f8cbf3a8a92c28d1227c4b03c17429773'
COMMIT = '39f58144ffe5aa7ba4b940f76c984f991f93d6ab'
IMPLEMENTATION = 'd3569ec98e64fb83ef43c2b50db4543cfe6a3bc6'
GUIDE = 'docs/docs/examples/case-studies/6. Qwen3 Federated LoRA.md'
ADDENDUM = 'evidence/2026-refresh/llm-retirement-docs-cli-addendum.json'
RECEIPT = 'evidence/2026-refresh/qwen-reference-validation.json'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args]).decode()


assert git(DOCS, 'rev-parse', 'HEAD').strip() == COMMIT
assert git(DOCS, 'rev-parse', 'HEAD^').strip() == PARENT
assert not git(DOCS, 'status', '--porcelain').strip()
assert git(QWEN, 'rev-parse', 'HEAD').strip() == IMPLEMENTATION
assert not git(QWEN, 'status', '--porcelain').strip()
assert set(git(DOCS, 'diff', '--name-only', PARENT, COMMIT).splitlines()) == {
    GUIDE, ADDENDUM,
}

addendum = json.loads((DOCS / ADDENDUM).read_text())
receipt = json.loads((QWEN / RECEIPT).read_text())
assert sha(DOCS / GUIDE) == addendum['documentation_source_identity']['changed_files_sha256'][GUIDE]
assert sha(QWEN / RECEIPT) == addendum['implementation_identity']['receipt_sha256']
assert sha(SCRATCH / 'review.json') == addendum['prior_independent_review']['sha256']
source_hashes = {name: sha(QWEN / name) for name in receipt['source_sha256']}
assert source_hashes == receipt['source_sha256']
assert all(sha(QWEN / name) == digest
           for name, digest in addendum['implementation_identity']['inspected_sources_sha256'].items())

config = tomllib.loads((QWEN / 'configs/HuggingFace/fedavg_qwen3_06b_lora.toml').read_text())
assert config['clients']['comm_simulation'] is False
assert config['server']['comm_simulation'] is False
assert config['trainer']['random_seed'] == 17
assert config['trainer']['max_concurrency'] == 1
assert config['trainer']['rounds'] == 1
assert config['trainer']['target_perplexity'] == {'null': True}
assert config['server']['random_seed'] == config['data']['random_seed'] == config['data']['shuffle_seed'] == 17

cli_path = Path(addendum['normal_entrypoint_actual_transport']['raw_receipt_path'])
raw_cli = json.loads(cli_path.read_text())
cli = receipt['normal_entrypoint_actual_transport']
assert addendum['normal_entrypoint_actual_transport']['result'] == cli
assert all(cli[key] == value for key, value in raw_cli.items())
assert sha(cli_path) == addendum['normal_entrypoint_actual_transport']['raw_receipt_sha256']
log_path = Path(cli['log'])
assert sha(log_path) == cli['log_sha256'] == addendum['normal_entrypoint_actual_transport']['log_sha256']
log = log_path.read_text()
assert all(line in log for line in cli['actual_transfer_log_lines'])
assert len(cli['actual_transfer_log_lines']) == 8
assert '(simulated)' not in '\n'.join(cli['actual_transfer_log_lines'])
assert 'Global model perplexity: 131.19' in log
assert 'Target number of training rounds reached.' in log
assert 'Saving the checkpoint to ' in log
assert cli['returncode'] == 0 and cli['natural_exit']
assert not cli['watchdog_containment'] and not cli['survivors_after_exit']
assert cli['descendant_shutdown_grace_seconds'] == 10
warning = addendum['normal_entrypoint_actual_transport']['shutdown_warning_text']
assert warning in log
assert log.count('UserWarning: resource_tracker:') == 1

qual_path = Path(addendum['single_process_qualification']['raw_receipt_path'])
qual = json.loads(qual_path.read_text())
assert qual == receipt['pretrained_qualification'] == addendum['single_process_qualification']['result']
assert sha(qual_path) == addendum['single_process_qualification']['raw_receipt_sha256']
assert f"{qual['elapsed_seconds']:.2f}" == '14.18'
assert f"{qual['peak_rss_bytes'] / (1024 ** 3):.2f}" == '3.97'
assert f"{cli['elapsed_seconds']:.2f}" == '48.71'
assert f"{cli['peak_combined_rss_bytes_observed'] / (1024 ** 3):.2f}" == '10.71'

# Reuse the original generic HTML parser only, preserving the original receipt.
original_verifier = (SCRATCH / 'verify.py').read_text()
parser_source = original_verifier.split('class Page(HTMLParser):', 1)[1].split('receipt_path = ', 1)[0]
from html.parser import HTMLParser
from urllib.parse import unquote, urlsplit

exec('class Page(HTMLParser):' + parser_source)
site = SCRATCH / 'addendum-site'
pages = {path: Page(path) for path in site.rglob('*.html')}
missing = []
path_hrefs = 0
fragment_hrefs = 0
for page_path, page in pages.items():
    for href in page.hrefs:
        url = urlsplit(href)
        if url.scheme or url.netloc or not (url.path or url.fragment):
            continue
        target = page_path
        if url.path:
            path_hrefs += 1
            target = ((site / unquote(url.path).lstrip('/')) if url.path.startswith('/')
                      else page_path.parent / unquote(url.path)).resolve()
            if target.is_dir():
                target /= 'index.html'
        if not target.exists():
            missing.append({'from': str(page_path.relative_to(site)), 'href': href})
        elif url.fragment and target.suffix == '.html':
            fragment_hrefs += 1
            if unquote(url.fragment) not in (pages.get(target) or Page(target)).ids:
                missing.append({'from': str(page_path.relative_to(site)), 'href': href})
assert not missing
rendered = (site / 'examples/case-studies/6. Qwen3 Federated LoRA/index.html').read_text()
assert all(value in rendered for value in ('48.71', '11,497,668,608', '10.71', '14.18', '4,258,398,208', 'resource_tracker'))

result = {
    'documentation_commit': COMMIT,
    'documentation_parent': PARENT,
    'implementation_commit': IMPLEMENTATION,
    'guide_sha256': sha(DOCS / GUIDE),
    'addendum_receipt_sha256': sha(DOCS / ADDENDUM),
    'implementation_receipt_sha256': sha(QWEN / RECEIPT),
    'implementation_source_hashes_verified': source_hashes,
    'raw_cli_receipt_sha256': sha(cli_path),
    'cli_log_sha256': sha(log_path),
    'actual_transfer_lines_verified': 8,
    'raw_qualification_receipt_sha256': sha(qual_path),
    'strict_build_log_sha256': sha(SCRATCH / 'addendum-mkdocs-build.log'),
    'rendered_links': {'path_hrefs': path_hrefs, 'fragment_hrefs': fragment_hrefs, 'missing': missing},
    'measurement_values_and_rounding_match': True,
    'seed_wording_note': 'Trainer resets global Torch RNG to 17+client_id; IID sampler uses its own generator seeded from data.random_seed=17.',
}
(SCRATCH / 'addendum-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': 'PASS_FACTUAL_BINDING_AND_BUILD', **result['rendered_links']}, indent=2))
