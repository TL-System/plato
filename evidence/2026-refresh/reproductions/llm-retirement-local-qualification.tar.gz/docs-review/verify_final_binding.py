"""Focused final correction and evidence-binding verification."""

from __future__ import annotations

import hashlib
import json
import subprocess
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit

DOCS = Path('/tmp/plato-refresh-worktrees/llm-retirement-docs')
QWEN = Path('/tmp/plato-refresh-worktrees/qwen-reference')
SCRATCH = Path('/tmp/plato-llm-docs-review')
COMMIT = 'fd4a2bcfa0eb3a57fa015281a156e893d95e9484'
PARENT = '39f58144ffe5aa7ba4b940f76c984f991f93d6ab'
IMPLEMENTATION = 'bca1f6ec3541090dccb838197206fee2d6412516'
OLD_IMPLEMENTATION = 'd3569ec98e64fb83ef43c2b50db4543cfe6a3bc6'
GUIDE = 'docs/docs/examples/case-studies/6. Qwen3 Federated LoRA.md'
BINDING = 'evidence/2026-refresh/llm-retirement-docs-final-binding.json'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args])


assert git(DOCS, 'rev-parse', 'HEAD').decode().strip() == COMMIT
assert git(DOCS, 'rev-parse', 'HEAD^').decode().strip() == PARENT
assert not git(DOCS, 'status', '--porcelain').strip()
assert git(QWEN, 'rev-parse', 'HEAD').decode().strip() == IMPLEMENTATION
assert not git(QWEN, 'status', '--porcelain').strip()
assert set(git(DOCS, 'diff', '--name-only', PARENT, COMMIT).decode().splitlines()) == {GUIDE, BINDING}

binding = json.loads((DOCS / BINDING).read_text())
assert sha(DOCS / GUIDE) == binding['documentation_source_identity']['guide_sha256']
assert sha(SCRATCH / 'addendum-review.json') == binding['finding_closed']['review_sha256']
for name, digest in binding['finding_closed']['source_sha256'].items():
    assert sha(QWEN / name) == digest
text = (DOCS / GUIDE).read_text()
assert 'Torch’s global RNG to `17 + client_id`' in text
assert 'The IID sampler uses a separate generator' in text
assert 'seeded by `data.random_seed = 17`' in text
assert 'for Torch sampling' not in text
assert 'torch.manual_seed(int(seed) + self.client_id)' in (QWEN / 'plato/trainers/huggingface.py').read_text()
assert 'gen.manual_seed(self.random_seed)' in (QWEN / 'plato/samplers/iid.py').read_text()
assert 'self.random_seed = Config().data.random_seed' in (QWEN / 'plato/samplers/base.py').read_text()

correction_path = QWEN / binding['current_implementation']['receipt_path']
correction = json.loads(correction_path.read_text())
assert binding['current_implementation']['commit'] == IMPLEMENTATION
assert sha(correction_path) == binding['current_implementation']['receipt_sha256']
source_hashes = {name: sha(QWEN / name) for name in correction['source_sha256']}
assert source_hashes == correction['source_sha256']
raw_path = Path(binding['fresh_qualifier']['raw_receipt_path'])
qualification = json.loads(raw_path.read_text())
assert qualification == correction['fresh_real_pretrained_qualification']['result']
assert sha(raw_path) == binding['fresh_qualifier']['raw_receipt_sha256']
assert sha(raw_path) == correction['fresh_real_pretrained_qualification']['qualification_sha256']
assert f"{qualification['elapsed_seconds']:.2f}" == '14.04'
assert qualification['peak_rss_bytes'] == 4259299328
assert f"{qualification['peak_rss_bytes'] / 1024**3:.2f}" == '3.97'
assert '14.04' in text and '4,259,299,328' in text
assert qualification['status'] == 'PASS'
assert qualification['frozen_base_unchanged'] and qualification['reload_logits_match']
assert qualification['adapter_only_checkpoint'] and qualification['weighted_oracle_all_tensors']

historical_path = QWEN / binding['historical_launcher']['receipt_path']
historical = json.loads(historical_path.read_text())
assert sha(historical_path) == binding['historical_launcher']['receipt_sha256']
assert git(QWEN, 'show', f'{OLD_IMPLEMENTATION}:{binding["historical_launcher"]["receipt_path"]}') == historical_path.read_bytes()
assert binding['historical_launcher']['implementation_commit'] == OLD_IMPLEMENTATION
assert binding['historical_launcher']['rerun_for_correction'] is False
assert OLD_IMPLEMENTATION in text and 'original launcher receipt' in text
cli_path = Path('/tmp/plato-qwen-validation/cli-transport/cli-result.json')
cli = json.loads(cli_path.read_text())
assert sha(cli_path) == binding['historical_launcher']['raw_receipt_sha256']
assert sha(Path(cli['log'])) == binding['historical_launcher']['log_sha256']
assert f"{cli['elapsed_seconds']:.2f}" == '48.71'
assert cli['peak_combined_rss_bytes_observed'] == 11497668608
assert '48.71' in text and '11,497,668,608' in text
assert 'cause has not been established' in text

# Check rendered links without repeating archive or historical provenance checks.
parser_source = (SCRATCH / 'verify.py').read_text().split('class Page(HTMLParser):', 1)[1].split('receipt_path = ', 1)[0]
exec('class Page(HTMLParser):' + parser_source)
site = SCRATCH / 'final-binding-site'
pages = {path: Page(path) for path in site.rglob('*.html')}
missing = []
path_count = 0
fragment_count = 0
for html, page in pages.items():
    for href in page.hrefs:
        url = urlsplit(href)
        if url.scheme or url.netloc or not (url.path or url.fragment):
            continue
        target = html
        if url.path:
            path_count += 1
            target = ((site / unquote(url.path).lstrip('/')) if url.path.startswith('/')
                      else html.parent / unquote(url.path)).resolve()
            if target.is_dir():
                target /= 'index.html'
        if not target.exists():
            missing.append({'from': str(html.relative_to(site)), 'href': href})
        elif url.fragment and target.suffix == '.html':
            fragment_count += 1
            if unquote(url.fragment) not in (pages.get(target) or Page(target)).ids:
                missing.append({'from': str(html.relative_to(site)), 'href': href})
assert not missing
html = (site / 'examples/case-studies/6. Qwen3 Federated LoRA/index.html').read_text()
assert all(value in html for value in ('14.04', '4,259,299,328', 'qwen-reference-expanded-embeddings-validation.json', OLD_IMPLEMENTATION))

report = {
    'schema_version': 1,
    'date': '2026-10-03',
    'review_type': 'Independent bounded final documentation correction and factual binding review',
    'reviewer': '/root/llm_docs_review',
    'decision': 'ACCEPT_DOCUMENTATION_FINAL_BINDING_SCOPE',
    'unresolved_findings': {'critical': 0, 'high': 0, 'medium': 0, 'low': 0},
    'findings': [],
    'closed_findings': [{
        'id': 'DOCS-ADDENDUM-L01',
        'status': 'CLOSED',
        'evidence': 'Corrected guide explicitly distinguishes the 17 + client_id global Torch RNG reset from the IID sampler generator seeded with data.random_seed=17. Current trainer and IID/base sampler sources agree.',
        'prior_review_sha256': sha(SCRATCH / 'addendum-review.json'),
    }],
    'source': {
        'documentation_commit': COMMIT,
        'documentation_parent': PARENT,
        'documentation_worktree_clean': True,
        'only_changed_paths': [GUIDE, BINDING],
        'guide_sha256': sha(DOCS / GUIDE),
        'final_binding_receipt_sha256': sha(DOCS / BINDING),
        'current_qwen_implementation_commit': IMPLEMENTATION,
        'current_qwen_worktree_clean': True,
        'current_qwen_receipt_sha256': sha(correction_path),
        'current_qwen_source_sha256_verified': source_hashes,
    },
    'factual_binding': {
        'fresh_qualifier': {
            'implementation_commit': IMPLEMENTATION,
            'raw_receipt_sha256': sha(raw_path),
            'result_exactly_matches_committed_correction_receipt': True,
            'elapsed_seconds': qualification['elapsed_seconds'],
            'peak_rss_bytes': qualification['peak_rss_bytes'],
            'guide_rounding_matches': True,
            'scope': qualification['peak_rss_scope'],
        },
        'historical_cli': {
            'implementation_commit': OLD_IMPLEMENTATION,
            'original_receipt_sha256': sha(historical_path),
            'original_receipt_byte_identical_to_d3569ec': True,
            'raw_receipt_sha256': sha(cli_path),
            'log_sha256': sha(Path(cli['log'])),
            'guide_explicitly_identifies_historical_revision': True,
            'no_cli_replay_claim': True,
            'measurements_and_warning_scope_unchanged': True,
        },
        'assessment': 'The fresh qualifier and corrected implementation have their own linked receipt; the normal CLI observation remains explicitly bound to d3569ec with its original receipt. Single-process qualification and sampled aggregate launcher RSS remain distinct, and the semaphore-warning cause remains unknown.',
    },
    'independent_checks': {
        'strict_mkdocs': {
            'command': ['/tmp/plato-llm-docs-venv/bin/python', '-m', 'mkdocs', 'build', '--strict', '--config-file', 'docs/mkdocs.yml', '--site-dir', str(site)],
            'exit_code': 0,
            'log_sha256': sha(SCRATCH / 'final-binding-build.log'),
        },
        'rendered_links': {'path_hrefs': path_count, 'fragment_hrefs': fragment_count, 'missing': missing},
        'new_receipt_link_target_exists_in_committed_qwen_tree': True,
        'whitespace_diff_check_exit_code': 0,
    },
    'verification_script': {'path': str(SCRATCH / 'verify_final_binding.py'), 'sha256': sha(SCRATCH / 'verify_final_binding.py')},
    'limits': [
        'Focused two-file documentation correction review; earlier accepted archive/navigation/provenance review was not repeated.',
        'No source edits, subagents, dependency changes or runtime executions. Supplied execution evidence was independently read and source/hash-correlated.',
        'This accepts documentation facts and bindings at the exact named commits. Combined repository qualification and final publication remain root-owned.',
    ],
}
(SCRATCH / 'final-binding-review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'path': str(SCRATCH / 'final-binding-review.json'), 'sha256': sha(SCRATCH / 'final-binding-review.json'), 'decision': report['decision'], 'unresolved_findings': report['unresolved_findings'], 'rendered_links': report['independent_checks']['rendered_links']}, indent=2))
