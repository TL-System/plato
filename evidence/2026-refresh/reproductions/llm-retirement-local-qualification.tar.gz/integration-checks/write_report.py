"""Write the preliminary independent integration receipt outside the worktree."""

import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path('/tmp/plato-refresh-worktrees/llm-integrated')
SCRATCH = Path('/tmp/plato-llm-integration/checks')
PROFILE = Path('/tmp/plato-llm-integration/preliminary-d3569ec')


def fingerprint(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


bounded = json.loads((SCRATCH / 'bounded-checks.json').read_text())
typing = json.loads((SCRATCH / 'typing-classification.json').read_text())
sources = json.loads((SCRATCH / 'source-fingerprints.json').read_text())
assert not typing['new_full_diagnostic_signatures']
assert not typing['changed_active_diagnostic_count']
assert not typing['scoped_diagnostic_count']
assert not typing['qwen_diagnostic_count']
assert (typing['baseline_diagnostics'], typing['full_diagnostics']) == (664, 657)
assert len(typing['removed_full_diagnostic_signatures']) == 7
commands = [
    {'command': 'zsh -lc: UV_PROJECT_ENVIRONMENT=/tmp/plato-llm-integration/tooling-313 uv sync --locked --python 3.13 --no-default-groups --group dev --group build --group docs',
     'exit_code': 0, 'result': 'Own isolated Python 3.13.16 tooling environment provisioned from unchanged locked inputs.',
     'log': fingerprint(SCRATCH / 'sync-tooling.log')},
    {'command': 'zsh -lc: /tmp/plato-llm-integration/tooling-313/bin/ruff check . --select I',
     'exit_code': 0, 'result': 'All checks passed!',
     'log': fingerprint(SCRATCH / 'ruff.log')},
    {'command': 'zsh -lc: uv build --no-build-isolation --python /tmp/plato-llm-integration/tooling-313/bin/python --sdist --wheel --out-dir /tmp/plato-llm-integration/checks/dist',
     'exit_code': 0, 'result': 'Wheel and sdist built; no archives/retired, external/nanochat or retired runtime modules.',
     'log': fingerprint(SCRATCH / 'build.log')},
    {'command': 'zsh -lc: uv lock --check --python 3.13',
     'exit_code': 0, 'result': 'Resolved 268 packages; lock current.',
     'log': fingerprint(SCRATCH / 'lock-check.log')},
    {'command': 'zsh -lc: PYTHONDONTWRITEBYTECODE=1 /tmp/plato-llm-integration/tooling-313/bin/python /tmp/plato-llm-integration/checks/verify_integration.py',
     'exit_code': 0, 'result': 'Exact collection ledger, CI preservation/helper fixture, immutable archive bytes, distribution boundaries and unchanged source/index verified.',
     'log': fingerprint(SCRATCH / 'bounded-checks.log')},
    {'command': 'zsh -lc: git diff --cached --check',
     'exit_code': 0, 'result': 'Staged diff whitespace check passed before releasing the source hold.'},
]
for run in typing['runs']:
    commands.append({**run, 'log': fingerprint(run['log']),
                     'result': ('All checks passed!' if run['exit_code'] == 0
                                else 'Classified full-project baseline; normal diagnostic exit 1.')})
commands.append({**typing['exact_workflow_guard'],
                 'result': 'Exact embedded current CI type guard passed.',
                 'log': fingerprint(SCRATCH / 'workflow-type-guard.log')})
collections = []
for profile in ['mandatory', 'base']:
    directory = PROFILE / f'run-{profile}'
    receipt = json.loads((directory / 'receipt.json').read_text())
    collection = next(run for run in receipt['results'] if run['label'] == 'collection')
    assert collection['returncode'] == 0
    assert not receipt['tracked_source_changes']
    assert not any(record['sha256'] != json.loads((directory / 'source-before.json').read_text())[path]
                   for path, record in sources.items())
    collections.append({**collection, 'performed_by': 'Root integration runner; independent node-set analysis here.',
                        'profile': profile,
                        'collection_log': fingerprint(directory / 'collection.log'),
                        'source_before': fingerprint(directory / 'source-before.json'),
                        'runner_receipt': fingerprint(directory / 'receipt.json')})
immutable_new = [record for record in bounded['archives']['file_fingerprints']
                 if record['path'].startswith('archives/retired/')]
assert len(immutable_new) == 73
out = {
    'schema_version': 1,
    'review_type': 'Independent preliminary read-only combined integration qualification',
    'reviewer': '/root/llm_integration_checks',
    'completed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'decision': 'PASS_BOUNDED_PRELIMINARY_CHECKS_FINAL_ACCEPTANCE_NOT_CLAIMED',
    'reason_preliminary': 'Root reported fresh Qwen review finding on supplied pre-expanded PEFT models; candidate correction and final combined suites remain required.',
    'repository_worktree': str(ROOT),
    'root_head': bounded['head'],
    'reviewed_qwen_candidate': 'd3569ec98e64fb83ef43c2b50db4543cfe6a3bc6',
    'staged_tree': 'f3d438addf713e4f24444de4c87e84e98982f6a4',
    'index_entries_sha256': bounded['index_sha256'],
    'source_and_index_preserved_during_owned_checks': bounded['source_and_index_unchanged'],
    'source_hold_released_to_root_after_owned_checks': True,
    'source_fingerprints': fingerprint(SCRATCH / 'source-fingerprints.json'),
    'changed_active_python_fingerprints': {
        path: sources[path] for path in typing['changed_active_files']},
    'ci': bounded['ci'],
    'collections': {**bounded['collection'], 'root_collection_runs': collections,
                    'retirement_removed': 19, 'retirement_added': 24,
                    'original_baseline': 1303, 'retirement_mandatory': 1308,
                    'original_survivors': 1284,
                    'current_base_omissions': 'Exactly the same seven DP nodes as accepted retirement/base profile.'},
    'typing': {key: value for key, value in typing.items() if key != 'runs'},
    'immutable_archives': {
        'new_retirement_immutable_files': len(immutable_new),
        'original_snapshots': 69,
        'total_existing_and_new_archive_files_verified': bounded['archives']['immutable_files_verified'],
        'exact_accepted_retirement_commit': bounded['archives']['retirement_commit'],
        'all_immutable_payloads_match_accepted_retirement_bytes': True,
        'new_readme_migration_prose': 'Separately reviewed; excluded only the two top-level retirement README documents from immutable comparison.',
        'fingerprints': immutable_new},
    'distributions': bounded['distributions'],
    'existing_followups': [{
        'area': 'Legacy archive source distribution contents',
        'assessment': 'Existing packaging boundary, outside this retirement change.',
        'files': 19,
        'paths': 'archives/legacy_datalib and archives/legacy_rl_env',
        'byte_identical_to_root_head': True,
        'wheel_contents': 'No archive paths.',
        'accepted_requirement': 'New archives/retired and retired runtime modules excluded from both distributions.'}],
    'commands': commands,
    'artifacts': {name: fingerprint(SCRATCH / name) for name in [
        'verify_integration.py', 'check_typing.py', 'write_report.py',
        'bounded-checks.json', 'typing-classification.json', 'collection-ledger.json',
        'workflow-type-guard.py', 'index-snapshot.bin']},
    'limitations': [
        'This receipt applies only to the fingerprinted preliminary d356 candidate and staged tree, before the separately reviewed Qwen correction and final docs addendum.',
        'Root interrupted preliminary full suites after a reviewer finding. Their complete suite acceptance is not claimed; collection completed successfully.',
        'No Linux execution, Python 3.14 qualification, final docs build, pretrained Qwen execution, benchmark, convergence or full optimizer-resume claim is made here.',
        'Full typing retains 657 existing diagnostics; zero new signatures, seven removed signatures and clean changed active sources are confirmed. This is not a zero-diagnostic whole-repository gate.',
        'Type comparison used exact root HEAD with unchanged initialized/pinned vision-submodule snapshots, under the same candidate dependency environment; retired-only dependencies were not installed.',
        'No repository source/index edits, commits, nested agents or remote writes performed. Git write-tree produced a tree object only; source/index bytes remained unchanged during the checks.',
        'Author/reviewer raw upstream provenance is reused from accepted retirement review; this check reconfirms exact integrated immutable archive bytes rather than repeating every upstream Git/tar proof.',
        'Source tree was released to root for the correction after bounded checks; the final report uses preserved source manifests and logs rather than asserting the currently mutable worktree still equals this candidate.'
    ]
}
path = SCRATCH / 'preliminary-integration-validation.json'
path.write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'receipt': fingerprint(path), 'decision': out['decision'],
                  'mandatory_cases': 1332, 'base_cases': 1325,
                  'typing_baseline': 664, 'typing_candidate': 657,
                  'new_typing_signatures': 0, 'changed_active_typing_diagnostics': 0,
                  'immutable_retirement_files': 73}, indent=2))
