"""Bind the final staged integration tree without changing Git or source files."""

import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/tmp/plato-refresh-worktrees/llm-integrated')
SCRATCH = Path('/tmp/plato-llm-integration/checks/final')
BEFORE = 'f3d438addf713e4f24444de4c87e84e98982f6a4'
FINAL = 'd230cd65244b4e8fc030778ad02c8760615f863f'
SCRATCH.mkdir(exist_ok=True)


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


def entries(tree):
    result = {}
    for entry in git('ls-tree', '-rz', tree).split(b'\0'):
        if not entry:
            continue
        fields, path = entry.split(b'\t', 1)
        mode, kind, oid = fields.decode().split()
        result[path.decode()] = {'mode': mode, 'kind': kind, 'oid': oid}
    return result


index = git('ls-files', '--stage', '-z')
indexed = {}
for entry in index.split(b'\0'):
    if not entry:
        continue
    fields, path = entry.split(b'\t', 1)
    mode, oid, stage = fields.decode().split()
    assert stage == '0'
    indexed[path.decode()] = {'mode': mode, 'oid': oid}
final_entries = entries(FINAL)
assert indexed == {path: {k: record[k] for k in ['mode', 'oid']}
                   for path, record in final_entries.items()}
before_entries = entries(BEFORE)
changes = {path: {'before': before_entries.get(path), 'after': final_entries.get(path)}
           for path in before_entries.keys() | final_entries.keys()
           if before_entries.get(path) != final_entries.get(path)}
expected = {
    'plato/trainers/huggingface.py': 'bca1f6ec3541090dccb838197206fee2d6412516',
    'tests/integration/test_qwen3_lora.py': 'bca1f6ec3541090dccb838197206fee2d6412516',
    'evidence/2026-refresh/qwen-reference-expanded-embeddings-validation.json': 'bca1f6ec3541090dccb838197206fee2d6412516',
    'docs/docs/examples/case-studies/6. Qwen3 Federated LoRA.md': 'fd4a2bcfa0eb3a57fa015281a156e893d95e9484',
    'evidence/2026-refresh/llm-retirement-docs-cli-addendum.json': '39f58144ffe5aa7ba4b940f76c984f991f93d6ab',
    'evidence/2026-refresh/llm-retirement-docs-final-binding.json': 'fd4a2bcfa0eb3a57fa015281a156e893d95e9484',
}
assert changes.keys() == expected.keys()
for path, owner in expected.items():
    assert final_entries[path] == entries(owner)[path], path
    changes[path]['exact_owner_commit'] = owner
sources = {}
submodules = {}
for path, record in final_entries.items():
    file = ROOT / path
    if record['kind'] == 'commit':
        actual = subprocess.check_output(['git', '-C', str(file), 'rev-parse', 'HEAD']).decode().strip()
        assert actual == record['oid']
        assert not subprocess.check_output(['git', '-C', str(file), 'status', '--porcelain=v1'])
        submodules[path] = {'pin': actual, 'clean': True}
        continue
    data = str(file.readlink()).encode() if record['mode'] == '120000' else file.read_bytes()
    blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    assert blob == record['oid'], path
    sources[path] = {**record, 'bytes': len(data), 'sha256': sha(data)}
previous = json.loads(Path('/tmp/plato-llm-integration/checks/source-fingerprints.json').read_text())
reuse = []
for path, record in previous.items():
    if path in changes:
        continue
    assert sources[path]['sha256'] == record['sha256'], path
    reuse.append(path)
assert not git('diff', '--name-only')
(SCRATCH / 'index-before.bin').write_bytes(index)
(SCRATCH / 'source-before.json').write_text(json.dumps(sources, indent=2) + '\n')
out = {'staged_tree': FINAL, 'previous_staged_tree': BEFORE,
       'index_exactly_matches_declared_tree': True, 'working_bytes_match_index': True,
       'index_sha256': sha(index), 'source_file_count': len(sources),
       'source_manifest_sha256': sha((SCRATCH / 'source-before.json').read_bytes()),
       'delta': changes, 'unchanged_source_files_verified': len(reuse),
       'submodules': submodules,
       'reused_ci_lock_archives_build_settings': [path for path in reuse
           if path in {'uv.lock', 'pyproject.toml', '.github/workflows/pytorch_tests.yml',
                       '.github/scripts/stage_ci_artifacts.py', '.gitattributes', '.gitmodules'}
           or path.startswith('archives/')]}
(SCRATCH / 'snapshot.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({key: value for key, value in out.items()
                 if key not in {'delta', 'reused_ci_lock_archives_build_settings'}}, indent=2))
