"""Read-only preliminary integration verification; scratch output only."""

import hashlib
import importlib.util
import io
import json
import re
import shutil
import subprocess
import tarfile
import zipfile
from pathlib import Path

import yaml

ROOT = Path('/tmp/plato-refresh-worktrees/llm-integrated')
SCRATCH = Path('/tmp/plato-llm-integration/checks')
RETIREMENT = '321c5311ac3f4bd4c92e398c73b5a9d5d8b53ad4'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def fingerprint(path):
    path = Path(path)
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': sha(path.read_bytes())}


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


def nodes(path):
    return {line for line in path.read_text().splitlines()
            if line.startswith('tests/') and '::' in line}


changed = git('diff', '--cached', '--name-only', '--diff-filter=AM').decode().splitlines()
active_python = [p for p in changed if p.endswith('.py')
                 and not p.startswith('archives/')]
tracked = git('ls-files', '-z').decode().split('\0')
source_fingerprints = {p: fingerprint(ROOT / p) for p in tracked
                       if p and (ROOT / p).is_file()
                       and not p.startswith('evidence/')}
(SCRATCH / 'source-fingerprints.json').write_text(
    json.dumps(source_fingerprints, indent=2) + '\n')
(SCRATCH / 'active-python-paths.json').write_text(
    json.dumps(active_python, indent=2) + '\n')
start_index = git('ls-files', '--stage', '-z')
(SCRATCH / 'index-snapshot.bin').write_bytes(start_index)
out = {'status': 'PRELIMINARY_BOUNDED_CHECKS',
       'head': git('rev-parse', 'HEAD').decode().strip(),
       'index_sha256': sha(start_index),
       'source_fingerprints': fingerprint(SCRATCH / 'source-fingerprints.json')}

# Full node-set ledger using already recorded, immutable collection logs.
receipt = json.loads((ROOT / 'evidence/2026-refresh/llm-retirement-validation.json').read_text())
baseline_path = Path(receipt['logs']['before-collection']['path'])
assert sha(baseline_path.read_bytes()) == receipt['logs']['before-collection']['sha256']
baseline = nodes(baseline_path)
retired_mandatory_path = Path('/tmp/plato-retirement-review/collection-mandatory.log')
retired_base_path = Path('/tmp/plato-retirement-review/collection-base.log')
retired_mandatory = nodes(retired_mandatory_path)
retired_base = nodes(retired_base_path)
review = json.loads(Path('/tmp/plato-retirement-review/review.json').read_text())
for name, path in [('collection-mandatory.log', retired_mandatory_path),
                   ('collection-base.log', retired_base_path)]:
    assert sha(path.read_bytes()) == review['independent_artifacts'][name]['sha256']
current_dir = Path('/tmp/plato-llm-integration/preliminary-d3569ec')
mandatory_path = current_dir / 'run-mandatory/collection.log'
base_path = current_dir / 'run-base/collection.log'
mandatory, base = nodes(mandatory_path), nodes(base_path)
qwen_receipt_path = ROOT / 'evidence/2026-refresh/qwen-reference-validation.json'
qwen = json.loads(qwen_receipt_path.read_text())
qwen_ledger = qwen['focused_tests']['collection_ledger'] if 'focused_tests' in qwen else next(
    value['collection_ledger'] for value in qwen.values()
    if isinstance(value, dict) and 'collection_ledger' in value)
qwen_nodes = set(qwen_ledger['nodes'])
assert (len(baseline), len(retired_mandatory), len(retired_base), len(mandatory), len(base)) == (
    1303, 1308, 1301, 1332, 1325)
assert sorted(baseline - retired_mandatory) == sorted(receipt['collection_ledger']['removed'])
assert sorted(retired_mandatory - baseline) == sorted(receipt['collection_ledger']['added'])
assert len(qwen_nodes) == 24
assert mandatory - retired_mandatory == base - retired_base == qwen_nodes
assert not retired_mandatory - mandatory and not retired_base - base
assert mandatory - base == retired_mandatory - retired_base
assert not base - mandatory
assert not any('archives/' in n for n in mandatory | base)
ledger = {'baseline': 1303, 'retirement_mandatory': 1308,
          'retirement_base': 1301, 'preliminary_qwen_mandatory': 1332,
          'preliminary_qwen_base': 1325, 'retirement_removed': sorted(baseline - retired_mandatory),
          'retirement_added': sorted(retired_mandatory - baseline),
          'qwen_added': sorted(qwen_nodes), 'qwen_removed': [],
          'base_omissions': sorted(mandatory - base),
          'log_fingerprints': [fingerprint(p) for p in [baseline_path,
              retired_mandatory_path, retired_base_path, mandatory_path, base_path]],
          'exact_node_identity_ledger_verified': True}
(SCRATCH / 'collection-ledger.json').write_text(json.dumps(ledger, indent=2) + '\n')
out['collection'] = {'mandatory': len(mandatory), 'base': len(base),
                     'qwen_added': len(qwen_nodes), 'qwen_removed': 0,
                     'exact_ledger_verified': True,
                     'receipt': fingerprint(SCRATCH / 'collection-ledger.json')}

# Retain root CI features, with only the reviewed retirement owner replacement.
workflow_path = '.github/workflows/pytorch_tests.yml'
workflow = (ROOT / workflow_path).read_text()
before = git('show', f'HEAD:{workflow_path}').decode()
assert workflow == before.replace('"tests/test_nanochat_integration.py",',
    '"tests/test_retired_backends.py", "plato/utils/retired_backends.py",')
jobs = yaml.safe_load(workflow)['jobs']
matrix = jobs['PyTorch-Tests']['strategy']['matrix']['include']
assert matrix == [{'python': '3.13', 'profile': 'supported-default'}]
assert jobs['PyTorch-Tests']['defaults']['run']['shell'] == 'zsh -lc ". {0}"'
steps = jobs['PyTorch-Tests']['steps']
staging = next(step for step in steps if step['name'].startswith('Stage qualification'))
assert staging['if'] == 'always()'
assert 'python .github/scripts/stage_ci_artifacts.py' in staging['run']
assert '--require-complete' in staging['run']
assert next(step for step in steps if step['name'].startswith('Upload qualification'))['with']['path'] == 'ci-artifacts-upload/'
helper_path = '.github/scripts/stage_ci_artifacts.py'
assert (ROOT / helper_path).read_bytes() == git('show', f'HEAD:{helper_path}')
spec = importlib.util.spec_from_file_location('stage_ci_artifacts', ROOT / helper_path)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
source = SCRATCH / 'staging-fixture-source'
for fixture in [source, SCRATCH / 'staging-fixture-output']:
    if fixture.exists():
        shutil.rmtree(fixture)
source.mkdir()
for name in helper.EXPECTED_RECORDS:
    (source / name).write_text(name + '\n')
unit = source / 'base-tmp'
unit.mkdir()
(unit / 'small.log').write_text('unit diagnostic\n')
(unit / 'fixture.bin').write_bytes(b'fixture')
(unit / 'oversized.log').write_bytes(b'x' * (helper.DIAGNOSTIC_LIMIT + 1))
(unit / 'alias').symlink_to(source, target_is_directory=True)
runtime = source / 'runtime-tmp'
runtime.mkdir()
(runtime / 'payload.bin').write_bytes(b'x' * (helper.DIAGNOSTIC_LIMIT + 1))
manifest = helper.stage_artifacts(source, SCRATCH / 'staging-fixture-output')
included = {e['path'] for e in manifest['included']}
assert not manifest['missing_expected_records'] and not manifest['read_issues']
assert {'base-tmp/small.log', 'runtime-tmp/payload.bin'} <= included
assert not {'base-tmp/fixture.bin', 'base-tmp/oversized.log', 'base-tmp/alias'} & included
assert {e['reason'] for e in manifest['omitted']} == {
    'reproducible_unit_fixture', 'unit_diagnostic_exceeds_size_limit', 'symlink_not_followed'}
out['ci'] = {'matrix': matrix, 'workflow_change_exactly_retirement_owned': True,
             'helper_identical_to_root_head': True,
             'fixture_regular_diagnostics_retained': True,
             'fixture_unit_payload_limits_and_symlink_exclusions': True,
             'fixture_runtime_payload_retained': True,
             'workflow': fingerprint(ROOT / workflow_path),
             'helper': fingerprint(ROOT / helper_path),
             'staging_manifest': fingerprint(SCRATCH / 'staging-fixture-output/artifact-selection.json')}

# Immutable archives must still match accepted retirement bytes. README prose is
# separately authorized migration documentation, so compare all other payloads.
archives = []
for path in tracked:
    if not path.startswith('archives/') or path in {
        'archives/retired/nanochat/README.md',
        'archives/retired/lerobot/README.md',
    }:
        continue
    data = (ROOT / path).read_bytes()
    assert data == git('show', f'{RETIREMENT}:{path}'), path
    archives.append({'path': path, 'sha256': sha(data)})
out['archives'] = {'immutable_files_verified': len(archives),
                   'all_match_accepted_retirement_commit': True,
                   'retirement_commit': RETIREMENT,
                   'readme_prose_reviewed_separately': True,
                   'file_fingerprints': archives}

# Distribution paths must exclude archives and all retired runtime payloads.
retired_paths = {'plato/datasources/lerobot.py', 'plato/datasources/nanochat.py',
    'plato/evaluators/nanochat_core.py', 'plato/models/nanochat.py',
    'plato/models/smolvla.py', 'plato/processors/nanochat_tokenizer.py',
    'plato/trainers/lerobot.py', 'plato/trainers/nanochat.py',
    'plato/utils/third_party.py'}
distributions = {}
for path in sorted((SCRATCH / 'dist').glob('*')):
    if path.suffix == '.whl':
        with zipfile.ZipFile(path) as archive:
            names = archive.namelist()
        normalized = names
    elif path.name.endswith('.tar.gz'):
        with tarfile.open(path) as archive:
            names = archive.getnames()
        normalized = [name.partition('/')[2] for name in names]
    else:
        continue
    unwanted = [name for name in normalized if name.startswith('archives/retired/')
                or name.startswith('external/nanochat') or name in retired_paths]
    assert not unwanted, unwanted
    assert 'plato/utils/retired_backends.py' in normalized
    assert 'plato/utils/huggingface.py' in normalized
    legacy_archives = [name for name in normalized if name.startswith('archives/')]
    if legacy_archives:
        with tarfile.open(path) as archive:
            by_path = {member.name.partition('/')[2]: member
                       for member in archive.getmembers() if member.isfile()}
            for name in legacy_archives:
                assert archive.extractfile(by_path[name]).read() == git('show', f'HEAD:{name}'), name
    distributions[path.name] = {**fingerprint(path), 'entries': len(names),
                               'retired_or_retirement_archive_payloads': unwanted,
                               'pre_existing_legacy_archive_paths': legacy_archives,
                               'legacy_archives_byte_identical_to_root_head': True}
assert len(distributions) == 2
out['distributions'] = distributions

# Copy root HEAD outside the worktree to compare pre-existing type diagnostics.
baseline_source = SCRATCH / 'typing-baseline-source'
baseline_source.mkdir()
with tarfile.open(fileobj=io.BytesIO(git('archive', 'HEAD'))) as archive:
    archive.extractall(baseline_source, filter='data')
out['typing_baseline_source'] = str(baseline_source)
assert git('ls-files', '--stage', '-z') == start_index
for path, record in source_fingerprints.items():
    assert sha((ROOT / path).read_bytes()) == record['sha256'], path
out['source_and_index_unchanged'] = True
(SCRATCH / 'bounded-checks.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({k: v for k, v in out.items()
                 if k not in {'archives', 'distributions'}}, indent=2))
