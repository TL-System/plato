"""Verify final bounded integration and bind rebuilt distribution payloads."""

from collections import Counter
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
import zipfile

ROOT = Path('/tmp/plato-refresh-worktrees/llm-integrated')
SCRATCH = Path('/tmp/plato-llm-integration/checks')
FINAL = SCRATCH / 'final'
SNAPSHOT = json.loads((FINAL / 'snapshot.json').read_text())
SOURCES = json.loads((FINAL / 'source-before.json').read_text())
PREVIOUS = json.loads((SCRATCH / 'preliminary-integration-validation.json').read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def fingerprint(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


def nodes(path):
    return {line for line in path.read_text().splitlines()
            if line.startswith('tests/') and '::' in line}


# Exact final collection delta, bound to the root runner source manifests.
previous_ledger = json.loads((SCRATCH / 'collection-ledger.json').read_text())
expected_added = {'tests/integration/test_qwen3_lora.py::test_supplied_preexpanded_peft_model_preserves_embedding_snapshots_and_logits'}
collections = {}
for profile, expected_count in [('mandatory', 1333), ('base', 1326)]:
    current_dir = Path('/tmp/plato-llm-integration') / f'run-{profile}'
    previous_dir = Path('/tmp/plato-llm-integration/preliminary-d3569ec') / f'run-{profile}'
    current = nodes(current_dir / 'collection.log')
    previous = nodes(previous_dir / 'collection.log')
    assert len(current) == expected_count
    assert current - previous == expected_added and not previous - current
    manifest = json.loads((current_dir / 'source-before.json').read_text())
    assert manifest.keys() == SOURCES.keys()
    assert all(manifest[path] == record['sha256'] for path, record in SOURCES.items())
    collections[profile] = {'count': len(current), 'added': sorted(current - previous),
        'removed': [], 'collection_log': fingerprint(current_dir / 'collection.log'),
        'root_runner_source_manifest': fingerprint(current_dir / 'source-before.json'),
        'source_manifest_matches_this_exact_staged_tree': True}
mandatory = nodes(Path(collections['mandatory']['collection_log']['path']))
base = nodes(Path(collections['base']['collection_log']['path']))
assert sorted(mandatory - base) == previous_ledger['base_omissions']
assert not base - mandatory
assert not any('archives/' in node for node in mandatory | base)
ledger = {'baseline': 1303, 'retirement': 1308, 'initial_qwen': 1332,
    'final_mandatory': 1333, 'final_base': 1326,
    'retirement_removed': previous_ledger['retirement_removed'],
    'retirement_added': previous_ledger['retirement_added'],
    'initial_qwen_added': previous_ledger['qwen_added'],
    'correction_added': sorted(expected_added), 'correction_removed': [],
    'base_omissions': previous_ledger['base_omissions'],
    'collections': collections, 'exact_node_set_verified': True}
(FINAL / 'collection-ledger.json').write_text(json.dumps(ledger, indent=2) + '\n')

# Fresh full output remains exactly the preserved 657-diagnostic baseline.
full_log = FINAL / 'ty-full.log'
assert full_log.read_bytes() == (SCRATCH / 'ty-full.log').read_bytes()
assert (FINAL / 'ty-delta.log').read_text().strip() == 'All checks passed!'
assert (FINAL / 'ruff.log').read_text().strip() == 'All checks passed!'
pattern = r'^(.+?):(\d+):(\d+): (error|warning)\[([^]]+)\] (.*)$'
matches = list(re.finditer(pattern, full_log.read_text(), re.M))
assert len(matches) == 657
owned = json.loads((SCRATCH / 'active-python-paths.json').read_text())
assert not [match[0] for match in matches if match[1] in owned]
guard = SCRATCH / 'workflow-type-guard.py'
artifact_dir = FINAL / 'ci-artifacts'
artifact_dir.mkdir(exist_ok=True)
(artifact_dir / 'ty.log').write_bytes(full_log.read_bytes())
guard_command = ['/tmp/plato-llm-integration/tooling-313/bin/python', str(guard), '1']
process = subprocess.run(guard_command, cwd=FINAL, text=True, capture_output=True)
(FINAL / 'workflow-type-guard.log').write_text(process.stdout + process.stderr)
assert process.returncode == 0, process.stdout + process.stderr

# Inspect every package source payload, not only the exclusion patterns.
retired = {'plato/datasources/lerobot.py', 'plato/datasources/nanochat.py',
    'plato/evaluators/nanochat_core.py', 'plato/models/nanochat.py',
    'plato/models/smolvla.py', 'plato/processors/nanochat_tokenizer.py',
    'plato/trainers/lerobot.py', 'plato/trainers/nanochat.py',
    'plato/utils/third_party.py'}
distributions = {}
for path in sorted((FINAL / 'dist').glob('*')):
    payloads = {}
    if path.suffix == '.whl':
        with zipfile.ZipFile(path) as archive:
            for name in archive.namelist():
                if not name.endswith('/'):
                    payloads[name] = archive.read(name)
    elif path.name.endswith('.tar.gz'):
        with tarfile.open(path) as archive:
            for member in archive.getmembers():
                assert member.isdir() or member.isfile()
                assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
                if member.isfile():
                    payloads[member.name.partition('/')[2]] = archive.extractfile(member).read()
    else:
        continue
    unwanted = [name for name in payloads if name.startswith('archives/retired/')
                or name.startswith('external/nanochat') or name in retired]
    assert not unwanted, unwanted
    source_records = []
    generated_records = []
    for name, data in payloads.items():
        source = ROOT / name
        record = {'path': name, 'bytes': len(data), 'sha256': sha(data)}
        if source.is_file():
            assert data == source.read_bytes(), name
            source_records.append(record)
        else:
            generated_records.append(record)
    assert 'plato/trainers/huggingface.py' in payloads
    assert sha(payloads['plato/trainers/huggingface.py']) == SOURCES['plato/trainers/huggingface.py']['sha256']
    if path.suffix != '.whl':
        for changed in SNAPSHOT['delta']:
            assert changed in payloads and sha(payloads[changed]) == SOURCES[changed]['sha256'], changed
    legacy = [name for name in payloads if name.startswith('archives/')]
    assert legacy == PREVIOUS['distributions'][path.name]['pre_existing_legacy_archive_paths']
    listing = FINAL / (path.name + '.contents.json')
    listing.write_text(json.dumps({'source_payloads': source_records,
                                  'generated_metadata_payloads': generated_records}, indent=2) + '\n')
    distributions[path.name] = {**fingerprint(path), 'regular_files': len(payloads),
        'source_payloads_verified_against_final_worktree': len(source_records),
        'generated_metadata_payloads': generated_records,
        'contents_manifest': fingerprint(listing),
        'retired_and_retirement_archive_payloads': unwanted,
        'legacy_archive_paths': legacy, 'legacy_archive_bytes_unchanged': True,
        'final_trainer_payload_sha256': sha(payloads['plato/trainers/huggingface.py'])}
assert len(distributions) == 2

# Prior assertions are valid only for byte-identical inputs in this snapshot.
reused = {}
for name, paths in {
    'lock_check': ['uv.lock', 'pyproject.toml'],
    'ci_matrix_and_staging_helper_probe': ['.github/workflows/pytorch_tests.yml',
        '.github/scripts/stage_ci_artifacts.py'],
    'archive_exclusions_and_identity': ['pyproject.toml', '.gitattributes', '.gitmodules',
        *[p for p in SOURCES if p.startswith('archives/')]],
}.items():
    prior_sources = json.loads((SCRATCH / 'source-fingerprints.json').read_text())
    assert all(SOURCES[path]['sha256'] == prior_sources[path]['sha256'] for path in paths)
    reused[name] = {'all_inputs_byte_identical_to_previous_receipt': True,
                   'input_fingerprints': {path: SOURCES[path]['sha256'] for path in paths}}

# Final immutability check covers every tracked regular file and both submodules.
assert git('ls-files', '--stage', '-z') == (FINAL / 'index-before.bin').read_bytes()
assert not git('diff', '--name-only')
for path, record in SOURCES.items():
    source = ROOT / path
    data = str(source.readlink()).encode() if record['mode'] == '120000' else source.read_bytes()
    assert sha(data) == record['sha256'], path
for path, record in SNAPSHOT['submodules'].items():
    assert subprocess.check_output(['git', '-C', str(ROOT / path),
                                    'rev-parse', 'HEAD']).decode().strip() == record['pin']
    assert not subprocess.check_output(['git', '-C', str(ROOT / path), 'status', '--porcelain=v1'])

commands = [
    {'command': 'zsh -lc: PYTHONDONTWRITEBYTECODE=1 /tmp/plato-llm-integration/tooling-313/bin/python /tmp/plato-llm-integration/checks/final_snapshot.py',
     'exit_code': 0, 'result': 'Exact staged tree/index/source and six owner-commit deltas verified.'},
    {'command': 'zsh -lc: /tmp/plato-llm-integration/tooling-313/bin/ruff check . --select I',
     'exit_code': 0, 'result': 'All checks passed!', 'log': fingerprint(FINAL / 'ruff.log')},
    {'command': 'zsh -lc: PYTHONDONTWRITEBYTECODE=1 /tmp/plato-llm-integration/tooling-313/bin/ty check --python /tmp/plato-llm-integration/tooling-313/bin/python --output-format concise',
     'exit_code': 1, 'result': '657 existing diagnostics; output byte-identical to preliminary log; all 28 changed active files remain clean.',
     'log': fingerprint(full_log)},
    {'command': 'zsh -lc: PYTHONDONTWRITEBYTECODE=1 /tmp/plato-llm-integration/tooling-313/bin/ty check --python /tmp/plato-llm-integration/tooling-313/bin/python --output-format concise plato/trainers/huggingface.py tests/integration/test_qwen3_lora.py',
     'exit_code': 0, 'result': 'Both correction Python files pass scoped typing.',
     'log': fingerprint(FINAL / 'ty-delta.log')},
    {'command': guard_command, 'cwd': str(FINAL), 'exit_code': process.returncode,
     'result': 'Exact unchanged embedded CI type guard passes fresh final output.',
     'log': fingerprint(FINAL / 'workflow-type-guard.log')},
    {'command': 'zsh -lc: uv build --no-build-isolation --python /tmp/plato-llm-integration/tooling-313/bin/python --sdist --wheel --out-dir /tmp/plato-llm-integration/checks/final/dist',
     'exit_code': 0, 'result': 'Final wheel and sdist built; every source payload verified against final source.',
     'log': fingerprint(FINAL / 'build.log')},
    {'command': 'zsh -lc: git diff --cached --check',
     'exit_code': 0, 'result': 'Final staged whitespace check passed.'},
    {'command': 'zsh -lc: PYTHONDONTWRITEBYTECODE=1 /tmp/plato-llm-integration/tooling-313/bin/python /tmp/plato-llm-integration/checks/write_final_report.py',
     'exit_code': 0, 'result': 'Final exact ledger, fresh typing guard, package content binding, evidence reuse and source/index preservation verified.'},
]
out = {
    'schema_version': 1, 'review_type': 'Independent bounded final combined integration qualification',
    'reviewer': '/root/llm_integration_checks',
    'completed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'decision': 'ACCEPT_BOUNDED_FINAL_INTEGRATION_CHECKS',
    'repository_worktree': str(ROOT), 'staged_tree': SNAPSHOT['staged_tree'],
    'previous_receipt': fingerprint(SCRATCH / 'preliminary-integration-validation.json'),
    'exact_delta': SNAPSHOT['delta'], 'exact_owner_commit_bytes_verified': True,
    'index_exactly_matches_declared_tree': True,
    'index_entries_sha256': SNAPSHOT['index_sha256'],
    'tracked_source_and_index_unchanged_during_all_owned_checks': True,
    'final_source_manifest': fingerprint(FINAL / 'source-before.json'),
    'final_source_fingerprints': {path: SOURCES[path] for path in SNAPSHOT['delta']},
    'ci': {'python_matrix': PREVIOUS['ci']['matrix'], 'matrix_and_helper_byte_unchanged': True,
           'prior_helper_behavior_probe_reused': True, 'fresh_existing_type_guard_passed': True},
    'typing': {'baseline_root_initialized': 664, 'preliminary': 657, 'final': 657,
        'new_diagnostic_signatures_vs_preliminary': 0, 'new_diagnostic_signatures_vs_root': 0,
        'final_output_byte_identical_to_preliminary': True,
        'all_28_changed_active_python_files_have_zero_full_diagnostics': True,
        'both_delta_python_files_have_zero_scoped_diagnostics': True,
        'fresh_ci_guard_exit_code': 0},
    'collection': {'baseline': 1303, 'retirement': 1308, 'initial_qwen': 1332,
        'final_mandatory': 1333, 'final_base': 1326, 'correction_added': sorted(expected_added),
        'correction_removed': [], 'base_omissions': previous_ledger['base_omissions'],
        'exact_node_set_and_source_binding_verified': True,
        'ledger': fingerprint(FINAL / 'collection-ledger.json')},
    'reused_evidence': reused,
    'distributions': distributions,
    'unresolved_findings_in_owned_bounded_scope': [],
    'existing_packaging_followup': PREVIOUS['existing_followups'],
    'commands': commands,
    'artifacts': {name: fingerprint(path) for name, path in {
        'snapshot': FINAL / 'snapshot.json', 'snapshot_script': SCRATCH / 'final_snapshot.py',
        'verification_script': SCRATCH / 'write_final_report.py',
        'previous_typing_classification': SCRATCH / 'typing-classification.json',
        'ci_guard_source': guard}.items()},
    'limits': [
        'Acceptance covers only the bounded integration checks on staged tree d230cd65244b4e8fc030778ad02c8760615f863f; it does not claim full-suite or hosted-CI results.',
        'Root owns concurrently running complete base/mandatory suites; this receipt independently analyzes completed collection logs and exact source manifests only.',
        'Fresh code and documentation reviewers independently own behavioral correction and final prose acceptance.',
        'No Linux runtime, Python 3.14, final docs build, real pretrained-model execution, convergence or full optimizer-resume qualification is claimed here.',
        'Lock, CI-helper behavior and immutable archive provenance are reused only after explicit byte equality; their full probes were not gratuitously rerun.',
        'Nineteen pre-existing legacy archive files remain in the source distribution with unchanged bytes; the new retirement archive and retired runtime modules are absent from both distributions.',
        'No source/index edits, commits, nested agents or remote writes were performed; only reviewer-owned scratch scripts, reports and artifacts were created.'
    ]
}
path = SCRATCH / 'final-integration-checks.json'
path.write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'receipt': fingerprint(path), 'decision': out['decision'],
                  'staged_tree': out['staged_tree'], 'mandatory_cases': 1333,
                  'base_cases': 1326, 'typing_diagnostics': 657,
                  'new_typing_signatures': 0,
                  'distribution_fingerprints': {name: {key: record[key] for key in
                      ['path', 'bytes', 'sha256', 'regular_files']} for name, record in distributions.items()}}, indent=2))
