"""Classify staged integration type diagnostics against exact root HEAD."""

from collections import Counter
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile
import textwrap

ROOT = Path('/tmp/plato-refresh-worktrees/llm-integrated')
SCRATCH = Path('/tmp/plato-llm-integration/checks')
TOOLING = Path('/tmp/plato-llm-integration/tooling-313/bin')
BASELINE = SCRATCH / 'typing-baseline-source'
paths = json.loads((SCRATCH / 'active-python-paths.json').read_text())


def run_type(name, cwd, selected):
    command = [str(TOOLING / 'ty'), 'check', '--python', str(TOOLING / 'python'),
               '--output-format', 'concise', *selected]
    log = SCRATCH / f'ty-{name}.log'
    with log.open('w') as output:
        process = subprocess.run(command, cwd=cwd, stdout=output,
                                 stderr=subprocess.STDOUT)
    return {'command': command, 'cwd': str(cwd), 'exit_code': process.returncode,
            'log': str(log)}


# git archive omits gitlink contents. Supply the exact unchanged pinned vision
# submodule trees so full-project baseline and candidate cover identical files.
submodules = []
for path, pin in [('plato/models/dvit', '1ccb152cea43fcbc3cd517a45c12c65734f8ace3'),
                  ('plato/models/t2tvit', '0f63dc9558f4d192de926504dbddfa1b3f5db6ca')]:
    repository = ROOT / path
    actual = subprocess.check_output(['git', '-C', str(repository),
                                      'rev-parse', 'HEAD']).decode().strip()
    assert actual == pin
    assert not subprocess.check_output(['git', '-C', str(repository),
                                        'status', '--porcelain=v1'])
    destination = BASELINE / path
    destination.mkdir(parents=True, exist_ok=True)
    payload = subprocess.check_output(['git', '-C', str(repository), 'archive', pin])
    with tarfile.open(fileobj=io.BytesIO(payload)) as archive:
        archive.extractall(destination, filter='data')
    submodules.append({'path': path, 'pin': pin,
                       'git_archive_sha256': hashlib.sha256(payload).hexdigest(),
                       'clean_worktree': True})
runs = [run_type('baseline', BASELINE, []),
        {'command': [str(TOOLING / 'ty'), 'check', '--python', str(TOOLING / 'python'),
                     '--output-format', 'concise', *paths],
         'cwd': str(ROOT), 'exit_code': 0,
         'log': str(SCRATCH / 'ty-changed-active.log'),
         'execution_note': 'Preserved initial-snapshot scoped run before source release.'}]


def diagnostics(path):
    log = path.read_text()
    matches = list(re.finditer(
        r'^(.+?):(\d+):(\d+): (error|warning)\[([^]]+)\] (.*)$', log, re.M))
    if not matches:
        assert log.strip() == 'All checks passed!', log
        return []
    report = re.search(r'^Found ([1-9][0-9]*) diagnostics?$', log, re.M)
    assert report is not None and len(matches) == int(report[1]), log
    return [{'path': m[1], 'line': int(m[2]), 'column': int(m[3]),
             'severity': m[4], 'rule': m[5], 'message': m[6]} for m in matches]


baseline = diagnostics(SCRATCH / 'ty-baseline.log')
current = diagnostics(SCRATCH / 'ty-full.log')
scoped = diagnostics(SCRATCH / 'ty-changed-active.log')
baseline_all_signatures = Counter((d['path'], d['severity'], d['rule'], d['message'])
                                  for d in baseline)
current_all_signatures = Counter((d['path'], d['severity'], d['rule'], d['message'])
                                 for d in current)
baseline_signatures = Counter((d['path'], d['severity'], d['rule'], d['message'])
                              for d in baseline)
changed = []
for diagnostic in current:
    if diagnostic['path'] not in paths:
        continue
    signature = (diagnostic['path'], diagnostic['severity'],
                 diagnostic['rule'], diagnostic['message'])
    existing = baseline_signatures[signature] > 0
    if existing:
        baseline_signatures[signature] -= 1
    changed.append({**diagnostic, 'classification':
                    'pre_existing_same_path_rule_and_message' if existing
                    else 'requires_review_new_or_message_changed'})

# Execute the exact embedded workflow guard against the full candidate log.
workflow = (ROOT / '.github/workflows/pytorch_tests.yml').read_text()
match = re.search(r'python - "\$ty_status" <<\'PY\'\n(.*?)\n          PY',
                  workflow, re.S)
assert match
guard_source = textwrap.dedent(match[1]) + '\n'
(SCRATCH / 'workflow-type-guard.py').write_text(guard_source)
guard_dir = SCRATCH / 'ci-artifacts'
guard_dir.mkdir(exist_ok=True)
(guard_dir / 'ty.log').write_bytes((SCRATCH / 'ty-full.log').read_bytes())
command = [str(TOOLING / 'python'), str(SCRATCH / 'workflow-type-guard.py'), '1']
process = subprocess.run(command, cwd=SCRATCH, text=True, capture_output=True)
(SCRATCH / 'workflow-type-guard.log').write_text(process.stdout + process.stderr)
assert process.returncode == 0, process.stdout + process.stderr
qwen_paths = subprocess.check_output([
    'git', '-C', str(ROOT), 'diff-tree', '--no-commit-id', '--name-only', '-r',
    'd3569ec98e64fb83ef43c2b50db4543cfe6a3bc6']).decode().splitlines()
qwen_paths = [p for p in qwen_paths if p.endswith('.py')]
qwen_diagnostics = [d for d in current if d['path'] in qwen_paths]
all_runs = [{'command': [str(TOOLING / 'ty'), 'check', '--python',
              str(TOOLING / 'python'), '--output-format', 'concise'],
             'cwd': str(ROOT), 'exit_code': 1, 'log': str(SCRATCH / 'ty-full.log')},
            *runs]
out = {'full_diagnostics': len(current), 'baseline_diagnostics': len(baseline),
       'initialized_submodule_baseline': submodules,
       'new_full_diagnostic_signatures': list((current_all_signatures - baseline_all_signatures).elements()),
       'removed_full_diagnostic_signatures': list((baseline_all_signatures - current_all_signatures).elements()),
       'changed_active_files': paths,
       'changed_active_diagnostics': changed,
       'changed_active_diagnostic_count': len(changed),
       'changed_active_classifications': dict(Counter(d['classification'] for d in changed)),
       'scoped_diagnostic_count': len(scoped), 'scoped_diagnostics': scoped,
       'qwen_changed_python_files': qwen_paths,
       'qwen_diagnostic_count': len(qwen_diagnostics),
       'qwen_diagnostics': qwen_diagnostics,
       'exact_workflow_guard': {'command': command, 'exit_code': process.returncode,
                               'source_sha256': hashlib.sha256(guard_source.encode()).hexdigest()},
       'runs': all_runs,
       'limits': ['Full repository typing remains a classified baseline, not a zero-diagnostic gate.',
                  'Baseline comparison holds the candidate environment constant; retired-only dependencies remain absent.',
                  'Line numbers may move; existing classification requires identical path, severity, rule and message.']}
(SCRATCH / 'typing-classification.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({key: value for key, value in out.items()
                 if key not in {'changed_active_diagnostics', 'changed_active_files',
                                'scoped_diagnostics', 'qwen_changed_python_files'}}, indent=2))
