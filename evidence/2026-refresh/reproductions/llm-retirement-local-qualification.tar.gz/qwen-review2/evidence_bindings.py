import hashlib
import json
import subprocess
from pathlib import Path
from safetensors import safe_open

repo = Path("/tmp/plato-refresh-worktrees/qwen-reference-review2")
scratch = Path("/tmp/plato-qwen-review2")
original_path = repo / "evidence/2026-refresh/qwen-reference-validation.json"
original = json.loads(original_path.read_text())
correction_path = repo / "evidence/2026-refresh/qwen-reference-expanded-embeddings-validation.json"
correction = json.loads(correction_path.read_text())
current_real = correction["fresh_real_pretrained_qualification"]
snapshot = Path(current_real["result"]["resolved_checkpoint_directory"])

def sha(path):
    with Path(path).open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()

for name, details in original["official_checkpoint_artifacts"].items():
    path = snapshot / name
    assert path.stat().st_size == details["bytes"]
    assert sha(path) == details["sha256"]
config = json.loads((snapshot / "config.json").read_text())
with safe_open(snapshot / "model.safetensors", framework="pt", device="cpu") as handle:
    embeddings_shape = handle.get_slice("model.embed_tokens.weight").get_shape()
assert config["vocab_size"] == embeddings_shape[0] == 151936
assert (embeddings_shape[0] != config["vocab_size"]) is False
assert sha(original_path) == correction["historical_d3569ec_observations"]["original_receipt_sha256"]
assert subprocess.check_output(["git","show","d3569ec98e64fb83ef43c2b50db4543cfe6a3bc6:evidence/2026-refresh/qwen-reference-validation.json"], cwd=repo) == original_path.read_bytes()
cli_log = Path("/tmp/plato-qwen-validation/cli-transport/plato.log")
cli_text = cli_log.read_text()
historical = correction["historical_d3569ec_observations"]["actual_transport_cli"]
assert sha(cli_log) == historical["log_sha256"]
assert cli_text.count("resource_tracker: There appear to be") == 1
assert all(line in cli_text for line in historical["actual_transfer_log_lines"])
assert len(historical["actual_transfer_log_lines"]) == 8
wrapper_path = Path("/tmp/plato-qwen-validation/run_cli_transport.py")
assert sha(wrapper_path) == historical["wrapper_sha256"]
real_log_path = Path("/tmp/plato-qwen-validation/preexpanded-fix-real.log")
assert sha(real_log_path) == current_real["log_sha256"]
for log in (cli_log,real_log_path):
    contents = log.read_text()
    assert "/resolve/main/" not in contents and "/revision/main" not in contents
summary = json.loads((scratch / "evidence-checks.json").read_text())
summary.update({
    "original_receipt_byte_identical_to_d3569ec": True,
    "official_checkpoint_files_match_size_and_sha256": True,
    "official_original_vocabulary": config["vocab_size"],
    "official_pretrained_input_embedding_shape": embeddings_shape,
    "correction_preserve_embeddings_predicate_for_shipped_qwen": False,
    "historical_cli_transfer_lines_verified": 8,
    "historical_cli_visible_semaphore_cleanup_warnings": 1,
    "historical_cli_log_and_wrapper_sha256_verified": True,
    "current_real_qualification_log_sha256_verified": True,
    "current_real_and_historical_cli_logs_have_no_main_revision_paths": True,
    "cli_wrapper_path": str(wrapper_path),
    "current_real_log_path": str(real_log_path),
})
(scratch / "evidence-checks.json").write_text(json.dumps(summary,indent=2)+"\n")
print("Official config/weight hashes verified; ordinary embedding predicate false at vocabulary151936.")
print("Original receipt unchanged; historical CLI8 transfer lines, one visible warning and exact log/wrapper hashes verified.")
