import hashlib
import importlib.metadata
import json
import subprocess
import sys
from pathlib import Path

repo = Path("/tmp/plato-refresh-worktrees/qwen-reference-review2")
scratch = Path("/tmp/plato-qwen-review2")
correction = json.loads((repo / "evidence/2026-refresh/qwen-reference-expanded-embeddings-validation.json").read_text())
probe = json.loads((scratch / "final-probe.json").read_text())
edge = json.loads((scratch / "edges/receipt.json").read_text())
persistence = json.loads((scratch / "persistence/receipt.json").read_text())
evidence = json.loads((scratch / "evidence-checks.json").read_text())

def sha(path):
    with Path(path).open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()

head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
tree = subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], cwd=repo, text=True).strip()
clean = not subprocess.check_output(["git", "status", "--porcelain"], cwd=repo, text=True).strip()
assert head == "bca1f6ec3541090dccb838197206fee2d6412516"
assert tree == "ad54c4f9b3001a5572b16d8e6a998d5a49c4521b"
assert clean
assert all(row["logits_restored"] and row["max_logit_error_after_reload"] == 0 for row in edge)
assert all(row["plato_save_embedding_layers"] and len(row["payload_embedding_keys"]) == 2 and len(row["checkpoint_embedding_keys"]) == 2 for row in edge)
assert len(persistence["variants"]) == 6
assert "25 passed, 10 warnings" in (scratch / "focused-tests.log").read_text()
bindings = {
    "original_d3569ec_validation_receipt": repo / "evidence/2026-refresh/qwen-reference-validation.json",
    "current_expanded_embedding_correction_receipt": repo / "evidence/2026-refresh/qwen-reference-expanded-embeddings-validation.json",
    "original_review_finding": Path("/tmp/plato-qwen-review/qwen-reference-review-d3569ec.json"),
    "original_edge_reproducer": Path("/tmp/plato-qwen-review/edge_cases.py"),
    "independent_current_edge_reproducer": scratch / "edge_cases.py",
    "independent_current_edge_receipt": scratch / "edges/receipt.json",
    "independent_current_edge_log": scratch / "edge-cases.log",
    "original_accumulation_payload_probe": Path("/tmp/plato-qwen-review/independent_probe.py"),
    "independent_current_accumulation_payload_probe": scratch / "independent_probe.py",
    "independent_current_accumulation_payload_receipt": scratch / "final-probe.json",
    "independent_current_accumulation_payload_log": scratch / "final-probe.log",
    "independent_mutation_persistence_probe": scratch / "persistence_probe.py",
    "independent_mutation_persistence_receipt": scratch / "persistence/receipt.json",
    "independent_mutation_persistence_log": scratch / "persistence-probe.log",
    "focused_tests_log": scratch / "focused-tests.log",
    "evidence_checks": scratch / "evidence-checks.json",
    "fresh_real_pretrained_qualification": Path("/tmp/plato-qwen-validation/preexpanded-fix-real/qualification.json"),
    "fresh_real_pretrained_log": Path("/tmp/plato-qwen-validation/preexpanded-fix-real.log"),
    "historical_actual_transport_cli_receipt": Path("/tmp/plato-qwen-validation/cli-transport/cli-result.json"),
    "historical_actual_transport_cli_log": Path("/tmp/plato-qwen-validation/cli-transport/plato.log"),
    "historical_actual_transport_cli_wrapper": Path("/tmp/plato-qwen-validation/run_cli_transport.py"),
}
report = {
    "schema_version": 1,
    "review_type": "Fresh independent read-only final exact-candidate Qwen/HF/PEFT review",
    "reviewer": "/root/qwen_reference_review2",
    "date": "2026-10-03",
    "decision": "ACCEPT",
    "reviewed_commit": head,
    "reviewed_tree": tree,
    "baseline_commit": "9ee92c52307cd3ecdce0c7416708c504bdb52137",
    "first_candidate_commit": "d3569ec98e64fb83ef43c2b50db4543cfe6a3bc6",
    "frozen_checkout": str(repo),
    "checkout_clean_before_and_after_checks": clean,
    "unresolved_findings": {"critical": 0, "high": 0, "medium": 0, "low": 0},
    "findings": [],
    "resolved_findings": [{
        "id": "QWEN-01",
        "prior_severity": "medium",
        "status": "RESOLVED",
        "title": "Supplied pre-expanded PEFT model embedding state now survives federated payloads and checkpoints",
        "source": "plato/trainers/huggingface.py:646",
        "resolution": "Trainer compares actual current embedding size with self.config.vocab_size from its independently loaded exact configured original model revision. This also marks already-resized supplied models, whose own config has already changed. Existing in-Trainer growth remains marked. Neither branch adds a new Hub lookup.",
        "independent_reproduction": edge,
        "actual_new_regression": "tests/integration/test_qwen3_lora.py::test_supplied_preexpanded_peft_model_preserves_embedding_snapshots_and_logits",
        "actual_new_regression_result": "PASS in independent 25-test run, including payload independence, Algorithm load, checkpoint load and exact restored logits.",
    }],
    "verified_passes": [
        "Exact frozen commit/tree remained clean. All 15 source SHA256 entries in the correction receipt match; original historical receipt remains byte-identical to d3569ec and only the two corrected source paths differ from its original hashes.",
        "Original edge reproducer independently rerun against this candidate: both in-Trainer and caller-preexpanded vocabulary 256 to 257 paths include input/output embedding weights in real PEFT payloads and checkpoints and restore logits exactly (maximum error 0). Config reloads forbidden during extraction/export.",
        "Independent 48-case float64 SGD/momentum accumulation oracle passed with maximum parameter error0: steps 1/2/3/4, counts 1/2/3/5/6/7, both last-batch and finalize tail paths. Optimizer counts, pre/post callbacks, scheduler advancement, counter clearing and repeated-finalize idleness all match.",
        "Independent actual PEFT tiny native Qwen3 payload probe passed q/v, saved head, embedding-LoRA and explicit expanded-vocabulary variants. No CPU aliases, changed snapshots, hidden config reloads or payload round-trip errors; required modules/embeddings retained and ordinary frozen base excluded.",
        "Six additional independent actual PEFT mutation-and-reload variants passed: q/v, modules_to_save head, modules_to_save input embedding, embedding-LoRA list target, embedding-LoRA regex target and trainable token indices. Both production payload load and checkpoint load restore logits exactly; malformed checkpoint shapes reject before any active-state mutation.",
        "All 25 focused new tests passed with 10 visible warnings and no skips/xfails/deselections. Includes offline real tiny Qwen/PEFT 2/3 weighted updates through production server aggregation, every-tensor oracle, unchanged frozen base, checkpoints/snapshots, exact artifact revisions and bad-pin failure, dataset cache identity, configured seed and actual HF tail callback/control/scheduler integration.",
        "Source review confirms explicitly configured model/tokenizer revisions flow to every maintained loader and PEFT revision. trust_remote_code=False and supported token/dtype arguments are used. Failures have no retry-main/random fallback. Legacy unspecified revision defaults are explicit in artifact_identity and distinct from failure fallback.",
        "Raw HF dataset cache identity includes explicit dataset revision and resolved local file path plus streaming content SHA256. Pinned/local inputs cannot use legacy unpinned caches.",
        "Configured trainer seed drives actual adapter initialization and client-specific training Torch seed. An independent actual no-seed initialization check preserves incoming RNG variation; configurations without trainer.random_seed are not newly forced to a seed.",
        "Fresh official pretrained qualification JSON and log match committed correction evidence. All reported numerical/hash fields plus client losses exactly equal original qualification. Official cached config/model file sizes and streaming SHA256 match original evidence; original vocabulary and actual checkpoint input embedding header are both 151936.",
        "Historical actual-transport CLI JSON, wrapper and log hashes verified, including all 8 transfer lines, 2.22 MB each direction/client, both comm_simulation=false, exit 0, natural shutdown and no survivors. Exactly one visible resource_tracker semaphore warning remains. It is correctly presented as d3569ec history.",
        "Ordinary Qwen correction predicate is false because current embedding size equals pinned original 151936. Config, transport/checkpoint interfaces and remaining source hashes are unchanged, and fresh real qualification is numerically identical. This supports ordinary behavior equivalence without claiming a fresh CLI rerun."
    ],
    "independent_execution": {
        "python": sys.version,
        "environment": "/tmp/plato-phase2-integration/final-mandatory-313",
        "package_versions": {name: importlib.metadata.version(name) for name in ("torch", "transformers", "peft", "datasets", "huggingface-hub", "safetensors")},
        "focused_tests": {
            "argv": ["/tmp/plato-phase2-integration/final-mandatory-313/bin/python", "-m", "pytest", "tests/test_huggingface_artifacts.py", "tests/integration/test_qwen3_lora.py", "tests/trainers/test_huggingface_accumulation.py", "-q"],
            "env": {"PYTHONPATH": str(repo), "HF_HUB_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1"},
            "result": "25 passed, 10 warnings; no skips, xfails, deselections."
        },
        "accumulation_cases": len(probe["accumulation"]),
        "accumulation_max_error": max(row["max_error"] for row in probe["accumulation"]),
        "payload_variants": [row["variant"] for row in probe["adapters"]],
        "persistence_variants": [row["variant"] for row in persistence["variants"]],
        "reviewer_scratch_adaptation": "Only scratch was changed. The edge reproducer differs only in output directory. The standalone Algorithm payload fixture has no Trainer, so its expanded-vocabulary case establishes plato_save_embedding_layers from its explicitly preserved original vocabulary and actual pre-wrapper embedding size. Trainer detection itself is independently exercised by the unchanged edge logic and the actual new regression. One initial scratch attempt read num_embeddings through the embedding-LoRA wrapper and failed; the scratch fixture was corrected to capture the embedding size before wrapping, then all 48 accumulation and 4 payload cases passed.",
    },
    "evidence_checks": evidence,
    "evidence_bindings": {name: {"path": str(path), "sha256": sha(path)} for name,path in bindings.items()},
    "reviewed_source_sha256": correction["source_sha256"],
    "limitations": [
        "No source edits, nested agents, commits or external service calls. Scratch reports/scripts only; existing model cache read without download or mutation.",
        "This reviewer independently reran offline focused tests and numerical/persistence probes, but did not rerun the 596M official qualification or socket CLI. Both supplied runs were read and hash-bound to committed evidence.",
        "Actual-transport CLI remains a historical d3569ec observation. Source equivalence for the ordinary reference and fresh real numerical qualification support its applicability; no claim of a current-correction CLI execution.",
        "Tiny native random Qwen tests establish architecture/runtime behavior, separate from official pretrained qualification. Fixture metrics are not benchmark quality/convergence evidence; no full optimizer resume or Python 3.14 qualification claim.",
        "CLI used two serial logical clients with max_concurrency 1. Its aggregate RSS is sampled process-group RSS; qualification peak RSS is single-process and not directly comparable.",
        "The historical CLI has one visible semaphore-cleanup warning. Its cause is not conclusively attributed to new HF/LoRA code; natural exit and absence of survivors are verified and warning was not suppressed.",
        "Retirement archives/docs, packaging/hosted CI, combined repository suites and overall task acceptance remain root review/integration scope."
    ]
}
destination = scratch / "qwen-reference-review-bca1f6e.json"
destination.write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({"review": str(destination), "sha256": sha(destination), "decision":report["decision"],"unresolved_findings":report["unresolved_findings"]},indent=2))
