"""Independent, offline runtime probes; repository sources are read-only."""

from __future__ import annotations

import copy
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

REPO = Path(os.environ["PLATO_REVIEW_REPO"]).resolve()
SCRATCH = Path(os.environ.get("PLATO_REVIEW_SCRATCH", "/tmp/plato-qwen-review"))
sys.path.insert(0, str(REPO))
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["HF_DATASETS_OFFLINE"] = "1"
sys.argv = ["review-probe"]

import torch
from peft import LoraConfig, get_peft_model
from transformers import Qwen3Config, Qwen3ForCausalLM

from plato.algorithms.lora import Algorithm
from plato.trainers.huggingface import HuggingFaceTrainingStepStrategy
from plato.trainers.strategies.base import TrainingContext

torch.set_num_threads(2)


def tensor_hash(weights):
    digest = hashlib.sha256()
    for name, tensor in sorted(weights.items()):
        digest.update(name.encode())
        digest.update(tensor.detach().cpu().contiguous().numpy().tobytes())
    return digest.hexdigest()


class ScalarModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.weight = torch.nn.Parameter(torch.tensor(0.3, dtype=torch.float64))

    def forward(self, input_ids, labels, **unused):
        return SimpleNamespace(loss=((self.weight * input_ids - labels) ** 2).mean())


def accumulation_case(steps, count, last_flag):
    model = ScalarModel()
    oracle = copy.deepcopy(model)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.017, momentum=0.2)
    oracle_optimizer = torch.optim.SGD(oracle.parameters(), lr=0.017, momentum=0.2)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, 1, gamma=0.83)
    oracle_scheduler = torch.optim.lr_scheduler.StepLR(oracle_optimizer, 1, gamma=0.83)
    calls = []
    context = TrainingContext()
    context.device = torch.device("cpu")
    context.config = {"gradient_accumulation_steps": steps}
    context.state["hf_trainer"] = SimpleNamespace(
        _hf_on_pre_optimizer_step=lambda: calls.append("pre"),
        _hf_on_optimizer_step=lambda: calls.append("post"),
    )
    strategy = HuggingFaceTrainingStepStrategy(steps)
    strategy.setup(context)
    inputs = [torch.tensor([1.0 + i / 7], dtype=torch.float64) for i in range(count)]
    labels = [torch.tensor([(-1) ** i * (i + 1) / 3], dtype=torch.float64) for i in range(count)]
    step_flags = []
    updates = 0
    for i in range(count):
        context.state["is_last_batch"] = last_flag and i == count - 1
        loss = strategy.training_step(model, optimizer, {"input_ids": inputs[i]}, labels[i], None, context)
        flag = bool(context.state.get("optimizer_step_completed", False))
        step_flags.append(flag)
        if flag:
            updates += 1
            scheduler.step()
        assert torch.isfinite(loss)
    flush_loss = strategy.finalize(model, optimizer, context)
    if flush_loss is not None and context.state.get("optimizer_step_completed", False):
        updates += 1
        scheduler.step()
    for start in range(0, count, steps):
        oracle_optimizer.zero_grad()
        stop = min(start + steps, count)
        oracle(input_ids=torch.cat(inputs[start:stop]), labels=torch.cat(labels[start:stop])).loss.backward()
        oracle_optimizer.step()
        oracle_scheduler.step()
    expected_updates = (count + steps - 1) // steps
    repeat_flush = strategy.finalize(model, optimizer, context)
    return {
        "steps": steps,
        "microbatches": count,
        "is_last_batch_path": last_flag,
        "weight": model.weight.item(),
        "oracle_weight": oracle.weight.item(),
        "max_error": abs(model.weight.item() - oracle.weight.item()),
        "step_flags": step_flags,
        "optimizer_updates": updates,
        "expected_updates": expected_updates,
        "callbacks": calls,
        "callbacks_match": calls == [event for _ in range(expected_updates) for event in ("pre", "post")],
        "lr_matches": optimizer.param_groups[0]["lr"] == oracle_optimizer.param_groups[0]["lr"],
        "repeat_finalize_idle": repeat_flush is None,
        "counter_reset": context.state["grad_accum_counter"] == 0,
    }


def tiny_config():
    return Qwen3Config(
        vocab_size=32, hidden_size=16, intermediate_size=32,
        num_hidden_layers=1, num_attention_heads=2, num_key_value_heads=1,
        head_dim=8, max_position_embeddings=64, tie_word_embeddings=False,
        pad_token_id=0, eos_token_id=1,
    )


def adapter_case(name, targets, modules_to_save=None, expanded=False):
    torch.manual_seed(17)
    config = tiny_config()
    original_path = SCRATCH / "original-base-config"
    original_path.mkdir(exist_ok=True)
    config.save_pretrained(original_path)
    config._name_or_path = str(original_path)
    original_vocab_size = config.vocab_size
    base = Qwen3ForCausalLM(config)
    if expanded:
        base.resize_token_embeddings(36, mean_resizing=False)
    current_vocab_size = base.get_input_embeddings().num_embeddings
    model = get_peft_model(base, LoraConfig(
        r=2, lora_alpha=4, lora_dropout=0,
        target_modules=targets, modules_to_save=modules_to_save,
        task_type="CAUSAL_LM",
    ))
    model.plato_save_embedding_layers = (
        current_vocab_size != original_vocab_size
    )
    algorithm = Algorithm(SimpleNamespace(model=model))
    hidden_config_calls = []
    original_loader = Qwen3Config.from_pretrained

    def loader(*args, **kwargs):
        hidden_config_calls.append({"args": [str(x) for x in args], "kwargs": kwargs})
        return original_loader(*args, **kwargs)

    with patch.object(Qwen3Config, "from_pretrained", side_effect=loader):
        payload = algorithm.extract_weights()
    snapshot = {key: value.clone() for key, value in payload.items()}
    before_hash = tensor_hash(snapshot)
    parameter_ptrs = {tensor.data_ptr() for tensor in model.parameters()}
    aliases = [key for key, value in payload.items() if value.data_ptr() in parameter_ptrs]
    with torch.no_grad():
        for parameter in model.parameters():
            if parameter.requires_grad:
                parameter.add_(0.13)
    mutated_payload = [key for key, value in payload.items() if not torch.equal(value, snapshot[key])]
    roundtrip_error = None
    try:
        algorithm.load_weights(snapshot)
        restored = algorithm.extract_weights()
        roundtrip_error = max((restored[key] - value).abs().max().item() for key, value in snapshot.items())
    except Exception as exc:
        roundtrip_error = f"{type(exc).__name__}: {exc}"
    saved_modules_present = not modules_to_save or any("lm_head" in key and "lora" not in key for key in payload)
    embedding_adapter_present = "embed_tokens" not in targets or any("lora_embedding" in key for key in payload)
    expanded_embeddings_present = not expanded or (
        any("embed_tokens" in key and payload[key].shape[0] == 36 for key in payload)
        and any("lm_head" in key and payload[key].shape[0] == 36 for key in payload)
    )
    return {
        "variant": name,
        "keys": sorted(payload),
        "before_sha256": before_hash,
        "live_cpu_aliases": aliases,
        "snapshot_changed_after_local_mutation": mutated_payload,
        "hidden_config_calls": hidden_config_calls,
        "roundtrip_max_error": roundtrip_error,
        "modules_to_save_present": saved_modules_present,
        "embedding_adapter_present": embedding_adapter_present,
        "expanded_input_and_output_embeddings_present": expanded_embeddings_present,
        "ordinary_frozen_base_keys_excluded": not any(
            marker in key for key in payload
            for marker in ("input_layernorm", "post_attention_layernorm", "mlp.", "q_norm", "k_norm")
        ),
    }


def main():
    cases = [accumulation_case(steps, count, last) for steps in (1, 2, 3, 4)
             for count in (1, 2, 3, 5, 6, 7) for last in (False, True)]
    adapters = [
        adapter_case("qv", ["q_proj", "v_proj"]),
        adapter_case("saved_head", ["q_proj", "v_proj"], ["lm_head"]),
        adapter_case("embedding_lora", ["embed_tokens"]),
        adapter_case("expanded_vocabulary", ["q_proj", "v_proj"], expanded=True),
    ]
    result = {
        "reviewed_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip(),
        "repo": str(REPO),
        "python": sys.version,
        "scope": "Offline synthetic accumulation oracle and actual PEFT tiny native Qwen3 payload variants; no real pretrained claim.",
        "accumulation": cases,
        "adapters": adapters,
    }
    output = Path(os.environ["PLATO_REVIEW_OUTPUT"])
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({
        "receipt": str(output),
        "head": result["reviewed_head"],
        "accumulation_cases": len(cases),
        "accumulation_numerical_failures": sum(case["max_error"] > 1e-12 for case in cases),
        "adapter_variants": len(adapters),
        "adapter_snapshot_failures": sum(bool(case["snapshot_changed_after_local_mutation"]) for case in adapters),
        "hidden_config_calls": sum(len(case["hidden_config_calls"]) for case in adapters),
    }, indent=2))


if __name__ == "__main__":
    main()
