"""Independent mutation/reload probes for real offline tiny Qwen3/PEFT."""
import json
import os
import sys
from pathlib import Path
from unittest.mock import patch

REPO = Path(os.environ["PLATO_REVIEW_REPO"]).resolve()
sys.path.insert(0, str(REPO))
sys.argv = ["independent-persistence"]
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["HF_DATASETS_OFFLINE"] = "1"

import torch
from plato.algorithms.lora import Algorithm
from plato.models.huggingface import Model
from plato.trainers.huggingface import Trainer
from plato.serialization.safetensor import deserialize_tree, serialize_tree
from tests.integration.utils import configure_environment
from tests.test_utils.qwen3 import create_tiny_qwen3, reference_config, tensor_digest

torch.set_num_threads(2)
scratch = Path("/tmp/plato-qwen-review2/persistence")
scratch.mkdir(exist_ok=True)
directory = create_tiny_qwen3(scratch / "base")
variants = [
    ("qv", {}),
    ("saved_head", {"modules_to_save": ["lm_head"]}),
    ("saved_input", {"modules_to_save": ["embed_tokens"]}),
    ("embedding_lora", {"target_modules": ["embed_tokens"]}),
    ("regex_embedding_lora", {"target_modules": ".*embed_tokens"}),
    ("trainable_tokens", {"trainable_token_indices": [3, 4]}),
]
results = []
for name, override in variants:
    config = reference_config(directory)
    config["parameters"]["lora"].update(override)
    with configure_environment(config):
        model = Model.get()
        trainer = Trainer(model=model)
        algorithm = Algorithm(trainer)
        model.eval()
        inputs = torch.tensor([[1, 3, 4]])
        with patch.object(type(model.config), "from_pretrained", side_effect=AssertionError("implicit base config lookup")):
            payload = algorithm.extract_weights()
            original_hash = tensor_digest(payload)
            aliases = [key for key, value in payload.items() if value.data_ptr() in {parameter.data_ptr() for parameter in model.parameters()}]
            trainer.save_model(name + ".safetensors", str(scratch))
            with torch.no_grad():
                expected_logits = model(input_ids=inputs).logits.detach().clone()
                for parameter in model.parameters():
                    if parameter.requires_grad:
                        parameter.add_(0.13)
                mutated_logits = model(input_ids=inputs).logits.detach().clone()
            assert tensor_digest(payload) == original_hash
            assert not aliases
            assert not torch.equal(expected_logits, mutated_logits)
            algorithm.load_weights(payload)
            payload_restored_logits = model(input_ids=inputs).logits.detach()
            torch.testing.assert_close(payload_restored_logits, expected_logits, rtol=0, atol=0)
            with torch.no_grad():
                for parameter in model.parameters():
                    if parameter.requires_grad:
                        parameter.add_(0.27)
            trainer.load_model(name + ".safetensors", str(scratch))
            checkpoint_restored_logits = model(input_ids=inputs).logits.detach()
            torch.testing.assert_close(checkpoint_restored_logits, expected_logits, rtol=0, atol=0)
            assert tensor_digest(algorithm.extract_weights()) == original_hash
            checkpoint_path = scratch / (name + ".safetensors")
            saved_bytes = checkpoint_path.read_bytes()
            saved = deserialize_tree(saved_bytes)
            first_key = next(iter(saved))
            saved[first_key] = saved[first_key][:-1]
            checkpoint_path.write_bytes(serialize_tree(saved))
            before_failed_load = tensor_digest(algorithm.extract_weights())
            try:
                trainer.load_model(name + ".safetensors", str(scratch))
                raise AssertionError("Malformed checkpoint was accepted")
            except ValueError as error:
                assert "shape mismatch" in str(error)
            assert tensor_digest(algorithm.extract_weights()) == before_failed_load
            checkpoint_path.write_bytes(saved_bytes)
        results.append({
            "variant": name,
            "payload_keys": sorted(payload),
            "cpu_aliases": aliases,
            "snapshot_unchanged": True,
            "payload_reload_max_logit_error": (payload_restored_logits - expected_logits).abs().max().item(),
            "checkpoint_reload_max_logit_error": (checkpoint_restored_logits - expected_logits).abs().max().item(),
            "malformed_checkpoint_rejected_without_mutation": True,
            "implicit_base_config_calls": 0,
        })

config = reference_config(directory)
del config["trainer"]["random_seed"]
with configure_environment(config):
    torch.manual_seed(31)
    unseeded_first = Algorithm(Trainer(model=Model.get())).extract_weights()
    torch.manual_seed(99)
    unseeded_second = Algorithm(Trainer(model=Model.get())).extract_weights()
assert tensor_digest(unseeded_first) != tensor_digest(unseeded_second)
receipt = {
    "repo": str(REPO),
    "variants": results,
    "absent_seed_preserves_incoming_rng_variation": True,
    "scope": "Actual random native tiny Qwen3/PEFT, offline; no official pretrained claim.",
}
(scratch / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"variants": len(results), "all_exact_reload_logits": True, "absent_seed_preserves_incoming_rng_variation": True}))
