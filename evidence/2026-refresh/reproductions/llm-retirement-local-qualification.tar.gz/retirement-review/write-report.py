import hashlib,json,subprocess
from datetime import datetime,timezone
from pathlib import Path
root=Path("/tmp/plato-refresh-worktrees/retire-llm-backends")
scratch=Path("/tmp/plato-retirement-review")
receipt_file=root/"evidence/2026-refresh/llm-retirement-validation.json"
receipt=json.loads(receipt_file.read_text())
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
plan=Path("/tmp/plato-llm-retirement-plan.json")
design_review=Path("/tmp/plato-llm-retirement-plan-review.json")
assert digest(plan)==receipt["plan_sha256"]
assert digest(design_review)==receipt["plan_review_sha256"]
head=subprocess.check_output(["git","-C",str(root),"rev-parse","HEAD"],text=True).strip()
assert head=="321c5311ac3f4bd4c92e398c73b5a9d5d8b53ad4"
assert not subprocess.check_output(["git","-C",str(root),"status","--porcelain=v1","--untracked-files=all"])
evidence_names=["integrity-and-lock.json","behavior-and-build.json","collection-ledger.json","focused-tests.log","collection-mandatory.log","collection-base.log","archive-collection.log","build.log","lock-check.log","ruff.log","check-integrity.py","check-behavior.py","check-collection.py"]
report={
"schema_version":1,
"review_type":"Fresh independent read-only retirement implementation review",
"reviewer":"/root/retirement_review",
"completed_at":datetime.now(timezone.utc).isoformat(),
"decision":"ACCEPT_RETIREMENT_IMPLEMENTATION",
"repository_worktree":str(root),
"baseline_commit":"9ee92c52307cd3ecdce0c7416708c504bdb52137",
"reviewed_commit":head,
"clean_worktree_before_and_after":True,
"plan":{"path":str(plan),"sha256":digest(plan)},
"design_review":{"path":str(design_review),"sha256":digest(design_review),"decision":"ACCEPT_DESIGN"},
"author_receipt":{"path":str(receipt_file),"sha256":digest(receipt_file),"source_hashes":96,"archive_hashes":73,"all_fingerprints_verified":True,"all_12_referenced_log_fingerprints_verified":True},
"unresolved_findings":{"critical":0,"high":0,"medium":0,"low":0},
"findings":[],
"review_basis":[
{"area":"Archive closure and provenance","assessment":"Accept","evidence":"48 Nanochat plus 21 LeRobot original snapshots exactly match baseline Git bytes, lengths, SHA256, Git blob identities and modes. No unmanifested originals. All 25 deleted regular files are preserved; Nanochat gitlink is the sole additional deletion. Upstream tar content independently equals the complete pinned Nanochat Git tree: 54 blobs and executable modes at c75fe54aa7c1fa881701c246f9427bcbe4eee5a4. Tar has no links/devices/absolute/traversal paths; MIT/Andrej Karpathy notice exactly equals upstream LICENSE and the separate notice copy."},
{"area":"Supported runtime retirement","assessment":"Accept","evidence":"Removed the owned runtime modules, Nanochat/LeRobot/SmolVLA registry imports and entries, Nanochat processor utility and active gitlink/.gitmodules entry. Active plato/tests/configs/CI/package sweep finds retired names only in the diagnostic map and retirement regression tests. CORE-specific state/logging/result hooks are removed; generic structured logging and evaluation/checkpoint contracts remain."},
{"area":"Retired selections fail closed","assessment":"Accept","evidence":"Existing regression tests pass. Independent probes reject inferred and mixed-case model names, explicit datasource overrides, mixed-case trainer names, and retired evaluator types even when dynamically registered, allow_missing=True, or fail_on_error=False. Factory/evaluation execution cannot bypass retirement; errors point to archive and migration destinations."},
{"area":"Generic HF/PEFT/evaluation preservation","assessment":"Accept","evidence":"Eight relevant generic HF model/trainer/datasource, LoRA/FedAvg algorithm and Lighteval/base evaluator modules remain byte-identical to baseline. Generic adapter metadata coverage is retained with neutral wording. Actual generic evaluator results including metrics, metadata and artifacts survive persisted test-state reload; unrelated state survives, and disabled evaluation clears only generic evaluation keys. Focused evaluator/trainer/FedAvg/split-learning suites pass."},
{"area":"Test profile enforcement and collection ledger","assessment":"Accept","evidence":"DP/MPC/RL prerequisite-negative probes all fail correctly; the exact original absent-Opacus base skip remains permitted and unexpected retirement skips are rejected. Remaining mandatory node set, runtime set/startup counts and deselection/session-finish enforcement are AST-identical to baseline. Candidate collection is 1308 mandatory/1301 base; independent set comparison with the hashed 1303-case baseline log exactly matches the removal/addition ledger (1284 preserved, 19 removed, 24 added). Base omits only the existing seven DP cases. Archives recurse to zero tests."},
{"area":"Package/archive containment and lock boundary","assessment":"Accept","evidence":"Independent wheel and sdist built from the exact reviewed commit contain zero archive paths, external Nanochat paths or retired Plato runtime modules. Hatch/Ruff/ty/pytest archive exclusions are explicit and scope-limited. Locked package set moves 277 to 267, removes exactly the documented ten packages, adds none, and leaves every retained external package record (including versions, sources, hashes and dependency metadata) unchanged. uv lock --check passes."},
{"area":"Owned CI changes","assessment":"Accept within author scope","evidence":"Workflow diff replaces only the retired Nanochat test target with the retirement tests and diagnostic utility in the owned type guard. Matrix/helper delivery is separately root-owned; this review does not claim the old author matrix is the final integrated CI configuration."}
],
"independent_validation":[
{"command":"PYTHONDONTWRITEBYTECODE=1 HF_HUB_OFFLINE=1 HF_DATASETS_OFFLINE=1 /tmp/plato-retirement-mandatory-313/bin/python -m pytest tests/test_retired_backends.py tests/evaluators tests/trainers/test_composable_trainer.py tests/algorithms/test_fedavg_algorithm.py tests/servers/test_fedavg_strategy.py tests/servers/test_split_learning_selection_strategy.py --test-profile=mandatory -q -p no:cacheprovider --basetemp=/tmp/plato-retirement-review/pytest-runtime","exit_code":0,"result":"143 passed in 0.62s; no skips."},
{"command":"Mandatory tests --collect-only using Python 3.13.16 with cacheprovider disabled","exit_code":0,"result":"1308 collected; exact ledger confirmed."},
{"command":"Base tests --collect-only using isolated author base Python 3.13.16 with cacheprovider disabled","exit_code":0,"result":"1301 collected; exactly seven existing DP nodes absent."},
{"command":"pytest archives --collect-only -q -p no:cacheprovider","exit_code":5,"result":"Expected no-tests-collected exit; zero archive tests."},
{"command":"/tmp/plato-retirement-mandatory-313/bin/python /tmp/plato-retirement-review/check-integrity.py","exit_code":0,"result":"Exact original/upstream Git object closure, receipt fingerprints, and retained lock records verified."},
{"command":"/tmp/plato-retirement-mandatory-313/bin/python /tmp/plato-retirement-review/check-behavior.py","exit_code":0,"result":"12 independent retired registry/evaluator negative paths, three mandatory prerequisite negative paths, strict skip behavior, generic checkpoint round-trip, and distribution containment verified."},
{"command":"/tmp/plato-retirement-mandatory-313/bin/python /tmp/plato-retirement-review/check-collection.py","exit_code":0,"result":"Exact collection ledger and all 12 receipt log hashes verified."},
{"command":"uv build --no-build-isolation --python /tmp/plato-retirement-mandatory-313/bin/python --sdist --wheel --out-dir /tmp/plato-retirement-review/dist","exit_code":0,"result":"Reviewed commit builds; wheel 426 entries, sdist 1353 entries; zero retired/archive payloads."},
{"command":"uv lock --check --python 3.13","exit_code":0,"result":"Resolved 268 packages including workspace metadata; current lock."},
{"command":"/tmp/plato-retirement-mandatory-313/bin/ruff check . --select I","exit_code":0,"result":"All checks passed."},
{"command":"git diff --check 9ee92c52307cd3ecdce0c7416708c504bdb52137..HEAD; git status --porcelain=v1 --untracked-files=all","exit_code":0,"result":"Clean diff and worktree."}
],
"independent_artifacts":{name:{"path":str(scratch/name),"sha256":digest(scratch/name)} for name in evidence_names},
"reviewed_distributions":json.loads((scratch/"behavior-and-build.json").read_text())["distribution"],
"integration_notes":[
"Acceptance covers the retirement owner's exact commit. Integrate separately owned archive READMEs/public migration notices and the Qwen replacement config before final public delivery so runtime diagnostic destinations exist.",
"Root must retain the newer Phase 2 CI helper and Python 3.13-only configuration during three-way integration, then run the final integrated checks and Linux acceptance gate.",
"Archive material, manifests and immutable historical evidence should remain byte-preserved through integration."
],
"limits":[
"No repository source edits, commits, nested agents or external review service used. Only reviewer-owned scratch reports/scripts/artifacts were written.",
"Existing author environments were used for read-only command execution; no installs/syncs or environment mutation performed.",
"No full-suite execution or broad type rerun was performed; collection, focused execution and independent probes cover this implementation scope. Root owns final integrated qualification.",
"No Python 3.14, Qwen/HF replacement changes, pretrained-weight execution or docs build is certified by this retirement-only review.",
"Baseline collection is independently parsed from its hash-verified author log; the original Nanochat-enabled baseline suite was not re-executed."
]}
out=scratch/"review.json"
out.write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({"decision":report["decision"],"reviewed_commit":head,"unresolved_findings":report["unresolved_findings"],"report_path":str(out),"report_sha256":digest(out)},indent=2))

