import ast, hashlib, json, subprocess, sys, tarfile, zipfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
root = Path("/tmp/plato-refresh-worktrees/retire-llm-backends")
scratch = Path("/tmp/plato-retirement-review")
sys.path.insert(0, str(root))
import pytest
import torch
from torch import nn
import tests.conftest as guards
from plato.config import Config, ConfigNode
from plato.models import registry as models
from plato.datasources import registry as datasources
from plato.trainers import registry as trainers
from plato.trainers.composable import ComposableTrainer
from plato.evaluators import registry as evaluators
from plato.evaluators.base import EvaluationResult
from plato.evaluators.runner import EVALUATION_PRIMARY_KEY, EVALUATION_RESULTS_KEY, run_configured_evaluation
from plato.trainers.strategies.base import TrainingContext
from tests.integration.utils import build_minimal_config, configure_environment
assert Path(models.__file__).resolve().is_relative_to(root.resolve())
baseline = "9ee92c52307cd3ecdce0c7416708c504bdb52137"
def git(*args):
    return subprocess.check_output(["git", "-C", str(root), *args])
old_ast = ast.parse(git("show", f"{baseline}:tests/conftest.py").decode())
new_ast = ast.parse((root / "tests/conftest.py").read_text())
def assignment(tree, name):
    return next(n.value for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in n.targets))
for key in ("_DP_MODULE", "_DP_REASON", "_RUNTIME", "_STARTUP_CASES"):
    assert ast.dump(assignment(old_ast, key)) == ast.dump(assignment(new_ast, key)), key
assert ast.dump(assignment(old_ast, "_REQUIRED").right) == ast.dump(assignment(new_ast, "_REQUIRED"))
def method(tree, name):
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "_ProfileChecks")
    return next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == name)
for name in ("pytest_deselected", "pytest_sessionfinish", "pytest_terminal_summary"):
    assert ast.dump(method(old_ast, name)) == ast.dump(method(new_ast, name)), name
def config(profile):
    opts = {"test_profile": profile, "keyword": "", "markexpr": "", "deselect": [], "collectonly": False}
    return SimpleNamespace(rootpath=root, args=[str(root / "tests")], getoption=lambda key: opts.get(key, False))
for dependency in ("opacus", "kazoo", "gymnasium"):
    guard = guards._ProfileChecks(config("mandatory"))
    actual_import = guards.importlib.import_module
    def importing(name, package=None):
        if name == dependency:
            raise ImportError(f"probe missing {dependency}")
        return actual_import(name, package)
    with patch.object(guards.importlib, "import_module", importing):
        try:
            guard.pytest_sessionstart()
        except pytest.UsageError as exc:
            assert "mandatory prerequisite failed" in str(exc) and dependency in str(exc)
        else:
            raise AssertionError(f"Missing {dependency} was accepted")
base = guards._ProfileChecks(config("base"))
report = SimpleNamespace(skipped=True, nodeid=guards._DP_MODULE, longrepr=("file", 1, "Skipped: " + guards._DP_REASON))
with patch.object(guards.importlib.util, "find_spec", return_value=None):
    base._check_skip(report)
assert base.allowed_skips == {guards._DP_MODULE} and not base.violations
base._check_skip(SimpleNamespace(skipped=True, nodeid="tests/reviewer::unexpected", longrepr=("file", 1, "Skipped: base profile omits optional nanochat integration")))
assert len(base.violations) == 1
runtime = scratch / "probe-runtime"
runtime.mkdir(exist_ok=True)
calls = []
def retired_error(fn):
    try:
        fn()
    except ValueError as exc:
        message = str(exc)
        assert "retired" in message and "archives/retired/" in message
        return message
    raise AssertionError("Retired selection accepted")
with configure_environment(build_minimal_config(), runtime_root=runtime):
    assert isinstance(models.get(model_name="lenet5"), nn.Module)
    negative = {}
    for name in ("nanochat", "Nanochat", "smolvla", "SmolVLA"):
        negative["model-inferred:" + name] = retired_error(lambda name=name: models.get(model_name=name, model_type=""))
    for name in ("Nanochat", "LeRobot"):
        negative["datasource-override:" + name] = retired_error(lambda name=name: datasources.get(datasource_name=name))
    for name in ("Nanochat", "LeRobot"):
        Config.trainer = Config.trainer._replace(type=name)
        negative["trainer:" + name] = retired_error(lambda: trainers.get(model=nn.Linear(2, 1)))
    for name in ("nanochat_core", "NANOCHAT_CORE"):
        def forbidden_factory(cfg):
            calls.append("factory")
            raise AssertionError("Retired factory invoked")
        evaluators.register(name, forbidden_factory)
        try:
            negative["registered-evaluator:" + name] = retired_error(lambda name=name: evaluators.get({"type": name}, allow_missing=True))
            Config.evaluation = ConfigNode.from_object({"type": name, "fail_on_error": False})
            negative["nonfatal-runner:" + name] = retired_error(lambda: run_configured_evaluation(model=nn.Linear(2,1), context=TrainingContext()))
        finally:
            evaluators.unregister(name)
    assert not calls
    metric_name = "review_metric"
    class Metric:
        def __init__(self, config):
            self.config = config
        def evaluate(self, request):
            return EvaluationResult(evaluator=metric_name, primary_metric="loss", metrics={"loss":0.75,"perplexity":2.117}, metadata={"split":"validation"}, artifacts={"log":"local"})
    evaluators.register(metric_name, Metric)
    try:
        Config.evaluation = ConfigNode.from_object({"type":metric_name, "fail_on_error":True})
        first = ComposableTrainer(model=nn.Linear(2,1))
        result = run_configured_evaluation(model=first.model, context=first.context, trainer=first)
        assert result.primary_value == 0.75
        before = {key:first.context.state[key] for key in (EVALUATION_RESULTS_KEY,EVALUATION_PRIMARY_KEY)}
        first._save_test_state("review-generic.eval.pkl")
        restored = ComposableTrainer(model=nn.Linear(2,1))
        restored.context.state["unrelated"] = {"kept":True}
        restored._load_test_state("review-generic.eval.pkl")
        assert {key:restored.context.state[key] for key in before} == before
        assert restored.context.state["unrelated"] == {"kept":True}
        del Config.evaluation
        assert run_configured_evaluation(model=restored.model, context=restored.context) is None
        assert EVALUATION_RESULTS_KEY not in restored.context.state and EVALUATION_PRIMARY_KEY not in restored.context.state
        assert restored.context.state["unrelated"] == {"kept":True}
    finally:
        evaluators.unregister(metric_name)
preserved = [
"plato/models/huggingface.py", "plato/trainers/huggingface.py",
"plato/datasources/huggingface.py", "plato/datasources/lora.py",
"plato/algorithms/lora.py", "plato/algorithms/fedavg.py",
"plato/evaluators/lighteval.py", "plato/evaluators/base.py",
]
for path in preserved:
    assert git("show", f"{baseline}:{path}") == (root / path).read_bytes(), path
dist = {}
for path in (scratch / "dist").iterdir():
    if path.name.endswith(".whl"):
        with zipfile.ZipFile(path) as package:
            names = package.namelist()
    elif path.name.endswith(".tar.gz"):
        with tarfile.open(path) as package:
            names = package.getnames()
    else:
        continue
    assert not any("/archives/retired/" in "/" + name or "/external/nanochat/" in "/" + name for name in names)
    assert not any("/plato/" in "/" + name and any(term in name.lower() for term in ("nanochat", "lerobot", "smolvla")) for name in names)
    dist[path.name] = {"entries":len(names), "sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"retired_payloads":0}
out={"strict_profile_guards":{"dp_mpc_rl_prerequisite_negative_paths":3,"original_dp_skip_only":True,"unexpected_retirement_skip_rejected":True,"remaining_mandatory_nodes_and_runtime_counts_unchanged":True,"selection_and_finish_enforcement_ast_identical":True},"negative_registry_paths":negative,"generic_evaluator_checkpoint_state":{"metrics_metadata_artifacts_roundtrip":True,"unrelated_state_preserved":True,"disabled_evaluation_clears_generic_state":True},"unchanged_generic_modules":preserved,"distribution":dist}
(scratch / "behavior-and-build.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps(out,indent=2))

