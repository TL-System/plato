import hashlib, json, subprocess, tarfile, tomllib
from pathlib import Path
root = Path("/tmp/plato-refresh-worktrees/retire-llm-backends")
scratch = Path("/tmp/plato-retirement-review")
baseline = "9ee92c52307cd3ecdce0c7416708c504bdb52137"
commit = "321c5311ac3f4bd4c92e398c73b5a9d5d8b53ad4"
gitdir = "/Users/bli/Playground/plato/.git/modules/external/nanochat"
def git(*args):
    return subprocess.check_output(["git", "-C", str(root), *args])
def sha(data):
    return hashlib.sha256(data).hexdigest()
assert git("rev-parse", "HEAD").decode().strip() == commit
assert not git("status", "--porcelain=v1", "--untracked-files=all")
out = {"reviewed_commit": commit, "baseline": baseline, "start_clean": True}
archived = {}
original_paths = set()
for backend, expected in (("nanochat", 48), ("lerobot", 21)):
    manifest_file = root / f"archives/retired/{backend}/manifest.json"
    m = json.loads(manifest_file.read_text())
    assert m["pre_retirement_plato_commit"] == baseline
    assert len(m["files"]) == expected
    expected_archive = set()
    for e in m["files"]:
        original_paths.add(e["original_path"])
        expected_archive.add(e["archive_path"])
        blob = git("show", f"{baseline}:{e['original_path']}")
        archived_bytes = (root / e["archive_path"]).read_bytes()
        assert blob == archived_bytes, e["original_path"]
        assert len(blob) == e["bytes"] and sha(blob) == e["sha256"]
        entry = git("ls-tree", baseline, "--", e["original_path"]).decode().split()
        assert (entry[0], entry[2]) == (e["git_mode"], e["git_blob"])
        if e["disposition"] == "moved":
            assert not (root / e["original_path"]).exists()
    actual_archive = {
        p.relative_to(root).as_posix()
        for p in (root / f"archives/retired/{backend}/original").rglob("*")
        if p.is_file()
    }
    assert expected_archive == actual_archive
    archived[backend] = {"snapshots": expected, "exact_baseline_bytes_and_manifest_metadata": True, "no_unmanifested_originals": True}
    if backend == "nanochat":
        u = m["upstream"]
        pin = u["gitlink_pin"]
        baseline_gitlink = git("ls-tree", baseline, "--", "external/nanochat").decode().split()
        assert baseline_gitlink[0:2] == ["160000", "commit"] and baseline_gitlink[2] == pin
        assert not git("ls-tree", commit, "--", "external/nanochat")
        entries = subprocess.check_output(["git", f"--git-dir={gitdir}", "ls-tree", "-rz", pin])
        pinned = {}
        for entry in entries.split(b"\0"):
            if not entry: continue
            meta, path = entry.split(b"\t", 1)
            mode, kind, blob = meta.decode().split()
            assert kind == "blob"
            pinned[path.decode()] = (mode, blob)
        assert len(pinned) == 54
        records = {e["path"]: (e["git_mode"], e["git_blob"]) for e in u["files"]}
        assert pinned == records, "manifest must equal complete pinned upstream Git tree"
        archive_bytes = (root / u["archive_path"]).read_bytes()
        assert len(archive_bytes) == u["archive_bytes"] and sha(archive_bytes) == u["archive_sha256"]
        with tarfile.open(root / u["archive_path"]) as tf:
            members = tf.getmembers()
            assert all(not Path(e.name).is_absolute() and ".." not in Path(e.name).parts for e in members)
            assert all(e.isdir() or e.isfile() for e in members), "No links or devices"
            files = {e.name: e for e in members if e.isfile()}
            assert set(files) == set(pinned)
            for path, (mode, blob) in pinned.items():
                archived_data = tf.extractfile(files[path]).read()
                upstream_data = subprocess.check_output(["git", f"--git-dir={gitdir}", "cat-file", "blob", blob])
                assert archived_data == upstream_data, path
                assert files[path].mode & 0o111 == int(mode, 8) & 0o111
            notice = tf.extractfile(files["LICENSE"]).read()
        assert notice == (root / u["license_path"]).read_bytes()
        assert sha(notice) == u["license_sha256"]
        assert b"MIT License" in notice and b"Andrej Karpathy" in notice
        archived[backend].update({"upstream_files": 54, "exact_pinned_upstream_tree_and_bytes": True, "safe_tar_members_and_executable_modes": True, "mit_notice_preserved": True, "active_gitlink_removed": True})
deleted = git("diff", "--no-renames", "--diff-filter=D", "--name-only", baseline, commit).decode().splitlines()
assert set(deleted) - {"external/nanochat"} <= original_paths
out["archive"] = archived
out["deleted_source_closure"] = {"deleted_files": len(deleted), "all_deleted_regular_files_preserved": True}
before = tomllib.loads(git("show", f"{baseline}:uv.lock").decode())
after = tomllib.loads((root / "uv.lock").read_text())
def packages(lock):
    return {p["name"]: p for p in lock["package"]}
old, new = packages(before), packages(after)
removed = {name: old[name]["version"] for name in old.keys() - new.keys()}
added = {name: new[name]["version"] for name in new.keys() - old.keys()}
changed = {name: (old[name]["version"], new[name]["version"]) for name in old.keys() & new.keys() if old[name]["version"] != new[name]["version"]}
external_records_changed = [name for name in old.keys() & new.keys() if name != "plato-learn" and old[name] != new[name]]
assert len(removed) == 10 and not added and not changed and not external_records_changed
out["lock_delta"] = {"before_packages": len(old), "after_packages": len(new), "removed": removed, "added": added, "retained_version_changes": changed, "retained_external_records_changed": external_records_changed}
receipt_path = root / "evidence/2026-refresh/llm-retirement-validation.json"
receipt = json.loads(receipt_path.read_text())
for group in ("source_hashes", "archive_hashes"):
    for path, expected_hash in receipt[group].items():
        if expected_hash is None:
            assert not (root / path).exists(), path
            continue
        assert sha((root / path).read_bytes()) == expected_hash, path
out["receipt"] = {"sha256": sha(receipt_path.read_bytes()), "source_hash_count": len(receipt["source_hashes"]), "archive_hash_count": len(receipt["archive_hashes"]), "all_tracked_fingerprints_match": True}
assert not git("status", "--porcelain=v1", "--untracked-files=all")
(scratch / "integrity-and-lock.json").write_text(json.dumps(out, indent=2) + "\n")
print(json.dumps(out, indent=2))
