import hashlib, json, re, subprocess
from pathlib import Path
root=Path("/tmp/plato-refresh-worktrees/retire-llm-backends")
scratch=Path("/tmp/plato-retirement-review")
receipt=json.loads((root/"evidence/2026-refresh/llm-retirement-validation.json").read_text())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def nodes(path):
    return {line for line in path.read_text().splitlines() if line.startswith("tests/") and "::" in line}
before_path=Path(receipt["logs"]["before-collection"]["path"])
assert sha(before_path)==receipt["logs"]["before-collection"]["sha256"]
before=nodes(before_path)
mandatory=nodes(scratch/"collection-mandatory.log")
base=nodes(scratch/"collection-base.log")
assert len(before)==1303 and len(mandatory)==1308 and len(base)==1301
removed=sorted(before-mandatory)
added=sorted(mandatory-before)
assert removed==sorted(receipt["collection_ledger"]["removed"])
assert added==sorted(receipt["collection_ledger"]["added"])
assert len(before & mandatory)==1284
assert sorted(mandatory-base)==sorted(receipt["collection_ledger"]["base_profile"]["omitted_mandatory_nodes"])
assert all(n.startswith("tests/trainers/test_dp_data_loader_strategy.py::") for n in mandatory-base)
assert not any("archives/" in n for n in mandatory | base)
logs=[]
for name, entry in receipt["logs"].items():
    assert sha(Path(entry["path"]))==entry["sha256"], name
    logs.append(name)
out={"baseline_cases":len(before),"mandatory_cases":len(mandatory),"base_cases":len(base),"preserved":len(before & mandatory),"removed":removed,"added":added,"base_omissions":sorted(mandatory-base),"ledger_exactly_matches_hashed_baseline_log_and_current_collections":True,"receipt_log_fingerprints_verified":logs}
(scratch/"collection-ledger.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({k:v for k,v in out.items() if k not in ("removed","added","base_omissions")},indent=2))

