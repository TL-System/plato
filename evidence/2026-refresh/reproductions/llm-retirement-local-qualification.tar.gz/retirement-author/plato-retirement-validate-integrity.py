from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import zipfile

root = Path.cwd()
results = {}
for backend in ('nanochat', 'lerobot'):
    manifest = json.loads((root / 'archives/retired' / backend / 'manifest.json').read_text())
    for entry in manifest['files']:
        original = subprocess.check_output(['git', 'show', f"{manifest['pre_retirement_plato_commit']}:{entry['original_path']}"])
        archived = (root / entry['archive_path']).read_bytes()
        assert original == archived
        assert hashlib.sha256(original).hexdigest() == entry['sha256']
    results[backend] = {'original_files': len(manifest['files']), 'all_match_original_git_blobs': True}
    if backend == 'nanochat':
        upstream = manifest['upstream']
        with tarfile.open(root / upstream['archive_path']) as source:
            for entry in upstream['files']:
                file = source.extractfile(entry['path'])
                assert file is not None
                data = file.read()
                git_blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
                assert git_blob == entry['git_blob']
                # Git records executable bits, not Unix group-write permissions.
                assert source.getmember(entry['path']).mode & 0o111 == int(entry['git_mode'][-3:], 8) & 0o111
        results[backend]['upstream_tracked_files'] = len(upstream['files'])
        results[backend]['upstream_git_blobs_and_executable_modes_match'] = True
for path in Path('/tmp/plato-retirement-dist').glob('*'):
    if path.suffix == '.whl':
        with zipfile.ZipFile(path) as package:
            names = package.namelist()
    elif path.name.endswith('.tar.gz'):
        with tarfile.open(path) as package:
            names = package.getnames()
    else:
        continue
    assert not any('/archives/retired/' in '/' + name or '/external/nanochat/' in '/' + name for name in names)
    assert not any('/plato/' in '/' + name and any(term in name.lower() for term in ('nanochat', 'lerobot', 'smolvla')) for name in names)
    results[path.name] = {'entries': len(names), 'archive_or_retired_runtime_entries': 0, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
Path('/tmp/plato-retirement-integrity-and-build.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
