"""Bind the completed read-only review to the frozen candidate."""

import hashlib
import json
import subprocess
from pathlib import Path

repo = Path("/tmp/plato-refresh-worktrees/qwen-reference-review")
scratch = Path("/tmp/plato-qwen-review")
evidence_path = repo / "evidence/2026-refresh/qwen-reference-validation.json"
evidence = json.loads(evidence_path.read_text())


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
tree = subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], cwd=repo, text=True).strip()
clean = not subprocess.check_output(["git", "status", "--porcelain"], cwd=repo, text=True).strip()
assert head == "d3569ec98e64fb83ef43c2b50db4543cfe6a3bc6" and clean
actual_hashes = {filename: sha(repo / filename) for filename in evidence["source_sha256"]}
assert actual_hashes == evidence["source_sha256"]
actual_cli = json.loads(Path("/tmp/plato-qwen-validation/cli-transport/cli-result.json").read_text())
assert all(evidence["normal_entrypoint_actual_transport"][key] == value for key, value in actual_cli.items())
actual_qualification = json.loads(Path("/tmp/plato-qwen-validation/real-pretrained/qualification.json").read_text())
assert actual_qualification == evidence["pretrained_qualification"]
cli_log = Path(actual_cli["log"])
cli_text = cli_log.read_text()
assert sha(cli_log) == evidence["normal_entrypoint_actual_transport"]["log_sha256"]
assert sha("/tmp/plato-qwen-validation/run_cli_transport.py") == evidence["normal_entrypoint_actual_transport"]["wrapper_sha256"]
assert sha("/tmp/plato-qwen-validation/real-pretrained.log") == evidence["pretrained_qualification_command"]["log_sha256"]
assert "/resolve/main/" not in cli_text and "/revision/main" not in cli_text
final_probe = json.loads((scratch / "final-probe.json").read_text())
assert final_probe["reviewed_head"] == head
assert len(final_probe["accumulation"]) == 48
assert all(case["max_error"] == 0 and case["callbacks_match"] and case["lr_matches"]
           and case["repeat_finalize_idle"] and case["counter_reset"]
           and case["optimizer_updates"] == case["expected_updates"]
           for case in final_probe["accumulation"])
assert all(not case["live_cpu_aliases"] and not case["snapshot_changed_after_local_mutation"]
           and not case["hidden_config_calls"] and case["roundtrip_max_error"] == 0
           for case in final_probe["adapters"])
edges = json.loads((scratch / "edges/receipt.json").read_text())
assert edges[0]["logits_restored"] and not edges[1]["logits_restored"]
report = {
    "schema_version": 1,
    "review_type": "Fresh independent read-only exact-candidate Qwen/HF/PEFT implementation review",
    "reviewer": "/root/qwen_reference_review",
    "date": "2026-10-03",
    "decision": "REQUEST_CHANGES",
    "reviewed_commit": head,
    "reviewed_tree": tree,
    "baseline_commit": "9ee92c52307cd3ecdce0c7416708c504bdb52137",
    "frozen_checkout": str(repo),
    "checkout_clean_before_and_after_tests": clean,
    "unresolved_findings": {"critical": 0, "high": 0, "medium": 1, "low": 0},
    "findings": [{
        "id": "QWEN-01",
        "severity": "medium",
        "title": "Supplied PEFT models expanded before trainer construction silently lose added embeddings",
        "paths": ["plato/trainers/huggingface.py:648", "plato/utils/huggingface.py:58", "plato/algorithms/lora.py:46"],
        "trigger": "Load the configured original base through Model.get(), expand that supplied PEFT model to the configured expanded tokenizer size using resize_token_embeddings(), then construct Trainer(model=model).",
        "cause": "Trainer only sets plato_save_embedding_layers when it itself expands the input embedding. A supplied model that already has the required size does not receive the marker. adapter_save_embeddings then returns false for q/v LoRA, overriding PEFT's prior expanded-vocabulary preservation behavior.",
        "impact": "Both input and output expanded embedding matrices are absent from production federated payloads and adapter checkpoints. Loading the saved adapter does not restore changed added-token embeddings, so the model's logits differ from the checkpoint.",
        "independent_reproduction": {
            "script": str(scratch / "edge_cases.py"),
            "receipt": str(scratch / "edges/receipt.json"),
            "log": str(scratch / "edge-cases.log"),
            "configured_original_vocabulary": 256,
            "expanded_tokenizer_and_embedding_size": 257,
            "trainer_performed_resize": edges[0],
            "caller_performed_resize": edges[1]
        },
        "required_fix": "Identify already-expanded supplied models using the already pinned original AutoConfig vocabulary or equivalent explicit original-vocabulary metadata, and preserve both input/output embeddings without an unpinned PEFT auto lookup. Add an actual supplied-model pre-resize payload/checkpoint/logit regression; rerun the existing in-trainer expansion case.",
        "scope_note": "The shipped Qwen reference has no added vocabulary and passed its qualification. This finding violates the accepted requirement to preserve configured expanded-vocabulary embedding behavior in the shared HF/PEFT runtime."
    }],
    "verified_passes": [
        "All 15 source SHA256 values in the committed validation receipt match this exact clean candidate.",
        "Independent 48-case float64 SGD/momentum accumulation oracle: steps 1/2/3/4, counts 1/2/3/5/6/7, is_last_batch and finalize paths. All final parameters match exactly; callbacks, scheduler advancement, optimizer update counts, counter clearing and repeated finalize behavior match.",
        "Independent actual PEFT tiny native Qwen payload variants show no CPU storage aliases, no changed snapshots after local trainable-parameter mutation, no implicit base-config calls and exact payload load round-trips. Ordinary q/v, modules_to_save head and embedding-LoRA states are preserved.",
        "24 focused new candidate tests passed on the existing Python 3.13 environment with 10 visible warnings, zero skips/xfails/deselections. Coverage includes real offline tiny-Qwen/PEFT update, unequal 2/3 production weighted aggregation, every-tensor oracle, base hash preservation, checkpoint/restored logits, revision propagation/bad-pin failure, cache identity, configured seed, accumulation and actual HF callback/control/scheduler integration.",
        "Source review confirms exact configured revisions flow through model config/weights, tokenizer loaders and PEFT revision; trust_remote_code is false, current token/dtype arguments are used and loader failures have no retry-main/random fallback.",
        "Raw HF dataset cache identity includes explicit revision and resolved local-file path plus streaming SHA256; explicitly pinned/local inputs do not accept legacy unpinned raw caches.",
        "trainer.random_seed is optional: adapter initialization seeds Torch only when configured; train_model applies configured seed plus client ID before sampling/training. Reference data/server seeds are explicitly 17. Existing configs without trainer.random_seed retain the prior no-seeding behavior.",
        "Committed real-pretrained receipt matches the external qualification JSON exactly. It reports official Qwen3-0.6B-Base at the approved SHA, CPU FP32/Python 3.13, 596049920 frozen base parameters plus 573440 trainable adapter parameters, finite metrics/gradients, unequal 2/3 weighted aggregation, independent snapshots, unchanged base and matching reload logits.",
        "Actual-transport CLI JSON/log/wrapper and real qualification log hashes match the committed evidence. CLI has comm_simulation=false on server/clients, safetensor encode/decode, real 2.22 MB transfers for both logical clients, returncode 0, natural process-group exit and zero survivors. Prior simulated run is explicitly historical."
    ],
    "evidence_bindings": {
        "committed_validation_receipt": {"path": str(evidence_path), "sha256": sha(evidence_path)},
        "reviewed_source_sha256": actual_hashes,
        "independent_baseline_probe": {"path": str(scratch / "baseline-probe.json"), "sha256": sha(scratch / "baseline-probe.json")},
        "independent_final_probe": {"path": str(scratch / "final-probe.json"), "sha256": sha(scratch / "final-probe.json")},
        "independent_edge_receipt": {"path": str(scratch / "edges/receipt.json"), "sha256": sha(scratch / "edges/receipt.json")},
        "focused_test_log": {"path": str(scratch / "focused-final.log"), "sha256": sha(scratch / "focused-final.log")},
        "actual_transport_cli": {"path": "/tmp/plato-qwen-validation/cli-transport/cli-result.json", "sha256": sha("/tmp/plato-qwen-validation/cli-transport/cli-result.json")},
        "real_pretrained": {"path": "/tmp/plato-qwen-validation/real-pretrained/qualification.json", "sha256": sha("/tmp/plato-qwen-validation/real-pretrained/qualification.json")}
    },
    "limitations": [
        "No source files edited; only scratch scripts/reports were written. No nested agents or external review tool used.",
        "The 596M real-weight run and normal CLI were read and hash-bound to supplied receipts; this independent reviewer did not rerun them or re-download/mutate model cache.",
        "Independent tiny native Qwen tests are architecture/runtime checks, distinct from official pretrained qualification.",
        "CLI exercised two logical clients serially with max_concurrency=1; the wrapper observed up to four process-group members. RSS observation is sampled aggregate RSS, while qualification peak RSS is a single-process measurement.",
        "CLI contains one visible resource_tracker semaphore-cleanup warning. Natural exit and zero survivors are verified by the bound wrapper receipt. The warning's cause is not proven to be new HF/LoRA code and was not suppressed.",
        "Fixture metrics establish bounded integration behavior, without benchmark quality/convergence, full optimizer resume or Python 3.14 qualification claims.",
        "Retired archive closure, full combined repository suite, packaging and hosted CI remain root/other reviewers' scope."
    ]
}
destination = scratch / "qwen-reference-review-d3569ec.json"
destination.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"report": str(destination), "decision": report["decision"], "commit": head, "source_hashes_match": len(actual_hashes), "medium_findings": 1}, indent=2))
