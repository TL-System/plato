"""Read-only candidate checks for supplied expanded PEFT models and persistence."""

import json
import os
import sys
from pathlib import Path
from unittest.mock import patch

import torch
from peft import get_peft_model_state_dict
from transformers import AutoTokenizer

REPO = Path(os.environ["PLATO_REVIEW_REPO"]).resolve()
sys.path.insert(0, str(REPO))
sys.argv = ["review-edge-cases"]

from plato.algorithms.lora import Algorithm
from plato.config import Config
from plato.models.huggingface import Model
from plato.serialization.safetensor import deserialize_tree
from plato.trainers.huggingface import Trainer
from tests.integration.utils import configure_environment
from tests.test_utils.qwen3 import create_tiny_qwen3, reference_config, tensor_digest

scratch = Path("/tmp/plato-qwen-review/edges")
scratch.mkdir(exist_ok=True)
directory = create_tiny_qwen3(scratch / "original-model")
tokenizer = AutoTokenizer.from_pretrained(directory)
tokenizer.add_tokens([f"review-added-token-{index}" for index in range(128)])
tokenizer.save_pretrained(scratch / "expanded-tokenizer")
config = reference_config(directory)
config["trainer"]["tokenizer_name"] = str(scratch / "expanded-tokenizer")
results = []
for when in ("inside_trainer", "before_trainer"):
    with configure_environment(config):
        model = Model.get()
        if when == "before_trainer":
            model.resize_token_embeddings(len(tokenizer), mean_resizing=False)
        trainer = Trainer(model=model)
        algorithm = Algorithm(trainer)
        with patch.object(type(model.config), "from_pretrained", side_effect=RuntimeError("hidden config reload")):
            payload = algorithm.extract_weights()
            trainer.save_model(f"{when}.safetensors", str(scratch))
        peft_expected = get_peft_model_state_dict(model, save_embedding_layers=True)
        persisted = deserialize_tree((scratch / f"{when}.safetensors").read_bytes())
        original_logits = model(input_ids=torch.tensor([[1, len(tokenizer)-1, 4]])).logits.detach().clone()
        with torch.no_grad():
            model.get_input_embeddings().weight[-1].add_(0.5)
            model.get_output_embeddings().weight[-1].add_(0.3)
        trainer.load_model(f"{when}.safetensors", str(scratch))
        restored_logits = model(input_ids=torch.tensor([[1, len(tokenizer)-1, 4]])).logits.detach().clone()
        results.append({
            "resize_when": when,
            "tokenizer_size": len(tokenizer),
            "embedding_size": model.get_input_embeddings().num_embeddings,
            "plato_save_embedding_layers": getattr(model, "plato_save_embedding_layers", None),
            "payload_embedding_keys": [key for key in payload if "embed_tokens" in key or "lm_head" in key],
            "native_peft_embedding_keys": [key for key in peft_expected if "embed_tokens" in key or "lm_head" in key],
            "checkpoint_embedding_keys": [key for key in persisted if "embed_tokens" in key or "lm_head" in key],
            "logits_restored": torch.allclose(original_logits, restored_logits),
            "max_logit_error_after_reload": (original_logits-restored_logits).abs().max().item(),
        })
output = scratch / "receipt.json"
output.write_text(json.dumps(results, indent=2) + "\n")
print(json.dumps(results, indent=2))
