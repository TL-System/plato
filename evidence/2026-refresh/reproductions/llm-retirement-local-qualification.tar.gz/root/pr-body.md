Retire the Nanochat and LeRobot/SmolVLA integrations and provide a reproducible Qwen3-0.6B-Base federated LoRA example through Plato's existing Hugging Face backend.

The retired code, configs, tests, runbooks, dependency provenance, and licenses remain in verified archives. Nanochat's pinned upstream source is preserved in an inert archive, and fresh checkouts no longer require its submodule. Retired backend selections produce migration guidance. Generic evaluation, adapter handling, and the other active examples remain supported.

The replacement pins the model and tokenizer to the same official Apache-2.0 checkpoint, uses a small local text fixture, and exchanges adapter weights. Fixes include consistent artifact revisions, independent CPU adapter snapshots, correct final accumulation-window scaling, and preserving Qwen's padded embedding table.

Validation will be recorded here after final integration:
- Archive byte/provenance and wheel/sdist containment checks.
- Python 3.13 focused and full integrated suites with an explicit collection-change ledger.
- Actual pretrained training, sample-weighted two-client adapter aggregation, frozen-base verification, and adapter reload.
- Normal reference-config server/client execution and clean shutdown.
- Strict documentation build and link checks.

The small data fixture validates integration and reproducibility; it is not a training-quality benchmark. Python 3.13 remains the development and CI target.
