"""Audit actual integrated runtime artifacts using the accepted independent oracle."""
import hashlib
import json
import random
from fractions import Fraction
from pathlib import Path
import numpy as np
import torch

mandatory = True
runtime_dir = Path("/tmp/plato-llm-integration/run-mandatory/pytest-tmp")
root = runtime_dir
runtime_records=[]
runtime_duplicate_paths=[]
seen_runtime_hashes=set()
fedavg=None
for p in sorted(runtime_dir.rglob("result.json")):
    d=json.loads(p.read_text())
    if not isinstance(d,dict) or "processes" not in d or "events" not in d:
        continue
    digest=hashlib.sha256(p.read_bytes()).hexdigest()
    if digest in seen_runtime_hashes:
        runtime_duplicate_paths.append(str(p.relative_to(root)))
        continue
    seen_runtime_hashes.add(digest)
    assert not d["survivors"],p
    rec=dict(path=str(p.relative_to(root)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),case=d.get("case","feddyn_entrypoint"),returncode=d["returncode"],timed_out=d["timed_out"],forced=d["forced"],survivors=d["survivors"])
    if "case" not in d or d.get("case")=="socket_round":
        assert d["returncode"]==0 and not d["timed_out"] and not d["forced"],p
    if d.get("case")=="socket_round":
        received=[e for e in d["events"] if e["event"]=="server_received"]
        aggregate=next(e["weights"] for e in d["events"] if e["event"]=="server_aggregate")
        assert sorted(e["samples"] for e in received)==[2,6]
        errors={}
        for key,actual in aggregate.items():
            expected=sum(np.asarray(e["weights"][key],dtype=np.float64)*e["samples"] for e in received)/8
            error=float(np.max(np.abs(np.asarray(actual)-expected)))
            assert error<=1e-6,(key,error)
            errors[key]=error
        fedavg=dict(samples=[e["samples"] for e in received],max_absolute_error=max(errors.values()),per_key_error=errors,natural_completion=True)
    runtime_records.append(rec)
if mandatory:
    assert len(runtime_records)==55,len(runtime_records)
    assert sum(r["case"]=="feddyn_entrypoint" for r in runtime_records)==7
    assert fedavg is not None

def load(p):
    return torch.load(p,weights_only=True,map_location="cpu")
def equal(a,b):
    if type(a) is not type(b):
        return False
    if isinstance(a,torch.Tensor):
        return a.dtype==b.dtype and a.shape==b.shape and torch.equal(a,b)
    if isinstance(a,np.ndarray):
        return a.dtype==b.dtype and np.array_equal(a,b)
    if isinstance(a,dict):
        return a.keys()==b.keys() and all(equal(a[k],b[k]) for k in a)
    if isinstance(a,(list,tuple)):
        return len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
    return a==b
scalar=[]
for parent in sorted(runtime_dir.glob("test_actual_shipped_run_resume[0-9]*")):
    # Pytest parameter index0 is uniform, index1 sample; derive from saved bundle.
    first_bundle=load(parent/"control/run/committed-1.pth")
    mode=first_bundle["config"]["weighting"]
    assert first_bundle["config"]["base_alpha"]==0.1 and first_bundle["config"]["lr"]==0.1
    assert first_bundle["config"]["population"]==10 and first_bundle["config"]["per_round"]==2
    x=Fraction(2);history=[Fraction(0)]*10;selector=random.Random(17)
    rows=[]
    for round_id in range(1,5):
        selected=selector.sample(list(range(1,11)),2)
        endpoints={}
        for i in selected:
            y=x
            alpha=Fraction(1,10) if mode=="uniform" else Fraction(11,20*i)
            for _ in range(2):
                y-=Fraction(1,10)*(y-i+alpha*(y-x+history[i-1]))
            endpoints[i]=y
            history[i-1]+=y-x
        x=sum(endpoints.values())/2+sum(history)/10
        directories=[parent/"control/run",parent/("split/first" if round_id<=2 else "split/resumed")]
        for directory in directories:
            actual=load(directory/f"committed-{round_id}.pth")
            incoming=load(directory/f"received-{round_id}.pth")
            assert incoming["selected"]==selected
            assert abs(actual["model"]["theta"].item()-float(x))<=1e-12
            for i,h in enumerate(history,1):
                assert abs(actual["histories"][i]["theta"].item()-float(h))<=1e-12
            for payload in incoming["payloads"]:
                assert type(payload[1]["client_id"]) is int
                assert abs(payload[0]["theta"].item()-float(endpoints[payload[1]["client_id"]]))<=1e-12
        if round_id>=3:
            a,b=(load(directory/f"committed-{round_id}.pth") for directory in directories)
            assert all(equal(a[k],b[k]) for k in ("model","histories","counts","committed_round","rng"))
        rows.append(dict(round=round_id,selected=selected,cloud_exact=str(x),cloud=float(x),histories_exact=list(map(str,history))))
    saved=load(parent/"split/first/committed-2.pth")
    start=load(parent/"split/resumed/start.pth")
    assert start["round"]==2 and start["pending"] is None and equal(saved["rng"],start["rng"])
    scalar.append(dict(mode=mode,rows=rows,full_cpu_rng_resume_equal=True))
if mandatory:
    assert sorted(r["mode"] for r in scalar)==["sample","uniform"],scalar

result = dict(status="PASS_ACTUAL_INTEGRATED_RUNTIME_AUDIT",
              runtime_observations=runtime_records,
              runtime_duplicate_paths=runtime_duplicate_paths,
              fedavg=fedavg, feddyn_scalar=scalar)
Path("/tmp/plato-llm-integration/runtime-audit.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps(dict(status=result["status"], records=len(runtime_records), fedavg=fedavg)))
