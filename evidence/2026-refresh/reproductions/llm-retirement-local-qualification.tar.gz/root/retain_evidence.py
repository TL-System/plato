"""Retain bounded LLM retirement qualification records and runtime payloads."""
import hashlib
import json
from pathlib import Path
import tarfile

base = Path('/tmp/plato-llm-integration')
selected = {}
text_suffixes = {'.json', '.log', '.py', '.txt', '.toml', '.xml', '.md'}
excluded = {'site', 'dist', 'huggingface', '__pycache__', '.git', 'typing-baseline-source',
            'staging-fixture-source', 'staging-fixture-output', 'ci-artifacts',
            'pytest-tmp', 'pytest-runtime', 'runtime', 'model-cache', 'cache'}

def add(path, name):
    if path.is_file() and not path.is_symlink():
        assert name not in selected or selected[name] == path
        selected[name] = path

for label, directory in [
    ('retirement-review', Path('/tmp/plato-retirement-review')),
    ('qwen-review1', Path('/tmp/plato-qwen-review')),
    ('qwen-review2', Path('/tmp/plato-qwen-review2')),
    ('qwen-author', Path('/tmp/plato-qwen-validation')),
    ('docs-review', Path('/tmp/plato-llm-docs-review')),
    ('integration-checks', base / 'checks'),
]:
    for path in sorted(directory.rglob('*')):
        relative = path.relative_to(directory)
        if not any(part in excluded for part in relative.parts) and path.suffix in text_suffixes:
            if path.is_file() and path.stat().st_size <= 1024 * 1024:
                add(path, label + '/' + relative.as_posix())

for profile in ['base', 'mandatory']:
    for path in (base / ('run-' + profile)).iterdir():
        if path.is_file():
            add(path, 'final-' + profile + '/' + path.name)
    partial = base / 'preliminary-d3569ec' / ('run-' + profile)
    for path in partial.iterdir():
        if path.is_file():
            add(path, 'interrupted-preliminary-' + profile + '/' + path.name)

runtime = json.loads((base / 'runtime-audit.json').read_text())
runtime_root = base / 'run-mandatory/pytest-tmp'
parents = set()
for record in runtime['runtime_observations']:
    path = runtime_root / record['path']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == record['sha256']
    parents.add(Path(record['path']).parts[0])
for parent in sorted(parents):
    for path in sorted((runtime_root / parent).rglob('*')):
        add(path, 'actual-runtime/' + path.relative_to(runtime_root).as_posix())

for path in base.iterdir():
    if path.is_file() and path.suffix in text_suffixes and path.stat().st_size <= 1024 * 1024:
        add(path, 'root/' + path.name)

receipt = Path('/tmp/plato-refresh-worktrees/retire-llm-backends/evidence/2026-refresh/llm-retirement-validation.json')
def referenced(value):
    if isinstance(value, dict):
        for child in value.values():
            referenced(child)
    elif isinstance(value, list):
        for child in value:
            referenced(child)
    elif isinstance(value, str) and value.startswith('/tmp/plato-retirement-'):
        path = Path(value)
        if path.is_file() and path.suffix in text_suffixes:
            add(path, 'retirement-author/' + path.name)
referenced(json.loads(receipt.read_text()))

artifact = base / 'llm-retirement-local-qualification.tar.gz'
rows = []
with tarfile.open(artifact, 'w:gz') as archive:
    for name, path in sorted(selected.items()):
        info = archive.gettarinfo(str(path), arcname=name)
        assert info.isfile()
        info.uid = info.gid = 0
        info.uname = info.gname = ''
        with path.open('rb') as incoming:
            archive.addfile(info, incoming)
        rows.append(dict(path=name, source=str(path), bytes=path.stat().st_size,
                         sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
with tarfile.open(artifact) as archive:
    assert len(archive.getmembers()) == len(rows)
    for row in rows:
        assert hashlib.sha256(archive.extractfile(row['path']).read()).hexdigest() == row['sha256']
manifest = dict(artifact=artifact.name, bytes=artifact.stat().st_size,
                sha256=hashlib.sha256(artifact.read_bytes()).hexdigest(), files=rows,
                exclusions='Environments, downloaded model weights/caches, generated docs/distributions, bulk unit binaries and bytecode. Actual core runtime payloads/checkpoints are retained; Qwen model identity, source, commands, logs and numerical receipts reproduce its bounded qualification.')
(base / 'llm-retirement-local-qualification-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({k: v for k, v in manifest.items() if k != 'files'}))
print('Retained files:', len(rows))
