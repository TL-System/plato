"""Run an isolated integrated profile and retain its exact source and results."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

root = Path('/tmp/plato-refresh-worktrees/llm-integrated')
scratch = Path('/tmp/plato-llm-integration')
profile = sys.argv[1]
assert profile in {'base', 'mandatory'}
out = scratch / ('run-' + profile)
out.mkdir(exist_ok=True)
python = scratch / (profile + '-313') / 'bin/python'
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', HF_HUB_OFFLINE='1',
           HF_DATASETS_OFFLINE='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
           TOKENIZERS_PARALLELISM='false', CUDA_VISIBLE_DEVICES='')

def snapshot():
    paths = subprocess.check_output(['git', 'ls-files', '-z'], cwd=root).decode().split('\0')
    return {p: hashlib.sha256((root / p).read_bytes()).hexdigest()
            for p in paths if p and (root / p).is_file()}

before = snapshot()
(out / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
commands = [
    [str(python), '-m', 'pytest', 'tests', '--collect-only',
     '--test-profile=' + profile, '-q'],
    [str(python), '-m', 'pytest', 'tests', '--test-profile=' + profile, '-ra',
     '--basetemp=' + str(out / 'pytest-tmp'), '--junitxml=' + str(out / 'tests.xml')],
]
if profile == 'base':
    commands[1] += ['-m', 'not runtime']
else:
    commands[1] += ['--cov=plato', '--cov-report=term',
                    '--cov-report=json:' + str(out / 'coverage.json')]
results = []
for label, command in zip(['collection', 'suite'], commands):
    start = time.monotonic()
    with (out / (label + '.log')).open('w') as log:
        try:
            completed = subprocess.run(command, cwd=root, env=env, stdout=log,
                                       stderr=subprocess.STDOUT, timeout=3000)
            code = completed.returncode
        except subprocess.TimeoutExpired:
            code = 'timeout'
    results.append(dict(label=label, command=command, returncode=code,
                        seconds=time.monotonic() - start))
    if code != 0:
        break
after = snapshot()
changes = sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))
cases = list(ET.parse(out / 'tests.xml').getroot().iter('testcase')) if (out / 'tests.xml').exists() else []
counts = {kind: sum(c.find(kind) is not None for c in cases)
          for kind in ['failure', 'error', 'skipped']}
receipt = dict(profile=profile, utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               results=results, tracked_source_changes=changes, junit_cases=len(cases),
               junit_counts=counts,
               passed=len(cases) - sum(counts.values()),
               source_manifest_sha256=hashlib.sha256((out / 'source-before.json').read_bytes()).hexdigest())
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
sys.exit(0 if len(results) == 2 and all(r['returncode'] == 0 for r in results) and not changes else 1)
