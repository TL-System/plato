"""Verify complete integrated collections, execution identities and notices."""
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

root = Path('/tmp/plato-llm-integration')
previous = json.loads(Path('/tmp/plato-phase2-linux/corrected-313/root-audit.json').read_text())
runtime = next(p for p in previous['profiles'] if p['profile'] == 'runtime')
runtime_ids = {c['classname'] + '::' + c['name'] for c in runtime['cases']}
assert len(runtime_ids) == 51

def identity(node):
    location, name = node.rsplit('::', 1)
    return location.replace('/', '.').replace('.py', '').replace('::', '.') + '::' + name

profiles = []
for profile, collected, expected_passed in [('mandatory', 1333, 1333), ('base', 1326, 1275)]:
    out = root / ('run-' + profile)
    receipt = json.loads((out / 'receipt.json').read_text())
    assert all(r['returncode'] == 0 for r in receipt['results']), receipt
    assert not receipt['tracked_source_changes'], receipt
    source = json.loads((out / 'source-before.json').read_text())
    assert all(hashlib.sha256((Path('/tmp/plato-refresh-worktrees/llm-integrated') / p).read_bytes()).hexdigest() == digest
               for p, digest in source.items())
    collection_log = (out / 'collection.log').read_text()
    nodes = [line for line in collection_log.splitlines() if line.startswith('tests/') and '.py::' in line]
    assert len(nodes) == len(set(nodes)) == collected, (profile, len(nodes))
    expected = {identity(node) for node in nodes}
    if profile == 'base':
        assert runtime_ids <= expected
        expected -= runtime_ids
    cases = list(ET.parse(out / 'tests.xml').getroot().iter('testcase'))
    assert not any(c.find('failure') is not None or c.find('error') is not None for c in cases)
    skips = [dict(case=c.attrib, reason=c.find('skipped').attrib) for c in cases if c.find('skipped') is not None]
    actual = {c.attrib.get('classname', '') + '::' + c.attrib['name'] for c in cases if c.find('skipped') is None}
    assert actual == expected and len(actual) == expected_passed, (profile, sorted(expected - actual), sorted(actual - expected))
    if profile == 'mandatory':
        assert not skips
        assert runtime_ids <= actual
    else:
        assert len(skips) == 1 and skips[0]['case']['name'] == 'tests.trainers.test_dp_data_loader_strategy', skips
        assert 'base profile optional dp: opacus not installed' in (out / 'suite.log').read_text()
    log = (out / 'suite.log').read_text()
    counts = re.findall(r'(\d+) warnings?', log.split('short test summary info')[-1])
    profiles.append(dict(profile=profile, collected=collected, passed=expected_passed,
                         skips=skips, warnings=int(counts[-1]) if counts else 0,
                         source_invariance=True, exact_execution_identity=True,
                         receipt_sha256=hashlib.sha256((out / 'receipt.json').read_bytes()).hexdigest()))
result = dict(status='PASS_COMPLETE_INTEGRATED_SUITE_AUDIT', profiles=profiles,
              runtime_nodes_unchanged=51,
              limitation='Actual runtime payload/numerical/process records are audited separately.')
(root / 'suite-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
