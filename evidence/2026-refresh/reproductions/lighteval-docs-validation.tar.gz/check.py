from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import hashlib,json,os,re,shlex,subprocess,tomllib
root=Path.cwd();base='c1bdae78456b6a8b16d2b78d16ab6ec973067b06';tmp=Path('/tmp/plato-lighteval-docs-validation');site=tmp/'site'
files=subprocess.check_output(['git','diff','--name-only',base],text=True).splitlines()
files=[p for p in files if p.startswith('docs/') and p.endswith('.md')]
class HTML(HTMLParser):
 def __init__(self,path):super().__init__();self.links=[];self.ids=set();self.feed(path.read_text())
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if a.get('id'):self.ids.add(a['id'])
  if tag=='a' and a.get('href'):self.links.append(a['href'])
links=0;errors=[];commands=[]
for file in files:
 page=site/Path(file).relative_to('docs/docs').with_suffix('')/'index.html'
 assert page.exists()
 for href in HTML(page).links:
  u=urlsplit(href)
  if u.scheme or u.netloc:continue
  target=page if not u.path else (site/unquote(u.path).lstrip('/') if u.path.startswith('/') else page.parent/unquote(u.path))
  target=target.resolve()
  if target.is_dir():target/='index.html'
  links+=1
  if not target.exists():errors.append([file,href,'missing target'])
  elif u.fragment and target.suffix=='.html' and unquote(u.fragment) not in HTML(target).ids:errors.append([file,href,'missing anchor'])
 for line in Path(file).read_text().splitlines():
  if not line.startswith('uv '):continue
  args=shlex.split(line)
  if 'llm_eval' in args or any('smollm2_135m.toml' in x or 'tests/llm_eval' in x for x in args):
   assert '--locked' in args and args[args.index('--extra')+1]=='llm_eval'
   if 'nltk.downloader' in args:assert args[-2:]==['punkt','punkt_tab']
   if 'pytest' in args:
    target=args[args.index('pytest')+1];assert Path(target).exists()
    group=args[args.index('--group')+1]
    assert group==('test-model-search' if target=='tests' else 'test')
    if target=='tests/llm_eval/test_lighteval_runtime.py':assert 'model_config' in Path(target).read_text()
   if '--config' in args:assert Path(args[args.index('--config')+1]).exists()
   commands.append({'file':file,'command':line,'check':'Syntax/extra/group/resource/target checked; runtime not executed.'})
assert not errors
metadata=tomllib.loads(Path('pyproject.toml').read_text())
assert 'xxhash>=3.8.1,<4' in metadata['project']['optional-dependencies']['llm_eval']
assert {'include-group':'test'} in metadata['dependency-groups']['test-model-search']
assert any(s.startswith('ptflops') for s in metadata['dependency-groups']['test-model-search'] if isinstance(s,str))
dryruns=[]
for name,flags,expected in [('eval',['--extra','llm_eval'],0),('eval-test',['--extra','llm_eval','--group','test'],0),('eval-combined',['--extra','llm_eval','--group','test-model-search'],0),('conflicting-all-extras',['--all-extras'],2)]:
 cmd=['uv','sync','--locked','--dry-run','--python','3.13',*flags]
 env={**os.environ,'UV_PROJECT_ENVIRONMENT':str(tmp/(name+'-env'))}
 r=subprocess.run(cmd,env=env,text=True,capture_output=True)
 log=r.stdout+r.stderr;(tmp/(name+'.log')).write_text(log)
 assert r.returncode==expected,(cmd,r.returncode,log)
 if expected==0:assert 'xxhash==3.8.1' in log
 else:assert 'incompatible' in log and 'ssl' in log and 'llm-eval' in log
 dryruns.append({'name':name,'command':cmd,'returncode':r.returncode,'log_sha256':hashlib.sha256(log.encode()).hexdigest(),'compatible_xxhash_selected':expected==0})
protected=['docs/docs/mlx.md','docs/docs/examples/case-studies/6. Qwen3 Federated LoRA.md','configs/HuggingFace/fedavg_qwen3_06b_lora.toml','pyproject.toml','uv.lock','.github/workflows/pytorch_tests.yml']
protected+=subprocess.check_output(['git','ls-files','archives','examples/outdated'],text=True).splitlines()
for p in protected:assert Path(p).read_bytes()==subprocess.check_output(['git','show',base+':'+p]),p
result={'files':files,'rendered_links_checked':links,'errors':errors,'evaluator_commands':commands,'dependency_dryruns':dryruns,'protected_files_unchanged':len(protected),'profile_status':'Accepted plan only; actual profile implementation, final source rebinding and integrated execution not validated by this documentation task.','limits':'No model training, NLTK downloads, benchmark datasets or runtime test collection executed.'}
(tmp/'checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'links':links,'errors':errors,'commands':len(commands),'dryruns':len(dryruns),'protected':len(protected)},indent=2))
