import hashlib
import json
import re
import subprocess
import textwrap
import time
from collections import Counter
from pathlib import Path

root=Path("/tmp/plato-refresh-worktrees/phase2-final-validation")
out=Path("/tmp/plato-phase2-integration/final-quality")
out.mkdir()
records=[]
def run(name, command, cwd=root, allowed=(0,)):
    log=out/(name+".log");start=time.monotonic()
    with log.open("wb") as f:
        p=subprocess.run(command,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    records.append(dict(name=name,argv=command,cwd=str(cwd),exit_code=p.returncode,seconds=time.monotonic()-start,log=str(log),sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
    assert p.returncode in allowed,(name,p.returncode)
    return log,p.returncode
run("lock",["uv","lock","--check"])
run("diff",["git","diff","--check"])
run("ruff",["/tmp/plato-phase2-integration/final-mandatory-313/bin/ruff","check",".","--select","I"])
workflow=(root/".github/workflows/pytorch_tests.yml").read_text()
marker='          python - "$ty_status" <<\x27PY\x27'
guard=textwrap.dedent(workflow.split(marker,1)[1].split("\n          PY",1)[0]).strip()+"\n"
guard_path=out/"ci-owned-typing-guard.py";guard_path.write_text(guard)
changed=set(subprocess.check_output(["git","diff","--name-only","fda60becedfa6236c11d415b87a868b52789a41e","HEAD"],cwd=root,text=True).splitlines())
classifications={}
for version in ("313","314"):
    env=Path("/tmp/plato-phase2-integration/final-mandatory-"+version)/"bin"
    log,status=run("ty-full-"+version,[str(env/"ty"),"check","--python",str(env/"python"),"--output-format","concise"],allowed=(0,1))
    stage=out/("ci-"+version);(stage/"ci-artifacts").mkdir(parents=True)
    (stage/"ci-artifacts/ty.log").write_bytes(log.read_bytes())
    run("ci-typing-guard-"+version,[str(env/"python"),str(guard_path),str(status)],cwd=stage)
    run("ty-owned-"+version,[str(env/"ty"),"check","--python",str(env/"python"),"examples/customized_client_training/feddyn","plato/trainers/strategies/algorithms/feddyn_strategy.py","tests/trainers/test_dp_data_loader_strategy.py"])
    rows=[]
    for m in re.finditer(r"^(.+?):(\d+):(\d+): (?:error|warning)\[([^]]+)\] (.*)$",log.read_text(),re.M):
        file,line,column,code,message=m.groups()
        if file.startswith(("plato/models/dvit/","plato/models/t2tvit/","external/")):group="pinned_vendor"
        elif file.startswith("archives/"):group="inactive_archive"
        elif file.startswith("evidence/"):group="retained_reproduction"
        elif file.startswith("tests/"):group="tests_changed" if file in changed else "tests_unchanged"
        else:group="active_source_changed" if file in changed else "active_source_unchanged"
        rows.append(dict(file=file,line=int(line),column=int(column),code=code,message=message,group=group))
    groups=dict(Counter(r["group"] for r in rows))
    assert not groups.get("active_source_changed"),groups
    classifications[version]=dict(total=len(rows),groups=groups,diagnostics=rows,ci_owned_gate="PASS",scoped_feddyn_and_DP="PASS",global_clean_claim=False)
(out/"typing-classification.json").write_text(json.dumps(classifications,indent=2)+"\n")
result=dict(commit="204082f53d0fd335e57712ac981ad7d40bff19dd",status="PASS_SCOPED_CHECKS_WITH_CLASSIFIED_TYPING_RESIDUALS",commands=records,exact_CI_guard_sha256=hashlib.sha256(guard.encode()).hexdigest(),classification="typing-classification.json")
(out/"receipt.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(dict(status=result["status"],typing={k:dict(total=v["total"],groups=v["groups"]) for k,v in classifications.items()})))
