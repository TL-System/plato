"""Retain final qualification receipts and replay inputs, excluding environments."""
import hashlib
import json
import tarfile
from pathlib import Path

root = Path('/Users/bli/Playground/plato')
scratch = Path('/tmp/plato-phase2-integration')
out = root / 'evidence/2026-refresh/reproductions'
runs = [
    'mandatory-313-14436940f658', 'mandatory-314-dda37b8168f1',
    'base-313-1ed434509666', 'base-314-a8148428fe45',
]
selected = {}
def add(path, arc):
    assert path.is_file() and not path.is_symlink(), path
    selected[arc] = path

for name in runs:
    run = scratch / 'runs' / name
    receipt = json.loads((run/'receipt.json').read_text())
    audit = json.loads((run/'root-audit.json').read_text())
    assert receipt['status'] == 'EXECUTION_PASS_REQUIRES_ROOT_AUDIT'
    assert audit['status'] == 'PASS_ROOT_PROFILE_AUDIT'
    for p in run.iterdir():
        if p.is_file() and not p.is_symlink():
            add(p, 'runs/'+name+'/'+p.name)
    # Keep runtime payloads, configuration, event/process logs and small replay bundles.
    for result in (run/'tmp').rglob('result.json'):
        d = json.loads(result.read_text())
        if not isinstance(d, dict) or 'processes' not in d or 'events' not in d:
            continue
        for p in result.parent.rglob('*'):
            if p.is_file() and not p.is_symlink() and p.stat().st_size < 1_000_000:
                add(p, 'runs/'+name+'/'+str(p.relative_to(run)))
for name in ('final-quality', 'final-artifacts'):
    for p in (scratch/name).iterdir():
        if p.is_file() and not p.is_symlink():
            add(p, name+'/'+p.name)
for p in scratch.glob('final-*.json'):
    add(p,p.name)
add(scratch/'final-build.log','final-build.log')
for name in ('audit_final_profile.py','audit_source.py','run_integration_profile.py',
             'final_quality_checks.py','final_artifact_checks.py','integration-plan.json',
             'retain_final_qualification.py'):
    add(Path('/tmp/plato-phase2-root')/name, 'tools/'+name)
records = [dict(path=arc, original_path=str(p), bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())
           for arc,p in sorted(selected.items())]
bundle = out/'phase2-final-local-qualification.tar.gz'
with tarfile.open(bundle,'w:gz') as tar:
    for arc,p in sorted(selected.items()):
        tar.add(p,arcname=arc,recursive=False)
manifest = dict(source_commit='204082f53d0fd335e57712ac981ad7d40bff19dd',
                bundle=bundle.name,bundle_sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(),
                files=records, file_count=len(records), total_bytes=sum(r['bytes'] for r in records),
                exclusions=['virtual environments', 'built distribution archives (hashes retained)',
                            'large reproducible unit-test checkpoint fixtures'],
                runtime_retention='Actual result JSONs, process logs, configuration and sub-1 MB replay files.')
(out/'phase2-final-local-qualification-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='files'},indent=2))
