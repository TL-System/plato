import hashlib
import io
import json
import os
import subprocess
import tarfile
import time
from pathlib import Path

root=Path("/tmp/plato-refresh-worktrees/phase2-final-validation")
out=Path("/tmp/plato-phase2-integration/final-artifacts")
out.mkdir()
head="204082f53d0fd335e57712ac981ad7d40bff19dd"
wheel=next(Path("/tmp/plato-phase2-integration/final-dist").glob("*.whl"))
sdist=next(Path("/tmp/plato-phase2-integration/final-dist").glob("*.tar.gz"))
target=out/"installed-wheel"
records=[]
env=os.environ.copy()
env.update(PYTHONDONTWRITEBYTECODE="1",OMP_NUM_THREADS="1",OPENBLAS_NUM_THREADS="1",MKL_NUM_THREADS="1",HF_HUB_OFFLINE="1",HF_DATASETS_OFFLINE="1")
def run(name,command,cwd=out):
    log=out/(name+".log");start=time.monotonic()
    with log.open("wb") as f:
        p=subprocess.run(command,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    records.append(dict(name=name,argv=command,cwd=str(cwd),exit_code=p.returncode,seconds=time.monotonic()-start,log=str(log),sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
    assert p.returncode==0,(name,p.returncode,log)
py313="/tmp/plato-phase2-integration/final-mandatory-313/bin/python"
run("wheel-install",["uv","pip","install","--python",py313,"--target",str(target),"--no-deps",str(wheel)])
code="""
import sys,pathlib,json
sys.path.insert(0,sys.argv[1])
import plato,torch
from plato.serialization.safetensor import serialize_tree,deserialize_tree
from plato.utils.checkpoint_paths import checkpoint_name
assert pathlib.Path(plato.__file__).resolve().is_relative_to(pathlib.Path(sys.argv[1]).resolve())
original={"model":{"weight":torch.tensor([1.,2.])},"version":1,"alpha":0.1}
restored=deserialize_tree(serialize_tree(original))
assert type(restored["version"]) is int and type(restored["alpha"]) is float
torch.testing.assert_close(restored["model"]["weight"],original["model"]["weight"])
assert checkpoint_name("org/model")!=checkpoint_name("org_model")
print(json.dumps({"package":plato.__file__,"metadata_types":["int","float"],"tensor_roundtrip":"PASS","checkpoint_collision":"PASS"}))
"""
archive=out/"source-without-git";archive.mkdir()
data=subprocess.check_output(["git","archive",head],cwd=root)
with tarfile.open(fileobj=io.BytesIO(data)) as t:t.extractall(archive,filter="data")
assert not (archive/".git").exists()
nodes=["tests/trainers/test_review_training_boundaries.py::test_actual_accepted_b_feddyn_writer_migration","tests/trainers/test_feddyn_strategy.py::test_legacy_actual_writer_weight_bias_and_corruption_are_inspection_only"]
for version in ("313","314"):
    python="/tmp/plato-phase2-integration/final-mandatory-"+version+"/bin/python"
    run("wheel-import-"+version,[python,"-I","-B","-c",code,str(target)])
    run("archive-"+version,[python,"-B","-m","pytest",*nodes,"-q","-p","no:cacheprovider","--basetemp="+str(out/("archive-tmp-"+version)),"--junitxml="+str(out/("archive-"+version+".xml"))],cwd=archive)
result=dict(commit=head,status="PASS_FINAL_ARTIFACT_AND_ARCHIVE_CHECKS",commands=records,artifacts={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in (wheel,sdist)},git_source_archive_sha256=hashlib.sha256(data).hexdigest(),no_git_directory=True,scope="Isolated target wheel uses each fresh locked mandatory environment for dependencies; no independent PyPI dependency-resolution claim. Actual legacy writer/reader cases run from exact source archive without Git on both versions.")
(out/"receipt.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(dict(status=result["status"],artifacts=result["artifacts"])))
