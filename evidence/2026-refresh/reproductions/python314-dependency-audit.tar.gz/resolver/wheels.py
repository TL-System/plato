import concurrent.futures,json,pathlib,subprocess
out=pathlib.Path("/tmp/plato-python314-blockers")
(out/"lerobot_training_smolvla_only.in").write_text("lerobot[training,smolvla]==0.6.1\n")
(out/"lerobot_latest_only.in").write_text("lerobot==0.6.1\n")
profiles=[p.stem for p in out.glob("*.in") if not p.stem.startswith("lerobot")]+["lerobot_latest_only","lerobot_training_smolvla_only"]
def run(j):
 name,py,platform=j
 stem=f"wheels-{name}-py{py}-{platform}"
 cmd=["uv","pip","compile",str(out/(name+".in")),"--python-version",py,*(["--python-platform",platform] if platform!="native" else []),"--only-binary",":all:","--overrides",str(out/"override.txt"),"--no-header","--no-annotate","-o",str(out/(stem+".txt"))]
 p=subprocess.run(cmd,cwd="/Users/bli/Playground/plato",text=True,capture_output=True)
 (out/(stem+".log")).write_text("COMMAND: "+" ".join(cmd)+"\n"+p.stdout+p.stderr)
 return dict(profile=name,python=py,platform=platform,code=p.returncode,log=stem+".log")
jobs=[(name,py,platform) for name in profiles for py in ["3.13","3.14"] for platform in ["native","x86_64-unknown-linux-gnu"]]
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool: results=list(pool.map(run,jobs))
(out/"wheel-results.json").write_text(json.dumps(results,indent=2))
for r in results:
 if r["code"]: print(r)
