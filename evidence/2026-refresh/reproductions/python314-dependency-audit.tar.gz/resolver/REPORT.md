# Dependency audit (2026-10-03; initial working-tree manifests)

This audit is read-only for the repository and its environments. Requirements, resolution outputs, logs, and independent source-build/install environments are under this directory. Root requirements were extracted from pyproject.toml and recursively expanded for each workspace dependency on plato-learn. The root uv override nltk==3.10.3 was preserved. SSL and llm_eval were resolved separately because the declared ANTLR incompatibility is deliberate. These independent resolutions do not claim all profiles can coexist.

## Manifest profiles

Root, every named extra (mpc, rl, dp, mlx, nanochat, ssl, llm_eval), and all 15 workspace member profiles resolve on Python 3.13 and 3.14 on the current native Apple Silicon host (Darwin27/macOS27). All profiles also resolve on Python3.14 on Linux x86_64 with glibc>=2.35, including MLX. See results.json and followup-results.json plus profile*.in and corresponding logs.

Explicit uv platform aarch64-apple-darwin defaults macOS13, rejecting torch2.14.1 macOS14 wheels on BOTH Python versions. Explicit x86_64-unknown-linux-gnu defaults glibc2.28, rejecting MLX0.32.3 glibc2.35 wheels on BOTH Python versions. These are platform baselines, not Python3.14 blockers; suitable native/macOS14+ or Linux2.35+ platforms resolve.

--only-binary all exposes zstd1.5.7.2 missing macOS cp314 published wheels. This is a source-build requirement, not a blocker: the preexisting isolated3.14 root environment contains its built cp314-cp314-macosx_27_0_arm64 wheel. Lighteval has source-only rouge-score/docopt etc on both Python versions. Ordinary resolution allows source distributions. See wheel-results.json and wheels-*.log.

## LeRobot (outside root manifest)

Latest LeRobot0.6.1 caps numpy>=2,<2.3,torch>=2.7,<2.12,torchvision>=0.22,<0.27. Dataset/training extras cap datasets<5; SmolVLA caps transformers<5.6. Root requires numpy>=2.5.3,torch>=2.14.1,torchvision>=0.29.1,datasets>=5.0.1,transformers>=5.18.0. Combined root+LeRobot profiles cannot resolve on EITHER3.13 OR3.14, on macOS and Linux. See lerobot_with_root*.log and lerobot_smolvla_with_root*.log. This is a general dependency conflict.

LeRobot0.6.1 alone resolves Python3.14 by selecting NumPy2.2.6 source,torch2.11.0,torchvision0.26.0. Restricting NumPy to wheels produces a Python-specific failure: available NumPy<2.3 has no cp314 wheels;3.13 passes. This must NOT be described as a hard Python3.14 blocker. Actual NumPy2.2.6 source build on Python3.14.8 succeeded in28.80s, then import,matrix multiply,SVD,random generation passed. See numpy314-build.log and numpy314-smoke.log.

Installing lerobot[training,smolvla]==0.6.1 into that independent Python3.14 environment SUCCEEDED. Selected versions: numpy2.2.6,torch2.11.0,torchvision0.26.0,datasets4.8.5,transformers5.5.4,av15.1.0,torchcodec0.11.1. See lerobot314-install.log and lerobot314-import.log. The import checks do not download pretrained models or establish full robotics training correctness.

## Upstream evidence

- https://github.com/huggingface/lerobot/blob/v0.6.1/pyproject.toml (release constraints)
- https://pypi.org/pypi/lerobot/json (full saved metadata-lerobot.json)
- https://numpy.org/doc/2.3/release/2.2.6-notes.html (official supported Python3.10–3.13; actual source build still succeeds3.14)
- https://numpy.org/doc/stable/release/2.3.2-notes.html (first cp314 wheels in2.3.x)
- https://pypi.org/project/zstd/1.5.7.2/ (published wheels)

Current upstream full JSON metadata is saved as metadata-*.json for key packages. Existing classifiers alone were never used as a blocker.
