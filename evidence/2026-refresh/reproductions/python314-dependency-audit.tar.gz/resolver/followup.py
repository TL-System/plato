import concurrent.futures,json,pathlib,subprocess,urllib.request
out=pathlib.Path("/tmp/plato-python314-blockers")
def run(j):
 name,py,platform,extras=j
 stem=f"followup-{name}-py{py}-{platform}"
 cmd=["uv","pip","compile",str(out/(name+".in")),"--python-version",py,*(["--python-platform",platform] if platform!="native" else []),"--overrides",str(out/"override.txt"),"--no-header","--no-annotate",*extras,"-o",str(out/(stem+".txt"))]
 p=subprocess.run(cmd,cwd="/Users/bli/Playground/plato",text=True,capture_output=True)
 (out/(stem+".log")).write_text("COMMAND: "+" ".join(cmd)+"\n"+p.stdout+p.stderr)
 return dict(profile=name,python=py,platform=platform,code=p.returncode,log=stem+".log")
jobs=[(p.stem,"3.14","x86_64-manylinux_2_35",[]) for p in out.glob("*.in") if not p.stem.startswith("lerobot")]+[("extra_mlx","3.13","x86_64-manylinux_2_35",[])]+[("lerobot_latest_only",py,p,["--only-binary","numpy"]) for py in ["3.13","3.14"] for p in ["native","x86_64-manylinux_2_35"]]+[("lerobot_training_smolvla_only",py,p,["--only-binary","numpy,av,torchcodec"]) for py in ["3.13","3.14"] for p in ["native","x86_64-manylinux_2_35"]]
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool: results=list(pool.map(run,jobs))
(out/"followup-results.json").write_text(json.dumps(results,indent=2))
for r in results: print(r)
for package in ["numpy","av","torchcodec","zstd","mlx"]:
 d=json.load(urllib.request.urlopen("https://pypi.org/pypi/"+package+"/json"));(out/("metadata-"+package+".json")).write_text(json.dumps(d,indent=2))
 print(package,d["info"]["version"],d["info"]["requires_python"])
 print("cp314",[v["filename"] for v in d["urls"] if "cp314" in v["filename"]])
