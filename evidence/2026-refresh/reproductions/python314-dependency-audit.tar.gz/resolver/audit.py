import concurrent.futures, json, pathlib, re, subprocess, tomllib
root=pathlib.Path("/Users/bli/Playground/plato")
out=pathlib.Path("/tmp/plato-python314-blockers")
cfg=tomllib.loads((root/"pyproject.toml").read_text())
base=cfg["project"]["dependencies"]
extras=cfg["project"]["optional-dependencies"]
profiles={"root":base}
profiles.update({"extra_"+k:base+v for k,v in extras.items()})
for member in cfg["tool"]["uv"]["workspace"]["members"]:
 p=tomllib.loads((root/member/"pyproject.toml").read_text())["project"]
 deps=[]
 for d in p["dependencies"]:
  if d.startswith("plato-learn"):
   deps+=base
   m=re.search(r"\[([^]]+)\]",d)
   if m:
    for e in m[1].split(","): deps+=extras[e]
  else: deps.append(d)
 profiles["workspace_"+p["name"].lower()]=deps
profiles["lerobot_only"]=["lerobot"]
profiles["lerobot_with_root"]=[*base,"lerobot"]
profiles["lerobot_smolvla_with_root"]=[*base,"lerobot[smolvla]"]
(out/"override.txt").write_text("nltk==3.10.3\n")
for name,deps in profiles.items(): (out/(name+".in")).write_text("\n".join(dict.fromkeys(deps))+"\n")

def run(job):
 name,py,platform=job
 stem=f"{name}-py{py}-{platform}"
 cmd=["uv","pip","compile",str(out/(name+".in")),"--python-version",py,*(["--python-platform",platform] if platform!="native" else []),"--overrides",str(out/"override.txt"),"--no-header","--no-annotate","-o",str(out/(stem+".txt"))]
 p=subprocess.run(cmd,cwd=root,text=True,capture_output=True)
 (out/(stem+".log")).write_text("COMMAND: "+" ".join(cmd)+"\n"+p.stdout+p.stderr)
 return dict(profile=name,python=py,platform=platform,code=p.returncode,log=stem+".log")
jobs=[(name,py,platform) for name in profiles for py in ["3.13","3.14"] for platform in ["native","x86_64-unknown-linux-gnu"]]
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
 results=list(pool.map(run,jobs))
(out/"results.json").write_text(json.dumps(results,indent=2))
for r in results: print(r["profile"],r["python"],r["code"])
