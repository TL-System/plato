import json, pickle, sys
from pathlib import Path
import rustbpe, tiktoken
from plato.processors.nanochat_tokenizer import NanochatTokenizerProcessor
texts=['hello nanochat', 'hello Plato', 'café 世界 👋', 'line one\nline two']
p=NanochatTokenizerProcessor(train_corpus=texts*8,vocab_size=300,prepend_bos=False)
encoded=p.process(texts)
assert all(p._encoding.decode(ids)==s for ids,s in zip(encoded,texts))
path=Path('/tmp/plato-python314-native-probe/tokenizer.pkl')
with path.open('wb') as f: pickle.dump(p._encoding,f)
restored=NanochatTokenizerProcessor(tokenizer_path=path,prepend_bos=False)
assert restored.process(texts)==encoded
print(json.dumps({'python':sys.version,'rustbpe':rustbpe.__file__,'tiktoken':tiktoken.__version__,'texts':len(texts),'training_encoding_decoding_save_load':'PASS'}))
