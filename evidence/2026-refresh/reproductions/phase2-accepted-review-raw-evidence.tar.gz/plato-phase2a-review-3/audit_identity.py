"""Read-only identity, archival and retained-evidence audit."""

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

REPO = Path('/private/tmp/plato-refresh-worktrees/data')
SCRATCH = Path('/tmp/plato-phase2a-review-3')
ROOT = Path('/Users/bli/Playground/plato/evidence/2026-refresh')
BASE = 'fda60becedfa6236c11d415b87a868b52789a41e'
CANDIDATE = '150a48860b556eab1575178891577dd07dc6f06d'
IMPLEMENTATION = '49fe01e4787d3cb30ffaf82b59bacae932470453'
PRIOR = 'b728a5b71d0945828dcf288a39b796b1e0fb4ec7'


def command(cmd):
    result = subprocess.run(['/bin/zsh', '-lc', cmd], cwd=REPO,
                            env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'},
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            check=True)
    return result.stdout


def sha(value):
    return hashlib.sha256(value).hexdigest()


def record(path):
    path = Path(path)
    content = path.read_bytes()
    return {'path': str(path), 'bytes': len(content), 'sha256': sha(content)}


def compare_blobs(root):
    mismatches, gitlinks, count = [], [], 0
    for entry in command(f'git ls-tree -rz {CANDIDATE}').split(b'\0'):
        if not entry:
            continue
        metadata, encoded = entry.split(b'\t', 1)
        mode, kind, expected = metadata.decode().split()
        filename = encoded.decode()
        if kind == 'commit':
            gitlinks.append(filename)
            continue
        path = root / filename
        content = os.readlink(path).encode() if mode == '120000' else path.read_bytes()
        actual = hashlib.sha1(f'blob {len(content)}\0'.encode() + content).hexdigest()
        count += 1
        if actual != expected:
            mismatches.append({'path': filename, 'expected': expected, 'actual': actual})
    return {'tracked_non_gitlink_blobs': count, 'mismatches': mismatches,
            'gitlinks': gitlinks}


author = json.loads((REPO / 'evidence/2026-refresh/phase2a-validation.json').read_text())
audit = {
    'base_commit': BASE, 'base_tree': command(f'git rev-parse {BASE}^{{tree}}').decode().strip(),
    'candidate_commit': CANDIDATE,
    'candidate_tree': command(f'git rev-parse {CANDIDATE}^{{tree}}').decode().strip(),
    'implementation_commit': IMPLEMENTATION,
    'implementation_tree': command(f'git rev-parse {IMPLEMENTATION}^{{tree}}').decode().strip(),
    'observed_head': command('git rev-parse HEAD').decode().strip(),
    'observed_status': command('git status --porcelain=v1 --untracked-files=all').decode(),
    'base_to_candidate_binary_diff_sha256': sha(command(f'git diff --binary {BASE} {CANDIDATE}')),
    'base_to_implementation_binary_diff_sha256': sha(command(f'git diff --binary {BASE} {IMPLEMENTATION}')),
    'prior_to_implementation_binary_diff_sha256': sha(command(f'git diff --binary {PRIOR} {IMPLEMENTATION}')),
    'evidence_only_child_changed_paths': command(f'git diff-tree --no-commit-id --name-only -r {IMPLEMENTATION} {CANDIDATE}').decode().splitlines(),
    'base_to_candidate_name_status': command(f'git diff --name-status {BASE} {CANDIDATE}').decode().splitlines(),
    'candidate_blob_check': compare_blobs(REPO),
    'export_blob_check': compare_blobs(SCRATCH / 'candidate'),
    'inputs': {}, 'author_log_integrity': {}, 'archives': [],
}
for name in ['plan.md', 'plan-addendum.json', 'plan-review-3.json',
             'plan-addendum-acceptance.json', 'phase2a-review.json',
             'phase2a-root-probes.json', 'phase2a-review-2.json',
             'phase2a-root-base-validation.json']:
    audit['inputs'][name] = record(ROOT / name)
audit['inputs']['candidate_validation'] = record(REPO / 'evidence/2026-refresh/phase2a-validation.json')
audit['inputs']['AGENTS.md'] = record(REPO / 'AGENTS.md')
for section, directory, key in [('review_corrections', 'revision', 'raw_logs_sha256'),
                                 ('review2_corrections', 'revision2', 'retained_raw_artifacts_sha256')]:
    for filename, expected in author[section][key].items():
        path = Path('/tmp/plato-phase2a-lZqbqj') / directory / filename
        actual = record(path)
        audit['author_log_integrity'][directory + '/' + filename] = {
            **actual, 'expected_sha256': expected,
            'equal': actual['sha256'] == expected}
for path, expected in author['review2_corrections']['read_only_probe_sources_sha256'].items():
    audit['inputs'][path] = {**record(path), 'expected_sha256': expected,
                            'equal': record(path)['sha256'] == expected}
for original in command(f'git ls-tree -r --name-only {BASE} plato/datasources/datalib').decode().splitlines():
    relative = original.removeprefix('plato/datasources/datalib/')
    destination = 'archives/legacy_datalib/' + relative
    baseline = command(f'git show {BASE}:{original}')
    archived = (REPO / destination).read_bytes()
    audit['archives'].append({'original': original, 'archived': destination,
                              'equal': baseline == archived, 'sha256': sha(archived)})
baseline_license = command(f'git show {BASE}:LICENSE')
archive_license = (REPO / 'archives/legacy_datalib/LICENSE').read_bytes()
audit['archive_license'] = {'equal': baseline_license == archive_license,
                            'sha256': sha(archive_license)}
shared = ['pyproject.toml', 'uv.lock', '.python-version', 'tests/conftest.py']
audit['shared_metadata'] = {p: {**record(REPO / p),
    'unchanged_from_phase_base': command(f'git show {BASE}:{p}') == (REPO / p).read_bytes()}
    for p in shared}
audit['shared_runtime_changed'] = command(
    f'git diff --name-only {BASE} {CANDIDATE} -- plato/client.py plato/clients plato/servers plato/trainers .github').decode().splitlines()
audit['unchanged_since_review2'] = command(
    f'git diff --name-only {PRIOR} {CANDIDATE} -- plato/config.py plato/samplers plato/datasources/base.py plato/datasources/torchvision.py plato/utils/archive.py archives').decode().splitlines()
scan = subprocess.run(['/bin/zsh', '-lc',
    "rg -n --glob '*.py' 'plato\\.datasources\\.datalib|from .*datalib|import .*datalib|archives\\.legacy_datalib|from archives|import archives' plato tests examples"],
    cwd=REPO, capture_output=True, text=True)
assert scan.returncode in (0, 1), scan.stderr
audit['active_archive_reference_scan'] = {'command': scan.args, 'exit_code': scan.returncode,
                                         'matches': scan.stdout.splitlines()}
audit['author_identity_matches'] = {
    'implementation_tree': audit['implementation_tree'] == author['identity']['final_implementation_tree'],
    'base_diff': audit['base_to_implementation_binary_diff_sha256'] == author['identity']['baseline_to_final_binary_diff_sha256'],
    'prior_diff': audit['prior_to_implementation_binary_diff_sha256'] == author['identity']['previous_candidate_to_final_binary_diff_sha256'],
}
assert audit['observed_head'] == CANDIDATE and not audit['observed_status']
assert audit['evidence_only_child_changed_paths'] == ['evidence/2026-refresh/phase2a-validation.json']
assert all(audit['author_identity_matches'].values())
assert all(v['equal'] for v in audit['author_log_integrity'].values())
assert not audit['candidate_blob_check']['mismatches'] and not audit['export_blob_check']['mismatches']
assert len(audit['archives']) == 14 and all(v['equal'] for v in audit['archives'])
assert audit['archive_license']['equal']
assert all(v['unchanged_from_phase_base'] for v in audit['shared_metadata'].values())
assert not audit['shared_runtime_changed'] and not audit['unchanged_since_review2']
assert not audit['active_archive_reference_scan']['matches']
(SCRATCH / f'identity-{sys.argv[1]}.json').write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps({k: audit[k] for k in ['candidate_commit','candidate_tree','observed_status',
    'author_identity_matches','candidate_blob_check','export_blob_check']}, indent=2))
print('All retained correction logs, archived bytes, license and shared-file identities match.')
