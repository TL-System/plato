"""Assemble the sole root-owned review report from retained raw evidence."""

import datetime
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

SCRATCH = Path('/tmp/plato-phase2a-review-3')
REPORT = Path('/Users/bli/Playground/plato/evidence/2026-refresh/phase2a-review-3.json')
before = json.loads((SCRATCH / 'identity-before.json').read_text())
after = json.loads((SCRATCH / 'identity-after.json').read_text())
commands = json.loads((SCRATCH / 'commands.json').read_text())
finding = json.loads((SCRATCH / 'finding.json').read_text())
assert before == after


def file_record(path):
    content = path.read_bytes()
    return {'path': str(path), 'bytes': len(content),
            'sha256': hashlib.sha256(content).hexdigest()}


def pytest_result(prefix, version, command, exit_code):
    logfile = SCRATCH / f'logs/{prefix}-{version}.log'
    xmlfile = SCRATCH / f'logs/{prefix}-{version}.xml'
    tree = ET.parse(xmlfile).getroot()
    suites = [tree] if tree.tag == 'testsuite' else tree.findall('testsuite')
    count = lambda key: sum(int(s.attrib.get(key, 0)) for s in suites)
    text = logfile.read_text()
    result = {
        'command': command, 'working_directory': commands['working_directory'],
        'shell': commands['shell'], 'exit_code': exit_code,
        'tests': count('tests'), 'passed': count('tests') - count('errors') - count('failures') - count('skipped'),
        'failed': count('failures'), 'errors': count('errors'), 'skipped': count('skipped'),
        'warnings': 0, 'junit_seconds': sum(float(s.attrib.get('time', 0)) for s in suites),
        'summary': next(line.strip('= ') for line in reversed(text.splitlines())
                        if re.search(r'\d+ (passed|failed)', line) and line.startswith('=')),
        'log': file_record(logfile), 'junit': file_record(xmlfile),
        'failed_nodes': [c.attrib['name'] for c in tree.iter('testcase')
                         if c.find('failure') is not None or c.find('error') is not None],
    }
    assert 'warnings summary' not in text.lower()
    if prefix == 'base':
        assert '48 deselected' in text
        result['runtime_deselected'] = 48
        result['skip_reasons'] = [line for line in text.splitlines() if line.startswith('SKIPPED')]
    return result


validation = {}
for prefix, key, exit_code in [('focused', 'focused', 0), ('base', 'clean_base', 0),
                               ('independent', 'independent', 1),
                               ('default-negative', 'minimal_default_negative', 1)]:
    validation[prefix] = {version: pytest_result(prefix, version, commands[key][index], exit_code)
                         for index, version in enumerate(['3.13', '3.14'])}
assert all(r['passed'] == 226 for r in validation['focused'].values())
assert all(r['passed'] == 429 and r['skipped'] == 4 for r in validation['base'].values())
assert all(r['passed'] == 97 and r['failed'] == 2 for r in validation['independent'].values())
assert all(r['passed'] == 2 and r['failed'] == 2 for r in validation['default-negative'].values())

observations = {}
for version in ['3.13', '3.14']:
    paths = sorted({p.resolve() for p in (SCRATCH / f'default-negative-{version}-fixtures').glob('*/observed.json')})
    observations[version] = []
    for path in paths:
        data = json.loads(path.read_text())
        observations[version].append({
            **file_record(path), 'name': data['name'], 'requests': data['requests'],
            'successful_constructors': data['successful_constructors'],
            'completion_markers': data['completion_markers'],
            'errors': [{'type': e['type'], 'message': e['message']} for e in data['errors']],
        })
    assert len(observations[version]) == 4
finding['reproduction']['retained_observations'] = observations

identity = {
    **before,
    'candidate_head_at_start': before['observed_head'],
    'candidate_head_at_end': after['observed_head'],
    'candidate_status_at_start': '', 'candidate_status_at_end': after['observed_status'],
    'candidate_immutable': True,
    'exact_export': '/tmp/plato-phase2a-review-3/candidate',
    'export_command': 'git archive 150a48860b556eab1575178891577dd07dc6f06d | tar -xf - -C /tmp/plato-phase2a-review-3/candidate',
    'tracked_source_verification': 'All 943 tracked non-gitlink blobs match exact candidate Git object IDs in both original worktree and test export. Before/after audits and all input/log hashes are identical.',
    'gitlinks_limit': 'The three unrelated gitlinks are not initialized in the export. No submodule update or content review occurred.',
}
input_records = identity.pop('inputs')
author_logs = identity.pop('author_log_integrity')
archive_records = identity.pop('archives')
archive_license = identity.pop('archive_license')

report = {
    'schema_version': 1,
    'reviewer': 'plato-phase2a-review-3',
    'review_role': 'Fresh independent exact-commit Phase 2A review; no nested or delegated agents.',
    'review_date': '2026-10-03',
    'written_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'model_requested': 'gpt-6.1-sol', 'reasoning_effort_requested': 'xhigh',
    'verdict': 'CHANGES_REQUESTED', 'decision': 'CHANGES_REQUESTED',
    'summary': 'Numeric cache validation/rebuild and all single-constructor required-image corrections pass on Python 3.13.16 and 3.14.8. The 226-case scoped suite and 429-case non-runtime base suite pass on both. One medium finding remains: default Tiny recovery rejects a constructor after failed recovery or while another recovery has temporarily removed its completion marker. Minimal unmodified-lock reproductions fail both default cases and pass both configured-URL controls on each version.',
    'finding_counts': {'critical': 0, 'high': 0, 'medium': 1, 'low': 0},
    'identity': identity,
    'write_scope_and_authority': {
        'sole_root_write': str(REPORT), 'owned_scratch': str(SCRATCH),
        'candidate_edits': 0, 'commits_created': 0, 'pushes': 0,
        'agents_spawned': 0, 'questions_or_approval_requests': 0,
        'shared_metadata_runtime_or_ci_edits': 0,
        'shell': 'Every shell call used exec_command(shell=/bin/zsh, login=true), i.e. zsh -lc; audit subprocess shells also explicitly use /bin/zsh -lc.',
        'herdr': {'workspace_id': 'w16', 'tab_id': 'w16:t1', 'pane_id': 'w16:p1',
                  'workspace_label': 'plato-phase2-data-review-3',
                  'agent_name': 'plato-phase2-data-review-3',
                  'verification': 'HERDR_ENV=1, herdr pane current --current, workspace get and agent get confirmed the separately assigned reviewer workspace. No layout, focus or shared metadata mutations.',
                  'guidance': 'Read herdr --skill before Herdr control/read commands.'},
        'candidate_execution_policy': 'Original worktree was read only. All dependency installation, exported-source execution, test outputs, pytest fixtures and reviewer probes were confined to owned scratch. UV cache and TMPDIR were explicitly scratch-local.',
    },
    'accepted_and_prior_sources_read': input_records,
    'environment': {
        '3.13': json.loads((SCRATCH / 'environment-3.13.json').read_text()),
        '3.14': json.loads((SCRATCH / 'environment-3.14.json').read_text()),
        'profile': 'Two freshly created locked test-base environments against the exact exported candidate; no default groups or optional packages added.',
        'uv': 'uv 0.12.22 (70fe1196a 2026-10-01 aarch64-apple-darwin)',
        'sync_commands': {
            v: f'UV_CACHE_DIR=/tmp/plato-phase2a-review-3/uv-cache TMPDIR=/tmp/plato-phase2a-review-3/tmp UV_PROJECT_ENVIRONMENT=/tmp/plato-phase2a-review-3/base-{v} uv sync --project /tmp/plato-phase2a-review-3/candidate --locked --no-default-groups --group test-base --python /tmp/plato-phase2a-lZqbqj/revision2/base-{v}/bin/python > /tmp/plato-phase2a-review-3/logs/sync-{v}.log 2>&1'
            for v in ['3.13', '3.14']},
        'sync_exit_codes': {'3.13': 0, '3.14': 0},
        'interpreter_selection': 'Existing author environment interpreter paths were used only to select the installed Python binaries. Reviewer environments and all package installations are fresh and owned; author environments were neither installed into nor executed as test profiles.',
        'source_attribution': 'Parent and child interpreter imports resolve to the exact scratch candidate, with matching environment prefixes. Source path comparisons resolve /tmp and /private/tmp aliases.',
    },
    'independent_validation': {
        **validation,
        'interpretation': 'Nonzero probe exits are retained product failures, not harness errors or green results. The two broader failures and two minimal failures represent one common default-source eligibility defect.',
        'static': [
            {'command': commands['static'][i], 'exit_code': 0,
             'tool_version': ['ruff 0.16.10', 'ty 0.0.84 (8dd9a7f7f 2026-09-24)'][i],
             'result': 'All checks passed.', 'log': file_record(SCRATCH / f'logs/{name}.log')}
            for i, name in enumerate(['ruff', 'ty'])],
        'diff_check': {'command': 'GIT_OPTIONAL_LOCKS=0 git diff --check fda60becedfa6236c11d415b87a868b52789a41e 150a48860b556eab1575178891577dd07dc6f06d', 'exit_code': 0, 'output': ''},
        'unchanged_runtime_matrix': '48 startup/socket runtime cases were deliberately deselected. No shared runtime changed; the unchanged eight-minute startup matrix was not repeated.',
    },
    'finding_dispositions': [
        {'id': 'R2A2-01', 'status': 'RESOLVED in reviewed scope',
         'evidence': 'All 26 author invalid-cache constructor cases and eight compatible-cache cases pass. Independent actual constructors additionally cover numeric Unicode, zero-imaginary complex, object/structured/datetime features, signed Inf, just-above-float32-boundary features and smallest positive fractional labels. Both raw datasets include cached IDs 0 and 99. Correct stored raw arrays and exact float32/int64 tensors survive second load; nine compatible dtype/boundary modes per dataset preserve original NPZ bytes. Failed cache recovery can later rebuild from supplied raw data; no wrong labels or permanent cache poisoning observed.'},
        {'id': 'R2A2-02', 'status': 'Single-constructor correction verified; default-source negative paths remain open as R2A3-01',
         'evidence': 'All eight author train/eval PNG-loss cases pass. Independent cases cover CINIC configured, Tiny prepared configured, Tiny native configured/default, a second referenced native validation PNG while another image survives, uppercase image extension, nested class paths and unsupported-extension-only leftovers. Correct label-1 evaluation subsets return finite tensors; stopped-server/request-prohibited repeat loads pass. Configured recovery failures never republish incomplete completion and later recover. Default concurrent/failed recovery fails as documented.'},
        {'id': 'R2A-01', 'status': 'Retained positive and negative controls pass',
         'evidence': 'Actual fedavg_cs.Server.configure on the tracked TOML accepts assigned edge IDs 4 and 5 with 600 unique deterministic evaluation indices. Invalid ordinary, unassigned, training and indexed-sampler edge roles still reject; caller RNG preservation checks pass.'},
        {'id': 'R2A-02', 'status': 'Retained publication/locking correction passes',
         'evidence': 'Both datasets use actual paused np.savez writers and concurrent readers. Readers wait under flock while final NPZ is unpublished; released or killed writers yield correct stored arrays, recover offline and leave no abandoned temporary cache. Raw-only/cache-only and corrupt/missing-key/shape paths pass.'},
        {'id': 'R2A-03', 'status': 'Retained native/prepared discrimination passes',
         'evidence': 'Incomplete direct/nested native roots do not create an images class from official unlabeled test/images; offline manual incomplete roots reject clearly. Valid direct/nested native and prepared labeled roots work.'},
        {'id': 'R2A-04', 'status': 'Directory/annotation and single-image controls pass; default-source negative gap R2A3-01 blocks complete acceptance',
         'evidence': 'Actual HTTP/extraction recovery restores missing CINIC directories and Tiny annotations, including the canonical default URL. Configured/default successful single-image recovery and complete-root offline reuse pass. Default eligibility before the downloader guard is the remaining failure.'},
        {'id': 'ROOT-2A-01', 'status': 'RESOLVED controls retained',
         'evidence': 'Prepared CINIC/Tiny subsets use the training class mapping, with coherent samples/imgs/targets/classes/class_to_idx. Independent recovery keeps evaluation label 1 with two training classes; unknown prepared/native labels reject without requests.'},
        {'id': 'ROOT-2A-02', 'status': 'RESOLVED controls retained',
         'evidence': 'Native/prepared Tiny evaluation is bit-identical across repeats, finite and 3x299x299 with independent constant-pixel normalization reference. Training still varies on a gradient image; explicit train/test transform callables remain independent.'},
        {'id': 'F13', 'status': 'Verified', 'evidence': 'Config optional-section reset, legacy singleton invalidation, include and CLI regressions pass; Config source unchanged since review2.'},
        {'id': 'F15', 'status': 'Verified', 'evidence': 'Repeated Dirichlet counts match realized sampler/loader counts without caller or private RNG draws; seeded membership/RNG controls pass.'},
        {'id': 'F16', 'status': 'Verified', 'evidence': 'Empty IID and infeasible partition pools terminate in bounded subprocess guards; literal nonempty seeded IID membership and padding controls pass.'},
        {'id': 'EMNIST', 'status': 'Verified', 'evidence': 'Actual local native IDX balanced/digits fixtures retain distinct train/test labels, constructor train flags and counts.'},
        {'id': 'Archive containment and legacy datalib', 'status': 'Verified within existing limits',
         'evidence': 'Active TAR/ZIP extraction tests on both versions reject absolute/traversal names, TAR link escapes and preexisting symlink destinations before outside writes or completion publication; safe extraction and lock owner-death controls pass. All 14 archived original blobs and copied baseline LICENSE are identical; no active Python archive imports found.'},
    ],
    'source_and_scope_audit': {
        'review2_to_current': 'Production changes are limited to _vector_cache.py, _image_folder.py, cinic10.py and tiny_imagenet.py; one regression test module and phase2a-validation.json were added/updated. Purchase/Texas consumers, Config, all samplers, base downloader, EMNIST, archive helper, archived bytes and shared files remain unchanged since review2.',
        'numeric_contract': 'Real finite float32-compatible features and integral IDs 0..99 agree with the existing 100-class Purchase/Texas VectorDataset consumers. Accepted caches normalize to native float32/int64 only in memory, retaining NPZ bytes/schema and feature width.',
        'image_contract': 'Installed torchvision make_dataset/find_classes/is_image_file semantics were inspected in both environments. Empty present classes reject; uppercase extensions and nested class images work. Native Tiny readiness checks every parsed annotation reference. Prepared valid class subsets keep training-space labels and unknown classes reject.',
        'accepted_prepared_inventory_limit': 'Independent prepared-layout control deletes one of two class images and correctly remains offline with a usable surviving image. Without source inventory that loss is not detectable and is not a finding.',
        'no_scope_expansion': 'No content checksum/decoding validation requirement, corpus manifest, feature-count redesign, protocol/security redesign, cosmetic typing finding or unrelated optimization was added.',
    },
    'archive_review': {'original_count': 14, 'records': archive_records,
                       'license': archive_license,
                       'active_import_scan': before['active_archive_reference_scan'],
                       'qualification': 'Archived multimedia/REFER code remains unqualified historical source; preservation and inactive closure do not claim runtime support.'},
    'author_and_root_evidence_attribution': {
        'both_correction_histories_read': True,
        'retained_log_integrity': author_logs,
        'exact_author_identity': 'Author implementation tree and both base/prior binary diff hashes were independently recomputed and matched. 150a4886 differs from 49fe01e4 only in the assigned evidence JSON.',
        'author_revision2_results': 'Retained logs match 36 failed/6 passed red, 42 new-case green, 226 focused green and 429 base passed/4 permitted skips/48 runtime deselections on each version. Independent current-candidate runs reproduce the green suites and add the failing recovery controls; author results are not silently relabeled as root or reviewer acceptance.',
        'earlier_history_limits': 'The first correction history excludes its initial edge fixture AttributeError as product evidence; corrected edge red and staged default-URL red are separately attributed. The second history discloses the /tmp alias identity and evidence assembly harness corrections. Their logs and original verdicts are unchanged.',
        'root_prior_base': 'phase2a-root-base-validation.json records 387 passed only for prior b728a5b. It is not current-candidate qualification. This reviewer independently ran current non-runtime base on both versions; root combined Linux/full mandatory qualification remains pending.',
        'earlier_SSL_and_config_inventory': 'The unchanged eight-configuration SSL transform probes and 160 config-load inventory are historical author evidence, not newly executed SSL/training or whole-stack qualification. Lightly is absent from both reviewer base environments.',
    },
    'findings': [finding],
    'harness_disposition': 'No corrected or discarded failing product probe. The first independent suite reports two failures; a separate smaller reproduction captures the exact ValueError without guard instrumentation and adds passing configured-source controls. These are one shared material finding, not four independent findings.',
    'limits': [
        'macOS ARM64 CPU on Python 3.13.16 and 3.14.8 only. Linux merged-tree and full mandatory optional-profile qualification remain with root.',
        'Fresh locked editable test-base environments with exact exported-source parent/child identity; wheel/sdist installed-artifact isolation was not repeated.',
        'Four permitted base skips only: one absent-Opacus DP module and three optional Nanochat nodes. No broad skips, warning suppressions, fixture changes or weakened assertions.',
        '48 unchanged startup/socket runtime cases explicitly deselected. No new shared client/server, HF/LeRobot/Nanochat/MLX, metadata or CI work was performed.',
        'Bounded local raw/IDX/PNG data and localhost HTTP archives only; no external corpus, cloud service, accelerator, full training accuracy or new SSL support claim.',
        'Image readiness is file existence/extensions and native annotation references. Full image decoding/checksums and prepared source-inventory recovery are outside the accepted scope.',
        'NPZ publication evidence concerns successful same-filesystem replace and killed processes, not power-loss/directory-fsync durability. Archive extraction retains its no-unrelated-concurrent-writer and no-corrupt-filesystem-rollback limits.',
        'The remaining medium default recovery finding blocks PASS. Corrections return to the original author followed by a fresh exact-candidate review; no root phase gate or acceptance is claimed.',
    ],
    'retained_resources': {
        'scratch': str(SCRATCH), 'environments': [str(SCRATCH / ('base-' + v)) for v in ['3.13', '3.14']],
        'retention': 'All owned exports, environments, caches, scripts, raw logs, JUnit and reproduction fixtures retained. Original author and previous reviewer resources remain untouched.',
        'processes': 'All owned test commands completed. Writer/reader subprocesses are reaped by their finally guards; all independent HTTP workers and constructor threads joined. No experimental service is intentionally left running.',
    },
}
artifact_paths = sorted(set(
    list((SCRATCH / 'logs').glob('*.log')) + list((SCRATCH / 'logs').glob('*.xml'))
    + list(SCRATCH.glob('*.py')) + list(SCRATCH.glob('*.json'))
    + list(SCRATCH.glob('*.py.txt'))))
artifact_paths = [p for p in artifact_paths if p.name != 'report-assembly.log']
report['retained_resources']['artifacts'] = [file_record(p) for p in artifact_paths]
if REPORT.exists():
    existing = json.loads(REPORT.read_text())
    assert existing['reviewer'] == 'plato-phase2a-review-3'
    assert existing['identity']['candidate_commit'] == before['candidate_commit']
REPORT.write_text(json.dumps(report, indent=2) + '\n')
parsed = json.loads(REPORT.read_text())
assert parsed['decision'] == 'CHANGES_REQUESTED'
assert parsed['finding_counts']['medium'] == len(parsed['findings']) == 1
assert parsed['identity']['candidate_immutable']
print(json.dumps({'verdict': parsed['verdict'], 'findings': parsed['finding_counts'],
                  'report': str(REPORT), 'report_sha256': file_record(REPORT)['sha256'],
                  'retained_artifacts': len(artifact_paths)}, indent=2))
