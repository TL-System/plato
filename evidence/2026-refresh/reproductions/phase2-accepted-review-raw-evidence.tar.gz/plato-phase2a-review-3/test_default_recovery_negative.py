"""Minimal default-URL recovery reproductions, with unmodified flock behavior."""

import json
import sys
import threading
import traceback

import plato
import pytest

import test_independent_contracts as support

configure = support.configure


def save_result(tmp_path, name, state, errors, values):
    result = {
        "name": name, "python": sys.version, "source": plato.__file__,
        "requests": state["hits"], "successful_constructors": len(values),
        "completion_markers": [p.name for p in tmp_path.glob("*.complete")],
        "errors": [
            {"type": type(e).__name__, "message": str(e),
             "traceback": "".join(traceback.format_exception(e))} for e in errors
        ],
    }
    (tmp_path / "observed.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


@pytest.mark.parametrize("mode", ["tiny_default", "tiny_native"])
def test_retry_after_incomplete_archive_with_source_restored(tmp_path, monkeypatch, mode):
    members, _, missing_name = support.fixture(mode)
    errors, values = [], []
    with support.server(support.zipped(members)) as (url, state):
        module = support.setup_source(mode, url, monkeypatch)
        support.check_images(module.DataSource())
        missing = tmp_path / missing_name
        missing.unlink()
        assert len(list(tmp_path.glob("*.complete"))) == 1
        state["payload"] = support.zipped(
            {k: v for k, v in members.items() if k != missing_name})
        with pytest.raises(RuntimeError, match="required extracted dataset artifacts"):
            module.DataSource()
        assert len(state["hits"]) == 2
        assert not list(tmp_path.glob("*.complete")) and not missing.exists()
        state["payload"] = support.zipped(members)
        try:
            values.append(module.DataSource())
        except Exception as exc:
            errors.append(exc)
        save_result(tmp_path, "retry-with-working-source-" + mode, state, errors, values)
        assert not errors, f"Working source cannot recover: {errors!r}"
        support.check_images(values[0])
        assert missing.is_file() and len(state["hits"]) == 3
        assert list(tmp_path.glob("*.complete"))


@pytest.mark.parametrize("mode", ["tiny_default", "tiny_native"])
def test_two_constructors_during_paused_default_recovery(tmp_path, monkeypatch, mode):
    members, _, missing_name = support.fixture(mode)
    with support.server(support.zipped(members)) as (url, state):
        module = support.setup_source(mode, url, monkeypatch)
        support.check_images(module.DataSource())
        (tmp_path / missing_name).unlink()
        state["pause"] = True
        errors, values = [], []
        workers = [threading.Thread(target=support.load_in_thread,
                                    args=(module, values, errors)) for _ in range(2)]
        try:
            workers[0].start()
            # The recovery owns the real download flock and has invalidated the marker.
            assert state["entered"].wait(5)
            assert not list(tmp_path.glob("*.complete"))
            workers[1].start()
            workers[1].join(.25)
        finally:
            state["release"].set()
            for worker in workers:
                if worker.ident is not None:
                    worker.join(10)
        assert not any(w.is_alive() for w in workers)
        save_result(tmp_path, "concurrent-recovery-" + mode, state, errors, values)
        assert not errors, f"Contender rejects live recovery: {errors!r}"
        assert len(values) == 2 and len(state["hits"]) == 2
        for value in values:
            support.check_images(value)
