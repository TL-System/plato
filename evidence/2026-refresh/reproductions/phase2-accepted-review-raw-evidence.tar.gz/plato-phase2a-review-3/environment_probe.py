"""Record reviewer-owned environments and parent/child source attribution."""

import hashlib
import importlib.metadata
import importlib.util
import inspect
import json
import platform
import shlex
import subprocess
import sys
from pathlib import Path

import plato
import torchvision.datasets.folder as folder

root = Path('/tmp/plato-phase2a-review-3')
candidate = (root / 'candidate/plato/__init__.py').resolve()
assert Path(plato.__file__).resolve() == candidate
child_command = (shlex.quote(sys.executable) + ' -c ' + shlex.quote(
    'import json,plato,sys; print(json.dumps({"source":plato.__file__,"prefix":sys.prefix}))'))
child = subprocess.run(['/bin/zsh', '-lc', child_command], capture_output=True,
                       text=True, check=True)
child_data = json.loads(child.stdout)
assert Path(child_data['source']).resolve() == candidate
assert Path(child_data['prefix']).resolve() == Path(sys.prefix).resolve()
result = {
    'python': sys.version, 'executable': sys.executable, 'prefix': sys.prefix,
    'platform': platform.platform(), 'machine': platform.machine(),
    'source': plato.__file__, 'child_command': child_command, 'child': child_data,
    'packages': {p: importlib.metadata.version(p) for p in [
        'plato-learn', 'numpy', 'torch', 'torchvision', 'requests', 'pytest', 'pytest-cov']},
    'optional_available': {p: importlib.util.find_spec(p) is not None for p in [
        'opacus', 'kazoo', 'gymnasium', 'tiktoken', 'lightly']},
    'default_python': (root / 'candidate/.python-version').read_text().strip(),
    'torchvision_folder_source_path': inspect.getfile(folder),
    'torchvision_folder_source_sha256': hashlib.sha256(inspect.getsource(folder).encode()).hexdigest(),
}
assert not any(result['optional_available'].values())
(root / f'environment-{sys.argv[1]}.json').write_text(json.dumps(result, indent=2) + '\n')
(root / f'torchvision-folder-{sys.argv[1]}.py.txt').write_text(inspect.getsource(folder))
print(json.dumps(result, indent=2))
