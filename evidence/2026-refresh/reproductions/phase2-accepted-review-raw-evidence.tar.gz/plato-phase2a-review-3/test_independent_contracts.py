"""Independent exact-candidate review probes; all fixtures live in owned scratch."""

import contextlib
import http.server
import io
import threading
import zipfile
from pathlib import Path

import numpy as np
import pytest
import torch
from PIL import Image

from plato.config import Config
from plato.datasources import base, cinic10, purchase, texas, tiny_imagenet


RAW_X = np.array([[1, -2, .25], [3, 4, .5], [5, -6, .75],
                  [7, 8, 1], [9, -10, 1.25], [11, 12, 1.5]])
RAW_Y = np.array([0, 1, 99, 7, 98, 25])
ORDER = [5, 2, 1, 3, 0, 4]


@pytest.fixture(autouse=True)
def configure(tmp_path):
    Config.reset()
    Config._instance = object.__new__(Config)
    Config.data = Config.node_from_dict({"random_seed": 31})
    Config.params = {"data_path": str(tmp_path)}
    yield
    Config.reset()


def write_raw(root, module):
    if module is purchase:
        np.savetxt(root / "dataset_purchase", np.column_stack((RAW_Y + 1, RAW_X)),
                   delimiter=",")
    else:
        folder = root / "texas/100"
        folder.mkdir(parents=True, exist_ok=True)
        np.savetxt(folder / "feats", RAW_X, delimiter=",")
        np.savetxt(folder / "labels", RAW_Y + 1, delimiter=",")


def cache_path(root, module):
    return root / ("purchase_numpy.npz" if module is purchase else "texas_numpy.npz")


def prohibit_vector_network(monkeypatch, module):
    monkeypatch.setattr(module.request, "urlretrieve",
                        lambda *a, **k: pytest.fail("unexpected vector network"))


def check_vector(source, features, labels):
    assert source.num_train_examples() == 6 and source.num_test_examples() == 0
    assert len(source.classes()) == 100
    assert source.trainset.data.dtype == torch.float32
    assert source.trainset.targets.dtype == torch.int64
    assert source.targets().tolist() == labels[ORDER].tolist()
    expected = np.asarray(features[ORDER], dtype=np.float32)
    # Bit comparison checks sign of zero and the exact native float32 conversion.
    assert source.trainset.data.numpy().tobytes() == expected.tobytes()
    assert torch.isfinite(source.trainset.data).all()
    for i in range(6):
        tensor, label = source.get_train_set()[i]
        assert tensor.shape == (features.shape[1],)
        assert 0 <= label.item() < 100


BAD_KINDS = ["unicode_x", "numeric_unicode_x", "complex_x", "real_complex_x",
             "nan_x", "inf_x", "negative_inf_x", "overflow_x", "above_boundary_x",
             "object_x", "structured_x", "datetime_x", "unicode_y", "complex_y",
             "fractional_y", "nan_y", "inf_y", "negative_y", "class100_y",
             "uint64_overflow_y", "tiny_fraction_y"]


@pytest.mark.parametrize("module", [purchase, texas])
@pytest.mark.parametrize("bad", BAD_KINDS)
def test_invalid_cache_recovers_exact_raw_and_remains_reusable(tmp_path, monkeypatch,
                                                              module, bad):
    write_raw(tmp_path, module)
    prohibit_vector_network(monkeypatch, module)
    x, y = RAW_X.copy(), RAW_Y.astype(np.float64)
    if bad in ("unicode_x", "numeric_unicode_x"):
        x = np.full(x.shape, "bad" if bad == "unicode_x" else "1.25")
    elif bad in ("complex_x", "real_complex_x"):
        x = x.astype(np.complex128) + (2j if bad == "complex_x" else 0j)
    elif bad == "object_x":
        x = x.astype(object)
    elif bad == "structured_x":
        x = np.zeros(x.shape, dtype=[("value", np.float64)])
    elif bad == "datetime_x":
        x = np.full(x.shape, np.datetime64("2026-01-01"))
    elif bad.endswith("_x"):
        values = {"nan_x": np.nan, "inf_x": np.inf, "negative_inf_x": -np.inf,
                  "overflow_x": np.finfo(np.float64).max,
                  "above_boundary_x": np.nextafter(float(np.finfo(np.float32).max),
                                                    np.inf)}
        x[0, 0] = values[bad]
    elif bad == "unicode_y":
        y = y.astype(str)
    elif bad == "complex_y":
        y = y.astype(complex)
    elif bad == "uint64_overflow_y":
        y = y.astype(np.uint64)
        y[0] = 2**64 - 1
    else:
        values = {"fractional_y": 7.5, "nan_y": np.nan, "inf_y": np.inf,
                  "negative_y": -1, "class100_y": 100,
                  "tiny_fraction_y": np.nextafter(0., 1.)}
        y[0] = values[bad]
    cache = cache_path(tmp_path, module)
    np.savez(cache, X=x, Y=y)
    for _ in range(2):
        check_vector(module.DataSource(), RAW_X, RAW_Y)
        with np.load(cache, allow_pickle=False) as stored:
            np.testing.assert_array_equal(stored["X"], RAW_X)
            np.testing.assert_array_equal(stored["Y"], RAW_Y)


@pytest.mark.parametrize("module", [purchase, texas])
@pytest.mark.parametrize("dtype", ["float16", "float32", "float64", ">f4", ">f8",
                                   "int16", "uint64", "bool", "boundary"])
def test_compatible_cache_only_preserves_bytes_and_tensor_values(tmp_path, monkeypatch,
                                                               module, dtype):
    prohibit_vector_network(monkeypatch, module)
    x, y = RAW_X.copy(), RAW_Y.copy()
    if dtype == "boundary":
        maximum = float(np.finfo(np.float32).max)
        x[0] = [maximum, -maximum, -0.]
        x[1] = [np.nextafter(np.float32(0), np.float32(1)), 2**40, -2**40]
        y = y.astype(">f8")
    else:
        if dtype in ("uint64", "bool"):
            x = abs(x)
        x = x.astype(dtype)
        y = y.astype("bool" if dtype == "bool" else ">f8")
    cache = cache_path(tmp_path, module)
    np.savez(cache, X=x, Y=y)
    original = cache.read_bytes()
    for _ in range(2):
        check_vector(module.DataSource(), x, y)
        assert cache.read_bytes() == original


@pytest.mark.parametrize("module", [purchase, texas])
def test_invalid_cache_failed_recovery_does_not_poison_later_raw(tmp_path, monkeypatch,
                                                              module):
    cache = cache_path(tmp_path, module)
    np.savez(cache, X=RAW_X, Y=RAW_Y + .1)
    calls = []

    def refuse(*args):
        calls.append(args[0])
        raise OSError("controlled offline source")

    monkeypatch.setattr(module.request, "urlretrieve", refuse)
    with pytest.raises(OSError, match="controlled offline"):
        module.DataSource()
    assert len(calls) == 1 and not cache.exists()
    assert not list(tmp_path.glob(".*.tmp"))
    write_raw(tmp_path, module)
    prohibit_vector_network(monkeypatch, module)
    for _ in range(2):
        check_vector(module.DataSource(), RAW_X, RAW_Y)


@contextlib.contextmanager
def server(payload):
    state = {"payload": payload, "hits": [], "pause": False,
             "entered": threading.Event(), "release": threading.Event()}

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            state["hits"].append(self.path)
            self.send_response(200)
            self.send_header("Content-Length", str(len(state["payload"])))
            self.end_headers()
            if state["pause"]:
                state["entered"].set()
                assert state["release"].wait(10)
            self.wfile.write(state["payload"])

        def log_message(self, *args):
            pass

    host = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    worker = threading.Thread(target=lambda: host.serve_forever(poll_interval=.01))
    worker.start()
    try:
        yield f"http://127.0.0.1:{host.server_port}/source.zip", state
    finally:
        state["release"].set()
        host.shutdown()
        worker.join(3)
        host.server_close()
        assert not worker.is_alive()


def fixture(mode):
    native = mode in ("tiny_native", "tiny_default")
    prefix = "tiny-imagenet-200/" if native else ""
    train = prefix + "train/n020/images/b.PNG"
    evaluation = prefix + ("val/images/z2.PNG" if native else "test/n020/z2.PNG")
    png = io.BytesIO()
    Image.new("RGB", (19, 13), (40, 90, 160)).save(png, format="PNG")
    members = {prefix + "train/n010/images/a.PNG": png.getvalue(),
               train: png.getvalue(), evaluation: png.getvalue()}
    if native:
        members[prefix + "val/images/z1.PNG"] = png.getvalue()
        members[prefix + "val/val_annotations.txt"] = b"z1.PNG\tn020\n z2.PNG\tn020\n"
    return members, train, evaluation


def zipped(members):
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w") as archive:
        for name, value in members.items():
            archive.writestr(name, value)
    return stream.getvalue()


def setup_source(mode, url, monkeypatch):
    module = cinic10 if mode == "cinic" else tiny_imagenet
    if mode == "tiny_default":
        original_get = base.requests.get

        def dispatch(requested, **kwargs):
            assert requested == "https://cs231n.stanford.edu/tiny-imagenet-200.zip"
            return original_get(url, **kwargs)

        monkeypatch.setattr(base.requests, "get", dispatch)
    else:
        Config.data.download_url = url
    return module


def check_images(source):
    assert source.classes() == ["n010", "n020"]
    assert source.trainset.class_to_idx == source.testset.class_to_idx == {
        "n010": 0, "n020": 1}
    assert source.trainset.targets == [0, 1]
    assert source.testset.targets == [1] * len(source.testset)
    if hasattr(source.testset, "imgs"):
        assert source.testset.imgs == source.testset.samples
    for dataset in (source.trainset, source.testset):
        for i in range(len(dataset)):
            image, label = dataset[i]
            assert label == dataset.targets[i]
            assert torch.isfinite(image).all() and image.shape[0] == 3
    assert torch.equal(source.testset[0][0], source.testset[0][0])


MODES = ["cinic", "tiny_prepared", "tiny_native", "tiny_default"]


@pytest.mark.parametrize("mode", MODES)
@pytest.mark.parametrize("damage", ["train", "evaluation", "not_image"])
def test_real_http_required_image_recovery_and_offline_reuse(tmp_path, monkeypatch,
                                                          mode, damage):
    members, train, evaluation = fixture(mode)
    with server(zipped(members)) as (url, state):
        module = setup_source(mode, url, monkeypatch)
        check_images(module.DataSource())
        assert len(state["hits"]) == 1
        markers = list(tmp_path.glob("*.complete"))
        assert len(markers) == 1
        missing = tmp_path / (train if damage != "evaluation" else evaluation)
        missing.unlink()
        if damage == "not_image":
            missing.with_suffix(".txt").write_bytes(members[train])
        assert missing.parent.is_dir() and markers[0].is_file()
        check_images(module.DataSource())
        assert len(state["hits"]) == 2 and missing.read_bytes() == members[
            train if damage != "evaluation" else evaluation]
        assert markers[0].is_file()
    monkeypatch.setattr(base.requests, "get",
                        lambda *a, **k: pytest.fail("completed root used network"))
    check_images(module.DataSource())
    check_images(module.DataSource())


@pytest.mark.parametrize("mode", MODES)
def test_stale_marker_incomplete_recovery_cannot_publish_completion(tmp_path,
                                                                  monkeypatch, mode):
    members, train, evaluation = fixture(mode)
    with server(zipped(members)) as (url, state):
        module = setup_source(mode, url, monkeypatch)
        check_images(module.DataSource())
        missing = tmp_path / evaluation
        missing.unlink()
        state["payload"] = zipped({k: v for k, v in members.items() if k != evaluation})
        with pytest.raises(RuntimeError, match="required extracted dataset artifacts"):
            module.DataSource()
        assert len(state["hits"]) == 2 and not list(tmp_path.glob("*.complete"))
        assert not missing.exists()
        state["payload"] = zipped(members)
        check_images(module.DataSource())
        assert len(state["hits"]) == 3 and list(tmp_path.glob("*.complete"))
    monkeypatch.setattr(base.requests, "get",
                        lambda *a, **k: pytest.fail("restored root used network"))
    check_images(module.DataSource())


def load_in_thread(module, values, failures):
    try:
        values.append(module.DataSource())
    except BaseException as exc:
        failures.append(exc)


@pytest.mark.parametrize("mode", MODES)
def test_competing_recovery_rechecks_readiness_after_real_flock(tmp_path, monkeypatch,
                                                              mode):
    members, train, evaluation = fixture(mode)
    with server(zipped(members)) as (url, state):
        module = setup_source(mode, url, monkeypatch)
        module.DataSource()
        (tmp_path / evaluation).unlink()
        attempted = threading.Event()
        original_guard = base.DataSource._download_guard

        @contextlib.contextmanager
        def observed_guard(root):
            attempted.set()
            with original_guard(root):
                yield

        monkeypatch.setattr(base.DataSource, "_download_guard", observed_guard)
        values, failures = [], []
        worker = threading.Thread(target=load_in_thread, args=(module, values, failures))
        with original_guard(str(tmp_path)):
            worker.start()
            assert attempted.wait(5)
            worker.join(.1)
            assert worker.is_alive() and len(state["hits"]) == 1
            # A competing owner has repaired the root and retained its valid marker.
            (tmp_path / evaluation).write_bytes(members[evaluation])
        worker.join(10)
        assert not worker.is_alive() and not failures
        assert len(values) == 1 and len(state["hits"]) == 1
        check_images(values[0])


@pytest.mark.parametrize("mode", MODES)
def test_two_actual_recoverers_download_once_under_lock(tmp_path, monkeypatch, mode):
    members, train, evaluation = fixture(mode)
    with server(zipped(members)) as (url, state):
        module = setup_source(mode, url, monkeypatch)
        module.DataSource()
        (tmp_path / evaluation).unlink()
        attempted_second = threading.Event()
        original_guard = base.DataSource._download_guard
        count = []

        @contextlib.contextmanager
        def observed_guard(root):
            count.append(threading.get_ident())
            if len(count) == 2:
                attempted_second.set()
            with original_guard(root):
                yield

        monkeypatch.setattr(base.DataSource, "_download_guard", observed_guard)
        values, failures = [], []
        workers = [threading.Thread(target=load_in_thread, args=(module, values, failures))
                   for _ in range(2)]
        state["pause"] = True
        try:
            workers[0].start()
            assert state["entered"].wait(5)
            workers[1].start()
            assert attempted_second.wait(5)
            assert all(w.is_alive() for w in workers)
        finally:
            state["release"].set()
            for w in workers:
                if w.ident is not None:
                    w.join(10)
        assert not any(w.is_alive() for w in workers) and not failures
        assert len(values) == 2 and len(state["hits"]) == 2
        assert list(tmp_path.glob("*.complete"))
        for value in values:
            check_images(value)


@pytest.mark.parametrize("mode", ["cinic", "tiny_prepared"])
def test_surviving_prepared_class_image_obeys_accepted_inventory_limit(tmp_path,
                                                                    monkeypatch, mode):
    members, train, evaluation = fixture(mode)
    survivor = str(Path(evaluation).with_name("survivor.PNG"))
    members[survivor] = members[evaluation]
    with server(zipped(members)) as (url, state):
        module = setup_source(mode, url, monkeypatch)
        module.DataSource()
        (tmp_path / evaluation).unlink()
    monkeypatch.setattr(base.requests, "get",
                        lambda *a, **k: pytest.fail("valid remaining class went online"))
    check_images(module.DataSource())
    assert len(state["hits"]) == 1


@pytest.mark.parametrize("mode", MODES)
def test_unknown_class_rejects_without_network(tmp_path, monkeypatch, mode):
    members, train, evaluation = fixture(mode)
    for name, value in members.items():
        path = tmp_path / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(value)
    if mode in ("tiny_native", "tiny_default"):
        annotation = tmp_path / "tiny-imagenet-200/val/val_annotations.txt"
        annotation.write_text("z1.PNG\tn999\n")
    else:
        alien = tmp_path / "test/n999/alien.PNG"
        alien.parent.mkdir()
        alien.write_bytes(members[evaluation])
    monkeypatch.setattr(base.requests, "get",
                        lambda *a, **k: pytest.fail("unknown class caused network"))
    module = cinic10 if mode == "cinic" else tiny_imagenet
    with pytest.raises(ValueError, match="Unknown evaluation classes|Invalid Tiny"):
        module.DataSource()
