"""Read-only verification of exact candidates and retained runtime evidence."""

import hashlib
import json
import subprocess
from pathlib import Path

import numpy as np

from plato.serialization.safetensor import deserialize_tree

SOURCE = Path('/private/tmp/plato-refresh-worktrees/runtime')
ROOT = Path('/Users/bli/Playground/plato')
SCRATCH = Path('/tmp/plato-phase2b-review-2')
AUTHOR = Path('/tmp/plato-phase2b-runtime')
B = '7753ca37bacbbdbcaef4192150e6532d79247011'
I = '516da21d66472d8916ed42aa21ce462d29944f73'
BASE = 'fda60becedfa6236c11d415b87a868b52789a41e'
D = 'aa232791f04d93eb9de09ed6c596ac714db5b605'
OLD_D = 'a4a4733e96cf248a73db76e6b2182536b9f592ea'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=SOURCE)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


report = {'candidate': B, 'candidate_tree': git('rev-parse', B + '^{tree}').decode().strip(),
          'implementation': I, 'implementation_tree': git('rev-parse', I + '^{tree}').decode().strip(),
          'base': BASE, 'source_files': {}, 'authority_files': {}, 'logs': {}, 'runs': {}}
assert git('rev-parse', 'HEAD').decode().strip() == B
assert not git('status', '--porcelain')
assert git('rev-parse', B + '^').decode().strip() == I
assert git('diff', '--name-only', I, B).decode().splitlines() == ['evidence/2026-refresh/phase2b-validation.json']
changed = git('diff', '--name-only', BASE, B).decode().splitlines()
for name in changed:
    candidate = git('show', B + ':' + name)
    assert (SOURCE / name).read_bytes() == candidate
    assert (SCRATCH / 'candidate' / name).read_bytes() == candidate
    report['source_files'][name] = sha(SOURCE / name)
for name in ['AGENTS.md', 'uv.lock', 'pyproject.toml', '.python-version',
             'evidence/2026-refresh/plan.md', 'evidence/2026-refresh/plan-addendum.json',
             'evidence/2026-refresh/plan-addendum-acceptance.json',
             'tests/conftest.py', 'tests/integration/test_event_loop_startup.py',
             'tests/integration/startup_harness.py', 'tests/integration/startup_probe.py',
             'tests/integration/startup_socket.py', 'tests/integration/utils.py']:
    assert (SCRATCH / 'candidate' / name).read_bytes() == git('show', B + ':' + name)
    report['authority_files'][name] = sha(SOURCE / name)
    if name.startswith('tests/'):
        assert (SOURCE / name).read_bytes() == git('show', BASE + ':' + name)
evidence = json.loads((SOURCE / 'evidence/2026-refresh/phase2b-validation.json').read_text())
for name, digest in evidence['environment']['identities_sha256'].items():
    assert sha(SOURCE / name) == digest
review = evidence['review_corrections']['review']
for field in ['file', 'root_probe', 'read_only_reference']:
    expected = {'file': 'sha256', 'root_probe': 'root_probe_sha256',
                'read_only_reference': 'reference_sha256'}[field]
    path = Path(review[field])
    assert sha(path) == review[expected]
    report['authority_files'][str(path)] = sha(path)

for version, result in evidence['review_corrections']['results'].items():
    for stage in ['red', 'green', 'final_affected_suite']:
        path = Path(result[stage]['log'])
        assert sha(path) == result[stage]['sha256']
        lines = path.read_text().splitlines()
        report['logs'][str(path)] = {'sha256': sha(path), 'last_line': lines[-1]}
        if stage == 'red':
            failures = [line for line in lines if line.startswith('FAILED ')]
            assert len(failures) == 22
            report['logs'][str(path)]['failure_lines'] = failures

initial_review = json.loads((ROOT / 'evidence/2026-refresh/phase2b-review.json').read_text())
initial_logs = next(check['log_identities'] for check in initial_review['checks_performed']
                    if check['check'] == 'Retained red/green logs and evidence truthfulness')
for name, record in initial_logs.items():
    path = AUTHOR / name
    assert sha(path) == record['sha256']
    report['logs'][str(path)] = {'sha256': sha(path), 'last_line': path.read_text().splitlines()[-1]}

combined = evidence['review_corrections']['combined_source']
pinned = Path(combined['owned_read_only_copy'])
assert sha(pinned) == combined['source_sha256']
assert pinned.read_bytes() == git('show', OLD_D + ':plato/utils/s3.py')
assert pinned.read_bytes() == git('show', D + ':plato/utils/s3.py')
assert pinned.read_bytes() == (SCRATCH / 's3_aa232791.py').read_bytes()
assert sha(Path(combined['integration_probe'])) == combined['probe_sha256']
assert (Path('/private/tmp/plato-refresh-worktrees/payloads') / 'plato/utils/s3.py').read_bytes() == pinned.read_bytes()
report['combined_source'] = {'old_d': OLD_D, 'current_d': D,
                             'current_d_tree': git('rev-parse', D + '^{tree}').decode().strip(),
                             'implementation': '639ca69bf4eaeff868462d0b30a5fcc72218f061',
                             'source_sha256': sha(pinned), 'identical_between_d_candidates': True,
                             'author_probe_sha256': combined['probe_sha256']}

canonical = lambda event: json.dumps(event, sort_keys=True)
for run_root in [AUTHOR, AUTHOR / 'review-fixes']:
    for run in ['accepted313', 'accepted314']:
        records = sorted((run_root / run).rglob('result.json'))
        assert len(records) == 48
        forced = []
        record_hashes = {}
        for path in records:
            data = json.loads(path.read_text())
            assert not data['survivors']
            durable = [json.loads(line) for p in path.parent.glob('events-*.jsonl')
                       for line in p.read_text().splitlines()]
            assert sorted(map(canonical, durable)) == sorted(map(canonical, data['events']))
            record_hashes[str(path)] = sha(path)
            if data['forced']:
                forced.append({'path': str(path), 'case': data['case'],
                               'options': data['options'], 'forced': data['forced']})
        assert len(forced) == 5
        socket = next(p for p in records if json.loads(p.read_text())['case'] == 'socket_round')
        data = json.loads(socket.read_text())
        assert data['returncode'] == 0 and not data['timed_out'] and not data['forced']
        trained = [e for e in data['events'] if e['event'] == 'client_trained']
        received = [e for e in data['events'] if e['event'] == 'server_received']
        baseline = next(e['weights'] for e in data['events'] if e['event'] == 'server_baseline')
        final = next(e['weights'] for e in data['events'] if e['event'] == 'server_aggregate')
        assert len(trained) == len(received) == 2
        assert sorted(e['samples'] for e in trained) == [2, 6]
        assert len({e['pid'] for e in trained}) == 2
        assert {e['pid'] for e in trained} == {e['pid'] for e in data['events'] if e['event'] == 'child_returned'}
        errors = {}
        artifacts = {}
        for key in final:
            denominator = sum(e['samples'] for e in received)
            expected = sum(e['samples'] * np.asarray(e['weights'][key], dtype=np.float64)
                           for e in received) / denominator
            errors[key] = float(np.max(np.abs(np.asarray(final[key], dtype=np.float64) - expected)))
            assert errors[key] <= 1.5e-8
        for client in trained:
            arrived = next(e for e in received if e['client_id'] == client['client_id'])
            assert arrived['samples'] == client['samples']
            assert arrived['weights'] == client['weights'] and client['weights'] != baseline
            path = socket.parent / 'models/pretrained' / f"startup_tiny_{client['client_id']}_{client['pid']}.safetensors"
            stored = deserialize_tree(path.read_bytes())
            for key in stored:
                np.testing.assert_array_equal(stored[key].numpy(), client['weights'][key])
            artifacts[str(path)] = sha(path)
        for folder, name in [('models/pretrained', 'startup_tiny.safetensors'),
                             ('checkpoints', 'checkpoint_startup_tiny_1.safetensors')]:
            path = socket.parent / folder / name
            stored = deserialize_tree(path.read_bytes())
            for key in stored:
                np.testing.assert_array_equal(stored[key].numpy(), final[key])
            artifacts[str(path)] = sha(path)
        report['runs'][str(run_root / run)] = {
            'records': 48, 'survivors': 0, 'result_hashes': record_hashes,
            'deliberate_negative_containment': forced,
            'all_durable_events_match_results': True,
            'socket_result': str(socket), 'socket_result_sha256': sha(socket),
            'socket_elapsed': data['elapsed'], 'socket_forced': data['forced'],
            'socket_event_hashes': {str(p): sha(p) for p in socket.parent.glob('events-*.jsonl')},
            'trained': [{'id': e['client_id'], 'samples': e['samples'], 'pid': e['pid']} for e in trained],
            'maximum_weighted_reference_errors': errors, 'artifact_hashes': artifacts}

report['all_changed_files_match_exact_candidate'] = True
report['candidate_clean'] = not git('status', '--porcelain')
(SCRATCH / 'evidence-audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'candidate': B, 'runs': {k: {'records': v['records'], 'survivors': v['survivors'],
                  'errors': v['maximum_weighted_reference_errors']} for k, v in report['runs'].items()},
                  'combined_source': report['combined_source'], 'candidate_clean': report['candidate_clean']}))
