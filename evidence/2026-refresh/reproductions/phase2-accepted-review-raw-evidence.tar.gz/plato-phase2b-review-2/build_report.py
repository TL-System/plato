"""Build the sole root-owned artifact for the independent correction review."""

import ast
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

SCRATCH = Path('/tmp/plato-phase2b-review-2')
SOURCE = Path('/private/tmp/plato-refresh-worktrees/runtime')
ROOT = Path('/Users/bli/Playground/plato')
B = '7753ca37bacbbdbcaef4192150e6532d79247011'
INITIAL = 'b3b038efa376b060e1c01f1da39173240768a019'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def resource(path):
    return {'path': str(path), 'sha256': sha(path)}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=SOURCE).decode().strip()


audit = json.loads((SCRATCH / 'evidence-audit.json').read_text())
assert git('rev-parse', 'HEAD') == B
assert git('status', '--porcelain') == ''
disconnect = {}
for version in ['313', '314']:
    path = SCRATCH / ('confirmed' + version + '.log')
    disconnect[version] = {'log': resource(path)}
    for line in path.read_text().splitlines():
        for phase in ['before', 'after']:
            prefix = 'review2 disconnect ' + phase + ' '
            index = line.find(prefix)
            if index >= 0:
                disconnect[version][phase] = ast.literal_eval(line[index + len(prefix):])
    assert disconnect[version]['before']['deferred'] == [8]
    assert disconnect[version]['after']['assignments'] == {'lost': 8}
(SCRATCH / 'disconnect-result.json').write_text(json.dumps(disconnect, indent=2) + '\n')

threads = 'PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1'
checks = []
for version, python in [('313', '3.13.16'), ('314', '3.14.8')]:
    checks.append({
        'check': 'Independent affected runtime suite excluding unchanged startup subprocess matrix',
        'python': python,
        'command': f'{threads} {SCRATCH}/venv{version}/bin/python -m pytest tests/clients tests/servers tests/callbacks tests/integration/test_smoke_configs.py -q -p no:cacheprovider --basetemp {SCRATCH}/pytest{version}',
        'cwd': str(SCRATCH / 'candidate'),
        'result': '179 passed; no skips or warnings',
        'log': resource(SCRATCH / ('runtime' + version + '.log')),
    })
    checks.append({
        'check': 'Independent final correction, numerical and disconnect probes',
        'python': python,
        'command': f'{threads} {SCRATCH}/venv{version}/bin/python -m pytest tests/test_review2_probes.py tests/test_review2_disconnect_probe.py -q -s -p no:cacheprovider --basetemp {SCRATCH}/confirmed{version}',
        'cwd': str(SCRATCH / 'candidate'),
        'result': '22 passed, 1 failed. Sole product failure is R2B-04 at the final absent-session assertion.',
        'log': resource(SCRATCH / ('confirmed' + version + '.log')),
        'scope': 'F10, F11 and 12 F18 callback-transformation cases reused the original independent review source; seven new positive correction cases and the disconnect degradation case were independently authored in owned scratch. Actual runtime selection, batching, default staleness predicate, ingress, heap, accounting and disconnect execute. Payload/report generation, outbound network and aggregate/wrap are stubs.',
    })
    checks.append({
        'check': 'Actual immutable D S3 utility writer and B bounded HTTP reader',
        'python': python,
        'command': f'{threads} {SCRATCH}/venv{version}/bin/python -m pytest tests/test_review2_probes.py tests/test_review2_s3_combined.py -q -s -p no:cacheprovider --basetemp {SCRATCH}/probes{version}',
        'result': 'All 24 writer/botocore-presigner/bounded-reader integration cases passed. This early combined run had 44 passes and two reviewer harness cleanup failures; those two lacked a configured Socket.IO stub, were corrected only in owned scratch, and both pass in the final 22-case positive probe set.',
        'log': resource(SCRATCH / ('probes' + version + '.log')),
        'source': resource(SCRATCH / 'candidate/tests/test_review2_s3_combined.py'),
        'scope': 'Author 24-case probe copied into owned scratch, changing only pinned utility source pathname. Real exact D constructor, head requests, send_to_s3 -> put_to_s3, Requests PUT and botocore presigning execute against local HTTP. Empty/prefixed/nested/trailing-slash namespaces, full/minimal adapters, successful reads, size rejection and absolute deadline execute. Shipped eight minimal-adapter cases separately cover already-qualified keys and leading/trailing slashes.',
    })

checks.extend([
    {'check': 'Retained evidence integrity and numerical socket references',
     'command': f'PYTHONDONTWRITEBYTECODE=1 PYTHONPATH={SCRATCH}/candidate OMP_NUM_THREADS=1 {SCRATCH}/venv313/bin/python {SCRATCH}/audit_evidence.py',
     'result': 'Verified every changed source/test file against exact B git objects; original accepted startup sources/fixtures byte-identical to phase base. All declared correction red/green/broad log hashes and original reviewed log hashes match. Inspected 192 retained startup records (96 initial plus 96 correction), each durable event stream matches its result, zero survivors, five deliberate negative containment cases per run. Both corrected socket rounds return naturally with separate real CPU clients and actual 2/6 reports. Four socket rounds including initial evidence reproduce weighted NumPy float64 errors <=1.4901161193847656e-08; client/final/checkpoint Safetensors equal recorded values.',
     'source': resource(SCRATCH / 'audit_evidence.py'),
     'output': resource(SCRATCH / 'evidence-audit.json'),
     'log': resource(SCRATCH / 'evidence-audit.log')},
    {'check': 'Actual author correction red and green evidence',
     'result': 'Verified both interpreter log hashes, meaningful 22-failure breakdown, 40-case correction green results and final 227-pass affected matrices. Collection of exact B yields 227 affected nodes, including 48 unchanged startup cases. The separate actual D combination adds 24 distinct nodes: 251 per interpreter, not 227+40. Initial collection-only author harness failures remain excluded from product red evidence.',
     'logs': audit['logs'],
     'collection': resource(SCRATCH / 'collection227.log')},
    {'check': 'Static source checks',
     'result': 'Scoped production Ruff import-order check and git diff --check from phase base to exact B pass. No changes to candidate, other environments, metadata, CI, trainer/algorithm sources or D worktree.'},
])

finding = {
    'id': 'R2B-04',
    'severity': 'medium',
    'blocking': True,
    'title': 'A deferred urgent request is assigned to a disconnected physical worker and permanently stops recovery mode.',
    'path': 'plato/servers/base.py',
    'line': 1277,
    'related_lines': [1252, 1274, 1289, 1300, 1308, 1476, 1487, 1504, 1511],
    'description': 'The corrected same-worker queue retains old reports, but the urgent loop checks only whether their sid is busy. In general.debug=false recovery mode, disconnect removes the physical worker and its current urgent assignment while leaving its completed deferred reports retained. When another worker finishes its valid urgent response, the urgent loop removes the next retained report and issues a new assignment to the removed sid. Its emit has no recipient. The session validator correctly refuses a report from that unregistered sid, so this assignment can never complete. No active transfer timer exists, and the periodic task does not advance simulated-time rounds.',
    'reachability': 'Two physical workers with max_concurrency=2 on one device, per_round=4, minimum_clients=1, asynchronous simulated wall time, request_update=true, staleness_bound=1, rounds=10 and general.debug=false. Actual selection/batching/ingress creates round-1 reports 7/2/8/9, followed by 9 in rounds 2 and 3. Logical clients 7 and 8 belong to the same reused physical worker. The default staleness predicate issues client 7 to lost and client 2 to survivor, deferring client 8. Disconnect lost, then finish survivor/client 2 through real handlers. The server issues client 8 to the absent lost session.',
    'reproduction': {
        'source': resource(SCRATCH / 'candidate/tests/test_review2_disconnect_probe.py'),
        'helper_source': resource(SCRATCH / 'candidate/tests/test_review2_probes.py'),
        'test': 'tests/test_review2_disconnect_probe.py::test_actual_batched_urgent_disconnect_never_reassigns_dead_session',
        'bounded_seconds': 2,
        'interpreters': ['3.13.16', '3.14.8'],
        'results': disconnect,
        'raw_result': resource(SCRATCH / 'disconnect-result.json'),
        'observed': 'Only survivor remains registered. assignments={lost:8}, training_sids=[lost], training_clients=[8], update_requested[8]=true, active_transfers=[], close_called=0; round and round_after_periodic both equal 3. Absent-session response is rejected before parsing. Final failure is the intended no-dead-session-assignment assertion after cleanup.',
        'stubs': 'Outbound emit is AsyncMock. _send generates inert reports/payloads via actual ingress. Aggregation, wrap_up and close are inert; selection, batching, queue construction, default urgency predicate, assignment validation, disconnect recovery branch, second urgent completion and periodic task are production code. No trainer snapshot decoder is invoked.'},
    'required_correction': 'Handle retained/deferred urgency when its physical worker disappears. Never create an outstanding assignment for an unregistered sid. Continue or end with a bounded surfaced failure according to the existing disconnect policy, keeping usable completed reports and exact byte accounting consistent. Add this actual-batching degradation regression and verify surviving-worker progress or explicit termination. Preserve current session rejection and concurrent requests for live distinct workers; no auth, nonce or wire change is needed.',
    'test_gap': 'The new shared-worker correction regression finishes both responses from a live worker. The disconnect regression clears one active transfer but has no deferred urgent report and does not test subsequent round progress.',
    'baseline_boundary': 'This is a remaining material failure in the in-scope correction and recovery path, not a claim that general.debug=false recovery first became defective in this commit. Initial R2B-03 already prevented the normal same-worker flow; correcting its serialization exposes the deferred-worker-loss case.'
}

report = {
    'schema_version': 1,
    'review': 'Fresh independent Phase2B correction review 2',
    'reviewer': 'plato-phase2-runtime-review-2',
    'requested_model': 'GPT6.1Solxhigh',
    'completed_at_utc': datetime.now(timezone.utc).isoformat(),
    'decision': 'CHANGES_REQUESTED',
    'decision_basis': ['One material medium disconnect-recovery finding remains; no critical/high findings in this review.',
                       'Original responsive-worker R2B-03, R2B-01, R2B-02, R2B-L01 and B-local S3 namespace corrections pass. Their positive results do not waive R2B-04.'],
    'identities': {
        'candidate_commit': B, 'candidate_tree': audit['candidate_tree'],
        'implementation_commit': audit['implementation'], 'implementation_tree': audit['implementation_tree'],
        'initial_reviewed_candidate': INITIAL, 'phase_base': audit['base'],
        'candidate_worktree': str(SOURCE), 'root_worktree': str(ROOT), 'review_scratch': str(SCRATCH),
        'candidate_read_only': True, 'candidate_status_before_and_after': 'clean',
        'evidence_commit_boundary': 'Exact B is an evidence-only direct child of 516da21d; only phase2b-validation.json differs.',
        'all_changed_source_and_test_files_match_exact_git_objects': True,
        'base_to_candidate_diff': resource(SCRATCH / 'base-to-candidate.diff'),
        'correction_diff': resource(SCRATCH / 'corrections.diff'),
        'source_sha256': audit['source_files'], 'authority_sha256': audit['authority_files'],
        'review_environments': [{'python': '3.13.16', 'path': str(SCRATCH / 'venv313'),
                                'sync_log': resource(SCRATCH / 'sync313.log')},
                               {'python': '3.14.8', 'path': str(SCRATCH / 'venv314'),
                                'sync_log': resource(SCRATCH / 'sync314.log')}],
        'provision': 'git archive exact B into owned scratch; UV_PROJECT_ENVIRONMENT=<owned venv> uv sync --locked --group dev --python 3.13/3.14. All execution uses zsh -lc; PYTHONDONTWRITEBYTECODE=1 prevents imported read-only files from gaining cache writes.',
        'd_source_verification': audit['combined_source']},
    'scope': {
        'authorities_read': ['AGENTS.md', 'accepted plan.md', 'accepted plan-addendum.json and acceptance',
                             'entire phase2b-validation.json including initial evidence and review_corrections',
                             'root phase2b-review.json and phase2b-root-probe.json'],
        'included': ['F10 own-client cleanup', 'F11 actual PORT writer, historical reader and weighted numerical reference',
                     'F18 raw/transformed/direct/legacy/delta/cross-silo pre-mutation validation',
                     'runtime session/registration/selection/urgent identity, heap/time invariants',
                     'report/socket/S3/file limits, deadlines and cleanup',
                     'distinct transfer accounting, retained completion visibility and lifecycle',
                     'callback/context/async/buffered/split/personalized/cross-silo and evaluation regressions',
                     'actual D S3 source identity and bounded writer-reader integration',
                     'retained startup/process/event/tensor/source/log evidence'],
        'excluded': ['F07 global checkpoint codec and F21-F26 trainer/DP/personalization lifecycle owned by 2C',
                     'MLX tree validation owned by 3A', 'HE/MPC and S3 utility fixes/review owned by 2D',
                     'auth, nonces, new wire protocols or untrusted-pickle protection']},
    'findings': [finding],
    'mandatory_contract_disposition': {
        'R2B-03': {'status': 'Responsive-worker acceptance passes; recovery corner remains blocked by R2B-04',
                    'result': 'Actual single-worker rounds 7/2/9 then 9/9 issue exactly one outstanding urgent assignment, preserve the other report/payload and 190-byte ownership until dispatch, accept both responses, reject wrong/deferred/old/unknown identities, aggregate both and reach round 4. Distinct-worker assignments are established before any emit await; immediate response inside each emit passes without premature aggregation.'},
        'R2B-01': {'status': 'PASS', 'result': 'Selective removal restores the heap. Actual ingress-created partial heap selects [20,9,28] and [20,9,28,31], with the independently recorded finish-time reference. Simulated wall time stays at 50 for earlier responses in both minimum-selection and stale-drain paths.'},
        'R2B-02': {'status': 'PASS', 'result': 'Two distinct retained completions for logical ID 7 across workers each count once at the actual _select_clients send-await boundary. 190+190 bytes against budget 400 reject the third 169-byte report before load_pickle. Reuse releases only its cache; malformed third-worker ingress and first-worker disconnect preserve queued bytes. Processed release and close clear the correct owners and queue objects. Legacy report/payload values remain visible.'},
        'R2B-L01': {'status': 'PASS', 'result': 'The cumulative reserve check enforces max_buffered_bytes as well as max_payload_bytes before append. Actual client socket and local HTTP S3 reject 82-byte payloads at a 20-byte cap and clear transfer state; bounded simulated-file cap remains consistent.'},
        'S3_B_local': {'status': 'PASS; final accepted B/D combination still required at root',
                       'result': 'Minimal interface requires only key_prefix, bucket and s3_client.generate_presigned_url. Empty, prefixed, qualified, nested and leading/trailing-slash cases pass. Actual immutable D S3 utility source is identical at a4a4733 and current aa232791 (SHA256 a26d306d...). All 24 actual writer/presigner/bounded-reader key/size/deadline cases pass on both interpreters; copied namespace assertions alone are not the evidence.'},
        'F10': {'status': 'PASS', 'result': 'Actual disconnect cleans current logical identity 17 .pth/.pth.pkl/.safetensors files, preserving former/other identities, server resume state, unrelated suffixes and directories.'},
        'F11': {'status': 'PASS locally; F07 handoff retained', 'result': 'Actual weights_aggregated hook writes Safetensors plus sidecar. Reader deserializes repository tree and CPU weights_only legacy .pth. Actual stale cosine 0.6 and independent 2/6 stale weighting pass; reversed insertion order with two parameter keys gives cosine 1/3 while values, storage, CPU device and eval mode remain unchanged.'},
        'F18': {'status': 'PASS', 'result': 'Raw/transformed sample weights and cardinality reject before ordinary, legacy or delta mutation, including negative/nonfinite counts and nonfinite total. Twelve independent callback mutations pass; shipped direct/legacy/delta/raw/hook/reverse/fractional/zero/feature and cross-silo trainer-identity-before-mutation cases pass.'},
        'identity_and_bounded_ingress': {'status': 'PASS in tested ingress; R2B-04 is dispatcher liveness',
                                        'result': 'Current assignment and embedded identity checks reject wrong/unknown/stale/duplicate ingress and S3 references before affecting other peers. Finite report/chunk/payload/count/deadline limits, malformed/trailing/truncated/incomplete cleanup, retry, header/stream S3 caps and timeout tests pass. No weakening of the identity guard is needed.'},
        'callbacks_selection_evaluation': {'status': 'PASS for tested contracts',
                                           'result': 'Registration order and callback-body AttributeError propagation pass. Async partial replacement, FedBuff uniform mean, actual FedAsync example staleness mixing, personalized/split selection, central-edge assignment, cross-silo pre-mutation validation and finite all-zero evaluation pass.'},
        'startup_runtime': {'status': 'PASS retained exact-source acceptance',
                           'result': '48 unchanged startup cases per interpreter and final 227-pass author matrices verified. Corrected real two-client CPU socket results have natural returns, no forced success or survivors, actual sample counts 2/6 and numerical error <=1.4901161193847656e-08. No full startup matrix rerun; retained raw artifacts and hashes independently rechecked.'}},
    'checks_performed': checks,
    'retained_runtime_evidence': audit['runs'],
    'count_policy': 'Author final 227 affected nodes plus 24 separate actual D combination nodes = 251 distinct per interpreter. The author 40-case correction run overlaps 16 affected nodes. Reviewer reports separate 179-node suite, 22 positive probes, 24 integration cases and one product-negative probe; repeats and intermediate harness failures are not additive acceptance counts.',
    'handoffs_and_pending_integration': [
        {'id': 'B_REVIEW_GATE', 'owner': 'Original B author/root', 'status': 'Not passed',
         'requirement': 'Resolve R2B-04 and obtain fresh exact-candidate review. Shared checkpoint ownership transfer to 2C remains conditioned on root PASS.'},
        {'id': 'B_D_COMBINATION', 'owner': 'Root', 'status': 'Required after both owners are accepted',
         'requirement': 'Revalidate final accepted B and D combined source. Preserve/promote the actual utility writer-to-bounded-reader regression into final CI; scratch-only evidence and duplicated namespace expectations do not replace that final coverage. Current D aa232791 still awaits its separate review.'},
        {'id': 'F07_F21_F26', 'owner': '2C', 'status': 'Explicit future dependency, not new B finding',
         'requirement': 'Retain the full checkpoint writer/reader/sidecar inventory. Actual urgent snapshot decoder and epoch ordering F26 remain unqualified; this review validates runtime dispatch and ingress with inert trainer reports, not full urgent checkpoint end-to-end.'},
        {'id': 'MLX_F17', 'owner': '3A', 'status': 'Later narrow ingress validation extension',
         'requirement': 'Extend raw/transformed pre-dispatch tree validation, including zero weights and both arrival orders, after B acceptance.'},
        {'id': 'PHASE_INTEGRATION', 'owner': 'Root', 'status': 'Pending',
         'requirement': 'Complete final combined full validation and phase gate; this is a component correction review.'}],
    'explicit_limits': [
        'No live cloud S3, GPU/distributed execution, production multi-silo run or whole-stack Python 3.14 support claim.',
        'Wire limits and session binding operate within trusted peers/storage. Pickle object expansion and arbitrary execution are outside these caps; no auth/nonces/new protocol required.',
        'Same logical identity replay during an indistinguishable fresh assignment is outside the unchanged wire contract.',
        'Urgent runtime probes exercise production batching/dispatch/ingress/heap/round logic using trainer stubs. Actual urgent snapshot metadata decoder and epoch sorting remain F26/2C dependencies.',
        'PORT non-mutation executed on CPU; other-device preservation follows the inspected detach().cpu() copies, not an accelerator test.',
        'The new medium finding specifically requires general.debug=false recovery mode and physical-worker disconnect with a deferred urgent report. Default debug/unspecified mode terminates on disconnect and does not demonstrate this stall.',
        'Initial reviewer monotonic cleanup failures lacked a configured sio stub; corrected in owned scratch. An early disconnect setup assertion counted a current non-stale report as deferred; corrected filtering and realistic max_concurrency=2/rounds=10 before the retained final behavioral reproduction. No candidate regression was inferred from harness failures.',
        'No full eight-minute startup matrix repeated. Exact-source final author logs and retained actual runtime resources independently checked; root combined full validation remains required.',
        'No production/test changes to candidate or other owner worktrees, no environment mutation outside owned scratch, no metadata/CI edits, commits/push/PR changes, questions or nested agents.'],
    'owned_resources': {'root': str(SCRATCH),
                        'policy': 'Retain exact archive, owned 3.13/3.14 venvs, probes, raw logs, pytest bases, evidence audit and diffs for root/author. No other agent resources removed.',
                        'write_scope': 'Only this root evidence/2026-refresh/phase2b-review-2.json and owned /tmp/plato-phase2b-review-2 scratch.'},
}

destination = ROOT / 'evidence/2026-refresh/phase2b-review-2.json'
destination.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'decision': report['decision'], 'finding': finding['id'],
                  'severity': finding['severity'], 'path': str(destination),
                  'sha256': sha(destination), 'candidate_clean': git('status', '--porcelain') == ''}))
