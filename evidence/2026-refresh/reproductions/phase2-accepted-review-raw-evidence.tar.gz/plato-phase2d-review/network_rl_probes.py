"""Owned independent local HTTP and active policy probes."""
import asyncio
import copy
import importlib.util
import json
import pickle
import random
import subprocess
import sys
import threading
import time
from collections import Counter
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import parse_qs, unquote, urlparse
from xml.sax.saxutils import escape

import numpy as np
import torch
from gymnasium import spaces
ROOT=Path('/private/tmp/plato-refresh-worktrees/payloads');sys.path.insert(0,str(ROOT))
SCRATCH=Path('/tmp/plato-phase2d-review')
from plato.utils import s3
from plato.config import Config
from tests.integration.utils import configure_environment, build_minimal_config
from plato.utils.reinforcement_learning.policies import ddpg,sac,td3

out={'python':sys.version,'network':[],'rl':[]}
state=SimpleNamespace(objects={},requests=[],fail_remaining=0,pages=[],mode='normal',release=threading.Event())
class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def respond(self,status,body=b''):
        self.send_response(status);self.send_header('Content-Length',str(len(body)));self.end_headers()
        if self.command!='HEAD':
            try:self.wfile.write(body)
            except (BrokenPipeError,ConnectionResetError):pass
    def handle_request(self):
        parsed=urlparse(self.path);key=unquote(parsed.path).removeprefix('/bucket/');q=parse_qs(parsed.query)
        state.requests.append((self.command,key,q))
        if state.mode=='forbidden':return self.respond(403)
        if state.fail_remaining>0:state.fail_remaining-=1;return self.respond(503)
        if self.command=='HEAD':return self.respond(200 if parsed.path=='/bucket' or key in state.objects else 404)
        if self.command=='PUT':state.objects[key]=self.rfile.read(int(self.headers['Content-Length']));return self.respond(200)
        if self.command=='DELETE':state.objects.pop(key,None);return self.respond(204)
        if q.get('list-type')==['2']:
            token=q.get('continuation-token',['0'])[0];state.pages.append(token)
            matches=sorted(k for k in state.objects if k.startswith(q.get('prefix',[''])[0]))
            # Deliberately empty middle page with continuation, not merely an empty bucket.
            keys=matches[:1] if token=='0' else [] if token=='1' else matches[1:]
            contents=''.join('<Contents><Key>'+escape(k)+'</Key></Contents>' for k in keys)
            next_token='<NextContinuationToken>'+str(int(token)+1)+'</NextContinuationToken>' if token!='2' and matches else ''
            body=('<ListBucketResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/"><IsTruncated>'+str(bool(next_token)).lower()+'</IsTruncated>'+contents+next_token+'</ListBucketResult>').encode()
            return self.respond(200,body)
        if key not in state.objects:return self.respond(404)
        return self.respond(200,state.objects[key])
    do_HEAD=handle_request;do_GET=handle_request;do_PUT=handle_request;do_DELETE=handle_request
service=ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=service.serve_forever,daemon=True);thread.start()
previous_config=s3.Config;s3.Config=lambda:SimpleNamespace(server=SimpleNamespace())
# Independent snapshot is loaded without touching the 2B worktree.
b_source=subprocess.check_output(['git','show','b3b038efa376b060e1c01f1da39173240768a019:plato/clients/transport.py'],cwd=ROOT)
b_path=SCRATCH/'transport_b3b038e.py';b_path.write_bytes(b_source)
spec=importlib.util.spec_from_file_location('review_transport',b_path);transport=importlib.util.module_from_spec(spec);sys.modules[spec.name]=transport;spec.loader.exec_module(transport)
try:
    for prefix in ['', 'outer/rounds', '/outer/rounds/']:
        state.objects={};state.requests=[];state.pages=[]
        storage=s3.S3(endpoint=f'http://127.0.0.1:{service.server_port}',access_key='local-key',secret_key='local-secret',bucket='s3://bucket/'+prefix)
        canonical=prefix.strip('/');physical=(canonical+'/' if canonical else '')+'nested/model'
        storage.put_to_s3('nested/model',{'w':[1,2]});storage.send_to_s3(physical,{'w':[99]})
        assert state.objects.keys()=={physical};assert storage.receive_from_s3(physical)=={'w':[1,2]}
        storage.put_to_s3(physical,{'w':[3,4]});assert storage.receive_from_s3('nested/model')=={'w':[3,4]}
        storage.put_to_s3('second',6);state.objects['unrelated'] = pickle.dumps(9)
        if not canonical:state.objects.pop('unrelated')
        expected=sorted([physical,(canonical+'/' if canonical else '')+'second'])
        assert storage.lists()==expected;assert state.pages==['0','1','2']
        for key in storage.lists():assert storage.receive_from_s3(key) in [{'w':[3,4]},6]
        async def bounded_receive(key):
            transfer=transport.InboundTransfer(transport.TransportLimits(max_payload_bytes=1024,payload_timeout=2),lambda:None)
            try:return await transport.receive_s3_payload(storage,key,transfer,transfer.reserve)
            finally:transfer.close()
        combined={}
        for kind,key in [('logical','nested/model'),('qualified',physical)]:
            try:value=asyncio.run(bounded_receive(key));combined[kind]={'result':'passed','value':value}
            except ValueError as exc:combined[kind]={'result':'failed','error':str(exc)}
        out['network'].append({'prefix':prefix,'physical_key':physical,'utility_all_operations':'passed','pagination_tokens':['0','1','2'],'empty_intermediate_page':'passed','2B_reader_integration':combined})
        storage.delete_from_s3('nested/model');storage.delete_from_s3(expected[1] if expected[1]!=physical else expected[0])
        if canonical:assert state.objects=={'unrelated':pickle.dumps(9)}
        else:assert not state.objects
        assert storage.lists()==[]
    state.objects={};state.requests=[]
    client=s3.S3(endpoint=f'http://127.0.0.1:{service.server_port}',access_key='local-key',secret_key='local-secret',bucket='bucket')
    state.fail_remaining=2;client.put_to_s3('recover',{'value':7})
    put_attempts=sum(method=='PUT' for method,_,_ in state.requests);assert put_attempts==3
    state.fail_remaining=3;started=time.monotonic()
    try:client.receive_from_s3('recover')
    except ValueError as exc:error=str(exc)
    else:raise AssertionError('exhausted 503 silently succeeded')
    duration=time.monotonic()-started
    get_attempts=sum(method=='GET' for method,_,_ in state.requests);assert get_attempts==3 and duration<2
    state.mode='forbidden'
    try:client.send_to_s3('recover',99)
    except Exception as exc:service_error=type(exc).__name__
    else:raise AssertionError('forbidden HEAD not propagated')
    assert pickle.loads(state.objects['recover'])=={'value':7}
    out['network'].append({'default_MAX_ATTEMPTS':client.MAX_ATTEMPTS,'NETWORK_TIMEOUT':client.NETWORK_TIMEOUT,'PUT_transient_recovery_attempts':put_attempts,'GET_exhaustion_attempts':get_attempts,'GET_duration_seconds':duration,'403_HEAD_error':service_error})
finally:
    service.shutdown();service.server_close();thread.join(2);s3.Config=previous_config

runtime=SCRATCH/('rl-runtime-'+str(sys.version_info.minor));runtime.mkdir(exist_ok=True)
config=build_minimal_config();config['algorithm'].update(max_action=1,learning_rate=.001,replay_size=32,replay_seed=8,batch_size=3,update_iteration=2,gamma=.91,tau=.1,policy_noise=0,noise_clip=.5,policy_freq=1,recurrent_actor=False,hidden_size=8,deterministic=False,automatic_entropy_tuning=True,alpha=.2,epsilon=1e-6,model_name='review')
with configure_environment(config,runtime_root=runtime):
    for kind in ['ddpg','td3','sac','sac_deterministic','td3_rnn']:
        Config.algorithm=SimpleNamespace(**config['algorithm']);Config.algorithm.deterministic=kind=='sac_deterministic';Config.algorithm.recurrent_actor=kind=='td3_rnn'
        torch.manual_seed(701);np.random.seed(702)
        policy=sac.Policy(3,spaces.Box(-1,1,shape=(2,),dtype=np.float32)) if kind.startswith('sac') else (ddpg if kind=='ddpg' else td3).Policy(3,2)
        for i in range(7):
            st=np.array([.1*i,-.2,.3]);rec=(st,np.array([.4,.6]),.2*i,st+.1,float(i==6))
            if kind=='td3_rnn':h,c=policy.get_initial_states();rec+=(h,c,h,c)
            policy.replay_buffer.push(rec)
        before={k:v.detach().clone() for k,v in policy.actor.named_parameters()};critic_before={k:v.detach().clone() for k,v in policy.critic.named_parameters()}
        loss=policy.update();assert np.isfinite(loss).all()
        changed=sum(not torch.equal(v,before[k]) for k,v in policy.actor.named_parameters());critic_changed=sum(not torch.equal(v,critic_before[k]) for k,v in policy.critic.named_parameters());assert changed>0 and critic_changed>0
        source_keys=list(policy.actor.state_dict());policy.save_model(4)
        with torch.no_grad():
            for p in policy.actor.parameters():p.add_(1)
            for p in policy.critic.parameters():p.add_(1)
        policy.load_model(4)
        assert list(policy.actor.state_dict())==source_keys
        for model,target in [(policy.actor,policy.actor_target),(policy.critic,policy.critic_target)]:
            for a,b in zip(model.parameters(),target.parameters()):assert torch.equal(a,b)
        # Backpropagate after checkpoint synchronization as well.
        loss_after=policy.update();assert np.isfinite(loss_after).all()
        out['rl'].append({'policy':kind,'actor_changed_parameters':changed,'critic_changed_parameters':critic_changed,'losses':list(loss),'post_load_losses':list(loss_after),'checkpoint_keys_and_both_targets':'passed'})
    Config.server=SimpleNamespace(synchronous=False);Config.algorithm.recurrent_actor=True
    torch.manual_seed(111)
    actor=td3.RNNActor(3,4,8,1);critic=td3.RNNCritic(3,4,8)
    states=[torch.tensor([[.1,.2,.3]]),torch.arange(9).reshape(3,3).float()/10]
    snapshots=[v.clone() for v in states]
    acts,_=actor(states);qa,qb=critic(states,acts,None,None)
    qa_rows=[];qb_rows=[];acts_rows=[]
    for s in states:
        a,_=actor([s]);x,y=critic([s],a,None,None);qa_rows.append(x);qb_rows.append(y);acts_rows.append(a)
    torch.testing.assert_close(acts,torch.cat(acts_rows),atol=1e-7,rtol=0)
    torch.testing.assert_close(qa,torch.cat(qa_rows),atol=1e-7,rtol=0);torch.testing.assert_close(qb,torch.cat(qb_rows),atol=1e-7,rtol=0)
    assert all(torch.equal(a,b) for a,b in zip(states,snapshots));assert not torch.count_nonzero(acts[0,1:]) and not torch.count_nonzero(acts[1,3:]);assert torch.allclose(acts.sum((1,2)),torch.ones(2))
    out['rl'].append({'recurrent_per_transition_actor_and_both_critics':'matches isolated evaluation','padding':'zero action and excluded critic values','source_sequences':'unchanged'})

# Invoke actual cleanup CLI solely on an owned miniature filesystem.
owned=SCRATCH/('cleanup-root-'+str(sys.version_info.minor));external=SCRATCH/('cleanup-external-'+str(sys.version_info.minor));owned.mkdir(exist_ok=True);external.mkdir(exist_ok=True);(external/'keep').write_text('preserve')
(owned/'linked').symlink_to(external,target_is_directory=True);(owned/'__pycache__').symlink_to(external,target_is_directory=True);(owned/'a').mkdir(exist_ok=True);(owned/'a'/'runtime').symlink_to(external,target_is_directory=True)
(owned/'b').mkdir(exist_ok=True);(owned/'b'/'runtime').mkdir(exist_ok=True);(owned/'b'/'runtime'/'temp').write_text('temporary');(owned/'b'/'runtime'/'external-link').symlink_to(external,target_is_directory=True)
cleanup=subprocess.run([sys.executable,'-B',str(ROOT/'cleanup.py'),str(owned)],text=True,capture_output=True,timeout=5)
assert cleanup.returncode==0 and (external/'keep').read_text()=='preserve' and not (owned/'b'/'runtime').exists()
out['cleanup']={'actual_CLI':'passed','external_symlinks':'preserved','owned_runtime':'removed'}
(SCRATCH/('network_rl'+str(sys.version_info.minor)+'.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
