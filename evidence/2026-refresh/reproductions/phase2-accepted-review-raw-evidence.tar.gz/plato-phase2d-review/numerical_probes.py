"""Independent bounded Phase 2D numerical/wire checks; writes owned scratch only."""
import asyncio
import copy
import hashlib
import importlib.util
import json
import math
import pickle
import random
import subprocess
import sys
import tomllib
from pathlib import Path
from types import SimpleNamespace
from struct import pack

import numpy as np
import torch
import tenseal as ts
from safetensors.numpy import save

ROOT = Path('/private/tmp/plato-refresh-worktrees/payloads')
sys.path.insert(0, str(ROOT))
SCRATCH = Path('/tmp/plato-phase2d-review')
from plato.serialization.safetensor import serialize_tree, deserialize_tree
from plato.processors import compress, decompress, model_quantize, model_dequantize
from plato.processors import model_quantize_qsgd as qe, model_dequantize_qsgd as qd
from plato.utils import toml_writer, unary_encoding
from plato.mpc import RoundInfoStore
from plato.processors.mpc_model_encrypt_additive import Processor as Additive
from plato.processors.mpc_model_encrypt_shamir import Processor as Shamir
from plato.servers.strategies.mpc import MPCAdditiveAggregationStrategy, MPCShamirAggregationStrategy
from tests.integration.utils import build_minimal_config, configure_environment

out = {'python':sys.version, 'candidate':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(), 'checks':[], 'defect_probes':[]}
def record(name, fn):
    try:
        value = fn()
        out['checks'].append({'name':name,'result':'passed','observed':value})
    except Exception as error:
        out['checks'].append({'name':name,'result':'failed','error':repr(error)})
        raise

def safetensors():
    leaves = [torch.arange(30, dtype=torch.float64).reshape(5,6).T,
              np.arange(30,dtype=np.int16).reshape(5,6)[::-1,::2],
              torch.tensor(3,dtype=torch.int64),np.array(False),
              torch.arange(8,dtype=torch.bfloat16),torch.empty(0,2)]
    tree={'model.layer.weight':leaves[0], 'literal[1]':leaves[1], 'other':tuple(leaves[2:]),'meta':[2,1.25,True,None,'λ',b'wire']}
    restored=deserialize_tree(serialize_tree(tree))
    for a,b in [(restored['model.layer.weight'],leaves[0]),(restored['literal[1]'],leaves[1]),*zip(restored['other'],leaves[2:])]:
        assert a.shape==b.shape and a.dtype==b.dtype
        if isinstance(b,torch.Tensor): assert torch.equal(a,b)
        else: np.testing.assert_array_equal(a,b)
    assert restored['meta']==tree['meta']
    # Construct the historical flat wire independently, without calling the flattener.
    meta={'':{'type':'dict','children':['module.weight'],'container':None,'backend':None,'dtype':None},
          'module.weight':{'type':'leaf','children':None,'container':None,'backend':'torch','dtype':'torch.float32'}}
    old_wire=save({'module.weight':np.array([1.,-2.],dtype=np.float32),'_tree_metadata':np.frombuffer(json.dumps(meta).encode(),dtype=np.uint8)})
    assert torch.equal(deserialize_tree(old_wire)['module.weight'],torch.tensor([1.,-2.]))
    for bad in [{'x.y':torch.tensor(1), 'x':{'y':torch.tensor(2)}}, {'a':[1], 'a[0]':2}, {'_tree_metadata':1}, {1:1,'1':2}]:
        try:serialize_tree(bad)
        except ValueError:pass
        else:raise AssertionError('accepted collision')
    return {'strided_scalar_dtype_leaves':len(leaves),'historical_wire':'compatible','collisions':'rejected'}
record('safetensors independent values/dtypes and historical wire',safetensors)

def qsgd():
    x=torch.tensor([-3.75,-.12,0.,.44,1.25,3.75],dtype=torch.float32).reshape(2,3).T
    source=x.clone(); statistics=[]
    for levels in [2,16,128]:
        enc=qe.Processor(client_id=1,quantization_level=levels); dec=qd.Processor(client_id=1,quantization_level=levels)
        random.seed(410)
        samples=torch.stack([dec.process(enc.process({'w':x}))['w'] for _ in range(512)])
        delta=(samples-x).abs(); bound=float(x.abs().max())/(levels-1)
        assert bool((delta<=bound+1e-6).all()); assert torch.equal(x,source)
        empirical_mean=samples.double().mean(0)
        stderr=samples.double().std(0,unbiased=True)/math.sqrt(512)
        assert bool(((empirical_mean-x.double()).abs() <= 6*stderr+1e-6).all())
        statistics.append({'levels':levels,'max_error':float(delta.max()),'bound':bound,'max_mean_error':float((empirical_mean-x.double()).abs().max())})
        for empty in [torch.empty(0,3),torch.tensor(0.)]:
            y=dec.process(enc.process({'w':empty}))['w']; assert y.shape==empty.shape and torch.equal(y,empty)
    buffers={'count':torch.tensor(2**40+3),'mask':torch.tensor([True,False])}
    y=qd.Processor(client_id=1).process(qe.Processor(client_id=1).process(buffers))
    for k in buffers:assert y[k].dtype==buffers[k].dtype and torch.equal(y[k],buffers[k])
    bad=[pack('!fIh',float('nan'),1,0)+b'\x00',pack('!fIh',1.,1,0)+b'\x7f',pack('!fIh',1.,2,1)+pack('!h',1)+b'\x01\x02']
    for blob in bad:
        try:qd.Processor(client_id=1).process({'w':blob})
        except ValueError:pass
        else:raise AssertionError('malformed QSGD accepted')
    return statistics
record('QSGD error bounds, stochastic expectation, RNG seed and empty/malformed',qsgd)

x=torch.tensor([1e38,-1e38,0.],dtype=torch.float32)
for levels in [2,16,64,128]:
    y=qd.Processor(client_id=1,quantization_level=levels).process(qe.Processor(client_id=1,quantization_level=levels).process({'w':x}))['w']
    normalized_reference=(torch.tensor([levels-1,-(levels-1),0],dtype=torch.float64)/(levels-1)*float(x.abs().max())).to(torch.float32)
    out['defect_probes'].append({'name':'QSGD finite scale overflow','levels':levels,'input':[str(a) for a in x.tolist()],'actual':[str(a) for a in y.tolist()],'reference':[str(a) for a in normalized_reference.tolist()],'actual_finite':bool(torch.isfinite(y).all())})

def compression():
    array=np.arange(48,dtype=np.float64).reshape(6,8)[::-1,::2]
    batch=[(array,np.empty((0,2),dtype=np.int64)),(array+1,np.array([7,2],dtype=np.uint8))]
    recovered=decompress.Processor().process(compress.Processor().process(batch))
    for pairs in zip(batch,recovered):
        for a,b in zip(*pairs):np.testing.assert_array_equal(a,b); assert a.dtype==b.dtype
    assert decompress.Processor().process(compress.Processor().process([]))==[]
    from plato.utils.zstd_helpers import get_zstd
    simple=np.arange(12,dtype=np.float32).reshape(3,4)
    old_wire=(simple.shape,simple.dtype,get_zstd().compress(simple.tobytes(),1))
    np.testing.assert_array_equal(decompress.Processor().process(old_wire),simple)
    for second in [np.zeros((3,4),dtype=np.float32),array.astype(np.int64)]:
        try:compress.Processor().process([(array,np.array([1])),(second,np.array([2]))])
        except ValueError:pass
        else:raise AssertionError('heterogeneous batch accepted')
    return {'strided_empty_targets':'exact','shared_header':'rejects shape/dtype mismatch','historical_wire':'compatible'}
record('compression independent strided/dtype and old wire',compression)

def toml():
    doc={'café':{'literal.dot':'日本語'},'groups':[{'name':'one','subgroups':[{'empty':{},'table':{'x':True}},{'table':{'x':False}}]},{'name':'two','subgroups':[{'table':{'x':True}}]}]}
    result=tomllib.loads(toml_writer.dumps(doc));assert result==doc
    return {'nested_array_table_depth':2,'BMP_unicode':'passed'}
record('TOML nested/Unicode independent stdlib reference',toml)
for doc in [{'🚀':1},{'title':'experiment 🚀'},{'tables':[{'𠮷':{'literal.dot':[1,2]}}]}]:
    wire=toml_writer.dumps(doc)
    try:parsed=tomllib.loads(wire); error=None
    except tomllib.TOMLDecodeError as exc:error=str(exc)
    out['defect_probes'].append({'name':'TOML non-BMP Unicode','document':doc,'output':wire,'parse_error':error})

config=build_minimal_config(clients_per_round=5,total_clients=5)
config['server']['mpc_shamir_threshold']=1
config['clients']['outbound_processors']=['mpc_model_encrypt_shamir']
runtime=SCRATCH/('independent-runtime-'+str(sys.version_info.minor));runtime.mkdir(exist_ok=True)
with configure_environment(config,runtime_root=runtime):
    from plato.config import Config
    from plato.clients.strategies.mpc import MPCLifecycleStrategy
    from plato.processors import registry
    from plato.servers.fedavg_he import Server as HEServer
    from plato.servers.strategies.aggregation.he import FedAvgHEAggregationStrategy
    from plato.utils import homo_enc
    def mpc():
        stats=[]
        clients=[11,7,2,19,4];counts=[.5,0.,2.5,1.,3.]
        weights=[{'layer.w':torch.tensor([[.125*(i+1),-.25*i],[.04,.07]],dtype=torch.float64).T,'scalar':torch.tensor(.05*i,dtype=torch.float64),'empty':torch.empty(0,2,dtype=torch.float64)} for i in range(5)]
        for kind,threshold in [('additive',None),('shamir',1),('shamir',3),('shamir',5)]:
            path=runtime/(kind+str(threshold));store=RoundInfoStore(storage_dir=path);store.initialise_round(23,clients)
            for cid,n in zip(clients,counts):store.record_client_samples(cid,n,round_number=23)
            kw={} if kind=='additive' else {'threshold':threshold}
            proc=Additive if kind=='additive' else Shamir
            random.seed(123)
            payload=[proc(client_id=cid,round_store=store,debug_artifacts=False,**kw).process(w) for cid,w in zip(clients,weights)]
            strategy=(MPCAdditiveAggregationStrategy if kind=='additive' else MPCShamirAggregationStrategy)(store,**kw)
            updates=[SimpleNamespace(client_id=cid,report=SimpleNamespace(num_samples=n)) for cid,n in zip(clients,counts)]
            baseline={k:torch.zeros_like(v) for k,v in weights[0].items()}
            order=[2,4,0,3,1]
            actual=asyncio.run(strategy.aggregate_weights([updates[i] for i in order],baseline,[payload[i] for i in order],SimpleNamespace(current_round=23)))
            maximum=0.
            for name in baseline:
                ref=sum(w[name]*n for w,n in zip(weights,counts))/sum(counts)
                if ref.numel(): maximum=max(maximum,float((actual[name]-ref).abs().max()))
                torch.testing.assert_close(actual[name],ref,rtol=0,atol=2e-6)
            stats.append({'kind':kind,'threshold':threshold,'max_absolute_error':maximum})
            snapshot=pickle.dumps(store.load_state())
            for write in [lambda:store.record_client_samples(11,9,round_number=22),lambda:store.append_additive_share(7,weights[0],round_number=22,from_client=11),lambda:store.store_pairwise_share(7,11,weights[0],round_number=22)]:
                try:write()
                except RuntimeError:pass
                else:raise AssertionError('stale writer accepted')
            assert pickle.dumps(store.load_state())==snapshot
        return stats
    record('MPC weighted scalar/strided/empty numerical references and all write fences',mpc)
    # Exercise actual client lifecycle kwargs/registry wire, not manually shared thresholds.
    store=RoundInfoStore(storage_dir=runtime/'threshold-config');clients=[1,2,3,4,5];store.initialise_round(9,clients)
    updates=[];payload=[];w={'w':torch.tensor([.125,-.2],dtype=torch.float64)}
    passed_thresholds=[]
    for cid in clients:
        store.record_client_samples(cid,1,round_number=9)
        ctx=SimpleNamespace(round_store=store,client_id=cid,debug_artifacts=False)
        kwargs=MPCLifecycleStrategy()._build_processor_kwargs(ctx)
        passed_thresholds.append(kwargs['mpc_model_encrypt_shamir'].get('threshold'))
        outbound,_=registry.get('Client',client_id=cid,processor_kwargs=kwargs)
        encoded=outbound.process(w)
        payload.append(deserialize_tree(encoded) if isinstance(encoded,bytes) else encoded)
        updates.append(SimpleNamespace(client_id=cid,report=SimpleNamespace(num_samples=1)))
    result=asyncio.run(MPCShamirAggregationStrategy(store,threshold=Config.server.mpc_shamir_threshold).aggregate_weights(updates,{'w':torch.zeros(2,dtype=torch.float64)},payload,SimpleNamespace(current_round=9)))
    out['defect_probes'].append({'name':'Production client configured Shamir threshold','configured_server_threshold':Config.server.mpc_shamir_threshold,'passed_client_thresholds':passed_thresholds,'effective_client_threshold':3,'actual':result['w'].tolist(),'reference':w['w'].tolist(),'max_absolute_error':float((result['w']-w['w']).abs().max())})
    def he():
        ckks=ts.context(ts.SCHEME_TYPE.CKKS,poly_modulus_degree=8192,coeff_mod_bit_sizes=[60,40,40,60],n_threads=1);ckks.global_scale=2**40
        server=HEServer.__new__(HEServer);server.he_context=ckks;server.trainer=SimpleNamespace(zeros=torch.zeros);server.para_nums={'x':4,'b':1};server.weight_shapes={'x':(2,2),'b':()};server.encrypted_model='before';server.total_samples=111
        context=SimpleNamespace(server=server,trainer=server.trainer)
        ws=[{'x':torch.tensor([[.25,-2],[3.,4.]]),'b':torch.tensor(.75)},{'x':torch.tensor([[1.,1.5],[-.5,-2.]]),'b':torch.tensor(-1.25)}]
        updates=[SimpleNamespace(report=SimpleNamespace(num_samples=n)) for n in [1.5,4.5]]
        errors=[]
        for mask in [[],[0,3,4],list(range(5))]:
            caller_mask=mask[::-1];original=caller_mask[:]
            payload=[homo_enc.encrypt_weights(w,context=ckks,indices=caller_mask) for w in ws];assert caller_mask==original
            res=asyncio.run(FedAvgHEAggregationStrategy().aggregate_weights(updates,{},payload,context))
            err=max(float((res[k].double()-(ws[0][k].double()+3*ws[1][k].double())/4).abs().max()) for k in ws[0])
            assert err<=2e-5;errors.append({'mask':mask,'max_absolute_error':err})
        saved_model=pickle.dumps(server.encrypted_model)
        bad=homo_enc.encrypt_weights(ws[0],context=ckks,indices=[0]);bad['encrypted_weights']=b'not ckks'
        try:asyncio.run(FedAvgHEAggregationStrategy().aggregate_weights(updates[:1],{},[bad],context))
        except Exception:pass
        else:raise AssertionError('malformed ciphertext accepted')
        assert pickle.dumps(server.encrypted_model)==saved_model
        return {'CKKS_reference_errors':errors,'failure_model_publication':'unchanged'}
    record('native CKKS independently weighted matrices/scalar and failed decode',he)

out_path=SCRATCH/('numerical'+str(sys.version_info.minor)+'.json');out_path.write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(out,indent=2,ensure_ascii=False))
