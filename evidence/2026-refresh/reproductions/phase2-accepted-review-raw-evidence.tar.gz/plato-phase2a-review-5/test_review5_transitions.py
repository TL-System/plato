"""Independent localhost transitions, exact archive bytes, and public ZIP callers."""

import contextlib
import hashlib
import http.server
import io
import json
import sys
import threading
import zipfile

import plato
import pytest
import requests
import torch

import test_independent_contracts as support
from plato.datasources import femnist
from plato.utils.archive import UnsafeArchiveError

configure = support.configure


@contextlib.contextmanager
def host(payload):
    state = dict(payload=payload, status=200, truncated=False, hits=[], pause_on=0,
                 entered=threading.Event(), release=threading.Event())

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            payload, status, truncated = (
                state['payload'], state['status'], state['truncated'])
            state['hits'].append([self.path, status, len(payload), truncated])
            self.send_response(status)
            self.send_header('Content-Length', str(len(payload) + 19 * truncated))
            self.end_headers()
            if len(state['hits']) == state['pause_on']:
                state['entered'].set()
                assert state['release'].wait(10)
            self.wfile.write(payload)

        def log_message(self, *args):
            pass

    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    worker = threading.Thread(target=lambda: server.serve_forever(poll_interval=.01))
    worker.start()
    try:
        yield f'http://127.0.0.1:{server.server_port}/source.zip', state
    finally:
        state['release'].set()
        server.shutdown()
        worker.join(3)
        server.server_close()
        assert not worker.is_alive()


def corrupt_crc(members):
    """Valid ZIP headers, actual CRC failure while extracting member data."""
    payload = bytearray(support.zipped(members))
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        info = archive.infolist()[0]
        start = info.header_offset + 30 + len(info.filename.encode()) + len(info.extra)
    payload[start] ^= 1
    return bytes(payload)


def select_failure(state, failure, members):
    if failure == '503':
        state['status'] = 503
        return requests.HTTPError
    if failure == 'truncated':
        state['truncated'] = True
        return requests.exceptions.ChunkedEncodingError
    if failure == 'crc':
        state['payload'] = corrupt_crc(members)
        return zipfile.BadZipFile
    state['payload'] = support.zipped({**members, '../escaped.txt': b'escape'})
    return UnsafeArchiveError


def canonical(root, mode):
    return root / ('tiny-imagenet-200.zip' if mode == 'tiny_default' else 'source.zip')


def record(root, state, **details):
    result = dict(source=plato.__file__, python=sys.version, requests=state['hits'],
                  markers=[p.name for p in root.glob('*.complete')],
                  staging=[p.name for p in root.glob('.download-*')], **details)
    (root / 'review5-observed.json').write_text(json.dumps(result, indent=2) + '\n')


@pytest.mark.parametrize('mode', ['tiny_default', 'tiny_native', 'cinic'])
@pytest.mark.parametrize('failure', ['503', 'truncated', 'crc', 'unsafe'])
def test_real_replacement_error_retains_exact_archive_then_recovers(
    tmp_path, monkeypatch, mode, failure
):
    members, _, missing_name = support.fixture(mode)
    payload = support.zipped(members)
    with host(payload) as (url, state):
        module = support.setup_source(mode, url, monkeypatch)
        support.check_images(module.DataSource())
        archive = canonical(tmp_path, mode)
        assert archive.read_bytes() == payload
        (tmp_path / missing_name).unlink()
        expected_error = select_failure(state, failure, members)
        with pytest.raises(expected_error):
            module.DataSource()
        assert len(state['hits']) == (2 if failure == 'unsafe' else 4)
        assert archive.read_bytes() == payload
        assert not list(tmp_path.glob('*.complete'))
        assert not list(tmp_path.glob('.download-*'))
        assert not (tmp_path.parent / 'escaped.txt').exists()
        failed = dict(canonical_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                      requests=len(state['hits']), marker=False, staging=[])
        # Different safe replacement bytes make successful publication observable.
        restored = support.zipped({**members, 'recovery-note.txt': b'fresh archive'})
        state.update(payload=restored, status=200, truncated=False)
        source = module.DataSource()
        support.check_images(source)
        assert source.testset.targets == [1] * len(source.testset)
        if mode.startswith('tiny'):
            assert source.testset[0][0].shape == (3, 299, 299)
        assert archive.read_bytes() == restored
        assert (tmp_path / missing_name).read_bytes() == members[missing_name]
        assert len(list(tmp_path.glob('*.complete'))) == 1
        assert not list(tmp_path.glob('.download-*'))
        record(tmp_path, state, failure=failure, mode=mode, after_failure=failed,
               old_sha256=hashlib.sha256(payload).hexdigest(),
               new_sha256=hashlib.sha256(restored).hexdigest())
    monkeypatch.setattr(support.base.requests, 'get',
                        lambda *a, **kw: pytest.fail('ready source went online'))
    support.check_images(module.DataSource())


@pytest.mark.parametrize('mode', ['tiny_default', 'tiny_native'])
def test_waiter_survives_owner_retry_exhaustion_without_replacing_guard(
    tmp_path, monkeypatch, mode
):
    members, _, missing_name = support.fixture(mode)
    payload = support.zipped(members)
    values, errors = [], []
    at_flock, done = threading.Event(), threading.Event()

    def load(waiter=False):
        def profile(frame, event, function):
            if event == 'c_call' and function is support.base.fcntl.flock:
                at_flock.set()
        if waiter:
            sys.setprofile(profile)
        try:
            values.append(module.DataSource())
        except Exception as error:
            errors.append(error)
        finally:
            if waiter:
                sys.setprofile(None)
                done.set()

    with host(payload) as (url, state):
        module = support.setup_source(mode, url, monkeypatch)
        support.check_images(module.DataSource())
        (tmp_path / missing_name).unlink()
        state.update(status=503, pause_on=4)
        workers = [threading.Thread(target=load),
                   threading.Thread(target=load, kwargs={'waiter': True})]
        try:
            workers[0].start()
            assert state['entered'].wait(7)
            assert canonical(tmp_path, mode).read_bytes() == payload
            assert not list(tmp_path.glob('*.complete'))
            workers[1].start()
            assert at_flock.wait(5) and not done.is_set()
            state.update(status=200, pause_on=0)
        finally:
            state['release'].set()
            for worker in workers:
                if worker.ident is not None:
                    worker.join(10)
        assert not any(worker.is_alive() for worker in workers)
        assert len(errors) == 1 and isinstance(errors[0], requests.HTTPError)
        assert len(values) == 1 and len(state['hits']) == 5
        assert canonical(tmp_path, mode).read_bytes() == payload
        assert not list(tmp_path.glob('.download-*'))
        support.check_images(values[0])
        record(tmp_path, state, mode=mode, owner_error=type(errors[0]).__name__,
               success_count=len(values), waiter_blocked=True)


@pytest.mark.parametrize('client_id', [0, 1])
def test_femnist_public_zip_constructor_and_offline_reuse(
    tmp_path, monkeypatch, client_id
):
    expected = {'x': [[0.25] * 784, [0.5] * 784], 'y': [7, 23]}
    payload = support.zipped({f'{client_id}/data.json': json.dumps(expected).encode()})
    original_get = requests.get
    segment = 'test' if client_id == 0 else 'train'
    expected_url = ('https://iqua.ece.toronto.edu/baochun/FEMNIST/'
                    f'{segment}/{client_id}.zip')
    with host(payload) as (url, state):
        def dispatch(requested, **kwargs):
            assert requested == expected_url
            return original_get(url, **kwargs)
        monkeypatch.setattr(requests, 'get', dispatch)
        source = femnist.DataSource(client_id=client_id,
                                    train_transform=lambda x: torch.tensor(x))
        assert source.num_train_examples() == source.num_test_examples() == 2
        assert source.trainset[0][1] == 7 and source.testset[1][1] == 23
        assert source.trainset[0][0].shape == (784,)
        root = tmp_path / 'FEMNIST/packaged_data' / segment
        assert (root / f'{client_id}.zip').read_bytes() == payload
        assert (root / f'{client_id}.zip.complete').is_file()
        assert not list(root.glob('.download-*')) and len(state['hits']) == 1
        record(tmp_path, state, caller='FEMNIST', client_id=client_id)
    monkeypatch.setattr(requests, 'get',
                        lambda *a, **kw: pytest.fail('FEMNIST cache went online'))
    assert femnist.DataSource(client_id=client_id).testset[1][1] == 23
