"""Assemble the sole authorized root report from retained independent evidence."""
import datetime
import hashlib
import json
import shlex
import xml.etree.ElementTree as ET
from pathlib import Path

S = Path('/tmp/plato-phase2a-review-5')
R = Path('/Users/bli/Playground/plato/evidence/2026-refresh')
REPORT = R / 'phase2a-review-5.json'


def record(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def read(path):
    return json.loads(Path(path).read_text())


before, after = read(S / 'identity-before.json'), read(S / 'identity-after.json')
assert before == after
assert after['observed_status'] == ''
audit = read(S / 'evidence-audit.json')
author = read(S / 'author.json')
environments = {v: read(S / f'environment-{v}.json') for v in ['3.13', '3.14']}
commands = {p.stem.removeprefix('command-'): read(p) for p in sorted(S.glob('command-*.json'))}
validations = {}
for action in ['focused', 'base', 'independent', 'original', 'coupled-corrected',
               'new-independent', 'author-red']:
    validations[action] = {}
    for version in ['3.13', '3.14']:
        journal = commands[f'{action}-{version}']
        suites = ET.parse(S / f'logs/{action}-{version}.xml').getroot().findall('testsuite')
        counts = {k: sum(int(x.attrib[k]) for x in suites)
                  for k in ['tests', 'errors', 'failures', 'skipped']}
        counts['passed'] = counts['tests'] - counts['errors'] - counts['failures'] - counts['skipped']
        counts['pytest_seconds'] = sum(float(x.attrib['time']) for x in suites)
        if action == 'author-red':
            assert counts['passed'] == 6 and counts['failures'] == 3 and journal['exit_code'] == 1
            counts['expected_failures'] = [
                dict(node=c.attrib['name'], actual=c.find('failure').attrib['message'])
                for suite in suites for c in suite.findall('testcase') if c.find('failure') is not None]
        else:
            assert counts['failures'] == counts['errors'] == 0 and journal['exit_code'] == 0
        if action == 'base':
            counts['deselected'] = 48
            assert counts['passed'] == 445 and counts['skipped'] == 4
        else:
            assert counts['skipped'] == 0
        if action == 'focused':
            new_cases = [c for suite in suites for c in suite.findall('testcase')
                         if c.attrib['classname'].endswith('test_review4_regressions')]
            assert len(new_cases) == 9 and not any(c.find('failure') is not None for c in new_cases)
            counts['new_durable_regressions_passed'] = 9
        validations[action][version] = dict(**journal, counts=counts,
            log_identity=record(S / f'logs/{action}-{version}.log'),
            junit_identity=record(S / f'logs/{action}-{version}.xml'))
observations = {}
for version in ['3.13', '3.14']:
    observations[version] = {}
    for action, name, expected in [('original', 'observed.json', 4),
                                  ('coupled-corrected', 'observed.json', 6),
                                  ('new-independent', 'review5-observed.json', 16)]:
        paths = [p for p in (S / f'{action}-{version}-fixtures').glob(f'*/{name}')
                 if not p.parent.is_symlink()]
        assert len(paths) == expected, (action, len(paths))
        results = []
        for path in sorted(paths):
            value = read(path)
            assert Path(value['source']).resolve() == (S / 'candidate/plato/__init__.py').resolve()
            results.append(dict(artifact=record(path), observation=value))
        observations[version][action] = results
(S / 'observations.json').write_text(json.dumps(observations, indent=2) + '\n')
public = {}
for version in ['3.13', '3.14']:
    source = S / f'public-{version}-fixtures/results.json'
    value = read(source)
    assert all(item['completed'] for item in value['results'].values())
    assert Path(value['source']).resolve() == (S / 'candidate/plato/__init__.py').resolve()
    env = dict(HF_HUB_OFFLINE='1', HF_DATASETS_OFFLINE='1', PYTHONDONTWRITEBYTECODE='1',
               OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
               VECLIB_MAXIMUM_THREADS='1', NUMEXPR_NUM_THREADS='1',
               XDG_CACHE_HOME=str(S / 'cache'), TMPDIR=str(S / 'tmp'),
               PYTHONPATH=str(S / 'candidate'))
    command = ' '.join(shlex.quote(k+'='+v) for k,v in env.items()) + ' ' + shlex.join([
        f'/tmp/plato-phase2a-review-4/base-{version}/bin/python', str(S / 'independent_probes.py'),
        str(S / f'public-{version}-fixtures')])
    public[version] = dict(command=command, cwd=str(S / 'candidate'), shell='/bin/zsh -lc',
                           exit_code=0, results=value, result_identity=record(source),
                           log_identity=record(S / f'logs/public-{version}.log'))
(S / 'public-probes.json').write_text(json.dumps(public, indent=2) + '\n')
inputs = {name: record(R / name) for name in [
    'plan.md', 'plan-addendum.json', 'phase2a-review.json', 'phase2a-review-2.json',
    'phase2a-review-3.json', 'phase2a-review-4.json', 'phase2a-root-probes.json']}
inputs['root_AGENTS.md'] = record('/Users/bli/Playground/plato/AGENTS.md')
inputs['candidate_validation'] = after['inputs']['candidate_validation']
assert inputs['phase2a-review-4.json']['sha256'] == 'a602fb94c5b5e3eeae855dae39082ceab99ff1f0dc6660203839f3ee1f8dce76'
manifest = [record(p) for p in sorted(S.iterdir()) if p.is_file()]
manifest += [record(p) for p in sorted((S / 'logs').iterdir()) if p.is_file()]
(S / 'artifact-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
report = {
    'schema_version': 1,
    'reviewer': 'Fresh independent Sol reviewer; no nested agents.',
    'model_requested': 'Sol',
    'reasoning_effort_requested': 'xhigh',
    'review_role': 'Exact clean Phase 2A candidate review 5, including R2A4-01 closure and retained A contracts.',
    'written_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'verdict': 'PASS',
    'decision': 'PASS for this exact scoped A candidate; no whole-phase, root integration, Linux or whole-stack qualification claim.',
    'finding_counts': dict(critical=0, high=0, medium=0, low=0),
    'findings': [],
    'low_findings': [],
    'summary': 'R2A4-01 is resolved. Actual default-URL Tiny constructors survive exhausted HTTP 503, invalid ZIP and truncated-body recovery, retain prior canonical ZIP bytes, publish no incomplete marker, clean normal-exception staging, then recover correct useful samples and work offline. Waiting contenders, valid-incomplete-ZIP readiness recovery, first-download failures, safe containment and prior A contracts pass on Python 3.13.16 and 3.14.8. No material issue found within accepted contracts.',
    'identity': after,
    'accepted_and_prior_sources_read': inputs,
    'write_scope_and_authority': {
        'sole_root_write': str(REPORT), 'scratch': str(S),
        'all_shells': '/bin/zsh -lc', 'agents_spawned': 0,
        'source_edits': 0, 'commits': 0, 'pushes': 0, 'cleanup': 0,
        'other_reports_or_environments_mutated': False,
        'execution': 'Exact git-archive exports. Existing reviewer4 Python environments used read only with PYTHONPATH and cwd pinned to review5 candidate (prior for intentional red). No sync, install or package mutation. Bytecode and pytest cache writes disabled; fixtures, journals, logs, artifacts and tool caches owned here.',
        'source_checks': 'All 945 non-gitlink tracked blobs match the candidate in both worktree and export, before and after; clean HEAD unchanged. Prior export retains all 944 prior blobs plus the separately attributed new regression module.',
    },
    'environment': {
        'platform': environments['3.13']['platform'], 'python': environments,
        'read_only_python_environments': ['/tmp/plato-phase2a-review-4/base-3.13', '/tmp/plato-phase2a-review-4/base-3.14'],
        'provisioning_in_this_review': 'None. Existing locked test-base environments read only, expressly allowed by the user.',
        'parent_and_child_source_pin': 'Both versions independently verify plato.__file__ resolves to /private/tmp/plato-phase2a-review-5/candidate/plato/__init__.py in parent and fresh shell child; interpreter prefixes agree. All saved current observations and actual public probes point there.',
        'metadata': after['shared_metadata'],
        'default_and_minimum': '3.13 remains unchanged.',
        'static_tools': 'Read-only author dev-environment Ruff/ty executables. Scope and repository checks run from pinned scratch source; original environments never synced.',
    },
    'independent_validation': {
        **validations,
        'static': {k: dict(**commands[k], log_identity=record(S / f'logs/{k}.log'))
                   for k in ['ruff', 'ruff-repository', 'typing']},
        'diff_check': 'git diff --check fda60becedfa6236c11d415b87a868b52789a41e 79da1f97d8a12fe97402750cc32c7b3e8f5cdf6e exited 0.',
        'base_skips': 'Exactly one absent-Opacus DP module and three optional Nanochat integration cases. No warnings, new skips or suppressions.',
        'runtime_exclusions': '48 unchanged runtime/socket cases explicitly deselected as authorized. Shared runtime source byte-identical; no socket matrix repeated.',
        'untouched_scripts': 'Byte-identical owned copies of the exact requested review4 corrected script and review3 negative/independent scripts were executed; source originals and hashes unchanged. The coupled script permits precisely BadZipFile/tarfile.ReadError as in accepted corrected version. No harness correction or assertion weakening in this review.',
        'counts_overlap': 'Suites and constructor probes overlap. Counts are per invocation/interpreter and are not added into a support total.',
        'actual_public_behavior': {
            'artifact': record(S / 'public-probes.json'),
            'each_version': 'All five groups complete: 2 actual edge configure cases, 4 live/killed NPZ writer cases, 14 cache input cases, 4 native/prepared image cases and 6 HTTP recovery cases.',
            'qualification': 'Edge configure uses actual tracked config/server/sampler branch with inert model/processor setup. NPZ probe pauses real np.savez, observes unpublished final pathname and blocked actual reader, then releases/SIGKILLs writer. Child processes bounded and joined. No socket or training qualification claimed.',
        },
        'observations_artifact': record(S / 'observations.json'),
    },
    'correction_dispositions': [
        {
            'id': 'R2A4-01', 'prior_severity': 'medium', 'status': 'RESOLVED',
            'prior_report_sha256': inputs['phase2a-review-4.json']['sha256'],
            'implementation_locations': [
                {'path': 'plato/datasources/base.py', 'line': 85, 'purpose': 'Flock scope owns ExitStack cleanup.'},
                {'path': 'plato/datasources/base.py', 'line': 94, 'purpose': 'ZIP replacement uses private temporary directory under destination.'},
                {'path': 'plato/datasources/base.py', 'line': 136, 'purpose': 'Request cleanup deletes staged file, preserving canonical archive.'},
                {'path': 'plato/datasources/base.py', 'line': 167, 'purpose': 'Successful safe extraction atomically replaces canonical ZIP.'},
                {'path': 'plato/datasources/base.py', 'line': 183, 'purpose': 'Readiness gates completion after archive publication.'},
            ],
            'expected': 'Failed replacement preserves recognized default recovery eligibility and old archive; no marker or normal-exception staging leak. Restored source is fetched by actual constructor and yields training-space labels, finite 299-pixel evaluation tensors and offline reuse.',
            'actual': 'All three failure triggers exhaust exactly three real attempts, retain old ZIP byte for byte, and leave marker/staging absent. Restored default/configured source succeeds on request five. Prior nine-case author regression independently reproduces 3 failures/6 controls on exact d26 export and all nine cases pass within both 242-case current suites. Untouched review4 8/8 and review3 4/4 pass each version.',
            'fresh_additional_reproduction': '16 independently written cases per interpreter: HTTP 503, truncated stream, real member CRC failure and traversal preflight for default Tiny/configured Tiny/CINIC; source restoration publishes observably different safe ZIP bytes; waiting contender blocks at real C flock while owner exhausts retries, then succeeds; FEMNIST public server/client ZIP constructor controls. No download, readiness, guard, extraction or retry patch. Only canonical public URL dispatch redirects requests to localhost.',
            'readiness_and_contention': 'Untouched probes verify valid incomplete ZIP fails readiness without completion, restores source and succeeds; paused successful owner/contender uses one recovery; failed-readiness owner releases waiter for a healthy request. New retry-exhaustion contention yields one expected HTTPError, one successful waiter, five requests and no staging leak.',
            'containment': 'Fresh unsafe ZIP preflight writes no traversal target, retains old canonical ZIP and removes staging. Fresh CRC error also retains canonical archive. Existing absolute/traversal/link/symlink TAR/ZIP tests pass both versions.',
        },
        {'id': 'R2A3-01 / R2A-04 / R2A2-02', 'status': 'RESOLVED within accepted readiness contract',
         'evidence': 'Actual HTTP/extraction restores required directories, annotations, empty-class images and native referenced validation PNGs. Default failed-readiness and waiting-contender transitions succeed; no incomplete completion.'},
        {'id': 'R2A2-01', 'status': 'PRESERVED',
         'evidence': 'Independent malformed NPZ constructor cases rebuild from correct raw arrays: real finite float32-compatible features; integral IDs 0..99; string/object/structured/datetime/complex/nonfinite/overflow/fractional/out-of-range refusal. Compatible cache-only numeric/bool/endian/boundary inputs retain original NPZ bytes and exact tensor values. Failed recovery later rebuilds offline.'},
        {'id': 'R2A-02', 'status': 'PRESERVED',
         'evidence': 'Actual Purchase/Texas live/killed NPZ writers and readers establish lock exclusion, unpublished final pathname, atomic valid publication and abandoned temporary cleanup; raw/cache offline reuse preserved on both interpreters.'},
        {'id': 'R2A-01', 'status': 'PRESERVED',
         'evidence': 'Actual tracked cross-silo config edge configure accepts IDs 4/5, deterministic unique 600-index evaluation partitions and unchanged caller RNG. Invalid ordinary/unassigned/wrong-role/training/indexed-IID IDs reject.'},
        {'id': 'R2A-03 / manual recovery refusal', 'status': 'PRESERVED',
         'evidence': 'Direct/nested native and labeled prepared layouts remain distinct. Official test/images stays unlabeled. Manual incomplete native roots, generic lock and unrelated archives remain insufficient eligibility. Unknown prepared/native labels reject, including with canonical default artifacts.'},
        {'id': 'ROOT-2A-01 / ROOT-2A-02', 'status': 'PRESERVED',
         'evidence': 'CINIC/Tiny evaluation subsets retain training IDs with coherent class/samples/imgs/targets metadata. Tiny native/prepared evaluation is deterministic, finite 3x299x299 with preserved normalization; training randomness and custom transforms remain supported.'},
        {'id': 'F13', 'status': 'PRESERVED', 'evidence': 'Config optional reset, repeated/reverse reloads, legacy singleton reset, include/CLI and client-speed RNG cases pass.'},
        {'id': 'F15 / F16', 'status': 'PRESERVED', 'evidence': 'Realized Dirichlet counts agree with loader membership without redraw/RNG mutation. Timeout-guarded empty IID and infeasible pools reject; literal seeded nonempty padding/membership contracts pass.'},
        {'id': 'EMNIST', 'status': 'PRESERVED', 'evidence': 'Actual native balanced/digits IDX constructor checks retain distinct training/test flags, labels and counts.'},
    ],
    'source_and_scope_audit': {
        **audit['source_delta'],
        'scope_basis': 'New downloader/test diff inspected completely, with prior full-A reviews plus exact blob preservation for unchanged production. Current focused/base/public and independent contract checks independently revalidate retained behavior.',
        'new_production_delta': 'Only plato/datasources/base.py since d26; private ZIP staging, exception cleanup and os.replace publication. Tiny source byte-identical. Non-ZIP branches retain their prior file/extraction behavior.',
        'evidence_only_child': '79da1f9 differs from f036956 only in phase2a-validation.json.',
        'no_extra_protocol': 'No provenance manifest, cache/archive schema, generic-lock eligibility, manual incomplete-native acceptance, lock redesign, research equation change or unrelated runtime/adapter change.',
        'typing_suppression_policy': 'No added suppression. Existing pyproject unresolved-import rule/exclusions are unchanged from phase base; scoped ty pass does not constitute whole-tree/vendor typing qualification.',
    },
    'archive_review': {
        'original_files': after['archives'], 'license': after['archive_license'],
        'provenance': record(S / 'candidate/archives/legacy_datalib/README.md'),
        'active_import_scan': after['active_archive_reference_scan'],
        'disposition': 'All 14 baseline datalib files and copied license byte-identical. README records original path map, exact baseline, authors, historical dependencies/reproduction and unchanged REFER defects. No active archive/datalib Python imports; historical bundle support is not claimed.',
    },
    'author_and_root_evidence_attribution': {
        'author_evidence': inputs['candidate_validation'],
        'implementation_and_diff_match': after['author_identity_matches'],
        'author_raw_artifact_hashes': 'All four correction generations of retained author log/artifact hashes match the checked files; see identity-before/after.json.',
        'author_current_claims_verified': '9 new green / red 3 failed+6 controls each; 242 focused each; 445 base passed+4 allowed skips+48 runtime deselections each; untouched corrected review4/review3 8/4 each. Raw logs and JUnit agree. Own current runs and exact-prior red independently corroborate these numbers.',
        'historical_report_attribution': 'Original reviewer verdicts/files/probe sources unchanged and correctly hashed. Historical candidate evidence blobs match author attribution; author green reruns are author verification, distinct from this independent PASS.',
        'root_probes': 'ROOT-2A-01/02 are previously independent root findings whose behavior is independently revalidated here. Root whole-phase/merged-tree evidence is not promoted into this review claim.',
        'audit_artifact': record(S / 'evidence-audit.json'),
    },
    'harness_disposition': 'No product/harness correction, failure reclassification or weakened assertion in this review. Expected red exit 1 is exclusively the three known prior default-source refusals; current invocations all exit 0. Earlier author/reviewer harness notes remain in their original immutable reports.',
    'limits': [
        'macOS ARM64 CPU, CPython 3.13.16 and 3.14.8 only. Linux, final merged root, whole Phase 2 and whole-stack qualification remain root-owned.',
        'Existing Python environments used read only with independently verified parent/child source pins. No fresh provisioning, installed wheel/sdist isolation, full mandatory-extra, SSL runtime or config-inventory campaign repeated.',
        'Local synthesized raw/IDX/PNG/JSON/native annotation fixtures and localhost HTTP only; no full corpus, external service, accelerator or training/accuracy qualification.',
        'Readiness checks filesystem existence, supported extensions, present usable classes and native annotation references; no image decode/checksum or reconstruction of loss among surviving prepared-class images without source inventory.',
        'No full extracted-tree rollback on corrupt archive/filesystem failures, hostile unrelated concurrent destination writer, power-loss/directory-fsync durability or new provenance protocol is promised.',
        'Normal exceptions remove private staging; SIGKILL may leave staging. No generalized scavenger or killed-ZIP-staging cleanup requirement added. Existing stable-inode flock/platform boundaries retained.',
        'Base skips only the four allowed optional cases; 48 unchanged runtime cases explicitly deselected. Optional integrations, Windows flock and whole-tree/vendor typing remain unqualified by this report.',
    ],
    'retained_resources': {
        'scratch': str(S), 'source_export': str(S / 'candidate'), 'prior_export': str(S / 'prior'),
        'identity_before': record(S / 'identity-before.json'), 'identity_after': record(S / 'identity-after.json'),
        'artifact_manifest': record(S / 'artifact-manifest.json'),
        'report_sha256_handoff': str(S / 'final-verification.json'),
        'cleanup': 'None. Source exports, fixtures, scripts, logs and journals retained for root.',
    },
}
assert not REPORT.exists(), 'Do not overwrite any preexisting root report.'
REPORT.write_text(json.dumps(report, indent=2) + '\n')
final = dict(report=record(REPORT), candidate=after['candidate_commit'],
             candidate_tree=after['candidate_tree'], implementation=after['implementation_commit'],
             identity_after=record(S / 'identity-after.json'), verdict=report['verdict'],
             unchanged_candidate_status=after['observed_status'], scratch=str(S))
(S / 'final-verification.json').write_text(json.dumps(final, indent=2) + '\n')
print(json.dumps(final, indent=2))
