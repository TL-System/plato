"""Read-only evidence attribution and historical/source preservation checks."""
import hashlib
import json
import os
import shlex
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

SCRATCH = Path('/tmp/plato-phase2a-review-5')
ROOT = Path('/Users/bli/Playground/plato/evidence/2026-refresh')
REPO = Path('/private/tmp/plato-refresh-worktrees/data')
AUTHOR = Path('/tmp/plato-phase2a-lZqbqj')
evidence = json.loads((SCRATCH / 'author.json').read_text())


def shell(args):
    return subprocess.run(['/bin/zsh', '-lc', shlex.join(args)], cwd=REPO,
                          capture_output=True, check=True,
                          env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}).stdout


def sha(value):
    return hashlib.sha256(value).hexdigest()


def record(path):
    path = Path(path)
    value = path.read_bytes()
    return dict(path=str(path), bytes=len(value), sha256=sha(value))


result = dict(author_inputs=[], historical_evidence=[], unchanged_scripts=[],
              raw_results=[], source_delta={}, accepted_plan={})
inputs = evidence['review_corrections']['independent_inputs'] + [
    evidence[k]['independent_input'] for k in [
        'review2_corrections', 'review3_corrections', 'review4_corrections']]
for item in inputs:
    actual = record(item['path'])
    actual.update(expected_sha256=item['sha256'], equal=actual['sha256'] == item['sha256'])
    assert actual['equal'], actual
    result['author_inputs'].append(actual)
for item in evidence['identity']['earlier_candidates'] + [evidence['identity']['previous_candidate']]:
    actual = sha(shell(['git', 'show', item['commit'] + ':evidence/2026-refresh/phase2a-validation.json']))
    check = dict(commit=item['commit'], sha256=actual,
                 expected=item['evidence_file_sha256'], equal=actual == item['evidence_file_sha256'])
    assert check['equal'], check
    result['historical_evidence'].append(check)
for section in ['review2_corrections', 'review3_corrections', 'review4_corrections']:
    for path, expected in evidence[section]['read_only_probe_sources_sha256'].items():
        actual = record(path)
        actual.update(expected_sha256=expected, equal=actual['sha256'] == expected)
        assert actual['equal'], actual
        result['unchanged_scripts'].append(actual)
for name in ['test_default_recovery_negative.py', 'test_independent_contracts.py',
             'test_prior_remaining_contracts.py', 'independent_probes.py', 'prior_independent_probes.py',
             'test_coupled_recovery_corrected.py']:
    parent = '/tmp/plato-phase2a-review-4' if name == 'test_coupled_recovery_corrected.py' else '/tmp/plato-phase2a-review-3'
    original, copied = Path(parent) / name, SCRATCH / name
    assert original.read_bytes() == copied.read_bytes()
    result['unchanged_scripts'].append(dict(**record(copied), original=str(original), equal=True))
for version in ['3.13', '3.14']:
    items = [evidence['review4_corrections'][action][version] for action in ['red', 'green_new_cases']]
    items += [evidence['review4_corrections']['untouched_reviewer_scripts_author_rerun'][action][version]
              for action in ['review4', 'review3']]
    items += [evidence['red_green'][action][version] for action in ['green', 'clean_base_profile']]
    for item in items:
        path = AUTHOR / item['log']
        summary = path.read_text().splitlines()[-1]
        for key in ['passed', 'failed', 'skipped', 'deselected']:
            if item.get(key):
                assert f"{item[key]} {key}" in summary, (path, item, summary)
        result['raw_results'].append(dict(version=version, claim=item, actual_summary=summary, **record(path)))
    suite = ET.parse(AUTHOR / f'revision4/base-{version}.xml').getroot().find('testsuite')
    assert int(suite.attrib['tests']) == 449
    assert int(suite.attrib['skipped']) == 4
    assert int(suite.attrib['failures']) == int(suite.attrib['errors']) == 0
for name in ['plan.md', 'plan-addendum.json', 'plan-review-3.json', 'plan-addendum-acceptance.json']:
    result['accepted_plan'][name] = record(ROOT / name)
addendum = json.loads((ROOT / 'plan-addendum.json').read_text())
acceptance = json.loads((ROOT / 'plan-addendum-acceptance.json').read_text())
assert record(ROOT / 'plan.md')['sha256'] == addendum['immutable_plan']['sha256']
assert record(ROOT / 'plan-addendum.json')['sha256'] == acceptance['artifact_sha256']
result['accepted_plan']['decision'] = json.loads((ROOT / 'plan-review-3.json').read_text())['decision']
previous, current = evidence['identity']['previous_candidate']['commit'], '79da1f97d8a12fe97402750cc32c7b3e8f5cdf6e'
names = shell(['git', 'diff', '--name-only', previous, current]).decode().splitlines()
assert names == ['evidence/2026-refresh/phase2a-validation.json', 'plato/datasources/base.py',
                 'tests/datasources/test_review4_regressions.py']
result['source_delta']['paths_since_review4'] = names
result['source_delta']['all_other_previously_tracked_blobs_unchanged'] = True
result['source_delta']['gitlinks'] = shell(['git', 'ls-tree', current, 'external/nanochat',
                                         'plato/models/dvit', 'plato/models/t2tvit']).decode().splitlines()
diff = shell(['git', 'diff', previous, current, '--', 'plato', 'tests']).decode()
added = [line for line in diff.splitlines() if line.startswith('+') and not line.startswith('+++')]
assert not any(any(token in line for token in ['type: ignore', 'ty: ignore', 'noqa', 'pytest.skip', 'skipif'])
               for line in added)
result['source_delta']['new_suppressions_or_skips'] = []
result['source_delta']['metadata_config_runtime_lock_submodule_preservation'] = True
# Exact previous production export with one added regression file, separately attributed.
count = 0
for entry in shell(['git', 'ls-tree', '-rz', previous]).split(b'\0'):
    if not entry:
        continue
    metadata, name = entry.split(b'\t', 1)
    mode, kind, blob = metadata.decode().split()
    if kind == 'commit':
        continue
    path = SCRATCH / 'prior' / name.decode()
    content = os.readlink(path).encode() if mode == '120000' else path.read_bytes()
    assert hashlib.sha1(f'blob {len(content)}\0'.encode() + content).hexdigest() == blob
    count += 1
assert (SCRATCH / 'prior/tests/datasources/test_review4_regressions.py').read_bytes() == (
    SCRATCH / 'candidate/tests/datasources/test_review4_regressions.py').read_bytes()
result['prior_export'] = dict(commit=previous, exact_prior_blobs=count,
                             sole_addition=record(SCRATCH / 'prior/tests/datasources/test_review4_regressions.py'))
(SCRATCH / 'evidence-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print('Prior report/script identities, author red/green counts and historical evidence match; exact bounded delta and prior production export verified.')
