"""Bounded design-only equation checks; no candidate implementation imported."""

import hashlib
import json
import platform
import subprocess
import time
import types
from fractions import Fraction as Q
from pathlib import Path
from unittest.mock import patch

import torch

from plato.trainers.strategies.base import TrainingContext


ROOT = Path('/Users/bli/Playground/plato')
SCRATCH = Path('/tmp/plato-phase2c-scaffold-design-review')
BASE = 'fda60becedfa6236c11d415b87a868b52789a41e'
start = time.perf_counter()
design_bytes = (ROOT / 'evidence/2026-refresh/phase2c-scaffold-design.json').read_bytes()
design = json.loads(design_bytes)
assert hashlib.sha256(design_bytes).hexdigest() == (
    'f323f3aa9d824df44a1043b2d6aff9c8a963c42964f6e6685108c59b25fc3a89'
)


def fixed_gradient_reference(gradients):
    model = torch.nn.Linear(1, 1, bias=False, dtype=torch.float64)
    with torch.no_grad():
        model.weight.fill_(1)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.1)
    measured = []
    for g in gradients:
        optimizer.zero_grad()
        (model.weight.sum() * g).backward()
        measured.append(model.weight.grad.item())
        optimizer.step()
        with torch.no_grad():
            model.weight.sub_(0.1 * (2 - 1))
    y = model.weight.item()
    ci_new = 1 - 2 + (1 - y) / (len(gradients) * 0.1)
    assert abs(ci_new - sum(measured) / len(measured)) < 1e-12
    return {'gradients': measured, 'y': y, 'ci_new': ci_new, 'delta_ci': ci_new - 1}


torch_reference = [fixed_gradient_reference([0]), fixed_gradient_reference([3, 1])]
for result, expected in zip(torch_reference, [(0.9, 0, -1), (0.4, 2, 1)]):
    assert all(abs(result[k] - v) < 1e-12 for k, v in zip(
        ('y', 'ci_new', 'delta_ci'), expected
    ))

# Exact arithmetic from gradients of independent quadratic client objectives.
x, c, eta = Q(1), Q(2), Q(1, 10)
controls, targets, counts = [Q(1), Q(3), Q(2)], [Q(0), Q(2), Q(-1)], [2, 6, 4]
rounds = []
for selected in [(1, 2), (1, 3)]:
    local, fresh, deltas, gradients = [], [], [], []
    for client in selected:
        index = client - 1
        y = x
        gs = []
        for _ in range(2):
            g = y - targets[index]
            gs.append(g)
            y -= eta * (g - controls[index] + c)
        new_ci = controls[index] - c + (x - y) / (2 * eta)
        assert new_ci == sum(gs) / 2
        local.append(y)
        fresh.append(new_ci)
        deltas.append(new_ci - controls[index])
        gradients.append([str(g) for g in gs])
    uniform = sum(local) / len(selected)
    weighted = sum(counts[i - 1] * y for i, y in zip(selected, local)) / sum(
        counts[i - 1] for i in selected
    )
    c += sum(deltas) / 3
    for client, new_ci in zip(selected, fresh):
        controls[client - 1] = new_ci
    assert c == sum(controls) / 3
    row = {
        'selected': list(selected), 'starting_x': str(x),
        'local_y': [str(y) for y in local], 'ci_new': [str(v) for v in fresh],
        'delta_ci': [str(v) for v in deltas], 'gradients': gradients,
        'sample_weighted_x': str(weighted), 'c_new': str(c),
        'all_ci_after_round': [str(v) for v in controls],
        'uniform_x' if len(rounds) == 0 else 'uniform_x_for_these_local_models': str(uniform),
    }
    advertised = design['executed_design_checks']['independent_multiround_oracle']['rounds'][len(rounds)]
    for key, value in advertised.items():
        assert row[key] == value, (key, row[key], value)
    rounds.append(row)
    x = weighted

# Reproduce the legacy defect from the exact git object, never a moving worktree.
src_file = 'plato/trainers/strategies/algorithms/scaffold_strategy.py'
source = subprocess.check_output(['git', 'show', f'{BASE}:{src_file}'], cwd=ROOT)
assert source == (ROOT / src_file).read_bytes()
module = types.ModuleType('review_exact_baseline_scaffold')
exec(compile(source, f'{BASE}:{src_file}', 'exec'), module.__dict__)
context = TrainingContext()
context.model = torch.nn.Linear(1, 1, bias=False, dtype=torch.float64)
with torch.no_grad():
    context.model.weight.fill_(1)
context.client_id = 1
context.device = torch.device('cpu')
context.state.update(
    learning_rate=0.1,
    server_control_variate={'weight': torch.tensor([[2.]], dtype=torch.float64)},
)
unique_prefix = SCRATCH / f'baseline-{time.time_ns()}'
config = types.SimpleNamespace(params={'model_path': str(unique_prefix)}, trainer=types.SimpleNamespace())
with patch.object(module, 'Config', return_value=config):
    strategy = module.SCAFFOLDUpdateStrategy()
    strategy.setup(context)
    strategy.client_control_variate = {'weight': torch.tensor([[1.]], dtype=torch.float64)}
    strategy.on_train_start(context)
    optimizer = torch.optim.SGD(context.model.parameters(), lr=0.1)
    context.state['optimizer'] = optimizer
    optimizer.zero_grad()
    (context.model.weight.sum() * 0).backward()
    optimizer.step()
    strategy.after_step(context)
    strategy.on_train_end(context)
baseline = {
    'source_sha256': hashlib.sha256(source).hexdigest(),
    'y': context.model.weight.item(),
    'ci_new': strategy.client_control_variate['weight'].item(),
    'delta_ci': context.state['client_control_variate_delta']['weight'].item(),
    'retained_state_path': str(strategy.client_control_variate_path),
    'expected_correct': {'y': 0.9, 'ci_new': 0, 'delta_ci': -1},
}
assert abs(baseline['y'] - 1.1) < 1e-12
assert abs(baseline['ci_new'] - 1) < 1e-12
assert abs(baseline['y'] - 0.9) > 0.1

# The typo yields 2 even though the raw local gradient is 0.
typo = Q(2) - Q(1) + (Q(1) - Q(9, 10)) / Q(1, 10)
assert typo == 2

# Existing actual optimizer hooks can guard final and ordinary updates without
# reordering on_train_start; this is an API feasibility check, not implementation.
assert callable(getattr(optimizer, 'register_step_pre_hook', None))
executed_rates = []
def capture_rate(opt, args, kwargs):
    executed_rates.append([group['lr'] for group in opt.param_groups])
handle = optimizer.register_step_pre_hook(capture_rate)
optimizer.step()
handle.remove()
assert executed_rates == [[0.1]]

result = {
    'baseline_commit': BASE, 'design_sha256': hashlib.sha256(design_bytes).hexdigest(),
    'python': platform.python_version(), 'torch': torch.__version__, 'device': 'cpu',
    'dtype': 'float64', 'independent_torch_sgd': torch_reference,
    'independent_exact_multiround': rounds,
    'all_advertised_rational_values_match': True,
    'appendix_eq19_counterexample': {'reversed_displacement_expression': str(typo), 'mean_gradient': '0'},
    'exact_baseline_reproduction': baseline,
    'optimizer_pre_hook_feasibility': {'observed_executed_group_rates': executed_rates},
    'duration_seconds': round(time.perf_counter() - start, 4),
}
out = SCRATCH / 'independent_checks.json'
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
