import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/Users/bli/Playground/plato')
SCRATCH = Path('/tmp/plato-phase2c-scaffold-design-review')
BASE = 'fda60becedfa6236c11d415b87a868b52789a41e'
DESIGN = 'evidence/2026-refresh/phase2c-scaffold-design.json'
EXPECTED = 'f323f3aa9d824df44a1043b2d6aff9c8a963c42964f6e6685108c59b25fc3a89'
OUTPUT = ROOT / 'evidence/2026-refresh/phase2c-scaffold-design-review.json'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

assert git('rev-parse', 'HEAD').decode().strip() == BASE
design = json.loads((ROOT / DESIGN).read_text())
assert digest((ROOT / DESIGN).read_bytes()) == EXPECTED
assert not git('diff', '--name-only', BASE, '--', 'plato', 'examples', 'docs', 'tests')
assert not OUTPUT.exists(), 'Refuse to overwrite an existing review.'

input_paths = [
    'AGENTS.md', 'evidence/2026-refresh/plan.md',
    'evidence/2026-refresh/plan-review-3.json',
    'evidence/2026-refresh/plan-addendum.json',
    'evidence/2026-refresh/plan-addendum-acceptance.json',
    'evidence/2026-refresh/scaffold-equation-probe.json',
    'evidence/2026-refresh/trainer-lifecycle-probes.json', DESIGN,
]
inputs = [{'path': name, 'sha256': digest((ROOT / name).read_bytes())} for name in input_paths]
for supplied in design['inputs']:
    if 'sha256' in supplied:
        actual = next(x['sha256'] for x in inputs if x['path'] == supplied['path'])
        assert actual == supplied['sha256'], supplied['path']
assert {x['id'] for x in design['concern_dispositions']} == {f'C{i:02d}' for i in range(1, 11)}
assert {x['id'] for x in design['mandatory_acceptance']} == {f'A{i:02d}' for i in range(1, 11)}

inspected = {
    'plato/trainers/strategies/algorithms/scaffold_strategy.py':
        'Full strategy including setup, after_step, train end, persistence and V2.',
    'plato/trainers/composable.py':
        'Constructor/setup/client identity; save/load; train_model hook ordering; normal/final steps; train worker/parent return; obtain_model_update.',
    'plato/trainers/base.py':
        'Client identity and checkpoint/pause interfaces only.',
    'plato/trainers/strategies/base.py':
        'TrainingContext and model-update/training-step/optimizer hooks only.',
    'plato/trainers/strategies/training_step.py':
        'Default step and accumulation implementation; no other algorithm audit.',
    'plato/trainers/strategies/optimizer.py':
        'DefaultOptimizerStrategy and optimizer hook interfaces.',
    'plato/trainers/optimizers.py':
        'Actual registry configuration provenance and factory.',
    'plato/trainers/strategies/data_loader.py':
        'Default loader supports a real bounded one-minibatch-per-epoch oracle.',
    'plato/clients/strategies/defaults.py':
        'Configure/set_client_id, inbound/train/outbound ordering and reporting sample counts.',
    'plato/servers/fedavg.py':
        '_process_reports, model load before weights_aggregated, aggregation dispatch.',
    'plato/servers/strategies/aggregation/fedavg.py':
        'Eligible updates and retained sample-weighted direct/delta aggregation.',
    'examples/customized_client_training/scaffold/scaffold.py': 'Full entrypoint wiring.',
    'examples/customized_client_training/scaffold/scaffold_callback.py':
        'Full inbound/outbound processors and callback reuse.',
    'examples/customized_client_training/scaffold/scaffold_client.py':
        'Full example lifecycle and legacy control-file loader.',
    'examples/customized_client_training/scaffold/scaffold_trainer.py':
        'Full example trainer and delta property.',
    'examples/customized_client_training/scaffold/scaffold_server.py':
        'Full payload split, population control update and initialization.',
    'examples/customized_client_training/scaffold/scaffold_MNIST_lenet5.toml':
        'Full shipped config, including max_concurrency=2 and SGD momentum=.9.',
    'docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md':
        'SCAFFOLD claims and adjacent FedProx section boundary; other algorithms not audited.',
    'tests/integration/utils.py': 'Read fixture interfaces only; not used to execute a runtime suite.',
}
source_identity = []
for name, scope in inspected.items():
    source = git('show', f'{BASE}:{name}')
    assert source == (ROOT / name).read_bytes(), name
    source_identity.append({'path': name, 'git_revision': BASE, 'sha256': digest(source), 'read_scope': scope})
legacy_rev = git('rev-parse', '20380c4f^').decode().strip()
legacy_path = 'examples/customized_client_training/scaffold/scaffold_trainer.py'
source_identity.append({
    'path': legacy_path, 'git_revision': legacy_rev,
    'sha256': digest(git('show', f'{legacy_rev}:{legacy_path}')),
    'read_scope': 'Historical get_optimizer/train_step_end/train_run_end; verifies legacy origin of both wrong equations.'
})

checks = [
    {
        'id': 'R01', 'status': 'PASS', 'concerns': ['C01'], 'acceptance': ['A01', 'A07'],
        'subject': 'Explicit F27 semantic fix and independent reference',
        'rationale': 'Both legacy numerical defects are explicitly repaired, with detached round snapshots and delta computed against old ci. The exact zero/nonzero SGD cases discriminate the wrong sign and wrong control formula. Independent exact arithmetic matches every supplied two-round value.',
        'baseline_evidence': 'scaffold_strategy.py:261,347; historical trainer:86,115; independent_checks.json exact_baseline_reproduction.',
    },
    {
        'id': 'R02', 'status': 'PASS', 'concerns': ['C02'], 'acceptance': ['A02', 'A04'],
        'subject': 'Actual optimizer LR, constant equal-rate groups and real update timing',
        'rationale': 'The real optimizer is the authority, with no .01/trainer.lr fallback. The fixed positive finite scalar boundary, equal groups mapped by parameter identity, round reset and pre-update rejection of a changed rate are specific. Normal and final updates must capture the executed rate before post-step hooks/schedulers can change it.',
        'baseline_evidence': 'optimizers.py:45-62 reads parameters.optimizer; composable.py:447 precedes optimizer creation at481; before_step at530 is only a microbatch hook; finalization at605 has no before_step; post-optimizer hook at564 precedes correction at569.',
        'feasibility': 'Publishing context.state[optimizer] after creation is reachable without reordering on_train_start. The installed actual optimizer supports step pre-hooks, independently exercised once. The final-path pre-update capture remains mandatory implementation work under C02/A02/A04, not a defect deferred to variable-rate support.',
    },
    {
        'id': 'R03', 'status': 'PASS', 'concerns': ['C04'], 'acceptance': ['A03', 'A08'],
        'subject': 'Parameter ownership, custom names, buffers and historical controls',
        'rationale': 'Removing name filtering and using optimizer-owned requires_grad parameters fixes theta and reordered groups. Missing gradients receive zero-gradient additive correction. Frozen/excluded parameters avoid corrections; excluded trainable controls remain unchanged with zero delta. Known historical buffer/frozen extras are projected, unknown/missing/shape/nonfinite controls fail, and inbound tensors are detached rather than mutated.',
        'baseline_evidence': 'scaffold_strategy.py:235-239 versus332; scaffold_server.py:80-89 creates controls from the full state_dict and66-68 assumes delta keys for every entry.',
    },
    {
        'id': 'R04', 'status': 'PASS', 'concerns': ['C05'], 'acceptance': ['A02', 'A04'],
        'subject': 'Completed-update K, final accumulation, K=0 and zero LR',
        'rationale': 'F08 supplies the actual completed-step contract. Windows2 with1/3/4 microbatches test K=1/2/2 and normalized tails, skipped steps and no duplicate finalize. A later empty round must retain ci and emit fresh zero delta. Zero/negative/nonfinite LR fails before an attempted update; max(1,K) is removed.',
        'baseline_evidence': 'training_step.py:118-130; composable.py:558-575,603-616; scaffold_strategy.py:277,311.',
    },
    {
        'id': 'R05', 'status': 'PASS', 'concerns': ['C06'], 'acceptance': ['A05', 'A06'],
        'subject': 'Logical-client controls, migration and successful worker return',
        'rationale': 'One strategy owns ci. F23 logical identity and F07 contained paths are explicit prerequisites. Canonical state wins; only exact same-client legacy paths can be imported, never client0 for another ID. Reuse1->2->1 and reconstruction are compared over multiple rounds. Parent ci and delta must come from the current successful child; missing/failed handoff or load/save cannot yield a stale successful outbound result.',
        'baseline_evidence': 'composable.py:149,267-270,385-391,722-777; scaffold_strategy.py:117-137,366-382; scaffold_client.py:31-53; retained additional_F23_control_state_confirmation.',
        'compatibility': 'Legacy dictionaries/files remain structurally loadable and original files retained. Corrected continuation intentionally differs numerically. Consistent fresh initialization is documented without a one-client reset or a full-restart promise.',
    },
    {
        'id': 'R06', 'status': 'PASS', 'concerns': ['C07'], 'acceptance': ['A06', 'A07'],
        'subject': 'Late payload context handoff and reused processor binding',
        'rationale': 'Each inbound extraction installs current detached server c directly in the active trainer context. Reused processors rebind to the current trainer/client; omitted or malformed example c clears stale data and fails. The optional standalone zero-control fallback does not excuse missing controls in the federated example. A06 tests the actual order and consumed/emitted state, in both direct and shipped spawn paths.',
        'baseline_evidence': 'defaults.py:98 then245-255; scaffold_callback.py:26-43,87-90,119-120; scaffold_trainer.py:49-61.',
    },
    {
        'id': 'R07', 'status': 'PASS', 'concerns': ['C08'], 'acceptance': ['A07', 'A08'],
        'subject': 'Population denominator, model weighting and validation before commit',
        'rationale': 'Controls retain the1/N population update while model aggregation retains existing sample weights. Unequal-count behavior is labeled a SCAFFOLD-derived extension, with no weighted-objective/convergence claim. The oracle distinguishes x=1.19 from uniform x=1 and gives c=2/3. Required deltas and all control keys must validate before either model/control commit; malformed payloads cannot be silently dropped.',
        'baseline_evidence': 'scaffold_server.py:38-68; fedavg.py:179 then209/235 then239; aggregation/fedavg.py:97-107.',
        'feasibility': 'The example weights_received hook runs before model mutation and can validate/stage the complete control update. Checking only weights_aggregated is insufficient; existing C08/A08 already require early rejection. No general server-base redesign is necessary for this bounded contract.',
    },
    {
        'id': 'R08', 'status': 'PASS', 'concerns': ['C03', 'C09'], 'acceptance': ['A04', 'A09'],
        'subject': 'Honest SGD reference, momentum/Adam extension and V2 compatibility',
        'rationale': 'The shipped momentum=.9/config values are preserved. Plain fixed-rate SGD with momentum/weight_decay0 and maximize=false supplies the strict gradient reference. Other retained optimizers use the explicitly defined post-optimizer subtractive extension and warn once per run; A09 checks raw-optimizer composition instead of falsely claiming mean-gradient equivalence. Exported V2/constructor remain as corrected Option II compatibility, including the accumulation tail. True Option I is a feature deferral rather than a reason to keep the broken implementation.',
        'baseline_evidence': 'shipped TOML:38,58-61; scaffold_strategy.py:414-559; composable.py:562-569.',
    },
    {
        'id': 'R09', 'status': 'PASS', 'concerns': ['C10'], 'acceptance': ['A10'],
        'subject': 'Mandatory public docs, phase ownership and F20 exception',
        'rationale': 'Corrected formulas, actual delta transport, fixed-rate limits, optimizer/model-weighting limits, legacy numerical discontinuity and removal of blanket convergence claims are mandatory before Phase2C/Phase2 closure. Exact SCAFFOLD example/docs paths are reserved from Phase4/5. F20 legacy unsquared-L2 default and l1 behavior remain independently preserved; no squared-FedProx migration is inferred.',
        'baseline_evidence': 'Public SCAFFOLD section lines12-17; plan-addendum.json F20 policy; design decision.preserve, C10 and implementation_handoff.',
        'user_model_policy': 'Overall2C ownership names the phase task. C owns code/tests/docstrings. A fresh root-assigned Astra writing agent authors standalone README/public prose from C implementation facts, followed by independent review. This user-authorized handoff satisfies the ownership contract and must occur before Phase2 closure, not be deferred to later docs phases.',
    },
    {
        'id': 'R10', 'status': 'PASS', 'concerns': ['C01', 'C02', 'C06', 'C07', 'C08', 'C10'], 'acceptance': ['A01', 'A02', 'A03', 'A04', 'A05', 'A06', 'A07', 'A08', 'A09', 'A10'],
        'subject': 'Finite acceptance, dependencies and unnecessary scope',
        'rationale': 'A01-A10 are behavior-specific and discriminating, not helper-derived or parse-only checks. The deterministic synthetic config-based smoke produces real client gradients/deltas with actual counts2/6/4 and K2; one batch per epoch is reachable through the baseline loader. Direct/spawn qualification and F07/F08/F23 integrated review are mandatory. Deferred variable rates, true Option I, new model weighting, full restart, GPU and benchmarks do not excuse known supported-path defects. Authentication, transport, unrelated algorithms and general framework redesign are excluded.',
        'ownership': 'Root accepts the exact design, serializes any necessary shared handoff, authorizes the original2C implementer, assigns the prose handoff and records the Phase4 receipt. No extra user-permission detour is required. A10 uses supported locked3.13 and focused available3.14 evidence without claiming whole-stack support.',
    },
]

numerical = json.loads((SCRATCH / 'independent_checks.json').read_text())
report = {
    'schema_version': 1, 'date': '2026-10-02',
    'review_role': 'Fresh independent bounded F27 design reviewer; no nested agents.',
    'review_type': 'Design review, not implementation acceptance.',
    'decision': 'PASS', 'acceptance': 'PASS', 'finding': 'F27',
    'summary': 'No material critical/high/medium findings. The exact design closes the advertised SCAFFOLD equation and necessary integration defects with explicit compatibility limits, bounded acceptance and narrow ownership. Root may authorize the2C implementation; F27 remains open until implemented, independently reviewed and integrated acceptance passes.',
    'findings': [], 'finding_counts': {'critical': 0, 'high': 0, 'medium': 0, 'low': 0},
    'reviewed_design': {'path': DESIGN, 'expected_sha256': EXPECTED, 'sha256_at_start': EXPECTED, 'sha256_at_end': digest((ROOT / DESIGN).read_bytes()), 'identity_matches': True},
    'production_baseline': {'commit_at_start': BASE, 'commit_at_end': git('rev-parse', 'HEAD').decode().strip(), 'unchanged_production_examples_docs_tests': True, 'inspection_method': 'git show of exact baseline objects; current root bytes additionally matched for inspected files. No moving C worktree inspected.'},
    'inputs': inputs, 'baseline_interface_identity': source_identity,
    'primary_source_verification': {
        'title': 'SCAFFOLD: Stochastic Controlled Averaging for Federated Learning',
        'url': 'https://arxiv.org/pdf/1910.06378v4', 'revision': 'v4, 9 April 2021',
        'method': 'Opened the primary PDF directly; independently read Algorithm1 and equations3-5 from extracted text. Retained exact downloaded PDF bytes. No secondary source or appendix equation19 used as the oracle.',
        'locations': ['Algorithm1, PDF page4, lines10/12/16-17', 'Eq3, PDF page4', 'Eq4 and Eq5, PDF page5', 'AppendixE Eq19, PDF page26, checked only as a counterexample'],
        'verified_equations': {'local': 'y_next=y-eta*(g-ci+c)', 'option_II': 'ci_new=ci-c+(x-y)/(K*eta)', 'server_control': 'c_new=c+sum(delta_ci)/N', 'paper_model': 'x_new=x+eta_global*sum(y_i-x)/len(S)'},
        'independent_inference': 'Telescoping the local updates gives ci_new=mean of used gradients for constant-rate vanilla SGD. Appendix19 reverses c/ci in the displacement expression; g0,c2,ci1,eta.1 gives2 rather than0. This is independently disproved, not adopted.',
        'retained_pdf': str(SCRATCH / 'primary-paper-1910.06378v4.pdf'),
        'retained_pdf_sha256': digest((SCRATCH / 'primary-paper-1910.06378v4.pdf').read_bytes()),
    },
    'bounded_design_checks': checks,
    'executed_checks': {
        'command': 'zsh -lc \'PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=. OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .venv/bin/python /tmp/plato-phase2c-scaffold-design-review/independent_checks.py\'',
        'exit_code': 0, 'results': numerical,
        'source_path': str(SCRATCH / 'independent_checks.py'),
        'source_sha256': digest((SCRATCH / 'independent_checks.py').read_bytes()),
        'results_path': str(SCRATCH / 'independent_checks.json'),
        'results_sha256': digest((SCRATCH / 'independent_checks.json').read_bytes()),
        'baseline_probe_isolation': 'Compiled the exact git object and patched only its Config accessor in the probe process; the pickle output stayed in owned scratch. No root fixture or candidate code used.',
        'limits': 'Small CPU float64 SGD/reference and exact rational oracle only. Optimizer hook feasibility was exercised once. No implementation green claim, distributed/convergence result, broad runtime suite, GPU qualification, spawned candidate check or unrelated algorithm audit.',
    },
    'implementation_acceptance_still_required': {
        'design_criteria': 'All A01-A10, including normal/final executed-LR capture, no stale worker/processor state, legacy path precedence, early delta validation, buffers, momentum/Adam and V2 tests.',
        'docs_deadline': 'Fresh root-assigned Astra prose from C facts with independent review before Phase2 closure; C code/tests/docstrings stay with C.',
        'closure': 'Independent implementation review and root integration on F07/F08/F23/F27, required profiles, exact candidate/diff identity and retained commands/results. PASS authorizes design disposition only and does not close F27.',
    },
    'write_and_resource_scope': {
        'shell': 'zsh -lc', 'agents_spawned': 0, 'production_or_design_edits': 0,
        'commits': 0, 'pushes': 0, 'pr_edits': 0, 'questions': 0,
        'worktree_or_environment_changes': 0,
        'sole_root_write': 'evidence/2026-refresh/phase2c-scaffold-design-review.json',
        'owned_scratch': str(SCRATCH), 'resources_retained': True,
    },
}
assert report['reviewed_design']['sha256_at_end'] == EXPECTED
assert report['production_baseline']['commit_at_end'] == BASE
OUTPUT.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'decision': report['decision'], 'review_path': str(OUTPUT), 'design_sha256': EXPECTED, 'review_sha256': digest(OUTPUT.read_bytes()), 'checks': len(checks)}, indent=2))
