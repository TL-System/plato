import hashlib,json,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
import numpy as np
repo=Path('/private/tmp/plato-refresh-worktrees/training');scratch=Path('/tmp/plato-phase2c-feddyn-implementation');out=repo/'evidence/2026-refresh'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def artifact(p):p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def read(p):return json.loads(Path(p).read_text())
def write(p,j):Path(p).write_text(json.dumps(j,indent=2)+'\n')
data=read(out/'phase2c-feddyn-validation.json')
assert len(data['profiles'])==4 and all(j['exit_code']==0 and j['counts']['failed']==0 for j in data['profiles'].values())
assert all(r['exit_code']==0 for r in data['runtime'].values())
for criterion in data['acceptance_criteria'].values():
 if criterion['status']!='ROOT_CODE_PROSE_GATE_PENDING':criterion['status']='IMPLEMENTED_DUAL_VERSION_QUALIFIED_REVIEW_PENDING'
socket={}
startup={}
for v in ('313','314'):
 root=scratch/f'combined-mandatory-runtime-{v}'
 p=next(root.glob('test_real_two_client_cpu_so*/round/result.json'));r=read(p)
 received=[e for e in r['events'] if e['event']=='server_received'];aggregate=next(e['weights'] for e in r['events'] if e['event']=='server_aggregate')
 assert sorted(e['samples'] for e in received)==[2,6] and not r['timed_out'] and not r['forced'] and not r['survivors']
 errors={k:float(np.max(np.abs(np.asarray(actual)-sum(e['samples']*np.asarray(e['weights'][k]) for e in received)/8))) for k,actual in aggregate.items()}
 socket[v]={'result':artifact(p),'samples':sorted(e['samples'] for e in received),'max_error':max(errors.values()),'parameter_errors':errors,'natural_success':True,'survivors':[]}
 cases=ET.parse(scratch/f'combined-mandatory-runtime-{v}.xml').findall('.//testcase');assert len(cases)==51
 startup[v]={'startup_cases':sum('test_event_loop_startup' in c.attrib.get('classname','') for c in cases),'feddyn_entrypoint_cases':sum('test_feddyn_entrypoint' in c.attrib.get('classname','') for c in cases)}
 assert startup[v]==dict(startup_cases=48,feddyn_entrypoint_cases=3)
data['real_weighted_socket_qualification']=socket;data['runtime_case_inventory']=startup
data['status']='IMPLEMENTED_DUAL_VERSION_QUALIFIED_FRESH_REVIEW_PENDING'
data['source_identical_runtime_carry_forward']={'executed_commit':'05a9f00b8a4d54c233c1a9c00ef9ce2c4467480c','final_implementation_commit':data['implementation_commit'],'only_intervening_source_change':'FedDyn-only test branch in tests/trainers/test_personalized_state_ownership.py isolates its import namespace via guarded subprocess; no production/runtime test/harness/config difference.','diff':subprocess.check_output(['zsh','-lc','git diff --stat 05a9f00b HEAD'],cwd=repo,text=True).strip(),'no_repeat_reason':'All51 runtime cases passed; unrelated test-only import isolation is fully covered by rerun base/mandatory non-runtime profiles. No extra startup rerun solely for evidence commits.'}
data['checks']={'ruff':artifact(scratch/'ruff-final7d.log'),'ty':artifact(scratch/'ty-final7d.log'),'composable_baseline_comparison':artifact(scratch/'ty-composable-comparison.json'),'dependency_blob_comparison':artifact(scratch/'dependency-production-blobs.json'),'profiling_runner':artifact(scratch/'validate_combined.py')}
data['known_warnings']=dict(total_each_non_runtime_profile=17,categories={'secure_rng_disabled':5,'rdp_order_boundary':3,'torch_full_backward_hook':4,'spent_budget_epsilon_calibration':2,'new_subset_dataset_identity':3},blanket_filters_added=False,privacy_limit='Accounting state retained and measured; no global privacy-budget guarantee. make_private_with_epsilon warns it calibrates as if starting from zero.')
data['qualifying_profile_skip_policy']={'base':'3 exact allowed Nanochat omissions; Opacus is installed and its actual tests run.','mandatory':'1 exact allowed absence of callable native rustbpe.Tokenizer; real Nanochat model/trainer cases run.','native_nanochat_pin':'c75fe54aa7c1fa881701c246f9427bcbe4eee5a4','submodule_command':'zsh -lc git submodule update --init external/nanochat; initialized exact existing pin, never updated gitlink.'}
write(out/'phase2c-feddyn-validation.json',data)
facts=read(out/'phase2c-feddyn-facts.json');facts['validation_status']='Dual-version combined base/mandatory profiles qualified; fresh independent code/prose reviews and root acceptance pending.';facts['qualifying_counts']={k:r['counts'] for k,r in data['profiles'].items()};facts['runtime_cases_each']=startup['313'];facts['limits'].append('Author active clipping order is unsupported; the differentiated full loss matches the author unclipped plain-SGD step, not an active-clipping experiment.');facts['evidence']='phase2c-feddyn-validation.json';write(out/'phase2c-feddyn-facts.json',facts)
main=read(out/'phase2c-validation.json');main['current_feddyn_scaffold_delivery']={'status':data['status'],'implementation_commit':data['implementation_commit'],'implementation_tree':data['implementation_tree'],'evidence':artifact(out/'phase2c-feddyn-validation.json'),'facts':artifact(out/'phase2c-feddyn-facts.json'),'dependency_merges':data['dependency_merges'],'preserved_historical_report':'Original f977/earlier counts/findings remain historical, never relabelled as new candidate passes.','general_four_corrections':'Root independently accepted at f977; retained, not reopened.','new_corrections':['F27-R3-01 cleanup before direct acceptance; L01 failed-stage cleanup ownership and primary/secondary exception visibility.','ROOT-2BC-01 test reconciliation to independently referenced owned selection RNG.','ROOT-2C-02 portable actual old-writer fixture retained; FD now uses explicit read-only legacy inspection API.'],'finding_2C_11':'Implemented/qualified under accepted FD design; still open pending independent code/prose review and root acceptance.','public_scaffold_change':'Fallible successful cleanup now precedes final direct result acceptance; deferred parent/token/model-save ordering, equations/control paths and server callback/evaluation boundary unchanged. Astra prose reconciliation needed.','counts':{k:r['counts'] for k,r in data['profiles'].items()},'runtime':startup,'runtime_provenance':data['source_identical_runtime_carry_forward'],'whole_phase_acceptance':'Not claimed.'};write(out/'phase2c-validation.json',main)
print(json.dumps({'socket':socket,'profiles':{k:r['counts'] for k,r in data['profiles'].items()},'startup':startup},indent=2))
