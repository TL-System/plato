from datetime import datetime, timezone
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import shlex
import subprocess

SCRATCH = Path('/tmp/plato-phase2c-scaffold-docs-review')
ROOT = Path('/Users/bli/Playground/plato')
REPO = Path('/private/tmp/plato-refresh-worktrees/scaffold-docs')
OUT = ROOT / 'evidence/2026-refresh/phase2c-scaffold-docs-review.json'
checks = json.loads((SCRATCH / 'checks.json').read_text())
candidate = checks['candidate_commit']
base = checks['base_commit']
c_commit = checks['immutable_C_commit']


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['zsh', '-lc', shlex.join(['git', *args])], cwd=REPO)


assert git('rev-parse', 'HEAD').decode().strip() == candidate
assert git('status', '--porcelain') == b''
for item in checks['root_inputs']:
    assert sha(Path(item['path']).read_bytes()) == item['sha256']

manifest = checks['source_manifest']
for path in ['plato/models/registry.py', 'plato/models/lenet5.py', 'plato/datasources/registry.py', 'plato/datasources/torchvision.py']:
    entry = {'path': path}
    for label, commit in [('candidate', candidate), ('base', base), ('immutable_C', c_commit)]:
        entry[f'{label}_git_blob'] = git('rev-parse', f'{commit}:{path}').decode().strip()
        entry[f'{label}_sha256'] = sha(git('show', f'{commit}:{path}'))
    assert entry['candidate_sha256'] == entry['base_sha256'] == entry['immutable_C_sha256']
    manifest.append(entry)

oracle = []
for grads in [[F(0)], [F(3), F(1)]]:
    x, c, ci, eta = F(1), F(2), F(1), F(1, 10)
    y = x
    for gradient in grads:
        y -= eta * (gradient - ci + c)
    ci_new = ci - c + (x - y) / (len(grads) * eta)
    assert ci_new == sum(grads) / len(grads)
    oracle.append({'x': str(x), 'c': str(c), 'ci_old': str(ci), 'eta': str(eta), 'gradients': [str(g) for g in grads], 'y': str(y), 'ci_new': str(ci_new), 'delta_ci': str(ci_new-ci)})
assert (F(31, 50)*2 + F(69, 50)*6)/8 == F(119, 100)
assert (F(31, 50) + F(69, 50))/2 == 1
assert F(2) + (F(-1, 10) + F(-39, 10))/3 == F(2, 3)
math = {'type': 'Independent exact arithmetic from main-algorithm equations; no production strategy, Torch optimizer or training invocation.', 'local_cases': oracle, 'appendix_19_counterexample': {'g': '0', 'correct_ci_new': '0', 'reversed_c_minus_ci_displacement': '2'}, 'population_and_model_discriminator': {'N': 3, 'participants': 2, 'counts': [2, 6], 'local_models': ['31/50', '69/50'], 'sample_weighted_model': '119/100', 'uniform_model': '1', 'population_control': '2/3'}}
math_path = SCRATCH / 'independent-math.json'
math_path.write_text(json.dumps(math, indent=2)+'\n')

diff = git('diff', '--binary', '--full-index', base, candidate)
diff_path = SCRATCH / 'candidate-docs.diff'
diff_path.write_bytes(diff)
historical = []
for commit, path, use in [('00eeb9dcdd2b513e64db9408969356037e09bb8e', 'examples/customized_client_training/scaffold/scaffold_client.py', 'Exact historical example model_name/client filename and pickle loader.'), ('df1d763b487634ab3708f75f8f055af6f2789941', 'examples/customized_client_training/scaffold/scaffold_trainer.py', 'Actual historical pickle writer and old equations; documents numerical discontinuity.')]:
    historical.append({'revision': commit, 'path': path, 'git_blob': git('rev-parse', f'{commit}:{path}').decode().strip(), 'sha256': sha(git('show', f'{commit}:{path}')), 'use': use})

report = {
    'schema_version': 1,
    'date': '2026-10-03',
    'written_at_utc': datetime.now(timezone.utc).isoformat(),
    'role': 'Fresh independent SCAFFOLD documentation reviewer; no nested agents.',
    'review_type': 'Provisional exact-committed-snapshot writing review, not C implementation acceptance.',
    'decision': 'PASS',
    'acceptance': 'PROVISIONAL_WRITING_PASS_ONLY',
    'final_documentation_acceptance': False,
    'finding': 'F27',
    'summary': 'No critical/high/medium writing findings in candidate 95c7218fc9801099cd7ffa3afc1be227384d8500. The public prose accurately describes the reviewed successful paths and bounded failure behavior of code base 0dc34dd1d79d90071a0babfa6aa89f33d72a976f, whose code/tests match immutable C 62d7b7d8ef75be779149a96f567779c86699edb4. This PASS does not accept C, close F27 or authorize final documentation integration before final-source reconciliation and required review.',
    'finding_counts': {'critical': 0, 'high': 0, 'medium': 0, 'low': 0},
    'findings': [],
    'identities': {k: checks[k] for k in ['candidate_commit', 'candidate_tree', 'base_commit', 'base_tree', 'immutable_C_commit', 'immutable_C_tree', 'accepted_B_commit']},
    'scope': {
        'worktree': str(REPO),
        'allowed_changed_paths': checks['changed_paths'],
        'exactly_three_changed_paths': True,
        'public_doc_change_is_only_scaffold_section': True,
        'all_other_algorithm_sections': checks['non_scaffold_suffix'],
        'config_bytes_unchanged_since_writer_base': True,
        'config_values_equal_accepted_B': True,
        'all_other_production_and_tests_unchanged': True,
        'clean_candidate_before_and_after': True,
        'diff': {'path': str(diff_path), 'sha256': sha(diff), 'bytes': len(diff)},
        'code_base_to_immutable_C_changed_paths': git('diff', '--name-only', base, c_commit).decode().splitlines(),
    },
    'inputs': checks['root_inputs'],
    'root_evidence_retained_copy_directory': str(SCRATCH / 'root-inputs'),
    'candidate_validation': {
        'path': 'evidence/2026-refresh/phase2c-scaffold-docs-validation.json',
        'sha256': sha(git('show', candidate + ':evidence/2026-refresh/phase2c-scaffold-docs-validation.json')),
        'read': 'Full candidate JSON; all listed documentation/source hashes independently matched to committed bytes.',
        'honest_execution_boundary': 'Writer ran docs-only locked sync, strict builds and static command/render checks. Writer explicitly ran no C tests or MNIST training and did not claim a full training installation.',
        'historical_status_boundary': 'Pending-C-execution/review wording describes the writer handoff at its authored snapshot. Updated root code reviews are COMPLETE and request changes; neither those reviews nor their successful-path results are pending or accepted by this writing PASS. Final corrected-C execution, source reconciliation and acceptance still remain root-owned.',
    },
    'implementation_author_evidence': checks['author_evidence'],
    'implementation_author_evidence_interpretation': 'Read immutable facts and validation at 62d. Their reported qualification is author evidence, not reviewer reruns or proof that open C findings are corrected. Facts/test inventories do not override actual code or the completed independent reviews.',
    'source_manifest': manifest,
    'historical_sources': historical,
    'primary_source': {
        'title': 'Karimireddy et al., SCAFFOLD: Stochastic Controlled Averaging for Federated Learning, ICML 2020',
        'url': 'https://arxiv.org/pdf/1910.06378v4',
        'revision': 'v4, 9 April 2021',
        'read': ['Algorithm 1 and Eq. (3), PDF page 4', 'Eqs. (4)-(5) and Option I additional-gradient-pass description, PDF page 5', 'Appendix E Eq. (19), PDF page 26'],
        'verification': 'Primary PDF opened with web tool and independently downloaded. Main-algorithm signs take precedence over appendix Eq. (19). The mean-gradient identity and sign counterexample are independent reviewer algebraic inferences, not convergence claims.',
        'equations': {'local': 'y_next=y-eta*(g-ci+c)', 'post_optimizer': 'y=raw_optimizer_result-eta*(c-ci)', 'option_II': 'ci_new=ci-c+(x-y)/(K*eta)', 'delta': 'ci_new-ci', 'population_control': 'c_new=c+sum(delta_ci)/N', 'paper_model': 'x_new=x+eta_global*sum(y_i-x)/len(S)'},
        'retained_pdf': checks['paper'],
        'independent_math': {'path': str(math_path), 'sha256': sha(math_path.read_bytes()), 'result': 'PASS_EXACT_ARITHMETIC'},
        'screenshot_limit': 'Three web PDF screenshot requests failed with content-type/screenshot-disabled errors; extracted primary text and retained PDF provided the equations. No successful screenshot inspection is claimed.',
    },
    'claim_assessment': [
        {'subject': 'Main-algorithm local sign, corrected Option II, V2 and theory scope', 'result': 'PASS', 'docs': [{'path': 'examples/customized_client_training/scaffold/README.md', 'line': 24}, {'path': 'docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md', 'line': 25}], 'basis': 'Source strategy:254-308 and V2:373-379 match main Algorithm 1/Eqs. 3-5. The constant-rate vanilla gradient-average identity follows by telescoping. No true Option I or more-accurate V2 claim. Momentum .9 and other non-vanilla optimizer composition are expressly extensions, with no paper convergence guarantee.'},
        {'subject': 'Actual rate, completed K, accumulation tail, zero/skipped updates and parameter scope', 'result': 'PASS', 'docs': [{'path': 'examples/customized_client_training/scaffold/README.md', 'line': 49}, {'path': 'docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md', 'line': 37}], 'basis': 'Actual optimizer publication and step prehook capture finite positive equal scalar rates for participating trainable groups, reject within-round changes before the affected update, and reset next round. Post-step changes do not replace the executed rate. Composable completion/finalize paths and accumulation normalization support one correction per actual update, including the partial tail; K=0 avoids division and produces fresh zero delta. Identity-based included/no-gradient and excluded/frozen/buffer descriptions match code. Delivered assertions were read, not executed.'},
        {'subject': 'Population controls versus sample-weighted model averaging', 'result': 'PASS', 'docs': [{'path': 'examples/customized_client_training/scaffold/README.md', 'line': 72}, {'path': 'docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md', 'line': 46}], 'basis': 'Server stages unweighted sum(delta_ci)/clients.total_clients. Inherited positive-total-sample FedAvg model averaging is separately and correctly described. Unequal counts are scoped as a framework extension; no uniform-paper/weighted-objective convergence promise.'},
        {'subject': 'Logical client, canonical and exact historical state', 'result': 'PASS', 'docs': [{'path': 'examples/customized_client_training/scaffold/README.md', 'line': 88}, {'path': 'docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md', 'line': 55}], 'basis': 'Strategy setup/load/client-ID hooks match canonical scaffold_cv_ID.pkl under model_path or explicit save_path, then contained exact same-client model_name_ID_control_variate.pth, then exact prefix-concatenated same-client .pkl. No client-0 substitution or broad search. Canonical load failure does not fall back. Finite floating trainable controls/shapes are checked; known historical buffers/frozen entries projected and unknown keys rejected. Distinct legacy files are preserved. Actual historical pickle writer/loader corroborated.'},
        {'subject': 'Current payload, direct/spawn flow and bounded failure statement', 'result': 'PASS', 'docs': [{'path': 'examples/customized_client_training/scaffold/README.md', 'line': 64}, {'path': 'docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md', 'line': 66}], 'basis': 'Current inbound processor clears stale controls/delta and installs current validated c in active context. Direct state remains in-process; spawn uses the current token/client envelope to return ci/delta/K/rate after saved-model loading. Missing/stale handoff rejects successful outbound delta. This wording does not promise durable checkpoint rollback after failure or validation of malformed model halves; known C defects remain open.'},
        {'subject': 'Legacy numerical discontinuity and practical fresh-run advice', 'result': 'PASS', 'docs': [{'path': 'examples/customized_client_training/scaffold/README.md', 'line': 110}, {'path': 'docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md', 'line': 69}], 'basis': 'Separate -b run directory produces fresh client control files; server initializes controls to zero. Advice calls for consistently initialized server and all client controls. Structurally loadable old state is not promised numerically equivalent. No coordinated full server/optimizer/RNG/privacy restart promise.'},
        {'subject': 'Standalone usefulness, paths, flags and unchanged settings', 'result': 'PASS', 'basis': 'README provides complete root-relative installation/run commands, settings, processor behavior, supported rate constraints and practical state guidance. The public page supplies its own root/cd command and key limitations. Exact entrypoint/config paths and local module wiring checked statically; actual Config help and both documented relative TOML paths loaded through uv in reviewer-owned docs/config environment. Shipped values are preserved; no training environment or entrypoint training success claim.'},
    ],
    'known_implementation_dependencies_not_new_writing_findings': [
        {'id': 'F27-R01', 'severity_in_code_review': 'high', 'status': 'OPEN_IN_REVIEWED_SNAPSHOT; assigned to original C author', 'path': 'examples/customized_client_training/scaffold/scaffold_server.py', 'line': 68, 'precise_gap': 'Control halves validate, but malformed model halves can commit model/control state. Reviewed prose does not claim full model-half validation or whole-round rollback on arbitrary malformed payloads. Do not treat the accepted design or tests for invalid controls as implementation of that stronger contract.', 'required_before_final_acceptance': 'C correction and fresh code validation/review, then root reconciliation of server/aggregation hashes and all related writing/evidence claims.'},
        {'id': 'F27-R02', 'severity_in_code_review': 'medium', 'status': 'OPEN_IN_REVIEWED_SNAPSHOT; assigned to original C author', 'path': 'plato/trainers/strategies/algorithms/scaffold_strategy.py', 'line': 304, 'precise_gap': 'Child writes canonical ci before current handoff acceptance. Missing/stale handoff refuses outbound but advanced persisted controls can be adopted on reuse/reconstruction. Reviewed prose promises outbound refusal, not durable rollback or successful-retry numerical consistency after such a failure.', 'required_before_final_acceptance': 'C stages controls or restores prior canonical state on rejected handoff; root reconciles strategy/composable/test hashes and any changed persistence/handoff prose. Fresh writing review if claims change.'},
        {'ids': ['ROOT-2C-01', 'TRAINING-2C-01', 'TRAINING-2C-02', 'TRAINING-2C-03'], 'status': 'Separate general C review findings; read from root evidence, not evolving worktree.', 'writing_disposition': 'No new writing finding for this scoped SCAFFOLD prose. Final C changes affecting shared optimizer, cleanup, checkpoint or ownership paths still require hash/claim reconciliation. This review does not close those findings.'},
    ],
    'executed_checks': [
        {'command': 'UV_CACHE_DIR=/tmp/plato-phase2c-scaffold-docs-review/uv-cache UV_PROJECT_ENVIRONMENT=/tmp/plato-phase2c-scaffold-docs-review/venv uv sync --locked --only-group docs --no-install-project --python /tmp/plato-phase2c-scaffold-docs/venv/bin/python', 'shell': ['zsh', '-lc'], 'cwd': str(REPO), 'exit_code': 0, 'log': str(SCRATCH / 'docs-sync.log'), 'log_sha256': sha((SCRATCH / 'docs-sync.log').read_bytes()), 'boundary': 'Only reviewer-owned docs environment installed; external writer interpreter read, writer environment not mutated.'},
        {'command': 'UV_CACHE_DIR=/tmp/plato-phase2c-scaffold-docs-review/uv-cache uv pip install --python /tmp/plato-phase2c-scaffold-docs-review/venv/bin/python numpy==2.5.3 munch==4.0.0', 'shell': ['zsh', '-lc'], 'cwd': str(REPO), 'exit_code': 0, 'log': str(SCRATCH / 'config-deps.log'), 'log_sha256': sha((SCRATCH / 'config-deps.log').read_bytes()), 'boundary': 'Added only Config imports at locked versions to reviewer-owned environment; no full training installation.'},
        {'command': 'PYTHONDONTWRITEBYTECODE=1 /tmp/plato-phase2c-scaffold-docs-review/venv/bin/python /tmp/plato-phase2c-scaffold-docs-review/review_checks.py', 'shell': ['zsh', '-lc'], 'cwd': str(REPO), 'exit_code': 0, 'result': 'Exact diff/suffix/config/source/evidence hashes, static commands, repo-extension Markdown rendering, primary PDF hash and actual Config probes verified. Strict-build failures attributed and retained.', 'script_sha256': sha((SCRATCH / 'review_checks.py').read_bytes()), 'log': str(SCRATCH / 'check-run.log'), 'log_sha256': sha((SCRATCH / 'check-run.log').read_bytes()), 'results': str(SCRATCH / 'checks.json'), 'results_sha256': sha((SCRATCH / 'checks.json').read_bytes())},
        *checks['executions'],
    ],
    'mkdocs_attribution': {
        'strict_pass': False,
        'base_and_candidate_fail_identically': True,
        'results': checks['strict_builds'],
        'new_scaffold_warnings': 0,
        'disposition': 'The same two Nanochat relative-link warnings are preexisting and assigned Phase 5. They were neither repaired nor counted as writing blockers. Material emits the same informational banner in both runs; the strict abort is exactly two MkDocs link warnings.',
    },
    'static_command_checks': checks['static_commands'],
    'render_checks': checks['markdown_render'],
    'environment': {**checks['environment'], 'uv': '0.12.22', 'environment_path': str(SCRATCH / 'venv'), 'profile': 'Reviewer-owned docs/config-only environment; not full training dependency qualification.'},
    'practical_limits': [
        'No C strategy/runtime test suite, synthetic training pipeline, MNIST training, corpus download, GPU/MPS, benchmark or convergence run executed by this reviewer. Config help/load probes and pure rational equation arithmetic are the only non-build executions beyond source/hash/static inspection.',
        'Delivered code/tests and immutable author execution records were read as evidence; their presence does not establish a reviewer passing run. Two independent C code reviews are complete and request corrections, not pending or accepted.',
        'Full training uv sync and actual scaffold.py entrypoint execution were not run. Paths/wiring are static checks, complemented by actual Config argument/path loading through uv --no-sync in the owned environment.',
        'Markdown math wrappers, links, fenced code and admonition render using repository extensions. No browser/KaTeX visual inspection or full-site external link crawl; primary paper link fetched successfully.',
        'Strict MkDocs is not passing: both exact archived trees fail only the same two Phase 5 Nanochat relative links. Unrelated FedProx/other algorithm sections were not reviewed for correctness and remain byte-identical.',
        'Review is provisional to exact immutable base/candidate/C identities above. Root must reconcile all relevant code/test hashes against corrected final C, update validation/status claims where needed, obtain corrections and fresh review for changed claims, and complete C execution/acceptance before final documentation integration.',
    ],
    'write_and_resource_scope': {'only_root_write': str(OUT), 'scratch': str(SCRATCH), 'candidate_edits': 0, 'production_config_changes': 0, 'commits': 0, 'pushes': 0, 'nested_agents': 0, 'unrelated_docs_changes': 0, 'resources_retained': True},
}
OUT.write_text(json.dumps(report, indent=2)+'\n')
assert json.loads(OUT.read_text())['decision'] == 'PASS'
assert git('status', '--porcelain') == b''
print(json.dumps({'decision': report['decision'], 'acceptance': report['acceptance'], 'report': str(OUT), 'sha256': sha(OUT.read_bytes()), 'candidate_unchanged': True, 'writing_findings': report['finding_counts']}, indent=2))
