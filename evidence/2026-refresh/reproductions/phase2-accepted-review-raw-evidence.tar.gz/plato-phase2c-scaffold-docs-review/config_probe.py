import json
import os
os.environ.pop("config_file", None)
from pathlib import Path
from plato.config import Config
config = Config()
assert config.args.cpu
assert config.clients.total_clients == 5 and config.clients.per_round == 2
assert config.trainer.rounds == 5 and config.trainer.epochs == 3
assert config.trainer.max_concurrency == 2 and config.trainer.model_name == "lenet5"
assert config.parameters.optimizer._asdict() == {"lr": .01, "momentum": .9, "weight_decay": 0.0}
assert config.data.dataset_name == "MNIST" and config.data.download
base = Path(config.args.base).resolve()
for key in ["data_path", "model_path", "checkpoint_path", "result_path"]:
    assert Path(config.params[key]).resolve().is_relative_to(base)
print(json.dumps({"config_path": str(config.config_path), "cpu": config.args.cpu, "clients": config.clients._asdict(), "trainer": config.trainer._asdict(), "optimizer": config.parameters.optimizer._asdict(), "paths": {k: config.params[k] for k in ["base_path", "data_path", "model_path", "checkpoint_path", "result_path"]}}, indent=2))
