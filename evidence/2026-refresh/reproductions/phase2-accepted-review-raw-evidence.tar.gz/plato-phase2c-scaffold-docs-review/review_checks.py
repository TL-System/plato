import ast
import hashlib
import importlib.metadata
import io
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tarfile
import time
import tomllib
import urllib.request

REPO = Path('/private/tmp/plato-refresh-worktrees/scaffold-docs')
ROOT = Path('/Users/bli/Playground/plato')
SCRATCH = Path('/tmp/plato-phase2c-scaffold-docs-review')
CANDIDATE = '95c7218fc9801099cd7ffa3afc1be227384d8500'
BASE = '0dc34dd1d79d90071a0babfa6aa89f33d72a976f'
C = '62d7b7d8ef75be779149a96f567779c86699edb4'
B = '00eeb9dcdd2b513e64db9408969356037e09bb8e'
DOC = 'docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md'
README = 'examples/customized_client_training/scaffold/README.md'
VALIDATION = 'evidence/2026-refresh/phase2c-scaffold-docs-validation.json'
CONFIG = 'examples/customized_client_training/scaffold/scaffold_MNIST_lenet5.toml'


def sha(data):
    return hashlib.sha256(data).hexdigest()


records = []


def run(label, argv, cwd=REPO, overrides=None):
    command = shlex.join(argv)
    if overrides:
        command = shlex.join(['env', *[f'{k}={v}' for k, v in overrides.items()]]) + ' ' + command
    start = time.monotonic()
    result = subprocess.run(['zsh', '-lc', command], cwd=cwd, capture_output=True, timeout=55)
    log = SCRATCH / f'{label}.log'
    log.write_bytes(result.stdout + result.stderr)
    records.append({'label': label, 'command': command, 'shell': ['zsh', '-lc'], 'cwd': str(cwd), 'exit_code': result.returncode, 'duration_seconds': round(time.monotonic() - start, 3), 'log': str(log), 'log_sha256': sha(log.read_bytes())})
    return result


def git(*args):
    result = subprocess.run(['zsh', '-lc', shlex.join(['git', *args])], cwd=REPO, capture_output=True, timeout=15, check=True)
    return result.stdout


def obj(commit, path):
    return git('show', f'{commit}:{path}')


assert git('rev-parse', 'HEAD').decode().strip() == CANDIDATE
assert git('status', '--porcelain') == b''
allowed = sorted([DOC, README, VALIDATION])
changed = sorted(git('diff', '--name-only', BASE, CANDIDATE).decode().splitlines())
assert changed == allowed
assert git('diff', '--check', BASE, CANDIDATE) == b''
assert git('merge-base', '--is-ancestor', B, BASE) == b''
writer = json.loads(obj(CANDIDATE, VALIDATION))
marker = b'\n---\n\n### FedProx\n'
base_doc = obj(BASE, DOC)
candidate_doc = obj(CANDIDATE, DOC)
base_suffix = marker + base_doc.split(marker, 1)[1]
candidate_suffix = marker + candidate_doc.split(marker, 1)[1]
assert base_suffix == candidate_suffix
assert base_doc.startswith(b'### SCAFFOLD\n') and candidate_doc.startswith(b'### SCAFFOLD\n')
assert obj(BASE, CONFIG) == obj(CANDIDATE, CONFIG) == obj(C, CONFIG)
config = tomllib.loads(obj(CANDIDATE, CONFIG).decode())
assert config == tomllib.loads(obj(B, CONFIG).decode())
assert config['clients']['total_clients'] == 5 and config['clients']['per_round'] == 2
assert config['trainer']['epochs'] == 3 and config['trainer']['rounds'] == 5
assert config['trainer']['max_concurrency'] == 2
assert config['parameters']['optimizer'] == {'lr': .01, 'momentum': .9, 'weight_decay': 0.0}

snapshot_paths = {item['path'] for item in writer['consulted_snapshot_facts']}
snapshot_paths.update([DOC, README, VALIDATION, 'uv.lock', 'plato/trainers/base.py', 'plato/trainers/strategies/optimizer.py', 'plato/trainers/optimizers.py', 'plato/trainers/strategies/base.py', 'plato/clients/strategies/defaults.py', 'plato/servers/fedavg.py', 'plato/trainers/strategies/algorithms/__init__.py'])
manifest = []
for path in sorted(snapshot_paths):
    entry = {'path': path, 'candidate_git_blob': git('rev-parse', f'{CANDIDATE}:{path}').decode().strip(), 'candidate_sha256': sha(obj(CANDIDATE, path))}
    for label, revision in [('base', BASE), ('immutable_C', C)]:
        if path not in [README, VALIDATION]:
            entry[f'{label}_git_blob'] = git('rev-parse', f'{revision}:{path}').decode().strip()
            entry[f'{label}_sha256'] = sha(obj(revision, path))
    if path not in [README, VALIDATION, DOC]:
        assert entry['candidate_sha256'] == entry['base_sha256'] == entry['immutable_C_sha256']
    assert (REPO / path).read_bytes() == obj(CANDIDATE, path)
    manifest.append(entry)
for item in writer['consulted_snapshot_facts']:
    assert sha(obj(CANDIDATE, item['path'])) == item['sha256']
for path, digest in writer['documentation_sha256'].items():
    assert sha(obj(CANDIDATE, path)) == digest
root_inputs = []
for name in ['phase2c-scaffold-design.json', 'phase2c-scaffold-design-review.json', 'phase2c-scaffold-acceptance.json', 'phase2c-scaffold-code-review.json', 'phase2c-training-review.json', 'phase2c-scaffold-docs-source-reconciliation.json']:
    path = ROOT / 'evidence/2026-refresh' / name
    root_inputs.append({'path': str(path), 'sha256': sha(path.read_bytes())})
assert root_inputs[0]['sha256'] == 'f323f3aa9d824df44a1043b2d6aff9c8a963c42964f6e6685108c59b25fc3a89'
author_evidence = []
for name in ['phase2c-scaffold-facts.json', 'phase2c-validation.json']:
    path = 'evidence/2026-refresh/' + name
    data = obj(C, path)
    dest = SCRATCH / name
    dest.write_bytes(data)
    author_evidence.append({'path': path, 'revision': C, 'git_blob': git('rev-parse', f'{C}:{path}').decode().strip(), 'sha256': sha(data), 'retained': str(dest)})

commands = []
for path in [README, DOC]:
    text = obj(CANDIDATE, path).decode()
    if path == DOC:
        text = text.split('\n---\n\n### FedProx\n', 1)[0]
    cwd = REPO
    for block in re.findall(r'```bash\n(.*?)```', text, re.S):
        for line in block.replace('\\\n', ' ').splitlines():
            argv = shlex.split(line)
            if not argv:
                continue
            if argv[0] == 'cd':
                cwd = cwd / argv[1]
                assert cwd.is_dir()
            elif argv == ['uv', 'sync']:
                assert (cwd / 'pyproject.toml').exists()
            else:
                assert argv[:3] == ['uv', 'run', 'python']
                entrypoint = (cwd / argv[3]).resolve()
                toml = (cwd / argv[5]).resolve()
                assert argv[4] == '-c' and entrypoint.is_file() and toml.is_file()
                assert toml == REPO / CONFIG
                module = ast.parse(entrypoint.read_text())
                local = ['scaffold_client', 'scaffold_server', 'scaffold_trainer', 'scaffold_callback']
                for name in local:
                    assert (entrypoint.parent / f'{name}.py').is_file()
                assert any(isinstance(node, ast.FunctionDef) and node.name == 'main' for node in module.body)
            commands.append({'document': path, 'cwd': str(cwd), 'argv': argv, 'result': 'PASS_STATIC'})

builds = []
for label, revision in [('base', BASE), ('candidate', CANDIDATE)]:
    archive = SCRATCH / f'{label}-docs.tar'
    archive.write_bytes(git('archive', revision, 'docs'))
    dest = SCRATCH / label
    dest.mkdir(exist_ok=True)
    with tarfile.open(archive) as tar:
        tar.extractall(dest, filter='data')
    result = run(f'mkdocs-{label}', [sys.executable, '-m', 'mkdocs', 'build', '--strict', '-f', str(dest / 'docs/mkdocs.yml'), '-d', str(SCRATCH / f'{label}-site')], overrides={'PYTHONDONTWRITEBYTECODE': '1', 'XDG_CACHE_HOME': str(SCRATCH / 'xdg-cache')})
    warnings = [line for line in (result.stdout + result.stderr).decode().splitlines() if line.startswith('WARNING')]
    assert result.returncode == 1 and len(warnings) == 2
    assert all('Nanochat' in line and 'not found among documentation files' in line for line in warnings)
    builds.append({'revision': revision, 'exit_code': result.returncode, 'warnings': warnings})
assert builds[0]['warnings'] == builds[1]['warnings']

import markdown
extensions = ['admonition', 'pymdownx.details', 'pymdownx.superfences', 'pymdownx.arithmatex']
rendered = []
for name, text in [('readme', obj(CANDIDATE, README).decode()), ('scaffold-section', candidate_doc.decode().split('\n---\n\n### FedProx\n', 1)[0])]:
    html = markdown.markdown(text, extensions=extensions, extension_configs={'pymdownx.arithmatex': {'generic': True}})
    assert 'https://arxiv.org/pdf/1910.06378v4' in html and 'arithmatex' in html and '<code>' in html
    if name == 'scaffold-section':
        assert 'admonition note' in html
    artifact = SCRATCH / f'{name}.html'
    artifact.write_text(html)
    rendered.append({'artifact': str(artifact), 'sha256': sha(artifact.read_bytes()), 'result': 'PASS'})

env = {'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPATH': str(REPO), 'UV_PROJECT_ENVIRONMENT': str(SCRATCH / 'venv'), 'UV_CACHE_DIR': str(SCRATCH / 'uv-cache')}
assert run('config-help', ['uv', 'run', '--no-sync', 'python', str(SCRATCH / 'config_probe.py'), '--help'], overrides=env).returncode == 0
for label, cwd, config_path in [('root', REPO, CONFIG), ('examples', REPO / 'examples/customized_client_training', 'scaffold/scaffold_MNIST_lenet5.toml')]:
    result = run(f'config-{label}', ['uv', 'run', '--no-sync', 'python', str(SCRATCH / 'config_probe.py'), '-c', config_path, '--cpu', '-b', str(SCRATCH / f'config-runtime-{label}')], cwd=cwd, overrides=env)
    assert result.returncode == 0

pdf = SCRATCH / '1910.06378v4.pdf'
with urllib.request.urlopen('https://arxiv.org/pdf/1910.06378v4', timeout=30) as response:
    pdf.write_bytes(response.read())
assert sha(pdf.read_bytes()) == writer['primary_source']['pdf_sha256']

assert git('status', '--porcelain') == b''
result = {'candidate_commit': CANDIDATE, 'candidate_tree': git('rev-parse', CANDIDATE + '^{tree}').decode().strip(), 'base_commit': BASE, 'base_tree': git('rev-parse', BASE + '^{tree}').decode().strip(), 'immutable_C_commit': C, 'immutable_C_tree': git('rev-parse', C + '^{tree}').decode().strip(), 'accepted_B_commit': B, 'changed_paths': changed, 'clean_candidate_before_and_after': True, 'non_scaffold_suffix': {'byte_identical': True, 'bytes': len(candidate_suffix), 'sha256': sha(candidate_suffix)}, 'config_unchanged_bytes_since_base': True, 'config_values_equal_accepted_B': True, 'source_manifest': manifest, 'root_inputs': root_inputs, 'author_evidence': author_evidence, 'static_commands': commands, 'strict_builds': builds, 'markdown_render': rendered, 'executions': records, 'paper': {'path': str(pdf), 'sha256': sha(pdf.read_bytes())}, 'environment': {'python': sys.version, 'mkdocs': importlib.metadata.version('mkdocs'), 'mkdocs_material': importlib.metadata.version('mkdocs-material'), 'numpy': importlib.metadata.version('numpy'), 'munch': importlib.metadata.version('munch')}}
(SCRATCH / 'checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': 'PASS_CHECKS', 'candidate_tree': result['candidate_tree'], 'base_tree': result['base_tree'], 'strict_builds': builds, 'config_probes': [r['exit_code'] for r in records if r['label'].startswith('config')], 'source_paths_hashed': len(manifest), 'checks': str(SCRATCH / 'checks.json')}, indent=2))
