"""Read-only final identity/receipt/numerical audit for this reviewer."""
import hashlib
import json
import subprocess
from pathlib import Path

scratch = Path('/tmp/plato-phase2c-training-review')
candidate = Path('/private/tmp/plato-refresh-worktrees/training')
root = Path('/Users/bli/Playground/plato/evidence/2026-refresh')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def git(*args):
    # No shell expansion is used here; all actual shells are zsh -lc.
    return subprocess.check_output(['git', *args], cwd=candidate, text=True).strip()

inputs = [candidate / 'AGENTS.md', root / 'plan.md', root / 'plan-addendum.json',
          root / 'phase2b-acceptance.json', root / 'dp-reuse-probe.json',
          root / 'dp-step-probe.json', root / 'trainer-lifecycle-probes.json',
          root / 'phase2c-root-amp-clipping-probe.json',
          root / 'phase2c-root-base-validation.json',
          candidate / 'evidence/2026-refresh/phase2c-validation.json']
input_hashes = [{'path': str(p), 'sha256': sha(p)} for p in inputs]
root_checks = []
def walk(obj):
    if isinstance(obj, dict):
        if isinstance(obj.get('path'), str) and isinstance(obj.get('sha256'), str):
            p = Path(obj['path'])
            if p.is_absolute():
                actual = sha(p)
                root_checks.append({'path': str(p), 'expected': obj['sha256'],
                                    'actual': actual, 'matches': actual == obj['sha256']})
        for value in obj.values():
            walk(value)
    elif isinstance(obj, list):
        for value in obj:
            walk(value)
for name in ('phase2c-root-amp-clipping-probe.json', 'phase2c-root-base-validation.json'):
    data = (root / name).read_bytes()
    (scratch / ('root-receipt-' + name)).write_bytes(data)
    walk(json.loads(data))
assert all(x['matches'] for x in root_checks)

def flatten(value):
    if isinstance(value, list):
        return [x for item in value for x in flatten(item)]
    return [value]
socket = {}
for version in ('313', '314'):
    p = scratch / f'socket-{version}/test_real_two_client_cpu_socke0/round/result.json'
    data = json.loads(p.read_text())
    received = [x for x in data['events'] if x['event'] == 'server_received']
    aggregate = next(x for x in data['events'] if x['event'] == 'server_aggregate')['weights']
    assert {x['client_id'] for x in received} == {1, 2}
    assert sorted(x['samples'] for x in received) == [2, 6]
    error = max(abs(actual - sum(flatten(x['weights'][key])[i] * x['samples'] / 8
                                for x in received))
                for key, values in aggregate.items() for i, actual in enumerate(flatten(values)))
    assert error < 1e-7
    assert data['returncode'] == 0 and not data['timed_out'] and not data['forced'] and not data['survivors']
    socket[version] = {'path': str(p), 'sha256': sha(p), 'weighted_error': error,
                       'client_ids': sorted(x['client_id'] for x in received),
                       'samples': sorted(x['samples'] for x in received),
                       'returncode': data['returncode'], 'survivors': data['survivors']}

labels = ('focused-313', 'focused-314', 'independent-r2-313', 'independent-r2-314',
          'behavior-r2-313', 'behavior-r2-314', 'negative-313', 'negative-314',
          'socket-313', 'socket-314', 'ssl-313', 'ssl-314')
executions = []
for label in labels:
    d = json.loads((scratch / (label + '.json')).read_text())
    assert sha(d['log']) == d['sha256']
    executions.append(d)
changed = git('diff', '--name-only', '00eeb9dcdd2b513e64db9408969356037e09bb8e', 'HEAD').splitlines()
source_hashes = [{'path': p, 'sha256': sha(candidate / p)} for p in changed]
head = git('rev-parse', 'HEAD')
status = git('status', '--porcelain')
assert head == '62d7b7d8ef75be779149a96f567779c86699edb4' and status == ''
result = {'head': head, 'tree': git('rev-parse', 'HEAD^{tree}'), 'status_porcelain': status,
          'inputs': input_hashes, 'root_raw_receipts': root_checks, 'socket': socket,
          'executions': executions, 'candidate_changed_files_sha256': source_hashes}
(scratch / 'final-evidence-details.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'head': head, 'status': status, 'root_raw_hashes_matched': len(root_checks),
                  'reviewer_execution_log_hashes_matched': len(executions), 'socket': socket,
                  'changed_files_hashed': len(source_hashes)}, indent=2))
