import hashlib,json,os,subprocess,sys,time
from pathlib import Path
scratch=Path("/tmp/plato-phase2c-training-review")
label=sys.argv[1]; command=sys.argv[2]
start=time.time()
with (scratch/f"{label}.log").open("wb") as f:
 p=subprocess.run(["zsh","-lc",command],cwd="/private/tmp/plato-refresh-worktrees/training",stdout=f,stderr=subprocess.STDOUT)
log=scratch/f"{label}.log"
d={"label":label,"command":command,"shell":"zsh -lc","cwd":"/private/tmp/plato-refresh-worktrees/training","exit_code":p.returncode,"seconds":time.time()-start,"log":str(log),"sha256":hashlib.sha256(log.read_bytes()).hexdigest()}
(scratch/f"{label}.json").write_text(json.dumps(d,indent=2)); print(json.dumps(d)); print(log.read_text()[-6500:])
