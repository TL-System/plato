"""Assemble the assigned review evidence; never changes the candidate."""
import datetime
import hashlib
import json
import subprocess
from pathlib import Path

scratch = Path('/tmp/plato-phase2c-training-review')
candidate = Path('/private/tmp/plato-refresh-worktrees/training')
destination = Path('/Users/bli/Playground/plato/evidence/2026-refresh/phase2c-training-review.json')
def read(name):
    return json.loads((scratch / name).read_text())
def artifact(path):
    p = Path(path)
    return {'path': str(p), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
def git(*args):
    return subprocess.check_output(['git', *args], cwd=candidate, text=True).strip()

audit = read('final-evidence-details.json')
identity = read('identities.json')
author = json.loads((candidate / 'evidence/2026-refresh/phase2c-validation.json').read_text())
independent = {v: read(f'independent-{v}.json') for v in ('313', '314')}
behavior = {v: read(f'behavior-{v}-r2.json') for v in ('313', '314')}
negative = {v: read(f'negative-{v}.json') for v in ('313', '314')}
primary = [
    {'title': 'PyTorch AMP examples: gradient clipping requires unscaling first',
     'url': 'https://docs.pytorch.org/docs/2.14/notes/amp_examples.html',
     'use': 'Independent library contract supporting ROOT-2C-01, not a copied implementation expectation.'},
    {'title': 'Opacus BatchMemoryManager API', 'url': 'https://opacus.ai/api/batch_memory_manager.html',
     'use': 'Physical splits preserve logical updates; checked against actual optimizer/accountant and manual per-sample clipping.'},
    {'title': 'Opacus GradSampleModule API', 'url': 'https://opacus.ai/api/grad_sample_module.html',
     'use': 'Wrapper/hook ownership and supported removal, checked with real consecutive and interrupted runs.'},
    {'title': 'Timm upstream training loop',
     'url': 'https://raw.githubusercontent.com/huggingface/pytorch-image-models/main/train.py',
     'use': 'Actual-update and start/resume offset convention. Numerical qualification uses installed timm 1.0.30 and a closed-form cosine reference; current upstream main is not claimed to be that exact package revision.'},
]

def repro(node):
    return {
        'source': artifact(scratch / 'review_regressions.py'),
        'pytest_node': node,
        'commands': {v: negative[v]['command'] for v in ('313', '314')},
        'shell': 'zsh -lc', 'cwd': str(candidate),
        'selection': 'Commands run the complete five-case independent negative suite; the named node identifies this failure. No assertions skipped or weakened.',
        'exit_codes': {'313': 1, '314': 1},
        'suite_result_each': '4 failed, 1 passed, 2 warnings',
        'raw': [{**artifact(negative[v]['log']), 'python': v} for v in ('313', '314')],
    }

findings = [
    {
        'id': 'ROOT-2C-01', 'severity': 'medium', 'status': 'OPEN_CONFIRMED_INDEPENDENTLY',
        'title': 'Public optimizer clipping consumes scaled gradients with fused AMP SGD.',
        'locations': [{'path': 'plato/trainers/strategies/optimizer.py', 'line': 414},
                      {'path': 'plato/trainers/strategies/training_step.py', 'line': 253}],
        'trigger': 'MixedPrecisionStepStrategy composed with GradientClippingOptimizerStrategy(DefaultOptimizerStrategy), registry SGD fused=True, real CPU torch.amp.GradScaler. Scalar parameter 1, quadratic loss w^2, lr .1, max_norm 1, initial scale 8.',
        'expected': {'weight': 0.900000049999975, 'calculation': '1 - .1 * 2 / (2 + 1e-6), clipping the unscaled gradient 2.'},
        'actual_each_python': {'fused_weight': 0.987500011920929, 'nonfused_control': 0.9000000357627869, 'optimizer_step_completed': True},
        'cause_and_impact': 'The step prehook clips gradient 16 to about 1. AMP-aware fused SGD then unscales it by 8 inside the optimizer. A finite, completed training update is substantially too small. Nonfused GradScaler unscales before optimizer.step and passes the same numerical reference.',
        'reproducer': repro('test_amp_clip_uses_unscaled_gradient[True]'),
        'root_cross_reference': artifact('/Users/bli/Playground/plato/evidence/2026-refresh/phase2c-root-amp-clipping-probe.json'),
        'root_default_scale_corrob': 'Actual ComposableTrainer, loss 10*w and scale 65536 gives 0.9999984502792358 instead of 0.900000009999999 on both versions. Root source/raw receipts independently hash-checked; reviewer separately constructed scale-8 reference.',
        'test_gap': 'Existing actual fused/nonfused overflow tests exercise skip counting but do not combine a finite AMP update with the public clipping wrapper.',
        'bounded_acceptance': 'Clipping must consume unscaled gradients for actual fused and nonfused AMP. Preserve real overflow skip/update counting and accumulation-tail behavior; numerical parameter-reference regression required.',
        'limits': 'Actual CPU fused/nonfused Torch execution. CPU injection leaves CUDA autocast disabled with the recorded warning; no CUDA execution claim.',
    },
    {
        'id': 'TRAINING-2C-01', 'severity': 'medium', 'status': 'OPEN_CONFIRMED',
        'title': 'Long logical names produce worker files that pause_training does not remove.',
        'locations': [{'path': 'plato/trainers/base.py', 'line': 87},
                      {'path': 'plato/trainers/base.py', 'line': 92},
                      {'path': 'plato/utils/checkpoint_paths.py', 'line': 32}],
        'trigger': 'Actual train_process and test_process with max_concurrency=1, model_name="x"*240, client 7 and the actual run PID, followed by pause_training.',
        'expected': 'Remove this worker/client/run model, history and evaluation artifacts, retaining unrelated owners and persistent files.',
        'actual_each_python': 'Accuracy file is removed, but three owned files remain: ~t<tuple_digest>.safetensors, its .pkl history and ~t<tuple_digest>.eval.pkl.',
        'cause_and_impact': 'pause_training encodes a suffixless name and later appends extensions. The writer encodes the complete name with its suffix; suffix length and the 251-byte primary/history limit can change whether the tuple is digested. Cleanup silently leaves potentially large temporary model files and private worker state.',
        'reproducer': repro('test_long_name_cleanup_matches_actual_writer'),
        'numerical_raw': {v: independent[v]['long_worker_cleanup'] for v in ('313', '314')},
        'test_gap': 'The long-name default save/load regression verifies successful file creation but does not call actual worker writers and cleanup. Short ordinary/slash-name cleanup passes.',
        'bounded_acceptance': 'Derive each cleanup artifact through the same complete logical-name/suffix contract as its writer; model history follows its actual primary filename. Verify long, ordinary and special names and unrelated-owner preservation. Preserve accepted B F10 cleanup ownership.',
    },
    {
        'id': 'TRAINING-2C-02', 'severity': 'medium', 'status': 'OPEN_CONFIRMED',
        'title': 'FedDyn legacy migration misses the actual accepted B filename.',
        'locations': [{'path': 'plato/trainers/strategies/algorithms/feddyn_strategy.py', 'line': 397}],
        'accepted_b_writer': {'commit': '00eeb9dcdd2b513e64db9408969356037e09bb8e',
                              'path': 'plato/trainers/strategies/algorithms/feddyn_strategy.py', 'line': 342,
                              'expression': 'f"{base_path}_feddyn_grad_{context.client_id}.pth"'},
        'trigger': 'Canonical state absent; recognized nonzero-client state written by accepted B exists at root + "_feddyn_grad_1.pth", with default or custom save root.',
        'expected': 'Read the same-client accepted B vector, preserve the original, prefer canonical state if present, and never adopt client 0.',
        'actual_each_python': {'expected_weight_vector': 7.0, 'loaded_weight_vector': 0.0,
                               'log': 'No previous gradient vector found. Initializing to zero for first round.'},
        'cause_and_impact': 'Fallback omits the underscore between root and feddyn_grad, so previously saved cumulative gradients are silently lost when continuing from accepted B. This is a filename/compatibility defect independent of the separately open FedDyn objective design.',
        'reproducer': repro('test_feddyn_reads_actual_accepted_b_writer'),
        'reference_independence': 'Reproducer obtains the exact accepted B source with git show, executes its writer class in memory, calls actual setup/on_train_start/on_train_end for context client 1, then passes its saved vector to candidate reader. No checkout/source/commit mutation.',
        'supplemental_raw': {v: independent[v]['feddyn_legacy_writer_to_reader'] for v in ('313', '314')},
        'test_gap': {'path': 'tests/trainers/test_personalized_state_ownership.py', 'line': 164,
                     'detail': 'Test handcrafts root + "feddyn_grad_1.pth", copying the new reader spelling rather than using accepted B writer output.'},
        'bounded_acceptance': 'Restore the exact accepted nonzero-client legacy spelling; retain canonical precedence, read-only original preservation, custom save_path and client-0 exclusion. Add actual old-writer/new-reader coverage without changing FedDyn equations.',
    },
    {
        'id': 'TRAINING-2C-03', 'severity': 'medium', 'status': 'OPEN_CONFIRMED',
        'title': 'FedALA loses returning logical-client state when disk persistence is disabled.',
        'locations': [{'path': 'plato/trainers/strategies/algorithms/fedala_strategy.py', 'line': 119},
                      {'path': 'plato/trainers/strategies/algorithms/fedala_strategy.py', 'line': 172},
                      {'path': 'plato/trainers/strategies/algorithms/fedala_strategy.py', 'line': 209}],
        'trigger': 'FedALAUpdateStrategy(save_state=False), physical trainer client 1 -> 2 -> 1, with client 1 trained before reassignment. The documented flag controls persistence to disk, not logical in-memory ownership.',
        'expected': 'Returning client 1 continues its own local model, learned ALA weights and start_phase. Given identical incoming model and data, its update matches a dedicated client-1 trainer.',
        'actual_each_python': behavior['313']['fedala_reassignment_numerical'],
        'cause_and_impact': 'Identity change clears local_model_state, weights and start_phase with no per-client memory cache; _load_state restores only when save_state=True. Returning client therefore takes first-round initialization, bypasses adaptive aggregation, and changes the next-round weights by up to 1.1351019144058228.',
        'reproducer': repro('test_fedala_return_matches_dedicated_client_without_disk_state'),
        'deterministic_fixture': 'Two-class linear parameter [[1],[-1]], data x=[[1],[2]], labels=[1,1], SGD lr .1/momentum0, seed17, eta1/rand_percent100/max_ala_epochs2. Next incoming parameter [[2],[-1]] avoids the existing zero-sum ALA guard. All data/model/initialization equal between reused and dedicated references.',
        'reference_independence': 'Compare two actual trainer executions serving the same logical client, varying only intervening physical assignment. No hand-reimplementation of ALA equations.',
        'test_gap': 'Existing save_state=False worker coverage keeps the same client. Existing 1->2->1 FedALA ownership coverage uses default disk persistence, which hides the missing in-memory cache.',
        'bounded_acceptance': 'Keep and restore per-owner in-memory FedALA state when disk persistence is disabled, preserving cross-client isolation and successful worker returns. Dedicated-vs-reassigned numerical continuation must agree.',
    },
]

warnings = [
    {'count_each': 5, 'message': 'Secure RNG turned off', 'origin': 'opacus/privacy_engine.py:98',
     'classification': 'Intentional experimental policy notice',
     'assessment': 'Real Opacus is executed under its existing secure_mode=False experiment contract. No production privacy/security guarantee and no global security questionnaire introduced.'},
    {'count_each': 3, 'message': 'Optimal order is the largest alpha', 'origin': 'opacus/accountants/analysis/rdp.py:332',
     'classification': 'Visible numerical bound limitation',
     'assessment': 'This calibrator may yield a looser bound over its chosen alpha grid. Finite accounting and cumulative step preservation are qualified; optimal/tight epsilon is not claimed.'},
    {'count_each': 4, 'message': 'Full backward hook firing with respect to outputs because no inputs require gradients',
     'origin': 'plato/trainers/diff_privacy.py:332', 'classification': 'Expected supported Opacus hook behavior',
     'assessment': 'Training inputs are intentionally non-grad tensors. Actual per-sample gradient and parameter references pass; requiring data gradients just to silence this would alter the contract.'},
    {'count_each': 2, 'message': 'make_private_with_epsilon with non-zero privacy budget already spent',
     'origin': 'opacus/privacy_engine.py:576', 'classification': 'Intentional existing per-run calibration boundary',
     'assessment': 'C retains cumulative accountant history while calibrating the existing target per run. Overall repeated-run epsilon is not bounded by that per-run target. Global privacy-policy redesign is outside this review; warning stays visible.'},
    {'count_each': 3, 'message': 'PrivacyEngine detected new dataset object', 'origin': 'opacus/privacy_engine.py:156',
     'classification': 'Avoidable runtime identity warning', 'low_observation': 'TRAINING-LOW-01',
     'assessment': 'The executed reuse cases use the same logical dataset and indices; a fresh equivalent Subset is built each run. This is not evidence of incorrect accounting or a changed partition. Prefer stable logical Subset identity rather than broad suppression.'},
    {'count_each': 2, 'message': 'CUDA is not available or torch_xla is imported. Disabling autocast.',
     'origin': 'plato/trainers/strategies/training_step.py:235', 'classification': 'Avoidable CPU test/device warning',
     'low_observation': 'TRAINING-LOW-02',
     'assessment': 'Tests deliberately install a real CPU GradScaler but enter hardcoded CUDA autocast. CPU scaler skip behavior still executes; neither these tests nor this review qualify CUDA autocast. Normal auto-detected CPU path does not enable this strategy.'},
]
assert sum(x['count_each'] for x in warnings) == 19

contracts = [
    {'id': 'F07', 'status': 'PARTIAL_CHANGES_REQUIRED',
     'assessment': 'Shared component codec distinguishes org/model, org_model, literal digest-looking names and ordinary historical names. Actual default/worker/test/server/transport/personal/GAN/split/PORT writer-reader tests, custom roots, explicit normalized relative paths, canonical/recognized legacy precedence, sidecar containment, history roundtrip and device/mode paths executed. Overlong names save/load successfully but cleanup fails (TRAINING-2C-01). Historical FedDyn migration also fails (TRAINING-2C-02). Codec is cryptographic collision-resistant, not a promise of arbitrary-arity underscore tuple injectivity.'},
    {'id': 'F08', 'status': 'SUPPORTED_PATHS_VERIFIED_WITH_OPEN_COMPOSITION',
     'assessment': 'Independent float64 scalar reference for full windows, partial final window and shorter-than-window data; equal weighting of mean microbatch losses retained. Correct final normalization, no extra divisible update, idempotent finalize, fresh run gradients, actual optimizer/scheduler/model-update counts tested. Actual fused/nonfused GradScaler overflow skips tested; finite fused AMP clipping remains wrong (ROOT-2C-01).'},
    {'id': 'F14', 'status': 'NO_ADDITIONAL_FINDING_IN_TESTED_SCOPE',
     'assessment': 'Actual timm first 10 updates, local/global epoch-round offsets and completion-only counting exercised. Own real CosineLRScheduler matches closed-form .1*(1+cos(pi*u/100))/2 at round1 offsets1..6 and round3 offsets13..18. Actual timm state_dict/load_state_dict next updates7/19 agree. Public reference source checked. This qualifies scheduler counters/library continuation, not a new durable optimizer/RNG restart protocol.'},
    {'id': 'F20', 'status': 'NO_ADDITIONAL_FINDING_IN_TESTED_SCOPE',
     'assessment': 'Accepted unsquared L2 and L1 retained. Own origin gradients finite/zero, mu0 exact base, L2 offset[3,4] gives penalty .25 and gradient[.03,.04], L1 gives .7 and [.1,.1]. Shipped MNIST FedProx TOML actually selects plato.trainers.fedprox.Trainer, SGD and mu .1; two actual synthetic-data LeNet batches yield proximal penalties0/.0001201629638671875 and finite changed parameters. No MNIST download/accuracy benchmark claimed.'},
    {'id': 'F21', 'status': 'NO_ADDITIONAL_MATERIAL_FINDING_IN_TESTED_SCOPE',
     'assessment': 'Actual reusable Opacus runs and injected interruption finish with plain strict model keys, consistent model/context identity and no lingering grad hooks. Real calibrated counts4/8/9, exact save/load and changed training outputs independently checked. Successful spawned client1/1/2 ledgers4/8/4 and return1=8 tested by repository suite. Warnings classified separately; no global/durable killed-worker privacy guarantee.'},
    {'id': 'F22', 'status': 'NO_ADDITIONAL_FINDING_IN_TESTED_SCOPE',
     'assessment': 'Own manual per-sample clipped gradient reference with fixed samples/no noise and actual Opacus: physical caps2/4 both produce [[.3588939309120178],[-.1588939130306244]], exactly2 optimizer/accountant updates, flags[F,T,F,T]/[T,T]. Real calibrated trainer20 physical batches yields9 callbacks/base updates/accountant updates over reusable and interrupted runs. Physical observations remain separate from logical completion.'},
    {'id': 'F23', 'status': 'PARTIAL_CHANGES_REQUIRED',
     'assessment': 'Canonical nonzero-client paths, custom save roots, owner changes and successful child returns exercised for Ditto/APFL/FedDyn/FedALA; shared hook propagation through composite strategies reviewed. Own APFL scalar1->2->1 matches private weights1.74/1.152 and momentum1.3/2.94. SSL private head and DP ledgers isolate owners in tests. Two uncovered negative paths: actual B FedDyn legacy filename and FedALA save_state=False return (TRAINING-2C-02/03). Detailed SCAFFOLD control protocol excluded.'},
    {'id': 'F24', 'status': 'NO_ADDITIONAL_FINDING_IN_TESTED_SCOPE',
     'assessment': 'Own FedProx reference snapshots refresh from each incoming model, remain fixed within the run and give zero finite proximal loss at each new baseline. Actual two-run repository tests confirm the lifecycle.'},
    {'id': 'F25', 'status': 'NO_ADDITIONAL_FINDING_IN_TESTED_SCOPE',
     'assessment': 'Actual public split test path before any train call and empty partition execute in focused suite, including correct 0 result, restored context and retained training feature/gradient behavior.'},
    {'id': 'F26', 'status': 'NO_ADDITIONAL_FINDING_IN_TESTED_SCOPE',
     'assessment': 'Safetensors matching deserialize_tree strips metadata; numeric finish-time then epoch selection, same-client isolation, strict cutoff and no-eligible error exercised against actual ordinary/DP/GAN writers. Own urgent snapshots epochs9/10 with cutoff11 select weight10 on actual MPS:0, preserve eval mode/injected model architecture and leave current model unchanged.'},
    {'id': 'B_RUNTIME_PRESERVATION', 'status': 'NO_ADDITIONAL_FINDING_IN_TESTED_SCOPE',
     'assessment': 'Accepted B merged/ancestor confirmed before C shared-file changes. Client lifecycle/startup harness and profile fixture exact B identities unchanged; handed runtime edits inspected as naming/path coordination. Both PORT example writer and aggregation-strategy reader execute for safe and legacy checkpoints; independent dot-product similarity .6 and sample2/6 weighted delta reference passes without mutating current model/mode. Real socket round rerun each Python: clients1/2, samples2/6, weighted error1.49e-8, exit0/no survivors. Accepted F10 short-name cleanup passes, long-name variant remains open.'},
]

inventory = []
for item in author['additional_findings']:
    entry = {'id': item['id'], 'subject': item['subject']}
    if item['id'] == '2C-11':
        entry.update(status='OPEN_ROOT_DESIGN_REVIEW_EXCLUDED', assessment='Root owns primary-source FedDyn objective/alpha disposition; not duplicated or accepted here.')
    elif item['id'] == '2C-03':
        entry.update(status='PARTIAL_CHANGES_REQUIRED', assessment='Ordinary/tail clipping reference passes, finite fused AMP composition fails ROOT-2C-01.')
    elif item['id'] == '2C-12':
        entry.update(status='PARTIAL_CHANGES_REQUIRED', assessment='Actual successful spawned personalized state comparisons pass. Returning FedALA save_state=False owner is uncovered and fails TRAINING-2C-03.')
    elif item['id'] == '2C-18':
        entry.update(status='PARTIAL_CHANGES_REQUIRED', assessment='Overlong default save/load and history limit pass; actual worker cleanup mismatch TRAINING-2C-01 remains.')
    else:
        entry.update(status='NO_ADDITIONAL_FINDING_IN_TESTED_SCOPE', assessment='Source and corresponding focused regression/reference inspected and executed; bounded to the author inventory behavior, not whole research-algorithm certification.')
    inventory.append(entry)

report = {
    'review': 'Independent phase 2C general runtime/checkpoint/training review',
    'written_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'verdict': 'CHANGES_REQUIRED', 'findings_summary': {'critical': 0, 'high': 0, 'medium': 4, 'medium_new': 3, 'medium_root_cross_reference': 1, 'low_observations': 2},
    'conclusion': 'Four concrete medium defects remain in the assigned scope on the immutable candidate. Passing focused tests and valid author receipts do not establish phase C acceptance. Root retains reviewed-phase integration authority.',
    'candidate': {'path': str(candidate), 'requested_path': '/tmp/plato-refresh-worktrees/training',
                  'commit': audit['head'], 'tree': audit['tree'],
                  'implementation_commit': '0dc34dd1d79d90071a0babfa6aa89f33d72a976f',
                  'implementation_tree': git('rev-parse', '0dc34dd1d79d90071a0babfa6aa89f33d72a976f^{tree}'),
                  'accepted_b': '00eeb9dcdd2b513e64db9408969356037e09bb8e', 'accepted_b_is_ancestor_exit_code': identity['b_is_ancestor_exit'],
                  'implementation_to_candidate_delta': identity['implementation_delta'].splitlines(),
                  'clean_before': identity['status_porcelain'], 'clean_after': git('status', '--porcelain')},
    'scope': {
        'included': 'All C general runtime/checkpoint/training production changes relative to accepted B, mandatory F07/F08/F14/F20-F26 and all general author additional findings: GAN/DCGAN, SSL, optimizer/wrappers, loss tracking, model exchange, FedMos, personalization, APFL/Ditto/FedALA/FedDyn state ownership, PORT and shared B runtime naming/lifecycle preservation.',
        'excluded': ['Detailed SCAFFOLD equations and control-state worker protocol assigned to complementary reviewer.',
                     'FedDyn 2C-11 objective/label-alpha primary-source design disposition remains OPEN with root; this review reports only the independent FedDyn filename migration bug and checks the bounded zero-label finite fallback.',
                     'Optional HuggingFace/LeRobot/nanochat/smolVLA integrations and A/D/archive/docs scopes; no dependency/metadata broadening.'],
        'workspace_discipline': 'Read supplied isolated immutable training workspace and author/root logs/environments; all reviewer shell invocations zsh -lc, cwd/PYTHONPATH pinned to candidate for execution. No agents spawned. Wrote only own scratch plus this explicitly requested ROOT report. No source/commits/other worktrees/environment installation edits, cleanup or push.',
    },
    'findings': findings,
    'low_observations': [
        {'id': 'TRAINING-LOW-01', 'severity': 'low', 'status': 'RECORDED_AVOIDABLE_WARNING_NO_ACCOUNTING_FAILURE_PROVEN',
         'title': 'Recreating equivalent DP Subsets produces repeated dataset-identity warnings.',
         'location': {'path': 'plato/trainers/diff_privacy.py', 'line': 133},
         'evidence': '3 instances per focused run in consecutive/physical-split tests; own actual reuse probe reproduces same notice. Logical data/partition unchanged, independent parameter and accountant references pass.',
         'assessment': 'Stable equivalent dataset identity could avoid the notice; do not suppress genuinely changed-partition warnings. Recommendation is not elevated to a material accounting bug.'},
        {'id': 'TRAINING-LOW-02', 'severity': 'low', 'status': 'RECORDED_TEST_DEVICE_WARNING_AND_LIMITATION',
         'title': 'CPU GradScaler regression tests enter CUDA autocast.',
         'locations': [{'path': 'plato/trainers/strategies/training_step.py', 'line': 235},
                       {'path': 'tests/trainers/test_training_update_contract.py', 'line': 512}],
         'evidence': '2 instances per focused run, 2 per reviewer negative suite; root fresh base has the same 2 warnings on both versions.',
         'assessment': 'Useful real CPU overflow qualification executes, but the disabled autocast warning is avoidable test/device noise. No CUDA claim; no demonstrated failure of the ordinary auto-detected CPU runtime. A device-aware supported path or explicitly asserted expected warning would clarify coverage without blanket suppression.'},
    ],
    'warning_audit': {'author_count_each': 19, 'reviewer_focused_count_each': 19,
                      'classes': warnings, 'intentional_or_visible_contract_boundary_count_each': 14,
                      'avoidable_noise_count_each': 5,
                      'other_notices': 'Torch elastic import logs that redirects are unsupported on macOS; retained in raw logs, outside pytest warning totals. SCAFFOLD standalone-control/additive-optimizer notices belong to its selected extension contract and complementary review; no detailed protocol acceptance here.',
                      'suppression': 'No warning suppression, skipped assertions or altered source fixtures used.'},
    'mandatory_contracts': contracts,
    'additional_author_inventory_audit': inventory,
    'additional_source_assessment': {
        'GAN_model_exchange_runtime': 'DCGAN nn.Module registration/device/mode APIs and real G/D changes; owned CPU snapshot clones; bool/int delta behavior; combined Safetensors worker/urgent tree and history; existing Torch paired .pth/historical paired .safetensors fallback; normalized explicit companions rejected before writes; FID sampler/tail/rectangular padding and covariance sample boundary tested. Controlled feature/covariance references do not certify pretrained FID quality or full distributed GAN benchmarks.',
        'SSL': 'Instance constructor and explicit empty data preserved; train-reference/test-partition KNN boundaries and missing-reference errors tested. Canonical private-head owner/save/load/successful child return tested. Pure head training freezes encoder gradients/BN/dropout via eval/no_grad and restores per-module modes/flags on success and exceptions; no inference tensors reenter head autograd. Reexecuted actual Lightly multiview author smoke independently on both versions: finite loss .6038040518760681, encoder changed/head unchanged. This is an independent execution of author smoke, not a newly derived SSL loss equation reference.',
        'personalization_and_optimizer': 'FedPer/FedRep/LG previous requires_grad flags restored including exceptions/frozen parameters. LG two actual updates dispatch and follow actual scheduler; independent parameter/LR reference in executed tests. FedMos identity pairing distinguishes same-shaped parameters; retained legacy values5.95/11.45. Tracking records detached numerical weighted averages, no retained graph. Validation wrapper delegates chosen step strategy and validates before real/tail updates. APFL trusted historical NumPy alpha allowlist scoped/new primitive float, in-memory private momentum continuation independently derived. No durable private optimizer momentum restart protocol claimed.',
    },
    'independent_references': {'primary_library_sources': primary,
                               'methods': ['Closed-form scalar SGD accumulation/tail and FedProx norm derivatives.',
                                           'Actual old B writer output compared with C reader, rather than copying C filename.',
                                           'Dedicated logical-client execution versus physical reassignment; scalar APFL momentum recurrence.',
                                           'Manual per-sample clipping averaged over fixed logical samples, actual Opacus optimizer/accountant and alternate physical caps.',
                                           'Real timm cosine scheduler compared with closed-form cosine and library saved-state next update.',
                                           'Actual process socket results compared numerically with sample-weighted aggregation; no leftover process assertions skipped.']},
    'reviewer_executions': audit['executions'] + [read('final-evidence-audit-r2.json')],
    'reviewer_results': {'focused': {'313': '372 passed, 19 warnings in 86.85s', '314': '372 passed, 19 warnings in 126.79s'},
                         'negative': {'313': '4 failed, 1 passed, 2 warnings in 3.89s; exit 1', '314': '4 failed, 1 passed, 2 warnings in 4.11s; exit 1'},
                         'socket': audit['socket'],
                         'behavior': behavior,
                         'independent_numeric': {v: {k: d for k, d in independent[v].items() if k != 'identity'} for v in ('313', '314')},
                         'probe_exit_interpretation': 'Value-reporting independent.py exits0 while printing observed defects; negative pytest explicitly asserts intended behavior and exits1. run.py outer wrapper itself exits0; execution receipts contain actual inner exit codes, used throughout this report.'},
    'reviewer_harness_construction_attempts': [
        {'commands': {v: f'PYTHONDONTWRITEBYTECODE=1 PYTHONPATH={candidate} OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /tmp/plato-phase2c-{v}/bin/python {scratch}/independent.py' for v in ('313', '314')},
         'exit_each': 1, 'cause': 'Reviewer first probe forgot to create an isolated runtime_root before configure_environment; FileNotFoundError, not a candidate finding. Fixed scratch only and reran with r2 receipt labels.',
         'raw': [artifact(scratch / f'independent-{v}.log') for v in ('313', '314')]},
        {'commands': {v: f'PYTHONDONTWRITEBYTECODE=1 PYTHONPATH={candidate} OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /tmp/plato-phase2c-{v}/bin/python {scratch}/behavior.py' for v in ('313', '314')},
         'exit_each': 1, 'cause': 'Reviewer symmetric [2,-2] incoming FedALA fixture hit the existing zero-sum ALA guard, so initial numerical-difference assertion was unsuitable. Retained behavior-initial.py; changed only reviewer fixture to [2,-1] and used fresh r2 runtime directories. No production assertion waived.',
         'original_source': artifact(scratch / 'behavior-initial.py'),
         'raw': [artifact(scratch / f'behavior-{v}.log') for v in ('313', '314')]},
    ],
    'author_and_root_evidence_audited_not_claimed_as_reviewer_reruns': {
        'author_combined': author['validation']['final_combined'] if 'validation' in author else read('validation.json')['final_combined'],
        'author_raw_receipt_audit': {'checked_receipts': len(read('all-author-hash-checks.json')), 'mismatches': sum(not x['match'] for x in read('all-author-hash-checks.json')),
                                     'artifact': artifact(scratch / 'all-author-hash-checks.json')},
        'startup': {'author_results': read('startup-evidence-audit.json'),
                    'reason_not_rerun_all48_each': 'All 48 raw startup cases per Python and hashes audited (43 natural/5 expected forced, no survivors), accepted B startup/harness identities unchanged and C change concerns names/checkpoints. Own actual two-client socket case rerun each version. No skipped startup assertion or broad runtime waiver.'},
        'root_amp': read('root-receipt-phase2c-root-amp-clipping-probe.json'),
        'root_base': read('root-receipt-phase2c-root-base-validation.json'),
        'root_raw_hash_checks': audit['root_raw_receipts'],
    },
    'environment_and_limits': {
        '313': independent['313']['identity'], '314': independent['314']['identity'],
        'existing_environments': ['/tmp/plato-phase2c-313', '/tmp/plato-phase2c-314', '/tmp/plato-phase2c-ssl', '/tmp/plato-phase2c-ssl314'],
        'optional_execution': 'Actual Opacus1.6.0 and Lightly1.5.26 used; no installation/sync/environment modification by reviewer. PYTHONDONTWRITEBYTECODE and no pytest cache, all runtime outputs own scratch.',
        'platform': 'macOS arm64 CPU; actual MPS urgent-reader probe. CUDA unavailable; no CUDA/Linux/multi-host/full mandatory optional-stack execution claim.',
        'qualification_boundary': 'General C behavior and accepted B preservation in focused scope. No full paper-equation certification, global privacy-budget guarantee, durable killed-worker accountant/private optimizer restart, pretrained GAN quality, optional integrations or whole-repository phase acceptance.',
        'open_complementary_work': 'Root FedDyn2C-11 primary-source design remains open; detailed SCAFFOLD/F27 review and standalone prose handled elsewhere. These are not waived or accepted by this report.',
    },
    'input_hashes': audit['inputs'] + [artifact('/Users/bli/Playground/plato/evidence/2026-refresh/fedprox-gradient-probe.json')], 'candidate_changed_files_sha256': audit['candidate_changed_files_sha256'],
    'accepted_b_unchanged_source_hashes': identity,
    'retained_scratch': str(scratch),
    'retained_review_artifacts': [artifact(scratch / p) for p in ('review_regressions.py', 'independent.py', 'behavior.py', 'audit_receipts.py', 'run.py', 'candidate-vs-b.diff', 'receipt-checks.json', 'final-evidence-details.json', 'startup-evidence-audit.json', 'independent-313.json', 'independent-314.json', 'behavior-313-r2.json', 'behavior-314-r2.json')],
}
assert report['candidate']['clean_after'] == ''
assert len(findings) == 4 and all(x['severity'] == 'medium' for x in findings)
assert report['author_and_root_evidence_audited_not_claimed_as_reviewer_reruns']['author_raw_receipt_audit']['mismatches'] == 0
destination.write_text(json.dumps(report, indent=2) + '\n')
assert git('rev-parse', 'HEAD') == report['candidate']['commit'] and git('status', '--porcelain') == ''
print(json.dumps({'path': str(destination), 'sha256': artifact(destination)['sha256'],
                  'verdict': report['verdict'], 'findings': len(findings),
                  'candidate_status': git('status', '--porcelain'), 'bytes': destination.stat().st_size}))
