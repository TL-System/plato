import hashlib
import json
import platform
import subprocess
from pathlib import Path

scratch=Path('/tmp/plato-phase2a-review')
repo=Path('/private/tmp/plato-refresh-worktrees/data')
destination=Path('/Users/bli/Playground/plato/evidence/2026-refresh/phase2a-review.json')
audit=json.loads((scratch/'audit-evidence.json').read_text())
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def location(path,start,end=None):return {'path':path,'line_start':start,'line_end':end or start}
env='OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=.'
def command(script,argument,version='{python}'):
    return f"zsh -lc 'cd /tmp/plato-phase2a-review/candidate && {env} /tmp/plato-phase2a-review/venv-{version}/bin/python /tmp/plato-phase2a-review/{script} {argument}'"
findings=[
    {
        'id':'R2A-01','severity':'medium','status':'open',
        'title':'Valid cross-silo edge evaluation IDs are rejected by the new base sampler check.',
        'locations':[location('plato/samplers/base.py',17,21),location('plato/samplers/dirichlet.py',18),location('plato/servers/fedavg_cs.py',129,140)],
        'trigger':'An existing cross-silo edge server enables server.edge_do_test and data.testset_sampler="noniid". Its ID is total_clients + silo_number, as assigned by the existing runtime.',
        'actual':'The candidate raises ValueError: client_id must be between 1 and 3 for the valid first edge ID 4. The exact baseline Dirichlet implementation configures and emits 600 test indices through the same fedavg_cs.Server.configure branch.',
        'impact':'The new shared ID validation disables an existing edge-evaluation path before training starts. Tests currently classify every total_clients+1 ID as invalid without checking the cross-silo role.',
        'reproduction':{
            'command':command('edge_sampler_probe.py','/tmp/plato-phase2a-review/repro-edge-{python}'),
            'interpreters':['3.13.16','3.14.8'],
            'method':'Load the real configs/MNIST/fedavg_cross_silo_lenet5.toml with --id 4 --port 8101 and an owned base path; enable edge_do_test and noniid evaluation. Invoke the actual edge configure branch with 1000 local labeled examples and inert trainer/processor setup. Swap only the registered Dirichlet class for a base/candidate comparison.',
            'qualification':'This exercises actual configure and sampler behavior with injected setup dependencies; it is not a socket round or training qualification.',
            'logs':['/tmp/plato-phase2a-review/edge_sampler-3.13.json','/tmp/plato-phase2a-review/edge_sampler-3.14.json'],
        },
        'requested_fix':'Make validation aware of the existing edge-evaluation ID contract, or coordinate a narrow caller-to-sampler ID mapping that preserves existing evaluation semantics. Retain rejection of truly invalid ordinary client IDs and add a focused real-branch regression. Do not broadly permit every out-of-range ID.',
    },
    {
        'id':'R2A-02','severity':'medium','status':'open',
        'title':'Purchase/Texas cache readers bypass a live writer lock and permanently trust interrupted NPZ writes.',
        'locations':[location('plato/datasources/purchase.py',26,29),location('plato/datasources/purchase.py',41,55),location('plato/datasources/texas.py',27,30),location('plato/datasources/texas.py',42,53)],
        'trigger':'One client builds the NPZ cache while another client initializes against the same data root, or the writer dies after opening the final cache filename.',
        'actual':'The constructor sees the final cache pathname, skips download_dataset and its lock, then np.load raises BadZipFile while the real writer still holds flock. Killing the writer at that point leaves the same failure on the next initialization despite complete local raw data. After allowing the live writer to finish, the same reader loads the two examples successfully.',
        'impact':'The new download lock does not serialize consumers of the cache being produced. Concurrent startup can fail, and an interrupted cache cannot recover through the existing raw-data preprocessing path.',
        'reproduction':{
            'command':command('cache_writer_probe.py','/tmp/plato-phase2a-review/repro-cache-{python}'),
            'interpreters':['3.13.16','3.14.8'],
            'method':'A child calls the actual Purchase/Texas constructor with complete two-row raw files. A file wrapper pauses the real np.savez after its first ZIP header write while production holds the download lock. The parent initializes another actual datasource, then either releases or kills the child. No production source is patched.',
            'logs':['/tmp/plato-phase2a-review/cache_writer-3.13.json','/tmp/plato-phase2a-review/cache_writer-3.14.json'],
        },
        'requested_fix':'Publish NPZ caches atomically after successful construction and ensure initialization waits for preparation or validates/rebuilds an incomplete existing cache under the existing guard. Preserve valid cache-only and raw-only offline reuse. Add concurrent-reader and killed-writer regressions for both datasets.',
    },
    {
        'id':'R2A-03','severity':'medium','status':'open',
        'title':'An incomplete native Tiny ImageNet tree is silently interpreted as a prepared labeled test tree.',
        'locations':[location('plato/datasources/tiny_imagenet.py',62,68),location('plato/datasources/tiny_imagenet.py',81,85),location('plato/datasources/tiny_imagenet.py',109,112)],
        'trigger':'A direct native Tiny ImageNet root has train/<wnid>/images and the official unlabeled test/images directory, but its val_annotations.txt is missing, as in an incomplete local tree.',
        'actual':'prepared becomes true solely because train and test directories exist. No recovery is attempted. ImageFolder(test) creates the class ["images"] and targets [0], while training classes are ["n001", "n002"].',
        'impact':'Evaluation silently uses fabricated class-zero labels for unlabeled official test images. The new native/prepared selection does not reliably distinguish the two supported layouts.',
        'reproduction':{
            'command':command('risk_probes.py','/tmp/plato-phase2a-review/repro-risks-{python}'),
            'interpreters':['3.13.16','3.14.8'],
            'case':'native_tiny_missing_annotations',
            'method':'Create local PNGs under train/n001/images, train/n002/images and test/images, omit validation annotations, then invoke the actual Tiny ImageNet datasource.',
            'logs':['/tmp/plato-phase2a-review/risks-3.13.json','/tmp/plato-phase2a-review/risks-3.14.json'],
            'log_format':'These raw outputs include the base downloader progress lines before the JSON array.',
        },
        'requested_fix':'Validate that a prepared test tree contains labeled class directories compatible with training classes. Recognize the official unlabeled test/images layout even when validation annotations are absent; recover missing native data or reject the incomplete layout clearly. Retain correctly prepared labeled train/test support and add the missing-annotation regression.',
    },
    {
        'id':'R2A-04','severity':'medium','status':'open',
        'title':'Completion-marker fast paths prevent recovery after extracted dataset artifacts become incomplete.',
        'locations':[location('plato/datasources/base.py',80,85),location('plato/datasources/cinic10.py',25,36),location('plato/datasources/tiny_imagenet.py',68,85)],
        'trigger':'A root contains a previous successful download marker but is missing required extracted data, such as CINIC test/ or Tiny ImageNet val_annotations.txt.',
        'actual':'The changed constructors detect the missing root artifacts and call download, but both completion-marker checks return without restoring them. CINIC raises FileNotFoundError for test/; Tiny ImageNet raises FileNotFoundError for val_annotations.txt. Both markers remain present.',
        'impact':'Incomplete-root recovery only works before a marker has been written. An inconsistent existing cache remains unusable even when the configured archive is available locally or over a working server.',
        'reproduction':{
            'command':command('risk_probes.py','/tmp/plato-phase2a-review/repro-risks-{python}'),
            'interpreters':['3.13.16','3.14.8'],
            'case':'incomplete_extracted_tree_with_completion_marker',
            'method':'Use an actual localhost ZIP download to produce each complete dataset and its marker. Remove the CINIC test directory or Tiny ImageNet validation annotation, keep the server available, and instantiate the actual datasource.',
            'logs':['/tmp/plato-phase2a-review/risks-3.13.json','/tmp/plato-phase2a-review/risks-3.14.json'],
            'log_format':'Raw downloader progress precedes the JSON array.',
        },
        'requested_fix':'Allow callers that have established incomplete extracted data to invalidate/bypass the completion marker under the existing lock and retry extraction/download. A valid completed dataset must still skip network access. Add actual-download recovery regressions with stale markers; do not simply weaken the completeness checks.',
        'baseline_disposition':'The generic marker shortcut predates this candidate; it remains a demonstrated in-scope gap in the candidate incomplete-root repair rather than a claim that the shortcut itself was newly introduced.',
    },
]

sampler_summaries={version:{'cases':summary['executed_cases'],
                          'unchanged_seeded_cases':len(summary['unchanged_seeded_membership']),
                          'fixed_base_failures':len(summary['base_failures_fixed']),
                          'intentional_anchor_pool_changes':len(summary['changed_seeded_membership'])}
                   for version,summary in audit['sampler_comparison'].items()}
focus_nodes='tests/test_config_loader.py tests/samplers tests/datasources/test_registry.py tests/datasources/test_torchvision_datasource.py tests/datasources/test_feature_dataset.py tests/datasources/test_feature_datasource.py tests/datasources/test_data_loaders.py tests/datasources/test_download_contracts.py tests/datasources/test_local_datasets.py tests/utils/test_archive.py'
report={
    'schema_version':1,'date':'2026-10-02','task':'Independent exact-commit Phase 2A review',
    'verdict':'CHANGES_REQUESTED','severity_counts':{'critical':0,'high':0,'medium':4,'low':0},
    'summary':'F13/F15/F16, ordinary sampler compatibility, local native dataset selection, extraction containment and datalib preservation pass the scoped checks. Four material gaps remain: valid edge evaluation IDs, concurrent/interrupted NPZ publication, unlabeled Tiny ImageNet layout classification, and stale completion-marker recovery.',
    'identity':{key:audit[key] for key in ['candidate','base','implementation','candidate_tree','implementation_tree','candidate_binary_diff_sha256','implementation_binary_diff_sha256','evidence_only_child']},
    'inputs_read':[
        '/Users/bli/Playground/plato/AGENTS.md',
        '/private/tmp/plato-refresh-worktrees/data/AGENTS.md',
        '/private/tmp/plato-refresh-worktrees/data/evidence/2026-refresh/plan.md',
        '/private/tmp/plato-refresh-worktrees/data/evidence/2026-refresh/plan-addendum.json',
        '/private/tmp/plato-refresh-worktrees/data/evidence/2026-refresh/phase2a-validation.json',
    ],
    'input_hashes':{str(path.relative_to(repo)):digest(path) for path in [repo/'AGENTS.md',repo/'evidence/2026-refresh/plan.md',repo/'evidence/2026-refresh/plan-addendum.json',repo/'evidence/2026-refresh/phase2a-validation.json']},
    'scope':{
        'reviewed':'Entire base-to-candidate implementation/test/archive diff, config include/CLI lifecycle and sampler/dataset callers relevant to the changes.',
        'candidate_read_only':True,'candidate_status_before':'','candidate_status_after':'',
        'nested_agents':0,'commits_pushes_pr_edits':0,
        'authorized_writes':'Owned /tmp/plato-phase2a-review plus this root review JSON only.',
        'excluded':'Accepted Phase 1 package/design choices; future MLX/HuggingFace/robotics/ViT work; combined full validation and the unrelated socket matrix; authentication/protocol redesign.',
    },
    'environment':{
        'platform':platform.platform(),
        'python':{'3.13':'3.13.16 (uv managed)','3.14':'3.14.8 (Homebrew)'},
        'independent_environments':['/tmp/plato-phase2a-review/venv-3.13','/tmp/plato-phase2a-review/venv-3.14'],
        'provision_command':"zsh -lc 'UV_PROJECT_ENVIRONMENT=/tmp/plato-phase2a-review/venv-{python} uv sync --locked --group dev --extra ssl --python {python} --project /tmp/plato-phase2a-review/candidate'",
        'source_copy':'git archive of the exact candidate into owned scratch; original worktree and author environments were read only.',
        'versions':audit['environment'],'metadata_sha256':audit['metadata_sha256'],
        'cpu_environment':env,'shell':'Every shell command used zsh -lc.',
    },
    'findings':findings,
    'independent_validation':[
        {'check':'Focused author suite in independently provisioned exact-candidate environments',
         'command':f"zsh -lc 'cd /tmp/plato-phase2a-review/candidate && {env} /tmp/plato-phase2a-review/venv-{{python}}/bin/python -m pytest {focus_nodes} -q -o cache_dir=/tmp/plato-phase2a-review/pytest-cache-{{python}} --basetemp=/tmp/plato-phase2a-review/pytest-{{python}}'",
         'results':{'3.13':{'passed':150,'failed':0,'skipped':0,'warnings':0,'seconds':4.19},'3.14':{'passed':150,'failed':0,'skipped':0,'warnings':0,'seconds':39.73}},
         'logs':['/tmp/plato-phase2a-review/focused-3.13.log','/tmp/plato-phase2a-review/focused-3.14.log']},
        {'check':'F13 fixture-free repeated actual Config loads with relative includes and CLI overrides',
         'command':command('config_probe.py','/tmp/plato-phase2a-review/repro-config-{python}'),
         'result':'16 transitions per interpreter pass: public/legacy resets, present/absent/repeated optional sections, base path, client ID, server/port overrides and result defaults. No pytest fixture runs between loads.',
         'logs':['/tmp/plato-phase2a-review/config-3.13.json','/tmp/plato-phase2a-review/config-3.14.json']},
        {'check':'F15 realized partition counts, private/caller RNG and actual DataLoader membership',
         'command':command('dirichlet_probe.py','unused'),
         'result':'Four cases per interpreter (uniform/normal, clients 1/2) match independently computed first-draw sizes 9/14/14/11. 100 count queries per case preserve private/global NumPy and Torch state; loader/order/reconstruction agree.',
         'logs':['/tmp/plato-phase2a-review/dirichlet-3.13.json','/tmp/plato-phase2a-review/dirichlet-3.14.json']},
        {'check':'F16 actual empty IID in a bounded fresh subprocess',
         'command':command('iid_probe.py','unused'),
         'result':'Both interpreters return useful ValueError within the five-second deadline. The focused suite additionally exercises padded nonempty golden membership.',
         'logs':['/tmp/plato-phase2a-review/iid-3.13.json','/tmp/plato-phase2a-review/iid-3.14.json']},
        {'check':'All 11 registered sampler count/membership/determinism and caller RNG contracts',
         'command':command('sampler_probe.py','candidate'),
         'baseline_comparison_command':command('sampler_probe.py','base'),
         'results':sampler_summaries,
         'qualification':'Each interpreter executes all 11 samplers for train/test and clients 1/2/3. Sample samplers match actual DataLoader counts/order and bounds; modality masks match modality_size and allowed names. All candidate construction and iteration preserve NumPy/Python/Torch caller RNG and reconstruct deterministically. 54 ordinary cases have identical base/candidate indices; six no-anchor baseline failures are repaired and six mixed-anchor cases change as required by the demonstrated pool bug. Baseline all-inclusive comparison explicitly seeds ambient Python RNG to the configured seed; its previous ambient-RNG dependence is intentionally repaired.',
         'logs':['/tmp/plato-phase2a-review/samplers-candidate-3.13.json','/tmp/plato-phase2a-review/samplers-candidate-3.14.json','/tmp/plato-phase2a-review/samplers-base-3.13.json','/tmp/plato-phase2a-review/samplers-base-3.14.json']},
        {'check':'Native local MNIST/FashionMNIST/EMNIST and Tiny ImageNet selection',
         'result':'Focused suite independently executes real raw IDX datasets with distinct train/test and variant labels; EMNIST balanced/digits train flags, labels and counts pass. Native Tiny ImageNet nested/direct validation annotations map to training class IDs; normal prepared labeled directories pass. R2A-03 covers the additional incomplete-layout gap.',
         'qualification':'Locally synthesized dataset files read by actual torchvision/datasource code, not full downloaded corpora or training evidence.'},
        {'check':'Actual TAR/ZIP extraction containment and lock ownership',
         'result':'Both interpreters pass actual localhost base TAR/ZIP and local Purchase/Texas archive entrypoint tests for traversal, absolute names, TAR symlink/hardlink escapes, preexisting directory/file symlinks, archive/artifact symlinks, safe extraction, safe internal TAR links, manifest preflight and no completion/cache after rejection. Additional normalized nested/./link TAR/ZIP probes reject before the first write and preserve outside content. Dead-owner recovery, live-owner exclusion, interrupted HTTP response cleanup and bounded failures pass.',
         'logs':['/tmp/plato-phase2a-review/focused-3.13.log','/tmp/plato-phase2a-review/focused-3.14.log','/tmp/plato-phase2a-review/risks-3.13.json','/tmp/plato-phase2a-review/risks-3.14.json'],
         'qualification':'macOS POSIX flock only; the destination is not concurrently modified by an unrelated writer. NPZ consumers are separately covered by R2A-02.'},
        {'check':'Eight actual SSL config transform probes per interpreter',
         'command':command('ssl_probe.py','/tmp/plato-phase2a-review/repro-ssl-{python}').replace(env,env+' LIGHTLY_DID_VERSION_CHECK=True'),
         'result':'8/8 independently pass on both interpreters: simclr, simsiam, byol, fedema, mocov2, smog, swav and calibre. SwaV has eight finite (3,32,32) tensors; each other config has two.',
         'logs':['/tmp/plato-phase2a-review/ssl-3.13.json','/tmp/plato-phase2a-review/ssl-3.14.json'],
         'qualification':'Actual constructors and tensor transforms on local images; no SSL training, accelerator or full-dataset claim. Only the background Lightly version check is disabled.'},
    ],
    'author_evidence_review':{
        'raw_root':'/tmp/plato-phase2a-lZqbqj',
        'inspected':'Validation JSON, raw initial and corrected red failures, staged additional red log summaries, final 150-test green logs, SSL probe code and both eight-config outputs, archive preservation/closure/provenance and REFER defect records.',
        'verified_counts':'Final author green logs report 150 passed / zero failures or skips on each interpreter (2.43s / 37.68s). Actual SSL logs contain all eight finite-output config probes per interpreter.',
        'red_qualification':'Initial 43-failure red includes an invalid IID object() harness, and is not accepted as actual hang evidence. Corrected red-iid logs use object.__new__(Config) and show real five-second timeouts on both interpreters. Initial F13/F15 red shows stale sections and changing counts; EMNIST red shows reused training labels. Additional red logs explicitly represent intermediate owned source states, not one pristine baseline run.',
        'independence_limit':'Raw staged source states were not all separately reconstructed; the final exact candidate was independently executed. Recorded source hashes/trees and the implementation binary diff hash match independent Git inspection.',
        'raw_log_hash_inventory':'/tmp/plato-phase2a-review/audit-evidence.json',
    },
    'archive_review':{
        'result':'PASS','original_files':14,'byte_for_byte_preserved':True,
        'old_to_new':'plato/datasources/datalib/<relative-path> -> archives/legacy_datalib/<relative-path>',
        'license':'Apache-2.0 LICENSE exactly matches the baseline repository license.',
        'license_sha256':audit['archive_license_sha256'],
        'provenance':'README records the full baseline SHA, path reconstruction, git history/authors, historical dependency/data limits and preserved REFER failures; inspected Git history supports named authors.',
        'closure':'Independent rg scan of active plato/examples/configs/tests/docs/pyproject/.github found no old datalib or new archive imports/callers. Wheel package selection remains packages=["plato"], so the archive is outside the active package. Shared archive index/build/typing disposition stays with later root owners.',
        'manifest':audit['archive_files'],
        'historical_status':'REFER filtering defects remain explicitly archived and unfixed; no historical multimodal support claim.',
    },
    'limitations':[
        'macOS ARM64 CPU only. Linux and combined full validation remain root acceptance work; Windows flock behavior is unqualified.',
        'No external dataset download or end-to-end training was performed. Archive HTTP probes use localhost and local artifacts; IDX/PNG/vector tests use bounded synthesized fixtures.',
        'The cross-silo regression probe invokes the actual configure branch with inert setup dependencies. It establishes the sampler regression, not full edge orchestration support.',
        'No unrelated eight-minute socket matrix, accepted Phase 1 package/design re-review, future adapter/MLX/robotics/ViT campaign, or auth/protocol redesign was performed.',
        'Archive containment retains the implementation assumption of no unrelated concurrent destination mutation and does not promise rollback after corrupt-data/filesystem errors.',
        'An initial owned edge probe imported runtime modules before setting Config argv and failed argument parsing. Corrected results use the real config before imports; the initial harness failure is retained in edge-3.13.stderr and edge-3.14.stderr and is not a finding.',
    ],
    'retained_resources':{
        'scratch_root':str(scratch),'retain_until':'Root acceptance',
        'contents':'Exact candidate snapshot, baseline sampler sources, two independent locked SSL/dev environments, raw outputs, probe scripts, archive/content hashes and review writer.',
        'owned_processes':'All launched child processes, HTTP workers and command sessions completed or were explicitly joined/killed. No intentionally retained running process.',
        'review_output':str(destination),
    },
    'acceptance':'Resolve the four medium findings with production fixes and focused regressions, then obtain exact-commit re-review. Current candidate cannot receive PASS.',
}
status=subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not status and head==audit['candidate']
assert all(json.loads((scratch/f'ssl-{version}.json').read_text())[i]['finite'] for version in ['3.13','3.14'] for i in range(8))
assert not destination.exists(), 'Do not overwrite an existing independent review.'
destination.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'path':str(destination),'verdict':report['verdict'],
                  'findings':len(findings),'sha256':digest(destination)},indent=2))
