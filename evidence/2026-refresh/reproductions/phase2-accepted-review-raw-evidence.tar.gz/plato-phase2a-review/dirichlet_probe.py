import json
import sys
import numpy as np
import torch
from torch.utils.data import DataLoader
from plato.config import Config
from plato.samplers.dirichlet import Sampler
Config._instance=object.__new__(Config)
Config.clients=Config.node_from_dict({'total_clients':2})
Config.data=Config.node_from_dict({'random_seed':31,'partition_size':16,'concentration':1.0})
class Dataset:
    targets=[0,1,2,3]*20
    def __len__(self):return len(self.targets)
    def __getitem__(self,i):return i,self.targets[i]
class Source:
    def get_train_set(self):return Dataset()
    def classes(self):return [0,1,2,3]
    def targets(self):return Dataset.targets
def eq(a,b):return a[0]==b[0] and np.array_equal(a[1],b[1]) and a[2:]==b[2:]
results=[]
for distribution in ['uniform','normal']:
    for client_id in [1,2]:
        Config.data.partition_distribution=Config.node_from_dict({'distribution':distribution,'low':0.4,
                                                                 'high':1.2 if distribution=='uniform' else 0.2,'mean':1.0})
        caller=np.random.get_state()
        torch_state=torch.get_rng_state()
        sampler=Sampler(Source(),client_id,False)
        private=sampler.rng.get_state()
        reference=np.random.RandomState(31*client_id)
        reference.dirichlet([1.0]*4)
        scale=reference.uniform(0.4,1.2) if distribution=='uniform' else reference.normal(1.0,0.2)
        expected=int(16*scale)
        assert all(sampler.num_samples()==expected for _ in range(100))
        assert eq(private,sampler.rng.get_state())
        assert eq(caller,np.random.get_state()) and torch.equal(torch_state,torch.get_rng_state())
        indices=list(sampler.get())
        loaded=[int(i) for batch,_ in DataLoader(Dataset(),sampler=sampler.get(),batch_size=3) for i in batch]
        assert indices==loaded and len(indices)==len(set(indices))==expected
        assert list(Sampler(Source(),client_id,False).get())==indices
        results.append({'distribution':distribution,'client_id':client_id,'count':expected,'queries':100,
                        'private_and_caller_rng_preserved':True,'loader_matches':True,'reconstruction_matches':True})
print(json.dumps(results,indent=2))
