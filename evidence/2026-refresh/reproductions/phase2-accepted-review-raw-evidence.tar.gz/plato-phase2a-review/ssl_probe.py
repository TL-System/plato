import json
import sys
from pathlib import Path
import torch
from PIL import Image
from plato.config import Config
from plato.datasources.self_supervised_learning import get_transforms
root=Path(sys.argv[1])
results=[]
for name in ['simclr','simsiam','byol','fedema','mocov2','smog','swav','calibre']:
    config=Path('examples/ssl/configs')/(name+'_CIFAR10_resnet18.toml')
    Config.reset()
    sys.argv=['ssl-review','-c',str(config),'--base',str(root/name)]
    Config()
    transform=get_transforms()['train_transform']
    torch.manual_seed(19)
    views=transform(Image.new('RGB',(64,64),(20,50,90)))
    assert len(views)==(8 if name=='swav' else 2)
    assert all(tuple(view.shape)==(3,32,32) and torch.isfinite(view).all() for view in views)
    results.append({'config':str(config),'transform':type(transform).__name__,
                    'views':len(views),'shapes':[list(view.shape) for view in views],
                    'finite':True})
print(json.dumps(results,indent=2))
