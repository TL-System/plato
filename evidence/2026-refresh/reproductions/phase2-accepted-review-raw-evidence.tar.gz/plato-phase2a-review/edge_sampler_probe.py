"""Exercise the actual cross-silo edge configure branch with local data and inert dependencies."""
import importlib.util
import json
import sys
from pathlib import Path
from unittest.mock import patch
from plato.config import Config

root=Path(sys.argv[1])
sys.argv=['edge-probe','-c','configs/MNIST/fedavg_cross_silo_lenet5.toml',
          '--base',str(root),'-i','4','-p','8101']
Config.reset()
Config()
from plato.servers import fedavg, fedavg_cs
from plato.samplers import registry
assert Config.is_edge_server()
assert Config.args.id==Config.clients.total_clients+1
Config.server.edge_do_test=True
Config.data.testset_sampler='noniid'
Config.data.random_seed=12

class Dataset:
    targets=[0,1]*500
    def __len__(self):return len(self.targets)
class Source:
    def get_test_set(self):return Dataset()
    def classes(self):return ['zero','one']
class Trainer:
    def set_client_id(self,client_id):self.client_id=client_id

spec=importlib.util.spec_from_file_location('baseline_dirichlet','/tmp/plato-phase2a-review/plato/samplers/dirichlet.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
results=[]
for mode,cls in [('base',module.Sampler),('candidate',registry.registered_samplers['noniid'])]:
    server=object.__new__(fedavg_cs.Server)
    trainer=Trainer()
    server.init_trainer=lambda:None
    server.require_trainer=lambda:trainer
    with patch.object(fedavg.Server,'configure',lambda self:None), \
         patch.object(fedavg_cs.datasources_registry,'get',lambda **kwargs:Source()), \
         patch.object(fedavg_cs.processor_registry,'get',lambda *args,**kwargs:(None,None)), \
         patch.dict(registry.registered_samplers,{'noniid':cls}):
        try:
            server.configure()
            indices=list(server.testset_sampler.get())
            assert len(indices)==600
            outcome=f'configured {len(indices)} test samples'
        except Exception as exc:
            outcome=f'{type(exc).__name__}: {exc}'
        results.append({'mode':mode,'edge_id':Config.args.id,'physical_clients':Config.clients.total_clients,
                        'result':outcome})
print(json.dumps(results,indent=2))
