import json
import subprocess
import sys
script = '''
from plato.config import Config
from plato.samplers.iid import Sampler
Config._instance=object.__new__(Config)
Config.data=Config.node_from_dict({'partition_size':4,'random_seed':1})
Config.clients=Config.node_from_dict({'total_clients':2})
class Source:
    def get_train_set(self): return []
try: Sampler(Source(),1,False)
except ValueError as exc:
    assert 'empty' in str(exc).lower()
    print(str(exc))
else: raise AssertionError('empty IID accepted')
'''
child=subprocess.run([sys.executable,'-c',script],capture_output=True,text=True,timeout=5)
assert child.returncode==0,child.stderr
print(json.dumps({'returncode':child.returncode,'result':child.stdout.strip(),'deadline_seconds':5}))
