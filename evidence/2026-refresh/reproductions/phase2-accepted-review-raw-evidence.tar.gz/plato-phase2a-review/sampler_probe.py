"""All registered sampler contracts and ordinary base/candidate comparison."""
import json
import random
import sys

import numpy as np
import torch
from torch.utils.data import DataLoader
from plato.config import Config
import plato.samplers

mode = sys.argv[1]
if mode == 'base':
    plato.samplers.__path__ = ['/tmp/plato-phase2a-review/plato/samplers']
from plato.samplers import registry

Config._instance = object.__new__(Config)
Config.clients = Config.node_from_dict({'total_clients': 3})
Config.algorithm = Config.node_from_dict({'total_silos': 2})
Config.data = Config.node_from_dict({
    'random_seed': 12, 'partition_size': 8, 'min_partition_size': 4,
    'per_client_classes_size': 2, 'anchor_classes': [0, 1],
    'keep_anchor_classes_size': 1, 'consistent_clients': [0],
    'non_iid_clients': 1, 'testset_size': 11, 'sampler': 'iid',
})

class Dataset:
    def __init__(self, testing):
        self.targets = ([3, 2, 1, 0] if testing else [0, 1, 2, 3]) * 24
    def __len__(self): return len(self.targets)
    def __getitem__(self, i): return i, self.targets[i]
class Source:
    def __init__(self):
        self.trainset, self.testset = Dataset(False), Dataset(True)
    def classes(self): return ['a', 'b', 'c', 'd']
    def targets(self): return self.trainset.targets
    def get_train_set(self): return self.trainset
    def get_test_set(self): return self.testset
    def get_modality_name(self): return ['rgb', 'audio', 'flow']

def same_numpy(a, b):
    return a[0] == b[0] and np.array_equal(a[1], b[1]) and a[2:] == b[2:]

source = Source()
results = []
for name in registry.registered_samplers:
    for testing in [False, True]:
        for client_id in [1, 2, 3]:
            np.random.seed(777)
            random.seed(12)
            torch.manual_seed(777)
            before = (np.random.get_state(), random.getstate(), torch.get_rng_state())
            try:
                sampler = registry.get(source, client_id, testing=testing, sampler_type=name)
                indices = list(sampler.get())
                after = (np.random.get_state(), random.getstate(), torch.get_rng_state())
                preserved = same_numpy(before[0], after[0]) and before[1] == after[1] and torch.equal(before[2], after[2])
                if name.startswith('modality'):
                    count = sampler.modality_size()
                    assert count == len(indices)
                    assert set(indices) <= set(source.get_modality_name())
                else:
                    count = sampler.num_samples()
                    dataset = source.testset if testing else source.trainset
                    loaded = [int(i) for batch, _ in DataLoader(dataset, batch_size=7, sampler=sampler.get()) for i in batch]
                    assert len(indices) == count == len(loaded)
                    assert indices == loaded
                    assert all(0 <= int(i) < len(dataset) for i in indices)
                if mode == 'candidate':
                    assert preserved, (name, 'caller RNG changed')
                    repeated = registry.get(source, client_id, testing=testing, sampler_type=name)
                    assert list(repeated.get()) == indices
                results.append({'sampler': name, 'testing': testing, 'client_id': client_id,
                                'count': int(count), 'indices': [int(i) if isinstance(i, (int, np.integer)) else str(i) for i in indices],
                                'caller_rng_preserved': bool(preserved)})
            except Exception as exc:
                if mode == 'candidate': raise
                results.append({'sampler': name, 'testing': testing, 'client_id': client_id,
                                'base_error': f'{type(exc).__name__}: {exc}'})
print(json.dumps(results, indent=2))
