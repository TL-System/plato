import hashlib
import importlib.metadata
import json
import subprocess
from pathlib import Path

scratch=Path('/tmp/plato-phase2a-review')
repo=Path('/private/tmp/plato-refresh-worktrees/data')
base='fda60becedfa6236c11d415b87a868b52789a41e'
candidate='a7bfd3dcdf7aaf3ec3ca466a1b5f27efa58054eb'
implementation='53a60a7514b71e8098fe8c0f335547725d1e269e'
def git(*args): return subprocess.check_output(['git',*args],cwd=repo)
def sha(b): return hashlib.sha256(b).hexdigest()
paths=git('ls-tree','-r','--name-only',base,'plato/datasources/datalib').decode().splitlines()
preservation=[]
for old in paths:
    new=old.replace('plato/datasources/datalib/','archives/legacy_datalib/')
    original=git('show',base+':'+old)
    archived=git('show',candidate+':'+new)
    assert original==archived
    preservation.append({'old':old,'new':new,'sha256':sha(original),'bytes':len(original)})
assert len(preservation)==14
original_license=git('show',base+':LICENSE')
archive_license=git('show',candidate+':archives/legacy_datalib/LICENSE')
assert original_license==archive_license
samplers={}
for version in ['3.13','3.14']:
    current=json.loads((scratch/f'samplers-candidate-{version}.json').read_text())
    previous=json.loads((scratch/f'samplers-base-{version}.json').read_text())
    assert len(current)==66 and all(c['caller_rng_preserved'] for c in current)
    equal=[]; changed=[]; formerly_failed=[]
    for a,b in zip(current,previous):
        key=f"{a['sampler']}:{'test' if a['testing'] else 'train'}:client{a['client_id']}"
        if 'base_error' in b:
            formerly_failed.append({'case':key,'error':b['base_error']})
        elif a['indices']==b['indices'] and a['count']==b['count']:
            equal.append(key)
        else:
            changed.append({'case':key,'candidate_count':a['count'],'base_count':b['count']})
    samplers[version]={'executed_cases':len(current),'unchanged_seeded_membership':equal,
                      'changed_seeded_membership':changed,'base_failures_fixed':formerly_failed}
logs=Path('/tmp/plato-phase2a-lZqbqj')
raw_logs={}
for path in sorted(logs.glob('*.log')):
    content=path.read_bytes()
    text=content.decode(errors='replace')
    if path.name.startswith(('red-','green-delivery','ssl-smoke')):
        raw_logs[path.name]={'sha256':sha(content),'bytes':len(content),'tail':text.splitlines()[-3:]}
ssl={}
for version in ['3.13','3.14']:
    data=json.loads((logs/f'ssl-smoke-{version}.log').read_text())
    assert len(data)==8 and all(record['finite'] for record in data)
    ssl[version]=data
result={
    'candidate':candidate,'base':base,'implementation':implementation,
    'candidate_tree':git('rev-parse',candidate+'^{tree}').decode().strip(),
    'implementation_tree':git('rev-parse',implementation+'^{tree}').decode().strip(),
    'evidence_only_child':git('diff','--name-only',implementation,candidate).decode().splitlines(),
    'implementation_binary_diff_sha256':sha(git('diff','--binary',base,implementation)),
    'candidate_binary_diff_sha256':sha(git('diff','--binary',base,candidate)),
    'metadata_sha256':{name:sha((repo/name).read_bytes()) for name in ['pyproject.toml','uv.lock','.python-version']},
    'plan_sha256':sha((repo/'evidence/2026-refresh/plan.md').read_bytes()),
    'archive_files':preservation,'archive_license_sha256':sha(archive_license),
    'sampler_comparison':samplers,'author_raw_log_inventory':raw_logs,'author_ssl_results':ssl,
    'environment':{name:importlib.metadata.version(name) for name in ['numpy','torch','torchvision','scipy','requests','pytest','lightly']},
    'candidate_status':git('status','--porcelain').decode(),
}
(scratch/'audit-evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['archive_files','sampler_comparison','author_raw_log_inventory','author_ssl_results']},indent=2))
for version,summary in samplers.items():
    print(json.dumps({'version':version,'sampler_comparison':summary},indent=2))
