"""Independent bounded cache and extraction probes; no pytest fixtures."""
import io
import json
import os
import subprocess
import sys
import tarfile
import time
import zipfile
from pathlib import Path

from PIL import Image
from plato.config import Config
from plato.datasources import base, cinic10, purchase, texas, tiny_imagenet
from plato.utils.archive import extract_archive

root = Path(sys.argv[1])
root.mkdir(parents=True, exist_ok=True)
Config._instance = object.__new__(Config)
Config.data = Config.node_from_dict({'random_seed': 1})
Config.params = {}
results = []

# A real writer holds the production lock and exposes an in-progress NPZ.
for name, module in [('purchase', purchase), ('texas', texas)]:
    dest = root / ('concurrent-' + name)
    dest.mkdir()
    child_script = '''
import sys
from pathlib import Path
from plato.datasources.base import DataSource
with DataSource._download_guard(sys.argv[1]):
    with (Path(sys.argv[1]) / (sys.argv[2] + '_numpy.npz')).open('wb') as cache:
        cache.write(b'PK'); cache.flush()
        print('ready', flush=True)
        sys.stdin.readline()
'''
    child = subprocess.Popen([sys.executable, '-c', child_script, str(dest), name],
                             stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, text=True)
    try:
        import selectors
        with selectors.DefaultSelector() as selector:
            selector.register(child.stdout, selectors.EVENT_READ)
            assert selector.select(10), 'writer startup timeout'
            assert child.stdout.readline().strip() == 'ready'
        Config.params['data_path'] = str(dest)
        start = time.monotonic()
        try:
            module.DataSource()
            outcome = 'loaded'
        except Exception as exc:
            outcome = f'{type(exc).__name__}: {exc}'
        results.append({'probe': 'reader_during_locked_cache_write', 'module': name,
                        'result': outcome, 'seconds': time.monotonic() - start,
                        'writer_alive_and_holding_lock': child.poll() is None})
    finally:
        child.communicate('\n', timeout=10)
        assert child.returncode == 0

# Marker-based cache fast path is used even when expected extracted files vanish.
for name, module in [('cinic', cinic10), ('tiny', tiny_imagenet)]:
    dest = root / ('stale-' + name)
    dest.mkdir()
    if name == 'cinic':
        image_path = 'train/n001/one.png'
        other_path = 'test/n001/one.png'
    else:
        image_path = 'tiny-imagenet-200/train/n001/images/one.png'
        other_path = 'tiny-imagenet-200/val/images/one.png'
    image = io.BytesIO()
    Image.new('RGB', (8, 8)).save(image, format='PNG')
    payload = io.BytesIO()
    with zipfile.ZipFile(payload, 'w') as archive:
        archive.writestr(image_path, image.getvalue())
        archive.writestr(other_path, image.getvalue())
        if name == 'tiny':
            archive.writestr('tiny-imagenet-200/val/val_annotations.txt', 'one.png\tn001\t0\t0\t8\t8\n')
    from tests.datasources.test_download_contracts import serve
    with serve(payload.getvalue(), name + '.zip') as url:
        base.DataSource.download(url, str(dest))
        import shutil
        if name == 'cinic':
            shutil.rmtree(dest / 'test')
        else:
            (dest / 'tiny-imagenet-200/val/val_annotations.txt').unlink()
        Config.params['data_path'] = str(dest)
        Config.data.download_url = url
        try:
            module.DataSource()
            outcome = 'recovered'
        except Exception as exc:
            outcome = f'{type(exc).__name__}: {exc}'
        results.append({'probe': 'incomplete_extracted_tree_with_completion_marker',
                        'module': name, 'result': outcome,
                        'completion_marker': (dest / (name + '.zip.complete')).exists()})

# An interrupted direct native Tiny ImageNet tree must not assign the unlabeled
# official test directory to a synthetic class named images.
dest = root / 'incomplete-native-tiny'
for relative in ['train/n001/images/one.png', 'train/n002/images/two.png', 'test/images/unlabeled.png']:
    path = dest / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.new('RGB', (8, 8)).save(path)
Config.params['data_path'] = str(dest)
source = tiny_imagenet.DataSource()
results.append({'probe': 'native_tiny_missing_annotations', 'train_classes': source.classes(),
                'test_classes': source.testset.classes, 'test_targets': source.testset.targets})

# Actual extraction with name aliases, link chains and preexisting links.
for kind in ['tar', 'zip']:
    dest = root / ('extract-' + kind)
    dest.mkdir()
    outside = root / ('outside-' + kind)
    outside.write_bytes(b'original')
    (dest / 'nested').mkdir()
    (dest / 'nested/link').symlink_to(outside)
    archive_path = root / ('test.' + kind)
    if kind == 'zip':
        with zipfile.ZipFile(archive_path, 'w') as archive:
            archive.writestr('first', b'safe')
            archive.writestr('nested/./link', b'changed')
    else:
        with tarfile.open(archive_path, 'w') as archive:
            for filename, data in [('first', b'safe'), ('nested/./link', b'changed')]:
                info = tarfile.TarInfo(filename)
                info.size = len(data)
                archive.addfile(info, io.BytesIO(data))
    try:
        extract_archive(archive_path, dest)
        outcome = 'accepted'
    except Exception as exc:
        outcome = f'{type(exc).__name__}: {exc}'
    assert outside.read_bytes() == b'original'
    assert not (dest / 'first').exists()
    results.append({'probe': 'preexisting_symlink_normalized_member', 'format': kind,
                    'result': outcome, 'outside_unchanged': True, 'no_first_write': True})

print(json.dumps(results, indent=2))
