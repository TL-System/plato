"""Pause an actual production cache build in a real NPZ write; test live/crash readers."""
import json
import selectors
import subprocess
import sys
from pathlib import Path

from plato.config import Config
from plato.datasources import purchase, texas

Config._instance = object.__new__(Config)
Config.data = Config.node_from_dict({})
Config.params = {}
root = Path(sys.argv[1])
root.mkdir(parents=True, exist_ok=True)
results=[]
script = '''
import sys
from pathlib import Path
import numpy as np
from plato.config import Config
from plato.datasources import purchase, texas
Config._instance=object.__new__(Config)
Config.data=Config.node_from_dict({})
Config.params={'data_path':sys.argv[1]}
original=np.savez
class PausedFile:
    def __init__(self, handle): self.handle=handle; self.first=True
    def __getattr__(self, name): return getattr(self.handle,name)
    def write(self, value):
        written=self.handle.write(value)
        self.handle.flush()
        if self.first:
            self.first=False
            print('npz-header-written',flush=True)
            sys.stdin.readline()
        return written
def save(cache_path, **kwargs):
    with open(cache_path,'wb') as handle:
        original(PausedFile(handle),**kwargs)
np.savez=save
module=purchase if sys.argv[2]=='purchase' else texas
source=module.DataSource()
print('built:'+str(len(source.trainset)),flush=True)
'''
for name,module in [('purchase',purchase),('texas',texas)]:
    for death in [False,True]:
        dest=root/(name+('-crash' if death else '-live'))
        dest.mkdir()
        if name=='purchase':
            (dest/'dataset_purchase').write_text('1,0.1,0.2\n2,0.3,0.4\n')
        else:
            raw=dest/'texas/100'; raw.mkdir(parents=True)
            (raw/'feats').write_text('0.1,0.2\n0.3,0.4\n')
            (raw/'labels').write_text('1\n2\n')
        child=subprocess.Popen([sys.executable,'-c',script,str(dest),name],
                               stdin=subprocess.PIPE,stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE,text=True)
        try:
            with selectors.DefaultSelector() as selector:
                selector.register(child.stdout,selectors.EVENT_READ)
                assert selector.select(10),'writer startup timeout'
                assert child.stdout.readline().strip()=='npz-header-written'
            if death:
                child.kill(); child.communicate(timeout=10)
            Config.params['data_path']=str(dest)
            try:
                module.DataSource()
                outcome='loaded'
            except Exception as exc:
                outcome=f'{type(exc).__name__}: {exc}'
            entry={'module':name,'writer_crashed':death,'reader_result':outcome,
                   'raw_data_complete':True,'real_npz_header':(dest/(name+'_numpy.npz')).read_bytes().hex()}
            if not death:
                out,err=child.communicate('\n',timeout=10)
                assert child.returncode==0,err
                assert 'built:2' in out,out
                source=module.DataSource()
                assert source.num_train_examples()==2
                entry['writer_completed_and_subsequent_reader_passed']=True
            results.append(entry)
        finally:
            if child.poll() is None:
                child.kill(); child.communicate(timeout=10)
print(json.dumps(results,indent=2))
