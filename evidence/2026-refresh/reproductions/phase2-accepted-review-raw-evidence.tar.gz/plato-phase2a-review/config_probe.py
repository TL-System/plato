"""Repeated public/legacy resets through actual includes and CLI, fixture free."""
import json
import os
import sys
from pathlib import Path
from plato.config import Config

root = Path(sys.argv[1])
root.mkdir(parents=True, exist_ok=True)
(root / 'required.toml').write_text('''[clients]
total_clients=2
per_round=1
[server]
address="127.0.0.1"
port=8000
[data]
datasource="MNIST"
[trainer]
rounds=1
[algorithm]
type="fedavg"
''')
(root / 'present.toml').write_text('''include="required.toml"
[general]
base_path="ignored-by-cli"
[evaluation]
type="local"
[results]
types="round, loss"
result_path="custom"
[parameters.optimizer]
lr=0.1
''')
(root / 'absent.toml').write_text('include="required.toml"\n')
os.environ.pop('config_file', None)
results=[]
for mode in ['public','legacy']:
    for present in [True,False,True,True,False,False,True,False]:
        if mode == 'public': Config.reset()
        else: Config._instance=None
        path=root/('present.toml' if present else 'absent.toml')
        sys.argv=['probe','-c',str(path),'-b',str(root/'runtime'),'-i','2','-p','8123','-s','localhost:8124']
        cfg=Config()
        sections=['general','evaluation','results','parameters']
        assert all(hasattr(cfg,name)==present for name in sections)
        assert Config._cli_overrides['config'] and Config._cli_overrides['base']
        assert cfg.args.id==2 and cfg.args.port==8123 and cfg.server.port==8124
        assert cfg.params['base_path']==str(root/'runtime')
        assert cfg.params['result_types']==('round, loss' if present else 'round, accuracy, elapsed_time')
        results.append({'mode':mode,'present':present,'sections_correct':True,'cli_correct':True})
print(json.dumps(results,indent=2))
