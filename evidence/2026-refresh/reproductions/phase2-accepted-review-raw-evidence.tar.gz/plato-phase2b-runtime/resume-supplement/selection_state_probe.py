"""Retained audit of global versus selection-owned checkpoint RNG state."""

import json
import pickle
import random
import tempfile
from pathlib import Path

import numpy as np
import pytest

from plato.config import Config
from tests.integration.utils import configure_environment
from tests.servers.test_server_resume_rng import (
    POPULATION,
    intercept_process_launches,
    make_server,
    runtime_config,
)

results = []
for unrelated_draws in (0, 1):
    with tempfile.TemporaryDirectory(
        dir="/tmp/plato-phase2b-runtime/resume-supplement"
    ) as directory, configure_environment(
        runtime_config(False, 17), runtime_root=Path(directory)
    ), pytest.MonkeyPatch.context() as patch:
        server = make_server()
        server.configure()
        random.seed(17)
        np.random.seed(19)
        server.prng_state = random.getstate()
        previous = [
            server._select_clients_with_strategy(POPULATION, 2) for _ in range(2)
        ]
        selection_state = server.prng_state
        for _ in range(unrelated_draws):
            random.random()
        global_state = random.getstate()
        server.current_round = 2
        server.save_to_checkpoint()
        path = Path(Config.params["checkpoint_path"]) / "prng_state_2.pkl"
        with path.open("rb") as stream:
            saved_state = pickle.load(stream)
        uninterrupted = [
            server._select_clients_with_strategy(POPULATION, 2) for _ in range(3)
        ]
        random.seed(99)
        resumed = make_server()
        Config.args.resume = True
        intercept_process_launches(patch)
        observed = []
        state_checks = {}

        def capture_start():
            state_checks["restored_server_equals_saved"] = (
                resumed.prng_state == saved_state
            )
            state_checks["context_equals_restored_before_selection"] = (
                resumed.context.state["prng_state"] == resumed.prng_state
            )
            for _ in range(3):
                observed.append(resumed._select_clients_with_strategy(POPULATION, 2))
            state_checks["context_equals_server_after_selection"] = (
                resumed.context.state["prng_state"] == resumed.prng_state
            )

        patch.setattr(resumed, "start", capture_start)
        resumed.run()
        assert saved_state == global_state
        assert (saved_state == selection_state) == (unrelated_draws == 0)
        assert (observed == uninterrupted) == (unrelated_draws == 0)
        results.append(
            dict(
                unrelated_draws=unrelated_draws,
                prior=previous,
                uninterrupted=uninterrupted,
                resumed=observed,
                saved_equals_global=saved_state == global_state,
                saved_equals_selection_state=saved_state == selection_state,
                state_checks=state_checks,
            )
        )
print(json.dumps(results, indent=2))
