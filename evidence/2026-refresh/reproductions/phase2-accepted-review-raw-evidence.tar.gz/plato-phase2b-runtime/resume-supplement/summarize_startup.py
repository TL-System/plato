"""Summarize newly executed startup cases and independent socket arithmetic."""

import hashlib
import json
from pathlib import Path

import numpy as np

root = Path("/tmp/plato-phase2b-runtime/resume-supplement")
summary = {}
for interpreter in ("313", "314"):
    paths = sorted((root / f"startup{interpreter}").rglob("result.json"))
    assert len(paths) == 48, (interpreter, len(paths))
    records = [json.loads(path.read_text()) for path in paths]
    assert not any(record["survivors"] for record in records)
    socket_records = [row for row in records if row["case"] == "socket_round"]
    assert len(socket_records) == 1
    socket = socket_records[0]
    assert socket["returncode"] == 0
    assert not socket["timed_out"]
    assert not socket["forced"]
    events = socket["events"]
    received = {
        event["client_id"]: event
        for event in events
        if event["event"] == "server_received"
    }
    trained = {
        event["client_id"]: event
        for event in events
        if event["event"] == "client_trained"
    }
    assert sorted(row["samples"] for row in received.values()) == [2, 6]
    assert len({row["pid"] for row in trained.values()}) == 2
    (aggregate,) = [
        event["weights"] for event in events if event["event"] == "server_aggregate"
    ]
    reference = {}
    errors = {}
    total = sum(row["samples"] for row in received.values())
    for name, value in aggregate.items():
        expected = sum(
            np.asarray(row["weights"][name], dtype=np.float64) * row["samples"]
            for row in received.values()
        ) / total
        actual = np.asarray(value, dtype=np.float64)
        np.testing.assert_allclose(actual, expected, rtol=1e-5, atol=1e-6)
        reference[name] = expected.tolist()
        errors[name] = float(np.max(np.abs(actual - expected)))
    summary[interpreter] = {
        "subprocess_records": len(records),
        "surviving_owned_descendants": 0,
        "watchdog_cases": [
            {
                "case": row["case"],
                "options": row["options"],
                "returncode": row["returncode"],
                "forced": row["forced"],
            }
            for row in records
            if row["timed_out"]
        ],
        "real_socket": {
            "returncode": socket["returncode"],
            "timed_out": socket["timed_out"],
            "forced": socket["forced"],
            "survivors": socket["survivors"],
            "clients": {
                str(client_id): {
                    "pid": trained[client_id]["pid"],
                    "samples": row["samples"],
                    "weights": row["weights"],
                }
                for client_id, row in received.items()
            },
            "actual_aggregate": aggregate,
            "float64_weighted_reference": reference,
            "max_absolute_error": errors,
        },
        "raw_result_manifest": [
            {
                "path": str(path.relative_to(root)),
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            }
            for path in paths
        ],
    }
(root / "startup-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(
    json.dumps(
        {
            py: {key: value for key, value in data.items() if key != "raw_result_manifest"}
            for py, data in summary.items()
        },
        indent=2,
    )
)
