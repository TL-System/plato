"""Provisional exact-2D writer/presigner plus 2B bounded-reader integration."""
import asyncio
import importlib.util
from pathlib import Path
from types import SimpleNamespace

import pytest

from plato.clients.transport import InboundTransfer, TransportLimits, receive_s3_payload
from tests.conftest import temp_config
from tests.servers.test_runtime_s3_contract import local_object_store

SOURCE = Path("/tmp/plato-phase2b-runtime/review-fixes/s3_a4a4733.py")
spec = importlib.util.spec_from_file_location("phase2d_a4a4733_s3", SOURCE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

@pytest.mark.parametrize("prefix", ["", "prefix", "nested/prefix", "prefix/"])
@pytest.mark.parametrize("minimal_adapter", [False, True])
@pytest.mark.parametrize("kind", ["valid", "oversize", "deadline"])
def test_exact_d_writer_presigner_and_bounded_b_reader(
    temp_config, local_object_store, prefix, minimal_adapter, kind
):
    # Real 2D constructor, botocore requests/presigning, send_to_s3 and put_to_s3.
    storage = module.S3(
        endpoint=local_object_store.endpoint,
        access_key="local-test-key", secret_key="local-test-secret",
        bucket="s3://bucket/" + prefix,
    )
    payload = {"w": [1.0, 2.0, 3.0]}
    key = "client_payload_7_ABC123"
    storage.send_to_s3(key, payload)
    object_key = prefix.strip("/") + "/" + key if prefix.strip("/") else key
    assert set(local_object_store.objects) == {"bucket/" + object_key}
    assert storage._object_key(key) == object_key
    if minimal_adapter:
        storage = SimpleNamespace(key_prefix=prefix, bucket=storage.bucket, s3_client=storage.s3_client)
    raw = local_object_store.objects["bucket/" + object_key]
    limits = TransportLimits(
        max_payload_bytes=len(raw) - 1 if kind == "oversize" else 1024,
        payload_timeout=0.04 if kind == "deadline" else 2,
    )
    local_object_store.state["slow"] = kind == "deadline"

    async def scenario():
        transfer = InboundTransfer(limits, lambda: None)
        try:
            if kind == "valid":
                result = await receive_s3_payload(storage, key, transfer, transfer.reserve)
                assert result == payload
                assert transfer.byte_count == len(raw)
            else:
                with pytest.raises(ValueError if kind == "oversize" else TimeoutError):
                    await receive_s3_payload(storage, key, transfer, transfer.reserve)
                assert transfer.byte_count <= limits.max_payload_bytes
        finally:
            transfer.close()

    asyncio.run(scenario())
    assert local_object_store.requests[-1] == ("GET", "bucket/" + object_key)
