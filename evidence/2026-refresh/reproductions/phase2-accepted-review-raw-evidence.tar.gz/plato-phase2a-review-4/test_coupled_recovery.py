"""Real HTTP failure, failed owner contention and default artifact controls."""
import contextlib
import http.server
import json
import sys
import threading
import traceback
import zipfile
from pathlib import Path

import plato
import pytest
import requests

import test_independent_contracts as support

configure = support.configure


@contextlib.contextmanager
def source_server(payload):
    state = {'payload': payload, 'status': 200, 'hits': [], 'pause': False,
             'entered': threading.Event(), 'release': threading.Event()}

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            body, status = state['payload'], state['status']
            state['hits'].append({'path': self.path, 'status': status,
                                  'bytes': len(body)})
            self.send_response(status)
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            if state['pause']:
                state['entered'].set()
                assert state['release'].wait(10)
            self.wfile.write(body)

        def log_message(self, *args):
            pass

    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    worker = threading.Thread(target=lambda: server.serve_forever(poll_interval=.01))
    worker.start()
    try:
        yield f'http://127.0.0.1:{server.server_port}/source.zip', state
    finally:
        state['release'].set()
        server.shutdown()
        worker.join(3)
        server.server_close()
        assert not worker.is_alive()


def observe(root, name, state, values, errors, **extra):
    result = {
        'name': name, 'python': sys.version, 'source': plato.__file__,
        'http_requests': list(state['hits']), 'successful_constructors': len(values),
        'completion_markers': [p.name for p in root.glob('*.complete')],
        'canonical_archive_exists': (root / 'tiny-imagenet-200.zip').is_file(),
        'errors': [{'type': type(e).__name__, 'message': str(e),
                    'traceback': ''.join(traceback.format_exception(e))} for e in errors],
        **extra,
    }
    (root / 'observed.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


@pytest.mark.parametrize('mode', ['tiny_default', 'tiny_native'])
@pytest.mark.parametrize('failure', ['http_503', 'bad_zip'])
def test_restored_source_can_retry_after_failed_recovery_download(
    tmp_path, monkeypatch, mode, failure
):
    members, _, missing_name = support.fixture(mode)
    payload = support.zipped(members)
    with source_server(payload) as (url, state):
        module = support.setup_source(mode, url, monkeypatch)
        support.check_images(module.DataSource())
        assert len(state['hits']) == 1
        (tmp_path / missing_name).unlink()
        if failure == 'http_503':
            state['status'], expected_error = 503, requests.HTTPError
        else:
            state['payload'], expected_error = b'not a ZIP archive', zipfile.BadZipFile
        with pytest.raises(expected_error):
            module.DataSource()
        assert len(state['hits']) == 4
        assert not list(tmp_path.glob('*.complete'))
        assert not (tmp_path / missing_name).exists()
        failed_state = {
            'markers': [p.name for p in tmp_path.glob('*.complete')],
            'canonical_archive_exists': (tmp_path / 'tiny-imagenet-200.zip').is_file(),
        }
        state['status'], state['payload'] = 200, payload
        values, errors = [], []
        try:
            values.append(module.DataSource())
        except Exception as error:
            errors.append(error)
        observe(tmp_path, 'restored-source-' + failure + '-' + mode,
                state, values, errors, after_failed_recovery=failed_state)
        assert not errors, f'Restored source is never retried: {errors!r}'
        assert len(state['hits']) == 5
        assert (tmp_path / missing_name).read_bytes() == members[missing_name]
        support.check_images(values[0])
    monkeypatch.setattr(support.base.requests, 'get',
                        lambda *a, **kw: pytest.fail('Complete data stays offline'))
    support.check_images(module.DataSource())


@pytest.mark.parametrize('mode', ['tiny_default', 'tiny_native'])
def test_waiting_contender_retries_after_owner_failed_readiness(
    tmp_path, monkeypatch, mode
):
    members, _, missing_name = support.fixture(mode)
    values, errors = [], []
    contender_at_flock = threading.Event()
    contender_finished = threading.Event()

    def load(contender=False):
        def profile(frame, event, function):
            if event == 'c_call' and function is support.base.fcntl.flock:
                contender_at_flock.set()
        if contender:
            sys.setprofile(profile)
        try:
            values.append(support.tiny_imagenet.DataSource())
        except Exception as error:
            errors.append(error)
        finally:
            if contender:
                sys.setprofile(None)
                contender_finished.set()

    with source_server(support.zipped(members)) as (url, state):
        module = support.setup_source(mode, url, monkeypatch)
        support.check_images(module.DataSource())
        (tmp_path / missing_name).unlink()
        state['payload'] = support.zipped(
            {name: value for name, value in members.items() if name != missing_name})
        state['pause'] = True
        workers = [threading.Thread(target=load),
                   threading.Thread(target=load, kwargs={'contender': True})]
        try:
            workers[0].start()
            assert state['entered'].wait(5)
            assert not list(tmp_path.glob('*.complete'))
            workers[1].start()
            assert contender_at_flock.wait(5)
            assert not contender_finished.is_set()
            state['payload'], state['pause'] = support.zipped(members), False
        finally:
            state['release'].set()
            for worker in workers:
                if worker.ident is not None:
                    worker.join(10)
        assert not any(w.is_alive() for w in workers)
        observe(tmp_path, 'waiting-contender-failed-readiness-' + mode,
                state, values, errors)
        assert len(errors) == 1 and isinstance(errors[0], RuntimeError)
        assert 'required extracted dataset artifacts' in str(errors[0])
        assert len(values) == 1 and len(state['hits']) == 3
        support.check_images(values[0])
    monkeypatch.setattr(support.base.requests, 'get',
                        lambda *a, **kw: pytest.fail('Complete data stays offline'))
    support.check_images(module.DataSource())


@pytest.mark.parametrize('artifact', ['tiny-imagenet-200.zip',
                                     'tiny-imagenet-200.zip.complete'])
def test_unknown_native_annotation_rejects_despite_default_artifact(
    tmp_path, monkeypatch, artifact
):
    members, _, _ = support.fixture('tiny_default')
    for name, content in members.items():
        target = tmp_path / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
    annotation = tmp_path / 'tiny-imagenet-200/val/val_annotations.txt'
    annotation.write_text('z1.PNG\tn999\n')
    (tmp_path / artifact).write_bytes(b'prior artifact')
    monkeypatch.setattr(support.base.requests, 'get',
                        lambda *a, **kw: pytest.fail('Unknown classes reject'))
    with pytest.raises(ValueError, match='Invalid Tiny ImageNet validation annotation'):
        support.tiny_imagenet.DataSource()
