"""Verify immutable source/report identities and raw author result attribution."""
import hashlib
import json
import os
import shlex
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path('/Users/bli/Playground/plato/evidence/2026-refresh')
REPO = Path('/private/tmp/plato-refresh-worktrees/data')
SCRATCH = Path('/tmp/plato-phase2a-review-4')
AUTHOR = Path('/tmp/plato-phase2a-lZqbqj')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def shell(cmd):
    return subprocess.run(['/bin/zsh', '-lc', cmd], cwd=REPO,
                          capture_output=True, check=True,
                          env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}).stdout


def record(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


evidence = json.loads((REPO / 'evidence/2026-refresh/phase2a-validation.json').read_text())
result = {'author_history_reports': [], 'historical_candidate_evidence': [],
          'source_copy_checks': [], 'raw_revision3_results': [],
          'accepted_plan': {}, 'prior_export': {}, 'correction_histories': {}}
inputs = evidence['review_corrections']['independent_inputs'] + [
    evidence['review2_corrections']['independent_input'],
    evidence['review3_corrections']['independent_input'],
]
for item in inputs:
    actual = record(item['path'])
    actual.update(expected_sha256=item['sha256'], equal=actual['sha256'] == item['sha256'])
    assert actual['equal'], actual
    result['author_history_reports'].append(actual)
for item in evidence['identity']['earlier_candidates'] + [evidence['identity']['previous_candidate']]:
    blob = shell(shlex.join(['git', 'show', item['commit'] + ':evidence/2026-refresh/phase2a-validation.json']))
    check = {'commit': item['commit'], 'actual_sha256': sha(blob),
             'expected_sha256': item['evidence_file_sha256']}
    check['equal'] = check['actual_sha256'] == check['expected_sha256']
    assert check['equal'], check
    result['historical_candidate_evidence'].append(check)
previous = AUTHOR / 'revision3/previous-validation-150a4886.json'
assert previous.read_bytes() == shell('git show 150a48860b556eab1575178891577dd07dc6f06d:evidence/2026-refresh/phase2a-validation.json')
result['previous_validation_copy'] = record(previous)
for section in ['review2_corrections', 'review3_corrections']:
    for source, expected in evidence[section]['read_only_probe_sources_sha256'].items():
        check = {**record(source), 'expected_sha256': expected}
        check['equal'] = check['sha256'] == expected
        assert check['equal'], check
        result['source_copy_checks'].append(check)
for name in ['test_default_recovery_negative.py', 'test_independent_contracts.py',
             'test_prior_remaining_contracts.py', 'independent_probes.py',
             'prior_independent_probes.py']:
    source = Path('/tmp/plato-phase2a-review-3') / name
    target = SCRATCH / name
    check = {**record(target), 'original': str(source),
             'identical': source.read_bytes() == target.read_bytes()}
    assert check['identical'], check
    result['source_copy_checks'].append(check)
acceptance = json.loads((ROOT / 'plan-addendum-acceptance.json').read_text())
addendum = json.loads((ROOT / 'plan-addendum.json').read_text())
assert record(ROOT / 'plan.md')['sha256'] == addendum['immutable_plan']['sha256']
assert record(ROOT / 'plan-addendum.json')['sha256'] == acceptance['artifact_sha256']
assert record(ROOT / 'plan-addendum-review.json')['sha256'] == acceptance['review_sha256']
result['accepted_plan'] = {'plan': record(ROOT / 'plan.md'),
                           'addendum': record(ROOT / 'plan-addendum.json'),
                           'acceptance': acceptance,
                           'plan_review3_decision': json.loads((ROOT / 'plan-review-3.json').read_text())['decision']}
for version in ['3.13', '3.14']:
    for action in ['red', 'green_new_cases', 'original_reviewer_script_author_rerun']:
        item = evidence['review3_corrections'][action][version]
        log = (AUTHOR / item['log']).read_text()
        tail = log.splitlines()[-1]
        assert f"{item['passed']} passed" in tail
        if item.get('failed'): assert f"{item['failed']} failed" in tail
        result['raw_revision3_results'].append({'version': version, 'action': action,
                                               'claim': item, 'actual_summary': tail})
    for action in ['green', 'clean_base_profile']:
        item = evidence['red_green'][action][version]
        log = (AUTHOR / item['log']).read_text()
        tail = log.splitlines()[-1]
        assert f"{item['passed']} passed" in tail
        if item.get('skipped'): assert f"{item['skipped']} skipped" in tail
        if item.get('deselected'): assert f"{item['deselected']} deselected" in tail
        result['raw_revision3_results'].append({'version': version, 'action': action,
                                               'claim': item, 'actual_summary': tail})
        if action == 'clean_base_profile':
            doc = ET.parse(AUTHOR / f'revision3/base-{version}.xml')
            suite = doc.getroot().find('testsuite')
            assert int(suite.attrib['tests']) == 440
            assert int(suite.attrib['skipped']) == 4
            assert int(suite.attrib['failures']) == int(suite.attrib['errors']) == 0
    obs = json.loads((AUTHOR / 'revision3/independent-observations.json').read_text())
    result['author_original_reviewer_observations'] = obs
for section in ['review_corrections', 'review2_corrections', 'review3_corrections']:
    result['correction_histories'][section] = evidence[section]
prior = '150a48860b556eab1575178891577dd07dc6f06d'
count = 0
for entry in shell(f'git ls-tree -rz {prior}').split(b'\0'):
    if not entry: continue
    meta, name = entry.split(b'\t', 1)
    mode, kind, blob = meta.decode().split()
    if kind == 'commit': continue
    path = SCRATCH / 'prior' / name.decode()
    content = os.readlink(path).encode() if mode == '120000' else path.read_bytes()
    assert hashlib.sha1(f'blob {len(content)}\0'.encode() + content).hexdigest() == blob
    count += 1
assert (SCRATCH / 'prior/tests/datasources/test_review3_regressions.py').read_bytes() == (REPO / 'tests/datasources/test_review3_regressions.py').read_bytes()
result['prior_export'] = {'commit': prior, 'tracked_blobs_match': count,
                          'sole_added_regression': record(SCRATCH / 'prior/tests/datasources/test_review3_regressions.py'),
                          'qualification': 'Exact prior production plus new author tests. PYTHONPATH and cwd select the prior export using reviewer environments; no prior candidate or shared environment mutations.'}
(SCRATCH / 'evidence-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print('Immutable review digests, three historical evidence blobs, accepted plan/addendum, prior export and author revision3 raw counts all match.')
