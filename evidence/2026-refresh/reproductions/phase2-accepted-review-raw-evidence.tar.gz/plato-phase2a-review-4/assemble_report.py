"""Assemble the exact-candidate independent review; no candidate mutations."""
import datetime
import hashlib
import json
import os
import re
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

SCRATCH = Path('/tmp/plato-phase2a-review-4')
ROOT = Path('/Users/bli/Playground/plato/evidence/2026-refresh')
REPORT = ROOT / 'phase2a-review-4.json'


def read(name):
    return json.loads((SCRATCH / name).read_text())


def record(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def result(action, version):
    command = read(f'command-{action}-{version}.json')
    log = Path(command['log'])
    text = log.read_text()
    xml_path = SCRATCH / f'logs/{action}-{version}.xml'
    suite = ET.parse(xml_path).getroot().find('testsuite')
    tests = int(suite.attrib['tests'])
    failed = int(suite.attrib['failures'])
    errors = int(suite.attrib['errors'])
    skipped = int(suite.attrib['skipped'])
    summaries = [line for line in text.splitlines()
                 if re.search(r'=+.*(?:passed|failed|skipped).*in .*s', line)]
    return {
        **command, 'log': record(log), 'junit': record(xml_path),
        'tests': tests, 'passed': tests - failed - errors - skipped,
        'failed': failed, 'errors': errors, 'skipped': skipped,
        'warnings': 0 if 'warnings summary' not in text else 'see log',
        'junit_seconds': float(suite.attrib['time']), 'summary': summaries[-1],
        'failed_nodes': [case.attrib['name'] for case in suite.findall('testcase')
                         if case.find('failure') is not None or case.find('error') is not None],
        'skip_reasons': [line for line in text.splitlines() if line.startswith('SKIPPED')],
        'runtime_deselected': 48 if action == 'base' else 0,
    }


before, after = read('identity-before.json'), read('identity-after.json')
assert before == after
audit = read('evidence-audit.json')
validation = json.loads(Path(after['inputs']['candidate_validation']['path']).read_text())
identity = {key: value for key, value in after.items()
            if key not in {'inputs', 'author_log_integrity', 'archives',
                           'active_archive_reference_scan'}}
identity.update({
    'previous_reviewed_candidate': '150a48860b556eab1575178891577dd07dc6f06d',
    'previous_reviewed_tree': 'f9a191f004077f32f01bf0a4ae651c173a914b2c',
    'candidate_head_at_start': before['observed_head'],
    'candidate_head_at_end': after['observed_head'],
    'candidate_status_at_start': before['observed_status'],
    'candidate_status_at_end': after['observed_status'],
    'candidate_immutable': True,
    'full_before_after_audits_identical': True,
    'assigned_worktree': '/private/tmp/plato-refresh-worktrees/data',
    'exact_export': str(SCRATCH / 'candidate'),
    'export_command': 'git archive d26f2bc7bbd770dee86ae571e57ca79773a456a2 -o /tmp/plato-phase2a-review-4/candidate.tar; tar -xf /tmp/plato-phase2a-review-4/candidate.tar -C /tmp/plato-phase2a-review-4/candidate',
    'comparison': 'All 944 tracked non-gitlink blobs in the candidate checkout and export match the candidate Git blobs before and after review. Three unchanged gitlinks were not initialized in the export.',
    'identity_audits': [record(SCRATCH / f'identity-{stage}.json') for stage in ['before', 'after']],
})
checks = {action: {version: result(action, version) for version in ['3.13', '3.14']}
          for action in ['focused', 'base', 'independent', 'original',
                         'coupled', 'coupled-corrected', 'previous-red']}
for version in ['3.13', '3.14']:
    for action, passed, failed, skipped in [
        ('focused', 233, 0, 0), ('base', 436, 0, 4),
        ('independent', 99, 0, 0), ('original', 4, 0, 0),
        ('coupled', 5, 3, 0), ('coupled-corrected', 6, 2, 0),
        ('previous-red', 5, 2, 0),
    ]:
        item = checks[action][version]
        assert (item['passed'], item['failed'], item['skipped'], item['errors']) == (passed, failed, skipped, 0)
        assert item['warnings'] == 0
        assert item['exit_code'] == (1 if failed else 0)
    assert set(checks['coupled-corrected'][version]['failed_nodes']) == {
        'test_restored_source_can_retry_after_failed_recovery_download[http_503-tiny_default]',
        'test_restored_source_can_retry_after_failed_recovery_download[bad_zip-tiny_default]',
    }

observations = {}
for action, expected in [('original', 4), ('coupled-corrected', 6)]:
    observations[action] = {}
    for version in ['3.13', '3.14']:
        items = []
        for path in (SCRATCH / f'{action}-{version}-fixtures').glob('*/observed.json'):
            if path.parent.is_symlink():
                continue
            data = json.loads(path.read_text())
            assert Path(data['source']).resolve() == (SCRATCH / 'candidate/plato/__init__.py').resolve()
            items.append({**record(path), 'observation': data})
        assert len(items) == expected
        observations[action][version] = items
(SCRATCH / 'observations.json').write_text(json.dumps(observations, indent=2) + '\n')

ruff_command = 'XDG_CACHE_HOME=/tmp/plato-phase2a-review-4/cache TMPDIR=/tmp/plato-phase2a-review-4/tmp ' + validation['red_green']['static_checks'][0]['command'] + ' --no-cache'
ty_command = 'XDG_CACHE_HOME=/tmp/plato-phase2a-review-4/cache TMPDIR=/tmp/plato-phase2a-review-4/tmp ' + validation['red_green']['static_checks'][1]['command'].replace('ty check ', 'ty check --python /tmp/plato-phase2a-review-4/base-3.13/bin/python ')
static = [
    {'command': ruff_command, 'cwd': str(SCRATCH / 'candidate'), 'shell': '/bin/zsh -lc',
     'tool_version': 'ruff 0.16.10', 'exit_code': 0, 'result': 'All checks passed!',
     'log': record(SCRATCH / 'logs/ruff.log')},
    {'command': ty_command, 'cwd': str(SCRATCH / 'candidate'), 'shell': '/bin/zsh -lc',
     'tool_version': 'ty 0.0.84 (8dd9a7f7f 2026-09-24)', 'exit_code': 0,
     'result': 'All checks passed! No suppressions.', 'log': record(SCRATCH / 'logs/ty.log')},
    {'command': 'GIT_OPTIONAL_LOCKS=0 git diff --check fda60becedfa6236c11d415b87a868b52789a41e d26f2bc7bbd770dee86ae571e57ca79773a456a2',
     'cwd': '/private/tmp/plato-refresh-worktrees/data', 'shell': '/bin/zsh -lc',
     'exit_code': 0, 'result': 'clean', 'log': record(SCRATCH / 'logs/diff-check.log')},
]
assert all((SCRATCH / f'logs/{name}.log').read_text().strip() == 'All checks passed!' for name in ['ruff', 'ty'])
assert not (SCRATCH / 'logs/diff-check.log').read_bytes()

report = {
    'schema_version': 1,
    'reviewer': 'phase2a-data-review-4',
    'review_role': 'Fresh independent exact-candidate review; no implementation or root phase acceptance',
    'review_date': '2026-10-03',
    'written_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'model_requested': 'gpt-6.1-sol', 'reasoning_effort_requested': 'xhigh',
    'verdict': 'CHANGES_REQUESTED', 'decision': 'CHANGES_REQUESTED',
    'finding_counts': {'critical': 0, 'high': 0, 'medium': 1, 'low': 0},
    'summary': 'Exact clean d26f2bc7 passes the original review3 default retry/contention cases and all retained A controls on Python 3.13.16 and 3.14.8. One material coupled recovery gap remains: HTTP or invalid-archive cleanup deletes the canonical ZIP after stale completion removal, so subsequent default constructors reject the previously downloaded native root without requesting the restored source. Configured-source controls recover. This is one medium finding, R2A4-01.',
    'identity': identity,
    'write_scope_and_authority': {
        'root_report': str(REPORT), 'scratch': str(SCRATCH),
        'candidate_read_only': True, 'nested_agents': 0,
        'candidate_edits_commits_pushes': 0, 'shared_metadata_or_fixture_changes': 0,
        'other_review_author_resources': 'Read only; original reports, probes, verdicts, environments and fixtures unchanged. Copies used for execution write only reviewer scratch.',
        'shell': 'All shell commands used /bin/zsh -lc, including subprocess execution.',
        'herdr': {'workspace_id': 'w19', 'workspace_label': 'plato-phase2-data-review-4',
                  'tab_id': 'w19:t1', 'pane_id': 'w19:p1', 'HERDR_ENV': '1',
                  'isolation': 'Existing root-assigned separate workspace verified with herdr pane current --current and herdr workspace get. No other panes or agents controlled.',
                  'cli_instructions': 'Read herdr --skill after --help; caller context verified before current-workspace inspection.'},
        'excluded': 'Unchanged 48 startup/socket runtime cases, shared runtime, HF/LeRobot/Nanochat/MLX qualification, shared metadata/CI ownership, security questionnaires and protocol/redesign work.',
    },
    'accepted_and_prior_sources_read': after['inputs'],
    'environment': {
        'uv': 'uv 0.12.22 (70fe1196a 2026-10-01 aarch64-apple-darwin)',
        'profile': 'Fresh locked test-base editable installs of exact exported candidate; all five optional package absence checks pass.',
        'versions': {version: read(f'environment-{version}.json') for version in ['3.13', '3.14']},
        'provision': [
            {'version': '3.13', 'cwd': str(SCRATCH / 'candidate'), 'shell': '/bin/zsh -lc',
             'command': 'UV_CACHE_DIR=/tmp/plato-phase2a-review-4/uv-cache UV_PROJECT_ENVIRONMENT=/tmp/plato-phase2a-review-4/base-3.13 TMPDIR=/tmp/plato-phase2a-review-4/tmp uv sync --locked --no-default-groups --group test-base --python /Users/bli/.local/share/uv/python/cpython-3.13.16-macos-aarch64-none/bin/python3.13',
             'exit_code': 0, 'log': record(SCRATCH / 'logs/sync-3.13-corrected.log')},
            {'version': '3.14', 'cwd': str(SCRATCH / 'candidate'), 'shell': '/bin/zsh -lc',
             'command': 'UV_CACHE_DIR=/tmp/plato-phase2a-review-4/uv-cache UV_PROJECT_ENVIRONMENT=/tmp/plato-phase2a-review-4/base-3.14 TMPDIR=/tmp/plato-phase2a-review-4/tmp uv sync --locked --no-default-groups --group test-base --python 3.14.8 --no-managed-python',
             'exit_code': 0, 'log': record(SCRATCH / 'logs/sync-3.14.log')},
        ],
        'source_attribution': 'Each environment parent and fresh child resolves plato to the exact candidate export with the same interpreter prefix. Every saved current-candidate sample/recovery observation also points there. Prior-red reconstruction deliberately selects the byte-verified prior export through cwd and PYTHONPATH.',
        'environment_commands': {version: read(f'command-environment-{version}.json') for version in ['3.13', '3.14']},
    },
    'independent_validation': {
        **checks, 'static': static,
        'counts_overlap': True,
        'count_interpretation': 'Report each invocation separately. Focused 233 is contained in base 436; seven new author cases are contained in focused. The standalone original four and independent 99 repeat several public contracts, as do initial/corrected coupled runs. Counts are not summed into one total or attributed to distinct independent defects.',
        'base_skips': 'Exactly one absent-Opacus DP module and three explicitly optional Nanochat nodes per interpreter. No broad skips or warning suppressions.',
        'runtime_matrix': '48 unchanged runtime cases explicitly deselected as authorized. Linux and final merged-phase mandatory profiles remain root-owned.',
        'saved_observations': record(SCRATCH / 'observations.json'),
    },
    'correction_dispositions': [
        {'id': 'R2A3-01', 'status': 'The two originally demonstrated cases are resolved; generalized recovery remains blocked by R2A4-01',
         'evidence': 'Untouched minimal four-case reviewer script now passes independently on both versions. Default failed-readiness retry makes exactly three requests, restores referenced PNG, yields training-space labels and publishes completion only after readiness. Paused successful owner/contender constructors both succeed with exactly two requests. All 99 prior independent cases also pass.',
         'additional_lock_evidence': 'Real C flock observation in supplied tests confirms contender blocks, without replacing guard/download/readiness. New coupled control waits behind an owner whose incomplete archive fails readiness; after source restoration the waiter succeeds with exactly three requests total and one expected owner RuntimeError. No recursive lock deadlock. Unknown annotation classes reject despite canonical ZIP/completion artifacts.'},
        {'id': 'R2A2-01', 'status': 'RESOLVED controls preserved',
         'evidence': 'Actual Purchase/Texas malformed-cache raw rebuild and subsequent reuse, finite real float32 range, value-preserving integral IDs 0..99, native/non-native byte order, integral floats and bool cache-only fixtures pass; valid NPZ bytes remain unchanged. Source unchanged since prior review.'},
        {'id': 'R2A2-02 / R2A-04', 'status': 'Existing directory/annotation/required-image readiness controls pass; later default download-error cleanup remains open as R2A4-01',
         'evidence': 'Actual CINIC and configured/default Tiny HTTP/extraction restores missing required artifacts. Empty classes and missing native annotation references do not count as ready; incomplete recovery never publishes completion.'},
        {'id': 'R2A-01', 'status': 'Preserved',
         'evidence': 'Actual tracked cross-silo edge configure branch accepts both assigned IDs 4/5 with deterministic 600-index evaluation partitions. Invalid ordinary/unassigned/training/indexed roles reject; RNG checks pass.'},
        {'id': 'R2A-02', 'status': 'Preserved',
         'evidence': 'Actual paused NPZ writers and concurrent readers retain flock exclusion and unpublished final path. Normal completion and killed writers leave valid recoverable cache publication and clean abandoned temporary files. Complete raw-only and valid cache-only offline paths pass.'},
        {'id': 'R2A-03', 'status': 'Preserved',
         'evidence': 'Native/direct/nested and labeled prepared roots remain distinct. Official unlabeled test/images and unrelated incomplete manual native roots reject usefully. Generic lock and unrelated archive are insufficient recovery evidence.'},
        {'id': 'ROOT-2A-01 / ROOT-2A-02', 'status': 'Preserved',
         'evidence': 'Prepared evaluation subsets use training IDs with coherent metadata; unknown classes reject. Default Tiny evaluation is deterministic, finite and 3x299x299 with original normalization; custom transforms and stochastic training remain valid.'},
        {'id': 'F13', 'status': 'Preserved', 'evidence': 'Config optional reset, legacy singleton invalidation, repeated/reverse loads, include/CLI and client-speed RNG tests pass.'},
        {'id': 'F15', 'status': 'Preserved', 'evidence': 'Realized Dirichlet counts and repeated count/loader membership/private and caller RNG checks pass.'},
        {'id': 'F16 / seeded memberships', 'status': 'Preserved', 'evidence': 'Empty IID and infeasible sampling pools terminate under bounded subprocess guards; nonempty seeded membership and padding remain correct.'},
        {'id': 'EMNIST', 'status': 'Preserved', 'evidence': 'Actual local native IDX balanced/digits training and evaluation flags/counts/distinct labels pass.'},
        {'id': 'Archive containment', 'status': 'Preserved within accepted limits',
         'evidence': 'Actual TAR/ZIP traversal/absolute/link/symlink rejection, safe extraction, no outside writes or invalid completion/cache publication and lock owner-death controls pass on both versions.'},
    ],
    'source_and_scope_audit': {
        'production_changes_since_review3': ['plato/datasources/tiny_imagenet.py'],
        'other_changed_paths_since_review3': ['tests/datasources/test_review3_regressions.py', 'evidence/2026-refresh/phase2a-validation.json'],
        'guard_structure': '_default_recovery_layout acquires the existing stable-inode download guard, rechecks valid layout and artifact eligibility, then exits its context before DataSource.download independently acquires the guard. Valid layouts repaired by an earlier owner bypass download entirely.',
        'remaining_inconsistency': 'Canonical ZIP retention is true for incomplete post-extraction readiness, but base.py deletes that ZIP on request failures, size mismatches and caught archive/extraction errors. The fresh HTTP 503 and invalid-archive probes demonstrate deletion defeats the new default-source check.',
        'accepted_readiness': 'Existence, supported extensions, usable present classes and native annotation references. No full image-content decoding/checksum requirement or missing surviving prepared-class inventory detection without a manifest.',
        'no_unrelated_changes': 'All prior Config/sampler/vector/CINIC/EMNIST/base downloader/archive helpers, shared runtime, metadata/conftest, gitlinks and archived original bytes unchanged from prior candidate. No data format/protocol or unrelated security redesign requested.',
    },
    'archive_review': {
        'result': 'PASS', 'original_files': 14, 'byte_identical': True,
        'manifest': after['archives'], 'license': after['archive_license'],
        'active_reference_scan': after['active_archive_reference_scan'],
        'provenance': 'README preserves full baseline commit, old-to-new map, original history/authorship, historical environment/reconstruction and REFER defect evidence. Archive stays outside the shipped plato package; no active imports. Shared index/final packaging remain later root work.',
    },
    'author_and_root_evidence_attribution': {
        'candidate_validation': after['inputs']['candidate_validation'],
        'all_three_correction_histories_read': True,
        'author_identity_claims': after['author_identity_matches'],
        'retained_raw_artifacts': after['author_log_integrity'],
        'raw_artifacts_verified': len(after['author_log_integrity']),
        'evidence_audit': record(SCRATCH / 'evidence-audit.json'),
        'immutable_review_report_hash_checks': audit['author_history_reports'],
        'historical_candidate_evidence_hash_checks': audit['historical_candidate_evidence'],
        'previous_validation_copy': audit['previous_validation_copy'],
        'probe_source_hash_checks': audit['source_copy_checks'],
        'author_revision3_results': audit['raw_revision3_results'],
        'red_reconstruction': audit['prior_export'],
        'attribution': 'Retained original-author revision3 logs report 2 failed/5 passed red, 7 green, 233 focused and 436 base passed/4 allowed skips/48 runtime deselections on each interpreter. Hashes and raw counts match. Reviewer reconstruction independently reproduces the same two default failures and five controls on exact prior 150a production plus the new tests. Original reviewer-script author rerun (4 passed each) remains author verification; fresh current reviewer executions are separately recorded above.',
        'earlier_history_limits': 'Initial F16 object() harness and initial edge fixture AttributeErrors remain explicitly excluded as product evidence; corrected actual timeout/edge failures remain separately attributed. Earlier staged red states and /tmp alias/evidence-assembly harness corrections are retained. All earlier review verdicts remain unchanged. The current author observation-assembly alias issue was not a pytest/product failure.',
        'prior_root_base': 'Root 387-pass base evidence concerns older b728, not this candidate. The 429-pass prior review3 base is likewise historical. This review independently executed current candidate 436-pass base on both versions.',
        'historical_SSL_and_configs': 'Unchanged eight-config SSL and 160-config inventory evidence remains attributed to its original author/reviewers; no new SSL training/adapter/whole-stack support claim. Lightly is absent from both current base environments.',
    },
    'findings': [{
        'id': 'R2A4-01', 'severity': 'medium', 'status': 'open',
        'title': 'Default Tiny recovery still loses eligibility when failed download cleanup removes its canonical ZIP.',
        'locations': [
            {'path': 'plato/datasources/tiny_imagenet.py', 'line_start': 73, 'line_end': 78, 'primary': True},
            {'path': 'plato/datasources/base.py', 'line_start': 124, 'line_end': 128},
            {'path': 'plato/datasources/base.py', 'line_start': 163, 'line_end': 168},
        ],
        'trigger': 'Successfully construct/read Tiny through the canonical default URL, delete only one of two referenced validation PNGs while retaining directories/annotations/training and the original ZIP/completion, then make the recovery source return HTTP 503 for all three normal retry attempts. Restore the same HTTP source to the original complete ZIP and construct again. Invalid archive bodies trigger the same issue.',
        'actual': 'Recovery invalidates .complete under flock. The downloader deletes tiny-imagenet-200.zip on the first HTTP error (and after invalid archive extraction), then exhausts retries. The next constructor waits/acquires the guard but sees neither ZIP nor completion and raises the incomplete-native ValueError at tiny_imagenet.py:78. It sends no request to the now-restored source; required PNG remains absent. Default observation: four total requests (one success plus three failures), zero successful retry constructors, no completion, no canonical ZIP. Equivalent configured-source control: five requests, successful restored-source constructor, correct labels/finite sample access and offline reuse.',
        'expected': 'A root recognized as a prior default download stays eligible to retry after a bounded failed recovery when the source works again. Incomplete data must remain unmarked. Manual incomplete native/unlabeled roots lacking default artifacts still reject, and a generic lock/unrelated archive remains insufficient.',
        'impact': 'A transient HTTP outage while repairing one lost required image makes a previously default-downloaded dataset persistently unusable until manual intervention or configuration changes. The source can be healthy yet is never retried.',
        'reproduction': {
            'script': record(SCRATCH / 'test_coupled_recovery_corrected.py'),
            'versions': ['Python 3.13.16', 'Python 3.14.8'],
            'commands': {version: checks['coupled-corrected'][version]['command'] for version in ['3.13', '3.14']},
            'working_directory': str(SCRATCH / 'candidate'), 'shell': '/bin/zsh -lc',
            'minimal_test_selector': 'test_restored_source_can_retry_after_failed_recovery_download[http_503-tiny_default]',
            'method': 'Actual localhost ThreadingHTTPServer responses, ZIP extraction, two native classes, real annotations, default constructor and real finite transformed sample reads. Only requests.get URL dispatch redirects the asserted unchanged canonical URL to localhost. No download/readiness/guard patch, retries/sleeps patch, remote corpus, source edit or fixture weakening.',
            'results': {version: {'passed': 6, 'failed': 2, 'skipped': 0, 'warnings': 0,
                                  'failed_nodes': checks['coupled-corrected'][version]['failed_nodes'],
                                  'log': checks['coupled-corrected'][version]['log'],
                                  'junit': checks['coupled-corrected'][version]['junit']} for version in ['3.13', '3.14']},
            'observations': observations['coupled-corrected'],
            'independence': 'Both failure triggers retain the actual ValueError traceback/source and filesystem/request observations on the byte-verified candidate. Configured-source controls succeed in the same invocation.',
        },
        'required_fix': 'Preserve recognized default-source recovery eligibility through existing download-error cleanup under the same guard, while keeping incomplete completion absent. A bounded approach can retain the prior canonical archive while staging replacement attempts; do not rely on a generic lock, broaden acceptance of arbitrary manual native roots, or introduce a corpus manifest/new format/protocol. Add actual HTTP-error/invalid-archive -> restored-source constructor regressions on both versions, with configured and offline/labels/unknown-class/contention controls retained. Coordinate any necessary bounded downloader change with its existing owner.',
        'scope_and_attribution': 'Remaining R2A-04/R2A3-01 default recovery correctness coupled to unchanged base downloader cleanup, not a claim that request cleanup was newly added in 5f4749d. Original failed-readiness and successful contention reproductions pass. HTTP 503 performs no extraction or filesystem-corruption rollback, so this finding does not expand accepted archive rollback limits. Invalid archive is corroboration of the same eligibility loss, not a separate containment finding.',
        'routing': 'Original author fixes this bounded material issue, then another fresh independent exact-candidate review. Do not rewrite earlier reports/verdicts or treat this review as root acceptance.',
    }],
    'harness_disposition': {
        'initial_provision': 'Initial 3.13 uv call used --no-managed-python, which excluded the already-installed uv-managed interpreter and exited 2 before installing. Corrected by supplying its exact existing interpreter path. Initial log retained; no product failure or candidate edit.',
        'initial_provision_command': 'UV_CACHE_DIR=/tmp/plato-phase2a-review-4/uv-cache UV_PROJECT_ENVIRONMENT=/tmp/plato-phase2a-review-4/base-3.13 TMPDIR=/tmp/plato-phase2a-review-4/tmp uv sync --locked --no-default-groups --group test-base --python 3.13.16 --no-managed-python',
        'initial_provision_log': record(SCRATCH / 'logs/sync-3.13.log'),
        'initial_coupled': 'Initial coupled probe expected BadZipFile for a non-ZIP response; extract_archive detects non-ZIP and tries TAR, raising caught tarfile.ReadError after three retries. Those two bad_zip initial failures are excluded as harness failures. The HTTP default product failure already reproduced; other five nodes passed. Initial script/logs/JUnit/fixtures are retained unchanged.',
        'corrected_coupled': 'Separate corrected script permits precisely BadZipFile or tarfile.ReadError for failed invalid-archive recovery; all retry/readiness/marker/sample assertions remain. Both versions then show only the two actual default-source restored-retry ValueErrors, with six controls passing. No product red was reclassified as green or suppressed.',
        'finding_cardinality': 'HTTP and invalid-archive triggers are one shared material finding. Original/independent/coupled counts overlap; no totals across suites.',
    },
    'limits': [
        'macOS ARM64 CPU, CPython 3.13.16 and 3.14.8. Final merged-phase and Linux qualification remain root-owned.',
        'Fresh locked editable test-base exports were verified; wheel/sdist installed-artifact qualification not repeated. Optional support is not claimed from base skips.',
        '48 unchanged startup/socket cases deselected. No shared runtime, external adapter, MLX, metadata/CI or security-questionnaire work.',
        'Bounded local raw/IDX/PNG/native annotation fixtures and localhost HTTP only; no external corpus, full training accuracy, cloud service or accelerator qualification.',
        'Readiness checks existence/extensions/native references, not image decoding/checksums or loss of one prepared-class image when others survive without a manifest.',
        'NPZ publication covers successful same-filesystem replacement and killed writers, not power-loss/directory-fsync durability. Archive containment retains no-unrelated-concurrent-writer and no-corrupt-filesystem-rollback limits.',
        'No fresh SSL/160-config inventory campaign or historical multimodal support claim. Archived source/license remain preserved and inactive.',
        'One medium recovery finding blocks PASS; author correction plus another independent review and root integration remain required.',
    ],
    'retained_resources': {
        'scratch': str(SCRATCH), 'environments': [str(SCRATCH / f'base-{version}') for version in ['3.13', '3.14']],
        'exports': [str(SCRATCH / 'candidate'), str(SCRATCH / 'prior')],
        'retention': 'All reviewer-owned exports/tars, environments/caches, scripts, logs/JUnit, request/state observations and reproduction fixtures retained. All earlier author/reviewer resources left untouched.',
        'processes': 'All owned test commands completed. Local HTTP workers/constructor threads join in finally guards; subprocess regressions reap their owned children. No test service intentionally left running.',
        'artifacts': [record(path) for path in sorted(SCRATCH.glob('*.py'))] +
                     [record(path) for path in sorted((SCRATCH / 'logs').glob('*'))] +
                     [record(SCRATCH / 'observations.json'), record(SCRATCH / 'evidence-audit.json')],
    },
}
REPORT.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'verdict': report['verdict'], 'findings': ['R2A4-01'],
                  'report': record(REPORT), 'candidate_immutable': True}))
