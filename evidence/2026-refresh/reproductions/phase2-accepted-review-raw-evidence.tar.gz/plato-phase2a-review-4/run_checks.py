"""Run reviewer checks with an exact shell-command and result journal."""
import datetime
import json
import os
import shlex
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('/tmp/plato-phase2a-review-4')
version, action = sys.argv[1:]
environment = {
    'HF_HUB_OFFLINE': '1', 'HF_DATASETS_OFFLINE': '1',
    'PYTHONDONTWRITEBYTECODE': '1', 'OMP_NUM_THREADS': '1',
    'MKL_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1',
    'VECLIB_MAXIMUM_THREADS': '1', 'NUMEXPR_NUM_THREADS': '1',
    'TOKENIZERS_PARALLELISM': 'false',
    'XDG_CACHE_HOME': str(ROOT / 'cache'), 'TMPDIR': str(ROOT / 'tmp'),
    'PYTHONPATH': str(ROOT / 'candidate'),
}
python = str(ROOT / f'base-{version}/bin/python')
focused = [
    'tests/test_config_loader.py', 'tests/samplers',
    'tests/datasources/test_registry.py',
    'tests/datasources/test_torchvision_datasource.py',
    'tests/datasources/test_feature_dataset.py',
    'tests/datasources/test_feature_datasource.py',
    'tests/datasources/test_data_loaders.py',
    'tests/datasources/test_download_contracts.py',
    'tests/datasources/test_local_datasets.py',
    'tests/datasources/test_review_regressions.py',
    'tests/datasources/test_review2_regressions.py',
    'tests/datasources/test_review3_regressions.py',
    'tests/utils/test_archive.py',
]
args = {
    'environment': [python, str(ROOT / 'environment_probe.py'), version],
    'focused': [python, '-m', 'pytest', *focused, '--test-profile=base'],
    'base': [python, '-m', 'pytest', 'tests', '--test-profile=base', '-m', 'not runtime'],
    'independent': [python, '-m', 'pytest', str(ROOT / 'test_independent_contracts.py'),
                    str(ROOT / 'test_prior_remaining_contracts.py')],
    'original': [python, '-m', 'pytest', str(ROOT / 'test_default_recovery_negative.py'), '-s'],
    'coupled': [python, '-m', 'pytest', str(ROOT / 'test_coupled_recovery.py'), '-s'],
    'previous-red': [python, '-m', 'pytest', 'tests/datasources/test_review3_regressions.py', '--test-profile=base'],
    'coupled-corrected': [python, '-m', 'pytest', str(ROOT / 'test_coupled_recovery_corrected.py'), '-s'],
}[action]
if action != 'environment':
    args += ['-ra', '-p', 'no:cacheprovider',
             '--basetemp=' + str(ROOT / f'{action}-{version}-fixtures'),
             '--junitxml=' + str(ROOT / f'logs/{action}-{version}.xml')]
cwd = ROOT / ('prior' if action == 'previous-red' else 'candidate')
if action == 'previous-red':
    environment['PYTHONPATH'] = str(cwd)
command = ' '.join(shlex.quote(k + '=' + v) for k, v in environment.items()) + ' ' + shlex.join(args)
log = ROOT / f'logs/{action}-{version}.log'
result = {'action': action, 'version': version, 'shell': '/bin/zsh -lc',
          'command': command, 'cwd': str(cwd), 'log': str(log),
          'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
start = time.monotonic()
with log.open('wb') as output:
    proc = subprocess.run(['/bin/zsh', '-lc', command], cwd=cwd,
                          stdout=output, stderr=subprocess.STDOUT, timeout=300)
result.update(exit_code=proc.returncode, seconds=time.monotonic() - start)
(ROOT / f'command-{action}-{version}.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
print(log.read_text()[-2400:])
sys.exit(proc.returncode)
