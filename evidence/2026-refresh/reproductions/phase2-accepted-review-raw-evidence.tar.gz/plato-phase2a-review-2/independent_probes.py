"""Fresh Phase 2A public-behavior probes; writes only review scratch."""
import argparse
import contextlib
import http.server
import io
import json
import os
import selectors
import shutil
import subprocess
import sys
import threading
import time
import zipfile
from pathlib import Path
from unittest.mock import patch

import numpy as np
import torch
from PIL import Image

import plato
from plato.config import Config
from plato.datasources import base, cinic10, purchase, texas, tiny_imagenet
from plato.samplers import registry


def config(root):
    Config.reset()
    Config._instance = object.__new__(Config)
    Config.data = Config.node_from_dict({"random_seed": 41})
    Config.params = {"data_path": str(root)}


def image(path, gradient=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    if gradient:
        y, x = np.indices((64, 91))
        pixels = np.stack((y * 3, x * 2, (x + y)), axis=2).astype(np.uint8)
        Image.fromarray(pixels).save(path)
    else:
        Image.new("RGB", (13, 19), (10, 20, 30)).save(path)


def raw(root, name):
    root.mkdir(parents=True)
    if name == "purchase":
        (root / "dataset_purchase").write_text("1,0.1,0.2\n2,0.3,0.4\n3,0.5,0.6\n")
    else:
        folder = root / "texas/100"
        folder.mkdir(parents=True)
        (folder / "feats").write_text("0.1,0.2\n0.3,0.4\n0.5,0.6\n")
        (folder / "labels").write_text("1\n2\n3\n")


def child(mode, root, name):
    config(root)
    module = purchase if name == "purchase" else texas
    if mode == "writer":
        original = np.savez

        class PausedFile:
            def __init__(self, handle):
                self.handle = handle
                self.first = True

            def __getattr__(self, name):
                return getattr(self.handle, name)

            def write(self, value):
                result = self.handle.write(value)
                self.handle.flush()
                if self.first:
                    self.first = False
                    print("header", flush=True)
                    assert sys.stdin.readline().strip() == "release"
                return result

        def save(file, **kwargs):
            with contextlib.nullcontext(file) if hasattr(file, "write") else open(file, "wb") as handle:
                return original(PausedFile(handle), **kwargs)

        np.savez = save
    else:
        print("reader", flush=True)
    with patch.object(module.request, "urlretrieve", side_effect=AssertionError("offline raw")):
        source = module.DataSource()
    assert source.num_train_examples() == 3
    assert sorted(source.targets().tolist()) == [0, 1, 2]
    print("done", flush=True)


def line(process, expected):
    with selectors.DefaultSelector() as selector:
        selector.register(process.stdout, selectors.EVENT_READ)
        assert selector.select(15), expected + " timeout"
        actual = process.stdout.readline().strip()
        assert actual == expected, (actual, expected)


def concurrency(root):
    results = []
    for name in ("purchase", "texas"):
        for killed in (False, True):
            dest = root / (name + ("-killed" if killed else "-live"))
            raw(dest, name)
            writer = reader = None
            try:
                writer = subprocess.Popen([sys.executable, __file__, "writer", str(dest), name],
                                          stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                          stderr=subprocess.PIPE, text=True)
                line(writer, "header")
                final = dest / (name + "_numpy.npz")
                assert not final.exists()
                pending = list(dest.glob(".*.tmp"))
                assert len(pending) == 1 and pending[0].read_bytes().startswith(b"PK")
                reader = subprocess.Popen([sys.executable, __file__, "reader", str(dest), name],
                                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                line(reader, "reader")
                try:
                    reader.communicate(timeout=0.4)
                    raise AssertionError("reader bypassed locked real writer")
                except subprocess.TimeoutExpired:
                    pass
                if killed:
                    writer.kill()
                    writer.communicate(timeout=15)
                else:
                    out, err = writer.communicate("release\n", timeout=15)
                    assert writer.returncode == 0 and "done" in out, err
                out, err = reader.communicate(timeout=15)
                assert reader.returncode == 0 and "done" in out, err
                with np.load(final, allow_pickle=False) as loaded:
                    np.testing.assert_allclose(loaded["X"], [[.1, .2], [.3, .4], [.5, .6]])
                    np.testing.assert_array_equal(loaded["Y"], [0, 1, 2])
                assert not list(dest.glob(".*.tmp"))
                results.append({"dataset": name, "killed": killed, "blocked_before_release": True,
                                "atomic_publication": True, "valid_rebuilt_arrays": True})
            finally:
                for process in (writer, reader):
                    if process is not None and process.poll() is None:
                        process.kill()
                        process.communicate(timeout=15)
    return results


def cache_inputs(root):
    results = []
    for name, module in (("purchase", purchase), ("texas", texas)):
        for kind in ("raw-only", "cache-only", "crc-damage", "object-array", "string-features", "float-labels", "zero-features"):
            dest = root / (name + "-" + kind)
            raw(dest, name)
            cache = dest / (name + "_numpy.npz")
            features, labels = np.array([[.1, .2], [.3, .4], [.5, .6]]), np.array([0, 1, 2])
            if kind == "object-array":
                features = np.array([[object()], [object()], [object()]], dtype=object)
            elif kind == "string-features":
                features = np.array([["broken"], ["broken"], ["broken"]])
            elif kind == "float-labels":
                labels = np.array([.7, 1.7, 2.7])
            elif kind == "zero-features":
                features = np.zeros((3, 0))
            if kind != "raw-only":
                np.savez(cache, X=features, Y=labels)
            if kind == "crc-damage":
                with zipfile.ZipFile(cache) as archive:
                    info = archive.getinfo("X.npy")
                    offset = info.header_offset + 30 + len(info.filename.encode()) + len(info.extra)
                content = bytearray(cache.read_bytes())
                # Find the actual NPY payload (savez uses an extra ZIP64 field).
                offset = content.index(b"\x93NUMPY", offset)
                content[offset + 100] ^= 1
                cache.write_bytes(content)
            if kind == "cache-only":
                if name == "purchase": (dest / "dataset_purchase").unlink()
                else: shutil.rmtree(dest / "texas")
            config(dest)
            with patch.object(module.request, "urlretrieve", side_effect=AssertionError("unexpected network")):
                try:
                    source = module.DataSource()
                    outcome = {"loaded": True, "shape": list(source.trainset.data.shape),
                               "targets": source.targets().tolist()}
                    with np.load(cache) as loaded:
                        outcome["cache_dtype"] = str(loaded["X"].dtype)
                except Exception as exc:
                    outcome = {"loaded": False, "error_type": type(exc).__name__, "error": str(exc)}
            if kind in ("raw-only", "cache-only", "crc-damage", "object-array"):
                assert outcome["loaded"] and sorted(outcome["targets"]) == [0, 1, 2], outcome
            results.append({"dataset": name, "input": kind, **outcome})
    return results


def edges(root):
    os.environ.pop("config_file", None)
    saved_argv = sys.argv[:]
    results = []
    try:
        for edge_id in (4, 5):
            sys.argv = ["probe", "-c", "configs/MNIST/fedavg_cross_silo_lenet5.toml", "--base", str(root / str(edge_id)), "-i", str(edge_id), "-p", "8101"]
            Config.reset()
            Config()
            assert Config.is_edge_server()
            Config.server.edge_do_test = True
            Config.data.testset_sampler = "noniid"
            Config.data.random_seed = 19
            from plato.servers import fedavg, fedavg_cs

            class Dataset:
                targets = [0, 1] * 500
                def __len__(self): return 1000

            class Source:
                def get_test_set(self): return Dataset()
                def classes(self): return ["n001", "n002"]
                def targets(self): return Dataset.targets

            class Trainer:
                def set_client_id(self, value): self.client_id = value

            source, trainer = Source(), Trainer()
            server = object.__new__(fedavg_cs.Server)
            server.init_trainer = lambda: None
            server.require_trainer = lambda: trainer
            state = np.random.get_state()
            with patch.object(fedavg.Server, "configure", lambda self: None), patch.object(fedavg_cs.datasources_registry, "get", return_value=source), patch.object(fedavg_cs.processor_registry, "get", return_value=(None, None)):
                server.configure()
            sampler = server.testset_sampler
            indices = list(sampler.get())
            assert len(indices) == len(set(indices)) == sampler.num_samples() == 600
            np.testing.assert_array_equal(np.random.get_state()[1], state[1])
            assert trainer.client_id == edge_id
            assert list(registry.get(source, edge_id, testing=True, sampler_type="noniid").get()) == indices
            rejected = []
            for value, testing in ((0, True), (6, True), (9 - edge_id, True), (edge_id, False)):
                try: registry.get(source, value, testing=testing, sampler_type="noniid")
                except ValueError: rejected.append([value, testing])
                else: raise AssertionError((value, testing))
            # Indexed IID may not take advantage of the role exception.
            try: registry.get(source, edge_id, testing=True, sampler_type="iid")
            except ValueError: pass
            else: raise AssertionError("indexed edge accepted")
            results.append({"edge_id": edge_id, "count": len(indices), "rejected": rejected})
        Config.algorithm.cross_silo = False
        try: registry.get(source, 5, testing=True, sampler_type="noniid")
        except ValueError: pass
        else: raise AssertionError("ordinary role accepted edge ID")
    finally:
        sys.argv = saved_argv
    return results


@contextlib.contextmanager
def serve(payload):
    requests = []
    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            requests.append(self.path)
            self.send_response(200)
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
        def log_message(self, *args): pass
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": .01})
    thread.start()
    try: yield f"http://127.0.0.1:{server.server_port}/fixture.zip", requests
    finally:
        server.shutdown()
        thread.join(3)
        server.server_close()
        assert not thread.is_alive()


def image_cases(root):
    results = []
    for name, module in (("cinic", cinic10), ("tiny", tiny_imagenet)):
        dest = root / (name + "-subset")
        for filename in ("train/n001/a.png", "train/n002/b.png", "test/n002/z.png"):
            image(dest / filename, gradient=True)
        config(dest)
        source = module.DataSource()
        train, test = source.trainset, source.testset
        assert test.targets == [1] and test.samples[0][1] == test[0][1] == 1
        assert test.classes == train.classes == ["n001", "n002"]
        assert test.class_to_idx == train.class_to_idx == {"n001": 0, "n002": 1}
        assert test.samples == test.imgs
        tensors = [test[0][0] for _ in range(5)]
        assert all(torch.equal(tensors[0], t) for t in tensors[1:])
        if name == "tiny":
            assert tensors[0].shape == (3, 299, 299)
            torch.manual_seed(314)
            augmented = [train[0][0] for _ in range(5)]
            assert any(not torch.equal(augmented[0], t) for t in augmented[1:])
            custom = module.DataSource(train_transform=lambda img: "train", test_transform=lambda img: "test")
            assert custom.trainset[0] == ("train", 0) and custom.testset[0] == ("test", 1)
        image(dest / "test/n999/bad.png")
        try: module.DataSource()
        except ValueError as exc: assert "Unknown evaluation classes" in str(exc)
        else: raise AssertionError("unknown class accepted")
        results.append({"dataset": name, "subset_label": 1, "deterministic_eval": True, "unknown_class_rejected": True})
    for nested in (False, True):
        dest = root / ("incomplete-" + str(nested))
        native = dest / "tiny-imagenet-200" if nested else dest
        for filename in ("train/n001/images/a.png", "train/n002/images/b.png", "test/images/u.png"):
            image(native / filename)
        config(dest)
        with patch.object(base.requests, "get", side_effect=AssertionError("incomplete local root must reject")):
            try: tiny_imagenet.DataSource()
            except ValueError as exc: assert "unlabeled" in str(exc)
            else: raise AssertionError("fabricated class images")
        results.append({"incomplete_native_nested": nested, "rejected": True})
    return results


def recovery(root):
    results = []
    png = io.BytesIO()
    Image.new("RGB", (8, 8), (10, 20, 30)).save(png, format="PNG")
    for name, module, default in (("cinic", cinic10, False), ("tiny", tiny_imagenet, False), ("tiny-default", tiny_imagenet, True)):
        for damage in ("required-directory-or-annotation", "image-file"):
            dest = root / (name + "-" + damage)
            stream = io.BytesIO()
            prefix = "" if module is cinic10 else "tiny-imagenet-200/"
            train = prefix + "train/n001/images/a.png"
            eval_image = "test/n001/z.png" if module is cinic10 else prefix + "val/images/z.png"
            with zipfile.ZipFile(stream, "w") as zipped:
                zipped.writestr(train, png.getvalue())
                zipped.writestr(eval_image, png.getvalue())
                if module is tiny_imagenet:
                    zipped.writestr(prefix + "val/val_annotations.txt", "z.png\tn001\t0\t0\t8\t8\n")
            config(dest)
            real_get = base.requests.get
            with serve(stream.getvalue()) as (url, hits):
                if not default: Config.data.download_url = url
                def redirect(requested, **kwargs):
                    assert requested == "https://cs231n.stanford.edu/tiny-imagenet-200.zip"
                    return real_get(url, **kwargs)
                with patch.object(base.requests, "get", side_effect=redirect) if default else contextlib.nullcontext():
                    initial = module.DataSource()
                    assert initial.num_test_examples() == 1 and initial.testset[0][1] == 0
                    expected = torch.tensor([(10/255-.485)/.229, (20/255-.456)/.224, (30/255-.406)/.225])
                    if module is tiny_imagenet:
                        torch.testing.assert_close(initial.testset[0][0][:, 0, 0], expected, atol=1e-6, rtol=0)
                    if damage == "required-directory-or-annotation":
                        if module is cinic10: shutil.rmtree(dest / "test")
                        else: (dest / prefix / "val/val_annotations.txt").unlink()
                    else: (dest / eval_image).unlink()
                    try:
                        rebuilt = module.DataSource()
                        value = rebuilt.testset[0]
                        outcome = {"recovered": True, "label": value[1], "requests": len(hits)}
                    except Exception as exc:
                        outcome = {"recovered": False, "error_type": type(exc).__name__, "error": str(exc), "requests": len(hits)}
                    if damage == "required-directory-or-annotation": assert outcome["recovered"] and len(hits) == 2, outcome
            if outcome["recovered"]:
                with patch.object(base.requests, "get", side_effect=AssertionError("valid roots offline")):
                    assert module.DataSource().num_test_examples() == 1
            results.append({"dataset": name, "damage": damage, **outcome})
    return results


def main(root):
    root.mkdir(parents=True, exist_ok=False)
    result = {"python": sys.version, "source": plato.__file__, "environment": sys.prefix, "results": {}}
    for name, fn in (("edges", edges), ("concurrency", concurrency), ("cache_inputs", cache_inputs), ("image_cases", image_cases), ("recovery", recovery)):
        try: result["results"][name] = {"completed": True, "cases": fn(root / name)}
        except Exception as exc:
            import traceback
            result["results"][name] = {"completed": False, "error": str(exc), "traceback": traceback.format_exc()}
        (root / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    assert all(group["completed"] for group in result["results"].values())


if __name__ == "__main__":
    if sys.argv[1] in ("reader", "writer"):
        child(sys.argv[1], Path(sys.argv[2]), sys.argv[3])
    else: main(Path(sys.argv[1]))
