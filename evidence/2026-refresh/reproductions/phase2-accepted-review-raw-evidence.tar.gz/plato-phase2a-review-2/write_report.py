import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import xml.etree.ElementTree as ET

scratch = pathlib.Path('/tmp/plato-phase2a-review-2')
candidate = pathlib.Path('/private/tmp/plato-refresh-worktrees/data')
root = pathlib.Path('/Users/bli/Playground/plato/evidence/2026-refresh')
identity = json.loads((scratch / 'identity.json').read_text())
source_audit = json.loads((scratch / 'source-audit.json').read_text())
probes = {version: json.loads((scratch / ('probes' + version) / 'results.json').read_text()) for version in ('313', '314')}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def artifact(path):
    return {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}

common_env = 'HF_HUB_OFFLINE=1 HF_DATASETS_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1'
py313 = str(scratch / 'base313/bin/python')
py314 = str(scratch / 'candidate/.venv/bin/python')
remaining_command = common_env + ' PYTHONPATH=/tmp/plato-phase2a-review-2/candidate {python} -m pytest /tmp/plato-phase2a-review-2/test_remaining_contracts.py -q --basetemp=/tmp/plato-phase2a-review-2/remaining{version}-fixtures --junitxml=/tmp/plato-phase2a-review-2/logs/remaining{version}.xml > /tmp/plato-phase2a-review-2/logs/remaining{version}.log 2>&1'
focused_args = 'tests/test_config_loader.py tests/samplers tests/datasources/test_registry.py tests/datasources/test_torchvision_datasource.py tests/datasources/test_feature_dataset.py tests/datasources/test_feature_datasource.py tests/datasources/test_data_loaders.py tests/datasources/test_download_contracts.py tests/datasources/test_local_datasets.py tests/datasources/test_review_regressions.py tests/utils/test_archive.py'

def env_snapshot(executable):
    code = "import importlib.util,importlib.metadata,json,platform,sys,plato;print(json.dumps({'python':sys.version,'executable':sys.executable,'prefix':sys.prefix,'source_import':plato.__file__,'platform':platform.platform(),'packages':{x:importlib.metadata.version(x) for x in ['plato-learn','numpy','torch','torchvision','requests','pytest','pytest-cov']},'optional_available':{x:importlib.util.find_spec(x) is not None for x in ['opacus','kazoo','gymnasium','tiktoken','lightly']}}))"
    env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}
    return json.loads(subprocess.check_output([executable, '-c', code], cwd=scratch / 'candidate', env=env, text=True))

xml_results = {}
for name in ('base314', 'focused313', 'remaining313', 'remaining314'):
    tree = ET.parse(scratch / 'logs' / (name + '.xml'))
    suite = tree.getroot().find('testsuite')
    xml_results[name] = dict(suite.attrib)
    xml_results[name]['failure_nodes'] = [node.attrib['name'] for node in suite.findall('testcase') if node.find('failure') is not None]

report = {
    'schema_version': 1,
    'reviewer': 'plato-phase2a-review-2',
    'review_role': 'Fresh independent Phase 2A correction reviewer; no delegated or nested agents.',
    'review_date': '2026-10-03',
    'written_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'verdict': 'CHANGES_REQUESTED',
    'decision': 'CHANGES_REQUESTED',
    'summary': 'The original edge-ID, NPZ publication/locking, unlabeled-native-layout, label-subset and deterministic-transform reproductions pass. Directory/annotation marker recovery passes, including the default Tiny URL. Two medium gaps remain: malformed numeric cache semantics are trusted, and stale roots with missing required evaluation images bypass recovery. Both gaps reproduce on Python 3.13.16 and 3.14.8.',
    'finding_counts': {'critical': 0, 'high': 0, 'medium': 2, 'low': 0},
    'identity': {
        **identity,
        'candidate_head_at_start': 'b728a5b71d0945828dcf288a39b796b1e0fb4ec7',
        'candidate_tree_at_start': 'b0879eb78803b379d6888d4cc208fd8f914eb610',
        'candidate_status_at_start': '',
        'candidate_immutable': True,
        'phase_base': 'fda60becedfa6236c11d415b87a868b52789a41e',
        'assigned_candidate_worktree': str(candidate),
        'isolated_snapshot': str(scratch / 'candidate'),
        'snapshot_creation': 'git archive b728a5b71d0945828dcf288a39b796b1e0fb4ec7 | tar -xf - -C /tmp/plato-phase2a-review-2/candidate',
        'snapshot_verification': 'All 942 tracked non-gitlink blobs matched their exact candidate Git blob IDs after independent tests. Three unrelated gitlinks remain uninitialized in the snapshot; no submodule contents were changed.',
        'correction_commits': ['ee3d9ccd5467276f4f8abc257769461b467dfced', 'f2c77a071b67cef9b2ee954f94d565c4eddaf0d9'],
        'terminal_evidence_only_child_verified': 'git diff-tree f2c77a071b67cef9b2ee954f94d565c4eddaf0d9 b728a5b71d0945828dcf288a39b796b1e0fb4ec7 changes only evidence/2026-refresh/phase2a-validation.json.',
    },
    'write_scope_and_authority': {
        'sole_root_write': str(root / 'phase2a-review-2.json'),
        'scratch': str(scratch),
        'production_edits': 0,
        'commits_created': 0,
        'pushes': 0,
        'agents_spawned': 0,
        'shared_metadata_or_runtime_edits': 0,
        'security_questionnaires': 0,
        'shell': 'Every shell call used exec_command(shell=/bin/zsh, login=true), i.e. zsh -lc.',
        'candidate_execution_policy': 'Execution and installation used only the exact exported scratch snapshot; original candidate was read only.',
        'guidance': str(candidate / 'AGENTS.md'),
    },
    'accepted_and_prior_sources_read': {
        name: artifact(root / name) for name in ('plan.md', 'plan-addendum.json', 'plan-review-3.json', 'plan-addendum-acceptance.json', 'phase1-acceptance.json', 'phase1a-acceptance.json', 'phase1b-acceptance.json', 'phase1c-acceptance.json', 'phase2a-review.json', 'phase2a-root-probes.json', 'phase2a-root-base-validation.json')
    },
    'environment': {
        '3.13': env_snapshot(py313),
        '3.14': env_snapshot(py314),
        'uv': subprocess.check_output(['uv', '--version'], text=True).strip(),
        'sync_commands': [
            'uv sync --project /tmp/plato-phase2a-review-2/candidate --locked --python 3.14 --no-default-groups --group test-base > /tmp/plato-phase2a-review-2/logs/sync-base314.log 2>&1',
            'UV_PROJECT_ENVIRONMENT=/tmp/plato-phase2a-review-2/base313 uv sync --project /tmp/plato-phase2a-review-2/candidate --locked --python 3.13 --no-default-groups --group test-base > /tmp/plato-phase2a-review-2/logs/sync-base313.log 2>&1',
        ],
        'sync_exit_codes': {'3.13': 0, '3.14': 0},
        'profile': 'Clean locked test-base; opacus, kazoo, gymnasium, tiktoken and lightly all independently verified absent in both environments. No optional packages added to make A collect.',
        'working_directory_for_execution': str(scratch / 'candidate'),
        'source_attribution': 'Each interpreter editable installation and main/child source resolution point to the exact scratch candidate, not another phase worktree.',
    },
    'independent_validation': {
        'focused_python313': {
            'command': common_env + ' TOKENIZERS_PARALLELISM=false ' + py313 + ' -m pytest ' + focused_args + ' --test-profile=base -ra --basetemp=/tmp/plato-phase2a-review-2/focused313-fixtures --junitxml=/tmp/plato-phase2a-review-2/logs/focused313.xml > /tmp/plato-phase2a-review-2/logs/focused313.log 2>&1',
            'exit_code': 0, 'passed': 184, 'failed': 0, 'skipped': 0, 'warnings': 0, 'seconds': 19.18,
        },
        'clean_base_python314': {
            'command': common_env + ' TOKENIZERS_PARALLELISM=false .venv/bin/python -m pytest tests --test-profile=base -m \'not runtime\' -ra --basetemp=/tmp/plato-phase2a-review-2/base314-fixtures --junitxml=/tmp/plato-phase2a-review-2/logs/base314.xml > /tmp/plato-phase2a-review-2/logs/base314.log 2>&1',
            'exit_code': 0, 'passed': 387, 'failed': 0, 'permitted_optional_skips': 4, 'runtime_deselected': 48, 'warnings': 0, 'seconds': 57.91,
            'skip_details': ['One collection-time tests/trainers/test_dp_data_loader_strategy.py skip: base profile optional dp: opacus not installed.', 'Three exact tests/test_nanochat_integration.py skips: base profile omits optional nanochat integration.'],
            'new_A_tests': 'All 184 focused candidate tests, including actual configure and writer/reader regressions, execute within this clean base run; no additional optional imports or skips were needed.',
            'unchanged_runtime_suite': '48 accepted startup/socket cases deliberately deselected; data-only changes did not justify mechanically repeating that expensive suite.',
        },
        'fresh_public_behavior_probes': {
            'command': common_env + ' PYTHONPATH=/tmp/plato-phase2a-review-2/candidate {python} /tmp/plato-phase2a-review-2/independent_probes.py /tmp/plato-phase2a-review-2/probes{version} > /tmp/plato-phase2a-review-2/logs/probes{version}.log 2>&1',
            'parameter_mapping': {'313': py313, '314': py314},
            'exit_codes': {'313': 0, '314': 0},
            'interpretation': 'Harness completion is not a blanket green result. It asserts positive/required controls and records exploratory malformed-cache/missing-image outcomes, including the failures reported below.',
            'source': artifact(scratch / 'independent_probes.py'),
            'results': probes,
        },
        'explicit_remaining_contract_regressions': {
            'command': remaining_command,
            'parameter_mapping': {'313': py313, '314': py314},
            '3.13': {'exit_code': 1, 'failed': 7, 'passed': 0, 'skipped': 0, 'warnings': 0, 'seconds': 4.13},
            '3.14': {'exit_code': 1, 'failed': 7, 'passed': 0, 'skipped': 0, 'warnings': 0, 'seconds': 39.77},
            'failure_mapping': 'Four cache regressions (two malformed forms for each dataset) and three missing-image regressions (CINIC, Tiny configured URL, Tiny default URL). All failures originate in actual datasource construction/sample loading or unchanged invalid cache arrays, not missing optional dependencies.',
            'source': artifact(scratch / 'test_remaining_contracts.py'),
        },
        'static': {
            'ruff': {'command': '/tmp/plato-phase2a-lZqbqj/venv-3.13/bin/ruff check plato/config.py plato/datasources plato/samplers tests/test_config_loader.py tests/samplers/test_partition_contracts.py tests/datasources/test_download_contracts.py tests/datasources/test_local_datasets.py tests/datasources/test_review_regressions.py plato/utils/archive.py tests/utils/test_archive.py --select I', 'result': 'All checks passed!', 'exit_code': 0},
            'ty': {'command': '/tmp/plato-phase2a-lZqbqj/venv-3.13/bin/ty check plato/config.py plato/datasources/base.py plato/datasources/cinic10.py plato/datasources/purchase.py plato/datasources/texas.py plato/datasources/tiny_imagenet.py plato/datasources/_vector_cache.py plato/datasources/_image_folder.py plato/datasources/feature.py plato/datasources/feature_dataset.py plato/datasources/femnist.py plato/datasources/registry.py plato/datasources/self_supervised_learning.py plato/datasources/torchvision.py plato/samplers plato/utils/archive.py --output-format concise', 'result': 'All checks passed!', 'exit_code': 0},
            'environment_limit': 'Read-only existing Ruff/ty executables reused from author scratch; source/cwd was this reviewer snapshot. No existing author environment was installed into or altered.',
            'diff_check': {'command': 'git diff --check fda60becedfa6236c11d415b87a868b52789a41e b728a5b71d0945828dcf288a39b796b1e0fb4ec7', 'exit_code': 0},
        },
        'junit_summary': xml_results,
    },
    'correction_dispositions': [
        {'id': 'R2A-01', 'status': 'RESOLVED', 'evidence': 'Actual fedavg_cs.Server.configure branch on both interpreters accepts each assigned edge ID 4/5 from the tracked 3-client/2-silo config, generates 600 unique in-range samples, retains seeded membership/counts, and preserves caller NumPy RNG. Independent role mismatch, unassigned edge, out-of-range, training and indexed-IID checks reject; author six negative role tests also execute in both suites.', 'limit': 'Model/processor setup was injected and parent configure stubbed; this is actual edge configure/sampler behavior, not a socket/training qualification.'},
        {'id': 'R2A-02', 'status': 'ORIGINAL_CONCURRENCY_AND_INTERRUPTION_REPRODUCTIONS_RESOLVED', 'evidence': 'On both interpreters and both datasets, pause actual np.savez after its first private ZIP write; reader starts and stays blocked; no final cache pathname exists. Release or SIGKILL the real writer; reader subsequently publishes/loads correct X/Y arrays and abandonded temporary files disappear. Valid raw-only/cache-only offline paths, CRC-damaged and object caches recover. Supplied truncated/missing-Y/shape mismatch tests also execute.', 'remaining_related_finding': 'R2A2-01: new shape-only validation still trusts incompatible feature/label content.'},
        {'id': 'R2A-03', 'status': 'RESOLVED', 'evidence': 'Direct and nested official/native roots with train wnids and unlabeled test/images but no val annotations reject usefully without fabricated classes or unexpected downloads. Valid direct/nested native and prepared layouts execute in both supported-version suites.'},
        {'id': 'R2A-04', 'status': 'PARTIALLY_RESOLVED', 'evidence': 'Actual localhost download, deletion of CINIC test/ or Tiny val_annotations.txt, and re-instantiation cause two HTTP requests and restore the artifact. Tiny configured and default URL dispatch both pass; valid roots work offline with network explicitly prohibited.', 'remaining_related_finding': 'R2A2-02: deleting required evaluation images while retaining parent directories/annotation still bypasses recovery.'},
        {'id': 'ROOT-2A-01', 'status': 'RESOLVED', 'evidence': 'Actual CINIC and Tiny prepared training [n001,n002] with only n002 evaluation map samples, imgs, targets, __getitem__, classes and class_to_idx into training ID 1; n999 evaluation rejects. Missing training classes in evaluation are supported.'},
        {'id': 'ROOT-2A-02', 'status': 'RESOLVED', 'evidence': 'Five repeated evaluations of one non-square gradient image are bit-identical. Training remains stochastic; Tiny output stays (3,299,299), known constant pixel normalization matches independent arithmetic, and separate custom train/test callables are respected. Both native/prepared variant tests pass on both interpreters.'},
    ],
    'preserved_acceptance': {
        'F13': 'Supplied reset/reload tests execute independently on both interpreters, including optional-section isolation in repeated/reverse load order and CLI overrides; reset clears annotated singleton state.',
        'F15': 'Realized Dirichlet count, loader size, repeated count private/global RNG invariance and seeded repeat membership pass on both interpreters; correction changes only the edge opt-in path.',
        'F16': 'Timeout-guarded empty IID rejection and empty extend_indices tests pass; literal legacy padding memberships [2,4,3,1] and [1,0,2,4] remain correct.',
        'seeded_partition_contracts': 'Registry-wide deterministic sampling and caller NumPy/Python/Torch RNG isolation, full class coverage, sample-quantity labels, modality and feasibility checks pass in both environments.',
        'EMNIST': 'Actual local native IDX balanced/digits train/test labels and flags pass, with training labels [0,1,2] and evaluation [7,8].',
        'image_transform_compatibility': 'Existing torchvision datasource transform/customization tests execute in both suites. No SSL source changes in the correction diff.',
        'archive_containment': 'Supplied real TAR/ZIP extraction and active downloader tests execute on both interpreters: traversal, absolute names, TAR symlink/hardlink escapes, preexisting symlink destinations, safe extraction/reuse, useful failures and no completion on failed extraction.',
        'archives': source_audit['archived_files'],
        'archive_license_identical': source_audit['license_identical'],
        'archive_provenance': 'All 14 relocated original blobs and copied baseline LICENSE are byte-identical. New README documents inactive legacy status and known REFER evidence. Active Python reference/import scan across plato/tests/examples found no archive/datalib imports.',
        'metadata_and_runtime': 'No shared manifest/lock/CI/conftest or clients/servers/trainers runtime changes from phase base; unchanged startup suite not repeated.',
    },
    'author_and_root_evidence_attribution': {
        'candidate_validation': artifact(candidate / 'evidence/2026-refresh/phase2a-validation.json'),
        'exact_identity_checks': 'Author final implementation tree and both binary-diff SHA256 claims independently recomputed and matched. b728a5b differs from f2c77a0 only by its evidence file.',
        'revision_log_integrity': source_audit['revision_log_integrity'],
        'author_red_green': 'Read retained red/green outputs. Final author logs say 184 passed in 9.96s (3.13) and 46.08s (3.14). Every 12 revision log hash matches the exact new JSON. Initial edge fixture AttributeError is explicitly excluded by author; corrected edge-red logs show actual range ValueError. Staged default-URL regression is honestly not labeled pristine-baseline evidence.',
        'prior_SSL_and_config_load': 'The eight SSL constructor/transform probes per interpreter and 160 configuration-load checks are prior author evidence inherited from a7bfd3dc/unchanged sources, not fresh runtime qualification by this reviewer. Lightly is absent in the clean environments. No SSL training/accuracy claim is made.',
        'root_base313': 'Root exact-b728a5b clean-base preflight remains separately attributed: 387 passed, four permitted optional skips, 48 runtime deselections, 10.31s. Reviewer independently ran the 184 focused cases plus public behavior probes on 3.13 and full non-runtime base on 3.14; root editable-environment/source limitations remain explicit.',
        'prior_artifacts_immutable': 'Earlier independent verdict/probes, root preflight, plan/acceptance artifacts and author logs/environments were read only; no prior artifact was relabeled as approval.',
    },
    'findings': [
        {
            'id': 'R2A2-01', 'severity': 'medium', 'status': 'open',
            'title': 'Shape-only NPZ validation accepts unusable features and silently truncates fractional class labels.',
            'locations': [
                {'path': 'plato/datasources/_vector_cache.py', 'line_start': 15, 'line_end': 19},
                {'path': 'plato/datasources/_vector_cache.py', 'line_start': 29, 'line_end': 33},
                {'path': 'plato/datasources/purchase.py', 'line_start': 39, 'line_end': 45},
                {'path': 'plato/datasources/texas.py', 'line_start': 40, 'line_end': 46},
            ],
            'trigger': 'A local NPZ has X/Y with the required dimensions and matching row count, but X is a Unicode string array or Y contains nonintegral labels; complete valid local raw data exists.',
            'actual': 'Both datasource constructors accept the cache in load_cache. Nonnumeric X fails later in VectorDataset with TypeError, so the invalid-cache recovery branch never runs and the unusable cache persists. Y=[0.7,1.7,2.7] is accepted and silently cast by torch.tensor(dtype=long) to labels [0,1,2]; the fractional NPZ remains unchanged. The cache parser validates shape alone before bypassing correct available preprocessing.',
            'impact': 'A malformed cache can permanently block otherwise valid offline initialization or silently change labels. The new cache-validation/rebuild contract is incomplete even though atomic publication and flock are correct.',
            'reproduction': {
                'command': remaining_command,
                'interpreters': {'313': py313, '314': py314},
                'nodes': 'test_invalid_cache_recovers_numeric_integer_data: nonnumeric-features and fractional-labels, each for Purchase and Texas.',
                'method': 'Write three complete local raw rows. Use real np.savez to create shape-compatible malformed X or Y at the real cache name; prohibit external urlretrieve. Invoke the actual constructor and assert rebuilt X/Y match the raw fixture. No production source is patched.',
                'observed_both_versions': 'Four focused failures per version: two TypeError failures at actual tensor construction and two unchanged-Y comparisons (actual [0.7,1.7,2.7], expected [0,1,2]). Exploratory probes independently record the silent target truncation.',
                'logs': [str(scratch / 'logs/remaining313.log'), str(scratch / 'logs/remaining314.log')],
            },
            'required_correction': 'Validate features are compatible numeric data and class labels permit a value-preserving integer interpretation before treating an existing cache as valid. Raise InvalidVectorCacheError for demonstrated incompatible/fractional content so the existing locked raw-data rebuild handles it. Add these actual-constructor negative paths for both datasets and preserve valid numeric cache-only/raw-only offline behavior. No feature-count redesign or broad research-semantic rewrite is requested.',
            'scope': 'Direct follow-up to R2A-02 validation/rebuild acceptance and user-requested malformed-input review. The original concurrent/kill writer reproduction is resolved.',
        },
        {
            'id': 'R2A2-02', 'severity': 'medium', 'status': 'open',
            'title': 'Stale image roots with missing required samples still bypass download recovery.',
            'locations': [
                {'path': 'plato/datasources/cinic10.py', 'line_start': 25, 'line_end': 30},
                {'path': 'plato/datasources/tiny_imagenet.py', 'line_start': 25, 'line_end': 27},
                {'path': 'plato/datasources/tiny_imagenet.py', 'line_start': 64, 'line_end': 71},
                {'path': 'plato/datasources/tiny_imagenet.py', 'line_start': 91, 'line_end': 93},
            ],
            'trigger': 'An actual successful localhost download has a .complete marker. Delete CINIC test/n001/z.png while preserving test/n001/, or delete Tiny val/images/z.png while preserving val/images/ and its annotation referencing z.png; source server remains available.',
            'actual': 'CINIC ready() remains true because train/ and test/ exist, so ImageFolder raises FileNotFoundError for a class with no images. Tiny _locate_layout returns native solely because the annotation file and images directory exist; construction reports a sample whose required image is absent, then actual __getitem__ raises FileNotFoundError. No recovery request occurs. HTTP hit count remains one and the stale marker remains. Same result with controlled default Tiny URL dispatch.',
            'impact': 'Previously completed datasets remain unusable after required extracted sample loss despite a working recovery source. The R2A-04 correction covers missing directories/annotations but does not establish a usable extracted dataset.',
            'reproduction': {
                'command': remaining_command,
                'interpreters': {'313': py313, '314': py314},
                'nodes': 'test_stale_marker_recovers_missing_required_evaluation_image: CINIC configured URL, Tiny configured URL, Tiny default URL.',
                'method': 'Use real requests/HTTP localhost ZIP and real archive extraction to construct a valid one-class root. Read a labeled sample, delete only its required evaluation image, retain marker and directories/annotation, then invoke the actual constructor and sample again. Default Tiny requests retain the production URL identity and dispatch to the controlled localhost server.',
                'observed_both_versions': 'Three FileNotFoundError failures per version. Independent recovery probes record requests=1 after deletion, versus requests=2 and valid restored samples for directory/annotation removal controls.',
                'logs': [str(scratch / 'logs/remaining313.log'), str(scratch / 'logs/remaining314.log')],
            },
            'required_correction': 'Make readiness verify the concrete missing-sample cases, or handle these dataset-loading failures by invalidating/retrying under the existing downloader lock. Native Tiny annotation references must correspond to existing image files; a class directory with no valid image cannot count as ready. Verify missing images recover via actual HTTP/extraction for CINIC and configured/default Tiny, while valid roots remain offline, unknown labels still reject, and incomplete extraction is never marked complete. Full image checksums or a new cache format are not requested.',
            'scope': 'Remaining R2A-04 required-artifact-loss recovery acceptance, not a claim that the generic marker shortcut was first introduced in this correction.',
        },
    ],
    'nonblocking_exploratory_observations': [
        'Shape-compatible X with zero columns was accepted in both vector datasources. This artificial edge was recorded only; it is not a separate finding or request to impose the full upstream feature width.',
        'CRC-damaged uncompressed NPZ members and object arrays recovered from raw offline on both interpreters; no additional parser exception issue was established.',
    ],
    'artifacts': {
        'scratch_retention': 'Retain all scratch source, logs, fixtures and isolated environments for root/original-author reproduction; no cleanup performed.',
        'files': [artifact(scratch / 'logs' / n) for n in ('sync-base313.log', 'sync-base314.log', 'focused313.log', 'focused313.xml', 'base314.log', 'base314.xml', 'probes313.log', 'probes314.log', 'remaining313.log', 'remaining313.xml', 'remaining314.log', 'remaining314.xml', 'ruff.log', 'ty.log')],
        'sources_and_identity': [artifact(scratch / n) for n in ('independent_probes.py', 'test_remaining_contracts.py', 'identity.json', 'source-audit.json')],
        'processes': 'All independent writer/reader children completed or were killed and reaped in finally blocks. All owned localhost HTTP workers shut down and joined. No retained experimental process is intended.',
    },
    'limits': [
        'macOS ARM64 CPU Python 3.13.16 and 3.14.8 only; Linux merged-tree qualification remains with root.',
        'Exact scratch source execution with clean test-base dependencies; not an installed wheel/sdist isolation or full mandatory-extra rerun.',
        'No broad optional skips, conftest edits, warning suppressions, weakened assertions, production fixes, commits, pushes or shared metadata edits.',
        'No full corpus download, experiment training/accuracy, accelerator, full socket, Docker, remote-service or SSL runtime qualification added.',
        'Atomicity probes concern successful same-filesystem os.replace publication and process death, not simulated power loss or directory-fsync durability.',
        'Archive helper has its documented no-concurrent-external-destination-writer and no-corrupt-filesystem-rollback limits; those were not expanded into new redesign requirements.',
        'PASS is blocked solely by the two medium findings above. Route bounded fixes to the original author and obtain another fresh exact-commit review afterward.',
    ],
}
path = root / 'phase2a-review-2.json'
path.write_text(json.dumps(report, indent=2) + '\n')
parsed = json.loads(path.read_text())
assert parsed['verdict'] == 'CHANGES_REQUESTED'
assert len(parsed['findings']) == 2
assert identity['candidate_status_at_end'] == '' and not identity['snapshot_mismatches']
print(json.dumps({'report': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size, 'verdict': parsed['verdict'], 'medium_findings': len(parsed['findings'])}))
