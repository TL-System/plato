"""Independent regressions demonstrating remaining Phase 2A gaps."""
import importlib.util
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pytest

spec = importlib.util.spec_from_file_location(
    "phase2a_independent", Path(__file__).with_name("independent_probes.py")
)
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)


@pytest.mark.parametrize("module,name", [(probe.purchase, "purchase"), (probe.texas, "texas")])
@pytest.mark.parametrize("malformed", ["nonnumeric-features", "fractional-labels"])
def test_invalid_cache_recovers_numeric_integer_data(tmp_path, module, name, malformed):
    root = tmp_path / name
    probe.raw(root, name)
    cache = root / (name + "_numpy.npz")
    features = np.array([[.1, .2], [.3, .4], [.5, .6]])
    labels = np.array([0, 1, 2])
    if malformed == "nonnumeric-features":
        features = np.full((3, 2), "not-numeric")
    else:
        labels = np.array([.7, 1.7, 2.7])
    np.savez(cache, X=features, Y=labels)
    probe.config(root)
    with patch.object(module.request, "urlretrieve", side_effect=AssertionError("complete raw offline")):
        source = module.DataSource()
    assert source.num_train_examples() == 3
    with np.load(cache, allow_pickle=False) as rebuilt:
        np.testing.assert_allclose(rebuilt["X"], [[.1, .2], [.3, .4], [.5, .6]])
        np.testing.assert_array_equal(rebuilt["Y"], [0, 1, 2])


@pytest.mark.parametrize("name,module,default", [
    ("cinic", probe.cinic10, False),
    ("tiny", probe.tiny_imagenet, False),
    ("tiny-default", probe.tiny_imagenet, True),
])
def test_stale_marker_recovers_missing_required_evaluation_image(tmp_path, name, module, default):
    import contextlib
    import io
    import zipfile

    payload = io.BytesIO()
    image = io.BytesIO()
    probe.Image.new("RGB", (8, 8)).save(image, format="PNG")
    prefix = "" if name == "cinic" else "tiny-imagenet-200/"
    required = "test/n001/z.png" if name == "cinic" else prefix + "val/images/z.png"
    with zipfile.ZipFile(payload, "w") as archive:
        archive.writestr(prefix + "train/n001/images/a.png", image.getvalue())
        archive.writestr(required, image.getvalue())
        if name != "cinic":
            archive.writestr(prefix + "val/val_annotations.txt", "z.png\tn001\n")
    probe.config(tmp_path)
    original_get = probe.base.requests.get
    with probe.serve(payload.getvalue()) as (url, requests):
        if not default:
            probe.Config.data.download_url = url

        def redirect(requested, **kwargs):
            assert requested == "https://cs231n.stanford.edu/tiny-imagenet-200.zip"
            return original_get(url, **kwargs)

        with patch.object(probe.base.requests, "get", side_effect=redirect) if default else contextlib.nullcontext():
            assert module.DataSource().testset[0][1] == 0
            (tmp_path / required).unlink()
            markers = list(tmp_path.glob("*.complete"))
            assert len(markers) == 1
            assert module.DataSource().testset[0][1] == 0
            assert len(requests) == 2
            assert (tmp_path / required).is_file()
