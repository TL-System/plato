import ast,hashlib,json,subprocess,xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path
root=Path.cwd();scratch=Path('/tmp/plato-phase2d-review-2');reports=Path('/Users/bli/Playground/plato/evidence/2026-refresh')
d=json.loads((root/'evidence/2026-refresh/phase2d-validation.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args])
rows=[]
def visit(obj,where):
 if isinstance(obj,dict):
  if 'path' in obj and 'sha256' in obj and isinstance(obj['path'],str) and obj['path'].startswith('/'):
   p=Path(obj['path']);rows.append({'where':where,'path':str(p),'exists':p.is_file(),'sha256_match':p.is_file() and sha(p)==obj['sha256']})
  for k,v in obj.items():visit(v,where+'.'+k)
 elif isinstance(obj,list):
  for i,v in enumerate(obj):visit(v,where+f'[{i}]')
visit(d,'validation')
source=[]
for section,ref in [('review_corrections','639ca69bf4eaeff868462d0b30a5fcc72218f061'),('base_profile_correction','15c79d0c81ffd0e5e4873db869a2863f97fe8279'),('combined_b_d_validation','53aa72c3c578b1a32d8f83d64a98d6a543cdfb9a')]:
 manifest=d[section]['source_identity_manifest']
 if isinstance(manifest,dict):manifest=manifest.get('files',manifest)
 for e in manifest:
  if not isinstance(e,dict):continue
  p=e['path'];data=git('show',ref+':'+p)
  source.append({'section':section,'ref':ref,'path':p,'sha256_match':hashlib.sha256(data).hexdigest()==e['sha256'],'blob_match':git('rev-parse',ref+':'+p).decode().strip()==e.get('git_blob',git('rev-parse',ref+':'+p).decode().strip())})
counts=[]
for label,stem in [('historical-e7','final-full'),('correction-639','review-green'),('base-15','base-green-suite'),('mandatory-15','base-correction-mandatory'),('combined-base-53','combined-final-base'),('combined-mandatory-53','combined-final-mandatory')]:
 for version in ['313','314']:
  p=Path('/tmp/plato-phase2d.G3jkGH')/(stem+version+'.xml');tree=ET.parse(p);nodes=tree.findall('.//testcase')
  count=Counter(n.attrib.get('classname') for n in nodes if n.find('skipped') is None and n.find('failure') is None and n.find('error') is None)
  counts.append({'source_label':label,'version':version,'path':str(p),'sha256':sha(p),'tests':len(nodes),'passed':sum(count.values()),'skipped':sum(n.find('skipped') is not None for n in nodes),'failures':sum(n.find('failure') is not None or n.find('error') is not None for n in nodes),'affected_counts':{k:v for k,v in count.items() if k in ['tests.servers.test_runtime_s3_contract','tests.clients.test_client_lifecycle_variants','tests.mpc.test_round_store_contracts','tests.utils.test_rl_payload_utilities']}})
# Preserve B's original test function ASTs; only its local HTTP fixture grows.
def defs(ref,path):
 text=git('show',ref+':'+path).decode();return {x.name:ast.dump(x,include_attributes=False) for x in ast.parse(text).body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef)) and x.name.startswith('test_')}
b='00eeb9dcdd2b513e64db9408969356037e09bb8e';c='09b9b941bc4a816b62d8ed33ad993455f6f05da5';p='tests/servers/test_runtime_s3_contract.py'
old,new=defs(b,p),defs(c,p);preserved={k:new.get(k)==v for k,v in old.items()}
p='tests/clients/test_client_lifecycle_variants.py';bdefs=defs(b,p);ddefs=defs('f8aa0e9815b702f9d414ebe85a85eb48f9a982a1',p);cdefs=defs(c,p)
merged={'B_size_negative':cdefs['test_simulated_server_payload_limit_precedes_deserialization']==bdefs['test_simulated_server_payload_limit_precedes_deserialization'],'D_persisted_mpc':cdefs['test_mpc_training_strategy_records_samples']==ddefs['test_mpc_training_strategy_records_samples']}
archive=root/'archives/legacy_rl_env';original=git('show','fda60becedfa6236c11d415b87a868b52789a41e:plato/utils/rl_env.py')
archive_result={'original_bytes_equal':original==(archive/'rl_env.py').read_bytes(),'source_sha256':sha(archive/'rl_env.py'),'license_equal':(archive/'LICENSE').read_bytes()==(root/'LICENSE').read_bytes(),'license_sha256':sha(archive/'LICENSE')}
acceptance=json.loads((reports/'phase2b-acceptance.json').read_text());b_accept_sha=sha(reports/acceptance['review'])==acceptance['review_sha256']
addendum=json.loads((reports/'plan-addendum-acceptance.json').read_text());add_accept_sha=sha(reports/addendum['artifact'])==addendum['artifact_sha256'] and sha(reports/addendum['review'])==addendum['review_sha256']
result={'absolute_artifact_count':len(rows),'artifacts':rows,'source_manifests':source,'xml_counts':counts,'preserved_original_B_s3_tests':preserved,'lifecycle_merge':merged,'archive':archive_result,'accepted_B_review_hash_match':b_accept_sha,'accepted_addendum_hash_match':add_accept_sha}
(scratch/'evidence-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print('Artifact descriptors',len(rows),'failures',[x for x in rows if not x['sha256_match']]);print('Source manifests',len(source),'failures',[x for x in source if not x['sha256_match'] or not x['blob_match']]);print('Counts',json.dumps(counts,indent=2));print('B tests',preserved,'merge',merged,'archive',archive_result,'acceptance hashes',b_accept_sha,add_accept_sha)
