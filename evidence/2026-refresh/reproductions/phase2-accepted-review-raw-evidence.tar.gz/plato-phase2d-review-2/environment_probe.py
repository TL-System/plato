import hashlib,importlib.metadata,importlib.util,json,platform,sys
from pathlib import Path
rows=sorted((d.metadata['Name'].lower(),d.version) for d in importlib.metadata.distributions())
payload=json.dumps(dict(rows),sort_keys=True)
print(json.dumps({'python':sys.version,'executable':sys.executable,'prefix':sys.prefix,'platform':platform.platform(),'distribution_count':len(rows),'distributions':dict(rows),'distribution_fingerprint':hashlib.sha256(payload.encode()).hexdigest(),'optional_presence':{n:importlib.util.find_spec(n) is not None for n in ['kazoo','gymnasium','opacus','tiktoken']},'uv_lock_sha256':hashlib.sha256(Path('/private/tmp/plato-refresh-worktrees/payloads/uv.lock').read_bytes()).hexdigest()},indent=2))
