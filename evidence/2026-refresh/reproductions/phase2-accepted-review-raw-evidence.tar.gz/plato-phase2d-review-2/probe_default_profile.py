"""Exercise real current fixture selection with real parsed pytest configurations."""
import json
from types import SimpleNamespace
import pytest
from gymnasium.spaces import Box
from kazoo.exceptions import LockTimeout
from tests.conftest import _ProfileChecks
from tests.mpc.test_round_store_contracts import lock_timeout_type
from tests.utils.test_rl_payload_utilities import action_space

rows=[]
for name,extra in [('implicit_mandatory',[]),('explicit_mandatory',['--test-profile=mandatory']),('explicit_base',['--test-profile=base'])]:
    config=pytest.Config.fromdictargs({},['tests','-p','no:cacheprovider',*extra])
    checks=_ProfileChecks(config)
    request=SimpleNamespace(config=config)
    lock_type=lock_timeout_type.__wrapped__(request)
    space=action_space.__wrapped__(request)
    rows.append({'case':name,'args':config.args,'root':str(config.rootpath),'test_profile':config.getoption('test_profile'),'full':checks.full,'qualification_enabled':checks.qualify,'base':checks.base,'lock_timeout':lock_type.__module__+'.'+lock_type.__name__,'real_kazoo':lock_type is LockTimeout,'action_space':type(space).__module__+'.'+type(space).__name__,'real_gymnasium':isinstance(space,Box)})
    config._ensure_unconfigure()
print(json.dumps(rows,indent=2),flush=True)
assert rows[1]['real_kazoo'] and rows[1]['real_gymnasium']
assert rows[2]['base'] and not rows[2]['real_kazoo'] and not rows[2]['real_gymnasium']
assert rows[0]['qualification_enabled'] and not rows[0]['base']
assert rows[0]['real_kazoo'] and rows[0]['real_gymnasium'], 'Implicit mandatory qualification incorrectly selects base adapters'
