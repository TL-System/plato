import datetime,hashlib,json,subprocess
from pathlib import Path
s=Path('/tmp/plato-phase2d-review-2');root=Path('/private/tmp/plato-refresh-worktrees/payloads');er=Path('/Users/bli/Playground/plato/evidence/2026-refresh')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(name):return json.loads((s/name).read_text())
def artifact(p):return {'path':str(p),'sha256':sha(p)}
identity=read('initial-identity.json');final=read('final-immutability.json');audit=read('evidence-audit.json')
runs=[read(label+v+'.json') for v in ['313','314'] for label in ['base','mandatory','independent']]
for r in runs:
 label=r['label'];r['log']=artifact(s/(label+'.log'));r['junit']=artifact(s/(label+'.xml'));r['record']=artifact(s/(label+'.json'))
 assert r['exit_code']==0 and not r['failures']

finding={
'id':'2D-R05','severity':'MEDIUM','path':'tests/mpc/test_round_store_contracts.py','line':16,
'related_locations':[{'path':'tests/utils/test_rl_payload_utilities.py','line':16},{'path':'tests/conftest.py','line':98},{'path':'tests/conftest.py','line':115}],
'title':'The implicit mandatory test profile silently selects the base optional-library adapters.',
'scope_basis':'ROOT-2D-01 requires independent base behavioral contracts and actual Kazoo LockTimeout/Gymnasium Box qualification in the mandatory profile. The accepted existing conftest explicitly defaults an unfiltered full suite to mandatory.',
'description':'Both new fixtures select the actual library only when the raw test_profile option equals the string mandatory. For the standard unfiltered pytest tests invocation, that option is None, while _ProfileChecks.full=True, qualify=True and base=False enforce mandatory prerequisites. Despite installed/importable Kazoo and Gymnasium, lock_timeout_type returns builtins.TimeoutError and action_space returns types.SimpleNamespace. This silently removes actual-library fixture qualification from the default mandatory entrypoint. Explicit --test-profile=mandatory and the clean base correction both work; this is a narrow remaining test-policy gap, not a production arithmetic or S3 defect.',
'reproduction':{
'probe':artifact(s/'probe_default_profile.py'),
'commands':[
'PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/private/tmp/plato-refresh-worktrees/payloads TMPDIR=/tmp/plato-phase2d-review-2/tmp PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 /tmp/plato-phase2d-review/venv313/bin/python -B /tmp/plato-phase2d-review-2/probe_default_profile.py',
'PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/private/tmp/plato-refresh-worktrees/payloads TMPDIR=/tmp/plato-phase2d-review-2/tmp PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 /tmp/plato-phase2d-review/venv314/bin/python -B /tmp/plato-phase2d-review-2/probe_default_profile.py'],
'logs':[artifact(s/'default-profile313.log'),artifact(s/'default-profile314.log')],
'exit_codes':[1,1],
'actual':{'implicit_mandatory':{'raw_option':None,'full':True,'qualification_enabled':True,'base':False,'lock_timeout':'builtins.TimeoutError','action_space':'types.SimpleNamespace'},'explicit_mandatory':{'real_kazoo':True,'real_gymnasium':True},'explicit_base':{'real_kazoo':False,'real_gymnasium':False}},
'method':'Real pytest.Config.fromdictargs configurations for unfiltered tests, explicit mandatory, and explicit base; current _ProfileChecks and both current fixture bodies execute. The full implicit suite/startup matrix is not run. Probe ends with a failing assertion for the implicit mandatory case.'},
'required_fix':'Have these two owned test fixtures honor the effective profile, including the existing implicit mandatory mode, while continuing to run independent contracts in clean base. Add a focused regression for implicit/explicit mandatory and explicit base selection. Preserve the existing shared conftest, metadata, mandatory prerequisites, skips and negative assertions; no production or dependency change is needed.',
'acceptance':'On both interpreters, default unfiltered mandatory configuration and explicit mandatory select the real LockTimeout/Box; explicit base still executes all 13 affected cases without Kazoo/Gymnasium. Retain the currently passing 60 actual combined cases and base suite. Original author corrects this test-only gap followed by fresh independent review.'}

envs=[]
for name in ['base313','base314','mandatory313','mandatory314']:
 e=read('environment-'+name+'.json'); relevant={k:e['distributions'][k] for k in ['torch','numpy','safetensors','boto3','botocore','requests','urllib3','tenseal','kazoo','gymnasium','pytest','ruff'] if k in e['distributions']}
 envs.append({k:v for k,v in e.items() if k!='distributions'}|{'label':name,'relevant_distributions':relevant,'full_inventory':artifact(s/('environment-'+name+'.json')),'reuse':'Borrowed prior independent reviewer environment read-only; no install, sync, deletion, or reconfiguration. Candidate source selected through cwd/PYTHONPATH; bytecode writes disabled.'})

review={
'schema_version':1,'reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
'review_role':'Fresh independent Phase 2D correction/integration reviewer; no nested agents.',
'requested_profile':'gpt-6.1-sol xhigh, separate herdr workspace',
'decision':'CHANGES_REQUESTED','candidate_local_acceptance':False,'phase_integration_acceptance':False,
'summary':'All four original production findings are independently resolved, clean base collection/execution is restored, and actual durable B+D S3 integration passes on both interpreters. One medium test-qualification gap remains: the implicit mandatory profile selects base adapters in the two ROOT-2D-01 fixture corrections.',
'identity':{
'base_commit':identity['base'],'candidate_commit':identity['candidate'],'candidate_tree':identity['tree'],'worktree':str(root),
'initial_clean':identity['status_porcelain']=='','final_clean':final['tracked_and_untracked_status']=='','immutability':final,
'ancestry':'Verified base -> initial reviewed a4a4733 -> production correction 639ca69 -> evidence aa232791 -> test-only 15c79d0 -> evidence f8aa0e98; ccb31017 merges exactly f8aa0e98 and accepted B 00eeb9dc; test-only 926346bf and 53aa72c3 precede current evidence-only 09b9b941.',
'accepted_b_candidate':'00eeb9dcdd2b513e64db9408969356037e09bb8e','accepted_b_tree':'39b6b554e833aeb5e8916e40fbc38a2fa46f6671',
'premerge_d':'f8aa0e9815b702f9d414ebe85a85eb48f9a982a1','merge_commit':'ccb310177273f5cfa2ce7f1c0203f55ddaa68397','merge_parents':['f8aa0e9815b702f9d414ebe85a85eb48f9a982a1','00eeb9dcdd2b513e64db9408969356037e09bb8e'],
'final_tested_implementation':'53aa72c3c578b1a32d8f83d64a98d6a543cdfb9a','final_tested_implementation_tree':'ee4edd25a6b762591c6bd1680dfb818d0e5c4e7a',
'candidate_vs_tested_source':'Only evidence/2026-refresh/phase2d-validation.json changes between 53aa72c3 and 09b9b941.',
'manifest':artifact(s/'initial-identity.json'),'final_verification':artifact(s/'final-immutability.json')},
'scope':{
'reviewed':['Exact D production corrections and their config/registry/server wiring, valid and invalid numerical boundaries.','Retained F02-F05/F12 behavior and touched HE/MPC/RL/processors/utilities/archive risks.','ROOT-2D-01 base/mandatory optional test contracts, fixture lifecycle cleanup and actual RL updates.','Exact accepted B dependency preservation and both lifecycle test changes.','Durable current S3 writer/presigner -> current bounded reader and actual client failure owner cleanup.','Expanded validation identities, counts, raw logs, artifact/source hashes and original versus current attribution.'],
'accepted_b_policy':'B production is already accepted. This review verifies equality and D integration/touched risks, without reopening unrelated B runtime behavior.',
'writes':'Only this ROOT report and /tmp/plato-phase2d-review-2. No candidate edits, commits/push, shared metadata/fixture changes, questions or nested agents.',
'sources_read':[artifact(er/n) for n in ['plan.md','plan-review-3.json','plan-addendum.json','plan-addendum-acceptance.json','design-acceptance.json','phase2d-review.json','phase2d-root-base-probe.json','phase2b-review-3.json','phase2b-acceptance.json']]+[artifact(root/'AGENTS.md'),artifact(root/'evidence/2026-refresh/phase2d-validation.json')]},
'source_preservation':{
'D_changed_production_files':len(identity['scopes']['D']),'B_changed_production_files':len(identity['scopes']['B']),
'production_blobs_match_owning_candidates':all(all(rows.values()) for rows in identity['production_equality'].values()),
'D_entire_trees_equal_premerge':['plato/processors','plato/serialization','plato/mpc','plato/utils'],
'S3':'Current utility blob 926ce3af7973d0f93f2442886e457d36d7612414 and SHA-256 a26d306daa6a4accd4d67c9f26dea9f9ad153e74353fe8698643987cb6f25c03 are unchanged since initial D.',
'after_merge':'No production changes after ccb31017. 926346bf and 53aa72c3 change only tests/servers/test_runtime_s3_contract.py; 09b9b941 is evidence-only.',
'metadata_and_fixtures':'pyproject.toml, uv.lock, tests/conftest.py and tests/integration/utils.py equal phase base.',
'B_original_S3_test_functions_AST_unchanged':audit['preserved_original_B_s3_tests'],
'lifecycle_merge':audit['lifecycle_merge'],'other_B_test_blobs_preserved':final['preserved_B_other_test_blobs']},
'findings':[finding],
'resolved_original_findings':[
{'id':'2D-R01','status':'RESOLVED','path':'plato/clients/strategies/mpc.py','line':49,'source_review':'Authoritative server.mpc_shamir_threshold is assigned into registry kwargs, including None default, after merging protocol fields. Direct constructor threshold is unchanged.','independent_execution':'Six reviewer cases on each interpreter use actual Config -> server wrapper/from_config store -> MPCLifecycleStrategy.configure -> registry Shamir/Safetensors -> server strategy. Thresholds 1/2/None, local overrides 1/4, unrelated same-processor server_id/review_marker and unrelated processor kwargs, five clients with [.5,0,2.5,1,3], seed807, reversed arrivals, independently summed float64 plaintext reference at absolute 2e-6. Explicit direct Processor(threshold=4) stays 4. Only general FedAvg parent initialization is isolated; no MPC production method is copied.'},
{'id':'2D-R02','status':'RESOLVED','path':'plato/processors/model_dequantize_qsgd.py','line':81,'source_review':'Bounded code division precedes multiplication by header scale; existing sign/magnitude wire and max-norm equation remain.','independent_execution':'Four reviewer cases per interpreter cover levels 2/16/64/128, seeds0/49/2026, +/-3e38 endpoints and intermediate extreme magnitudes, finite results, exact endpoints and float64 quantization-bound calculation. Zero/empty and invalid source/header scales are exercised. Full base also executes all twelve shipped ordinary/1e38/3e38 level combinations and existing malformed contracts.'},
{'id':'2D-R03','status':'RESOLVED','path':'plato/utils/toml_writer.py','line':136,'source_review':'Keys and values share scalar-preserving non-ASCII string quoting with explicit DEL escape.','independent_execution':'Five reviewer cases per interpreter use rocket, supplementary CJK, U+10FFFF, DEL and mixed supplementary/DEL strings as keys and values, nested array tables and literal-dot names. dumps, UTF-8 dump/read and stdlib tomllib.loads/load reconstruct the independent input exactly.'},
{'id':'2D-R04','status':'RESOLVED','path':'plato/processors/mpc_model_encrypt_shamir.py','line':72,'source_review':'Coefficient-pool capacity is checked before bounded sampling without replacement. The 1..999 pool excludes integer secret10; threshold1000 cannot request999 coefficients from998 available.','independent_execution':'One subprocess case per interpreter executes real public process with 1000 selected participants, threshold1000 and tensor0.000010, requires coefficient-pool ValueError within one second after entering process, and compares all store bytes/files unchanged. Child containment is twelve seconds. Normal threshold reconstruction is covered by reviewer R01 and full base tests.','historical_red':'Retained review-red-bound313/314 logs contain entered public process then TimeoutExpired at12s and contained -9 child, not an import/startup timeout. Hashes verified. No finite-field or cryptographic redesign.'}
],
'ROOT_2D_01':{
'base_collection_and_behavior':'RESOLVED: both locked base environments have Kazoo/Gymnasium/Opacus/tiktoken absent; all 13 affected MPC/RL cases collect and execute within the 557-pass full non-runtime base suite.',
'cleanup':'Remote-store fixture patches both KazooClient and Lock before construction, addressing the original both-absent branch. Exception/false acquisition stops the client, never releases an unacquired lock and never writes; acquired-lock service failure releases and stops without treating the error as uninitialized state.',
'explicit_mandatory':'PASS: current 3 round-store and 10 RL cases execute with actual LockTimeout/Box, including finite actor updates, critic/target reloads, recurrent/padding/batch and every-target-row assertions.',
'implicit_mandatory':'CHANGES_REQUESTED under new 2D-R05. No new skip, dependency addition or conftest weakening was found.'},
'mandatory_acceptance':{
'F02':'PASS: actual public namespace put/send/receive/list/delete and durable bounded ingress cases use the same once-prefixed physical key for empty, nested and trailing prefixes.',
'F03':'PASS: empty pages without Contents return []; missing versus service failures remain distinct.',
'F04':'PASS: actual local XML paginator consumes five namespace objects over three pages, excludes namespace-other/elsewhere objects and applies namespace/ on every page.',
'F05':'PASS: source default connect/read inactivity 5/30s and total attempts3; Requests retry pool total2, bounded backoff and Retry-After disabled. Full base executes actual shortened-timeout stalls/service errors over init/PUT/GET/list/delete, transient recovery and useful errors. Runtime ingress separately has total deadline.',
'F12':'PASS: ambiguous dotted/bracketed/nested paths, coercion/empty paths and reserved _tree_metadata rejected before transmission. Ordinary literal state_dict keys, structure and Torch dtypes preserved. Reviewer directly checks transposed float64 and bfloat16, float32 bf16 wire with torch.bfloat16 metadata, exact restoration and nonaliasing.'},
'durable_B_D_integration':{
'status':'Executed provisional source combination and durable regression PASS; root final phase qualification remains pending.',
'path':'tests/servers/test_runtime_s3_contract.py','sha256':sha(root/'tests/servers/test_runtime_s3_contract.py'),
'production_imports':['plato.utils.s3.S3','plato.clients.transport.receive_s3_payload','plato.clients.strategies.defaults.DefaultPayloadStrategy'],
'no_source_copies':'Tracked tests import real current modules; no immutable scratch module, absolute /tmp dependency or copied production implementation. Independent import-origin probe requires current worktree paths.',
'cases':{'actual_writer_reader':24,'actual_client_failure_cleanup':4,'preserved_B_original':10,'S3_module_total':38,'client_lifecycle':9,'optional_contracts':13,'mandatory_affected_total':60},
'writer_reader_matrix':'empty/ordinary/nested/trailing prefix x native S3/minimal fields adapter retaining actual botocore presigner x valid/oversize/total deadline.',
'assertions':'Real constructor bucket HEAD, unused-key object HEAD, serialized HTTP PUT and presigned GET agree on the independently computed physical key. Input equals decoded payload and counted bytes equal stored bytes. Oversize advertised length rejects before reservation with byte_count0. Continuous trickling expires total deadline after multiple bytes, bounded remaining reservation and release.',
'client_owner':'Four cases call real finalise_inbound_payload, checking removal of inbound_transfer, cleared chunks/server_payload, closed transfer, canceled timer and no other asyncio tasks before test teardown.',
'timing_and_cleanup':'One-second total payload deadline with bytes every50ms; independent five-second outer watchdog expires as a test failure, with deadline completion below two seconds. Reader closes aiohttp session/response. Caller closes transfer; fixture stop event terminates trickling, GET completion event waits at most2s, server shutdown/server_close and serve thread join2s with liveness assertion. All 38 cases pass in both base and actual-library mandatory executions; no Python ResourceWarning/UserWarning in strict mandatory runs.'},
'independent_validation':{
'environments':envs,'runs':runs,'reviewer_probe':artifact(s/'test_independent_contracts.py'),'runner':artifact(s/'run_checks.py'),
'counts':'Per interpreter:557 tracked non-runtime base passes plus4 existing allowed skips;60 affected nodes repeat a subset of those tests with actual optional libraries;28 distinct reviewer-written execution nodes pass. Do not add the60 to557 as unique coverage. Explicit mandatory nodes have38 S3+9 lifecycle+3 store+10 RL. Separate profile-policy probe fails the implicit mandatory assertion on both interpreters.',
'collection':'Both independent base collect-only commands pass:560/608 item nodes,48 runtime deselected. JUnit execution561 includes the single module-level absent-Opacus skip in addition to560 selected item nodes;3 Nanochat item skips complete the four allowances.',
'collection_logs':[artifact(s/'collection313.log'),artifact(s/'collection314.log')],
'static':[{'command':'/tmp/plato-phase2d-review/venv313/bin/ruff check . --select I --no-cache','exit_code':0,'log':artifact(s/'ruff.log')},{'command':'git diff --check fda60becedfa6236c11d415b87a868b52789a41e 09b9b941bc4a816b62d8ed33ad993455f6f05da5','exit_code':0,'log':artifact(s/'diff-check.log')}],
'shell_and_process':'Initial exec calls selected /bin/zsh with login=true. Final collection/static/profile/report calls use explicit zsh -lc wrappers. Python subprocess test commands use argument vectors without shell. All test/fixture temp/cache output directed into owned scratch; bytecode and pytest cache writes disabled.',
'harness_history':'The first scratch-only reviewer run supplied name inside processor_kwargs, conflicting with the registry-owned name argument. Six MPC harness cases failed with duplicate keyword TypeError on each interpreter;22 other cases passed. Replaced this invalid reserved keyword with review_marker/server_id, kept logs/XML as independent-harness313/314, and reran all28 successfully. This is excluded from production findings.'},
'retained_evidence_audit':{
'audit':artifact(s/'evidence-audit.json'),'artifact_descriptors_checked':97,'artifact_hash_mismatches':[],'historical_and_current_source_manifest_entries_checked':20,'source_hash_or_blob_mismatches':[],
'accepted_plan_sha256':'edb9a58cc7915a940854f16d5029fe97434703bf2f75eca0dcb96de2d0f0eb15','accepted_addendum_hash_verified':audit['accepted_addendum_hash_match'],'accepted_B_review_hash_verified':audit['accepted_B_review_hash_match'],
'attribution':[{'source':'e7c0d59571d88efd7eb1fdbf4fc63ac2a7b81395','result':'412 passed +1 allowed native Nanochat skip per interpreter, including48 startup; historical initial implementation only.'},{'source':'639ca69bf4eaeff868462d0b30a5fcc72218f061','result':'95 scoped production-correction cases per interpreter.'},{'source':'15c79d0c81ffd0e5e4873db869a2863f97fe8279','result':'383 base pass +4 allowed skips, and13 explicit mandatory affected pass per interpreter.'},{'source':'53aa72c3c578b1a32d8f83d64a98d6a543cdfb9a','result':'557 base pass +4 allowed skips,48 runtime deselected;60 explicit mandatory affected pass per interpreter. This source equals current candidate outside evidence.'}],
'raw_xml_counts':audit['xml_counts'],'raw_combined_directory':'/tmp/plato-phase2d.G3jkGH/combined','historical_claims_preserved':True},
'research_and_touched_risk_review':{
'HE_MPC':'Reviewed changed real methods, round/share accounting, positive/zero/fractional counts, sender/recipient orientation, exact-range integer interpolation, store atomic-save/round fences and HE pre-publication validation. Full base executes shipped HE/MPC negatives; reviewer native CKKS no/partial/full masks with fractional [.5,0,2.5] and reversed arrivals matches independent weighted reference at2e-5. Existing equations/prototype preserved.',
'RL':'Reviewed replay reward/done shapes, TD3 per-row actions and target evaluation, recurrent padding/length masks and loaded target snapshots. Full base and explicit mandatory execute all five active policy variants, finite actor updates, asynchronous lengths/batch1/3, input immutability and target-row isolation. Three reviewer cases additionally require critic parameter changes and restored critic/actor targets; native Gymnasium action space used in explicit mandatory.',
'processors_utilities':'Reviewed float/bool/int buffer preservation, QSGD validation/wire, feature homogeneous header/strided/empty behavior, CPU feature precision, randomized-response copy, replacement-model pruning, empty compound loaders, unary stable epsilon, guarded parameter-count imports and cleanup symlink containment. Full base executes actual shipped contracts; utility/FEI standalone raw logs and instrumentation read with limitations retained.',
'archive':audit['archive']|{'path':'archives/legacy_rl_env','tracked_import_config_search':'rg rl_env over plato/examples/configs/docs/pyproject.toml finds no active references. Original module bytes and root Apache-2.0 license copied exactly; README contains baseline/last-source SHA, known four-value-step/shape/loop/wait limitations and historical checkout context. Active reinforcement_learning and FEI stay present.'}},
'handoffs_and_limits':[
'2D-R05 is the sole remaining medium finding in this review scope. Original author corrects the owned test fixtures, then a fresh independent review is required before D component acceptance.',
'Root final combined phase merge validation/gate remains pending despite successful current provisional B+D execution. This report does not reopen accepted B production or qualify the whole phase.',
'No repeated8-minute48-startup matrix. Its unchanged historical D and exact accepted B evidence remains attributed to those sources; current base runs deselect48. Root runs final combined qualification.',
'F07/F26 checkpoint/trainer/DP/SCAFFOLD and shared checkpoint integration belong to now-authorized C; they are not new D findings. Native MLX qualification remains3A.',
'Phase4 FEI2D-15 zero-norm NaN and2D-16 constructor dependency forwarding remain concrete tracked future internal fixes, not resolved or external blockers.',
'No live cloud S3, real ZooKeeper cluster, full distributed HE/MPC/FEI deployment, GPU/Metal/native MLX result, or cryptographic proof is claimed. Localhost contract servers and ephemeral native CKKS CPU contexts only.',
'S3 synchronous utility bounds inactivity/retries, not indefinitely trickling total duration; runtime reader separately has total deadline. Pickles remain trusted-peer/storage/local-file contracts. No speculative security/protocol redesign.',
'Profile-finding reproduction executes real parsed configurations/current fixture bodies in isolation. It does not claim an executed complete implicit mandatory suite or repeat startup containment.'
],
'resources':{'owned_scratch':str(s),'retention':'Retain all owned evidence/probes/test outputs and borrowed environments through root integration; nothing deleted or reconfigured.','write_scope':'Only /Users/bli/Playground/plato/evidence/2026-refresh/phase2d-review-2.json and /tmp/plato-phase2d-review-2.'}
}
path=er/'phase2d-review-2.json';path.write_text(json.dumps(review,indent=2,ensure_ascii=False)+'\n')
(s/'report-copy.json').write_text(path.read_text());print(review['decision'],str(path),'bytes',path.stat().st_size,'sha256',sha(path))
