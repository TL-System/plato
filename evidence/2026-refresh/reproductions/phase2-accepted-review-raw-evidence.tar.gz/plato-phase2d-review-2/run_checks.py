import hashlib,json,os,subprocess,sys,time,xml.etree.ElementTree as ET
from pathlib import Path
root=Path('/private/tmp/plato-refresh-worktrees/payloads'); scratch=Path('/tmp/plato-phase2d-review-2')
label,exe,profile,*paths=sys.argv[1:]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(root),TMPDIR=str(scratch/'tmp'),HF_HUB_OFFLINE='1',HF_DATASETS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',XDG_CACHE_HOME=str(scratch/'cache'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
(scratch/'tmp').mkdir(exist_ok=True)
cmd=[exe,'-B','-m','pytest',*paths,'--test-profile='+profile,'-m','not runtime','-q','-ra','-p','no:cacheprovider','--basetemp='+str(scratch/('pytest-'+label)),'--junitxml='+str(scratch/(label+'.xml'))]
if any(p.startswith(str(scratch)) for p in paths):cmd+=['-p','tests.conftest']
if profile=='mandatory':cmd+=['-W','error::UserWarning','-W','error::ResourceWarning']
t0=time.monotonic()
try:r=subprocess.run(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=240)
except subprocess.TimeoutExpired as e:
 (scratch/(label+'.log')).write_bytes(e.stdout or b'');raise
(scratch/(label+'.log')).write_text(r.stdout)
record={'label':label,'command':cmd,'cwd':str(root),'environment':{k:env[k] for k in ['PYTHONDONTWRITEBYTECODE','PYTHONPATH','TMPDIR','HF_HUB_OFFLINE','HF_DATASETS_OFFLINE','TOKENIZERS_PARALLELISM','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','XDG_CACHE_HOME','PYTEST_DISABLE_PLUGIN_AUTOLOAD']},'exit_code':r.returncode,'seconds':time.monotonic()-t0,'log_sha256':hashlib.sha256(r.stdout.encode()).hexdigest()}
xml=scratch/(label+'.xml')
if xml.exists():
 tree=ET.parse(xml);nodes=tree.findall('.//testcase');record.update(testcases=len(nodes),passed=sum(n.find('failure') is None and n.find('error') is None and n.find('skipped') is None for n in nodes),skipped=[{'node':n.attrib,'reason':n.find('skipped').attrib} for n in nodes if n.find('skipped') is not None],failures=[{'node':n.attrib,'failure':ET.tostring(n,encoding='unicode')} for n in nodes if n.find('failure') is not None or n.find('error') is not None])
(scratch/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ['skipped','failures','environment','command']}));print(r.stdout[-3500:]);sys.exit(r.returncode)
