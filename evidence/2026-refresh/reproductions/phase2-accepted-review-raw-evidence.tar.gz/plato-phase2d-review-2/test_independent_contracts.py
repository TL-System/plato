"""Independent current-source reviewer contracts; no production module copies."""
import asyncio
import importlib
import inspect
import math
import random
import subprocess
import sys
import threading
import time
import tomllib
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest
import torch
from safetensors.numpy import load

from tests.integration.utils import build_minimal_config, configure_environment

ROOT = Path('/private/tmp/plato-refresh-worktrees/payloads')
SCRATCH = Path('/tmp/plato-phase2d-review-2')


def test_all_relevant_imports_are_current_candidate():
    for name in [
        'plato.clients.transport', 'plato.clients.strategies.defaults',
        'plato.clients.strategies.mpc', 'plato.processors.registry',
        'plato.processors.mpc_model_encrypt_shamir', 'plato.servers.strategies.mpc',
        'plato.utils.s3', 'plato.serialization.safetensor',
        'plato.utils.reinforcement_learning.policies.td3',
    ]:
        mod = importlib.import_module(name)
        assert Path(mod.__file__).resolve().is_relative_to(ROOT), mod.__file__


@pytest.mark.parametrize('threshold', [1, 2, None])
@pytest.mark.parametrize('local_override', [1, 4])
def test_config_registry_threshold_weighted_reversed(threshold, local_override, tmp_path, monkeypatch):
    from plato.clients.strategies.mpc import MPCLifecycleStrategy
    from plato.processors.mpc_model_encrypt_shamir import Processor
    config = build_minimal_config(clients_per_round=5, total_clients=5)
    config['clients']['outbound_processors'] = ['mpc_model_encrypt_shamir', 'safetensor_encode']
    if threshold is not None:
        config['server']['mpc_shamir_threshold'] = threshold
    with configure_environment(config, runtime_root=tmp_path):
        from plato.servers import fedavg, fedavg_mpc_shamir
        def parent_init(server):
            server._mpc_round_lock = threading.Lock()
        monkeypatch.setattr(fedavg.Server, '__init__', parent_init)
        server = fedavg_mpc_shamir.Server()
        store = server.round_store
        ids, counts = [11, 3, 8, 6, 9], [.5, 0, 2.5, 1, 3]
        store.initialise_round(12, ids)
        weights = [torch.tensor([i*.137, -.23*(i+1), .000021], dtype=torch.float64) for i in range(5)]
        expected = sum(c*w for c,w in zip(counts,weights)) / math.fsum(counts)
        received = []; updates = []
        random.seed(807)
        for cid, count, w in zip(ids, counts, weights):
            store.record_client_samples(cid,count,round_number=12)
            kwargs = {'mpc_model_encrypt_shamir': {'threshold': local_override, 'review_marker': 'retained value', 'server_id': 83}, 'model_deepcopy': {'client_id': 99}}
            context = SimpleNamespace(client_id=cid, round_store=store, debug_artifacts=False, processor_kwargs=kwargs, model=None, datasource=None, trainer=SimpleNamespace(set_client_id=lambda _: None), algorithm=SimpleNamespace(set_client_id=lambda _: None))
            MPCLifecycleStrategy().configure(context)
            assert context.processor_kwargs['mpc_model_encrypt_shamir']['threshold'] is threshold
            assert context.processor_kwargs['mpc_model_encrypt_shamir']['review_marker'] == 'retained value'
            assert context.processor_kwargs['mpc_model_encrypt_shamir']['server_id'] == 83
            assert context.processor_kwargs['model_deepcopy'] == {'client_id': 99}
            shares = context.inbound_processor.process(context.outbound_processor.process({'w': w}))
            received.append(shares)
            updates.append(SimpleNamespace(client_id=cid, report=SimpleNamespace(num_samples=count)))
        assert server.aggregation_strategy.threshold is threshold
        result = asyncio.run(server.aggregation_strategy.aggregate_weights(updates[::-1], {'w':torch.zeros(3,dtype=torch.float64)}, received[::-1], SimpleNamespace(current_round=12)))
        torch.testing.assert_close(result['w'], expected, rtol=0, atol=2e-6)
        direct = Processor(client_id=ids[0],round_store=store,threshold=4,debug_artifacts=False)
        assert direct.threshold == 4
        assert store.load_state().client_samples == dict(zip(ids,counts))


@pytest.mark.parametrize('level', [2,16,64,128])
def test_qsgd_float32_extremes_and_invalid_scale(level):
    from plato.processors.model_quantize_qsgd import Processor as Encode
    from plato.processors.model_dequantize_qsgd import Processor as Decode
    from struct import pack
    enc, dec = Encode(client_id=1, quantization_level=level), Decode(client_id=1,quantization_level=level)
    for seed in [0, 49, 2026]:
        random.seed(seed)
        x = torch.tensor([3e38, -3e38, 2.75e38, -1.275e38, 0.0, 1e-20],dtype=torch.float32)
        wire=enc.process({'w':x})
        y=dec.process(wire)['w']
        assert torch.isfinite(y).all()
        torch.testing.assert_close(y[:2],x[:2],atol=0,rtol=0)
        bound=x.double().abs().max()/(level-1)
        assert (x.double()-y.double()).abs().max() <= bound*(1+4*torch.finfo(torch.float32).eps)
        corrupt={'w':pack('!f',float('inf'))+wire['w'][4:]}
        with pytest.raises(ValueError,match='scale'):dec.process(corrupt)
    for x in [torch.empty((0,2)),torch.zeros((2,3))]:
        torch.testing.assert_close(dec.process(enc.process({'w':x}))['w'],x)
    for bad in [float('nan'),float('inf'),-float('inf')]:
        with pytest.raises(ValueError,match='finite'):enc.process({'w':torch.tensor([bad])})


@pytest.mark.parametrize('char', ['🚀','𠮷','\U0010ffff','\x7f','🧪\x7f𠮷'])
def test_toml_supplementary_nested_utf8(char,tmp_path):
    from plato.utils import toml_writer
    data={char:char, 'a.b':[{char:{'nested.key':char,'list':[char, 'line\n\t\\"']}},{char:{'nested.key':char+'second'}}]}
    wire=toml_writer.dumps(data,comments={():['review supplementary unicode']})
    assert tomllib.loads(wire)==data
    p=tmp_path/'unicode.toml';toml_writer.dump(data,p)
    assert tomllib.loads(p.read_bytes().decode('utf-8'))==data
    with p.open('rb') as stream:assert tomllib.load(stream)==data


def test_impossible_pool_child_fails_before_state_change(tmp_path):
    code='''
from pathlib import Path
import sys,time,torch
from plato.mpc import RoundInfoStore
from plato.processors.mpc_model_encrypt_shamir import Processor
root=Path(sys.argv[1]);s=RoundInfoStore(storage_dir=root)
s.initialise_round(5,list(range(1000)));s.record_client_samples(2,1,round_number=5)
before={p.name:p.read_bytes() for p in root.iterdir()}
p=Processor(client_id=2,round_store=s,threshold=1000,debug_artifacts=False)
print('entered public process',flush=True);start=time.monotonic()
try:p.process({'w':torch.tensor(0.000010,dtype=torch.float64)})
except ValueError as e:assert 'coefficient pool' in str(e)
else:raise AssertionError('failed to reject')
assert time.monotonic()-start<1
assert before=={p.name:p.read_bytes() for p in root.iterdir()}
print('rejected without persistence',flush=True)
'''
    r=subprocess.run([sys.executable,'-B','-c',code,str(tmp_path)],capture_output=True,text=True,timeout=12)
    assert r.returncode==0,r.stdout+r.stderr
    assert 'rejected without persistence' in r.stdout


@pytest.mark.parametrize('collision', [
    {'a.b':np.ones(1),'a':{'b':np.zeros(1)}},
    {'a':{'b':np.zeros(1)},'a.b':np.ones(1)},
    {'a[0]':np.ones(1),'a':[np.zeros(1)]},
    {'_tree_metadata':np.ones(1)},
])
def test_tree_ambiguity_rejected_before_serialization(collision):
    from plato.serialization.safetensor import serialize_tree
    with pytest.raises(ValueError):serialize_tree(collision)


def test_bfloat16_wire_dtype_metadata_and_isolated_roundtrip():
    from plato.serialization.safetensor import serialize_tree,deserialize_tree
    bf=torch.tensor([[.125,-3],[1.5,.0625]],dtype=torch.bfloat16).T
    normal=torch.arange(12,dtype=torch.float64).reshape(3,4).T
    data={'layer.weight':normal,'nested':(bf,[None,'🚀',b'wire'])}
    wire=serialize_tree(data);flat=load(wire)
    assert flat['nested[0]'].dtype==np.float32
    assert b'torch.bfloat16' in flat['_tree_metadata'].tobytes()
    result=deserialize_tree(wire)
    assert isinstance(result['nested'],tuple)
    assert result['nested'][0].dtype==torch.bfloat16
    torch.testing.assert_close(result['nested'][0],bf)
    torch.testing.assert_close(result['layer.weight'],normal)
    result['nested'][0].zero_();assert torch.count_nonzero(bf)==4


@pytest.mark.parametrize('mask',[[],[2,0],[0,1,2]])
def test_native_he_fractional_weighting_and_mask_input_preservation(mask,temp_config):
    import tenseal as ts
    from plato.utils import homo_enc
    from plato.servers.fedavg_he import Server
    from plato.servers.strategies.aggregation.he import FedAvgHEAggregationStrategy
    ckks=ts.context(ts.SCHEME_TYPE.CKKS,poly_modulus_degree=8192,coeff_mod_bit_sizes=[60,40,40,60],n_threads=1);ckks.global_scale=2**40
    weights=[torch.tensor([-.3,2.,.07]),torch.tensor([1.,-2.,.4]),torch.tensor([.7,-.5,-.2])]
    counts=[.5,0,2.5];payload=[]
    for w in weights:
        supplied=mask.copy();payload.append(homo_enc.encrypt_weights({'w':w},context=ckks,indices=supplied));assert supplied==mask
    updates=[SimpleNamespace(report=SimpleNamespace(num_samples=c)) for c in counts]
    server=Server.__new__(Server);server.he_context=ckks;server.trainer=SimpleNamespace(zeros=torch.zeros);server.weight_shapes={'w':(3,)};server.para_nums={'w':3};server.encrypted_model='prior'
    result=asyncio.run(FedAvgHEAggregationStrategy().aggregate_weights(updates[::-1],{'w':torch.zeros(3)},payload[::-1],SimpleNamespace(server=server)))
    torch.testing.assert_close(result['w'].double(),sum(w.double()*c for w,c in zip(weights,counts))/sum(counts),atol=2e-5,rtol=0)


@pytest.mark.parametrize('kind',['ddpg','td3','sac'])
def test_policy_replay_updates_all_networks_and_load_targets(rl_config,action_space,kind):
    from plato.utils.reinforcement_learning.policies import ddpg,td3,sac
    torch.manual_seed(821);np.random.seed(821)
    p=sac.Policy(4,action_space) if kind=='sac' else (ddpg if kind=='ddpg' else td3).Policy(4,2)
    for i in range(7):
        state=np.array([.3,.1*i,-.2,.6]);p.replay_buffer.push((state,np.array([.2,.8]),i*.1,state+.03,float(i==6)))
    before={n:x.detach().clone() for n,x in p.critic.named_parameters()}
    losses=p.update();assert all(np.isfinite(x) for x in losses)
    assert any(not torch.equal(x,before[n]) for n,x in p.critic.named_parameters())
    assert all(torch.isfinite(x).all() for x in p.critic.parameters())
    saved={n:x.detach().clone() for n,x in p.critic.named_parameters()};p.save_model(7)
    with torch.no_grad():
        for x in p.critic.parameters():x.add_(2)
    p.load_model(7)
    for n,x in p.critic.named_parameters():torch.testing.assert_close(x,saved[n])
    for x,y in zip(p.critic.parameters(),p.critic_target.parameters()):torch.testing.assert_close(x,y)
    if hasattr(p,'actor_target'):
        for x,y in zip(p.actor.parameters(),p.actor_target.parameters()):torch.testing.assert_close(x,y)

# Reuse only existing environment contracts; tests above are reviewer-written.
from tests.utils.test_rl_payload_utilities import rl_config,action_space
