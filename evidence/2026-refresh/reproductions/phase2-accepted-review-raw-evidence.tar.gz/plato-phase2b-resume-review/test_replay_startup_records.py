"""Apply unchanged startup assertions to retained records, without new processes.

This is evidence auditing, not another startup execution count. The socket test's
late port-bind assertion checks today's port availability, not the historical bind.
"""
import hashlib
import json
import os
from pathlib import Path

import pytest

from tests.integration import test_event_loop_startup as original

RECORD_ROOT = Path(os.environ['REVIEW_RECORD_ROOT'])
MANIFEST = Path(os.environ['REVIEW_MANIFEST'])
PY = os.environ['REVIEW_PY']
SUMMARY = Path(os.environ['REVIEW_AUDIT_OUTPUT'])
records = {}
entries = []
used = set()
manifest = json.loads(MANIFEST.read_text())[PY]['raw_result_manifest']
assert len(manifest) == 48
for item in manifest:
    path = MANIFEST.parent / item['path']
    assert path.is_relative_to(RECORD_ROOT)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert digest == item['sha256'], str(path)
    row = json.loads(path.read_text())
    assert not row['survivors']
    stream_events = []
    streams = []
    for stream in sorted(path.parent.glob('events-*.jsonl')):
        stream_events.extend(json.loads(line) for line in stream.read_text().splitlines())
        streams.append({'path': str(stream), 'sha256': hashlib.sha256(stream.read_bytes()).hexdigest()})
    assert stream_events == row['events'], str(path)
    key = (row['case'], json.dumps(row['options'], sort_keys=True))
    assert key not in records, key
    records[key] = row
    entries.append({'path': str(path), 'sha256': digest,
                    'case': row['case'], 'options': row['options'],
                    'returncode': row['returncode'], 'timed_out': row['timed_out'],
                    'forced': row['forced'], 'survivors': row['survivors'],
                    'streams': streams})

@pytest.fixture(autouse=True)
def recorded_probe(monkeypatch):
    def replay(directory, case, *, timeout=30, interpreter=None, **options):
        key = (case, json.dumps(options, sort_keys=True))
        assert key in records, key
        assert key not in used, key
        used.add(key)
        return records[key]
    monkeypatch.setattr(original, 'run_probe', replay)

@pytest.fixture(scope='session', autouse=True)
def complete_audit():
    yield
    assert len(used) == len(records) == 48
    assert sum(row['timed_out'] for row in records.values()) == 5
    SUMMARY.write_text(json.dumps({'records': len(records), 'consumed': len(used),
        'deliberate_watchdogs': 5, 'survivors': 0, 'manifest': str(MANIFEST),
        'source': original.__file__, 'entries': entries,
        'count_policy': 'Replayed retained assertions; no new startup executions.'}, indent=2) + '\n')

for name in dir(original):
    if name.startswith('test_'):
        globals()[name] = getattr(original, name)
