import hashlib
import json
import subprocess
from pathlib import Path

REPO = Path('/private/tmp/plato-refresh-worktrees/runtime-resume-review')
ROOT = Path('/Users/bli/Playground/plato')
SCRATCH = Path('/tmp/plato-phase2b-resume-review')
ACCEPTED = '00eeb9dcdd2b513e64db9408969356037e09bb8e'
F28 = '5b1c4a5d9ed2c29e33cdd2d99c28dd83a7ce377b'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def load(path):
    return json.loads(path.read_text())

author = Path('/tmp/plato-phase2b-runtime')
snapshot = {}
for directory in ('resume-supplement', 'selection-rng'):
    for path in sorted((author / directory).rglob('*')):
        if path.is_file():
            snapshot[str(path)] = sha(path.read_bytes())
authority_names = ['AGENTS.md', 'evidence/2026-refresh/plan.md',
    'evidence/2026-refresh/plan-addendum.json',
    'evidence/2026-refresh/plan-addendum-acceptance.json',
    'evidence/2026-refresh/phase2b-acceptance.json',
    'evidence/2026-refresh/phase2b-review-3.json',
    'evidence/2026-refresh/server-resume-rng-probe.json']
authority = {str(ROOT / name): sha((ROOT / name).read_bytes())
             for name in authority_names}
prior = load(ROOT / 'evidence/2026-refresh/phase2b-review-3.json')
acceptance = load(ROOT / 'evidence/2026-refresh/phase2b-acceptance.json')
assert authority[str(ROOT / 'evidence/2026-refresh/phase2b-review-3.json')] == acceptance['review_sha256']

tracked = git('ls-files', '-z').decode().split('\0')
source = {}
for name in filter(None, tracked):
    path = REPO / name
    if path.is_file():
        current = sha(path.read_bytes())
        assert current == sha(git('show', f'HEAD:{name}')), name
        source[name] = current
changes = git('diff', '--name-only', ACCEPTED, 'HEAD').decode().splitlines()
assert sorted(changes) == sorted([
    'plato/servers/base.py', 'tests/servers/test_server_resume_rng.py',
    'evidence/2026-refresh/phase2b-resume-validation.json',
    'evidence/2026-refresh/phase2b-selection-rng-validation.json'])
assert sha(git('show', f'{ACCEPTED}:evidence/2026-refresh/phase2b-validation.json')) == source['evidence/2026-refresh/phase2b-validation.json']
assert sha(git('show', f'{F28}:evidence/2026-refresh/phase2b-resume-validation.json')) == source['evidence/2026-refresh/phase2b-resume-validation.json']

reports = [load(REPO / 'evidence/2026-refresh/phase2b-resume-validation.json'),
           load(REPO / 'evidence/2026-refresh/phase2b-selection-rng-validation.json')]
receipts = []
def verify_receipts(data):
    if isinstance(data, dict):
        if 'path' in data and 'sha256' in data and str(data['path']).startswith(str(author) + '/'):
            path = Path(data['path'])
            assert sha(path.read_bytes()) == data['sha256'], str(path)
            receipts.append(data)
        for value in data.values():
            verify_receipts(value)
    elif isinstance(data, list):
        for value in data:
            verify_receipts(value)
for report in reports:
    verify_receipts(report)
for name, digest in reports[1]['source_identities']['unchanged_tracked_files'].items():
    assert source[name] == digest, name
assert source['plato/servers/base.py'] == reports[1]['source_identities']['final_rng_source']
assert source['tests/servers/test_server_resume_rng.py'] == reports[1]['source_identities']['final_regression_source']
assert sha(git('show', f'{F28}:plato/servers/base.py')) == reports[1]['source_identities']['baseline_rng_source']
assert sha(git('show', f'{ACCEPTED}:plato/servers/base.py')) == reports[0]['identities']['baseline_source_sha256']['plato/servers/base.py']
assert git('show', f'{F28}:evidence/2026-refresh/phase2b-resume-validation.json') == (REPO / 'evidence/2026-refresh/phase2b-resume-validation.json').read_bytes()

# Read the entire previous independent review as structured evidence; preserve
# its detailed contract dispositions without treating its runs as new results.
prior_outline = {}
for key, value in prior.items():
    if isinstance(value, dict):
        prior_outline[key] = list(value)
    elif isinstance(value, list):
        prior_outline[key] = {'entries': len(value)}
    else:
        prior_outline[key] = value

result = {'candidate_commit': git('rev-parse', 'HEAD').decode().strip(),
    'candidate_tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
    'status': git('status', '--porcelain=v1', '--untracked-files=all').decode(),
    'changes_from_accepted': changes, 'candidate_sha256': source,
    'authority_sha256': authority, 'author_scratch_sha256': snapshot,
    'verified_author_report_receipts': receipts,
    'prior_review_outline': prior_outline,
    'prior_contract_dispositions': prior['mandatory_contract_disposition'],
    'all_tracked_regular_files_match_git': True,
    'original_b_report_unchanged': True, 'historical_f28_report_unchanged': True}
(SCRATCH / 'initial-audit.json').write_text(json.dumps(result, indent=2) + '\n')
(SCRATCH / 'accepted-to-candidate.diff').write_bytes(git('diff', ACCEPTED, 'HEAD'))
(SCRATCH / 'f28-to-final.diff').write_bytes(git('diff', F28, 'HEAD'))
print(json.dumps({'tracked_files_matched': len(source),
    'author_scratch_files_hashed': len(snapshot), 'author_receipts_verified': len(receipts),
    'prior_review_keys': prior_outline, 'changed_paths': changes, 'clean': result['status'] == ''}, indent=2))
