import ast
import hashlib
import json
import pickle
from pathlib import Path

import numpy as np

from plato.serialization.safetensor import deserialize_tree

REPO = Path('/private/tmp/plato-refresh-worktrees/runtime-resume-review')
SCRATCH = Path('/tmp/plato-phase2b-resume-review')
AUTHOR = Path('/tmp/plato-phase2b-runtime/selection-rng')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

final = (REPO / 'tests/servers/test_server_resume_rng.py').read_text()
red = final.replace(
    '        weights, python_reference, numpy_reference, uninterrupted = (\n'
    '            save_committed_round(unrelated_draws)\n'
    '        )',
    '        weights, python_reference, numpy_reference, uninterrupted = save_committed_round(\n'
    '            unrelated_draws\n'
    '        )')
red_path = SCRATCH / 'reconstructed-author-red-regression.py'
red_path.write_text(red)
declared = json.loads((REPO / 'evidence/2026-refresh/phase2b-selection-rng-validation.json').read_text())
assert sha(red_path) == declared['source_identities']['red_regression_source']
assert ast.dump(ast.parse(red), include_attributes=False) == ast.dump(ast.parse(final), include_attributes=False)

# Preserve the exact first reviewer script used for the independent red runs.
# Its only later edit made a missing parent directory for legacy-writer setup.
script = (SCRATCH / 'independent_resume_probe.py').read_text()
first_script = script.replace('directory.mkdir(parents=True, exist_ok=True)',
                             'directory.mkdir(exist_ok=True)')
(SCRATCH / 'independent_resume_probe_red_version.py').write_text(first_script)

output = {'red_regression_reconstruction': {
    'path': str(red_path), 'sha256': sha(red_path),
    'matches_author_receipt': True, 'red_green_ast_identical': True},
    'socket_checks': []}
reference_values = declared['independent_socket_numerics']['float64_reference']
for py in ('313', '314'):
    for label, root in [('author', AUTHOR / f'startup{py}'),
                        ('reviewer', SCRATCH / f'startup{py}')]:
        paths = list(root.rglob('result.json'))
        matches = [(path, json.loads(path.read_text())) for path in paths
                   if json.loads(path.read_text())['case'] == 'socket_round']
        assert len(matches) == 1
        path, row = matches[0]
        assert row['returncode'] == 0 and not row['timed_out']
        assert row['forced'] == row['survivors'] == []
        events = row['events']
        baseline, = [event['weights'] for event in events if event['event'] == 'server_baseline']
        aggregate, = [event['weights'] for event in events if event['event'] == 'server_aggregate']
        trained = {event['client_id']: event for event in events if event['event'] == 'client_trained'}
        received = {event['client_id']: event for event in events if event['event'] == 'server_received'}
        initial = {event['client_id']: event['weights'] for event in events if event['event'] == 'client_baseline'}
        assert set(trained) == set(received) == set(initial) == {1, 2}
        assert len({event['pid'] for event in trained.values()}) == 2
        assert {event['pid'] for event in events if event['event'] == 'child_returned'} == {event['pid'] for event in trained.values()}
        assert sorted(event['samples'] for event in received.values()) == [2, 6]
        checkpoint = path.parent / 'checkpoints/checkpoint_startup_tiny_1.safetensors'
        saved = deserialize_tree(checkpoint.read_bytes())
        errors = {}
        equal_mean_error = {}
        weighted_values = {}
        for key in aggregate:
            for client_id, event in trained.items():
                assert event['device'] == 'cpu'
                assert event['samples'] == received[client_id]['samples']
                np.testing.assert_array_equal(initial[client_id][key], baseline[key])
                np.testing.assert_array_equal(event['weights'][key], received[client_id]['weights'][key])
            assert any(not np.array_equal(event['weights'][key], baseline[key]) for event in trained.values())
            values = [np.asarray(event['weights'][key], dtype=np.float64) for event in received.values()]
            counts = [event['samples'] for event in received.values()]
            expected = sum(value * count for value, count in zip(values, counts, strict=True)) / sum(counts)
            actual = np.asarray(aggregate[key], dtype=np.float64)
            np.testing.assert_allclose(actual, expected, rtol=1e-5, atol=1e-6)
            # Independent arithmetic verifies the exact existing reference too.
            np.testing.assert_array_equal(expected, reference_values[key])
            np.testing.assert_array_equal(np.asarray(saved[key]), np.asarray(aggregate[key], dtype=np.float32))
            errors[key] = float(np.max(np.abs(actual - expected)))
            equal_mean_error[key] = float(np.max(np.abs(actual - sum(values) / 2)))
            weighted_values[key] = expected.tolist()
        assert max(equal_mean_error.values()) > 0.001
        with (path.parent / 'checkpoints/current_round.pkl').open('rb') as stream:
            assert pickle.load(stream) == 1
        output['socket_checks'].append({'owner': label, 'python': py,
            'result': {'path': str(path), 'sha256': sha(path)},
            'checkpoint': {'path': str(checkpoint), 'sha256': sha(checkpoint)},
            'samples': counts, 'max_absolute_error': errors,
            'error_if_unweighted_mean': equal_mean_error,
            'float64_reference': weighted_values,
            'received_equals_trained': True, 'checkpoint_equals_aggregate': True,
            'natural_parent_and_child_return': True, 'survivors': []})
output['source'] = {'path': str(REPO / 'tests/integration/startup_socket.py'),
                    'sha256': sha(REPO / 'tests/integration/startup_socket.py')}
(SCRATCH / 'numerics-audit.json').write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps(output, indent=2))
