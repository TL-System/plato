"""Independent real checkpoint/startup/selection probes, with retained JSON."""
import argparse
import hashlib
import importlib.metadata
import json
import pickle
import platform
import random
import sys
import traceback
from pathlib import Path
from unittest.mock import patch

import numpy as np
import torch

from plato.config import Config
from tests.integration.utils import build_minimal_config, configure_environment

parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--mode', choices=['green', 'red-f28', 'red-selection', 'legacy-write'], default='green')
parser.add_argument('--legacy-root', type=Path)
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=True)
population = list(range(1, 11))
records = []

def config(central, seed):
    value = build_minimal_config(total_clients=10, clients_per_round=2,
                                 model_name='review_linear', rounds=9)
    value['server'].update(do_test=False, disable_clients=False)
    if seed is None:
        del value['server']['random_seed']
    else:
        value['server']['random_seed'] = seed
    if central:
        value['algorithm'].update(cross_silo=True, total_silos=2, local_rounds=1)
    return value

def construct(cls=None):
    from plato.servers import fedavg
    from plato.trainers.composable import ComposableTrainer
    return (cls or fedavg.Server)(model=lambda: torch.nn.Linear(3, 2),
                                 trainer=ComposableTrainer)

def verify_numpy(state):
    current = np.random.get_state()
    assert current[0] == state[0]
    np.testing.assert_array_equal(current[1], state[1])
    assert current[2:] == state[2:]

def choose(server):
    # Observe the real strategy dispatch; use the public inherited selector.
    original = server.client_selection_strategy.select_clients
    with patch.object(server.client_selection_strategy, 'select_clients') as spy:
        def dispatch(pool, count, context):
            assert context.state['prng_state'] == server.prng_state
            assert context.current_round == server.current_round
            return original(pool, count, context)
        spy.side_effect = dispatch
        result = server.choose_clients(population, 2)
        assert spy.call_count == 1
    assert server.prng_state == server.context.state['prng_state'] == random.getstate()
    return result

def run_body(server, body, launches, central, resume):
    from plato.servers import base
    Config.args.resume = resume
    with patch.object(base.Server, '_start_clients', side_effect=lambda **kw: launches.append(kw)), patch.object(server, 'start', side_effect=body):
        before = len(launches)
        server.run()
        assert len(launches) == before + 1
        assert bool(launches[-1].get('as_server', False)) == central

def checkpoint_case(central, seed, draws, boundary):
    name = f'checkpoint-{central}-{seed}-{draws}-{boundary}'
    directory = args.output / name
    directory.mkdir()
    with configure_environment(config(central, seed), runtime_root=directory):
        from plato.servers import fedavg
        random.seed(17)
        np.random.seed(19)
        writer = construct()
        python_ref = random.Random()
        python_ref.setstate(writer.prng_state)
        if seed is not None:
            python_ref.seed(seed)
        expected_prior = [python_ref.sample(population, 2) for _ in range(boundary)]
        expected = [python_ref.sample(population, 2) for _ in range(5)]
        prior = []
        owned = []
        numpy_ref = np.random.RandomState()
        weights = {}
        uninterrupted = []
        launches = []
        def write_body():
            assert writer.current_round == 0 and not writer.resumed_session
            prior.extend(choose(writer) for _ in range(boundary))
            writer.current_round = boundary
            for value in writer.trainer.model.parameters():
                with torch.no_grad():
                    value.fill_(1.25 if value.ndim == 2 else -0.75)
            weights.update({key: value.clone() for key, value in writer.trainer.model.state_dict().items()})
            # Include NumPy's cached Gaussian, in addition to its integer array.
            np.random.normal(size=7)
            numpy_ref.set_state(np.random.get_state())
            for _ in range(draws):
                random.random()
            global_before = random.getstate()
            owned.append(writer.prng_state)
            context_before = writer.context.state['prng_state']
            torch_before = torch.get_rng_state().clone()
            writer.save_to_checkpoint()
            assert random.getstate() == global_before
            assert writer.prng_state == owned[0]
            assert writer.context.state['prng_state'] == context_before
            verify_numpy(numpy_ref.get_state())
            assert torch.equal(torch.get_rng_state(), torch_before)
            checkpoint = Path(Config.params['checkpoint_path'])
            assert {p.name for p in checkpoint.iterdir()} == {
                f'checkpoint_review_linear_{boundary}.safetensors',
                f'checkpoint_review_linear_{boundary}.safetensors.pkl',
                f'numpy_prng_state_{boundary}.pkl', f'prng_state_{boundary}.pkl',
                'current_round.pkl'}
            with (checkpoint / f'prng_state_{boundary}.pkl').open('rb') as stream:
                persisted = pickle.load(stream)
            assert isinstance(persisted, tuple) and len(persisted) == 3
            if args.mode == 'green':
                assert persisted == owned[0]
            # Repeated saves after more intrusive global draws keep the boundary.
            first_tuple = (checkpoint / f'prng_state_{boundary}.pkl').read_bytes()
            if args.mode == 'green':
                random.random()
                second_global = random.getstate()
                writer.save_to_checkpoint()
                assert random.getstate() == second_global
                assert (checkpoint / f'prng_state_{boundary}.pkl').read_bytes() == first_tuple
            uninterrupted.extend(choose(writer) for _ in range(5))
        run_body(writer, write_body, launches, central, False)
        assert prior == expected_prior
        assert uninterrupted == expected
        random.seed(991)
        np.random.seed(992)
        reader = construct()
        observed = []
        stale = []
        def read_body():
            assert reader.current_round == boundary and reader.resumed_session
            verify_numpy(numpy_ref.get_state())
            for key, value in reader.trainer.model.state_dict().items():
                assert torch.equal(value, weights[key])
            stale.append(reader.context.state['prng_state'] != reader.prng_state)
            # Arbitrary global draws after restoration must also be irrelevant.
            for count in (1, 7, 2, 9, 4):
                for _ in range(count):
                    random.random()
                observed.append(choose(reader))
                assert np.random.normal() == numpy_ref.normal()
        run_body(reader, read_body, launches, central, True)
        detail = {'name': name, 'prior': prior, 'expected': expected,
                  'uninterrupted': uninterrupted, 'resumed': observed,
                  'context_stale_before_first_selection': stale[0],
                  'model_round_numpy_restored': True,
                  'launches': len(launches)}
        assert observed == expected, json.dumps(detail)
        assert reader.prng_state == python_ref.getstate()
        records.append({**detail, 'pass': True})

def custom_case(central, seed):
    directory = args.output / f'custom-{central}-{seed}'
    directory.mkdir()
    with configure_environment(config(central, seed), runtime_root=directory):
        from plato.servers import fedavg
        reference = random.Random(121)
        reference.sample(population, 2)
        state = reference.getstate()
        expected = [reference.sample(population, 2) for _ in range(5)]
        class Custom(fedavg.Server):
            def _resume_from_checkpoint(self):
                self.current_round = 7
                self.prng_state = state
                # A custom override may own only the selection tuple.
        server = construct(Custom)
        launches = []
        actual = []
        def body():
            assert server.current_round == 7 and not server.resumed_session
            actual.extend(choose(server) for _ in range(5))
        run_body(server, body, launches, central, True)
        assert actual == expected
        records.append({'name': directory.name, 'pass': True, 'expected': expected, 'resumed': actual})

def legacy_case(central):
    directory = args.legacy_root / f'legacy-{central}'
    directory.mkdir(exist_ok=True)
    with configure_environment(config(central, 17), runtime_root=directory):
        if args.mode == 'legacy-write':
            random.seed(17)
            np.random.seed(191)
            server = construct()
            launches = []
            def body():
                prior = [choose(server) for _ in range(2)]
                assert prior == [[9, 7], [5, 6]]
                server.current_round = 2
                for parameter in server.trainer.model.parameters():
                    with torch.no_grad():
                        parameter.fill_(3.25)
                for _ in range(13):
                    random.random()
                legacy_state = random.getstate()
                selection_state = server.prng_state
                server.save_to_checkpoint()
                with (Path(Config.params['checkpoint_path']) / 'prng_state_2.pkl').open('rb') as stream:
                    assert pickle.load(stream) == legacy_state != selection_state
                reference = random.Random()
                reference.setstate(legacy_state)
                (directory / 'legacy-reference.json').write_text(json.dumps({
                    'prior': prior, 'expected': [reference.sample(population, 2) for _ in range(5)],
                    'writer_source': str(Path(sys.modules['plato.servers.base'].__file__).resolve())}) + '\n')
            run_body(server, body, launches, central, False)
        else:
            expected = json.loads((directory / 'legacy-reference.json').read_text())['expected']
            server = construct()
            observed = []
            def body():
                assert server.current_round == 2 and server.resumed_session
                for parameter in server.trainer.model.parameters():
                    assert torch.equal(parameter, torch.full_like(parameter, 3.25))
                np.testing.assert_array_equal(np.random.get_state()[1], np.random.RandomState(191).get_state()[1])
                observed.extend(choose(server) for _ in range(5))
            run_body(server, body, [], central, True)
            assert observed == expected
        records.append({'name': f'actual-old-writer-{central}', 'pass': True})

failures = []
if args.mode == 'green':
    cases = [(central, seed, draws, boundary) for central in (False, True)
             for seed in (17, None) for draws in (0, 1, 37) for boundary in (0, 2)]
elif args.mode == 'red-f28':
    cases = [(central, 17, 0, 2) for central in (False, True)]
elif args.mode == 'red-selection':
    cases = [(central, seed, draws, 2) for central in (False, True)
             for seed in (17, None) for draws in (1, 37)]
else:
    cases = []
for parameters in cases:
    try:
        checkpoint_case(*parameters)
    except Exception as error:
        failures.append({'parameters': parameters, 'type': type(error).__name__,
                         'message': str(error), 'traceback': traceback.format_exc()})
if args.mode == 'green':
    for central in (False, True):
        for seed in (17, None):
            custom_case(central, seed)
if args.legacy_root is not None:
    for central in (False, True):
        legacy_case(central)

import plato
from plato.servers import base
result = {'mode': args.mode, 'python': platform.python_version(),
          'executable': sys.executable, 'cwd': str(Path.cwd()),
          'plato_source': str(Path(plato.__file__).resolve()),
          'server_source': str(Path(base.__file__).resolve()),
          'server_sha256': hashlib.sha256(Path(base.__file__).read_bytes()).hexdigest(),
          'versions': {name: importlib.metadata.version(name) for name in (
              'torch', 'numpy', 'pytest', 'python-socketio', 'aiohttp', 'safetensors')},
          'passed': len(records), 'failed': len(failures),
          'records': records, 'failures': failures,
          'boundary': 'Real configure/trainer/save/load/inherited run/selection; external listener and launch intercepted; no fixture-created event loop.'}
(args.output / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ('mode', 'python', 'server_source', 'server_sha256', 'passed', 'failed')}))
sys.exit(bool(failures))
