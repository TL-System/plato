"""Verify retained receipts and write only the assigned root review report."""
import hashlib
import json
import re
import shlex
import subprocess
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

import psutil

REPO = Path('/private/tmp/plato-refresh-worktrees/runtime-resume-review')
ROOT = Path('/Users/bli/Playground/plato')
S = Path('/tmp/plato-phase2b-resume-review')
DESTINATION = ROOT / 'evidence/2026-refresh/phase2b-resume-review.json'
ACCEPTED = '00eeb9dcdd2b513e64db9408969356037e09bb8e'
F28 = '5b1c4a5d9ed2c29e33cdd2d99c28dd83a7ce377b'
FINAL = 'a058a2ef8d230ca2e34dbf1c91e6eaac0b0205ac'
TREE = '35098e6ba5f5792052ed6b24a771aec7b2cad9bb'

def load(path):
    return json.loads(path.read_text())

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def artifact(path):
    return {'path': str(path), 'sha256': digest(path)}

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO).decode().strip()

initial = load(S / 'initial-audit.json')
assert git('rev-parse', 'HEAD') == FINAL == initial['candidate_commit']
assert git('rev-parse', 'HEAD^{tree}') == TREE == initial['candidate_tree']
assert git('status', '--porcelain=v1', '--untracked-files=all') == ''
for name, expected in initial['candidate_sha256'].items():
    assert digest(REPO / name) == expected, name
for name, expected in initial['authority_sha256'].items():
    assert digest(Path(name)) == expected, name
for name, expected in initial['author_scratch_sha256'].items():
    assert digest(Path(name)) == expected, name

source = initial['candidate_sha256']
assert git('rev-parse', f'{FINAL}^') == '4329158c20f1533301c4d9430393ff282f9cb2be'
assert git('diff', '--name-only', f'{FINAL}^', FINAL) == 'evidence/2026-refresh/phase2b-selection-rng-validation.json'
plan_review = load(ROOT / 'evidence/2026-refresh/plan-review-3.json')
assert digest(ROOT / 'evidence/2026-refresh/plan.md') == plan_review['reviewed_plan_sha256']

final_audit = {'completed_utc': datetime.now(timezone.utc).isoformat(),
    'candidate_commit': FINAL, 'candidate_tree': TREE, 'status': 'clean',
    'all_tracked_regular_files_unchanged': len(source),
    'author_scratch_files_unchanged': len(initial['author_scratch_sha256']),
    'root_authority_files_unchanged': len(initial['authority_sha256']),
    'original_b_report_unchanged': True, 'historical_f28_report_unchanged': True,
    'current_surviving_reviewer_startup_processes': []}
for py in ('313', '314'):
    for path in (S / f'startup{py}').rglob('result.json'):
        record = load(path)
        assert record['survivors'] == []
        for pid, created in record['processes'].items():
            try:
                process = psutil.Process(int(pid))
                if process.create_time() == created and process.status() != psutil.STATUS_ZOMBIE:
                    final_audit['current_surviving_reviewer_startup_processes'].append(int(pid))
            except psutil.NoSuchProcess:
                pass
assert final_audit['current_surviving_reviewer_startup_processes'] == []
(S / 'final-audit.json').write_text(json.dumps(final_audit, indent=2) + '\n')

ENV = ('PYTHONDONTWRITEBYTECODE=1 XDG_CACHE_HOME=/tmp/plato-phase2b-resume-review/cache '
       'MPLCONFIGDIR=/tmp/plato-phase2b-resume-review/mpl OMP_NUM_THREADS=1 '
       'OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 '
       'VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1')
FOCUSED_ENV = ('PYTHONDONTWRITEBYTECODE=1 '
       'PYTHONPATH=/private/tmp/plato-refresh-worktrees/runtime-resume-review '
       'XDG_CACHE_HOME=/tmp/plato-phase2b-resume-review/cache '
       'MPLCONFIGDIR=/tmp/plato-phase2b-resume-review/mpl OMP_NUM_THREADS=1 '
       'OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 '
       'NUMEXPR_NUM_THREADS=1')
TARGETS = ('tests/servers/test_server_resume_rng.py '
           'tests/servers/test_personalized_selection_strategy.py '
           'tests/servers/test_split_learning_selection_strategy.py')
STARTUP_TESTS = ['test_fresh_entrypoint_executes_scheduled_work',
    'test_active_failure_reaches_synchronous_caller',
    'test_preconstructed_borrowed_loop_resources_survive',
    'test_explicitly_absent_loop_on_server_and_edge',
    'test_real_two_client_cpu_socket_round',
    'test_post_launch_failure_keeps_primary_error_and_contains_children',
    'test_noncooperative_teardown_is_watchdog_containment[task]']
STARTUP_TARGETS = ' '.join("'tests/integration/test_event_loop_startup.py::" + name + "'" for name in STARTUP_TESTS)

def shell(body):
    return 'zsh -lc ' + shlex.quote(body)

def xml_stats(path):
    tree = ET.parse(path)
    suites = tree.findall('.//testsuite')
    data = {name: sum(int(suite.attrib.get(name, '0')) for suite in suites)
            for name in ('tests', 'failures', 'errors', 'skipped')}
    data['seconds'] = sum(float(suite.attrib['time']) for suite in suites)
    data['nodeids'] = [case.attrib['classname'] + '.' + case.attrib['name']
                       for case in tree.findall('.//testcase')]
    return data

def pytest_run(py, label, targets, expected, env):
    stats = xml_stats(S / f'{label}{py}.xml')
    assert stats['tests'] == expected and stats['failures'] == stats['errors'] == stats['skipped'] == 0
    command = (f'{env} /tmp/plato-phase2b-runtime/venv{py}/bin/python -m pytest '
               f'{targets} -q -p no:cacheprovider --basetemp={S}/{label}{py} '
               f'--junitxml={S}/{label}{py}.xml > {S}/{label}{py}.log 2>&1')
    return {'command': shell(command), 'cwd': str(REPO), 'exit_code': 0,
            'result': stats, 'log': artifact(S / f'{label}{py}.log'),
            'junit': artifact(S / f'{label}{py}.xml')}

report = {'schema_version': 1,
    'review': 'Fresh independent supplemental Phase 2B F28 and B-RESUME-01 review',
    'reviewer': 'plato-phase2b-resume-review',
    'requested_model': 'Sol', 'requested_reasoning_effort': 'xhigh',
    'completed_at_utc': datetime.now(timezone.utc).isoformat(),
    'decision': 'PASS',
    'decision_basis': [
        'No critical, high or medium findings in the combined supplement above accepted original B. Both seed guards preserve resume ownership, and the existing Python tuple now persists self.prng_state without mutating live RNG state.',
        'Independent actual save/inherited run/restore/strategy probes reproduce both defects on exact historical Git archives and pass on the pinned final candidate, with five resumed choices agreeing with saved uninterrupted controls and a separate random.Random reference.',
        'Both interpreters pass 212 affected runtime cases, 22 fresh startup cases and 40 independent persistence/error cases. All 96 final-author startup records, hashes and durable streams pass the unchanged startup assertions; normal socket success is separated from deliberate containment.',
        'Candidate and both historical B evidence reports remain unchanged; final combined C checkpoint-codec integration remains root/C ownership.'
    ],
    'findings': [], 'optional_low_observations': [],
    'severity_counts': {'critical': 0, 'high': 0, 'medium': 0, 'low': 0},
    'identities': {
        'accepted_original_b_commit': ACCEPTED,
        'accepted_original_b_tree': git('rev-parse', f'{ACCEPTED}^{{tree}}'),
        'historical_f28_intermediate': F28,
        'historical_f28_tree': git('rev-parse', f'{F28}^{{tree}}'),
        'candidate_commit': FINAL, 'candidate_tree': TREE,
        'implementation_commit': '4329158c20f1533301c4d9430393ff282f9cb2be',
        'implementation_tree': git('rev-parse', '4329158c20f1533301c4d9430393ff282f9cb2be^{tree}'),
        'candidate_worktree': str(REPO), 'review_scratch': str(S),
        'candidate_status_before_and_after': 'clean',
        'candidate_all_tracked_regular_files_match_exact_git_objects': len(source),
        'candidate_all_tracked_regular_files_unchanged_through_review': len(source),
        'only_changes_above_accepted_b': initial['changes_from_accepted'],
        'candidate_is_evidence_only_direct_child_of_implementation': True,
        'source_and_test_sha256': {name: source[name] for name in source if name.startswith((
            'plato/servers/', 'plato/clients/', 'plato/callbacks/',
            'tests/servers/', 'tests/clients/', 'tests/callbacks/',
            'tests/integration/startup', 'tests/integration/test_event_loop'))},
        'original_reports_sha256': {name: source[name] for name in (
            'evidence/2026-refresh/phase2b-validation.json',
            'evidence/2026-refresh/phase2b-resume-validation.json',
            'evidence/2026-refresh/phase2b-selection-rng-validation.json')},
        'authority_sha256': {**initial['authority_sha256'],
            str(ROOT / 'evidence/2026-refresh/plan-review-3.json'): digest(ROOT / 'evidence/2026-refresh/plan-review-3.json')},
        'initial_audit': artifact(S / 'initial-audit.json'),
        'final_audit': artifact(S / 'final-audit.json'),
        'accepted_to_candidate_diff': artifact(S / 'accepted-to-candidate.diff'),
        'f28_to_final_diff': artifact(S / 'f28-to-final.diff'),
        'red_source_archives': [
            {'commit': ACCEPTED, 'archive': artifact(S / 'accepted.tar'),
             'base_source': artifact(S / 'accepted/plato/servers/base.py')},
            {'commit': F28, 'archive': artifact(S / 'f28.tar'),
             'base_source': artifact(S / 'f28/plato/servers/base.py')}],
        'no_evolving_c_or_runtime_source_read_or_execution': True,
        'nested_agents': 0, 'source_edits': 0, 'commits': 0, 'cleanup': 0
    },
    'authority_and_evidence_read': [
        'ROOT AGENTS.md, accepted plan.md and plan-review-3.json, plan-addendum.json and acceptance',
        'ROOT phase2b-acceptance.json and complete structured phase2b-review-3.json; relevant contract dispositions and commands inspected',
        'ROOT server-resume-rng-probe.json',
        'Historical phase2b-resume-validation.json at exact 5b1c4a5d; it still reports the then-unfixed B-RESUME-01',
        'Final phase2b-selection-rng-validation.json plus author red/green/source/environment manifests, startup summary, all 96 raw result JSONs and associated durable event streams',
        'Immutable final base.py, real selection strategies/configure/trainer persistence, supplemental tests and unchanged startup harness/probes; exact historical sources from Git archives'
    ],
    'contract_disposition': {
        'F28': {'status': 'PASS', 'locations': [
            {'file': 'plato/servers/base.py', 'line': 351},
            {'file': 'plato/servers/base.py', 'line': 378},
            {'file': 'plato/servers/base.py', 'line': 395}],
            'prior': [[9, 7], [5, 6]],
            'independent_red_next_choices': [[9, 7], [5, 6], [5, 3], [9, 5], [2, 1]],
            'expected_and_final_next_choices': [[5, 3], [9, 5], [2, 1], [4, 7], [7, 5]],
            'proof': 'Exact original B save -> inherited run/_resume -> real public choose_clients/RandomSelectionStrategy fails in both startup branches; final candidate preserves model, round, NumPy and selection. Fresh configured and no-seed runs, custom overrides without resumed_session, and all ordinary/central guards pass.'},
        'B-RESUME-01': {'status': 'PASS',
            'locations': [{'file': 'plato/servers/base.py', 'line': 1636},
                          {'file': 'plato/servers/base.py', 'line': 846},
                          {'file': 'plato/servers/base.py', 'line': 1657}],
            'independent_red_after_one_draw': [[9, 5], [2, 1], [4, 7], [7, 5], [9, 6]],
            'independent_red_after_37_draws': [[1, 6], [1, 8], [6, 1], [7, 4], [2, 9]],
            'expected_and_final': [[5, 3], [9, 5], [2, 1], [4, 7], [7, 5]],
            'proof': 'Eight independent 5b1c continuation cases fail per interpreter after one or 37 intrusive global draws, with genuine model/round/NumPy restore succeeding. Final candidate matches five uninterrupted selections and independent reference for ordinary/central x configured/no-seed x 0/1/37 draws x checkpoint before first choice/after two choices.',
            'save_effects': 'Actual save preserves live global Python, self.prng_state, context, full NumPy state including cached Gaussian, and CPU Torch state; repeated save after another global draw persists the identical selection tuple. Unrelated draws after resume also leave the next selection sequence correct.',
            'context': 'Context can be stale immediately after restore; the unchanged wrapper refreshes prng_state/current_round before actual strategy dispatch and preserves owned/context/global equality after selection.',
            'format_and_legacy': 'Same prng_state_<round>.pkl random-state tuple, pickle writer and reader. Independently generate actual old-writer checkpoint bundles on exact 5b1c, including diverged global state, then load them with final inherited run in both branches. Existing tuple remains readable with its recorded historical continuation.'},
        'checkpoint_errors': {'status': 'PASS',
            'proof': 'Eight shipped broken-pickle/Safetensors cases plus ten independent missing-file and semantically invalid valid-pickle RNG cases per interpreter raise before launch, periodic creation or socket start. Existing missing-model OSError remains visible. No atomic generic-restore claim.'},
        'retained_b_runtime': {'status': 'PASS',
            'proof': 'Accepted source outside base.py is byte-identical, as are all earlier tests/harnesses. The complete 212-case client/server/callback/smoke subset passes both versions, covering retained transport/session/timeout/recovery/PORT/S3/cleanup/aggregation/selection behavior. This is regression execution, not a new security-clean claim.'},
        'startup': {'status': 'PASS',
            'proof': 'Audit all 48 final-author records per interpreter against unchanged source assertions and raw event streams; verify five intended watchdogs and no survivors. Fresh reviewer subset has 22 executions per interpreter, including socket round, post-launch failure, borrowed/absent loops and one deliberate teardown watchdog.'}
    },
    'runs': {},
    'author_evidence_audit': {
        'verified_report_artifact_receipts': initial['verified_author_report_receipts'],
        'author_scratch_files_byte_identical_before_and_after': len(initial['author_scratch_sha256']),
        'original_b_report_byte_identical_to_accepted_commit': True,
        'historical_f28_report_byte_identical_to_5b1c_commit': True,
        'author_red_source_and_tests': {
            'original_b_source_sha256': digest(S / 'accepted/plato/servers/base.py'),
            'f28_source_sha256': digest(S / 'f28/plato/servers/base.py'),
            'historical_f28_test_sha256': digest(S / 'f28/tests/servers/test_server_resume_rng.py'),
            'selection_red_test_reconstructed_exact_receipt': artifact(S / 'reconstructed-author-red-regression.py'),
            'selection_red_green_test_ast_identical': True},
        'author_logs': 'Historical F28: 4 failed/14 passed red, 25 focused green and 48 startup per version. Latest selection persistence: 8 failed/27 passed red, 35 focused green and 48 startup per version. Verified hashed receipts; historical runs are not counted as fresh reviewer execution.',
        'startup_audits': [artifact(S / f'author-startup-audit{py}.json') for py in ('313', '314')],
        'numerics_audit': artifact(S / 'numerics-audit.json'),
        'audit_count_policy': 'The 48-record assertion replay per version audits retained evidence; it does not execute new startup processes. Replay uses scratch pytest root, producing eight harmless unknown-mark warnings per version. Its late port bind checks current availability, not historical contemporaneous port release; original author execution retains that assertion.'
    },
    'socket_numerics': load(S / 'numerics-audit.json')['socket_checks'],
    'count_policy': {
        'distinct_final_reviewer_cases_per_interpreter': 274,
        'breakdown': {'tracked_client_server_callback_smoke': 212,
                      'fresh_startup_process_cases': 22,
                      'independent_resume_save_fresh_custom_legacy': 30,
                      'independent_missing_or_invalid_checkpoint': 10},
        'focused_35': 'Separately rerun early; all 35 overlap the later 212-case runtime execution and are not added to the distinct count.',
        'red': '2 F28 + 8 B-RESUME-01 independent expected failures per interpreter; red cases do not count as green coverage.',
        'legacy_writer_setup': '2 historical writer operations per interpreter prepare bundles for two of the 30 final independent cases; not added as green candidate cases.',
        'author_and_replay': 'Author 83 green and replay 48 per version are retained/audited evidence, not extra independent execution counts.'
    },
    'checks': [
        {'command': shell('git diff --check ' + ACCEPTED + ' HEAD'), 'cwd': str(REPO), 'exit_code': 0},
        {'command': shell('PYTHONDONTWRITEBYTECODE=1 RUFF_CACHE_DIR=/tmp/plato-phase2b-resume-review/ruff /tmp/plato-phase2b-runtime/venv313/bin/ruff check plato/servers/base.py tests/servers/test_server_resume_rng.py --select I'), 'cwd': str(REPO), 'exit_code': 0},
        {'command': shell('PYTHONDONTWRITEBYTECODE=1 RUFF_CACHE_DIR=/tmp/plato-phase2b-resume-review/ruff /tmp/plato-phase2b-runtime/venv313/bin/ruff format --check tests/servers/test_server_resume_rng.py'), 'cwd': str(REPO), 'exit_code': 0}
    ],
    'reviewer_harness_corrections': [
        'Initial legacy-writer setup omitted parent mkdir, causing two harness FileNotFoundErrors before product execution. Parent creation fixed in owned scratch; original logs retained and successful setup reruns recorded.',
        'Initial missing-model negative probe expected FileNotFoundError; existing ComposableTrainer correctly raises OSError. Corrected only that expectation; retained initial logs and first script; all ten final negative cases pass each version.'
    ],
    'limits_and_root_handoff': [
        'PASS covers this exact supplemental component above original accepted B; root has not thereby accepted or validated a later combined C integration.',
        'No evolving C/runtime source was read or tested. Root/C must merge the supplemental changes with collision-safe checkpoint codec work at a clean boundary, preserve both seed guards and owned-state persistence, then run combined checkpoint/startup regressions.',
        'Independent save/resume probes execute actual generic configure, ComposableTrainer save/load, inherited Server.run/_resume_from_checkpoint and production strategy selection. External launch and listener are intercepted; configure_environment creates no loop. Full resumed network training, optimizer continuation, mid-round server restart, accelerator/GPU replay and complete cross-silo replay are not qualified.',
        'Selection tuple is authoritative; resume still installs it into global Python RNG. No independent continuation guarantee for unrelated global Python randomness. Legacy files remain readable but cannot reconstruct a selection boundary an old writer did not persist.',
        'Generic NumPy/model/round behavior is preserved. Error propagation is qualified, not atomic whole-bundle rollback. The separate accepted FedDyn local-checkpoint requirement to preserve all global/selection/NumPy/Torch state after complete validation remains a different algorithm contract; this review does not accept that new algorithm.',
        'Trusted-peer socket/S3/pickle boundaries and prior security disposition remain inherited. Regression passes do not create a fresh blanket security-clean claim, authentication guarantee or new transport protocol.',
        'The 48-case author startup suite was audited fully; reviewer reran the affected coherent 22-case subset on both versions, not another redundant full48. Four noncooperative teardown cases and stalled-client watchdog evidence remain negative-path containment, not successful rounds.',
        'Existing author venv313/venv314 were reused with bytecode writing disabled; no sync/install or environment mutation. Durable logs, basetemps, caches, exact historical snapshots and reviewer probes reside in retained review scratch. No implementation edits, merges, commits, publication or task cleanup.'
    ],
    'owned_resources': {'scratch': str(S), 'review_output': str(DESTINATION),
                        'retention': 'Retain all reviewer scratch and all original author evidence.'}
}

for py in ('313', '314'):
    green = load(S / f'independent-green{py}/results.json')
    negative = load(S / f'negative-retry{py}/results.json')
    assert green['passed'] == 30 and green['failed'] == 0
    assert negative['passed'] == 10 and negative['failed'] == 0
    assert green['server_sha256'] == source['plato/servers/base.py']
    assert negative['server_sha256'] == source['plato/servers/base.py']
    env = ENV + ' PYTHONPATH=' + str(REPO)
    focused = pytest_run(py, 'focused', TARGETS, 35, FOCUSED_ENV)
    startup = pytest_run(py, 'startup', STARTUP_TARGETS, 22, FOCUSED_ENV)
    runtime = pytest_run(py, 'runtime', 'tests/clients tests/servers tests/callbacks tests/integration/test_smoke_configs.py --test-profile base', 212, env)
    assert set(focused['result']['nodeids']).issubset(runtime['result']['nodeids'])
    startup_records = [load(path) for path in (S / f'startup{py}').rglob('result.json')]
    assert len(startup_records) == 22
    watchdog = [record for record in startup_records if record['timed_out']]
    assert len(watchdog) == 1 and watchdog[0]['case'] == 'client_lifecycle'
    assert watchdog[0]['options']['stall'] == 'task' and watchdog[0]['forced']
    startup['deliberate_containment_cases'] = [{'case': row['case'], 'options': row['options'],
                                              'forced': row['forced'], 'returncode': row['returncode']} for row in watchdog]
    startup['survivors'] = []
    rows = []
    for label, mode, archive_name, expected in (
            ('red-f28', 'red-f28', 'accepted', 2),
            ('red-selection', 'red-selection', 'f28', 8)):
        data = load(S / f'{label}{py}/results.json')
        assert data['failed'] == expected and data['passed'] == 0
        assert all(item['type'] == 'AssertionError' and item['message'].startswith('{') for item in data['failures'])
        command = (f'{ENV} PYTHONPATH={S}/{archive_name} /tmp/plato-phase2b-runtime/venv{py}/bin/python '
                   f'{S}/independent_resume_probe.py --mode={mode} --output={S}/{label}{py} '
                   f'> {S}/{label}{py}.log 2>&1')
        rows.append({'command': shell(command), 'cwd': str(S / archive_name), 'exit_code': 1,
                     'expected_failures': expected, 'source_sha256': data['server_sha256'],
                     'probe_source': artifact(S / 'independent_resume_probe_red_version.py'),
                     'log': artifact(S / f'{label}{py}.log'),
                     'results': artifact(S / f'{label}{py}/results.json'),
                     'expected_vs_actual': [json.loads(item['message']) for item in data['failures']]})
    setup_body = (f'{ENV} PYTHONPATH={S}/f28 /tmp/plato-phase2b-runtime/venv{py}/bin/python '
                  f'{S}/independent_resume_probe.py --mode=legacy-write --output={S}/legacy-write{py} '
                  f'--legacy-root={S}/legacy{py} > {S}/legacy-write{py}-retry.log 2>&1')
    green_body = (f'{env} /tmp/plato-phase2b-runtime/venv{py}/bin/python '
                  f'{S}/independent_resume_probe.py --mode=green --output={S}/independent-green{py} '
                  f'--legacy-root={S}/legacy{py} > {S}/independent-green{py}.log 2>&1')
    negative_body = (f'{ENV} TMPDIR={S}/tmp PYTHONPATH={REPO} /tmp/plato-phase2b-runtime/venv{py}/bin/python '
                     f'{S}/independent_negative_probe.py {S}/negative-retry{py} '
                     f'> {S}/negative-retry{py}.log 2>&1')
    report['runs'][green['python']] = {
        'environment': {key: green[key] for key in ('python', 'executable', 'cwd', 'plato_source', 'server_source', 'versions')},
        'focused': focused, 'retained_runtime': runtime, 'fresh_startup_subset': startup,
        'independent_expected_red': rows,
        'historical_writer_setup': {'command': shell(setup_body), 'cwd': str(S / 'f28'),
                                   'exit_code': 0, 'bundles': 2,
                                   'log': artifact(S / f'legacy-write{py}-retry.log'),
                                   'results': artifact(S / f'legacy-write{py}/results.json')},
        'independent_final': {'command': shell(green_body), 'cwd': str(REPO), 'exit_code': 0,
                             'passed': 30, 'failed': 0,
                             'log': artifact(S / f'independent-green{py}.log'),
                             'results': artifact(S / f'independent-green{py}/results.json')},
        'independent_negative': {'command': shell(negative_body), 'cwd': str(REPO), 'exit_code': 0,
                                'passed': 10, 'failed': 0,
                                'log': artifact(S / f'negative-retry{py}.log'),
                                'results': artifact(S / f'negative-retry{py}/results.json')},
        'warning_disposition': 'Early focused 3.13 has one inherited get_event_loop deprecation warning; focused 3.14 has none. Both later 212-case runtime and 22-case startup suites report no warnings/skips.'
    }

# Hash all retained scratch artifacts without a self-referential manifest entry.
manifest_path = S / 'scratch-manifest.json'
scratch_files = {str(path.relative_to(S)): digest(path)
                 for path in sorted(S.rglob('*')) if path.is_file() and path != manifest_path}
manifest_path.write_text(json.dumps(scratch_files, indent=2) + '\n')
report['owned_resources']['scratch_manifest'] = artifact(manifest_path)
report['owned_resources']['reviewer_probes'] = [artifact(S / name) for name in (
    'independent_resume_probe.py', 'independent_resume_probe_red_version.py',
    'independent_negative_probe.py', 'independent_negative_probe_first.py',
    'test_replay_startup_records.py', 'audit_evidence.py', 'audit_numerics.py', 'build_review.py')]
assert not DESTINATION.exists(), 'Assigned review output already exists; do not overwrite another review.'
DESTINATION.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'decision': report['decision'], 'output': str(DESTINATION),
                  'sha256': digest(DESTINATION),
                  'distinct_final_cases_per_interpreter': 274,
                  'candidate_status': final_audit['status'],
                  'author_scratch_files_unchanged': final_audit['author_scratch_files_unchanged']}))
