"""Real startup propagation for missing files and malformed valid-pickle states."""
import hashlib
import json
import pickle
import platform
from pathlib import Path
from unittest.mock import patch

import numpy as np
import torch

from plato.config import Config
from tests.integration.utils import build_minimal_config, configure_environment

output = Path(__import__('sys').argv[1])
output.mkdir(parents=True, exist_ok=True)
records = []
for central in (False, True):
    for kind in ('missing-round', 'missing-python', 'missing-model', 'invalid-python', 'invalid-numpy'):
        directory = output / f'{central}-{kind}'
        directory.mkdir()
        config = build_minimal_config(total_clients=10, clients_per_round=2,
                                      model_name='review_negative')
        config['server'].update(do_test=False, random_seed=17, disable_clients=False)
        if central:
            config['algorithm'].update(cross_silo=True, total_silos=2, local_rounds=1)
        with configure_environment(config, runtime_root=directory):
            from plato.servers import base, fedavg
            from plato.trainers.composable import ComposableTrainer
            def make():
                return fedavg.Server(model=lambda: torch.nn.Linear(2, 1),
                                     trainer=ComposableTrainer)
            writer = make()
            writer.configure()
            writer.current_round = 2
            writer.save_to_checkpoint()
            checkpoint = Path(Config.params['checkpoint_path'])
            if kind.startswith('missing-'):
                target = {'missing-round': 'current_round.pkl',
                          'missing-python': 'prng_state_2.pkl',
                          'missing-model': 'checkpoint_review_negative_2.safetensors'}[kind]
                # Move within owned scratch instead of deleting any artifact.
                (checkpoint / target).rename(checkpoint / (target + '.retained'))
                expected = FileNotFoundError
            elif kind == 'invalid-python':
                with (checkpoint / 'prng_state_2.pkl').open('wb') as stream:
                    pickle.dump((3, (1, 2), None), stream)
                expected = ValueError
            else:
                with (checkpoint / 'numpy_prng_state_2.pkl').open('wb') as stream:
                    pickle.dump(('unknown-algorithm', np.zeros(624, dtype=np.uint32), 0, 0, 0.0), stream)
                expected = ValueError
            server = make()
            Config.args.resume = True
            calls = []
            with patch.object(base.Server, '_start_clients', side_effect=lambda **kw: calls.append('launch')), patch.object(server, 'start', side_effect=lambda: calls.append('socket')), patch.object(server, '_periodic', side_effect=lambda *a: calls.append('periodic')):
                try:
                    server.run()
                except expected as error:
                    assert calls == [], calls
                    records.append({'central': central, 'kind': kind,
                                    'error': type(error).__name__, 'message': str(error),
                                    'launch_socket_periodic_calls': calls})
                else:
                    raise AssertionError(f'{kind} swallowed or startup continued')
import plato.servers.base as source
result = {'python': platform.python_version(), 'passed': len(records), 'failed': 0,
          'server_source': source.__file__,
          'server_sha256': hashlib.sha256(Path(source.__file__).read_bytes()).hexdigest(),
          'cases': records, 'limit': 'Propagation before external startup; no transactional restore/rollback guarantee.'}
(output / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
