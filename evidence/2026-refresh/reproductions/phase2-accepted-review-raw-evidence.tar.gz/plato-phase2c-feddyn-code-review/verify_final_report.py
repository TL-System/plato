"""Validate assigned report links, hashes, identities, and retained reference."""
import hashlib
import json
from pathlib import Path
import subprocess

H = Path('/tmp/plato-phase2c-feddyn-code-review')
P = Path('/Users/bli/Playground/plato/evidence/2026-refresh/phase2c-feddyn-code-review.json')
R = json.loads(P.read_text())
IDS = {x['id'] for x in R['executions']}
assert {x['id'] for x in R['criterion_mapping']} == {f'FD-A{i:02d}' for i in range(1, 16)}
assert len(R['criterion_mapping']) == 15
verified = []


def walk(value):
    if isinstance(value, dict):
        if {'path', 'sha256', 'bytes'} <= value.keys():
            path = Path(value['path'])
            raw = path.read_bytes()
            assert len(raw) == value['bytes'], path
            assert hashlib.sha256(raw).hexdigest() == value['sha256'], path
            verified.append(str(path))
        for key, item in value.items():
            if key in ('execution_ids', 'independent_evidence', 'evidence') and isinstance(item, list):
                assert all(ident in IDS for ident in item), (key, item)
            walk(item)
    elif isinstance(value, list):
        for item in value:
            walk(item)


walk(R)
for name, digest in (
    ('feddyn_reference.py', '3028ca542112acf494b4d9bc0ea10c8c98df78e49f114b7859ebae0fe5c7f3db'),
    ('reference.json', '77c0fbad765a743bd0153fd17501f1bff9f57417925442235e19647eb4cc75d7'),
    ('preparation-receipt.json', '01904049424e6ee757770bf89ed2d370dbf2d19e400d385914dc053c6f3cd8f0'),
):
    assert hashlib.sha256((H / name).read_bytes()).hexdigest() == digest
for tag in (313, 314):
    observed = json.loads((H / f'final-observed-environment-{tag}.json').read_text())
    declared = R['environments'][str(tag)]
    assert observed['no_plato_import_asserted']
    assert observed['python'] == declared['python']
    assert observed['platform'] == declared['platform']
    assert observed['packages'] == declared['packages']
    assert Path(observed['executable']).resolve() == Path(declared['executable']).resolve()
assert R['dependency_review_context']['review']['sha256'] == 'ecded9d6b645910a5c2b1149181593ab131fd0e404c4bc59a03db18c75cb8d42'
candidate = Path(R['reviewed_candidate']['path'])
for argument, expected in [('HEAD', R['reviewed_candidate']['commit']), ('HEAD^{tree}', R['reviewed_candidate']['tree'])]:
    actual = subprocess.check_output(['zsh', '-lc', 'git rev-parse ' + argument], cwd=candidate, text=True).strip()
    assert actual == expected
assert not subprocess.check_output(['zsh', '-lc', 'git status --porcelain=v1'], cwd=candidate, text=True).strip()
receipt = json.loads((H / 'final-report-receipt.json').read_text())['report']
assert receipt['sha256'] == hashlib.sha256(P.read_bytes()).hexdigest()
result = {'status': 'PASS', 'criteria': 15, 'linked_execution_ids': len(IDS),
          'receipt_occurrences_verified': len(verified), 'unique_receipt_paths': len(set(verified)),
          'report': receipt, 'preparation_reference_unchanged': True,
          'candidate_commit_tree_clean': True, 'observed_environments_match': True}
(H / 'final-report-link-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
