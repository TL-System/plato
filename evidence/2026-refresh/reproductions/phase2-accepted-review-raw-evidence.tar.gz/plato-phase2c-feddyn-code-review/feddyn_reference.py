"""Independent FedDyn numerical oracle; no Plato or federated runtime code.

For F(w)=c*w**2/2-d*w, one SGD update is r*w+b, where
r=1-eta*(c+alpha_i), b=eta*(d+alpha_i*(x-h)). Thus K updates
give r**K*w0+b*sum(r**j, j=0..K-1). This is finite SGD algebra,
not a claim about exact local minimization or convergence.
"""

import argparse
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path
import platform
import random
import sys


def assert_no_plato():
    assert not any(k == "plato" or k.startswith("plato.") for k in sys.modules)


class DenyPlato:
    def find_spec(self, fullname, path=None, target=None):
        if fullname == "plato" or fullname.startswith("plato."):
            raise ModuleNotFoundError("This independent reference forbids Plato imports")
        return None


assert_no_plato()
sys.meta_path.insert(0, DenyPlato())

import numpy as np
import torch

ROOT = Path("/Users/bli/Playground/plato/evidence/2026-refresh")
PRIMARY = Path("/tmp/plato-phase2-root/feddyn-primary")
DESIGN_SHA = "62c5d61805c49ccc06f99776d0da820c5b27cffeb5916754ddb16bb3135c1d5b"
REVIEW_SHA = "454aa4b5d6503e2d3fbdc572719620983bab13cd7fbd5e59df8a3dc254e0f0e1"
TOLERANCES = {
    "fraction": {"comparison": "exact", "encoding": "reduced numerator/denominator string"},
    "float64": {"atol": 1e-12, "rtol": 0, "equal_nan": False},
    "float32": {"atol": 1e-6, "rtol": 1e-6, "equal_nan": False},
}


def coefficients(alpha, counts, mode):
    """Full-population cardinalities are inputs; labels have no role here."""
    assert mode in ("uniform", "sample")
    assert counts and all(type(n) is int and n > 0 for n in counts)
    q = [Q(1)] * len(counts)
    if mode == "sample":
        q = [Q(len(counts) * n, sum(counts)) for n in counts]
    return q, [alpha / qi for qi in q]


def quadratic_endpoint(w0, x, h, alpha, eta, c, d, steps):
    """Closed-form scalar update, usable without NumPy/Torch/Plato helpers."""
    assert steps >= 0
    r = 1 - eta * (c + alpha)
    b = eta * (d + alpha * (x - h))
    geometric_sum = Q(steps) if r == 1 else (1 - r**steps) / (1 - r)
    return r**steps * w0 + b * geometric_sum


def cloud_from_endpoints(x, histories, endpoints):
    """Only numerical algebra: caller supplies a valid nonempty selected set."""
    assert endpoints
    updated = list(histories)
    for client, y in endpoints.items():
        updated[client - 1] += y - x
    selected_mean = sum(endpoints.values(), Q(0)) / len(endpoints)
    population_mean = sum(updated, Q(0)) / len(updated)
    return selected_mean + population_mean, updated, selected_mean, population_mean


def trajectory(counts, mode, selected, targets, x=Q(2), histories=None):
    q, alphas = coefficients(Q(1, 10), counts, mode)
    h = [Q(0)] * len(counts) if histories is None else list(histories)
    rounds = []
    for round_id, clients in enumerate(selected, 1):
        before = list(h)
        endpoints = {
            i: quadratic_endpoint(x, x, h[i - 1], alphas[i - 1],
                                  Q(1, 10), Q(1), Q(targets[i - 1]), 2)
            for i in clients
        }
        next_x, h, selected_mean, mean_h = cloud_from_endpoints(x, h, endpoints)
        rounds.append({
            "round": round_id, "selected": list(clients), "baseline": x,
            "q": q, "alpha_i": alphas, "histories_before": before,
            "endpoints": endpoints,
            "deltas": {i: y - x for i, y in endpoints.items()},
            "histories_after": list(h), "selected_mean": selected_mean,
            "population_history_mean": mean_h, "cloud": next_x,
            "completed_steps": {i: 2 for i in clients},
        })
        x = next_x
    return rounds


def window_case(name, epochs, width, skipped=(), x=Q(2), h=Q(1, 2)):
    """Epoch-local windows use mean-of-microbatch-means, including short tails.

    Each microbatch is (c,d,cardinality) with task gradient c*w-d.
    Cardinality documents the convention; it does not reweight these means.
    A skipped window discards gradients and performs zero SGD updates.
    """
    w = x
    windows = []
    for epoch_id, batches in enumerate(epochs, 1):
        for offset in range(0, len(batches), width):
            group = batches[offset:offset + width]
            c = sum((g[0] for g in group), Q(0)) / len(group)
            d = sum((g[1] for g in group), Q(0)) / len(group)
            skip = len(windows) in skipped
            next_w = w if skip else quadratic_endpoint(
                w, x, h, Q(1, 10), Q(1, 10), c, d, 1
            )
            windows.append({
                "epoch": epoch_id, "microbatches": group,
                "normalizer": len(group), "mean_c": c, "mean_d": d,
                "skipped": skip, "weight_before": w, "weight_after": next_w,
            })
            w = next_w
    completed = sum(not row["skipped"] for row in windows)
    return {"name": name, "x": x, "h": h, "alpha": Q(1, 10),
            "eta": Q(1, 10), "width": width, "windows": windows,
            "completed_steps": completed, "endpoint": w,
            "acceptable_attempt": completed > 0,
            "history_after": h + w - x if completed else None,
            "history_staging_count": int(completed > 0)}


def exact_json(obj):
    if isinstance(obj, Q):
        return str(obj)
    if isinstance(obj, dict):
        return {str(k): exact_json(v) for k, v in obj.items()}
    if isinstance(obj, (tuple, list)):
        return [exact_json(v) for v in obj]
    return obj


def make_reference():
    selected = [[1], [2], [1]]
    trajectories = {
        "uniform": trajectory([1, 3], "uniform", selected, [0, 4]),
        "sample": trajectory([1, 3], "sample", selected, [0, 4]),
        "equal_counts_sample": trajectory([2, 2], "sample", selected, [0, 4]),
        "changed_counts_uniform": trajectory([17, 93], "uniform", selected, [0, 4]),
    }
    scalar_inputs = [
        ("zero_history_fixed_point", Q(2), Q(2), Q(0), Q(1, 10), Q(0), Q(0)),
        ("shifted_nonzero_history", Q(1), Q(2), Q(1, 2), Q(1, 10), Q(0), Q(0)),
        ("same_client_new_baseline", Q(3), Q(3), Q(1, 2), Q(1, 10), Q(0), Q(0)),
        ("alpha_zero_task_only", Q(2), Q(9), Q(7), Q(0), Q(3), Q(2)),
    ]
    scalars = []
    for name, w, x, h, alpha, c, d in scalar_inputs:
        gradient = c * w - d + alpha * (w - x + h)
        y = quadratic_endpoint(w, x, h, alpha, Q(1, 10), c, d, 1)
        scalars.append({"name": name, "w": w, "x": x, "h": h, "alpha": alpha,
                        "c": c, "d": d, "eta": Q(1, 10), "gradient": gradient,
                        "endpoint": y, "history_after": h + y - x})
    x, h, m, mean_h = cloud_from_endpoints(
        Q(2), [Q(2, 5), Q(-1, 5), Q(3, 5)], {1: Q(1), 3: Q(4)}
    )
    zero = (Q(0), Q(0), 1)
    windows = [
        window_case("short", [[zero]], 3),
        window_case("tail", [[zero] * 3], 2),
        window_case("divisible", [[zero] * 4], 2),
        window_case("two_epoch_tails", [[zero] * 3] * 2, 2),
        window_case("one_skipped_then_success", [[zero] * 2], 1, (0,)),
        window_case("all_skipped", [[zero] * 3], 2, (0, 1)),
        window_case("empty_epoch", [[]], 2),
        window_case("zero_epochs", [], 2),
        window_case("heterogeneous_microbatch_means",
                    [[(Q(1), Q(0), 1), (Q(3), Q(6), 9),
                      (Q(2), Q(-2), 2)]], 2),
    ]
    rng = random.Random(17)
    seed_selected = [rng.sample(list(range(1, 11)), 2) for _ in range(4)]
    assert seed_selected == [[9, 7], [5, 6], [5, 3], [9, 5]]
    return {
        "schema_version": 1, "purpose": "Independent numerical targets only",
        "production_cases_executed": False,
        "derivation": quadratic_endpoint.__doc__, "tolerances": TOLERANCES,
        "local_task": "F_i(w)=c_i*w^2/2-d_i*w (irrelevant constants omitted)",
        "contract": {"gradient": "c*w-d+alpha_i*(w-x+h)",
                     "history": "h_i_next=h_i+y_i-x; inactive unchanged",
                     "cloud": "unweighted selected mean(y)+sum(all updated h)/N",
                     "sample_q": "N*n_i/sum(all n)", "sample_alpha": "alpha/q_i",
                     "accumulation": "mean of microbatch means per epoch-local window"},
        "scalar_cases": scalars, "three_round": trajectories,
        "aggregation_inactive": {"x": Q(2), "counts": [1, 3, 2],
                                 "histories_before": [Q(2, 5), Q(-1, 5), Q(3, 5)],
                                 "endpoints": {1: Q(1), 3: Q(4)},
                                 "histories_after": h, "selected_mean": m,
                                 "population_history_mean": mean_h, "cloud": x},
        "full_participation": {
            mode: trajectory([1, 3], mode, [[1, 2]], [0, 4])
            for mode in ("uniform", "sample")
        },
        "never_selected_zero_history": trajectory(
            [1, 1, 1, 1], "uniform", [[1]], [0, 4, 0, 0]
        ),
        "quadratic_objective_optima": {"uniform": Q(2), "sample_1_3": Q(3)},
        "window_cases": windows,
        "seed17_four_round": {
            "counts": list(range(1, 11)), "targets": list(range(1, 11)),
            "selections": seed_selected, "checkpoint_boundary_after_round": 2,
            "note": "Targets for later actual run/resume tests; no checkpoint simulated",
            "trajectories": {
                mode: trajectory(list(range(1, 11)), mode, seed_selected,
                                 list(range(1, 11)))
                for mode in ("uniform", "sample")
            },
        },
    }


def near(actual, expected, dtype):
    tol = TOLERANCES[dtype]
    np.testing.assert_allclose(actual, expected, atol=tol["atol"],
                               rtol=tol["rtol"], equal_nan=False)


def torch_sgd(w, x, h, alpha, eta, c, d, steps, dtype):
    """Real autograd of explicit J, with plain fresh CPU SGD."""
    parameter = torch.nn.Parameter(torch.tensor(float(w), dtype=dtype, device="cpu"))
    anchor = torch.tensor(float(x), dtype=dtype)
    history = torch.tensor(float(h), dtype=dtype)
    coef = torch.tensor(float(alpha), dtype=dtype)
    optimizer = torch.optim.SGD([parameter], lr=float(eta))
    path = []
    for _ in range(steps):
        optimizer.zero_grad(set_to_none=True)
        task = float(c) * parameter.square() / 2 - float(d) * parameter
        loss = task + coef * history * parameter + coef * (parameter - anchor).square() / 2
        loss.backward()
        optimizer.step()
        path.append(parameter.detach().item())
    return parameter.detach().item(), path


def numerical_trajectory(rows, targets, backend, dtype):
    """Forward numerical run; does not reset to expected intermediate states."""
    scalar_type = np.float64 if dtype == "float64" else np.float32
    x = scalar_type(float(rows[0]["baseline"]))
    h = np.asarray([float(v) for v in rows[0]["histories_before"]], dtype=scalar_type)
    errors = []
    for row in rows:
        endpoints = {}
        for i in row["selected"]:
            alpha = row["alpha_i"][i - 1]
            d = targets[i - 1]
            if backend == "torch":
                y, _ = torch_sgd(x, x, h[i - 1], alpha, Q(1, 10),
                                 Q(1), Q(d), 2, getattr(torch, dtype))
                endpoints[i] = scalar_type(y)
            else:
                w = x
                for _ in range(2):
                    gradient = w - scalar_type(d) + scalar_type(float(alpha)) * (
                        w - x + h[i - 1]
                    )
                    w = w - scalar_type(0.1) * gradient
                endpoints[i] = w
            near(endpoints[i], float(row["endpoints"][i]), dtype)
            errors.append(abs(float(endpoints[i]) - float(row["endpoints"][i])))
        for i, endpoint in endpoints.items():
            h[i - 1] += endpoint - x
        x = np.mean(np.asarray(list(endpoints.values()), dtype=scalar_type)) + np.mean(h)
        near(h, [float(v) for v in row["histories_after"]], dtype)
        near(x, float(row["cloud"]), dtype)
        errors.append(abs(float(x) - float(row["cloud"])))
    return max(errors)


def validate_windows(case, dtype):
    dt = getattr(torch, dtype)
    w = torch.nn.Parameter(torch.tensor(float(case["x"]), dtype=dt))
    x = torch.tensor(float(case["x"]), dtype=dt)
    h = torch.tensor(float(case["h"]), dtype=dt)
    alpha = torch.tensor(float(case["alpha"]), dtype=dt)
    optimizer = torch.optim.SGD([w], lr=float(case["eta"]))
    completed = 0
    for row in case["windows"]:
        optimizer.zero_grad(set_to_none=True)
        # Differentiate each microbatch at the same w, average by ACTUAL length.
        for c, d, _cardinality in row["microbatches"]:
            task = float(c) * w.square() / 2 - float(d) * w
            regularizer = alpha * h * w + alpha * (w - x).square() / 2
            ((task + regularizer) / row["normalizer"]).backward()
        if not row["skipped"]:
            optimizer.step()
            completed += 1
        optimizer.zero_grad(set_to_none=True)
        near(w.detach().item(), float(row["weight_after"]), dtype)
        assert w.grad is None
    assert completed == case["completed_steps"]
    if completed:
        near(float(case["h"]) + w.detach().item() - float(case["x"]),
             float(case["history_after"]), dtype)
    return completed


def validate_labels():
    q, alphas = coefficients(Q(1, 10), [1, 3], "sample")
    gradients = []
    for labels in ([0, 0], [0, 1], [1, 1], [19, 2]):
        # The labels are varied only for coefficient/regularizer invariance.
        assert len(labels) == 2
        w = torch.tensor(1.0, dtype=torch.float64, requires_grad=True)
        regularizer = float(alphas[0]) * (0.5 * w + (w - 2).square() / 2)
        gradients.append(torch.autograd.grad(regularizer, w)[0].item())
    near(gradients, [-0.1] * 4, "float64")
    # A matching class permutation preserves classification loss and gradients.
    logits = torch.tensor([[0.3, -0.7, 1.2], [0.5, 0.1, -0.2]],
                          dtype=torch.float64, requires_grad=True)
    labels = torch.tensor([2, 0], dtype=torch.long)
    permutation = torch.tensor([2, 0, 1], dtype=torch.long)
    inverse = torch.argsort(permutation)
    original = torch.nn.functional.cross_entropy(logits, labels)
    permuted = torch.nn.functional.cross_entropy(logits[:, permutation], inverse[labels])
    near(original.item(), permuted.item(), "float64")
    near(torch.autograd.grad(original, logits)[0].numpy(),
         torch.autograd.grad(permuted, logits)[0].numpy(), "float64")
    return {"q": exact_json(q), "alpha_i": exact_json(alphas),
            "regularizer_gradients": gradients,
            "matching_class_permutation": "PASS",
            "count_provenance_limit": "Actual candidate loader/report binding untested"}


def source_audit(reference):
    paths = [ROOT / name for name in (
        "phase2c-feddyn-design.json", "phase2c-feddyn-design-review-2.json",
        "phase2c-feddyn-acceptance.json", "plan.md", "plan-addendum.json",
        "plan-addendum-acceptance.json")]
    paths += [ROOT.parent.parent / "AGENTS.md"]
    paths += [PRIMARY / name for name in (
        "2111.04263v1.pdf", "utils_general.py", "utils_methods.py", "README.md",
        "sources.json")]
    receipts = [{"path": str(p), "bytes": p.stat().st_size,
                 "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]
    by_name = {Path(r["path"]).name: r for r in receipts}
    assert by_name["phase2c-feddyn-design.json"]["sha256"] == DESIGN_SHA
    assert by_name["phase2c-feddyn-design-review-2.json"]["sha256"] == REVIEW_SHA
    acceptance = json.loads((ROOT / "phase2c-feddyn-acceptance.json").read_text())
    assert acceptance["design_sha256"] == DESIGN_SHA
    assert acceptance["review_sha256"] == REVIEW_SHA
    design = json.loads((ROOT / "phase2c-feddyn-design.json").read_text())
    checked = 0
    for mode in ("uniform", "sample"):
        for ours, accepted in zip(reference["three_round"][mode],
                                  design["oracle"]["trajectory"][mode], strict=True):
            i = accepted["client"]
            fields = {"baseline": ours["baseline"], "alpha": ours["alpha_i"][i - 1],
                      "history_before": ours["histories_before"][i - 1],
                      "local": ours["endpoints"][i], "delta": ours["deltas"][i],
                      "h1": ours["histories_after"][0], "h2": ours["histories_after"][1],
                      "history_mean": ours["population_history_mean"],
                      "global_next": ours["cloud"]}
            assert ours["round"] == accepted["round"]
            for name, value in fields.items():
                assert value == Q(accepted[name]["exact"]), (mode, name, value)
                near(float(value), accepted[name]["decimal"], "float64")
                checked += 1
    for src in json.loads((PRIMARY / "sources.json").read_text())["sources"]:
        assert by_name[Path(src["path"]).name]["sha256"] == src["sha256"]
    assert by_name["2111.04263v1.pdf"]["sha256"] == (
        "395f508d4f1adf94b8509897fe1fdb40a36090d2171ea74bd15c4b59c1e2e2ff"
    )
    return {"receipts": receipts, "accepted_exact_fields_checked": checked,
            "concrete_numerical_inconsistencies": []}


def validate(reference):
    checks = []
    assert reference["three_round"]["uniform"] == reference["three_round"]["equal_counts_sample"]
    assert reference["three_round"]["uniform"] == reference["three_round"]["changed_counts_uniform"]
    assert reference["aggregation_inactive"]["histories_after"] == [Q(-3, 5), Q(-1, 5), Q(13, 5)]
    assert reference["aggregation_inactive"]["cloud"] == Q(31, 10)
    assert reference["full_participation"]["uniform"][0]["cloud"] == Q(2)
    assert reference["full_participation"]["sample"][0]["cloud"] == Q(751, 375)
    assert reference["never_selected_zero_history"][0]["population_history_mean"] == Q(-189, 2000)
    assert reference["window_cases"][1]["endpoint"] == Q(39801, 20000)
    assert reference["window_cases"][1]["history_after"] == Q(9801, 20000)
    # Cross-check the closed form, including r=1, with direct exact differentiation.
    grid_cases = 0
    for alpha in (Q(0), Q(1, 10), Q(1, 15), Q(1, 5)):
        for c, d in ((Q(0), Q(0)), (Q(0), Q(1)), (Q(1), Q(4)), (Q(3), Q(-2))):
            for k in (0, 1, 2, 7):
                expected = quadratic_endpoint(Q(2), Q(3), Q(1, 2), alpha, Q(1, 10), c, d, k)
                w = Q(2)
                for _ in range(k):
                    w -= Q(1, 10) * (c * w - d + alpha * (w - 3 + Q(1, 2)))
                assert w == expected
                actual, _ = torch_sgd(Q(2), Q(3), Q(1, 2), alpha, Q(1, 10), c, d, k, torch.float64)
                near(actual, float(expected), "float64")
                grid_cases += 1
    checks.append({"case": "closed_form_grid", "fraction_and_torch_float64_cases": grid_cases})
    for dtype in ("float64", "float32"):
        for backend in ("numpy", "torch"):
            for name, rows in reference["three_round"].items():
                error = numerical_trajectory(rows, [0, 4], backend, dtype)
                checks.append({"case": "three_round/" + name, "backend": backend,
                               "dtype": dtype, "max_endpoint_cloud_abs_error": error})
            for mode, rows in reference["seed17_four_round"]["trajectories"].items():
                error = numerical_trajectory(rows, list(range(1, 11)), backend, dtype)
                checks.append({"case": "seed17_four_round/" + mode, "backend": backend,
                               "dtype": dtype, "max_endpoint_cloud_abs_error": error})
        for row in reference["scalar_cases"]:
            w = torch.tensor(float(row["w"]), dtype=getattr(torch, dtype), requires_grad=True)
            loss = (float(row["c"]) * w.square() / 2 - float(row["d"]) * w
                    + float(row["alpha"]) * float(row["h"]) * w
                    + float(row["alpha"]) * (w - float(row["x"])).square() / 2)
            gradient = torch.autograd.grad(loss, w)[0].item()
            near(gradient, float(row["gradient"]), dtype)
            y, _ = torch_sgd(row["w"], row["x"], row["h"], row["alpha"], row["eta"],
                             row["c"], row["d"], 1, getattr(torch, dtype))
            near(y, float(row["endpoint"]), dtype)
            checks.append({"case": "scalar/" + row["name"], "dtype": dtype, "gradient": gradient})
        for case in reference["window_cases"]:
            steps = validate_windows(case, dtype)
            checks.append({"case": "windows/" + case["name"], "dtype": dtype,
                           "real_optimizer_steps": steps})
    return checks


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--results", type=Path, required=True)
    args = parser.parse_args()
    torch.set_num_threads(1)
    reference = make_reference()
    audit = source_audit(reference)
    checks = validate(reference)
    labels = validate_labels()
    assert_no_plato()
    encoded = json.dumps(exact_json(reference), indent=2, sort_keys=True) + "\n"
    args.reference.write_text(encoded)
    results = {
        "status": "PASS_REFERENCE_ONLY", "python": sys.version,
        "platform": platform.platform(), "numpy": np.__version__, "torch": torch.__version__,
        "numpy_path": np.__file__, "torch_path": torch.__file__, "no_plato_import_asserted": True,
        "plato_import_guard_installed": True, "source_audit": audit,
        "checks": checks, "check_groups": len(checks), "labels": labels,
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "reference_sha256": hashlib.sha256(encoded.encode()).hexdigest(),
        "limits": ["No production candidate read or tested", "No serialization/spawn/socket/CLI tests",
                   "No momentum/AMP/clipping/scheduler/GPU extension or convergence theorem",
                   "Standalone CPU numerical targets; all FD production acceptance remains pending"],
    }
    args.results.write_text(json.dumps(results, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: results[k] for k in (
        "status", "check_groups", "no_plato_import_asserted", "reference_sha256"
    )}))


if __name__ == "__main__":
    main()
