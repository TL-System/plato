"""Hash/ancestry/receipt audit of the frozen checkout, without author-source reads."""
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import xml.etree.ElementTree as ET

C = Path('/tmp/plato-refresh-worktrees/training-final-review')
H = Path('/tmp/plato-phase2c-feddyn-code-review')
RAW = Path('/tmp/plato-phase2c-feddyn-implementation')


def git(*args):
    return subprocess.check_output(['zsh', '-lc', shlex.join(['git', *args])],
                                   cwd=C, text=True).strip()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert git('rev-parse', 'HEAD') == '13e38dafce476286db7e673e7f21343d54416b56'
    assert git('rev-parse', 'HEAD^{tree}') == '9fe8cfb039d0d97fc5b2c95a459de4c73c6d1b51'
    assert not git('status', '--short')
    v = json.loads((C / 'evidence/2026-refresh/phase2c-feddyn-validation.json').read_text())
    receipt = json.loads((C / 'evidence/2026-refresh/phase2c-feddyn-delivery-receipt.json').read_text())
    sources = []
    for relative, expected in v['sources'].items():
        p = C / relative
        actual = {'path': relative, 'sha256': sha(p), 'blob': git('rev-parse', 'HEAD:' + relative)}
        assert actual['sha256'] == expected['sha256'], actual
        assert actual['blob'] == expected['blob'], actual
        sources.append(actual)
    evidence = []
    for relative, expected in receipt['evidence_files'].items():
        p = C / 'evidence/2026-refresh' / relative
        assert p.stat().st_size == expected['bytes'] and sha(p) == expected['sha256']
        evidence.append({'path': str(p), 'sha256': sha(p)})
    raw = []
    for relative, expected in v['raw_inventory'].items():
        p = RAW / relative
        assert p.is_file(), p
        assert p.stat().st_size == expected['bytes'] and sha(p) == expected['sha256'], p
        raw.append({'path': str(p), **expected})
    changes_since_runtime = git('diff', '--name-only', '05a9f00b8a4d54c233c1a9c00ef9ce2c4467480c', 'HEAD').splitlines()
    assert all(p.startswith('evidence/') or p == 'tests/trainers/test_personalized_state_ownership.py'
               for p in changes_since_runtime)
    assert all(p.startswith('evidence/') for p in git('diff', '--name-only',
               '7d310b90d698a7be4aa9a184dc415f7dbb401e5b', 'HEAD').splitlines())
    assert not git('diff', '1fe8b63940c21eca23b91e9f79281171e80f0cbc', 'HEAD', '--',
                   'plato/servers/base.py', 'plato/servers/strategies/client_selection')
    for commit in ('79da1f97d8a12fe97402750cc32c7b3e8f5cdf6e',
                   '00eeb9dcdd2b513e64db9408969356037e09bb8e',
                   'a058a2ef8d230ca2e34dbf1c91e6eaac0b0205ac',
                   '96323afa094a37584844275cc04bf1e1eedfaa0d'):
        git('merge-base', '--is-ancestor', commit, 'HEAD')
    fixture = C / 'tests/fixtures/feddyn_accepted_b.py'
    provenance = json.loads((fixture.with_suffix('.provenance.json')).read_text())
    historical = subprocess.check_output(['zsh', '-lc', shlex.join(['git', 'show',
        provenance['source_commit'] + ':' + provenance['source_path']])], cwd=C)
    assert fixture.read_bytes() == historical
    assert sha(fixture) == provenance['source_sha256']
    suites = []
    for name in ('final-base-not-runtime-313', 'final-base-not-runtime-314',
                 'final-mandatory-not-runtime-313', 'final-mandatory-not-runtime-314',
                 'combined-mandatory-runtime-313', 'combined-mandatory-runtime-314'):
        root = ET.parse(RAW / (name + '.xml')).getroot()
        cases = list(root.iter('testcase'))
        suites.append({'name': name, 'unique_cases': len(set((c.get('classname'),c.get('name')) for c in cases)),
                       'cases': len(cases), 'failed': sum(c.find('failure') is not None or c.find('error') is not None for c in cases),
                       'skipped': sum(c.find('skipped') is not None for c in cases)})
    result = {'status': 'PASS', 'candidate_commit': git('rev-parse', 'HEAD'),
              'candidate_tree': git('rev-parse', 'HEAD^{tree}'), 'sources': sources,
              'source_receipts_verified': len(sources), 'raw_receipts': raw,
              'raw_receipts_verified': len(raw), 'evidence_receipts': evidence,
              'historical_fixture_sha256': sha(fixture),
              'changes_since_runtime': changes_since_runtime,
              'no_B_startup_selection_diff': True, 'accepted_dependencies_are_ancestors': True,
              'nanochat_pin': git('-C', 'external/nanochat', 'rev-parse', 'HEAD'),
              'setup_transition': 'Nanochat initially uninitialized; root initialized unchanged pinned gitlink before final qualification',
              'author_suite_receipts': suites,
              'author_profile_limit': 'Opacus installed in both author profiles; no fresh minimal-base provisioning claimed',
              'lock_sha256': sha(C/'uv.lock'), 'pyproject_sha256': sha(C/'pyproject.toml')}
    (H/'final-input-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('status','source_receipts_verified','raw_receipts_verified','nanochat_pin')}))


if __name__ == '__main__':
    main()
