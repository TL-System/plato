"""Focused pytest provenance: retain the source guard in child environments."""
import os
from pathlib import Path
import subprocess
import sys

CANDIDATE = Path('/tmp/plato-refresh-worktrees/training-final-review').resolve()
GUARD = '/tmp/plato-phase2c-feddyn-code-review/source_guard'
ORIGINAL = subprocess.Popen.__init__


def launch(self, *args, **kwargs):
    env = dict(kwargs.get('env') or os.environ)
    paths = env.get('PYTHONPATH', '').split(os.pathsep)
    assert str(CANDIDATE) in [str(Path(p).resolve()) for p in paths if p]
    if GUARD not in paths:
        paths.append(GUARD)
    env['PYTHONPATH'] = os.pathsep.join(paths)
    kwargs['env'] = env
    return ORIGINAL(self, *args, **kwargs)


def verify():
    for name, module in tuple(sys.modules.items()):
        if name == 'plato' or name.startswith('plato.') or name in (
            'feddyn', 'feddyn_client', 'feddyn_server', 'feddyn_trainer'
        ):
            origin = getattr(module, '__file__', None)
            if origin:
                assert Path(origin).resolve().is_relative_to(CANDIDATE), (name, origin)


def pytest_sessionstart(session):
    verify()
    subprocess.Popen.__init__ = launch


def pytest_sessionfinish(session, exitstatus):
    verify()
    subprocess.Popen.__init__ = ORIGINAL
