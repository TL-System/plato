"""Assemble the assigned independent review from retained executions."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import xml.etree.ElementTree as ET

import psutil

H = Path('/tmp/plato-phase2c-feddyn-code-review')
C = Path('/tmp/plato-refresh-worktrees/training-final-review')
REPORT = Path('/Users/bli/Playground/plato/evidence/2026-refresh/phase2c-feddyn-code-review.json')
COMMIT = '13e38dafce476286db7e673e7f21343d54416b56'
TREE = '9fe8cfb039d0d97fc5b2c95a459de4c73c6d1b51'


def receipt(path):
    path = Path(path)
    return {'path':str(path),'bytes':path.stat().st_size,
            'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    assert subprocess.check_output(['zsh','-lc','git rev-parse HEAD'],cwd=C,text=True).strip()==COMMIT
    assert subprocess.check_output(['zsh','-lc','git rev-parse HEAD^{tree}'],cwd=C,text=True).strip()==TREE
    assert not subprocess.check_output(['zsh','-lc','git status --short'],cwd=C,text=True).strip()
    audit=json.loads((H/'final-input-audit.json').read_text())
    captures=json.loads((H/'final-runtime-capture-validation.json').read_text())
    assert audit['status']==captures['status']=='PASS'
    nodes=[]; executions=[]
    focused=[
        'tests/trainers/test_feddyn_strategy.py','tests/integration/test_feddyn_round_flow.py',
        'tests/integration/test_feddyn_entrypoint.py',
        'tests/trainers/test_review_training_boundaries.py::test_actual_accepted_b_feddyn_writer_migration',
        'tests/trainers/test_personalized_state_ownership.py::test_feddyn_exact_legacy_prefix_load_is_same_client_and_canonical_wins',
        'tests/trainers/test_personalized_state_ownership.py::test_actual_spawn_returns_personal_state_and_optimizer_across_rounds[feddyn]']
    compatible=['tests/integration/test_checkpoint_runtime_agreement.py',
        *['tests/trainers/test_training_update_contract.py::'+n for n in (
        'test_fedprox_origin_and_nonzero_analytical_gradient','test_fedprox_rejects_invalid_penalty',
        'test_fedprox_refreshes_received_weights_each_run','test_real_fedprox_reference_config_activates_proximal_training')]]
    env_base='PYTHONPATH=/tmp/plato-refresh-worktrees/training-final-review:/tmp/plato-phase2c-feddyn-code-review:/tmp/plato-phase2c-feddyn-code-review/source_guard PYTHONDONTWRITEBYTECODE=1'
    for tag in (313,314):
        short='13' if tag==313 else '14'
        for kind, cases in [('focused',focused),('compatibility',compatible)]:
            xml=H/f'final-{kind}-{tag}.xml'
            junit=list(ET.parse(xml).getroot().iter('testcase'))
            assert all(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in junit)
            if tag==313:
                nodes.extend({'file':c.get('classname').replace('.','/')+'.py',
                              'name':c.get('name'),'function':c.get('name').split('[',1)[0],
                              'command_id':f'{kind}-{tag}'} for c in junit)
            command=(env_base+f' TMPDIR=/tmp/fdc{short} '+
                (f'XDG_CACHE_HOME={H}/cache-{tag} ' if kind=='focused' else '')+
                'OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 '+
                f'/tmp/plato-phase2c-{tag}/bin/python -B -m pytest '+shlex.join(cases)+
                (' --test-profile mandatory' if kind=='compatibility' else '')+
                f' -p origin_checks -p no:cacheprovider -q --basetemp /tmp/fdc{short}/{kind} --junitxml {xml} > {H}/final-{kind}-{tag}.log 2>&1')
            executions.append({'id':f'{kind}-{tag}','command':'zsh -lc '+shlex.quote(command),
                'cwd':str(C),'exit_code':0,'passed':len(junit),'skipped':0,'failed':0,
                'log':receipt(H/f'final-{kind}-{tag}.log'),'junit':receipt(xml),
                'scope':'Scoped tests only; not a complete base/mandatory suite qualification'})
        for name, script, directory, log in [
            ('independent','reviewer_candidate_probes.py','independent-v2',f'final-independent-v2-{tag}.log'),
            ('callback-count','reviewer_callback_count_probe.py','callback-count',f'final-callback-count-{tag}.log'),
            ('rng-cache','reviewer_rng_cache_probe.py','rng-cache-v2',f'final-rng-cache-v2-{tag}.log')]:
            root=Path(f'/tmp/fdc{short}')/directory
            command=(env_base+f' TMPDIR=/tmp/fdc{short} OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 '+
                     ('OPENBLAS_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 ' if name=='independent' else '')+
                     f'/tmp/plato-phase2c-{tag}/bin/python -B {H}/{script} {root} > {H}/{log} 2>&1')
            executions.append({'id':f'{name}-{tag}','command':'zsh -lc '+shlex.quote(command),
                'cwd':str(C),'exit_code':0,'script':receipt(H/script),
                'log':receipt(H/log),'result':receipt(root/'results.json'),
                'meaning':'Executable completed; exposed defects are explicit result statuses, not passing acceptance'})
        reference=json.loads((H/f'final-reference-results-{tag}.json').read_text())
        assert reference['no_plato_import_asserted'] and reference['reference_sha256']==receipt(H/'reference.json')['sha256']
        executions.append({'id':f'pure-reference-{tag}','command':f'zsh -lc \'TMPDIR=/tmp/fdc{short} OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /tmp/plato-phase2c-{tag}/bin/python -I -B {H}/feddyn_reference.py --reference {H}/final-reference-{tag}.json --results {H}/final-reference-results-{tag}.json > {H}/final-reference-{tag}.log 2>&1\'',
            'exit_code':0,'result':receipt(H/f'final-reference-results-{tag}.json'),
            'log':receipt(H/f'final-reference-{tag}.log'),'check_groups':51,'closed_form_grid_cases':64,
            'accepted_exact_trajectory_fields':54})
    assert len(nodes)==len(set((n['file'],n['name']) for n in nodes))==242
    for ident, script, result, log, prefix in [
        ('input-audit','audit_final_inputs.py','final-input-audit.json','final-input-audit.log',''),
        ('runtime-capture-validation','validate_runtime_captures.py','final-runtime-capture-validation.json','final-runtime-capture-validation.log','OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 '),
    ]:
        command=prefix+f'/tmp/plato-phase2c-313/bin/python -I -B {script} > {log} 2>&1'
        executions.append({'id':ident,'command':'zsh -lc '+shlex.quote(command),'cwd':str(H),
            'exit_code':0,'script':receipt(H/script),'result':receipt(H/result),'log':receipt(H/log),
            'scope':'Read-only source/raw evidence audit or strict post-capture comparison; no additional production case executions'})
    executions.append({'id':'scoped-import-and-type-checks','cwd':str(C),
        'commands':["zsh -lc '/tmp/plato-phase2c-313/bin/ruff check --no-cache --select I examples/customized_client_training/feddyn plato/trainers/strategies/algorithms/feddyn_strategy.py'",
            *[f"zsh -lc '/tmp/plato-phase2c-313/bin/ty check --python /tmp/plato-phase2c-{tag}/bin/python examples/customized_client_training/feddyn plato/trainers/strategies/algorithms/feddyn_strategy.py'" for tag in (313,314)]],
        'exit_codes':[0,1,1],
        'logs':[receipt(H/'final-ruff.log'),receipt(H/'final-ty-env-313.log'),receipt(H/'final-ty-env-314.log')]})
    findings=[
        {'id':'FD-C-R01','severity':'medium','title':'First uniform dispatch accepts a corrupted positive worker sample count',
         'location':{'path':'plato/trainers/strategies/algorithms/feddyn_strategy.py','line':627,'end_line':637},
         'related_location':{'path':'examples/customized_client_training/feddyn/feddyn_client.py','line':63,'end_line':67},
         'criteria_failed':['FD-A05','FD-A10'],
         'reproduction':'reviewer_candidate_probes.py::count_probe: real max_concurrency child trains a 2-item sampler, saves the valid endpoint/history/token bundle, then changes only worker-state num_samples from 2 to 3. On its first uniform dispatch expected_count_or_null is None.',
         'observed':'Both Python versions accept the parent result, emit report/payload count 3, and server commits round1 with observed_counts={1:3}; actual sampler cardinality is 2. Cloud remains correctly 1.433, so this is count provenance/acceptance failure, not an incorrect gradient claim. The identical corruption is rejected in sample mode.',
         'cause':'Worker count is compared only with a previously known/configured dispatch count. No independent current-attempt realized count binds first uniform parent handoff; report count is then overwritten with the sidecar value.',
         'required_behavior':'Bind and validate the current realized partition count in the parent before accepting the sidecar/outbound result. Wrong worker count must roll back and send no update, including when the server had no previous count.',
         'evidence':['independent-313','independent-314'],'probe_result_case':'spawn_positive_count_corruption/uniform'},
        {'id':'FD-C-R02','severity':'medium','title':'Resume accepts loss of the count cache for a client with nonzero history',
         'location':{'path':'examples/customized_client_training/feddyn/feddyn_server.py','line':617,'end_line':639},
         'criteria_failed':['FD-A12','FD-A05'],
         'reproduction':'reviewer_candidate_probes.py::bundle_count_probe: commit clients1 and2 with counts2 each, save the real round2 bundle, remove only counts[1] while retaining nonzero history1 and all model/config/RNG/token fields, and load fresh objects. Dispatch client1 with a now-3-item partition.',
         'observed':'Both versions accept the incomplete bundle, dispatch client1 with expected_count_or_null=None, accept its changed count3 and commit round3. Persisted h1 is approximately -0.378, proving it was previously trained and needed its realized count binding.',
         'cause':'Validation checks present count entries and only requires a nonempty map at positive rounds. It does not reject a missing count for a client whose saved history proves prior participation.',
         'required_behavior':'Reject this inconsistent bundle before changing live/pending state. Preserve fixed-data count provenance through continuation; at minimum a nonzero stored history must have a validated observed count.',
         'evidence':['independent-313','independent-314'],'probe_result_case':'bundle_missing_observed_count'},
        {'id':'FD-C-R03','severity':'medium','title':'Receive callback can commit an invalid boolean inactive count',
         'location':{'path':'examples/customized_client_training/feddyn/feddyn_server.py','line':359},
         'related_location':{'path':'examples/customized_client_training/feddyn/feddyn_server.py','line':439,'end_line':447},
         'criteria_failed':['FD-A11'],
         'reproduction':'reviewer_callback_count_probe.py: commit client2 at count1. During the next valid client1 round, on_weights_received changes only inactive observed_counts[2] from int1 to boolTrue.',
         'observed':'Both versions commit round2 with observed_counts[2] of type bool. Subsequent save_to_checkpoint raises "FedDyn checkpoint sample count must be a positive integer." Previous canonical bytes remain at round1; live model/history/round have advanced.',
         'cause':'Python dictionary equality treats 1 and True as equal, bypassing the precommit authority guard. Staging preserves the invalid inactive entry; count validity is checked only during later bundle validation.',
         'required_behavior':'Use type-sensitive comparison/validation for FedDyn-owned count state before arithmetic/commit. Reject and roll back this owned-state mutation; no arbitrary external callback side-effect transaction is requested.',
         'evidence':['callback-count-313','callback-count-314']}
    ]
    low=[{'id':'FD-C-L01','severity':'low','title':'Explicit owned-source type check reports five diagnostics',
          'criteria':['FD-A14'],'locations':[
              {'path':'examples/customized_client_training/feddyn/feddyn_trainer.py','line':71,'reason':'loader.sampler annotated Iterable is passed to len without Sized narrowing'},
              *[{'path':'plato/trainers/strategies/algorithms/feddyn_strategy.py','line':line,'reason':'Optional context.model passed to Module-only helper without narrowing'} for line in (429,499,570,682)]],
          'command':f'zsh -lc \'/tmp/plato-phase2c-313/bin/ty check --python /tmp/plato-phase2c-313/bin/python examples/customized_client_training/feddyn plato/trainers/strategies/algorithms/feddyn_strategy.py\'',
          'result':'Exit1, five invalid-argument-type diagnostics under explicit 3.13 and3.14 environments. Runtime validation is present; no runtime failure asserted from these annotations.',
          'remediation':'Narrow the Sized sampler and use the existing context_model validation helper or equivalent explicit Module narrowing.',
          'logs':[receipt(H/'final-ty-env-313.log'),receipt(H/'final-ty-env-314.log')]}]
    authored=json.loads((C/'evidence/2026-refresh/phase2c-feddyn-validation.json').read_text())['acceptance_criteria']
    statuses={'FD-A05':'FAIL','FD-A10':'PARTIAL_FAIL','FD-A11':'PARTIAL_FAIL','FD-A12':'PARTIAL_FAIL','FD-A14':'PARTIAL_TYPING_AND_SEPARATE_PROSE_GATE_PENDING'}
    mapping=[]
    for i in range(1,16):
        key=f'FD-A{i:02d}'
        functions=authored[key]['tests']
        covered=[n for n in nodes if n['function'] in functions]
        counts=Counter((n['file'],n['function']) for n in covered)
        mapping.append({'id':key,'status':statuses.get(key,'PASS_IN_REVIEWED_CPU_SCOPE'),
            'actual_test_functions':[{'file':f,'function':fn,'parameter_cases_each_version':count} for (f,fn),count in counts.items()],
            'matched_unique_pytest_cases_each_version':len(covered),
            'execution_ids':['focused-313','focused-314'] if covered else ['input-audit','scoped-import-and-type-checks'],
            'related_findings':[f['id'] for f in findings if key in f['criteria_failed']]+[f['id'] for f in low if key in f['criteria']],
            'overlap_policy':'Cases shared by multiple FD criteria are counted once in the242 unique executions per version; FD-A12/13 share two actual-entrypoint resume cases.',
            'independent_evidence':{
                1:['pure-reference-313','pure-reference-314'],
                2:['independent-313','independent-314'],3:['independent-313','independent-314'],
                4:['pure-reference-313','pure-reference-314'],
                5:['independent-313','independent-314'],6:['pure-reference-313','pure-reference-314'],
                7:['focused-313','focused-314'],8:['independent-313','independent-314','pure-reference-313','pure-reference-314'],
                9:['independent-313','independent-314'],10:['independent-313','independent-314'],
                11:['callback-count-313','callback-count-314'],
                12:['independent-313','independent-314','runtime-capture-validation','rng-cache-313','rng-cache-314'],
                13:['runtime-capture-validation'],14:['input-audit','pure-reference-313','pure-reference-314'],
                15:['input-audit','focused-313','focused-314']}[i]})
    origins=[]; starts=[]; origin_receipts=[]
    for p in sorted((H/'final-origin-logs').glob('*.jsonl')):
        origin_receipts.append(receipt(p))
        for line in p.read_text().splitlines():
            d=json.loads(line)
            (origins if d['event']=='import' else starts).append(d)
    assert all(Path(d['origin']).is_relative_to(C.resolve()) for d in origins)
    manifest={'status':'PASS','python_start_records':len(starts),'import_records':len(origins),
              'unique_origin_modules':len(set((d['module'],d['origin']) for d in origins)),
              'cwd_values':sorted(set(d['cwd'] for d in starts)),
              'all_recorded_production_and_integration_origins_under_immutable_source':True,
              'receipts':origin_receipts,'guard_files':[receipt(H/'origin_checks.py'),receipt(H/'source_guard/sitecustomize.py')]}
    (H/'final-origin-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    survivors=[]; checked=0
    for entry in captures['receipts']:
        p=Path(entry['path'])
        if p.name!='result.json': continue
        result=json.loads(p.read_text())
        if not isinstance(result,dict) or 'processes' not in result: continue
        for pid,created in result['processes'].items():
            checked+=1
            try:
                process=psutil.Process(int(pid))
                if process.create_time()==created and process.status()!=psutil.STATUS_ZOMBIE:
                    survivors.append(int(pid))
            except psutil.NoSuchProcess: pass
    assert not survivors
    scripts=['feddyn_reference.py','reviewer_candidate_probes.py','reviewer_callback_count_probe.py',
             'reviewer_rng_cache_probe.py','validate_runtime_captures.py','audit_final_inputs.py','build_final_report.py',
             'origin_checks.py','source_guard/sitecustomize.py','verify_final_report.py']
    report={'schema_version':1,'written_at_utc':datetime.now(timezone.utc).isoformat(),
        'role':'Fresh independent FedDyn implementation reviewer; no nested agents or author consultation',
        'verdict':'REQUEST_CHANGES','finding_counts':{'critical':0,'high':0,'medium':3,'low':1},
        'findings':findings,'low_findings':low,
        'reviewed_candidate':{'path':str(C),'commit':COMMIT,'tree':TREE,'base_commit':'1fe8b63940c21eca23b91e9f79281171e80f0cbc','tracked_source_clean_at_end':True},
        'accepted_contract':{'design_sha256':'62c5d61805c49ccc06f99776d0da820c5b27cffeb5916754ddb16bb3135c1d5b',
            'design_review_sha256':'454aa4b5d6503e2d3fbdc572719620983bab13cd7fbd5e59df8a3dc254e0f0e1',
            'root_acceptance':'/Users/bli/Playground/plato/evidence/2026-refresh/phase2c-feddyn-acceptance.json',
            'design_reopened':False,'concrete_numerical_reference_inconsistencies':[]},
        'summary':'Correct accepted objective/history/population algebra and valid-path CPU integration are independently confirmed. Three count-state acceptance/coherence defects remain, so all FD-A01..15 are not accepted.',
        'criterion_mapping':mapping,'executions':executions,
        'unique_counts':{'pytest_cases_each_python':242,'FD_focused_each':222,'B_F20_compatibility_each':20,
            'pytest_total_two_versions':484,'unique_nodes_each':242,'failures_or_skips_in_pytest':0,
            'independent_candidate_scenarios_each':12,'independent_expected_pass_each':9,'independent_exposed_defects_each':3,
            'pure_reference_check_groups_each':51,'closed_form_grid_cases_each':64,
            'actual_shipped_runtime_pytest_cases_each':3,'actual_shipped_process_runs_each':7,
            'strict_capture_comparison_groups_two_versions':18,'strict_float64_capture_fields':416,
            'no_double_counting':'Pure reference, independent scenario, and post-capture comparison groups are not extra pytest cases. Two resume tests overlap FD-A12/13. Author carried-forward full suites are not reviewer executions.'},
        'environments':audit['author_suite_receipts'] and json.loads((C/'evidence/2026-refresh/phase2c-feddyn-validation.json').read_text())['environments'],
        'independently_observed_environment_metadata':[receipt(H/f'final-observed-environment-{tag}.json') for tag in (313,314)],
        'environment_limits':'Existing3.13.16/3.14.8 macOS ARM64 CPU environments used read-only. No installation, SSL variant, fresh minimal base profile, Linux, GPU or whole optional-stack qualification.',
        'source_and_raw_receipt_audit':receipt(H/'final-input-audit.json'),
        'source_checks_summary':{'declared_source_receipts_verified':audit['source_receipts_verified'],
            'author_raw_receipts_verified':audit['raw_receipts_verified'],'accepted_dependencies_are_ancestors':True,
            'no_B_startup_selection_semantic_diff_from_1fe':True,'runtime_carry_forward_source_differences':audit['changes_since_runtime'],
            'historical_writer_fixture_verified_against_git_blob':audit['historical_fixture_sha256'],
            'nanochat_checkout_setup_transition':audit['setup_transition'],'nanochat_pin':audit['nanochat_pin']},
        'dependency_review_context':{'scope':'Root-provided SCAFFOLD acceptance context; not re-reviewed here and does not close the independent FedDyn findings.',
            'F27-R3-01':'Closed by fresh SCAFFOLD review4 on this exact candidate; one optional LOW duplicate rejection cleanup remains accepted by root.',
            'review':receipt('/Users/bli/Playground/plato/evidence/2026-refresh/phase2c-scaffold-code-review-4.json'),
            'acceptance':receipt('/Users/bli/Playground/plato/evidence/2026-refresh/phase2c-scaffold-implementation-acceptance.json')},
        'import_provenance':{'manifest':receipt(H/'final-origin-manifest.json'),'parent_cwd':str(C),
            'spawn_worker_cwd':'Inherited immutable checkout; real socket entrypoints intentionally use their own /tmp/fdc13|14 runtime directories with immutable PYTHONPATH.',
            'mechanism':'Reviewer-owned sitecustomize PathFinder guard plus parent module-origin assertions; pytest Popen wrapper appends provenance guard only, preserving supplied immutable PYTHONPATH and normal cwd.',
            'no_metadata_repair':'Native scalar types asserted after actual production deserialize/transport; no .item/coercion repairing metadata.'},
        'runtime_capture_validation':receipt(H/'final-runtime-capture-validation.json'),
        'runtime_shutdown':{'actual_rounds_and_oracle_checked':True,'inherited_exit0_not_sole_success_evidence':True,
            'process_identity_observations_rechecked':checked,'surviving_observed_owned_processes':survivors,
            'deadline_or_watchdog_kills_in_success_cases':False},
        'checks':{'ruff':{'exit_code':0,'command':f'zsh -lc \'/tmp/plato-phase2c-313/bin/ruff check --no-cache --select I examples/customized_client_training/feddyn plato/trainers/strategies/algorithms/feddyn_strategy.py\'','log':receipt(H/'final-ruff.log')},
            'ty':{'exit_code_each':1,'diagnostics_each':5,'logs':[receipt(H/'final-ty-env-313.log'),receipt(H/'final-ty-env-314.log')]}},
        'scripts':[receipt(H/p) for p in scripts],
        'reference_artifacts':[receipt(H/p) for p in ('reference.json','preparation-receipt.json','final-reference-313.json','final-reference-314.json')],
        'retained_setup_failures':[
            {'files':[receipt(H/'final-independent-313.log'),receipt(H/'final-independent-314.log')],
             'cause':'Reviewer forgot to create individual runtime roots before configure_environment; fixed in owned probe only. No candidate execution verdict inferred.'},
            {'files':[receipt(H/'final-rng-cache-313.log'),receipt(H/'final-rng-cache-314.log')],
             'cause':'Reviewer imported server base before installing test config, invoking CLI parsing of its scratch argument. Moved import inside configured environment; candidate unchanged.'}],
        'limits':['No complete C/Phase2 approval, documentation review, new design, protocol/security questionnaire or feature request.',
            'Final source-bound Astra prose and independent prose review remain root-owned separate gates; FD-A14 records that pending work.',
            'Synthetic deterministic CPU numerical and actual local sockets/spawn; no MNIST accuracy, new convergence theorem, active author-clipping, momentum, AMP, scheduler or GPU replay equivalence.',
            'Complete committed-round continuation tested; no in-flight, arbitrary external datasource RNG or external callback side-effect rollback claim.',
            'Generic B selection-owned persistence is preserved and not described as global Python replay; FedDyn separately promises and tests complete CPU RNG restoration.',
            'SCAFFOLD/general cleanup not re-reviewed; only direct FD successful-cleanup failure/rollback/retry and its relevant shared source were checked.',
            'Author full base/mandatory receipts audited, not independently rerun or counted as fresh minimal base provisioning. No profile guards changed.',
            'Source/test/docs/env dependencies untouched; only owned scratch and this assigned ROOT report written. No manual cleanup, commits, pushes or nested agents.'],
        'root_next_action':'Original implementer repairs FD-C-R01..03 within accepted contract, reconciles FD-C-L01, then fresh independent verification of an exact frozen revision. This report does not close2C-11.'}
    if REPORT.exists():
        (H/'prior-assigned-report.json').write_bytes(REPORT.read_bytes())
    REPORT.write_text(json.dumps(report,indent=2)+'\n')
    (H/'final-report-receipt.json').write_text(json.dumps({'report':receipt(REPORT),'candidate_commit':COMMIT,'candidate_tree':TREE},indent=2)+'\n')
    print(json.dumps({'verdict':report['verdict'],'finding_counts':report['finding_counts'],'report':receipt(REPORT)},indent=2))


if __name__=='__main__':
    main()
