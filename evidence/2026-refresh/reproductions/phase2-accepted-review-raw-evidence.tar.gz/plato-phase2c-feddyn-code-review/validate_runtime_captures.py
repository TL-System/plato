"""Strict independent oracle comparisons of real shipped socket/resume captures."""
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import random
import tomllib

import numpy as np
import torch

H = Path('/tmp/plato-phase2c-feddyn-code-review')
REF = json.loads((H/'reference.json').read_text())


def same(a, b):
    if type(a) is not type(b):
        return False
    if isinstance(a, torch.Tensor):
        return a.dtype == b.dtype and a.shape == b.shape and torch.equal(a, b)
    if isinstance(a, dict):
        return set(a) == set(b) and all(same(a[k], b[k]) for k in a)
    if isinstance(a, (tuple, list)):
        return len(a) == len(b) and all(same(x, y) for x, y in zip(a, b))
    return a == b


def close(tensor, exact):
    assert tensor.dtype == torch.float64 and tensor.shape == (1,)
    np.testing.assert_allclose(tensor.numpy(), float(Fraction(exact)), atol=1e-12,
                               rtol=0, equal_nan=False)


def metadata_native(meta):
    for key in ('version', 'round', 'client_id', 'num_samples', 'completed_steps'):
        assert type(meta[key]) is int, (key, type(meta[key]))
    for key in ('run_id', 'dispatch_token'):
        assert type(meta[key]) is str, (key, type(meta[key]))


def load(path):
    return torch.load(path, weights_only=True, map_location='cpu')


def main():
    checks, receipts = [], []
    numerical_fields = 0
    for tag in (313,314):
        short = '13' if tag == 313 else '14'
        root = Path('/tmp/fdc'+short)/'focused'
        for case in sorted(root.glob('test_actual_shipped_run_resume[01]')):
            config = tomllib.loads((case/'control/run/config.toml').read_text())
            mode = config['algorithm']['feddyn_weighting']
            rows = REF['seed17_four_round']['trajectories'][mode]
            seen = set()
            for relative, round_ids in [('control/run',range(1,5)),
                                        ('split/first',range(1,3)),
                                        ('split/resumed',range(3,5))]:
                directory = case/relative
                result = json.loads((directory/'result.json').read_text())
                assert result['returncode'] == 0 and not result['timed_out']
                assert not result['forced'] and not result['survivors']
                events = [e for e in result['events'] if e['event'] == 'committed']
                assert [e['round'] for e in events] == list(round_ids)
                assert any(e['event']=='server_will_close' for e in result['events'])
                assert any(e['event']=='child_returned' for e in result['events'])
                for r in round_ids:
                    expected = rows[r-1]
                    received, committed = load(directory/f'received-{r}.pth'), load(directory/f'committed-{r}.pth')
                    assert received['selected'] == expected['selected']
                    seen = {i for row in rows[:r] for i in row['selected']}
                    assert committed['counts'] == {i:i for i in seen}
                    close(committed['model']['theta'],expected['cloud'])
                    assert set(committed['histories']) == set(range(1,11))
                    for i, exact in enumerate(expected['histories_after'],1):
                        close(committed['histories'][i]['theta'],exact)
                    for payload in received['payloads']:
                        metadata_native(payload[1])
                        i = payload[1]['client_id']
                        assert payload[1]['num_samples'] == i
                        assert payload[1]['completed_steps'] == 2
                        close(payload[0]['theta'],expected['endpoints'][str(i)])
                    numerical_fields += 13
                checks.append({'python_tag':tag,'mode':mode,'run':relative,
                               'rounds':list(round_ids),'status':'PASS_STRICT_FLOAT64',
                               'natural_shutdown':True,'survivors':[]})
            saved = load(case/'split/first/committed-2.pth')
            start = load(case/'split/resumed/start.pth')
            assert saved['rng']['selection'] != saved['rng']['python']
            assert start['pending'] is None and start['round'] == 2
            assert same(start['rng'],saved['rng'])
            fresh = load(case/'control/run/start.pth')
            assert fresh['rng']['selection'] == random.Random(17).getstate()
            assert fresh['pending'] is None and fresh['round'] == 0
            for r in (3,4):
                control, resumed = load(case/f'control/run/committed-{r}.pth'),load(case/f'split/resumed/committed-{r}.pth')
                for key in ('model','histories','counts','committed_round','rng'):
                    assert same(control[key],resumed[key]), key
            checks.append({'python_tag':tag,'mode':mode,'case':'separate_CPU_RNG_and_actual_start_handoff',
                           'status':'PASS','later_selections':[[5,3],[9,5]]})
        directory = next(root.glob('test_shipped_mnist_shaped_l*/lenet-run'))
        result = json.loads((directory/'result.json').read_text())
        assert result['returncode'] == 0 and not result['timed_out'] and not result['forced'] and not result['survivors']
        histories = None
        changed = False
        max_error = 0.0
        for r in range(1,4):
            before, committed = load(directory/f'received-{r}.pth'), load(directory/f'committed-{r}.pth')
            if histories is None:
                histories = {i:{k:v.clone() for k,v in h.items()} for i,h in before['before'].items()}
            for payload in before['payloads']:
                metadata_native(payload[1])
                i = payload[1]['client_id']
                assert payload[1]['num_samples'] == (2 if i==1 else 6)
                assert payload[1]['completed_steps'] == 1
                for k,v in payload[0].items():
                    delta = v-before['baseline'][k]
                    changed |= bool(torch.any(delta!=0))
                    histories[i][k] += delta
            for k,v in committed['model'].items():
                endpoints = sum(p[0][k] for p in before['payloads'])/len(before['payloads'])
                expected = endpoints+sum(h[k] for h in histories.values())/2
                torch.testing.assert_close(v,expected,atol=1e-6,rtol=1e-6,equal_nan=False)
                max_error=max(max_error,float((v-expected).abs().max()))
            for i,h in histories.items():
                for k,expected in h.items():
                    torch.testing.assert_close(committed['histories'][i][k],expected,atol=1e-6,rtol=1e-6,equal_nan=False)
        assert changed
        checks.append({'python_tag':tag,'case':'actual_shipped_LeNet_native_wire_all_histories',
                       'status':'PASS','rounds':[1,2,3],'max_cloud_abs_error':max_error,
                       'survivors':[],'natural_shutdown':True})
        for p in root.rglob('*'):
            if p.is_file() and p.name in ('result.json','start.pth','received-1.pth','received-2.pth','received-3.pth','received-4.pth',
                                          'committed-1.pth','committed-2.pth','committed-3.pth','committed-4.pth'):
                receipts.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    result={'status':'PASS','checks':checks,'numerical_fields_checked':numerical_fields,
            'receipts':receipts,'production_cases_reexecuted_here':False,
            'provenance':'Independent strict comparison of completed focused-suite runtime executions; not additional entrypoint runs'}
    (H/'final-runtime-capture-validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','check_groups':len(checks),'numerical_fields_checked':numerical_fields,'raw_receipts':len(receipts)}))


if __name__ == '__main__':
    main()
