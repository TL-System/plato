"""Production full-bundle handoff with populated Python/NumPy Gaussian caches.

Real socket/CLI continuation is covered separately; here inherited start is
observed at its boundary to check fields whose cache flags were zero there.
"""
import asyncio
import copy
import json
from pathlib import Path
import random
import sys

import numpy as np
import torch

from plato.callbacks.server import ServerCallback
from tests.integration.test_feddyn_round_flow import client, configuration, dispatch, local, server
from tests.integration.utils import configure_environment


def main():
    root = Path(sys.argv[1])
    root.mkdir(parents=True, exist_ok=True)
    with configure_environment(configuration(), runtime_root=root):
        from plato.servers import base
        s = server()
        py = random.Random(43)
        py.gauss(0,1)
        ns = np.random.RandomState(29)
        ns.normal()
        ts = torch.Generator(device='cpu').manual_seed(31)
        selector = random.Random(17)
        selector.sample(list(range(1,11)),2)
        selector.sample(list(range(1,11)),2)
        class SetSavedStreams(ServerCallback):
            def on_weights_aggregated(self, current, updates):
                if current.committed_round == 2:
                    random.setstate(py.getstate())
                    np.random.set_state(ns.get_state())
                    torch.set_rng_state(ts.get_state())
                    current.prng_state = selector.getstate()
                    current.context.state['prng_state'] = selector.getstate()
        s.callback_handler.add_callback(SetSavedStreams())
        for i in (1,2):
            s.updates = [local(client(i),dispatch(s,[i])[i],(0.0,4.0)[i-1],2)]
            asyncio.run(s._process_reports())
        s.save_to_checkpoint()
        saved = torch.load(s.checkpoint_bundle_path(),weights_only=True)
        assert saved['rng']['python'][2] is not None and saved['rng']['numpy'][3] == 1
        random.seed(999); random.random()
        np.random.seed(555); np.random.normal()
        torch.manual_seed(777); torch.rand(2)
        resumed = server()
        before = resumed._rng_snapshot()
        resumed._resume_from_checkpoint()
        from plato.trainers.strategies.algorithms.feddyn_strategy import same_state
        assert same_state(resumed._rng_snapshot(),before)
        observed = []
        inherited = base.Server.start
        def enter(current,*args,**kwargs):
            observed.append(current._rng_snapshot())
            assert current._pending_resume_rng is None
            return 'observed-inherited-start-boundary'
        base.Server.start = enter
        try:
            assert resumed.start() == 'observed-inherited-start-boundary'
            assert same_state(observed[0],saved['rng'])
            assert random.gauss(0,1) == py.gauss(0,1)
            assert np.random.normal() == ns.normal()
            assert torch.equal(torch.rand(2),torch.rand(2,generator=ts))
            after = resumed._rng_snapshot()
            resumed.start()
            assert same_state(resumed._rng_snapshot(),after)
        finally:
            base.Server.start = inherited
        result={'status':'PASS','python_gaussian_cache_populated':True,
                'numpy_gaussian_cache_populated':True,'torch_CPU_restored':True,
                'separate_selection_context_fields_restored':True,
                'load_does_not_mutate_live_streams':True,'consumed_once':True,
                'limit':'Inherited start boundary observed here; actual listener/run/CLI/socket covered by separate captured entrypoint cases'}
        (root/'results.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result))


if __name__ == '__main__':
    main()
