"""Reviewer-owned source provenance guard, inherited by Python subprocesses."""
import importlib.machinery
import json
import os
from pathlib import Path
import sys

CANDIDATE = Path('/tmp/plato-refresh-worktrees/training-final-review').resolve()
LOGS = Path('/tmp/plato-phase2c-feddyn-code-review/final-origin-logs')
LOGS.mkdir(exist_ok=True)


def record(event, **values):
    with (LOGS / f'{os.getpid()}.jsonl').open('a') as stream:
        stream.write(json.dumps({'event': event, 'pid': os.getpid(), **values}) + '\n')


class Guard:
    def find_spec(self, fullname, path=None, target=None):
        if fullname == 'plato' or fullname.startswith('plato.') or fullname in (
            'feddyn', 'feddyn_client', 'feddyn_server', 'feddyn_trainer'
        ) or fullname.startswith('tests.integration.'):
            spec = importlib.machinery.PathFinder.find_spec(fullname, path, target)
            if spec is not None and spec.origin not in (None, 'built-in', 'frozen'):
                origin = Path(spec.origin).resolve()
                assert origin.is_relative_to(CANDIDATE), (fullname, origin)
                record('import', module=fullname, origin=str(origin))
            return spec
        return None


sys.meta_path.insert(0, Guard())
record('python_start', cwd=str(Path.cwd().resolve()), executable=sys.executable,
       pythonpath=os.environ.get('PYTHONPATH'), argv=sys.argv)
