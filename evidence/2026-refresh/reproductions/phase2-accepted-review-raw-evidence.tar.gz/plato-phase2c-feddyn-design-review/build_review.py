"""Assemble the independently authored report and immutable evidence receipts."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/bli/Playground/plato')
SNAPSHOT = Path('/private/tmp/plato-refresh-worktrees/feddyn-design')
SCRATCH = Path('/tmp/plato-phase2c-feddyn-design-review')
DESIGN = ROOT/'evidence/2026-refresh/phase2c-feddyn-design.json'
OUTPUT = ROOT/'evidence/2026-refresh/phase2c-feddyn-design-review.json'
EXPECTED = '455d144736f6318246c834d679e2ca8d371160dd654bfea6bab96b7abc9c4d60'


def receipt(path):
    p=Path(path);b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def git(*args):
    return subprocess.run(['git',*args],cwd=SNAPSHOT,check=True,
                          capture_output=True,text=True).stdout.strip()


def criterion(id, result, independent_expected, negative_path, evidence):
    return dict(id=id,design_assessment=result,
                independent_expected=independent_expected,
                negative_path_acceptance=negative_path,
                reviewer_evidence=evidence,
                implementation_status='NOT_IMPLEMENTED_OR_ACCEPTED_BY_THIS_REVIEW')


def main():
    d=json.loads(DESIGN.read_text())
    assert receipt(DESIGN)['sha256']==EXPECTED
    assert git('rev-parse','HEAD')=='62d7b7d8ef75be779149a96f567779c86699edb4'
    assert git('status','--porcelain=v1')==''
    inputs=[]
    for group in ['inputs','inspected_flow_receipts','primary_code']:
        for declared in d['sourceidentities'][group]:
            item=receipt(declared['path'])
            assert item['sha256']==declared['sha256'] and item['bytes']==declared['bytes']
            item['matches_design_receipt']=True
            inputs.append(item)
    astra_files=['oracle.py','oracle-results.json','candidate-scalar-replay.json',
                 'candidate-scalar-replay.stderr.log','build_design.py','2111.04263v1.pdf']
    astra_receipts=[receipt(Path('/tmp/plato-phase2c-feddyn-design')/p) for p in astra_files]
    assert astra_receipts[0]['sha256']==d['oracle']['script']['sha256']
    assert astra_receipts[1]['sha256']==d['oracle']['results']['sha256']
    assert astra_receipts[2]['sha256']==d['candidate_scalar_replay']['output']['sha256']
    assert astra_receipts[3]['sha256']==d['candidate_scalar_replay']['stderr']['sha256']
    assert astra_receipts[5]['sha256']==d['sourceidentities']['primary_paper']['sha256']
    extra_paths=['plato/servers/strategies/client_selection/random_selection.py',
                 'plato/trainers/strategies/data_loader.py',
                 'plato/trainers/strategies/training_step.py',
                 'plato/trainers/strategies/optimizer.py',
                 'plato/trainers/strategies/lr_scheduler.py',
                 'plato/models/lenet5.py','plato/config.py',
                 'tests/integration/utils.py','tests/integration/test_event_loop_startup.py',
                 'tests/integration/test_scaffold_round_flow.py']
    extra_receipts=[receipt(SNAPSHOT/p) for p in extra_paths]
    a_path=ROOT/'evidence/2026-refresh/phase2a-acceptance.json'
    a=json.loads(a_path.read_text())
    assert a['decision']=='ACCEPTED_COMPONENT'
    assert a['candidate_commit']=='79da1f97d8a12fe97402750cc32c7b3e8f5cdf6e'
    assert a['candidate_tree']=='dbd5d3847797665c80ea5ca2f92da48f6576467f'
    commands=json.loads((SCRATCH/'command-records.json').read_text())
    assert [r['exit_code'] for r in commands]==[0,0]
    probes={v:json.loads((SCRATCH/f'probes-{v}.json').read_text()) for v in ['313','314']}
    assert probes['313']['rational']==probes['314']['rational']
    owned=['review_probes.py','build_review.py','command-records.json',
           'source-fetch-receipts.json','probes-313.json','probes-313.stderr.log',
           'probes-314.json','probes-314.stderr.log','accepted-b-feddyn_strategy.py',
           '2111.04263v1.pdf','utils_general.py','utils_methods.py','README.md']
    evidence=[receipt(SCRATCH/p) for p in owned]
    for p in probes.values():
        for fixture in p['legacy_writer']['fixtures']:
            evidence.append(receipt(fixture['path']))
    verified=dict(design=receipt(DESIGN),declared_inputs=inputs,
                  additional_immutable_code=extra_receipts,astra_scratch=astra_receipts,
                  accepted_a=receipt(a_path))
    (SCRATCH/'verified-inputs.json').write_text(json.dumps(verified,indent=2)+'\n')
    evidence.append(receipt(SCRATCH/'verified-inputs.json'))

    findings=[dict(
        id='FD-D-R01',severity='medium',status='OPEN_DESIGN_BLOCKER',
        title='Checkpoint selection RNG restoration is overwritten by inherited startup reseeding.',
        artifact_fields=['/stateflow/checkpoint/owner','/stateflow/checkpoint/read',
                         '/stateflow/checkpoint/scope','/testacceptance/11'],
        criterion='FD-A12',
        trigger='Resume a committed synchronous FedDyn round with server.random_seed configured, through the actual example Server.run entrypoint.',
        source_locations=[dict(path='plato/servers/base.py',line=353,meaning='run restores the checkpoint before starting clients'),
                          dict(path='plato/servers/base.py',line=395,meaning='run reseeds random and replaces self.prng_state after restoration'),
                          dict(path='plato/servers/base.py',line=383,meaning='equivalent reseed exists in the central-server branch; cross-silo remains unsupported'),
                          dict(path='plato/servers/base.py',line=841,meaning='selection overwrites context prng_state from self.prng_state'),
                          dict(path='plato/servers/strategies/client_selection/random_selection.py',line=27,meaning='selection consumes the replaced context state')],
        evidence='Independently executed actual base.Server.run with a scratch-only subclass and the actual RandomSelectionStrategy, Python 3.13.16 and 3.14.8. Seed 17, population 10, per_round 2: committed selections [9,7] then [5,6]; restoring that boundary should select [5,3] next. Startup instead selects [9,7] and the restored state no longer matches. Both probe processes exit 0 after asserting this defect.',
        impact='The saved cloud/history bundle can be internally coherent yet advertised deterministic continuation fails at the actual user entrypoint. Testing _resume_from_checkpoint and then selecting directly would miss this ordering.',
        minimal_correction='Add an explicit example-local startup handoff, for example retain validated restored RNG state in _resume_from_checkpoint and reapply it from the FedDyn Server.start override after inherited seeding and before registration/selection. Restore the appropriate live/context selection state and declared CPU RNG states coherently. Keep plato/servers/base.py unchanged and preserve fresh-run seeding. A scratch-only start override already selects the expected [5,3] under the unchanged base run.',
        acceptance='Extend FD-A12 with actual Server.run/--resume ordering and nontrivial server.random_seed. Verify uninterrupted versus resumed selections and model/all-client histories over a later round, fresh-run seed behavior, and no live RNG/pending resume state change on rejected bundle loads. FD-A13 should include or share this bounded actual-entrypoint resume case.',
        scope='This requests one example-local hook and a focused continuation case, not generic checkpoint/runtime redesign or mid-round/GPU replay.',
        ownership='Root alone assigns this correction to the original Astra design author, then obtains a fresh independent review of the revised artifact. No correction was applied by this reviewer.'
    )]
    lows=[dict(
        id='FD-D-L01',severity='low',status='NONBLOCKING_PRECISION_CORRECTION',
        title='FD-A08 names per-update scheduler notifications despite the no-scheduler contract.',
        artifact_fields=['/testacceptance/7/expected','/algorithm/optimizer_policy'],
        source_locations=[dict(path='plato/trainers/composable.py',line=626),
                          dict(path='plato/trainers/composable.py',line=698),
                          dict(path='plato/trainers/composable.py',line=742),
                          dict(path='plato/trainers/strategies/lr_scheduler.py',line=51)],
        observation='The accepted normal/tail paths notify optimizer_strategy.on_optimizer_step, model_update_strategy.after_step and on_train_step_end per actual update. lr_scheduler_strategy.step is an epoch-boundary call; no actual scheduler is created in the supported example. FD-A08 says exactly two optimizer/scheduler/after-step notifications.',
        minimal_correction='Name the two actual optimizer/update/callback notifications and assert no scheduler creation or actual scheduler stepping. If spying on the no-op epoch scheduler strategy, distinguish its epoch call count from optimizer update count. Do not add or alter generic scheduler behavior.',
        acceptance='The three-microbatch/two-update scalar remains y=1.99005, h_next=.49005; its update counts remain two and zero-completed attempts still fail.'
    )]

    criteria=[
      criterion('FD-A01','ADEQUATE',
        'Analytical alpha*(w-x+h): at (2,2,0), gradient 0 and y=2; at (1,2,.5), gradient=-.05 and y=1.005; new same-client (3,3,.5), gradient=.05, y=2.995, h_next=.495. Locally alpha0 reduces to the task objective.',
        'The old y=2.02 must fail; full example alpha0 must reject before dispatch rather than apply a stale cloud correction.',
        'Independent Fraction calculations plus executed pinned author train_feddyn_mdl scalar return 2. The immutable candidate returns 2.0200000002980234 on both interpreters.'),
      criterion('FD-A02','ADEQUATE',
        'Uniform endpoints 811/500, 1918163/1000000, 3212457979/2000000000; cloud 1433/1000, 3943489/2000000, 5908210937/4000000000. Final h1=-1487031021/2000000000, h2=485163/1000000.',
        'Reject a substituted FedAvg endpoint, active-only history denominator, or reassigned-client history; compare every round boundary, including inactive history.',
        'Reviewer used an affine two-step closed form and the paper signed gradient-state recurrence, independently of the planner loop and any Plato helper. Every retained exact trajectory field agrees.'),
      criterion('FD-A03','ADEQUATE',
        'Counts [1,3] give q=[1/2,3/2], alpha_i=[1/5,1/15]. Endpoints 203/125, 90068/46875, 25293633/15625000; cloud 359/250, 123511/62500, 140139947/93750000. Equal counts reproduce uniform; counts [17,93] do not alter uniform.',
        'Selected-only normalization or sample-weighted model averaging must fail. Wrong/changed realized counts cannot commit. The objective minimizers 2 versus 3 follow directly from the two quadratic losses, not a convergence claim.',
        'All rational fields independently match. Executed the pinned author normalization/alpha/history/cloud statements; normalized counts [.5,1.5], alpha1=.2 and cloud1=1.4360000000000002.'),
      criterion('FD-A04','ADEQUATE',
        'N3, baseline2, old h=[.4,-.2,.6], selected endpoints1 and4 gives h_next=[-.6,-.2,2.6], mean h=.6, selected mean2.5, cloud3.1. Both modes use the same aggregation. Real first-round full participation gives cloud2 uniformly and 751/375 in sample mode.',
        'Changing N to 2, losing inactive -.2, or weighting selected endpoints by counts produces a different result and must fail; retain never-selected zeros.',
        'Independent exact Fraction checks passed for the population and full-participation values.'),
      criterion('FD-A05','ADEQUATE',
        'With matched task/output-column permutation, alpha and regularizer are independent of label IDs, labels summing to zero, class imbalance, batch size and epoch count. Count authority is len of the realized finite loader sampler, not backing trainset length.',
        'Unknown-length/streaming, inconsistent sampler metadata, sample-vector mismatch and later changed cardinality fail before optimization or commit; rejected counts never enter observed-count state.',
        'Inspected loader construction and both generic count fallbacks. Independently reproduced label-sensitive old behavior with the shipped N1000 settings. Accepted A is now available but does not eliminate these boundary checks.'),
      criterion('FD-A06','ADEQUATE',
        'Local alpha0 is mathematically task-only; the end-to-end method requires finite positive alpha, supported sync selection and exact validated configuration. Sample alpha must be computed in the parameter computation dtype, preserving float64 expectations.',
        'Invalid types including bool, nonfinite/negative alpha, counts/ranges/modes/conflicts, nonSGD/momentum/decay/clipping/AMP/DP/async choices fail with no state, files or successful outbound mutation; validate actual optimizer choices rather than silently rewrite them.',
        'Pinned author split-decay execution and independent derivative validate the need for optimizer weight_decay0 in the explicit full-loss formulation. Full unsupported-mode tests remain implementation obligations.'),
      criterion('FD-A07','ADEQUATE',
        'Only fixed Q trainables contribute to objective/history/cloud correction. Reversing optimizer groups preserves output because identity/names, not position or equal shapes, define ownership. Frozen parameters and static float/int/bool buffers remain equal to baseline.',
        'Missing/duplicate/foreign optimizer parameters, aliases, dynamic schema/trainability, original-model shape/dtype/key/finiteness mismatch and mutable buffers reject before acceptance. Byte snapshots must prevent payload alias mutation.',
        'Inspected fixed LeNet trainables and absence of registered mutable buffers. Strict validation can live in the owned strategy/adapters; no generic aggregation buffer policy change is required.'),
      criterion('FD-A08','ADEQUATE_WITH_LOW_WORDING_CORRECTION',
        'Two actual SGD updates yield 399/200 then 39801/20000 (1.995 then 1.99005), so staged h=.49005. One successful update following a skip yields y1.995/h.495. Count optimizer/update/callback events, with no actual scheduler in this contract.',
        'Tail/short/divisible windows count their actual successful updates. Empty/zero-epoch/all-skipped attempts produce no accepted result or history change; retry must begin with clean gradients.',
        'Independent rational scalar checks; inspected normal and accumulation-tail hooks and tail rescaling. See FD-D-L01 for scheduler wording.'),
      criterion('FD-A09','ADEQUATE',
        'Physical reuse 1->2->1, dedicated clients and fresh processes must expose identical FD-A02 endpoint/history/count/step state at each boundary. Consecutive same-client dispatches replace the global baseline.',
        'A client0/old-file decoy or stale previous dispatch cannot provide current history. Actual successful spawn must update parent model and strategy together before packaging its report.',
        'Existing identity-change and worker-state hooks are available. Their success was not asserted for unimplemented FedDyn; real spawn assertions are appropriately required.'),
      criterion('FD-A10','ADEQUATE',
        'The last successful server and parent state survives a failed child handoff. A valid retry from the same dispatch state reproduces the pre-failure oracle, including after 1->2->1 reuse.',
        'Nonzero-after-save, absent/corrupt/stale sidecar, bad h_next/model pairing or later parent callback exception sends no update, rolls back model/owned context/strategy, clears provisional state, and does not change canonical server bundle bytes.',
        'Inspected composable load-model-before-load-worker-state ordering and failure cleanup. The local Trainer.train wrapper can contain this with tensor snapshots; removing canonical client history writes addresses the exact F27-R02 contamination pattern.'),
      criterion('FD-A11','ADEQUATE',
        'Each original client model and all metadata must validate before any staged arithmetic/load. Revalidation after on_weights_received must protect against transformed or aliased models. Valid follow-up consumes current dispatches once.',
        'Malformed second participant, missing/extra keys, broadcastable wrong shapes, wrong dtype, NaN/Inf, buffer mutation, duplicate/stale/unknown IDs, count/token/generation mismatch, missing selected client and aggregation/load failure reject the whole batch. Verify every h_i, model, counts, accepted tokens and checkpoint bytes unchanged.',
        'Existing weights_received, aggregate_weights, weights_aggregated and local _process_reports wrapper can implement this; forcing weight-aggregation preference false avoids the inspected bypass. This addresses F27-R01 without modifying generic B policies.'),
      criterion('FD-A12','REQUIRES_FD_D_R01_CORRECTION',
        'A coherent round2 model/history/count/config/round/RNG bundle resumes the exact FD-A02 round3 rational result in either mode, including selection continuation through actual Server.run, not only a direct restore method call.',
        'Malformed/incompatible/versionless bundle and serialization failure leave live model/history/metadata/round/RNG and prior canonical bytes unchanged. Dispatch current_round cannot masquerade as a committed round. Rejected load also cannot leave pending startup-restoration state.',
        'Bundle design is bounded and otherwise coherent. Independently executed actual startup proves restored selection state is overwritten; scratch-only local start hook preserves expected continuation. Production bundle/socket resume remains unimplemented.'),
      criterion('FD-A13','ADEQUATE_WITH_RESUME_CASE_SHARED_FROM_FD_A12',
        'Actual shipped entrypoint instantiates the new adapters, trains finite changing LeNet endpoints on bounded MNIST-shaped data, and produces cloud from an independent endpoint/history table over three partial-participation rounds. Real socket and actual spawn serialize the same metadata.',
        'Bounded failures emit no successful report and leave no children. Unsupported settings fail clearly. Isolate ports/runtime paths and preserve normal shutdown; a watchdog kill is not successful completion. Add/share actual startup resume ordering case.',
        'Inspected real composable payload path, shipped wiring/TOML and accepted event-loop socket harness. Existing defaults meet plain SGD/static-buffer/fixed600 contract; smoke is not benchmark qualification and has not been run for a future implementation.'),
      criterion('FD-A14','ADEQUATE',
        'Exact source hashes, independent equations, scoped diff, public API migration and standalone Astra prose agree with final owned implementation; root acceptance follows fresh code/numerical/failure-path and prose reviews.',
        'No accepted B/shared loop/F20/SCAFFOLD changes or weakened tests; no finite-only claim closes algebra defects. Record interpreter/lock/source/commands/results/skips and limits. Source receipts are rechecked after the permitted accepted-A handoff.',
        'All declared source/input receipts match. Independently fetched pinned primary bytes match both retained copies. Shared source/prose ownership is explicit and serialized; design review closes neither 2C-11 nor Phase2.'),
      criterion('FD-A15','ADEQUATE_AND_JUSTIFIED_INTENTIONAL_MIGRATION',
        'Accepted-B actual writer produces weight7/bias8 at root+"_feddyn_grad_1.pth", for default and custom roots. Explicit new read-only inspection recovers that same-client vector, prefers canonical when present, and preserves every original byte.',
        'Client0 cannot seed another client; malformed vectors fail visibly; no fuzzy spelling or corruption-to-zero fallback. The old vector alone cannot resume corrected numerical histories. Explicit model-only warm start creates zero histories/new run UUID; save_path supplied for new training raises migration guidance.',
        'Independently executed the exact accepted-B class from git show on both interpreters, obtained weight7/bias8 and corroborated immutable candidate filename miss. Proposed new explicit reader is a future obligation; this review did not inspect the evolving training worktree or claim its separate repair accepted.')
    ]
    assert [c['id'] for c in criteria]==[f'FD-A{i:02d}' for i in range(1,16)]
    report=dict(
      schema_version=1,date='2026-10-03',written_at_utc=datetime.now(timezone.utc).isoformat(),
      role='Fresh independent design reviewer; no nested agents, implementation edits or acceptance authority.',
      verdict='REQUEST_CHANGES',design_acceptance='NOT_ACCEPTED_PENDING_ONE_MEDIUM_DESIGN_CORRECTION',
      finding_counts=dict(critical=0,high=0,medium=1,low=1),
      summary='Retain-and-repair, corrected algebra, authoritative histories, bounded API migration and complete round-boundary bundle are justified and feasible through example-local hooks. One concrete startup/RNG ordering gap blocks the promised continuation; correct it locally and strengthen FD-A12. Scheduler wording is a separate low. Design approval alone would not be code or phase acceptance.',
      reviewed_artifact=receipt(DESIGN),requested_sha256=EXPECTED,
      immutable_code_context=dict(root=str(SNAPSHOT),commit=git('rev-parse','HEAD'),
         tree=git('rev-parse','HEAD^{tree}'),detached=True,clean_before_and_after=True,
         evolving_training_worktree_used=False),
      findings=findings,low_findings=lows,
      primary_sources=dict(
        paper=dict(url='https://arxiv.org/pdf/2111.04263v1',receipt=receipt(SCRATCH/'2111.04263v1.pdf'),
                   locations='Section2 and Algorithm1, PDF pages3-4; clipping/reporting qualification in AppendixA.4.',
                   independent_read='Opened primary arXiv PDF through web and inspected Algorithm1; independently fetched full bytes with verified TLS. Hash equals pinned root and Astra copies.'),
        author_commit='48a19fac440ef079ce563da8e0c2896f8256fef9',
        fetches=json.loads((SCRATCH/'source-fetch-receipts.json').read_text()),
        source_reconciliation=[
          dict(source='[Pinned author local function](https://github.com/alpemreacar/FedDyn/blob/48a19fac440ef079ce563da8e0c2896f8256fef9/utils_general.py)',
               conclusion='Its linear term contributes alpha_i*(-x+h); SGD decay alpha_i+weight_decay contributes alpha_i*w when external weight_decay0. Together this is alpha_i*(w-x+h). The shifted quadratic plus linear h is therefore correct; an additional -x linear term doubles the shift.',
               execution='Executed the exact pinned function body for a float64 zero-task-gradient scalar, returning2.0. Separately executed split-decay clipping order: inactive case agrees; active scalar derivative20 produces author split y=.980000050505048 versus explicit unclipped y0. The design correctly rejects clipping and limits equivalence claims.'),
          dict(source='[Pinned author cloud loop](https://github.com/alpemreacar/FedDyn/blob/48a19fac440ef079ce563da8e0c2896f8256fef9/utils_methods.py)',
               conclusion='Counts normalize to population-mean-one q; effective alpha is alpha/q. History adds endpoint minus cloud without q scaling. Cloud uses uniform selected endpoint mean plus all-population history mean, in both modes. Selected/all/cloud evaluation models differ.',
               execution='Executed pinned normalization, alpha, history and cloud statements for counts1/3; obtained q=.5/1.5, alpha1=.2 and cloud1.436. Full three-round expectations derive independently from Fraction affine updates and paper signed gradient states.'),
          dict(source='[Primary paper Algorithm1](https://arxiv.org/pdf/2111.04263v1)',
               conclusion='Let paper client gradient state be g_i=-alpha*h_i for common-alpha scaled losses. Its server average is -alpha*mean(h). The paper subtracts that state divided by alpha, yielding selected mean(y)+population mean(h). Scaling local task losses by q_i explains sample weighting; finite-step SGD is an inexact solve and does not establish a new convergence theorem.')]),
      algorithm_assessment=dict(
         result='CORRECT_WITHIN_DECLARED_CONTRACT',
         local='J_i=F_i+alpha_i<h_i,w>+(alpha_i/2)||w-x||^2; grad=gradF_i+alpha_i*(w-x+h_i).',
         history_and_cloud='h_i_next=h_i+y_i-x exactly once for successful selected clients; other histories unchanged. x_next=uniform mean_selected(y)+uniform mean_population(h_next).',
         weighting='Uniform default q_i1; sample q_i=N*n_i/sum(n), alpha_i=alpha/q_i. Positive fixed realized counts and complete population vector in sample mode. Labels never enter alpha.',
         qualification='Plain CPU float32/float64 SGD, zero momentum/decay, no scheduler/clipping/AMP/DP, fixed nonempty trainables and static frozen/buffer state. Explicit full-loss differentiation avoids double alpha decay. Strict actual optimizer ownership and original-model validation are necessary.',
         numeric_result=probes['313']['rational']),
      feasibility_assessment=dict(
         client='The proposed DefaultTrainingStrategy subclass must be installed via _configure_composable: DefaultPayloadStrategy directly calls load_payload/train (defaults.py:297). simple.Client._load_payload/_train overrides alone are bypassed. Successful-result checks and stale training_error clearing can stop the generic ValueError/report fallback before outbound send.',
         server='fedavg._process_reports retains subclass aggregate_weights when _should_prefer_weight_aggregation returns false (fedavg.py:202-228). weights_received and post-callback aggregate validation can reject original model/metadata batches. weights_aggregated follows live model load, so example-local wrapper snapshots must contain all precommit exceptions and direct tensor restoration must not re-enter the injected failing loader.',
         worker='Composable requires_worker_state/get_worker_state/load_worker_state supports actual spawn. Generic load_model precedes load_worker_state (composable.py:855-858); example-local Trainer.train can snapshot/rollback actual model and owned strategy/context. Child stages history only, carries dispatch and baseline, and parent verifies h_next against the accepted loaded endpoint before publishing. Zero-step failure and normal/tail after_step hooks are available. No canonical child history write may survive a rejected result.',
         metadata='Realized loader sampler cardinality is available only after create_train_loader. The new local wrapper can bind it before optimizer construction/first compute_loss and report the same worker-accepted count, avoiding later generic sampler redraw/backing-dataset fallbacks. It must store a dedicated authoritative count rather than trust generic context.num_samples overwritten afterward.',
         startup='All selected adapter mechanisms exist in the immutable snapshot. The sole identified design gap is inherited run reseeding after checkpoint restore; local start interception is available and independently demonstrated.',
         failure_round='current_round increments on dispatch (base.py:568), so committed_round and committed RNG snapshot must remain distinct. Keep the fixed selected set through max_concurrency batches and commit only when every member validates. Default disconnect recovery under general.debug=false (base.py:1522) must be disabled/rejected or intercepted locally to enforce the already stated no-dropout/retry contract; this is an implementation caution under the explicit unsupported-mode requirement, not a separate design blocker.',
         user_invocation='Existing example path/config and algorithm.type=fedavg can remain. Dedicated adapters come from main. Existing LeNet has no mutable registered buffers; shipped counts600, SGD lr.03/momentum0/decay0 satisfy the bounded CPU command. New uniform default avoids fabricating a1000-entry count vector. Actual three-round/socket/spawn entrypoint qualification remains required.'),
      proportionality_and_migration=dict(
         disposition='Retaining the named method and fixing both local and server equations is proportionate; a loss-only patch with plain FedAvg would still advertise a different method. No evidence requires archival, benchmark campaign or generic protocol redesign.',
         history_placement='Central population histories are not the only possible mathematical placement, but are a bounded, coherent choice for logical-client reuse, current-worker pairing and whole-round rejection in the retained composable example. Sparse omitted never-selected zeros limit state in short default runs. Extra history downlink/O(Nd) server storage must be disclosed; no original communication-budget claim.',
         checkpoint_minimum='After server-owned histories are selected, model-only or separate unsynchronized client history checkpoints cannot preserve retained continuation. One atomic versioned model/population-history/schema/count/alpha/committed-round/selection-RNG bundle is the minimum coherent authority for this choice. Fresh local momentum-free SGD needs no retained optimizer state. Mid-round recovery, arbitrary datasource RNG and exact GPU replay remain outside scope.',
         intentional_api_change='The public class exports remain; corrected training requires explicit validated server-provided dispatch state. This is a deliberate numerical/state-interface migration, not transparent backward compatibility. Explicit read_legacy_history remains meaningful for save_path and returns detached validated historical data without adoption or writes; unsupported old training receives migration guidance.',
         f23_reconciliation='TRAINING-2C-02/F23 repaired a real filename/readability contract independently of objective correctness. Preserve the exact accepted-B underscore spelling, custom roots, canonical preference, client0 exclusion and originals through the explicit read-only operation. Keep its historical repair evidence. Versionless old vectors lack corrected cloud/population/config/generation coherence and must never silently continue new equations. The separate required operation and strong FD-A15 old-writer fixture make this clear, bounded and testable rather than contradictory.',
         root_policy='The accepted plan normally preserves research equations/configuration meaning. The user explicitly selected independent bounded disposition/review for2C-11 and allows root a justified design adjustment. This correction of the advertised algorithm plus explicit migration is justifiable under that authority. Root still decides acceptance; this reviewer authorizes no implementation.'),
      accepted_a_dependency=dict(receipt=receipt(a_path),commit=a['candidate_commit'],tree=a['candidate_tree'],
         status='USER_STEERING_CONFIRMED_BY_ROOT_ACCEPTANCE_RECEIPT',
         relevance='The snapshot predates independently accepted F15/realized-count/sampler-identity fixes. Final C may receive the user-authorized narrow clean-boundary merge before implementation. No A source or acceptance was rerun, and no pre-A sampler defect is counted as a missing-hook/feasibility blocker. Retain authoritative realized-loader checks and reject unknown/dynamic cardinality; re-pin final reviewed C source after handoff.'),
      relevant_prior_findings=dict(
         training='Read ROOT phase2c-training-review.json. TRAINING-2C-02 exact accepted-B writer filename is independently corroborated here. ROOT-2C-01 clipping, long-name cleanup and FedALA findings remain separate; no evolving fix source was consumed.',
         scaffold='Read ROOT phase2c-scaffold-code-review.json. F27-R01 demands validation of every original model plus controls before commit; FD-A11 covers its FedDyn analogue. F27-R02 demonstrates canonical child-state contamination after rejected handoff and1->2->1 reuse; server ownership/no child canonical writes and FD-A10 cover its analogue. Their correction/acceptance is not claimed by this review.'),
      criterion_reviews=criteria,
      ownership_and_prose=dict(
         result='EXPLICIT_AND_BOUNDED',
         source='Original C owns only feddyn_strategy.py and FedDyn example entrypoint/trainer/new client/new server/TOML. Root serializes narrowly changed FedDyn branches of shared ownership/update tests and evidence inventories; preserve other family/F08/F20 coverage.',
         dependency='Accepted A may be integrated only under the new user steering; generic B runtime, samplers, Config, optimizer registry, common loops and serialization remain outside FedDyn editing scope.',
         prose='Fresh Astra writer after implementation owns only FedDyn public prose, serialized with the SCAFFOLD writer. It must reconcile signs/cloud model, both weighting modes, count provenance, supported optimizer and buffer scope, actual command, extra state cost, API/save_path/legacy migration, checkpoint limits and pinned primary attribution. Independent prose/source reconciliation and root integrated acceptance remain mandatory.',
         workflow='Root alone assigns original Astra corrections and any fresh reviewer. This reviewer spawned no agents, assigned no tasks, made no source/design changes, commits, pushes or cleanup.'),
      reviewer_executions=commands,
      reviewer_results={v:{k:p[k] for k in ['torch','author_cloud','startup_rng','legacy_writer']} for v,p in probes.items()},
      evidence_receipts=evidence,verified_input_receipts=verified,
      limitations=[
         'Design assessment only. Future production loss/adapter/bundle/migration-reader/entrypoint/socket/worker negative-path suites have not run and are not passed by these review probes.',
         'Both Python3.13.16 and3.14.8 CPU probes used Torch2.14.1 and the immutable snapshot. No GPU, AMP, benchmark/convergence or broad dependency qualification claim.',
         'Startup-order probe executes the actual base run/selection route with scratch-only configuration/subclass interception; it intentionally launches no clients/sockets and serializes no production FedDyn bundle.',
         'Author function extraction executes pinned AST bodies/statements with controlled test globals; it is source/algebra evidence, not an execution of the full historical author experiment.',
         'Legacy old-writer/current-reader replay corroborates known immutable filename red behavior, not the proposed corrected reader or the unrelated author repairs in the evolving training workspace.',
         'No nested agents. Only the requested ROOT review JSON and reviewer scratch were written. Required corrections and later code/prose/phase acceptance remain with root.'
      ],
      root_next_action='Return FD-D-R01 and the low FD-D-L01 wording correction to the original Astra design author; fresh independent review of a revised exact hash before root selects implementation. Do not accept this artifact as code/phase closure.'
    )
    OUTPUT.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(report=receipt(OUTPUT),finding_counts=report['finding_counts'],
                          verdict=report['verdict'],scratch=str(SCRATCH)),indent=2))


if __name__=='__main__':
    main()
