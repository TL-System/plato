"""Independent design probes. Writes only reviewer-owned scratch."""

import ast
import hashlib
import json
import os
from pathlib import Path
import random
import sys
from fractions import Fraction as F
from types import SimpleNamespace
from unittest.mock import patch

SCRATCH = Path('/tmp/plato-phase2c-feddyn-design-review')
SNAPSHOT = Path('/private/tmp/plato-refresh-worktrees/feddyn-design')
DESIGN = Path('/Users/bli/Playground/plato/evidence/2026-refresh/phase2c-feddyn-design.json')


def exact_trajectory(sample=False, counts=(1, 3)):
    """Use affine two-step solution and paper's signed gradient state."""
    x, gradient_states = F(2), [F(0), F(0)]
    rows = []
    alpha, eta = F(1, 10), F(1, 10)
    for round_id, i in enumerate((0, 1, 0), 1):
        q = F(2 * counts[i], sum(counts)) if sample else F(1)
        ai = alpha / q
        h = -gradient_states[i] / alpha
        b = 1 - eta * (1 + ai)
        affine = eta * (F((0, 4)[i]) + ai * (x - h))
        y = b * b * x + (1 + b) * affine
        baseline = x
        gradient_states[i] -= alpha * (y - x)
        x = y - sum(gradient_states) / (2 * alpha)
        rows.append(dict(round=round_id, client=i + 1, baseline=baseline,
                         alpha=ai, history_before=h, local=y, delta=y-baseline,
                         h1=-gradient_states[0]/alpha,
                         h2=-gradient_states[1]/alpha,
                         history_mean=-sum(gradient_states)/(2*alpha),
                         global_next=x))
    return rows


def encode(value):
    if isinstance(value, F):
        return {'exact': str(value), 'decimal': float(value)}
    if isinstance(value, dict):
        return {k: encode(v) for k, v in value.items()}
    if isinstance(value, list):
        return [encode(v) for v in value]
    return value


def rational_checks():
    design = json.loads(DESIGN.read_text())
    rows = {m: exact_trajectory(m == 'sample') for m in ('uniform', 'sample')}
    for mode, records in rows.items():
        for actual, expected in zip(records, design['oracle']['trajectory'][mode], strict=True):
            assert actual.keys() == expected.keys()
            for k, value in actual.items():
                assert value == (F(expected[k]['exact']) if isinstance(value, F)
                                 else expected[k]), (mode, k, value, expected[k])
    assert exact_trajectory(True, (2, 2)) == rows['uniform']
    assert exact_trajectory(False, (17, 93)) == rows['uniform']
    scalars = []
    for w, x, h in [(F(2),F(2),F(0)), (F(1),F(2),F(1,2)),
                    (F(3),F(3),F(1,2))]:
        grad = F(1,10)*(w-x+h)
        y = w-F(1,10)*grad
        scalars.append(dict(w=w,x=x,h=h,gradient=grad,y=y,h_next=h+y-x))
    staged = [F(2,5)+1-2, F(-1,5), F(3,5)+4-2]
    assert staged == [F(-3,5), F(-1,5), F(13,5)]
    cloud = F(1+4,2) + sum(staged)/3
    assert cloud == F(31,10)
    full = {}
    for sample in (False, True):
        ys = []
        for i in (0, 1):
            ai = F(1,10)/(F(2*(1,3)[i],4) if sample else 1)
            b = 1-F(1,10)*(1+ai)
            c = F(1,10)*((0,4)[i]+ai*2)
            ys.append(2*b*b+(1+b)*c)
        xnext = sum(ys)/2 + sum(y-2 for y in ys)/2
        full['sample' if sample else 'uniform'] = {'endpoints':ys,'cloud':xnext}
    assert full['uniform']['cloud'] == 2
    assert full['sample']['cloud'] == F(751,375)
    w = F(2)
    accumulation = []
    for _ in range(2):
        w -= F(1,10)*F(1,10)*(w-2+F(1,2))
        accumulation.append(w)
    assert accumulation == [F(399,200),F(39801,20000)]
    return encode(dict(trajectories=rows, scalars=scalars, multiple_participants={
        'histories':staged,'cloud':cloud}, full=full, accumulation=accumulation,
        all_design_rational_fields_match=True))


def torch_checks():
    import numpy as np
    import torch
    import torch.nn as nn
    from torch.utils import data

    # Execute the pinned author function, not a manually rewritten equivalent.
    src = ast.parse((SCRATCH/'utils_general.py').read_text())
    node = next(n for n in src.body if isinstance(n, ast.FunctionDef)
                and n.name == 'train_feddyn_mdl')
    def dataset(x,y,**kwargs):
        return data.TensorDataset(torch.as_tensor(x, dtype=torch.float64),
                                  torch.as_tensor(y, dtype=torch.long))
    def get_params(models, n_par=None):
        return np.stack([np.concatenate([p.detach().cpu().numpy().reshape(-1)
                                        for p in m.parameters()]) for m in models])
    env = dict(torch=torch,np=np,data=data,Dataset=dataset,
               device=torch.device('cpu'),max_norm=10,get_mdl_params=get_params)
    exec(compile(ast.Module(body=[node],type_ignores=[]),
                 str(SCRATCH/'utils_general.py'),'exec'),env)
    class Scalar(nn.Module):
        def __init__(self,w=2.):
            super().__init__()
            self.theta = nn.Parameter(torch.tensor([w],dtype=torch.float64))
        def forward(self,x):
            return torch.stack([self.theta*0+x[:,0]*0,
                                self.theta*0+x[:,0]*0],dim=1)
    author = Scalar()
    env['train_feddyn_mdl'](author,Scalar,.1,torch.tensor([2.],dtype=torch.float64),
                           torch.tensor([0.],dtype=torch.float64),
                           np.zeros((2,1)),np.zeros(2,dtype=int),.1,2,1,2,0,'toy')
    assert author.theta.item() == 2.

    from plato.trainers.strategies.algorithms.feddyn_strategy import FedDynLossStrategy
    from plato.trainers.strategies.base import TrainingContext
    candidate = []
    for adaptive, labels in [(False,[0,0]),(True,[0,0]),(True,[0,1]),(True,[1,1])]:
        m = Scalar()
        ctx=TrainingContext();ctx.model=m;ctx.device=torch.device('cpu');ctx.client_id=1
        ctx.state.update(feddyn_global_weights={'theta':torch.tensor([2.],dtype=torch.float64)},
                         feddyn_cumulative_grad={'theta':torch.zeros(1,dtype=torch.float64)})
        loss=FedDynLossStrategy(alpha=.1,adaptive_alpha=adaptive,
                               base_loss_fn=lambda outputs,labels: outputs.sum()*0)
        loss.setup(ctx);loss.on_train_start(ctx)
        opt=torch.optim.SGD(m.parameters(),lr=.1)
        lab=torch.tensor(labels)
        objective=loss.compute_loss(m(torch.zeros((2,1))),lab,ctx)
        objective.backward();grad=m.theta.grad.item();opt.step()
        candidate.append(dict(adaptive=adaptive,labels=labels,
                              gradient=grad,y=m.theta.item()))
    assert candidate[0]['y'] > 2.01999
    # Full-loss differentiation versus split decay, and active clipping limit.
    clipping = {}
    for active in (False, True):
        w=torch.nn.Parameter(torch.tensor([2.],dtype=torch.float64))
        # task derivative 20 (active) or 0 (inactive); linear derivative -.2
        task_grad = 20. if active else 0.
        opt=torch.optim.SGD([w],lr=.1,weight_decay=.1)
        ((task_grad-.2)*w).sum().backward()
        torch.nn.utils.clip_grad_norm_([w],10)
        opt.step()
        explicit = 2.-.1*(task_grad+.1*(2.-2.))
        clipping[str(active)] = dict(author_split_y=w.item(),explicit_unclipped_y=explicit)
    assert abs(clipping['False']['author_split_y']-2.) < 1e-15
    assert abs(clipping['True']['author_split_y']-clipping['True']['explicit_unclipped_y']) > .5
    return dict(python=sys.version,torch=torch.__version__,
                pinned_author_zero_gradient_y=author.theta.item(),candidate=candidate,
                clipping=clipping)


def startup_rng_check():
    from plato.servers import base
    from plato.servers.strategies.client_selection.random_selection import RandomSelectionStrategy
    seed=17
    rng=random.Random(seed)
    prior=[rng.sample(list(range(1,11)),2) for _ in range(2)]
    restored=rng.getstate()
    expected=rng.sample(list(range(1,11)),2)
    class ProbeServer(base.Server):
        def __init__(self):
            self.disable_clients=True;self.periodic_interval=1
            self.context=SimpleNamespace(state={},current_round=2)
            self.client_selection_strategy=RandomSelectionStrategy()
            self.current_round=2
        def configure(self):
            pass
        def _resume_from_checkpoint(self):
            self.prng_state=restored
            self.context.state['prng_state']=restored
            random.setstate(restored)
        async def _periodic(self,interval):
            pass
        def start(self):
            self.after_startup_state_matches_saved=self.prng_state==restored
            self.actual=self._select_clients_with_strategy(list(range(1,11)),2)
        def __str__(self):
            return 'ReviewerStartupProbe'
    config=SimpleNamespace(args=SimpleNamespace(resume=True),
                           clients=SimpleNamespace(type='simple'),
                           server=SimpleNamespace(random_seed=seed),
                           is_central_server=lambda:False)
    s=ProbeServer()
    saved_random=random.getstate()
    try:
        with patch.object(base,'Config',lambda:config):
            s.run()
    finally:
        random.setstate(saved_random)
    assert not s.after_startup_state_matches_saved
    assert s.actual==prior[0]
    assert s.actual!=expected
    # Feasibility only: an example-local start hook can repair this ordering.
    class LocalStartProbe(ProbeServer):
        def start(self):
            self.prng_state=restored
            self.context.state['prng_state']=restored
            random.setstate(restored)
            super().start()
    corrected=LocalStartProbe()
    try:
        with patch.object(base,'Config',lambda:config):
            corrected.run()
    finally:
        random.setstate(saved_random)
    assert corrected.actual==expected
    assert corrected.after_startup_state_matches_saved
    return dict(seed=seed,committed_selection_rounds=prior,expected_next=expected,
                actual_next=s.actual,restored_state_survives_startup=False,
                example_local_start_hook_result=corrected.actual,
                boundary='actual base.Server.run -> start -> strategy selection',
                limitations='No sockets, model training, or checkpoint serialization in this startup-order probe.')


def author_cloud_check():
    import numpy as np
    tree=ast.parse((SCRATCH/'utils_methods.py').read_text())
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='train_FedDyn')
    wanted={296,297,387,393,396,397}
    nodes=sorted([n for n in ast.walk(fn) if isinstance(n,(ast.Assign,ast.AugAssign))
                  and n.lineno in wanted],key=lambda n:n.lineno)
    assert [n.lineno for n in nodes]==sorted(wanted)
    counts=[1,3]
    env=dict(np=np,n_clnt=2,clnt_y=[np.zeros(n) for n in counts],alpha_coef=.1,
             clnt=0,curr_model_par=np.array([1.624]),cld_mdl_param=np.array([2.]),
             local_param_list=np.zeros((2,1)),clnt_params_list=np.array([[1.624],[2.]]),
             selected_clnts=[0])
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(SCRATCH/'utils_methods.py'),'exec'),env)
    assert np.array_equal(env['weight_list'],[.5,1.5])
    assert env['alpha_coef_adpt']==.2
    assert abs(env['cld_mdl_param'].item()-1.436)<1e-15
    return dict(executed_pinned_statement_lines=sorted(wanted),
                normalized_counts=env['weight_list'].tolist(),alpha1=env['alpha_coef_adpt'],
                selected_mean=env['avg_mdl_param'].item(),
                population_history=env['local_param_list'].reshape(-1).tolist(),
                cloud=env['cld_mdl_param'].item())


def legacy_writer_check():
    import copy
    import logging
    import subprocess
    import tempfile
    from typing import Any
    import torch
    from plato.trainers.strategies.base import ModelUpdateStrategy,TrainingContext
    from plato.trainers.strategies.algorithms.feddyn_strategy import FedDynUpdateStrategy
    src=subprocess.run(['git','show',
        '00eeb9dcdd2b513e64db9408969356037e09bb8e:plato/trainers/strategies/algorithms/feddyn_strategy.py'],
        cwd=SNAPSHOT,check=True,capture_output=True).stdout
    (SCRATCH/'accepted-b-feddyn_strategy.py').write_bytes(src)
    tree=ast.parse(src)
    node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='FedDynUpdateStrategy')
    result=[]
    for custom in (False,True):
        fixture=Path(tempfile.mkdtemp(prefix=f'legacy-{sys.version_info.minor}-',dir=SCRATCH))
        root=fixture/('custom root' if custom else 'models')
        root.mkdir()
        env=dict(torch=torch,copy=copy,logging=logging,os=os,Any=Any,
                 TrainingContext=TrainingContext,ModelUpdateStrategy=ModelUpdateStrategy,
                 Config=lambda:SimpleNamespace(params={'model_path':str(root)}))
        exec(compile(ast.Module(body=[node],type_ignores=[]),str(SCRATCH/'accepted-b-feddyn_strategy.py'),'exec'),env)
        model=torch.nn.Linear(1,1,dtype=torch.float64)
        with torch.no_grad():model.weight.zero_();model.bias.zero_()
        ctx=TrainingContext();ctx.model=model;ctx.client_id=1
        old=env['FedDynUpdateStrategy'](save_path=str(root) if custom else None)
        old.setup(ctx);old.on_train_start(ctx)
        with torch.no_grad():model.weight.fill_(7);model.bias.fill_(8)
        old.on_train_end(ctx)
        path=Path(old.grad_vector_path)
        assert str(path)==str(root)+'_feddyn_grad_1.pth'
        before=path.read_bytes();v=torch.load(path,map_location='cpu',weights_only=True)
        assert v['weight'].item()==7 and v['bias'].item()==8
        # Current immutable snapshot's incorrect filename is corroborating historical red evidence.
        from plato.config import Config
        with patch.dict(Config().params,model_path=str(root)):
            new=FedDynUpdateStrategy(save_path=str(root) if custom else None)
            new.setup(ctx);new.on_train_start(ctx)
        assert new.cumulative_grad_vector['weight'].item()==0
        assert path.read_bytes()==before
        result.append(dict(custom_root=custom,path=str(path),weight=v['weight'].item(),
                           bias=v['bias'].item(),original_preserved=True,
                           snapshot_reader_weight=new.cumulative_grad_vector['weight'].item(),
                           fixture_sha256=hashlib.sha256(before).hexdigest()))
    return dict(commit='00eeb9dcdd2b513e64db9408969356037e09bb8e',
                source_sha256=hashlib.sha256(src).hexdigest(),fixtures=result,
                scope='Actual old writer and current pinned reader; proposed explicit migration reader does not yet exist.')


def main():
    # Config and any import-time directories stay in reviewer scratch.
    config = SCRATCH/'probe-config.toml'
    config.write_text((SNAPSHOT/'examples/customized_client_training/feddyn/feddyn_MNIST_lenet5.toml').read_text())
    os.environ['config_file']=str(config)
    sys.argv=[sys.argv[0],'-b',str(SCRATCH/'runtime'),'--cpu']
    results=dict(rational=rational_checks(),torch=torch_checks(),author_cloud=author_cloud_check(),
                 startup_rng=startup_rng_check(),legacy_writer=legacy_writer_check())
    print(json.dumps(results,indent=2))


if __name__ == '__main__':
    main()
