from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
from pathlib import Path
import shlex
import subprocess

OUT = Path('/tmp/plato-phase2-final-prose-review')
REPORT_ROOT = Path('/Users/bli/Playground/plato/evidence/2026-refresh')
DOC_ROOT = Path('/private/tmp/plato-refresh-worktrees/algorithm-docs-final-review')
CI_ROOT = Path('/private/tmp/plato-refresh-worktrees/phase2-ci-budget-review')
docs = json.loads((OUT/'docs-checks.json').read_text())
ci = json.loads((OUT/'ci-checks.json').read_text())
primary = json.loads((OUT/'primary-inputs.json').read_text())

def receipt(path):
    p=Path(path)
    return dict(path=str(p),bytes=p.stat().st_size,
                sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def shell(args,cwd):
    command=shlex.join(args)
    r=subprocess.run(['zsh','-lc',command],cwd=cwd,capture_output=True,timeout=60)
    return dict(command='zsh -lc '+shlex.quote(command),cwd=str(cwd),
                exit_code=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode())

def audit(topic,doc_locations,source_locations,result):
    return dict(topic=topic,doc_locations=doc_locations,
                source_locations=source_locations,result='PASS',assessment=result)

source_audit=[
 audit('FedDyn objective, history sign, fixed population cloud correction',
       ['examples/customized_client_training/feddyn/README.md:34','docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md:137'],
       ['plato/trainers/strategies/algorithms/feddyn_strategy.py:384','plato/trainers/strategies/algorithms/feddyn_strategy.py:544','examples/customized_client_training/feddyn/feddyn_server.py:277'],
       'J=F+alpha_i<h_i,w>+alpha_i/2||w-x||^2; gradient=grad F+alpha_i(w-x+h_i); h_i+=y_i-x once per accepted endpoint; cloud=mean(selected y)+sum(all updated h)/N. Inactive histories persist. Exact source agrees with both documents and pinned author displacement formulation; finite local SGD is not an exact local minimizer or convergence proof.'),
 audit('FedDyn coefficient modes, count provenance, defaults and zero alpha',
       ['examples/customized_client_training/feddyn/README.md:59','docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md:151'],
       ['plato/trainers/strategies/algorithms/feddyn_strategy.py:67','plato/trainers/strategies/algorithms/feddyn_strategy.py:79','plato/trainers/strategies/algorithms/feddyn_strategy.py:391','examples/customized_client_training/feddyn/feddyn_trainer.py:63'],
       'Uniform default has alpha_i=alpha and forbids a count vector. Sample alpha_i=alpha*sum(n)/(N*n_i) uses complete positive realized partition counts. Neither selected model mean nor population history mean is sample-weighted. alpha_coef precedes feddyn_alpha then .01; local alpha0 returns task loss while the full example rejects alpha0. Loader cardinality/declaration/drop_last checks and accepted uniform-count caching agree with prose.'),
 audit('FedDyn finite plain-SGD training, schema and accumulation boundary',
       ['examples/customized_client_training/feddyn/README.md:90','docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md:172'],
       ['plato/trainers/strategies/algorithms/feddyn_strategy.py:79','plato/trainers/strategies/algorithms/feddyn_strategy.py:157','plato/trainers/strategies/algorithms/feddyn_strategy.py:243','plato/trainers/strategies/algorithms/feddyn_strategy.py:498','examples/customized_client_training/feddyn/feddyn_trainer.py:212','plato/trainers/strategies/training_step.py:77'],
       'Dense finite float32/64, nonempty fixed trainables, no shared aliases, static nontrainables, exact optimizer ownership, actual fixed positive SGD LR and forbidden optimizer/config modes are source-backed. The normal accumulation window averages microbatch means; the tail rescales by actual microbatch count. Zero completed updates fail. Reviewed qualification remains CPU; no GPU or benchmark qualification is inferred.'),
 audit('FedDyn authoritative server, worker reuse and fallible parent acceptance',
       ['examples/customized_client_training/feddyn/README.md:109','docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md:180'],
       ['examples/customized_client_training/feddyn/feddyn_client.py:29','examples/customized_client_training/feddyn/feddyn_client.py:56','examples/customized_client_training/feddyn/feddyn_trainer.py:134','plato/trainers/strategies/algorithms/feddyn_strategy.py:439','plato/trainers/strategies/algorithms/feddyn_strategy.py:588','plato/trainers/composable.py:408','plato/trainers/composable.py:826'],
       'Dedicated client binds assignment header to full dispatch; direct/worker results are provisional and server histories remain authoritative. Parent verifies current endpoint/history/count/step handoff before outbound eligibility; changed logical IDs clear transient history, and no live history file is written.'),
 audit('Server aggregation callbacks versus postcommit evaluation',
       ['examples/customized_client_training/feddyn/README.md:116','examples/customized_client_training/scaffold/README.md:91','docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md:49','docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md:184'],
       ['examples/customized_client_training/feddyn/feddyn_server.py:325','examples/customized_client_training/scaffold/scaffold_server.py:122','plato/servers/fedavg.py:181'],
       'Whole-batch validation and validation of values actually used after receive callbacks precede aggregation. Both wrappers roll back owned model/control or model/history state on failure before successful aggregation callbacks/final guard, then retain the committed aggregation on later evaluation/report failure. External side effects are explicitly excluded.'),
 audit('FedDyn saved committed-round bundle and actual run/--resume ordering',
       ['examples/customized_client_training/feddyn/README.md:123','docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md:189'],
       ['examples/customized_client_training/feddyn/feddyn_server.py:477','examples/customized_client_training/feddyn/feddyn_server.py:509','examples/customized_client_training/feddyn/feddyn_server.py:571','examples/customized_client_training/feddyn/feddyn_server.py:647','examples/customized_client_training/feddyn/feddyn_server.py:676','plato/servers/base.py:346','plato/servers/base.py:1674'],
       'The canonical shipped bundle is base/models/feddyn/mnist/feddyn_lenet5.pth. Atomic replacement publishes the captured committed model/all histories/counts/settings/schema/run/round/token ledger and separate Python-global, owned/context selector, NumPy-global and default Torch-CPU RNG states. Resume validates before installation and start consumes pending RNG once before inherited listener/registration. trainer.rounds is the total target; unsaved commits, model-only files, inflight attempts, optimizer/GPU/external state are not durable continuation claims. This review parsed CLI options and read source; it did not execute training/resume.'),
 audit('FedDyn explicit read-only legacy reader and model-only fresh warm start',
       ['examples/customized_client_training/feddyn/README.md:152','docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md:200'],
       ['plato/trainers/strategies/algorithms/feddyn_strategy.py:456','plato/trainers/strategies/algorithms/feddyn_strategy.py:662','examples/customized_client_training/feddyn/feddyn_server.py:93'],
       'read_legacy_history(context) prefers contained feddyn_grad_ID.pth then exact root+_feddyn_grad_ID.pth, excludes client0 substitution, validates finite exact shape/dtype plus recognized frozen extras, and never adopts or rewrites. save_path rejects live training. warm_start_model(weights) after initialization resets UUID/round/history/count/token records; no CLI flag or implicit old-trajectory compatibility is claimed.'),
 audit('SCAFFOLD signs, corrected Option II/V2 and real K/LR accounting',
       ['examples/customized_client_training/scaffold/README.md:24','docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md:25'],
       ['plato/trainers/strategies/algorithms/scaffold_strategy.py:186','plato/trainers/strategies/algorithms/scaffold_strategy.py:258','plato/trainers/strategies/algorithms/scaffold_strategy.py:282','plato/trainers/strategies/algorithms/scaffold_strategy.py:415','plato/trainers/strategies/training_step.py:169'],
       'Local correction -eta(c-ci), ci_new=ci-c+(x-y)/(K*eta), and delta=new-old match main Algorithm1/Eqs3-5. V2 inherits corrected OptionII; no extra OptionI pass exists. Actual optimizer pre-hook captures a common finite positive rate, rejects unequal/changed rates before the affected step, and captures completed updates including the normalized tail. K0 retains ci and emits fresh zero delta; included no-gradient parameters receive correction and excluded/frozen/buffer state does not.'),
 audit('SCAFFOLD direct successful cleanup and deferred child/parent ordering',
       ['examples/customized_client_training/scaffold/README.md:64','docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md:73'],
       ['plato/trainers/composable.py:408','plato/trainers/composable.py:450','plato/trainers/composable.py:826','plato/trainers/strategies/algorithms/scaffold_strategy.py:311','plato/trainers/strategies/algorithms/scaffold_strategy.py:341'],
       'Callbacks, training-step end and successful model-update cleanup all precede direct acceptance. Deferred child cleanup retains provisional state, followed by saved model/state export and parent token/client/model/control loading before canonical persistence. train_model rejects its own failed stage; train_process rejects only later failed handoff stages. Failed end/cleanup/handoff cannot emit an accepted delta. Docs do not overclaim full model rollback for every client-side SCAFFOLD failure.'),
 audit('SCAFFOLD model/control aggregation and non-plain-SGD qualification',
       ['examples/customized_client_training/scaffold/README.md:75','docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md:40'],
       ['examples/customized_client_training/scaffold/scaffold_server.py:70','plato/servers/strategies/aggregation/fedavg.py','plato/trainers/strategies/algorithms/scaffold_strategy.py:199'],
       'Control=sum(delta_ci)/clients.total_clients; positive-total model aggregation retains inherited sample weights. Momentum .9 and other actual optimizers use the additive post-update extension within LR constraints. Unequal-count model averaging and non-vanilla optimizers are explicitly separated from the paper equivalence/convergence guarantee.'),
 audit('SCAFFOLD canonical/legacy paths, logical clients and restart caveat',
       ['examples/customized_client_training/scaffold/README.md:99','docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md:57'],
       ['plato/trainers/strategies/algorithms/scaffold_strategy.py:32','plato/trainers/strategies/algorithms/scaffold_strategy.py:105','examples/customized_client_training/scaffold/scaffold_callback.py:27'],
       'Strategy owns ci, exact contained canonical filename wins, legacy model_name_ID_control_variate.pth then concatenated root+scaffold_cv_ID.pkl are same-client only, malformed canonical state does not fall back, and known frozen/buffer extras are ignored. Current inbound processor replaces server controls. Old structurally loadable controls change trajectory and do not constitute coordinated server/optimizer/RNG/privacy restart.'),
 audit('Entrypoints, shipped values, pinned attribution and historical preservation',
       ['examples/customized_client_training/feddyn/README.md:10','examples/customized_client_training/scaffold/README.md:8'],
       ['examples/customized_client_training/feddyn/feddyn.py:16','examples/customized_client_training/scaffold/scaffold.py','examples/customized_client_training/feddyn/feddyn_MNIST_lenet5.toml','examples/customized_client_training/scaffold/scaffold_MNIST_lenet5.toml'],
       'Commands resolve from repository root or stated examples directory. FedDyn 1000/10/20/3, .01 alpha/.03LR, zero momentum/decay and concurrency3; SCAFFOLD5/2/3/5, .01LR/.9momentum/0decay and concurrency2 agree. Primary paper links and pinned author function spans resolve and support the cited equations/clipping distinction. All other public sections, including accepted legacy unsquared FedProx claims, remain unchanged and outside this verdict.')
]

extra_sources = ['plato/servers/fedavg.py','plato/servers/strategies/aggregation/fedavg.py',
                 'plato/trainers/strategies/training_step.py','plato/utils/checkpoint_paths.py',
                 'plato/trainers/strategies/algorithms/__init__.py']
for path in extra_sources:
    docs['sources'][path]=receipt(DOC_ROOT/path)
commands=docs['commands']
for family in ('feddyn','scaffold'):
    log=OUT/(family+'-uv-help.log')
    assert '--resume' in log.read_text() and '--cpu' in log.read_text()
    command=('PYTHONDONTWRITEBYTECODE=1 PYTHONPATH='+str(DOC_ROOT)+
             ' UV_PROJECT_ENVIRONMENT=/tmp/plato-phase2c-313 UV_CACHE_DIR='+str(OUT/'uv-cache')+
             ' XDG_CACHE_HOME='+str(OUT/'cache')+' TMPDIR='+str(OUT)+
             ' uv run --no-sync --offline python examples/customized_client_training/'+family+'/'+family+'.py --help')
    commands.append(dict(command='zsh -lc '+shlex.quote(command),cwd=str(DOC_ROOT),exit_code=0,log=str(log),sha256=receipt(log)['sha256']))
clean = []
for root in [DOC_ROOT,CI_ROOT]:
    item=shell(['git','status','--porcelain'],root)
    assert item['exit_code']==0 and not item['stdout'] and not item['stderr']
    clean.append(item)
now=datetime.now(timezone.utc).isoformat()
shared=dict(schema_version=1,written_at_utc=now,
            reviewer_role='Fresh independent Sol xhigh bounded review requested by root; no nested agents.',
            authority='Current user assignment and root AGENTS.md; accepted design records authorize implementation and do not themselves qualify it.',
            constraints_observed=dict(shell='zsh -lc for every shell invocation',
                writes='Only assigned /tmp/plato-phase2-final-prose-review scratch and the two assigned root JSON reports.',
                nested_agents=False,package_installs=False,training_runs=False,pytest_suites=False,
                candidate_edits=False,commits=False,pushes=False,cleanup=False))
doc_report=dict(**shared,verdict='PASS',
    verdict_scope='Writing/source reconciliation for the three owned documents at the exact candidate only. Not a whole-C implementation, numerical, convergence, phasegate, or hosted-CI verdict.',
    candidate=dict(root=str(DOC_ROOT),commit='69d7d8a7841589205283f13f0e07771fb1e325bd',tree='4844a34cf5eb3c0366d5904810932a337bd45293',
                   source_commit='13e38dafce476286db7e673e7f21343d54416b56',source_tree='9fe8cfb039d0d97fc5b2c95a459de4c73c6d1b51',
                   dependency_merge='448e3e75198dc330ecfd3709ae28b57f83f69203',nanochat_gitlink='c75fe54aa7c1fa881701c246f9427bcbe4eee5a4'),
    scope_verification=docs['scope'],candidate_file_receipts=docs['documents'],
    accepted_and_primary_inputs=primary,writer_inputs_independently_hashed=docs['inputs'],source_receipts=docs['sources'],
    manual_source_reconciliation=source_audit,material_findings=[],
    low_priority_suggestions=[
      dict(id='DOC-L01',severity='LOW',candidate_owned=True,path='examples/customized_client_training/feddyn/README.md',line=94,
           additional_location='docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md:172',
           observation='The support paragraph enumerates dtype/optimizer requirements but does not explicitly say the qualification is CPU. The run command already uses --cpu and the resume caveat excludes GPU RNG.',
           practical_effect='A reader skimming only this paragraph could mistake device-neutral conditions for executed GPU qualification.',
           suggestion='State CPU float32/float64 qualification explicitly in both support paragraphs; do not imply that the implementation rejects every GPU execution or add a GPU feature.'),
      dict(id='DOC-L02',severity='LOW',candidate_owned=False,path='plato/trainers/strategies/algorithms/__init__.py',line=15,
           observation='The unchanged package overview still calls SCAFFOLDUpdateStrategyV2 an Alternative implementation (Option 1).',
           source_authority='plato/trainers/strategies/algorithms/scaffold_strategy.py:415 makes it a compatibility subclass of corrected Option II, matching both candidate documents.',
           practical_effect='API-module readers may select V2 expecting an additional gradient pass that does not exist.',
           suggestion='Root should reconcile this source docstring through its separate C/source review ownership. It was preserved as required and does not block the bounded owned-document writing PASS.')],
    verification=dict(commands=commands,script=docs['script'],script_execution=dict(
         command='zsh -lc '+shlex.quote('PYTHONDONTWRITEBYTECODE=1 /tmp/plato-phase2c-scaffold-docs/final-13e/venv/bin/python -B '+str(OUT/'review_checks.py')+' > '+str(OUT/'review-checks.log')+' 2>&1'),
         exit_code=0,log=receipt(OUT/'review-checks.log')),
         environment=dict(runtime_python='/tmp/plato-phase2c-313/bin/python',docs_python='/tmp/plato-phase2c-scaffold-docs/final-13e/venv/bin/python',
                          python='3.13.16',mkdocs=importlib.metadata.version('mkdocs'),markdown=importlib.metadata.version('Markdown'),
                          use='Read-only preexisting environments; caches/output/base paths redirected to assigned scratch. uv help used --no-sync --offline.'),
         strict_mkdocs=dict(**docs['builds'],strict_build_pass_claimed=False,no_new_warnings=True,
                            disposition='Both strict exits are 1 from identical two known Nanochat relative links reserved to Phase5; no new in-scope finding. Existing Material dependency banner also occurs in both.'),
         normal_candidate_build='exit0 with the same baseline warnings; HTML inspected',
         markdown_render=[{k:v for k,v in entry.items() if k!='math'} for entry in docs['rendered']],
         published_html=receipt(OUT/'published-html-inspection.json'),
         rendering_limit='Inspected generated HTML, arithmatex delimiters/equations, admonitions, code blocks, primary links and KaTeX script wiring. No live browser/CDN/KaTeX execution or screenshot validation of the documentation is claimed.',
         primary_links=[dict(url='https://arxiv.org/pdf/1910.06378v4',result='Primary version read; main Algorithm1/Eqs3-5 and conflicting appendix Eq19 verified'),
                        dict(url='https://arxiv.org/pdf/2111.04263v1',result='Primary version read; Algorithm1 sign/population correction mapped to displacement history'),
                        dict(url='https://github.com/alpemreacar/FedDyn/blob/48a19fac440ef079ce563da8e0c2896f8256fef9/utils_methods.py#L286-L402',result='Resolved primary link; retained source hash and function span checked'),
                        dict(url='https://github.com/alpemreacar/FedDyn/blob/48a19fac440ef079ce563da8e0c2896f8256fef9/utils_general.py#L185-L227',result='Resolved primary link; retained source hash and loss/clipping/decay span checked')]),
    historical_evidence=dict(path='evidence/2026-refresh/phase2c-scaffold-docs-validation.json',
         sha256='6356985643631f85ed95baed0f1af53a31016c9afff9f9f3f1ad8999f4ea3004',
         unchanged_from='eed4bfa23edc37cf41b598fc976b281e141756c4',
         authority='Historical earlier-source receipts, not current pending-execution or production qualification assertions; new source-bound report controls current reconciliation.'),
    source_bound_revalidation_required_if_code_changes=[
         'Recheck equation signs, weighting/population denominators, trainable scope, counts and supported optimizer/dtype/state contracts against new exact source hashes.',
         'Recheck composable end/cleanup/direct acceptance and deferred child/save/handoff/parent persistence ordering, plus server receive/aggregation callback versus postcommit evaluation boundaries.',
         'Recheck bundle contents/path/config validation, separate selection/global RNGs, actual run/start/--resume handoff, legacy reader and warm-start APIs.',
         'If a source correction changes a public claim, update owned prose through its author and repeat scope/render/CLI/MkDocs differential checks. Numerical code changes require root numerical/failure-path review and merged profiles/hosted CI separately.'],
    limits=['No independent numerical/training/pytest qualification was executed in this writing task; source inspection and receipt integrity cannot replace root code review.',
            'No native GPU, inflight replay, arbitrary external-state restart, convergence, MNIST accuracy or benchmark claim accepted.',
            'Whole C/Phase2 acceptance, full merged profiles, exact-source Linux hosted CI, publication and cleanup remain root-owned.'],
    final_candidate_clean_checks=clean)

ci_report=dict(**shared,verdict='PASS',
    verdict_scope='Finite timeout metadata and measured rationale only; not a hosted Linux CI pass, large-suite rerun, implementation acceptance, or Phase2 closure.',
    candidate=dict(root=str(CI_ROOT),commit='8d27c5c7a205299537a2835358f1d5e91a7b51c3',tree='fa85f0b6ddc104e4fd1a2bd11a17c32619a1cc8a',
                   base_commit='13e38dafce476286db7e673e7f21343d54416b56',base_tree='9fe8cfb039d0d97fc5b2c95a459de4c73c6d1b51'),
    scope=dict(changed_files=ci['changed_files'],nonowned_unchanged=ci['nonowned_unchanged'],
               workflow_preserved_byte_for_byte_except_four_timeout_values=ci['byte_preservation_except_timeout_values']),
    candidate_workflow_receipt=ci['workflow_after'],baseline_workflow_sha256=ci['workflow_before_sha256'],validation_evidence=ci['evidence'],
    inputs=ci['inputs'],material_findings=[],low_priority_suggestions=[],
    exact_timeout_changes=[dict(**change,line=line) for change,line in zip(ci['semantic_changes'],[16,83,109,118])],
    preserved_contract='Every command, marker/profile/collection/missing-extra guard, tests, failure handling, coverage output, lint/typing guard, Python3.13/3.14 matrix, Ubuntu24.04 runner, max-parallel2/fail-fast=false, action SHA/version pins, contents:read permissions, environment, recursive submodules and artifact if:always()/retention behavior is unchanged. No modernization or timeout removal.',
    source_attribution=ci['source_attribution'],measurements=ci['measurements'],step_planning=ci['planning'],job_budget=ci['job_budget'],
    rationale_review=dict(result='PASS',
        non_runtime='Four actual author pytest durations 760.02/763.02/833.90/835.52s exceed old720s; command wall765.37/769.57/839.61/842.55s. Both base and mandatory steps now20min.',
        runtime='51 cases per Python, pytest659.89/680.58s and wall668.16/689.38s leave only51.84/30.62s below720. The finite16min budget adds reasonable planning margin. No runtime timeout failure was invented.',
        budget='Verified 1.25*slowest wall plus120s for each non-runtime step and60s for runtime, rounded up to20/20/16min. Mandatory measurement omitted hosted coverage, and base includes collection/missing-extra work; these chosen overhead reserves are transparently planning assumptions.',
        whole_job='All existing stages accounted for: explicit limits total84min (zsh3+provenance2+base sync10+base tests20+mandatory sync10+mandatory tests20+runtime16+lint/typing3), plus6min planning reserve for checkout2/Python setup2/uv setup1/artifact upload1 = job90min per matrix job. It is a finite envelope, not a guaranteed hosted duration.'),
    verification=dict(parser=ci['parser'],script=ci['script'],
        command='zsh -lc '+shlex.quote('PYTHONDONTWRITEBYTECODE=1 /tmp/plato-phase2c-313/bin/python -B '+str(OUT/'ci_checks.py')+' > '+str(OUT/'ci-checks.log')+' 2>&1'),
        exit_code=0,log=receipt(OUT/'ci-checks.log'),
        checks=['Git exact candidate commit/tree and clean status; exact two-file diff and all nonowned bytes preserved.',
                'PyYAML6.0.3 parser preserves literal on, true/false booleans and rejects duplicate mapping keys; all three triggers and false semantics retained.',
                'Exactly four expected semantic changes, all finite positive integers; textual diff identical after masking timeout values.',
                '18 selected raw log/wall/JUnit receipt hashes and sizes independently verified; summaries/pytest durations, successful exits, source heads and JUnit counts/failures agree.',
                'Non-runtime implementation7d310b source/tests/configs equal base13e; runtime05a9 source/integration/configs equal base except later unrelated personalized-state test isolation. Receipts retain their actual older execution identities.',
                'All measured step planning arithmetic and every whole-job stage allowance independently checked.',
                'git diff --check 13e38dafce476286db7e673e7f21343d54416b56 HEAD exits0.']),
    hosted_linux_ci_pass_claimed=False,
    limits=['Timings are retained author macOS-arm64 measurements, independently inspected and hashed, not reviewer execution or Ubuntu runner qualification.',
            'No packages installed, duplicate large suite run, invented failing CI run or hosted workflow dispatch was performed.',
            'Root must run full merged profiles and exact-source Linux hosted CI before acceptance/publication. If tests/profiles/coverage/actions or measured source change, recheck the finite budgets against fresh timings and retain all existing guards.'],
    final_candidate_clean_checks=clean)
for name,report in [('phase2c-algorithm-docs-review.json',doc_report),('phase2-ci-budget-review.json',ci_report)]:
    target=REPORT_ROOT/name
    assert not target.exists(), 'Assigned report already exists: '+str(target)
    target.write_text(json.dumps(report,indent=2)+'\n')
    assert json.loads(target.read_text())['verdict']=='PASS'
    print(json.dumps(receipt(target)))
(OUT/'report-receipts.json').write_text(json.dumps([
    receipt(REPORT_ROOT/'phase2c-algorithm-docs-review.json'),
    receipt(REPORT_ROOT/'phase2-ci-budget-review.json')],indent=2)+'\n')
