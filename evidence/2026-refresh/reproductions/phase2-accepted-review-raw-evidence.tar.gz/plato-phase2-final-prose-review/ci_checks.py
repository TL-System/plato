import copy
import hashlib
import json
import math
from pathlib import Path
import re
import shlex
import subprocess
import xml.etree.ElementTree as ET

import yaml

ROOT = Path('/private/tmp/plato-refresh-worktrees/phase2-ci-budget-review')
OUT = Path('/tmp/plato-phase2-final-prose-review')
BASE = '13e38dafce476286db7e673e7f21343d54416b56'
PATH = '.github/workflows/pytorch_tests.yml'

def git(*args):
    r = subprocess.run(['zsh','-lc',shlex.join(['git',*args])],cwd=ROOT,
                       capture_output=True,timeout=60)
    assert r.returncode == 0, r.stderr
    return r.stdout

def sha(data):
    return hashlib.sha256(data).hexdigest()

def receipt(path):
    p = Path(path)
    return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes()))

class GithubLoader(yaml.SafeLoader):
    pass

GithubLoader.yaml_implicit_resolvers = copy.deepcopy(yaml.SafeLoader.yaml_implicit_resolvers)
for letter, resolvers in GithubLoader.yaml_implicit_resolvers.items():
    GithubLoader.yaml_implicit_resolvers[letter] = [
        (tag, pattern) for tag,pattern in resolvers if tag != 'tag:yaml.org,2002:bool']
GithubLoader.add_implicit_resolver('tag:yaml.org,2002:bool',
    re.compile(r'^(?:true|false)$',re.I),list('tTfF'))
def mapping(loader,node,deep=False):
    result = {}
    for key_node,value_node in node.value:
        key = loader.construct_object(key_node,deep=deep)
        if key in result:
            raise ValueError('Duplicate YAML mapping key: '+str(key))
        result[key] = loader.construct_object(value_node,deep=deep)
    return result
GithubLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,mapping)

before_bytes = git('show',BASE+':'+PATH)
after_bytes = (ROOT/PATH).read_bytes()
before = yaml.load(before_bytes,Loader=GithubLoader)
after = yaml.load(after_bytes,Loader=GithubLoader)
assert 'on' in after and True not in after
assert after['on'] == before['on'] and set(after['on']) == {'push','pull_request','workflow_dispatch'}
assert after['jobs']['PyTorch-Tests']['strategy']['fail-fast'] is False
assert after['jobs']['PyTorch-Tests']['steps'][0]['with']['persist-credentials'] is False
changes = []
def compare(a,b,path=()):
    assert type(a) is type(b), path
    if isinstance(a,dict):
        assert a.keys() == b.keys(),path
        for key in a: compare(a[key],b[key],path+(key,))
    elif isinstance(a,list):
        assert len(a)==len(b),path
        for index,(x,y) in enumerate(zip(a,b)): compare(x,y,path+(index,))
    elif a != b:
        changes.append(dict(path=list(path),old=a,new=b))
compare(before,after)
evidence = json.loads((ROOT/'evidence/2026-refresh/phase2-ci-budget-validation.json').read_text())
assert changes == evidence['timeout_changes'],changes
expected = [('jobs','PyTorch-Tests','timeout-minutes',45,90),
            ('jobs','PyTorch-Tests','steps',6,'timeout-minutes',12,20),
            ('jobs','PyTorch-Tests','steps',8,'timeout-minutes',12,20),
            ('jobs','PyTorch-Tests','steps',9,'timeout-minutes',12,16)]
assert [tuple(c['path'])+(c['old'],c['new']) for c in changes] == expected
mask = lambda x: re.sub(rb'(?m)^(\s*timeout-minutes:) \d+$',rb'\1 TIMEOUT',x)
assert mask(before_bytes)==mask(after_bytes)
assert sha(before_bytes)==evidence['source']['workflow']['before']['sha256']
assert sha(after_bytes)==evidence['source']['workflow']['after']['sha256']
assert git('rev-parse','HEAD','HEAD^{tree}').decode().splitlines()==[
    '8d27c5c7a205299537a2835358f1d5e91a7b51c3','fa85f0b6ddc104e4fd1a2bd11a17c32619a1cc8a']
assert git('status','--porcelain') == b''
changed_files = git('diff','--name-only',BASE,'HEAD').decode().splitlines()
assert set(changed_files)=={PATH,'evidence/2026-refresh/phase2-ci-budget-validation.json'}
assert not git('diff',BASE,'HEAD','--','.',':(exclude)'+PATH,
               ':(exclude)evidence/2026-refresh/phase2-ci-budget-validation.json')
assert not git('diff','7d310b90d698a7be4aa9a184dc415f7dbb401e5b',BASE,
               '--','.',':(exclude)evidence')
runtime_diff=git('diff','--name-only','05a9f00b8a4d54c233c1a9c00ef9ce2c4467480c',BASE).decode().splitlines()
assert [x for x in runtime_diff if not x.startswith('evidence/')]==[
    'tests/trainers/test_personalized_state_ownership.py']

inputs=[]
for key,item in evidence['inputs'].items():
    p=Path(item['path'])
    if not p.is_absolute(): p=ROOT/p
    obs=receipt(p)
    assert obs['sha256']==item['sha256'],p
    inputs.append(obs)
measurements=[]
for item in evidence['measurements']:
    receipts=[]
    for label,expected_receipt in item['raw_receipts'].items():
        observed=receipt(expected_receipt['path'])
        assert observed['bytes']==expected_receipt['bytes']
        assert observed['sha256']==expected_receipt['sha256']
        receipts.append(dict(kind=label,**observed))
    wall=json.loads(Path(item['raw_receipts']['wall_report']['path']).read_text())
    log=Path(item['raw_receipts']['log']['path']).read_text()
    assert wall['head']==item['executed_commit']
    assert wall['exit_code']==0 and wall['seconds']==item['command_wall_seconds']
    assert wall['summary']==item['summary'] and item['summary'] in log
    assert wall['shell']=='zsh -lc' and wall['profile']==item['profile']
    assert wall['partition']==item['partition']
    junit=ET.parse(item['raw_receipts']['junit']['path']).getroot()
    suites=list(junit.iter('testsuite'))
    assert sum(int(s.attrib['tests']) for s in suites)==item['cases']
    assert sum(int(s.attrib['failures'])+int(s.attrib['errors']) for s in suites)==0
    assert item['pytest_seconds']==float(re.search(r' in ([\d.]+)s',item['summary'])[1])
    measurements.append(dict(python=item['python'],profile=item['profile'],partition=item['partition'],
                             executed_commit=item['executed_commit'],pytest_seconds=item['pytest_seconds'],
                             wall_seconds=wall['seconds'],old_step_margin_seconds=round(720-wall['seconds'],2),
                             command=wall['command'],receipts=receipts))
for plan in evidence['step_budget_planning']:
    matched=[m for m in measurements if m['profile']==plan['profile'] and m['partition']==plan['partition']]
    slowest=max(m['wall_seconds'] for m in matched)
    assert slowest==plan['slowest_measured_command_wall_seconds']
    seconds=slowest*plan['runner_variance_multiplier']+plan['additional_workflow_overhead_allowance_seconds']
    assert round(seconds,2)==plan['planning_seconds']
    assert math.ceil(seconds/60)==plan['new_timeout_minutes']
job=after['jobs']['PyTorch-Tests']
limits=[s['timeout-minutes'] for s in job['steps'] if 'timeout-minutes' in s]
assert all(type(x) is int and 0<x<=360 for x in limits+[job['timeout-minutes']])
assert sum(limits)==84 and job['timeout-minutes']==90
stages=evidence['job_budget_planning']['stages_in_execution_order']
assert [s['step'] for s in stages]==[s['name'] for s in job['steps']]
assert all(s['explicit_timeout_minutes']==step.get('timeout-minutes') for s,step in zip(stages,job['steps']))
assert sum(s['job_planning_allowance_minutes'] for s in stages)==90
assert sum(s['job_planning_allowance_minutes'] for s in stages if s['explicit_timeout_minutes'] is None)==6
assert not git('diff','--check',BASE,'HEAD')
data=dict(script=receipt(__file__),parser=dict(name='PyYAML',version=yaml.__version__,
          loader='SafeLoader with copied true/false-only bool resolution and duplicate-key rejection'),
          changed_files=changed_files,semantic_changes=changes,
          byte_preservation_except_timeout_values=True,nonowned_unchanged=True,
          workflow_before_sha256=sha(before_bytes),workflow_after=receipt(ROOT/PATH),
          evidence=receipt(ROOT/'evidence/2026-refresh/phase2-ci-budget-validation.json'),
          inputs=inputs,measurements=measurements,planning=evidence['step_budget_planning'],
          job_budget=dict(explicit_step_minutes=sum(limits),other_action_reserve_minutes=6,job_minutes=90),
          source_attribution=dict(non_runtime_source_exact=True,runtime_only_non_evidence_difference='tests/trainers/test_personalized_state_ownership.py'))
(OUT/'ci-checks.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({k:v for k,v in data.items() if k in ('parser','semantic_changes','byte_preservation_except_timeout_values','nonowned_unchanged','job_budget','source_attribution')},indent=2))
