import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys

import markdown
from bs4 import BeautifulSoup

OUT = Path('/tmp/plato-phase2-final-prose-review')
ROOT = Path('/private/tmp/plato-refresh-worktrees/algorithm-docs-final-review')
BASE = '13e38dafce476286db7e673e7f21343d54416b56'
DOCS_PYTHON = '/tmp/plato-phase2c-scaffold-docs/final-13e/venv/bin/python'
RUNTIME_PYTHON = '/tmp/plato-phase2c-313/bin/python'
records = []
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(OUT),
           MPLCONFIGDIR=str(OUT/'matplotlib'), XDG_CACHE_HOME=str(OUT/'cache'),
           PYTHONPATH=str(ROOT), UV_CACHE_DIR=str(OUT/'uv-cache'))

def run(args, cwd=ROOT, label=None):
    command = shlex.join(map(str, args))
    result = subprocess.run(['zsh', '-lc', command], cwd=cwd, env=env,
                            capture_output=True, timeout=60)
    if label:
        log = OUT/(label+'.log')
        log.write_bytes(result.stdout + result.stderr)
        records.append(dict(command='zsh -lc '+shlex.quote(command), cwd=str(cwd),
                            exit_code=result.returncode, log=str(log),
                            sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
    return result

def git(*args):
    r = run(['git', *args])
    assert r.returncode == 0, r.stderr
    return r.stdout

def tree(commit):
    values = {}
    for item in git('ls-tree', '-r', '-z', commit).split(b'\0'):
        if item:
            metadata, path = item.split(b'\t', 1)
            values[path.decode()] = metadata.decode()
    return values

def receipt(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

page = 'docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md'
owned = {page, 'examples/customized_client_training/feddyn/README.md',
         'examples/customized_client_training/scaffold/README.md',
         'evidence/2026-refresh/phase2c-algorithm-docs-validation.json',
         'evidence/2026-refresh/phase2c-scaffold-docs-validation.json'}
a, b = tree(BASE), tree('HEAD')
changed = sorted(p for p in a.keys() | b.keys() if a.get(p) != b.get(p))
assert set(changed) == owned, changed
assert git('rev-parse', 'HEAD', 'HEAD^{tree}').decode().splitlines() == [
    '69d7d8a7841589205283f13f0e07771fb1e325bd',
    '4844a34cf5eb3c0366d5904810932a337bd45293']
assert git('status', '--porcelain') == b''
assert run(['git','merge-base','--is-ancestor',BASE,'448e3e75198dc330ecfd3709ae28b57f83f69203']).returncode == 0
historical = 'evidence/2026-refresh/phase2c-scaffold-docs-validation.json'
assert git('show', 'eed4bfa23edc37cf41b598fc976b281e141756c4:'+historical) == (ROOT/historical).read_bytes()
def sections(data):
    return {m.group(1):m.group(0) for m in re.finditer(
        r'^### ([^\n]+)\n[\s\S]*?(?=^### |\Z)',data, re.M)}
candidate_sections = sections((ROOT/page).read_text())
preserved = []
for baseline in [BASE,'eed4bfa23edc37cf41b598fc976b281e141756c4']:
    before = sections(git('show', baseline+':'+page).decode())
    assert before.keys() == candidate_sections.keys()
    for name in before.keys()-{'SCAFFOLD','FedDyn'}:
        assert before[name] == candidate_sections[name], name
        preserved.append(dict(baseline=baseline, section=name,
                              sha256=hashlib.sha256(before[name].encode()).hexdigest()))
writer = json.loads((ROOT/'evidence/2026-refresh/phase2c-algorithm-docs-validation.json').read_text())
source_receipts = {}
for path, expected in writer['source_sha256'].items():
    observed = receipt(ROOT/path)
    assert observed['sha256'] == expected, path
    source_receipts[path] = observed
input_receipts = []
for item in writer['inputs']:
    p = Path(item['path'])
    if not p.is_absolute():
        p = ROOT/p
    observed = receipt(p)
    assert observed['sha256'] == item['sha256'], p
    input_receipts.append(observed)
assert receipt(ROOT/'evidence/2026-refresh/phase2c-algorithm-docs-validation.json')['sha256'] == '147a30bbee1451c0ddb0565e48c990488fb5d6e0fda2c9a0c13acbf7cf93205f'

# Export only baseline documentation into the assigned scratch directory.
baseline_root = OUT/'baseline'
for path in a:
    if path.startswith('docs/'):
        target = baseline_root/path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(git('show', BASE+':'+path))
build_results = {}
for name, configuration in [('baseline',baseline_root/'docs/mkdocs.yml'),
                            ('candidate',ROOT/'docs/mkdocs.yml')]:
    r = run([DOCS_PYTHON,'-B','-m','mkdocs','build','--strict','-f',configuration,
             '-d',OUT/(name+'-strict-site')], label='mkdocs-'+name+'-strict')
    warnings = [line.strip() for line in (r.stdout+r.stderr).decode().splitlines()
                if 'WARNING' in line]
    assert r.returncode == 1 and len(warnings) == 2, (name,r.returncode,warnings)
    build_results[name] = dict(exit_code=r.returncode,warnings=warnings)
assert build_results['baseline']['warnings'] == build_results['candidate']['warnings']
r = run([DOCS_PYTHON,'-B','-m','mkdocs','build','-f',ROOT/'docs/mkdocs.yml',
         '-d',OUT/'candidate-site'],label='mkdocs-candidate-nonstrict')
assert r.returncode == 0, r.stderr

rendered = []
for label, text in [('scaffold-readme',(ROOT/'examples/customized_client_training/scaffold/README.md').read_text()),
                    ('feddyn-readme',(ROOT/'examples/customized_client_training/feddyn/README.md').read_text()),
                    ('scaffold-public',candidate_sections['SCAFFOLD']),
                    ('feddyn-public',candidate_sections['FedDyn'])]:
    html = markdown.markdown(text,extensions=['admonition','pymdownx.details',
                            'pymdownx.superfences','pymdownx.arithmatex'],
                            extension_configs={'pymdownx.arithmatex':{'generic':True}})
    (OUT/(label+'.html')).write_text(html)
    soup = BeautifulSoup(html,'html.parser')
    maths = [x.get_text() for x in soup.select('.arithmatex')]
    links = [x['href'] for x in soup.select('a[href]')]
    assert maths and not soup.find_all('a',href=re.compile(r'^\['))
    assert '```' not in html and '$$' not in html
    assert all(re.match(r'https://(?:arxiv.org|github.com)/',link) for link in links), links
    if label.endswith('public'):
        assert soup.select('.admonition.note')
    rendered.append(dict(label=label,html=receipt(OUT/(label+'.html')),
                         math_count=len(maths),math=maths,links=links,
                         code_count=len(soup.select('code'))))

# CLI help and real Config parsing only; no training, model initialization, or resume execution.
probe = OUT/'config_probe.py'
probe.write_text('''import json\nfrom plato.config import Config\nc=Config()\nassert c.args.cpu and c.args.resume\nprint(json.dumps({"config":c.args.config,"base":c.params["base_path"],"model":c.params["model_path"],"checkpoint":c.params["checkpoint_path"],"rounds":c.trainer.rounds,"clients":c.clients.total_clients,"per_round":c.clients.per_round,"optimizer":c.parameters.optimizer._asdict(),"cpu":c.args.cpu,"resume":c.args.resume},indent=2))\nif c.clients.total_clients == 1000:\n from plato.trainers.strategies.algorithms.feddyn_strategy import settings_from_config\n print(json.dumps(settings_from_config(),indent=2))\n''')
for family in ['feddyn','scaffold']:
    entrypoint = ROOT/f'examples/customized_client_training/{family}/{family}.py'
    r = run([RUNTIME_PYTHON,'-B',entrypoint,'--help'],label=family+'-help')
    assert r.returncode == 0, r.stderr
    assert all(option in r.stdout.decode() for option in ['--cpu','--resume','--base','--config'])
    for location in ['root','examples']:
        cwd = ROOT if location == 'root' else ROOT/'examples/customized_client_training'
        prefix = 'examples/customized_client_training/' if location == 'root' else ''
        config = f'{prefix}{family}/{family}_MNIST_lenet5.toml'
        r = run([RUNTIME_PYTHON,'-B',probe,'-c',config,'--cpu','--resume',
                 '-b',OUT/'config-probes'/f'{family}-{location}'],cwd=cwd,
                label=f'{family}-config-{location}')
        assert r.returncode == 0, r.stderr
r = run(['git','diff','--check',BASE,'HEAD'],label='docs-diff-check')
assert r.returncode == 0
data = dict(scope=dict(changed=changed,unchanged_baseline_entries=len(a)-1,
                       nonowned_unchanged=True,preserved_public_sections=preserved),
            documents=[receipt(ROOT/path) for path in sorted(owned)],
            sources=source_receipts,inputs=input_receipts,builds=build_results,
            rendered=rendered,commands=records,script=receipt(__file__))
(OUT/'docs-checks.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(dict(changed=changed,nonowned_unchanged=True,
                     public_sections_preserved=sorted(candidate_sections.keys()-{'FedDyn','SCAFFOLD'}),
                     builds=build_results,rendered=[{k:v for k,v in x.items() if k in ('label','math_count','code_count','links')} for x in rendered],
                     cli_checks='PASS'),indent=2))
