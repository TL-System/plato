import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

root=Path('/Users/bli/Playground/plato/evidence/2026-refresh')
out=Path('/tmp/plato-phase2-final-prose-review')
def receipt(p):
    b=p.read_bytes()
    return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

a=root/'phase2c-scaffold-implementation-acceptance.json'
r=root/'phase2c-scaffold-code-review-4.json'
a_data=json.loads(a.read_text())
r_data=json.loads(r.read_text())
assert receipt(r)['sha256']=='ecded9d6b645910a5c2b1149181593ab131fd0e404c4bc59a03db18c75cb8d42'
assert a_data['candidate']=='13e38dafce476286db7e673e7f21343d54416b56'
assert a_data['tree']=='9fe8cfb039d0d97fc5b2c95a459de4c73c6d1b51'
assert r_data['candidate']['commit']==a_data['candidate']
p=root/'phase2c-algorithm-docs-review.json'
d=json.loads(p.read_text())
d['dependency_status_update']=dict(
    received_at_utc=datetime.now(timezone.utc).isoformat(),acceptance=receipt(a),review=receipt(r),
    decision=a_data['decision'],source_commit=a_data['candidate'],source_tree=a_data['tree'],
    closed_material_finding='F27-R3-01',
    optional_low_disposition='F27-R4-L01 remains optional; root requests no further code cycle for duplicate rejection cleanup after canonical replace failure.',
    review_impact='No source change and no repeat of the other reviewer general lifecycle scope. This writing verdict remains independent; SCAFFOLD bounded implementation/shared preservation is now root-accepted. FedDyn numerical, merged-profile, hosted Linux and whole C/Phase2 gates remain separate.',
    update_validation='Initial inline shell command had a quoting parse error before Python ran or any writes occurred. This scratch-file invocation validates and applies the update.')
p.write_text(json.dumps(d,indent=2)+'\n')
receipts=[]
for name in ('phase2c-algorithm-docs-review.json','phase2-ci-budget-review.json'):
    p=root/name
    d=json.loads(p.read_text())
    assert d['verdict']=='PASS' and not d['material_findings']
    assert d['constraints_observed']['candidate_edits'] is False
    receipts.append(receipt(p))
(out/'report-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(json.dumps(receipts,indent=2))
