import json
from plato.config import Config
c=Config()
assert c.args.cpu and c.args.resume
print(json.dumps({"config":c.args.config,"base":c.params["base_path"],"model":c.params["model_path"],"checkpoint":c.params["checkpoint_path"],"rounds":c.trainer.rounds,"clients":c.clients.total_clients,"per_round":c.clients.per_round,"optimizer":c.parameters.optimizer._asdict(),"cpu":c.args.cpu,"resume":c.args.resume},indent=2))
if c.clients.total_clients == 1000:
 from plato.trainers.strategies.algorithms.feddyn_strategy import settings_from_config
 print(json.dumps(settings_from_config(),indent=2))
