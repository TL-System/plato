"""Verify immutable source identity and retained exact-source author evidence."""

import hashlib
import json
import shlex
import subprocess
from pathlib import Path

import numpy as np

from plato.serialization.safetensor import deserialize_tree


SOURCE = Path('/private/tmp/plato-refresh-worktrees/runtime')
ROOT = Path('/Users/bli/Playground/plato')
SCRATCH = Path('/tmp/plato-phase2b-review-3')
AUTHOR = Path('/tmp/plato-phase2b-runtime')
BASE = 'fda60becedfa6236c11d415b87a868b52789a41e'
PRIOR = '7753ca37bacbbdbcaef4192150e6532d79247011'
IMPLEMENTATION = '861c5c5ca03d8657c13ca5b93c3f9e0298172954'
CANDIDATE = '00eeb9dcdd2b513e64db9408969356037e09bb8e'
D = 'aa232791f04d93eb9de09ed6c596ac714db5b605'
OLD_D = 'a4a4733e96cf248a73db76e6b2182536b9f592ea'


def git(*args):
    return subprocess.check_output(
        ['zsh', '-lc', 'GIT_OPTIONAL_LOCKS=0 ' + shlex.join(['git', *args])],
        cwd=SOURCE,
    )


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def artifact(path):
    return {'path': str(path), 'sha256': sha(path)}


report = {
    'base': BASE, 'prior': PRIOR, 'candidate': CANDIDATE,
    'implementation': IMPLEMENTATION, 'source_files': {}, 'authority_files': {},
    'author_logs': {}, 'runs': {},
}
assert git('rev-parse', 'HEAD').decode().strip() == CANDIDATE
assert not git('status', '--porcelain')
assert git('rev-parse', CANDIDATE + '^').decode().strip() == IMPLEMENTATION
assert git('rev-parse', IMPLEMENTATION + '^').decode().strip() == PRIOR
for name in ['base', 'prior', 'implementation', 'candidate']:
    report[name + '_tree'] = git('rev-parse', report[name] + '^{tree}').decode().strip()
assert git('diff', '--name-only', IMPLEMENTATION, CANDIDATE).decode().splitlines() == [
    'evidence/2026-refresh/phase2b-validation.json'
]
for name in git('diff', '--name-only', BASE, CANDIDATE).decode().splitlines():
    raw = git('show', CANDIDATE + ':' + name)
    assert (SOURCE / name).read_bytes() == raw
    assert (SCRATCH / 'candidate' / name).read_bytes() == raw
    report['source_files'][name] = sha(SOURCE / name)
for name in [
    'AGENTS.md', 'uv.lock', 'pyproject.toml', '.python-version',
    'evidence/2026-refresh/plan.md', 'evidence/2026-refresh/plan-addendum.json',
    'evidence/2026-refresh/plan-addendum-acceptance.json', 'tests/conftest.py',
    'tests/integration/test_event_loop_startup.py',
    'tests/integration/startup_harness.py', 'tests/integration/startup_probe.py',
    'tests/integration/startup_socket.py', 'tests/integration/utils.py',
]:
    assert (SOURCE / name).read_bytes() == git('show', CANDIDATE + ':' + name)
    report['authority_files'][name] = sha(SOURCE / name)
    if name.startswith('tests/'):
        assert (SOURCE / name).read_bytes() == git('show', BASE + ':' + name)
for name in ['phase2b-review.json', 'phase2b-review-2.json', 'phase2b-root-probe.json']:
    path = ROOT / 'evidence/2026-refresh' / name
    report['authority_files'][str(path)] = sha(path)
evidence = json.loads((SOURCE / 'evidence/2026-refresh/phase2b-validation.json').read_text())
assert evidence['identities']['final_implementation_commit'] == IMPLEMENTATION
latest = evidence['review_2_corrections']
assert latest['final_implementation_commit'] == IMPLEMENTATION
assert latest['review_identity']['candidate_commit'] == PRIOR
for name, digest in latest['source_sha256'].items():
    assert sha(SOURCE / name) == digest
    assert hashlib.sha256(git('show', IMPLEMENTATION + ':' + name)).hexdigest() == digest
for name, digest in evidence['environment']['identities_sha256'].items():
    assert sha(SOURCE / name) == digest
for record in [latest['review_identity'][name] for name in ['review', 'read_only_probe', 'read_only_helper']]:
    assert sha(record['path']) == record['sha256']

for version, result in latest['results'].items():
    for stage, expected in [('red', '3 failed, 2 passed'), ('green', '53 passed'), ('final_affected_suite', '232 passed')]:
        log = result[stage]['log']
        assert sha(log['path']) == log['sha256']
        lines = Path(log['path']).read_text().splitlines()
        assert expected in lines[-1]
        report['author_logs'][log['path']] = dict(log, last_line=lines[-1])
        if stage == 'red':
            failures = [line for line in lines if line.startswith('FAILED ')]
            assert len(failures) == 3
            report['author_logs'][log['path']]['failures'] = failures
for correction in latest['checks']:
    if 'log' in correction:
        assert sha(correction['log']['path']) == correction['log']['sha256']
        report['author_logs'][correction['log']['path']] = correction['log']
historical = evidence['review_corrections']
for result in historical['results'].values():
    for stage in ['red', 'green', 'final_affected_suite']:
        assert sha(result[stage]['log']) == result[stage]['sha256']
        report['author_logs'][result[stage]['log']] = {
            'sha256': result[stage]['sha256'],
            'last_line': Path(result[stage]['log']).read_text().splitlines()[-1],
            'historical_source': historical['implementation_commit'],
        }

combined = historical['combined_source']
pinned = Path(combined['owned_read_only_copy'])
assert sha(pinned) == combined['source_sha256']
assert pinned.read_bytes() == git('show', OLD_D + ':plato/utils/s3.py')
assert pinned.read_bytes() == git('show', D + ':plato/utils/s3.py')
assert sha(combined['integration_probe']) == combined['probe_sha256']
report['d_source'] = {
    'old_candidate': OLD_D, 'candidate': D,
    'tree': git('rev-parse', D + '^{tree}').decode().strip(),
    'source_sha256': sha(pinned), 'unchanged_source': True,
    'qualification': 'Provisional source combination only; root final accepted B+D remains pending.',
}

canonical = lambda row: json.dumps(row, sort_keys=True)
for version in [313, 314]:
    run = AUTHOR / 'review-2-fixes' / f'accepted{version}'
    paths = sorted(run.rglob('result.json'))
    assert len(paths) == 48
    records = []
    for path in paths:
        row = json.loads(path.read_text())
        assert not row['survivors']
        durable = [
            json.loads(line) for event_file in path.parent.glob('events-*.jsonl')
            for line in event_file.read_text().splitlines()
        ]
        assert sorted(map(canonical, durable)) == sorted(map(canonical, row['events']))
        records.append(row)
    assert sum(bool(row['forced']) for row in records) == 5
    socket_path = next(path for path in paths if json.loads(path.read_text())['case'] == 'socket_round')
    row = json.loads(socket_path.read_text())
    assert row['returncode'] == 0 and not row['timed_out'] and not row['forced']
    trained = [e for e in row['events'] if e['event'] == 'client_trained']
    received = [e for e in row['events'] if e['event'] == 'server_received']
    final = next(e['weights'] for e in row['events'] if e['event'] == 'server_aggregate')
    baseline = next(e['weights'] for e in row['events'] if e['event'] == 'server_baseline')
    assert len(trained) == len(received) == 2
    assert len({e['pid'] for e in trained}) == 2
    assert {e['pid'] for e in trained} == {e['pid'] for e in row['events'] if e['event'] == 'child_returned'}
    assert sorted(e['samples'] for e in received) == [2, 6]
    errors, artifacts = {}, {}
    for key in final:
        expected = sum(
            e['samples'] * np.asarray(e['weights'][key], dtype=np.float64)
            for e in received
        ) / sum(e['samples'] for e in received)
        errors[key] = float(np.max(np.abs(np.asarray(final[key], dtype=np.float64) - expected)))
        assert errors[key] <= 1.5e-8
    for client in trained:
        arrived = next(e for e in received if e['client_id'] == client['client_id'])
        assert arrived['weights'] == client['weights'] and arrived['samples'] == client['samples']
        assert client['weights'] != baseline
        path = socket_path.parent / 'models/pretrained' / f"startup_tiny_{client['client_id']}_{client['pid']}.safetensors"
        stored = deserialize_tree(path.read_bytes())
        for key in stored:
            np.testing.assert_array_equal(stored[key].numpy(), client['weights'][key])
        artifacts[str(path)] = sha(path)
    for folder, name in [('models/pretrained', 'startup_tiny.safetensors'), ('checkpoints', 'checkpoint_startup_tiny_1.safetensors')]:
        path = socket_path.parent / folder / name
        stored = deserialize_tree(path.read_bytes())
        for key in stored:
            np.testing.assert_array_equal(stored[key].numpy(), final[key])
        artifacts[str(path)] = sha(path)
    report['runs'][str(run)] = {
        'records': len(records), 'reported_survivors': 0,
        'events_match_durable_files': True, 'deliberate_negative_forced_cases': 5,
        'result_hashes': {str(path): sha(path) for path in paths},
        'socket_result': artifact(socket_path), 'socket_elapsed_seconds': row['elapsed'],
        'socket_returncode': row['returncode'], 'socket_forced': row['forced'],
        'socket_timed_out': row['timed_out'],
        'trained': [{'id': e['client_id'], 'samples': e['samples'], 'pid': e['pid']} for e in trained],
        'weighted_reference_max_abs_error': errors, 'tensor_hashes': artifacts,
        'event_hashes': {str(path): sha(path) for path in socket_path.parent.glob('events-*.jsonl')},
    }
report['all_changed_files_match_exact_candidate'] = True
report['candidate_clean'] = not git('status', '--porcelain')
(SCRATCH / 'evidence-audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({
    'candidate': CANDIDATE, 'tree': report['candidate_tree'],
    'author_logs_verified': len(report['author_logs']),
    'startup_records_verified': sum(r['records'] for r in report['runs'].values()),
    'socket_errors': [r['weighted_reference_max_abs_error'] for r in report['runs'].values()],
    'clean': report['candidate_clean'],
}))
