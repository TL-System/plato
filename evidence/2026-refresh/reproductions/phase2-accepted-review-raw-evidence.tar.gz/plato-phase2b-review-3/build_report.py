"""Assemble the sole authorized durable review artifact."""

import hashlib
import json
import shlex
import subprocess
from datetime import datetime, timezone
from pathlib import Path


SCRATCH = Path('/tmp/plato-phase2b-review-3')
SOURCE = Path('/private/tmp/plato-refresh-worktrees/runtime')
ROOT = Path('/Users/bli/Playground/plato')
REPORT = ROOT / 'evidence/2026-refresh/phase2b-review-3.json'
audit = json.loads((SCRATCH / 'evidence-audit.json').read_text())
threads = 'PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1'


def artifact(path):
    path = Path(path)
    return {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def git(*args):
    return subprocess.check_output(
        ['zsh', '-lc', 'GIT_OPTIONAL_LOCKS=0 ' + shlex.join(['git', *args])],
        cwd=SOURCE,
    ).decode().strip()


assert git('rev-parse', 'HEAD') == audit['candidate']
assert not git('status', '--porcelain')
old_source = subprocess.check_output(
    ['zsh', '-lc', 'GIT_OPTIONAL_LOCKS=0 git show ' + audit['prior'] + ':plato/servers/base.py'],
    cwd=SOURCE,
)
assert (SCRATCH / 'prior/plato/servers/base.py').read_bytes() == old_source
checks = []
new_states = {}
environments = []
for version in [313, 314]:
    environment = json.loads((SCRATCH / f'environment{version}.json').read_text())
    assert not any(environment['optional_present'].values())
    environment['artifact'] = artifact(SCRATCH / f'environment{version}.json')
    environment['provision'] = (
        f'zsh -lc \'UV_PROJECT_ENVIRONMENT={SCRATCH}/base{version} '
        f'UV_CACHE_DIR={SCRATCH}/uv-cache PYTHONDONTWRITEBYTECODE=1 '
        f'uv sync --locked --no-default-groups --group test-base --python '
        f'{"3.13" if version == 313 else "3.14"}\''
    )
    environment['provision_log'] = artifact(SCRATCH / f'base-sync{version}.log')
    environments.append(environment)
    specs = [
        ('runtime', '184 passed', 'tests/clients tests/servers tests/callbacks tests/integration/test_smoke_configs.py --test-profile base -q', SCRATCH / 'candidate'),
        ('probes', '12 passed', 'tests/test_review3_worker_loss.py -q -s', SCRATCH / 'candidate'),
        ('retained-probes', '47 passed', 'tests/test_review2_probes.py tests/test_review2_disconnect_probe.py tests/test_s3_combined.py -q -s', SCRATCH / 'candidate'),
        ('red', '11 failed, 6 passed', 'tests/test_review3_worker_loss.py tests/servers/test_runtime_disconnect_recovery.py -q -s', SCRATCH / 'prior'),
        ('collection-detail', '443 tests collected', 'tests --test-profile base --collect-only -q -rs', SOURCE),
    ]
    for kind, expected, args, cwd in specs:
        log = SCRATCH / f'{kind}{version}.log'
        lines = log.read_text().splitlines()
        assert expected in lines[-1]
        if kind != 'red':
            assert not any(line.startswith(('FAILED ', 'ERROR ', 'INTERNALERROR>')) for line in lines)
        checks.append({
            'check': kind, 'python': environment['python'].split()[0],
            'command': f'zsh -lc \'{threads} {SCRATCH}/base{version}/bin/python -m pytest {args} -p no:cacheprovider --basetemp {SCRATCH}/{kind}{version}\'',
            'cwd': str(cwd), 'result': lines[-1],
            'exit_code': 1 if kind == 'red' else 0,
            'log': artifact(log),
            'omissions': (
                ['Exactly the declared optional DP module skip: opacus absent. All 443 nodes collect; named startup and required base cases remain present.']
                if kind == 'collection-detail' else []
            ),
        })
    states = [
        json.loads(line.split('REVIEW3_RECOVERY ', 1)[1])
        for line in (SCRATCH / f'probes{version}.log').read_text().splitlines()
        if 'REVIEW3_RECOVERY ' in line
    ]
    assert len(states) == 8 and all(state['round'] == 6 for state in states)
    new_states[str(version)] = states
    nodes = [
        line for line in (SCRATCH / f'collection-detail{version}.log').read_text().splitlines()
        if line.startswith('tests/') and '::' in line
    ]
    affected = [node for node in nodes if node.startswith((
        'tests/clients/', 'tests/servers/', 'tests/callbacks/',
        'tests/integration/test_smoke_configs.py::',
        'tests/integration/test_event_loop_startup.py::',
    ))]
    assert len(affected) == 232
    assert len([node for node in affected if node.startswith('tests/integration/test_event_loop_startup.py::')]) == 48

identities = {
    'candidate_commit': audit['candidate'], 'candidate_tree': audit['candidate_tree'],
    'implementation_commit': audit['implementation'], 'implementation_tree': audit['implementation_tree'],
    'previous_reviewed_candidate': audit['prior'], 'previous_candidate_tree': audit['prior_tree'],
    'phase_base': audit['base'], 'phase_base_tree': audit['base_tree'],
    'candidate_worktree': str(SOURCE), 'root_worktree': str(ROOT), 'review_scratch': str(SCRATCH),
    'candidate_read_only': True, 'candidate_status_before_and_after': 'clean',
    'evidence_commit_boundary': '00eeb9dc is an evidence-only direct child of 861c5c5c; only phase2b-validation.json differs. 861c5c5c is a direct child of previous reviewed candidate 7753ca37.',
    'all_changed_source_and_test_files_match_exact_git_objects': True,
    'execution_source': 'Exact git archive of 00eeb9dc for tests; original read-only worktree for clean base collection and Ruff. Added reviewer probes exist only in authorized scratch. All tracked changed files and authority files match exact candidate objects.',
    'base_to_candidate_diff': artifact(SCRATCH / 'base-to-candidate.diff'),
    'recovery_diff': artifact(SCRATCH / 'recovery.diff'),
    'source_sha256': audit['source_files'], 'authority_sha256': audit['authority_files'],
    'independent_red_source_sha256': hashlib.sha256(old_source).hexdigest(),
    'independent_red_source': str(SCRATCH / 'prior/plato/servers/base.py'),
    'no_nested_agents': True,
}

report = {
    'schema_version': 1,
    'review': 'Fresh independent Phase 2B review 3',
    'reviewer': 'plato-phase2b-review-3',
    'requested_model': 'gpt-6.1-sol', 'requested_reasoning_effort': 'xhigh',
    'completed_at_utc': datetime.now(timezone.utc).isoformat(),
    'decision': 'PASS',
    'decision_basis': [
        'No critical, high or medium findings remain in the reviewed B scope. R2B-04 passes independent actual-selection/batching/default-urgency/event-handler probes with usable completed work, exact accounting, identity rejection and survivor progress in both disconnect/completion orderings.',
        'Earlier R2B-01/02/03/L01, B-local S3, F10/F11/F18 and representative lifecycle contracts remain passing on Python 3.13.16 and 3.14.8, including base-profile execution with optional extras absent.',
        'This is B component acceptance. Final accepted B+D integration, trainer snapshot F26 and phase-wide qualification remain separate assigned work.',
    ],
    'identities': identities,
    'scope': {
        'authorities_read': [
            'AGENTS.md in candidate and root', 'accepted plan.md',
            'plan-addendum.json and acceptance', 'ROOT phase2b-review.json',
            'ROOT phase2b-review-2.json', 'ROOT phase2b-root-probe.json',
            'entire candidate phase2b-validation.json, including both correction histories',
        ],
        'included': [
            'Actual simulated-time async physical-worker loss with deferred urgency, both event orders, ongoing survivor batch/replacement and missing/true debug close policy.',
            'One outstanding urgent assignment per worker; distinct workers concurrent with assignments prepared before any emit await; natural logical identities and wrong/stale/unknown-session rejection.',
            'Heap order and monotonic time; distinct transfer-object accounting, reusable/processed/malformed/disconnected/close cleanup, legacy fields and client-specific buffer caps.',
            'F10 own-current-client checkpoint cleanup; actual F11 PORT writer-to-history numerical weighting and live-model preservation; F18 raw/transformed/direct/legacy/delta/cross-silo pre-mutation input validation and valid zero/fractional weights.',
            'Bounded socket/file/S3 ingress, callbacks/context/evaluation/async/buffered/split/personalized/cross-silo regression cases, exact source/log/runtime-artifact attribution.',
        ],
        'excluded_with_owner': {
            '2C': 'F07 checkpoint naming and trainer lifecycle, accumulation, DP, personalization/SCAFFOLD and F26 time-snapshot decoder/epoch order. These future dependencies are not new B findings.',
            '3A': 'MLX aggregation-tree capability and backend qualification.',
            '2D': 'HE/MPC utility and corrected S3 utility ownership/review; no D edits demanded.',
            'root': 'Final accepted combined B+D regression promotion, execution and phase gate.',
        },
    },
    'findings': [],
    'optional_low_observations': [],
    'mandatory_contract_disposition': {
        'R2B-04': {
            'status': 'PASS', 'path': 'plato/servers/base.py',
            'lines': [976, 1281, 1547, 1555],
            'implementation': 'Reject unregistered assignment before mutation; preserve disconnected workers\' completed deferred reports rather than refreshing them; resume a ready simulated-time round from disconnect when there is no subsequent completion event. Existing outstanding live urgency still delays aggregation.',
            'independent_probe': artifact(SCRATCH / 'candidate/tests/test_review3_worker_loss.py'),
            'construction': 'ServerEvents client_alive starts actual production selection. Two physical workers/max_concurrency=2, four logical clients per round, minimum_clients=1, staleness_bound=1, request_update=true, debug=false. Actual report/chunk/part/done handlers produce rounds 7/2/8/9 then 9 and 9; the default urgency predicate requests lost/7 and survivor/2, deferring lost/8. Normal sends queue completions for later events rather than completing inside _send.',
            'matrix': 'Both disconnect/completion orders x no lost transfer, report-only, partial chunk and decoded part = 8 recovery cases per interpreter; both orders x missing/true debug = 4 close-policy cases.',
            'positive_result': 'All eight recovery cases on each interpreter preserve client 8\'s original completed payload and bytes, clear lost active/cache state, aggregate round-3 payloads {2:2,9:9,8:8}, finish a full [7,2,8,9] batch entirely on survivor, finish the next replacement and reach round 6. Only the original two urgent requests are emitted; all subsequent assignments belong to registered survivor.',
            'accounting_and_identity': 'An independent oracle sums recorded raw report/chunk lengths for unique report objects retained by heap/cache/active transfers after every event. Initial retained bytes=380, final usable retained bytes=570, close=0. Deferred token/payload survive until aggregation; heap stays valid and time never decreases. Late lost identities 7/8, prior survivor identity 2, deferred identity 8 and unknown session reject with a fail-on-parse sentinel before parsing.',
            'negative_reference': 'Exact previous 7753ca37 source gives 11 failed/6 passed on each interpreter: 8 new recovery failures plus 3 shipped assignment/order failures, with 6 existing close-policy cases passing. Lost-first reaches a dead lost/8 emit; survivor-first remains at round 3. No red candidate mutation was performed.',
            'stubs_and_limit': 'Outbound transport is an event queue; payload/report generation is inert; aggregation records updates and yields, wrap_up records no model work, and close calls actual _close_connections. Selection, registration, batching, urgency, assignment, ingress, disconnect, heap, cleanup and round transitions are production code. No urgent trainer snapshot decoder/checkpoint retrieval or real urgent socket training claim.',
        },
        'R2B-03': 'PASS: independently rerun actual shared-worker deferred report/byte/identity flow; first and second requested responses finish and reach round 4. Distinct-worker assignments exist before immediate response within first emit; aggregation waits for both valid responses.',
        'R2B-01': 'PASS: actual ingress partial urgency restores chronological heap, selecting [20,9,28] or [20,9,28,31]. Both minimum selection and stale draining preserve wall_time=50 for earlier responses.',
        'R2B-02': 'PASS: two distinct 190-byte completions for the same logical ID across physical workers count as 380 bytes at the real selection/send await. Budget 400 rejects the next 169-byte report before parsing. Worker reuse clears its own legacy cache only; queued work survives malformed ingress/disconnect until processed; close releases all.',
        'R2B-L01': 'PASS: actual client socket/S3 buffer cap rejects at max_buffered_bytes=20 while max_payload_bytes is larger. Simulated-file cap remains consistent.',
        'S3_B_local': 'PASS: exact-once empty, nested, already-qualified and leading/trailing prefix cases pass using only the minimal existing adapter interface. The separate 24 actual immutable D writer/presigner-to-B localhost reader cases pass per interpreter; this remains provisional source-combination evidence.',
        'F10': 'PASS: actual disconnect uses current logical identity 17, removes only its time-snapshot .pth/.pth.pkl/.safetensors files, preserves former/other client artifacts, resume files, unrelated suffixes and directories.',
        'F11': 'PASS locally: actual PORT weights_aggregated writes Safetensors with sidecar; reader uses repository tree decoding or CPU weights_only legacy .pth. Shipped stale cosine 0.6 and 2/6 numerical weighting pass. Independent reversed-key two-parameter cosine 1/3 preserves values/storage/CPU device/eval mode for both formats.',
        'F18': 'PASS: raw/transformed counts/cardinality reject before ordinary/legacy/delta and cross-silo trainer/model mutation. Negative/nonfinite and overflowing finite totals reject; 12 independent callback mutations pass. Valid fractional, zero, feature and reverse-order contracts remain passing, with valid zero totals returning the baseline through normal server dispatch.',
        'bounded_ingress_identity': 'PASS in tested existing contract: wrong/unknown/stale/duplicate session identity, oversized report/chunk/payload/count/buffer, malformed/trailing/truncated/incomplete transfers, absolute deadlines, retry and S3 header/stream caps execute and preserve unrelated peers.',
        'callbacks_selection_evaluation': 'PASS: ordered callbacks/body AttributeError propagation, context synchronization, partial async replacement, FedBuff uniform mean, actual FedAsync example mixing, personalized/split selection, central-edge assignment, cross-silo validation before identity mutation and finite zero-sample reporting.',
        'startup_runtime': 'PASS retained exact-source evidence: 48 unchanged startup cases per interpreter included in author current-source 232-case runs. Verified 96 results/durable streams, zero reported survivors and five deliberate negative containment cases per interpreter. Real CPU socket rounds return naturally with separate 2/6-sample clients; received/trained/final/checkpoint tensors and independent float64 weighting agree to <=1.4901161193847656e-08.',
    },
    'environments': environments,
    'commands_and_results': checks,
    'additional_checks': [
        {
            'command': f'zsh -lc \'PYTHONDONTWRITEBYTECODE=1 PYTHONPATH={SCRATCH}/candidate OMP_NUM_THREADS=1 {SCRATCH}/base313/bin/python {SCRATCH}/audit_evidence.py\'',
            'cwd': str(SCRATCH / 'candidate'),
            'result': 'All changed files match exact candidate git objects; parent boundaries and authority hashes match; 14 current/historical author logs verified; latest source hashes agree with 861c5c5c and candidate; 96 retained startup records/events and actual socket tensor artifacts verified.',
            'source': artifact(SCRATCH / 'audit_evidence.py'),
            'output': artifact(SCRATCH / 'evidence-audit.json'),
            'log': artifact(SCRATCH / 'evidence-audit.log'),
        },
        {
            'command': f'zsh -lc \'{SCRATCH}/venv313/bin/ruff check . --select I --no-cache\'',
            'cwd': str(SOURCE), 'result': 'All checks passed!',
            'log': artifact(SCRATCH / 'ruff.log'),
        },
        {
            'command': f'zsh -lc \'git diff {audit["base"]}..HEAD --check\'',
            'cwd': str(SOURCE), 'result': 'Passed; final candidate remains exact and clean.',
        },
    ],
    'exact_author_evidence': {
        'current_implementation': audit['implementation'],
        'current_candidate': audit['candidate'],
        'logs': audit['author_logs'],
        'current_startup_runs': audit['runs'],
        'historical_attribution': 'Initial 209/55 and first correction 227/40 results remain historical in phase2b-validation.json. Latest review_2_corrections identifies 861c5c5c; its green53 and affected232 results include the new recovery source. The final evidence-only child changes no implementation/test source.',
        'startup_source': 'Startup tests/helpers/fixtures are byte-identical to phase base. No unchanged eight-minute matrix rerun; retained current-source artifacts were independently verified.',
    },
    'independent_recovery_states': new_states,
    'd_combination': dict(audit['d_source'], probe=artifact(SCRATCH / 'candidate/tests/test_s3_combined.py'),
        original_probe=artifact('/tmp/plato-phase2b-runtime/review-fixes/test_s3_combined.py'),
        policy='No D edits, cherry-pick, environment changes or final combined root qualification claim. Root promotes the actual combined regression and runs it on final accepted B+D source.'),
    'count_policy': 'Per interpreter: 184 tracked affected cases excluding 48 unchanged startup subprocess cases, 12 newly independent event-driven loss/close probes, and 47 retained independent/provisional cases (22 positive contracts + original reviewer2 disconnect + 24 D/B combinations) all pass: 243 distinct reviewer execution nodes, zero skips/warnings. The 24 D/B cases remain provisional integration evidence. The independent red run has 17 nodes (11 fail/6 pass); 5 shipped red cases overlap the green affected suite. Author green53 overlaps affected232. Full original candidate base collection contains 443 nodes plus exactly the allowed absent-opacus module skip; the 232 author affected nodes and all 48 startup cases are present. Repeated collection/count checks are not additional coverage.',
    'handoffs_and_pending_integration': [
        {'id': 'B_REVIEW_GATE', 'owner': 'Root', 'status': 'PASS for exact 00eeb9dc candidate', 'requirement': 'The B review condition for serialized client/server F07 ownership transfer to C is satisfied; root controls acceptance/integration and handoff.'},
        {'id': 'B_D_COMBINATION', 'owner': 'Root', 'status': 'Pending final accepted-source qualification', 'requirement': 'Promote actual immutable D writer/presigner-to-B reader regression into tracked coverage and run on final accepted B+D tree. Current D base-test corrections and separate review are not B blockers or requests for unrelated D edits.'},
        {'id': 'F07_TRAINER_F26', 'owner': '2C', 'status': 'Assigned future dependency', 'requirement': 'Preserve full checkpoint writer/reader/sidecar inventory. Repair/qualify urgent time-snapshot metadata decoding and epoch order within C. Trainer lifecycle/accumulation/DP/personalization/SCAFFOLD work remains C scope.'},
        {'id': 'MLX_F17', 'owner': '3A', 'status': 'Later narrow ingress capability handoff', 'requirement': 'Extend eligible raw/transformed MLX tree validation, including zero weights and both arrival orders, after B acceptance.'},
        {'id': 'PHASE_INTEGRATION', 'owner': 'Root', 'status': 'Pending', 'requirement': 'Final combined validation and phase gate remain required; this component PASS does not replace them.'},
    ],
    'explicit_limits': [
        'No real urgent trainer/checkpoint end-to-end claim; new liveness probes use inert report/payload generation and real runtime event handlers. Actual urgent snapshot retrieval remains C/F26.',
        'No live cloud S3, GPU/distributed or production multi-silo run, and no whole-stack Python 3.14 support claim.',
        'Wire limits/session binding retain the existing trusted-peer/storage contract. Arbitrary decoded pickle expansion/execution and indistinguishable same-logical-ID replay are outside it; no auth/nonce/wire redesign requested.',
        'PORT model preservation executed on CPU; other-device preservation is source inspection of detach().cpu() copies, not an accelerator result.',
        'Author startup matrix was not mechanically repeated. Exact current-source logs/results/events/tensors were audited; root integration repeats the accepted combination later.',
        'Early reviewer-only harness failures were corrected in owned scratch: eager server import invoked Config argument parsing before fixtures; a later assertion incorrectly expected every asynchronous replacement round to contain four clients. The production replacement policy uses one replacement after a full batch. Those logs are retained and excluded from product findings; final probes still require the full four-client survivor batch plus genuine next-replacement progress.',
        'No candidate edits, metadata/CI edits, other-environment mutations, commits/push/PR edits, security questionnaire or nested agents.',
    ],
    'owned_resources': {
        'root': str(SCRATCH),
        'contents': 'Exact current/prior archives, owned dev and clean-base 3.13/3.14 environments, UV cache, independent/copied probes, raw red/green/collection/harness logs, pytest bases, source diffs and evidence audit/build scripts.',
        'retention': 'Keep for root acceptance and reproduction; no other agent resources removed.',
        'write_scope': f'Only {REPORT} and {SCRATCH}.',
    },
}
assert report['findings'] == [] and report['optional_low_observations'] == []
REPORT.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'decision': report['decision'], 'report': str(REPORT), 'bytes': REPORT.stat().st_size, 'candidate': audit['candidate']}))
