import importlib.metadata
import importlib.util
import json
import platform
import sys
from pathlib import Path

data = {
    'executable': sys.executable, 'python': sys.version,
    'host': platform.platform(), 'plato_source': importlib.util.find_spec('plato').origin,
    'versions': {name: importlib.metadata.version(name) for name in [
        'pytest', 'torch', 'torchvision', 'numpy', 'aiohttp', 'python-socketio',
        'safetensors', 'boto3', 'requests',
    ]},
    'optional_present': {name: importlib.util.find_spec(name) is not None for name in [
        'opacus', 'kazoo', 'gymnasium', 'tiktoken', 'mlx', 'lighteval', 'lightly',
    ]},
}
path = Path(sys.argv[1])
path.write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps(data))
