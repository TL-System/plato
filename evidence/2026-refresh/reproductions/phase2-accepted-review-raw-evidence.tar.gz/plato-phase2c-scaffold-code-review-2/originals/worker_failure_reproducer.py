"""Failed current spawn handoff followed by ordinary logical-client reuse."""
import json
import pickle
import sys
from pathlib import Path

import independent_checks as p

class MissingAfterSuccess(p.RecordingTrainer):
    def train_process(self,config,trainset,sampler,**kwargs):
        super().train_process(config,trainset,sampler,**kwargs)
        Path(self._training_state_path(config['run_id'])).unlink()

if __name__=='__main__':
    version=f'{sys.version_info.major}{sys.version_info.minor}'
    root=p.SCRATCH/f'failed-worker-reuse-{version}'
    root.mkdir(parents=True,exist_ok=True)
    with p.configure_environment(p.config(spawn=True),runtime_root=root):
        client=p.client(1)
        client.trainer.model_update_strategy.client_control_variate=p.controls(1)
        # Seed the last successful client state, so failure recovery is tested
        # against a real pre-existing canonical checkpoint.
        Path(client.trainer.model_update_strategy.client_control_variate_path).write_bytes(pickle.dumps(p.controls(1)))
        before_reconstructed=p.client(1)
        p.close(before_reconstructed.trainer.model_update_strategy.client_control_variate['theta'].item(),1)
        client.trainer.__class__=MissingAfterSuccess
        caught=None
        try:p.train_round(client,[p.controls(1),p.controls(2)],1,0.,2)
        except RuntimeError as exc:caught=str(exc)
        assert caught and 'successful current-round' in caught
        st=client.trainer.model_update_strategy
        parent_ci=st.client_control_variate['theta'].item()
        p.close(parent_ci,1)
        assert client.trainer.context.state.get('client_control_variate_delta') is None
        # This is routine trainer reuse, not a full server restart.
        for cid in (2,1):
            client.client_id=client._context.client_id=cid
            client.configure()
        reused_ci=st.client_control_variate['theta'].item()
        fresh=p.client(1)
        fresh_ci=fresh.trainer.model_update_strategy.client_control_variate['theta'].item()
        p.close(reused_ci,.9);p.close(fresh_ci,.9)
        client.trainer.__class__=p.RecordingTrainer
        retry=p.train_round(client,[p.controls(1),p.controls(2)],2,0.,2)
        retry_y=client.trainer.model.theta.item()
        retry_ci=st.client_control_variate['theta'].item()
        retry_delta=retry.payload[1]['theta'].item()
        p.close(retry_y,.601);p.close(retry_ci,.895);p.close(retry_delta,-.005)
        result=dict(python=sys.version,failed_handoff_error=caught,
            training_error=str(client._context.state.get('training_error')),
            parent_ci_after_failure=parent_ci,ci_after_1_to_2_to_1=reused_ci,
            reconstructed_ci=fresh_ci,
            expected='Failed handoff has no outbound delta; normal reuse must retain the pre-attempt ci=1. Retry should yield y=.62,ci=.9,delta=-.1.',
            actual_retry=dict(y=retry_y,ci=retry_ci,delta=retry_delta),
            next_server_c_if_retry_only_delivered=2+retry_delta/3,
            mean_retained_ci_after_retry=(retry_ci+3+2)/3,
            interpretation='Exit zero asserts the defect, not acceptance success.')
        assert abs(result['next_server_c_if_retry_only_delivered']-result['mean_retained_ci_after_retry'])>.03
    (p.SCRATCH/f'failed-worker-reuse-{version}.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
