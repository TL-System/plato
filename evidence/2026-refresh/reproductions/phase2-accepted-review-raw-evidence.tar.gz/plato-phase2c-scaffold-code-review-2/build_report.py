import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

scratch = Path('/tmp/plato-phase2c-scaffold-code-review-2')
source = Path('/private/tmp/plato-refresh-worktrees/training-review2')
destination = Path('/Users/bli/Playground/plato/evidence/2026-refresh/phase2c-scaffold-code-review-2.json')
candidate = 'f9772f61d52dfe0f4a3281252d23b8303ec237d2'
implementation = 'e65241c19448b74dcb57fc48bfe388152f3a3e58'
original = '62d7b7d8ef75be779149a96f567779c86699edb4'
B = '00eeb9dcdd2b513e64db9408969356037e09bb8e'


def read(name):
    return json.loads((scratch/name).read_text())


def receipt(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=source, text=True).strip()


initial = read('initial-identities.json')
scope = read('scope-and-receipts.json')
current = [receipt(item['path']) for item in initial['source_receipts']]
assert current == initial['source_receipts']
assert git('rev-parse', 'HEAD') == candidate
assert git('status', '--porcelain=v1', '--untracked-files=all') == ''
assert git('status', '--porcelain=v1', '--ignored') == ''
assert initial['existing_caches'] == []
assert subprocess.run(['git', 'symbolic-ref', '-q', 'HEAD'], cwd=source,
                      capture_output=True).returncode == 1
final = dict(head=candidate, tree=git('rev-parse','HEAD^{tree}'), status='',
             ignored_status='', detached=True, all_initial_source_hashes_match=True,
             checked_source_files=len(current), bytecode_and_tool_cache_pollution=False)
(scratch/'final-identities.json').write_text(json.dumps(final,indent=2)+'\n')
commands = [read(p.name) for p in sorted(scratch.glob('*.command.json'))]
for command in commands:
    actual = receipt(command['raw_log'])
    assert actual['sha256'] == command['raw_sha256']
    assert actual['bytes'] == command['raw_bytes']
assert all(c['exit_code'] == 0 for c in commands
           if c['label'] not in ['transport313','transport314'])
assert scope['shipped_toml_values_match_B']
assert scope['server_base_matches_original_candidate']
assert all(item['matches_receipt'] for item in scope['author_log_verification'])

callback_results = {v:read(f'callback-lifecycle-{v}.json') for v in ['313','314']}
checks = {v:dict(numerical=read(f'independent-{v}-normal.json'),
                 spawn=read(f'independent-{v}-spawn.json'),
                 boundary=read(f'boundary-{v}.json'),
                 original_server=read(f'server-reproducer-{v}.json'),
                 original_worker_retry=read(f'failed-worker-reuse-{v}.json'),
                 transport=read(f'transport-validation-{v}.json'),
                 direct_acceptance=read(f'direct-acceptance-{v}.json'))
          for v in ['313','314']}

findings = [
    dict(id='F27-R2-01', severity='high', status='OPEN',
         title='SCAFFOLD report callbacks bypass the promised batch failure boundary.',
         related_first_review='F27-R01: original raw NaN/missing/broadcast reproductions are fixed; callback and abort-state coverage remains incomplete.',
         acceptance_contracts=['A08','A10'],
         primary_location=dict(file='examples/customized_client_training/scaffold/scaffold_server.py',line=108),
         supporting_locations=[dict(file='examples/customized_client_training/scaffold/scaffold_server.py',line=118),
                               dict(file='plato/servers/fedavg.py',line=187),
                               dict(file='plato/servers/fedavg.py',line=188),
                               dict(file='plato/servers/fedavg.py',line=217),
                               dict(file='plato/servers/fedavg.py',line=248)],
         cause='weights_received validates raw halves and installs pending controls, but the SCAFFOLD subclass has no rejection cleanup around inherited _process_reports. The receive callback can raise or invalidate the returned model after validation. Only sample metadata is rechecked afterward. Model and controls commit before on_weights_aggregated callbacks run.',
         reproducer=dict(source=receipt(scratch/'callback_lifecycle_probe.py'),
                         commands=[c for c in commands if c['label'] in ['callback313','callback314']],
                         source_function='server_probes',
                         steps=['Use the actual shipped TOML with explicit CPU, scalar float64, plain SGD, eta=.1, N=3 overrides and a full report obtained from successful real example training.',
                                'Initial server x=1,c=2; submit two num_samples=2 reports with model theta=[7],[9] and finite control deltas [3],[4].',
                                'Register a normal ServerCallback that raises in on_weights_received; call actual server._process_reports(). Then call it again with invalid num_samples=-1.',
                                'Separately register a callback that invalidates sample metadata, a callback that raises in on_weights_aggregated, and a callback that fills a returned theta tensor with NaN.'],
                         expected='Each failed batch preserves x=1,c=2 and clears pending/received controls. A model invalidated between validation and aggregation must be rejected before either commit.',
                         actual='Receive failure and callback-induced metadata failure leave _pending_control_variate and received_client_control_variates populated. A later ingress sample error also leaves the stale stage. Aggregation callback failure raises after x=8,c=13/3 commit. Callback mutation of the cloned model to NaN completes without an exception and commits x=NaN,c=13/3. Raw inbound payloads remain unmodified.',
                         python_versions=['3.13.16','3.14.8'],
                         results={v:data['server'] for v,data in callback_results.items()},
                         exit_status_interpretation='Probe exits zero by asserting these defects; this is not an acceptance pass.'),
         impact='The actual report path still violates the accepted unchanged model/control and no stale staged controls contract after callback failure. Successful raw-payload validation alone does not close A08.',
         bounded_correction='Keep the correction in the SCAFFOLD example boundary: discard staged controls on every unsuccessful report batch, validate the model/control state actually used after receive callbacks, and restore/defer the batch model/control commit when an aggregation callback fails. Add real _process_reports callback regressions. No global FedAvg rewrite, external side-effect transaction, optimizer/server restart or whole federated round rollback is required.'),
    dict(id='F27-R2-02', severity='medium', status='OPEN',
         title='Direct train_model accepts and persists controls before its fallible end lifecycle.',
         related_first_review='F27-R02: original missing-worker handoff/reuse/retry regression is fixed; direct lifecycle failure remains an unclosed acceptance boundary.',
         acceptance_contracts=['A05','A06','A10'],
         primary_location=dict(file='plato/trainers/composable.py',line=449),
         supporting_locations=[dict(file='plato/trainers/composable.py',line=450),
                               dict(file='plato/trainers/composable.py',line=453),
                               dict(file='plato/trainers/composable.py',line=454),
                               dict(file='plato/trainers/composable.py',line=428),
                               dict(file='plato/trainers/strategies/base.py',line=253),
                               dict(file='plato/trainers/strategies/algorithms/scaffold_strategy.py',line=330)],
         cause='train_model calls on_train_result_accepted and marks successful before training_step_strategy.on_train_end runs in finally. If that public end hook raises, model-update cleanup at the next line is skipped. Canonical ci has already advanced, _result_accepted remains true, and the optimizer pre-hook remains installed. The deferred train_process path correctly rejects the same error through its outer catch, exposing inconsistent direct/process behavior.',
         reproducer=dict(source=receipt(scratch/'callback_lifecycle_probe.py'),
                         commands=[c for c in commands if c['label'] in ['callback313','callback314']],
                         source_function='trainer_probes; EndFailure',
                         steps=['Use the actual SCAFFOLD trainer, scalar quadratic data, x=1,c=2,old ci=1, eta=.1, two real updates; test both existing canonical ci=1 and absent canonical file.',
                                'Inject a GradientAccumulationStepStrategy subclass whose public on_train_end calls the ordinary end hook and then raises RuntimeError.',
                                'Call direct trainer.train_model. Inspect the canonical file, strategy ci, outbound delta eligibility and optimizer hook.',
                                'Perform ordinary configure-based 1->2->1 reuse and fresh reconstruction. Remove the injected failure and successfully retry the same inbound x,c.',
                                'Compare the exact same injected lifecycle failure through direct train_process.'],
                         expected='An end-hook error rejects the result: retain prior ci=1, preserve the existing file bytes or absence, refuse outbound delta, and release step hooks. With existing ci=1, routine reuse/reconstruction and successful retry yield y=.62,ci=.9,delta=-.1.',
                         actual='Direct train_model raises but persists ci=.9 even when the file was absent, leaves outbound get_update_payload usable, and retains the optimizer pre-hook. Reuse and reconstruction load .9. Successful retry yields y=.601,ci=.895,delta=-.005. train_process rejects the same error and preserves ci=1/file bytes or absence; its existing-canonical retry yields .62/.9/-.1.',
                         python_versions=['3.13.16','3.14.8'],
                         results={v:data['trainer'] for v,data in callback_results.items()},
                         absence_limit='For the train_process comparison with an absent canonical file, the injected ci=1 was only in memory. After identity changes/reconstruction it correctly has no saved controls and starts at zero; its recorded .43/.85/.85 retry is not a candidate finding. The material absent-file case is direct train_model creating .9 despite raising.',
                         exit_status_interpretation='Probe exits zero by asserting the direct lifecycle defect and correct process comparison; this is not an acceptance pass.'),
         numerical_consequence='For inactive controls (3,2), after only the successful erroneous retry delta is delivered, server c becomes 1.9983333333333335 while mean retained controls is 1.965. This is ordinary client reuse plus retry, not a full restart requirement or convergence claim.',
         impact='The newly introduced generic acceptance hook still permits a failed direct call to become durable and outbound-eligible. The same caller-visible error has different acceptance effects across the supported direct and process entrypoints.',
         bounded_correction='Run the fallible training-step end lifecycle before direct acceptance and guarantee model-update rejection cleanup plus context/optimizer-hook cleanup even if another end hook raises. Preserve the deferred model-save/current-token worker ordering. Add the direct/process failure comparison with successful retry; no general restart or new algorithm framework is required.')
]

contract_review = [
    dict(id='A01',status='PASS',evidence='Both core and V2 real float64 SGD hooks reproduce g0 -> y.9,ci0,delta-1 and gradients3,1 -> y.4,ci2,delta1. Independent Fraction arithmetic and recorded client gradients agree within1e-12; main Algorithm1/Eqs3-5 used.'),
    dict(id='A02',status='PASS',evidence='Focused actual-TOML/factory tests cover .1/.025, next-round .05, missing optimizer, invalid/unequal/changed rate and executed pre-hook capture before post-hook changes, including accumulation tail. Actual optimizer is published at composable.py:556; capture/ownership checks precede optimizer mutation.'),
    dict(id='A03',status='PASS',evidence='Focused theta/reordered equal-rate groups/missing-gradient/frozen/excluded/floating/integer-buffer controls, historical known extras, malformed controls and detached-input checks pass. Additional float32 cast-overflow and integer-control rejection cases pass at either payload position and zero/positive sample weight.'),
    dict(id='A04',status='PASS',evidence='Independent core/V2 accumulation windows2 for1/3/4 microbatches have K1/2/2 with normalized tail and later zero-step delta0; no duplicate finalize. Real CPU GradScaler overflow leaves y1,K0,ci1,delta0; subsequent success gives y.8,K1.'),
    dict(id='A05',status='FAIL_BOUNDARY',evidence='Ordinary successful logical-client/legacy/custom-path tests and callback/save/atomic-replace failures with successful retries pass. F27-R2-02 remains: direct end-lifecycle exception persists failed controls and is outbound-eligible.'),
    dict(id='A06',status='FAIL_BOUNDARY',evidence='Actual shipped spawn positive pipeline and missing/stale/model-save/parent-commit negative cases pass. Exact original ci1 missing-handoff -> reuse/fresh/retry .62/.9/-.1 passes. Reused inbound/outbound processors consume current server controls and clear stale values. Direct/process lifecycle inconsistency F27-R2-02 remains.'),
    dict(id='A07',status='PASS',evidence='Independent rational oracle, real client gradients, full actual _process_reports and next server payloads pass for direct uneven/equal-count cases and actual multiprocessing spawn. Round1 x1.19,c2/3; round2 x10209/10000,c896/1125. Inactive ci retained; c=mean(allci). Unequal model weighting is a documented extension.'),
    dict(id='A08',status='FAIL_BOUNDARY',evidence='Original NaN/missing/broadcast raw models now reject before commit. Delivered28 malformed-model+6 metadata cases and5 malformed-delta cases pass, plus independent12 dtype/control cases and compatible bool/integer/frozen transport case. F27-R2-01 remains: callback failure leaves stale stages or returns failure after commit; callback-modified malformed model can bypass validation.'),
    dict(id='A09',status='PASS',evidence='Unchanged momentum.9 lr.01/weight_decay0 and constant-rate Adam match independently stepped raw optimizers followed by -eta*(c-ci), warning once. V2 shares corrected OptionII; no OptionI/mean-gradient/convergence claim for extensions.'),
    dict(id='A10',status='FAIL_MATERIAL_FINDINGS',evidence='166 delivered focused tests pass each on3.13.16/3.14.8; Ruff import policy passes. Exact immutable identities and author523/17/startup receipts verified. Material boundary findings require original-author correction, another fresh code review, and final source/prose reconciliation. Missing prose in this worktree is not a finding.')
]

relevant_paths = ['plato/trainers/composable.py','plato/trainers/strategies/base.py',
                  'plato/trainers/strategies/model_update.py','plato/trainers/strategies/training_step.py',
                  'plato/trainers/strategies/algorithms/scaffold_strategy.py',
                  'plato/algorithms/fedavg.py','plato/servers/fedavg.py',
                  'plato/servers/strategies/aggregation/fedavg.py','plato/trainers/optimizers.py',
                  'plato/clients/strategies/defaults.py','plato/utils/checkpoint_paths.py',
                  'examples/customized_client_training/scaffold/scaffold.py',
                  'examples/customized_client_training/scaffold/scaffold_callback.py',
                  'examples/customized_client_training/scaffold/scaffold_client.py',
                  'examples/customized_client_training/scaffold/scaffold_trainer.py',
                  'examples/customized_client_training/scaffold/scaffold_server.py',
                  'examples/customized_client_training/scaffold/scaffold_MNIST_lenet5.toml',
                  'tests/trainers/test_scaffold_strategy.py',
                  'tests/integration/test_scaffold_round_flow.py',
                  'tests/integration/scaffold_round_worker.py']
scope_diff = subprocess.check_output(['git','diff','--binary',original,candidate,'--',*relevant_paths],cwd=source)
(scratch/'scaffold-review-corrections.diff').write_bytes(scope_diff)

report = dict(
    schema_version=1, date=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    role='Fresh independent SCAFFOLD code review 2; user-requested Sol xhigh; no nested agents.',
    decision='CHANGES_REQUIRED', acceptance='FAIL', finding='F27',
    summary='Original raw-model and failed-worker-handoff defects are corrected and their exact adapted reproductions pass on both Python versions. All166 focused tests pass each. Two material failure boundaries remain: server callback batch atomicity and direct train_model acceptance before its end lifecycle. No mathematical correction regression found.',
    finding_counts=dict(critical=0,high=1,medium=1,low=0), findings=findings,
    low_recommendations=[],
    low_note='No separate low recommendation is used to downgrade the material acceptance failures. Unrelated Opacus notices remain outside SCAFFOLD conclusions.',
    immutable_candidate=dict(path=str(source),requested_alias='/tmp/plato-refresh-worktrees/training-review2',
                             commit=candidate,tree=initial['tree'],implementation=implementation,
                             implementation_tree=git('rev-parse',implementation+'^{tree}'),
                             original_reviewed_candidate=original,accepted_B=B,
                             B_is_ancestor=scope['B_is_ancestor'],initial_status=initial['status'],
                             final=final,only_post_implementation_files=scope['post_implementation_changed_paths'],
                             initial_identity_receipt=receipt(scratch/'initial-identities.json'),
                             final_identity_receipt=receipt(scratch/'final-identities.json'),
                             source_diff=receipt(scratch/'scaffold-review-corrections.diff'),
                             candidate_vs_B=receipt(scratch/'candidate-vs-B.diff'),
                             candidate_vs_original=receipt(scratch/'candidate-vs-original.diff')),
    authorization_inputs=initial['inputs'],
    reviewed_source_identities=[receipt(source/p) for p in relevant_paths],
    primary_source=dict(title='SCAFFOLD: Stochastic Controlled Averaging for Federated Learning',
                        url='https://arxiv.org/pdf/1910.06378v4',revision='v4,9 April2021',
                        verification='Primary PDF browsed directly; Algorithm1/Eqs3-5 read. Exact retained first-review PDF copied read-only into owned scratch and hash preserved.',
                        artifact=receipt(scratch/'primary-paper-1910.06378v4.pdf'),
                        local='y_next=y-eta*(g-ci+c)',option_II='ci_new=ci-c+(x-y)/(K*eta)',
                        population='c_new=c+sum(delta_ci)/N',paper_model='uniform participating-client average with eta_global=1',
                        inference='Telescoping constant-rate vanilla SGD gives ci_new=mean(used gradients). Main equations take precedence over the appendix19 sign typo; no appendix reversal adopted.',
                        extension_limit='Post-optimizer momentum/Adam correction and unequal-count sample-weighted model averaging are extensions, with no paper convergence claim.'),
    accepted_contract_review=contract_review,
    original_review_disposition=dict(
        F27_R01='Exact original raw NaN/missing/broadcast malformed models now reject with x1,c2 unchanged and no stage. Additional server callback coverage fails as F27-R2-01, so full A08 remains open.',
        F27_R02='Exact original failed spawn missing handoff retains ci1, clears delta, survives1->2->1/fresh reconstruction and successful retry .62/.9/-.1; server control equals mean retained ci. Direct/process end-lifecycle inconsistency remains F27-R2-02.',
        retained_originals=[receipt(p) for p in sorted((scratch/'originals').glob('*.py'))],
        adapted_probes=[receipt(scratch/p) for p in ['server_reproducer.py','worker_failure_reproducer.py','independent_checks.py','boundary_checks.py']],
        adaptation='Retained originals unchanged. Replaced only immutable source/scratch roots in the numerical harness. Explicitly replaced defect assertions: server now requires validation error and x1,c2/no stage; worker reuse/fresh ci1 and retry .62/.9/-.1 replace .9 and .601/.895/-.005, and population inequality becomes equality. Original root equation probe is retained/read as historical evidence; actual-optimizer hook oracles supersede its synthetic learning_rate setup.'),
    independently_executed=dict(
        pytest=dict(count_each=166,python_versions=['3.13.16','3.14.8'],skips_each=0,warnings_each=0,
                    modules=dict(scaffold_strategy=32,scaffold_round_flow=54,training_update_contract=28,
                                 personalized_state_ownership=16,checkpoint_path_contract=14,composable_trainer=22),
                    interpretation='86 SCAFFOLD tests plus80 affected shared trainer tests per version. These counts are independent reruns, not the author523 profile or all55 new cases across six fixes.'),
        passing_probes=checks,
        material_failure_probes=callback_results,
        failure_probe_interpretation='callback313/314 exit0 asserts demonstrated defects; not passing acceptance cases.',
        numerical_tolerances='float64 exact-equation comparisons use abs error<1e-12. The explicit compatible float32 transport control uses1e-6; actual4.3333330154418945 versus rational13/3.',
        environments={v:read(f'environment-{v}.json') for v in ['313','314']},
        import_integrity='Every loaded plato/tests/SCAFFOLD source module in environment probes resolves beneath the immutable candidate, despite read-only use of existing author interpreters.',
        ruff='ruff check . --select I --no-cache: PASS'),
    command_records=commands,
    author_evidence=dict(final_combined=scope['author_final_combined'],log_verification=scope['author_log_verification'],
                         startup=scope['startup_receipts'],scope_receipt=receipt(scratch/'scope-and-receipts.json'),
                         interpretation='Author523 passes and17 visible Opacus notices each are broader C+B selection receipts, including48 startup cases each; not attributed to this SCAFFOLD review or independently rerun here. All55 new author cases cover six corrections, not55 SCAFFOLD-only cases.',
                         startup_verification='Accepted-B startup test/harness/probe hashes independently match this candidate. Hashes of retained combined execution logs match author receipts. The48 startup cases were not repeated.',
                         limits='No independent acceptance of AMP/clipping, cleanup, FedALA/FedDyn filename corrections, FedDyn equations, F28 startup-resume supplement or overall Phase2 follows from these receipts.'),
    public_contract_handoff=dict(
        facts=receipt(source/'evidence/2026-refresh/phase2c-scaffold-facts.json'),
        observed_changes='Raw model transport keys/tensor/exact shape/finite/dtype cast are now validated before initial control staging. Canonical same-path ci persistence moved from provisional on_train_end to direct acceptance or validated current-token/client model+control parent handoff; child no longer writes canonical controls.',
        unchanged='Equations, positive constant actual LR/K restrictions, population-N control denominator, inherited sample-weighted model policy, shipped TOML values and FedProx legacy unsquared-L2/l1 objectives remain unchanged.',
        facts_limit='The unconditional failed-attempt persistence guarantee must not be presented as finally accepted while F27-R2-02 remains. Server atomicity must include the callback cases in F27-R2-01. Final writer reconciliation must follow the next accepted code snapshot.',
        provisional_docs='95c7218fc9801099cd7ffa3afc1be227384d8500 has provisional writing PASS against0dc/62d. Existing source reconciliation ends at62d, predating these source changes. No prose edits or missing-doc finding made in this worktree.',
        docs_receipts=[receipt(Path('/Users/bli/Playground/plato/evidence/2026-refresh')/p) for p in ['phase2c-scaffold-docs-review.json','phase2c-scaffold-docs-source-reconciliation.json']]),
    preservation=dict(B=scope['checks'],shipped_TOML_values_equal_B=True,
                      config_bytes='SCAFFOLD config differs from B only by the already-reviewed explanatory comment; all parsed values equal B. Corrections since62d leave it unchanged.',
                      FedProx='Source/TOML unchanged since original reviewed candidate. Independent d=(3,4),mu2 legacyL2 loss5,gradient(.6,.8); L1 loss14,gradient(2,2); zero-distance gradients finite andmu0 leaves zero base gradient. No squared-norm migration.',
                      server_base='Contains prior C checkpoint-codec changes; unchanged since62d. F28 supplement remains B/root-owned and unaccepted here.'),
    reviewer_harness_limits=dict(
        retained_failed_attempts=['transport313','transport314'],
        explanation='The first additional transport probe incorrectly reused the1e-12 float64 tolerance for float32 population controls. Both runs reached the final assertion with finite control4.3333330154418945. The original script and logs remain; final v2 uses1e-6 for this explicit float32 case and passes all13 assertions. This was a reviewer tolerance error, not a candidate finding.',
        spawned_negative_bound='Delivered four failure-mode spawn tests and positive spawn use bounded60-second subprocess harnesses. Independent commands have360-second deadlines and completed; no external-network or convergence qualification is implied.'),
    scope_limits=['CPU PyTorch float64/float32 in-process real client/server payloads and actual multiprocessing spawn only; no SCAFFOLD network/dataset/GPU/MPS/CUDA or convergence benchmark.',
                  'No full server/optimizer/RNG restart guarantee invented or required. Reuse/reconstruction/retry concerns only the promised logical-client controls.',
                  'Generic ComposableTrainer/base/composite strategy lifecycle changes inspected and default/shared trainer tests run; no universal transaction claim for arbitrary composed plugins.',
                  'General AMP/cleanup/FedALA/FedDyn filename review, FedDyn mathematical design and B F28 supplement remain separate; no acceptance granted here.',
                  'Full mandatory project suite and48 startup cases not rerun; only identified focused selection and retained author receipts used.',
                  'Code acceptance and final public-prose reconciliation remain required; missing prose in this immutable worktree is not a blocker finding.'],
    required_next_step='Root returns the two material boundary findings to the original C author for bounded fixes, then assigns another fresh independent reviewer. Preserve original probes and exact candidate/report identities; no unassigned redesign or user-permission detour.',
    workflow=dict(shell='All shell invocations use zsh -lc; subprocess shells likewise.',agents_spawned=0,
                  source_edits=0,commits=0,pushes=0,environment_modifications=0,cleanup=0,
                  only_root_write=str(destination),owned_scratch=str(scratch),retained=True,
                  source_clean=True,source_immutable=True,
                  interpreter_use='Existing author Python environments read-only; PYTHONPATH/cwd pinned, PYTHONDONTWRITEBYTECODE=1, pytest cache disabled, unique scratch basetemps/TMPDIR/cache directories. No evolving training/runtime source read.'),
    retained_artifacts=[receipt(p) for p in sorted(scratch.iterdir()) if p.is_file()]
)
destination.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
assert git('status','--porcelain=v1','--ignored') == ''
assert git('rev-parse','HEAD') == candidate
print(json.dumps(dict(report=receipt(destination),decision=report['decision'],
                      findings=report['finding_counts'],source_clean=True),indent=2))
