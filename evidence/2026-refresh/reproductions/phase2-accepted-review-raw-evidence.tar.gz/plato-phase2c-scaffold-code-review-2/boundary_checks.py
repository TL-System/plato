import copy
import importlib.metadata
import json
import logging
import sys
from pathlib import Path

import independent_checks as p
import torch
from torch.utils.data import TensorDataset

from plato.trainers import optimizers
from plato.trainers.strategies.algorithms.fedprox_strategy import FedProxLossStrategy
from plato.trainers.strategies.training_step import MixedPrecisionStepStrategy

class Warnings(logging.Handler):
    def __init__(self): super().__init__(); self.messages=[]
    def emit(self,record):
        if 'additive-control optimizer extension' in record.getMessage():
            self.messages.append(record.getMessage())

def extensions(root):
    out=[]
    for name in ('SGD','Adam'):
        cfg=p.config(rate=.01)
        cfg['trainer']['optimizer']=name
        if name=='SGD': cfg['parameters']['optimizer']['momentum']=.9
        else: cfg['parameters']['optimizer']={'lr':.01}
        runtime=root/name;runtime.mkdir(parents=True,exist_ok=True)
        with p.configure_environment(cfg,runtime_root=runtime):
            ctx=p.TrainingContext();ctx.model=p.Scalar();ctx.client_id=1
            st=p.SCAFFOLDUpdateStrategy();st.setup(ctx)
            st.client_control_variate=p.controls(1);ctx.state['server_control_variate']=p.controls(2)
            st.on_train_start(ctx)
            opt=optimizers.get(ctx.model);ctx.state['optimizer']=opt
            raw_model=p.Scalar()
            raw=(torch.optim.SGD(raw_model.parameters(),lr=.01,momentum=.9,weight_decay=0)
                 if name=='SGD' else torch.optim.Adam(raw_model.parameters(),lr=.01))
            sink=Warnings();logging.getLogger().addHandler(sink)
            try:
                st.before_step(ctx)
                for gradient in (3.,1.):
                    opt.zero_grad();raw.zero_grad()
                    (ctx.model.theta*gradient).sum().backward()
                    (raw_model.theta*gradient).sum().backward()
                    raw.step()
                    with torch.no_grad():raw_model.theta.sub_(.01)
                    opt.step();st.after_step(ctx)
                st.on_train_end(ctx)
            finally:
                logging.getLogger().removeHandler(sink)
                st.on_train_cleanup(ctx,successful=True)
            p.close(ctx.model.theta.item(),raw_model.theta.item())
            reference_ci=1-2+(1-raw_model.theta.item())/.02
            p.close(st.client_control_variate['theta'].item(),reference_ci)
            assert len(sink.messages)==1
            out.append(dict(optimizer=name,parameters=cfg['parameters']['optimizer'],
                y=ctx.model.theta.item(),raw_plus_correction=raw_model.theta.item(),
                ci=st.client_control_variate['theta'].item(),reference_ci=reference_ci,
                warning_count=len(sink.messages),warning=sink.messages[0]))
    return out

def skipped(root):
    root.mkdir(parents=True,exist_ok=True)
    cfg=p.config();cfg['trainer'].update(batch_size=1,epochs=1)
    with p.configure_environment(cfg,runtime_root=root):
        step=MixedPrecisionStepStrategy(enabled=False)
        st=p.SCAFFOLDUpdateStrategy()
        tr=p.ComposableTrainer(model=p.Scalar(),model_update_strategy=st,training_step_strategy=step)
        tr.set_client_id(1)
        st.client_control_variate=p.controls(1)
        tr.context.state['server_control_variate']=p.controls(2)
        step.enabled=True;step.scaler=torch.amp.GradScaler('cpu')
        factor=[float('inf')]
        tr.loss_strategy.compute_loss=lambda outputs,labels,context: ((outputs-labels)**2).mean()/2*factor[0]
        data=TensorDataset(torch.ones(1,1,dtype=torch.float64),torch.zeros(1,1,dtype=torch.float64))
        run={**cfg['trainer'],'run_id':'real-cpu-scaler'}
        scale=step.scaler.get_scale()
        tr.train_model(run,data,torch.utils.data.SequentialSampler(data))
        p.close(tr.model.theta.item(),1);p.close(st.local_steps,0)
        p.close(st.client_control_variate['theta'].item(),1)
        p.close(st.get_update_payload(tr.context)['control_variate_delta']['theta'].item(),0)
        assert step.scaler.get_scale()<scale
        factor[0]=1.
        tr.train_model(run,data,torch.utils.data.SequentialSampler(data))
        p.close(tr.model.theta.item(),.8);p.close(st.local_steps,1)
        p.close(st.client_control_variate['theta'].item(),1)
        return dict(overflow=dict(y=1,K=0,ci=1,delta=0),
            subsequent_success=dict(y=tr.model.theta.item(),K=st.local_steps,
                ci=st.client_control_variate['theta'].item()),
            hardware='CPU GradScaler; CUDA autocast disabled because no GPU')

def fedprox():
    out=[]
    model=torch.nn.Linear(2,1,bias=False,dtype=torch.float64)
    with torch.no_grad():model.weight.zero_()
    ctx=p.TrainingContext();ctx.model=model
    for norm,mu in (('l2',2.),('l1',2.),('l2',0.)):
        with torch.no_grad():model.weight.zero_()
        st=FedProxLossStrategy(mu=mu,norm_type=norm,base_loss_fn=lambda outputs,labels: outputs.sum()*0)
        st.setup(ctx)
        zero=st.compute_loss(model(torch.ones(1,2,dtype=torch.float64)),torch.zeros(1),ctx)
        model.zero_grad();zero.backward()
        assert torch.isfinite(model.weight.grad).all()
        with torch.no_grad():model.weight.copy_(torch.tensor([[3.,4.]],dtype=torch.float64))
        model.zero_grad()
        loss=st.compute_loss(model(torch.ones(1,2,dtype=torch.float64)),torch.zeros(1),ctx)
        loss.backward()
        expected=([.6,.8] if norm=='l2' and mu else [2.,2.] if norm=='l1' else [0.,0.])
        for a,b in zip(model.weight.grad.flatten(),expected):p.close(a,b)
        out.append(dict(norm=norm,mu=mu,loss=loss.item(),actual_gradient=model.weight.grad.flatten().tolist(),analytical_legacy_gradient=expected))
    return out

if __name__=='__main__':
    version=''.join(sys.version_info[:2].__str__().replace('(','').replace(')','').replace(', ','').split())
    version=f'{sys.version_info.major}{sys.version_info.minor}'
    root=p.SCRATCH/f'boundary-{version}'
    root.mkdir(parents=True,exist_ok=True)
    result=dict(extensions=extensions(root/'extensions'),real_skipped_steps=skipped(root/'skipped'),
        fedprox_legacy_semantics=fedprox(),
        environment={name:importlib.metadata.version(name) for name in
            ('torch','torchvision','numpy','pytest','ruff','opacus','safetensors','timm')},
        python=sys.version,executable=sys.executable)
    (p.SCRATCH/f'boundary-{version}.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
