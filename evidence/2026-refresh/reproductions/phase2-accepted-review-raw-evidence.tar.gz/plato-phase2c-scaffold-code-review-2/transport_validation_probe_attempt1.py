"""Additional dtype, zero-weight control and inherited buffer transport checks."""
import asyncio
import copy
import json
import sys
from types import SimpleNamespace

import independent_checks as p
import torch


class TransportModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.theta = torch.nn.Parameter(torch.tensor([1.], dtype=torch.float32))
        self.frozen = torch.nn.Parameter(torch.tensor([4.]), requires_grad=False)
        self.register_buffer('flag', torch.tensor([False]))
        self.register_buffer('count', torch.tensor([0], dtype=torch.int64))

    def forward(self, data):
        return data*self.theta


if __name__ == '__main__':
    version = f'{sys.version_info.major}{sys.version_info.minor}'
    root = p.SCRATCH/f'transport-validation-{version}'
    root.mkdir(parents=True, exist_ok=True)
    records = []
    with p.configure_environment(p.config(), runtime_root=root):
        client = p.client(1)
        client.trainer.model_update_strategy.client_control_variate = p.controls(1)
        report = p.train_round(client, [p.controls(1), p.controls(2)], 1,0.,2).report
        for defect in ['model-cast-overflow', 'control-cast-overflow', 'control-integer']:
            for position in [0,1]:
                for count in [0,2]:
                    s = p.scaffold_server.Server(model=TransportModel, trainer=p.RecordingTrainer)
                    s.init_trainer()
                    s.context.trainer,s.context.algorithm = s.trainer,s.algorithm
                    s.server_control_variate = p.controls(2)
                    before = copy.deepcopy(s.algorithm.extract_weights())
                    updates = []
                    for samples,y,dc in [(2,7.,3.),(6,9.,4.)]:
                        weights = copy.deepcopy(before)
                        weights['theta'].fill_(y)
                        item = SimpleNamespace(report=copy.copy(report),payload=[weights,p.controls(dc)])
                        item.report.num_samples = samples
                        updates.append(item)
                    bad = updates[position]
                    bad.report.num_samples = count
                    value = torch.tensor([1e300], dtype=torch.float64)
                    if defect == 'model-cast-overflow':
                        bad.payload[0]['theta'] = value
                    elif defect == 'control-cast-overflow':
                        bad.payload[1]['theta'] = value
                    else:
                        bad.payload[1]['theta'] = torch.tensor([3], dtype=torch.int64)
                    originals = [p.serialize_tree(u.payload) for u in updates]
                    s.updates = updates
                    error = None
                    try:
                        asyncio.run(s._process_reports())
                    except ValueError as exc:
                        error = str(exc)
                    assert error and 'SCAFFOLD' in error
                    for name,tensor in before.items():
                        torch.testing.assert_close(s.algorithm.extract_weights()[name], tensor)
                    p.close(s.server_control_variate['theta'].item(),2.)
                    assert s._pending_control_variate is None
                    assert originals == [p.serialize_tree(u.payload) for u in updates]
                    records.append(dict(defect=defect,position=position,sample_weight=count,error=error))
        s = p.scaffold_server.Server(model=TransportModel,trainer=p.RecordingTrainer)
        s.init_trainer()
        s.context.trainer,s.context.algorithm=s.trainer,s.algorithm
        s.server_control_variate=p.controls(2)
        baseline=s.algorithm.extract_weights()
        s.updates=[]
        for samples,y,flag,count,dc in [(2,7.,.2,1.5,3.),(6,9.,.8,5.5,4.)]:
            weights=copy.deepcopy(baseline)
            weights['theta']=torch.tensor([y],dtype=torch.float64)
            weights['flag']=torch.tensor([flag],dtype=torch.float32)
            weights['count']=torch.tensor([count],dtype=torch.float32)
            item=SimpleNamespace(report=copy.copy(report),payload=[weights,p.controls(dc)])
            item.report.num_samples=samples
            s.updates.append(item)
        originals=[p.serialize_tree(u.payload) for u in s.updates]
        asyncio.run(s._process_reports())
        actual=s.algorithm.extract_weights()
        p.close(actual['theta'].item(),8.5)
        assert actual['flag'].item() is True
        assert actual['count'].item()==4
        assert actual['frozen'].item()==4.
        p.close(s.server_control_variate['theta'].item(),13/3)
        assert originals==[p.serialize_tree(u.payload) for u in s.updates]
        result=dict(python=sys.version,validation_cases=records,
                    inherited_buffers=dict(theta=8.5,flag=True,count=4,frozen=4.,control=13/3),
                    count=13,interpretation='All rejection and compatible transport assertions passed.')
    (p.SCRATCH/f'transport-validation-{version}.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
