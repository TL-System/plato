"""Independent actual report-callback and trainer acceptance failure probes."""
import asyncio
import copy
import json
import pickle
import sys
from pathlib import Path
from types import SimpleNamespace

import independent_checks as p
import torch
from plato.callbacks.server import ServerCallback
from plato.trainers.strategies.training_step import GradientAccumulationStepStrategy


class CallbackFailure(ServerCallback):
    def __init__(self, event):
        self.event = event

    def on_weights_received(self, server, weights):
        if self.event == 'received':
            raise RuntimeError('Independent received callback failure')
        if self.event == 'metadata':
            server.updates[-1].report.num_samples = -1
        if self.event == 'model-mutation':
            weights[-1]['theta'].fill_(float('nan'))

    def on_weights_aggregated(self, server, updates):
        if self.event == 'aggregated':
            raise RuntimeError('Independent aggregated callback failure')


class EndFailure(GradientAccumulationStepStrategy):
    def on_train_end(self, context):
        super().on_train_end(context)
        raise RuntimeError('Independent training-step end failure')


def error_of(fn):
    try:
        fn()
    except Exception as exc:
        return f'{type(exc).__name__}: {exc}'
    return None


def server_probes(root):
    records = []
    for mode in ['received', 'metadata', 'aggregated', 'model-mutation']:
        runtime = root/mode
        runtime.mkdir(parents=True, exist_ok=True)
        with p.configure_environment(p.config(), runtime_root=runtime):
            s = p.server()
            s.server_control_variate = p.controls(2)
            client = p.client(1)
            client.trainer.model_update_strategy.client_control_variate = p.controls(1)
            report = p.train_round(client, [p.controls(1), p.controls(2)], 1, 0., 2).report
            s.updates = [SimpleNamespace(report=copy.copy(report), payload=[p.controls(y), p.controls(dc)])
                         for y, dc in [(7., 3.), (9., 4.)]]
            s.callback_handler.add_callback(CallbackFailure(mode))
            original = [p.serialize_tree(u.payload) for u in s.updates]
            error = error_of(lambda: asyncio.run(s._process_reports()))
            x = s.trainer.model.theta.item()
            record = dict(mode=mode, before=dict(x=1., c=2.), error=error,
                          actual_x=x if torch.isfinite(s.trainer.model.theta).all() else 'NaN',
                          actual_c=s.server_control_variate['theta'].item(),
                          pending_controls=s._pending_control_variate is not None,
                          retained_received_controls=s.received_client_control_variates is not None,
                          raw_inputs_unchanged=original == [p.serialize_tree(u.payload) for u in s.updates])
            if mode == 'received':
                s.updates[-1].report.num_samples = -1
                record['later_bad_metadata_error'] = error_of(lambda: asyncio.run(s._process_reports()))
                record['pending_after_later_bad_metadata'] = s._pending_control_variate is not None
                assert record['pending_after_later_bad_metadata']
            if mode in ['received', 'metadata']:
                assert error is not None and record['pending_controls']
                p.close(x, 1.)
                p.close(record['actual_c'], 2.)
            elif mode == 'aggregated':
                assert error is not None
                p.close(x, 8.)
                p.close(record['actual_c'], 13/3)
            else:
                assert error is None and record['actual_x'] == 'NaN'
                p.close(record['actual_c'], 13/3)
            records.append(record)
    return records


def trainer_probes(root):
    records = []
    for interface in ['train_model', 'train_process']:
        for existing in [False, True]:
            runtime = root/f'{interface}-{existing}'
            runtime.mkdir(parents=True, exist_ok=True)
            with p.configure_environment(p.config(), runtime_root=runtime):
                client = p.client(1)
                trainer = client.trainer
                st = trainer.model_update_strategy
                st.client_control_variate = p.controls(1)
                canonical = Path(st.client_control_variate_path)
                if existing:
                    canonical.write_bytes(pickle.dumps(p.controls(1)))
                trainer.context.state['server_control_variate'] = p.controls(2)
                trainer.training_step_strategy = EndFailure(1)
                data = torch.utils.data.TensorDataset(torch.ones(2,1,dtype=torch.float64), torch.zeros(2,1,dtype=torch.float64))
                sampler = torch.utils.data.SequentialSampler(data)
                run = {**p.config()['trainer'], 'run_id':'end-failure'}
                error = error_of(lambda: getattr(trainer, interface)(run, data, sampler))
                outbound_error = error_of(lambda: st.get_update_payload(trainer.context))
                persisted = pickle.loads(canonical.read_bytes())['theta'].item() if canonical.exists() else None
                record = dict(interface=interface, existing_canonical=existing,
                              error=error, actual_ci=st.client_control_variate['theta'].item(),
                              persisted_ci=persisted, outbound_error=outbound_error,
                              expected_ci=1., expected_persisted_ci=1. if existing else None,
                              optimizer_hook_still_registered=bool(trainer.optimizer._optimizer_step_pre_hooks))
                assert error and 'training-step end failure' in error
                if interface == 'train_model':
                    p.close(persisted,.9)
                    assert outbound_error is None
                else:
                    p.close(record['actual_ci'],1.)
                    assert persisted == (1. if existing else None)
                    assert outbound_error is not None
                for cid in [2,1]:
                    client.client_id = client._context.client_id = cid
                    client.configure()
                reconstructed = p.client(1)
                fresh_ci = reconstructed.trainer.model_update_strategy.client_control_variate
                record['after_reconstruction_ci'] = fresh_ci['theta'].item() if fresh_ci else None
                trainer.training_step_strategy = GradientAccumulationStepStrategy(1)
                retry = p.train_round(client, [p.controls(1),p.controls(2)], 2,0.,2)
                record['successful_retry'] = dict(y=trainer.model.theta.item(),ci=st.client_control_variate['theta'].item(),delta=retry.payload[1]['theta'].item())
                if interface == 'train_model':
                    p.close(record['successful_retry']['y'],.601)
                    p.close(record['successful_retry']['ci'],.895)
                    p.close(record['successful_retry']['delta'],-.005)
                elif existing:
                    p.close(record['successful_retry']['y'],.62)
                    p.close(record['successful_retry']['ci'],.9)
                    p.close(record['successful_retry']['delta'],-.1)
                records.append(record)
    return records


if __name__ == '__main__':
    version = f'{sys.version_info.major}{sys.version_info.minor}'
    root = p.SCRATCH/f'callback-lifecycle-{version}'
    result = dict(python=sys.version, torch=torch.__version__,
                  server=server_probes(root/'server'), trainer=trainer_probes(root/'trainer'),
                  interpretation='Exit zero asserts the remaining defects and direct-process comparison; not an acceptance pass.')
    (p.SCRATCH/f'callback-lifecycle-{version}.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
