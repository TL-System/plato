import importlib.metadata
import json
import platform
import sys
from pathlib import Path

import independent_checks as p

modules = {}
for name, module in list(sys.modules.items()):
    if name == 'plato' or name.startswith(('plato.', 'tests.', 'scaffold_')):
        filename = getattr(module, '__file__', None)
        if filename:
            path = Path(filename).resolve()
            assert path.is_relative_to(p.CANDIDATE), (name, str(path))
            modules[name] = str(path)
result = dict(python=sys.version, executable=sys.executable,
              platform=platform.platform(), cwd=str(Path.cwd()),
              imported_source_modules=modules, versions={name:importlib.metadata.version(name)
                 for name in ['torch','torchvision','timm','numpy','opacus','pytest','ruff','safetensors']})
version = f'{sys.version_info.major}{sys.version_info.minor}'
(p.SCRATCH/f'environment-{version}.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
