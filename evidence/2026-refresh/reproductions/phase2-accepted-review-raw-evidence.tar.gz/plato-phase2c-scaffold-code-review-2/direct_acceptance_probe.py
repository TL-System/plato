"""Direct callbacks, model-save and atomic replacement failure followed by retry."""
import json
import os
import pickle
import sys
from pathlib import Path

import independent_checks as p
import torch
from plato.callbacks.trainer import TrainerCallback


class RunEndFailure(TrainerCallback):
    def on_train_run_end(self, trainer, config, **kwargs):
        raise RuntimeError('Independent run callback failure')


def io_failure(*args, **kwargs):
    raise OSError('Independent save/atomic replacement failure')


if __name__ == '__main__':
    version = f'{sys.version_info.major}{sys.version_info.minor}'
    root = p.SCRATCH/f'direct-acceptance-{version}'
    records = []
    for interface, failures in [('train_model',['callback','atomic-replace']),
                                ('train_process',['callback','model-save','atomic-replace'])]:
        for failure in failures:
            for existing in [False,True]:
                runtime = root/f'{interface}-{failure}-{existing}'
                runtime.mkdir(parents=True,exist_ok=True)
                with p.configure_environment(p.config(),runtime_root=runtime):
                    client = p.client(1)
                    trainer,st=client.trainer,client.trainer.model_update_strategy
                    old_ci = 1. if existing else 0.
                    st.client_control_variate=p.controls(old_ci)
                    trainer.context.state['server_control_variate']=p.controls(2)
                    canonical=Path(st.client_control_variate_path)
                    original=None
                    if existing:
                        canonical.write_bytes(pickle.dumps(p.controls(old_ci)))
                        original=canonical.read_bytes()
                    callback=RunEndFailure()
                    save,replace=trainer.save_model,os.replace
                    if failure=='callback':trainer.callback_handler.add_callback(callback)
                    elif failure=='model-save':trainer.save_model=io_failure
                    else:os.replace=io_failure
                    data=torch.utils.data.TensorDataset(torch.ones(2,1,dtype=torch.float64),torch.zeros(2,1,dtype=torch.float64))
                    run={**p.config()['trainer'],'run_id':'acceptance-failure'}
                    error=None
                    try:
                        getattr(trainer,interface)(run,data,torch.utils.data.SequentialSampler(data))
                    except (OSError,RuntimeError) as exc:
                        error=f'{type(exc).__name__}: {exc}'
                    finally:
                        trainer.save_model=save
                        os.replace=replace
                        trainer.callback_handler.callbacks=[cb for cb in trainer.callback_handler.callbacks if cb is not callback]
                    assert error is not None
                    p.close(st.client_control_variate['theta'].item(),old_ci)
                    assert canonical.exists() is existing
                    if existing:assert canonical.read_bytes()==original
                    assert not list(canonical.parent.glob('.scaffold_cv_*'))
                    refused=False
                    try:st.get_update_payload(trainer.context)
                    except RuntimeError:refused=True
                    assert refused
                    for cid in [2,1]:
                        client.client_id=client._context.client_id=cid
                        client.configure()
                    fresh=p.client(1)
                    for actual in [st,fresh.trainer.model_update_strategy]:
                        retained=actual.client_control_variate
                        p.close(retained['theta'].item() if retained else 0.,old_ci)
                    result=p.train_round(client,[p.controls(1),p.controls(2)],2,0.,2)
                    # Independent two-step quadratic and Option II arithmetic.
                    y=1.
                    gradients=[]
                    for _ in range(2):
                        gradients.append(y)
                        y-=.1*(y-old_ci+2)
                    new_ci=sum(gradients)/2
                    delta=new_ci-old_ci
                    p.close(trainer.model.theta.item(),y)
                    p.close(st.client_control_variate['theta'].item(),new_ci)
                    p.close(result.payload[1]['theta'].item(),delta)
                    inactive=(3.,2.) if existing else (3.,3.)
                    p.close(2+delta/3,(new_ci+sum(inactive))/3)
                    persisted=pickle.loads(canonical.read_bytes())['theta'].item()
                    p.close(persisted,new_ci)
                    records.append(dict(interface=interface,failure=failure,existing_canonical=existing,
                                        error=error,last_accepted_ci=old_ci,outbound_refused=True,
                                        successful_retry=dict(y=y,ci=new_ci,delta=delta),
                                        population_invariant=True))
    result=dict(python=sys.version,count=len(records),cases=records)
    (p.SCRATCH/f'direct-acceptance-{version}.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
