"""F27 A08 negative model-half reproducer through actual report dispatch."""
import asyncio
import copy
import json
import sys
from collections import OrderedDict
from pathlib import Path
from types import SimpleNamespace

import independent_checks as p
import torch

version=f'{sys.version_info.major}{sys.version_info.minor}'
root=p.SCRATCH/f'server-reproducer-{version}'
root.mkdir(parents=True,exist_ok=True)
records=[]
cases=[('nan',p.controls(float('nan'))),('missing',{}),
       ('broadcast',OrderedDict(theta=torch.tensor(9.,dtype=torch.float64)))]
for name,bad_weights in cases:
    runtime=root/name;runtime.mkdir(exist_ok=True)
    with p.configure_environment(p.config(),runtime_root=runtime):
        server=p.server();server.server_control_variate=p.controls(2)
        # Obtain an actual successful example report (all runtime fields included).
        client=p.client(1)
        client.trainer.model_update_strategy.client_control_variate=p.controls(1)
        successful=p.train_round(client,[p.controls(1),p.controls(2)],1,0.,2)
        report=successful.report
        assert report.num_samples==2
        before=dict(x=server.trainer.model.theta.item(),c=server.server_control_variate['theta'].item())
        server.updates=[SimpleNamespace(report=report,payload=[p.controls(7),p.controls(3)]),
            SimpleNamespace(report=copy.copy(report),payload=[bad_weights,p.controls(4)])]
        error=None
        try:asyncio.run(server._process_reports())
        except Exception as exc:error=f'{type(exc).__name__}: {exc}'
        actual_x=server.trainer.model.theta.item()
        actual_c=server.server_control_variate['theta'].item()
        records.append(dict(case=name,before=before,model_half=str(bad_weights),
            controls='finite theta deltas 3 and 4, N=3',
            expected='SCAFFOLD validation failure before model/control mutation: x=1,c=2',
            actual_x='NaN' if not torch.isfinite(server.trainer.model.theta).all() else actual_x,
            actual_c=actual_c,exception=error,pending_controls=server._pending_control_variate is not None,
            report_fields=sorted(vars(report))))
        assert actual_c==before['c']
        assert error is not None
        assert server._pending_control_variate is None
        assert server.received_client_control_variates is None
        p.close(actual_x,before['x'])
result=dict(python=sys.version,torch=torch.__version__,reproductions=records,
    interpretation='Adapted original reproducer now asserts corrected whole-batch rejection and unchanged state.')
(p.SCRATCH/f'server-reproducer-{version}.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
