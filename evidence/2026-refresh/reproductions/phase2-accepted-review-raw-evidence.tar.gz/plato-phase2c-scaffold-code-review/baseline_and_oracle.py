import hashlib
import json
import subprocess
import sys
import types
from pathlib import Path

import independent_checks as p
import torch

base='00eeb9dcdd2b513e64db9408969356037e09bb8e'
source=subprocess.check_output(['zsh','-lc',f'git show {base}:plato/trainers/strategies/algorithms/scaffold_strategy.py'],cwd=p.CANDIDATE)
(p.SCRATCH/'scaffold_strategy_at_B.py').write_bytes(source)
module=types.ModuleType('scaffold_at_B')
exec(compile(source,'scaffold_strategy_at_B.py','exec'),module.__dict__)
version=f'{sys.version_info.major}{sys.version_info.minor}'
runtime=p.SCRATCH/f'baseline-{version}';runtime.mkdir(parents=True,exist_ok=True)
with p.configure_environment(p.config(),runtime_root=runtime):
    ctx=p.TrainingContext();ctx.model=torch.nn.Linear(1,1,bias=False,dtype=torch.float64);ctx.client_id=1
    with torch.no_grad():ctx.model.weight.fill_(1)
    ctx.device=torch.device('cpu')
    ctx.state.update(learning_rate=.1,server_control_variate={'weight':torch.tensor([[2.]],dtype=torch.float64)})
    st=module.SCAFFOLDUpdateStrategy();st.setup(ctx)
    st.client_control_variate={'weight':torch.tensor([[1.]],dtype=torch.float64)};st.on_train_start(ctx)
    optimizer=torch.optim.SGD(ctx.model.parameters(),lr=.1)
    (ctx.model.weight*0).sum().backward();optimizer.step();st.after_step(ctx);st.on_train_end(ctx)
    observed=dict(y=ctx.model.weight.item(),ci=st.client_control_variate['weight'].item(),delta=ctx.state['client_control_variate_delta']['weight'].item())
    assert abs(observed['y']-.9)>.15
    assert abs(observed['ci'])>.9
result=dict(base=base,baseline_source_sha256=hashlib.sha256(source).hexdigest(),
    observed_baseline=observed,expected_correct=dict(y=.9,ci=0,delta=-1),
    unequal_oracle=p.oracle()[0],equal_oracle=p.oracle(equal=True)[0],
    appendix19_sign_counterexample=dict(g=0,c=2,ci=1,eta=.1,displacement=.1,
        correct_ci=0,reversed_expression=2))
(p.SCRATCH/f'baseline-and-oracle-{version}.json').write_text(json.dumps(result,indent=2,default=str)+'\n')
print(json.dumps(result,indent=2,default=str))
