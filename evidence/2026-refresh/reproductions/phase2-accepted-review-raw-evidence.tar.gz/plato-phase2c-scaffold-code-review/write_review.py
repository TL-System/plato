import hashlib
import json
import math
import subprocess
from datetime import datetime, timezone
from pathlib import Path

S=Path('/tmp/plato-phase2c-scaffold-code-review')
C=Path('/private/tmp/plato-refresh-worktrees/training')
ROOT=Path('/Users/bli/Playground/plato/evidence/2026-refresh')
DEST=ROOT/'phase2c-scaffold-code-review.json'

def read(name): return json.loads((S/name).read_text())
def receipt(path):
    p=Path(path);raw=p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def git(command):
    return subprocess.check_output(['zsh','-lc',command],cwd=C,text=True).strip()
def safe(x):
    if isinstance(x,float) and not math.isfinite(x): return str(x)
    if isinstance(x,dict): return {k:safe(v) for k,v in x.items()}
    if isinstance(x,list): return [safe(v) for v in x]
    return x

identity=read('identities.json')
commands=[json.loads(path.read_text()) for path in sorted(S.glob('*.command.json'))]
author=json.loads((C/'evidence/2026-refresh/phase2c-validation.json').read_text())
accepted=json.loads((ROOT/'phase2c-scaffold-design.json').read_text())
positive={v:read(f'independent-{v}-normal.json') for v in ('313','314')}
spawn={v:read(f'independent-{v}-spawn.json') for v in ('313','314')}
boundary={v:read(f'boundary-{v}.json') for v in ('313','314')}
server_bug={v:read(f'server-reproducer-{v}.json') for v in ('313','314')}
worker_bug={v:read(f'failed-worker-reuse-{v}.json') for v in ('313','314')}
oracle={v:read(f'baseline-and-oracle-{v}.json') for v in ('313','314')}
for v in positive: positive[v].pop('malformed_model_results',None)

findings=[
    dict(id='F27-R01',severity='high',status='OPEN',
        title='SCAFFOLD validates control halves but commits malformed model halves.',
        acceptance_contracts=['A08','A10'],
        primary_location=dict(file='examples/customized_client_training/scaffold/scaffold_server.py',line=68),
        supporting_locations=[dict(file='examples/customized_client_training/scaffold/scaffold_server.py',line=75),
            dict(file='examples/customized_client_training/scaffold/scaffold_server.py',line=85),
            dict(file='plato/servers/fedavg.py',line=203),
            dict(file='plato/servers/fedavg.py',line=217)],
        cause='weights_received validates only payload[1], appends payload[0] without checking required model keys, per-client shapes or finiteness, then stages controls. The inherited aggregator can broadcast malformed shapes or omit a client key, and load_weights accepts NaN. The final aggregated shape cannot validate each original client model.',
        concrete_reproducer=dict(source=receipt(S/'server_reproducer.py'),
            command_records=[read('server313.command.json'),read('server314.command.json')],
            steps=[
                'Use the actual shipped TOML with explicit CPU/scalar/quadratic/SGD overrides, N=3.',
                'Obtain a full valid report through actual example configure, inbound processing, training and outbound processing; num_samples=2.',
                'Initial server x=1,c=2. Supply two reports: first model theta=[7], delta theta=[3]; second delta theta=[4] with model theta=[NaN], missing theta={}, or scalar theta=9 instead of shape [1].',
                'Call actual server._process_reports(), including its inherited aggregate_weights, load_weights and weights_aggregated hooks.',
            ],
            expected='Reject the entire batch before arithmetic/commit; model x=1 and control c=2 remain unchanged.',
            actual='All three cases finish report processing without an exception. Global x becomes NaN, 3.5, or 8 respectively; c commits 13/3 in every case.',
            python_versions=['3.13.16','3.14.8'],results=server_bug),
        impact='A malformed model paired with valid controls can corrupt the global model and advance population controls. The selected whole-batch atomic model/control contract is not satisfied.',
        provenance='This does not assert a newly introduced generic B aggregation regression. It is an unclosed F27 implementation obligation in the SCAFFOLD subclass; generic B FedAvg and its adapter payload policies are unchanged.',
        bounded_correction='Validate each SCAFFOLD model half against the applicable model payload schema before staging either half, preserving existing model-buffer aggregation and accepted B adapter semantics. Add the failing raw-model cases and atomicity assertions to the SCAFFOLD integration tests.'),
    dict(id='F27-R02',severity='medium',status='OPEN',
        title='A failed worker handoff advances canonical client controls that routine reuse later adopts.',
        acceptance_contracts=['A05','A06','A10'],
        primary_location=dict(file='plato/trainers/strategies/algorithms/scaffold_strategy.py',line=304),
        supporting_locations=[dict(file='plato/trainers/strategies/algorithms/scaffold_strategy.py',line=315),
            dict(file='plato/trainers/strategies/algorithms/scaffold_strategy.py',line=133),
            dict(file='plato/trainers/composable.py',line=416),
            dict(file='plato/trainers/composable.py',line=423),
            dict(file='plato/trainers/composable.py',line=849)],
        cause='The child overwrites the canonical ci checkpoint in on_train_end before model saving/current-token state handoff is complete. A failed handoff correctly refuses outbound processing and retains old parent ci, but unsuccessful cleanup only clears transient delta. The advanced canonical ci is then loaded by normal identity reassignment or reconstruction.',
        concrete_reproducer=dict(source=receipt(S/'worker_failure_reproducer.py'),
            command_records=[read('workerfailure313-v2.command.json'),read('workerfailure314-v2.command.json')],
            steps=[
                'Real shipped max_concurrency spawn path, CPU quadratic target 0, sample_count=2, epochs=2, eta=.1. Initial x=1,c=2,ci=1; a real pre-existing canonical checkpoint stores ci=1 and fresh construction verifies it.',
                'A scratch-only trainer subclass calls the unchanged actual worker then removes its required current training-state handoff file. This is the same missing-state failure class exercised by the delivered worker negative test.',
                'Actual outbound refuses the failed handoff; parent ci remains 1 and no delta is emitted.',
                'Run ordinary configure-based logical identity reuse 1->2->1 and reconstruct client 1. Both read ci=.9 from the failed attempt.',
                'Restore the ordinary trainer and retry the same x=1,c=2. Inspect the real successful spawned model, ci and outbound delta.',
            ],
            expected='Preserve the last successful canonical ci=1 across the rejected handoff and ordinary client reuse; successful retry yields y=.62,ci=.9,delta=-.1.',
            actual='Rejected attempt leaves parent ci=1 but persisted/reloaded ci=.9. Successful retry yields y=.601,ci=.895,delta=-.005, permanently omitting the failed attempt delta=-.1.',
            numerical_consequence='For inactive ci=(3,2), applying only the successfully emitted retry delta to c=2 gives c=1.9983333333333335 while mean retained ci is 1.965. This consequence is independently calculated, not a convergence claim.',
            python_versions=['3.13.16','3.14.8'],results=worker_bug),
        impact='A detected worker failure is followed by a successful numerically stale control update after normal logical-client reuse. The parent and durable state disagree, and server/client population controls lose their invariant.',
        scope_boundary='This uses normal 1->2->1 configure reuse and fresh client reconstruction in the existing process/config, with a seeded canonical last-successful checkpoint. It does not require a full server/optimizer/RNG restart protocol.',
        bounded_correction='Stage worker controls until the parent accepts the current successful model/control handoff, or reliably restore the prior canonical controls on rejected attempts. Extend the current failed-worker test through normal client reuse and a successful retry.'),
]

details={
 'A01':dict(status='PASS',evidence=['baseline313-v2','baseline314-v2','independent313-v5','independent314-v5'],
    source='scaffold_strategy.py:254-308',
    checks='Exact B git-object real zero-gradient SGD fails at y=1.1,ci~=1,delta~=0. Candidate real float64 SGD gives (.9,0,-1) and (.4,2,1) for gradients [0] and [3,1]; ci equals independently recorded mean gradients within 1e-12. V2 also matches.'),
 'A02':dict(status='PASS',evidence=['focused313','focused314','independent313-v5','spawn313-v4','spawn314-v4'],
    source='scaffold_strategy.py:182-252; composable.py:548-551,599-600,698-699',
    checks='Inspected optimizer publication and actual public prehook capture at normal/tail steps. Executed shipped TOML Config+real optimizer-factory tests at .1/.025 and next-round .05; absent optimizer, unequal/reordered equal groups, zero/negative/NaN/Inf rates, and within-round change rejection. Post-step .025 cannot replace executed .1 correction or denominator. Failure clears outbound success and hooks.'),
 'A03':dict(status='PASS',evidence=['focused313','focused314'],
    source='scaffold_strategy.py:31-67,154-179,207-252,268-297',
    checks='Reviewed validation/projection/clones by parameter name and optimizer object identity, no substring filters. Executed theta/weight/bias/missing-gradient unused parameter, frozen/excluded parameters, floating/integer buffers and reordered equal-rate groups. Missing/unknown/shape/nonfinite control failures precede correction; inbound tensors remain unchanged; excluded ci unchanged and delta zero.'),
 'A04':dict(status='PASS',evidence=['focused313','focused314','independent313-v5','independent314-v5','boundary313','boundary314'],
    source='scaffold_strategy.py:254-299; composable.py:684-715; training_step.py:125-186,242-258',
    checks='Separate sequential-data Fraction oracle uses accumulation 2 with 1/3/4 microbatches and real gradients: K=1/2/2, normalized tail exactly once, V2 same. Subsequent empty rounds retain ci and publish zero delta. Independently executed real CPU GradScaler overflow: K=0, y=1,ci=1,delta=0; subsequent successful step K=1,y=.8. CUDA autocast is disabled; no CUDA claim.'),
 'A05':dict(status='FAIL',finding='F27-R02',evidence=['focused313','focused314','workerfailure313-v2','workerfailure314-v2'],
    source='scaffold_strategy.py:101-145,300-319; composable.py:273-285',
    passed='Normal successful 1->2->1/2 multi-round reuse matches dedicated references; fresh reconstruction and canonical precedence, exact example and prefix legacy imports, client-0 exclusion, custom root/slash containment, historical buffer projection and immediate save/load error surfacing all exercised.',
    failed='Canonical checkpoint advances despite failed handoff and contaminates subsequent ordinary identity reuse/retry.'),
 'A06':dict(status='FAIL',finding='F27-R02',evidence=['focused313','focused314','spawn313-v4','spawn314-v4','workerfailure313-v2','workerfailure314-v2'],
    source='scaffold_callback.py:27-39,54-61,70-129; composable.py:408-434,806-881',
    passed='Real configure-before-inbound pipeline runs with detached c refresh, changed c, reused processor rebinding, malformed/missing inbound c invalidation, actual direct training/outbound and successful current-token spawn return. Independent child gradient/ci/delta/K/rate traces match parent model/ci/delta. Delivered actual missing/stale handoff subprocess tests refuse immediate outbound and preserve absent delta.',
    failed='After that immediate refusal, failed child canonical controls are later adopted by normal client reassignment. Successful independent spawn probes took <26s under 240s subprocess deadlines; delivered worker harness has a 60s deadline.'),
 'A07':dict(status='PASS',evidence=['independent313-v5','independent314-v5','spawn313-v4','spawn314-v4','baseline313-v2','baseline314-v2'],
    source='scaffold.py real component wiring; scaffold_client/scaffold_callback/scaffold_trainer/scaffold_server',
    checks='Read the real committed TOML, recorded raw values and explicit synthetic CPU overrides. Actual sample counts 2/6/4, batch 6, two epochs, K=2, N=3, selected (1,2) then (1,3). Independent rational arithmetic and recorded actual autograd gradients match every local y/ci/delta, weighted x and population c. Real _process_reports used. Round 1 weighted x=1.19 vs uniform x=1, c=2/3; round 2 x=10209/10000,c=896/1125. Inactive ci retained and c equals mean all ci. Equal-count 2/2/2 two-round control reduces to uniform model reference.'),
 'A08':dict(status='FAIL',finding='F27-R01',evidence=['focused313','focused314','independent313-v5','spawn313-v4','server313','server314'],
    source='scaffold_server.py:53-96',
    passed='Partial N=3>selected=2 and unequal sample model weights preserve unsampleweighted control sum/N; next payload carries cloned controls. All delivered missing/malformed required control delta cases reject before model/control commit; full floating/integer model buffers follow inherited aggregation with parameter-only controls.',
    failed='Each model half must also be validated before arithmetic/commit. NaN, missing model key and broadcast-compatible rank mismatch currently commit both model/control state.'),
 'A09':dict(status='PASS',evidence=['focused313','focused314','boundary313','boundary314'],
    source='scaffold_strategy.py:195-205,373-379',
    checks='Unchanged shipped momentum=.9 and constant-rate Adam compose two actual raw optimizer updates with subtractive correction; independent raw optimizers and displacement Option II agree. Once-per-run extension warnings verified. Example momentum .9 uses .01 unchanged; independent constant gradients [3,1] give y=.913,ci=3.35, visibly not mean gradient 2. V2 is a compatibility subclass and no longer claims Option I.'),
 'A10':dict(status='FAIL_FOR_IMPLEMENTATION_ACCEPTANCE',findings=['F27-R01','F27-R02'],
    evidence=['identities','focused313','focused314','ruff','boundary313','boundary314'],
    passed='106 focused delivered tests pass on each supported available interpreter, no skips/xfails/assertion weakening; includes affected F07/F08/F23/F20 regressions. Independent source identities, exact B ancestry, implementation-only snapshot and raw evidence hashes checked. Ruff . --select I --no-cache passes. TOML values identical to B. FedProx independently retains unsquared L2 and l1 gradients with finite zero-distance/mu=0 behavior.',
    limitation='Author retained 468-case C+B suites and all 48 startup cases are hash-verified, not independently rerun wholesale. Separate prose review on 95c7218fc9801099cd7ffa3afc1be227384d8500 is outside this worktree/code verdict; absent prose here is not a failure. Two demonstrated code defects prevent independent implementation acceptance.'),
}
contracts=[dict(contract=item,review=details[item['id']]) for item in accepted['mandatory_acceptance']]
artifact_names=['identities.json','candidate-vs-B.diff','implementation-vs-B.diff',
    'primary-paper-1910.06378v4.pdf','run_command.py','audit_identities.py',
    'independent_checks.py','boundary_checks.py','server_reproducer.py',
    'worker_failure_reproducer.py','baseline_and_oracle.py','scaffold_strategy_at_B.py']
artifact_names += [f'{prefix}-{v}{suffix}.json' for v in ('313','314') for prefix,suffix in
    [('independent','-normal'),('independent','-spawn'),('boundary',''),
     ('server-reproducer',''),('failed-worker-reuse',''),('baseline-and-oracle','')]]

report=dict(schema_version=1,date=datetime.now(timezone.utc).isoformat(),
    role='Fresh independent SCAFFOLD F27 implementation/integration reviewer; no nested agents or source edits.',
    decision='CHANGES_REQUIRED',acceptance='FAIL',finding='F27',
    summary='The corrected research equations and successful direct/spawn/configured round paths check out, but server model-half validation and durable client controls after failed worker handoff do not satisfy the accepted contracts. One high and one medium issue are independently reproduced on Python 3.13.16 and 3.14.8. Passing delivered tests do not close these issues.',
    finding_counts=dict(critical=0,high=1,medium=1,low=0),findings=findings,low_findings=[],
    low_findings_note='No additional concrete low-severity issue recorded; stylistic recommendations are not presented as bugs.',
    immutable_candidate=dict(path=str(C),commit='62d7b7d8ef75be779149a96f567779c86699edb4',
        implementation='0dc34dd1d79d90071a0babfa6aa89f33d72a976f',
        accepted_b='00eeb9dcdd2b513e64db9408969356037e09bb8e',
        initial_status=identity['status'],final_status=git('git status --porcelain'),
        final_head=git('git rev-parse HEAD'),
        identity_receipt=receipt(S/'identities.json'),
        candidate_vs_b=identity['candidate_vs_b'],implementation_vs_b=identity['implementation_vs_b'],
        only_post_implementation_files=identity['post_implementation_files'],
        b_is_ancestor=identity['accepted_b_is_ancestor']),
    authorization_inputs=identity['input_receipts'],
    reviewed_source_identities=identity['reviewed_paths'],
    author_evidence_receipts=dict(checked_count=len(identity['receipts']),
        all_match=all(x.get('matches',True) for x in identity['receipts']),
        records=identity['receipts'],
        final_combined=author['validation']['final_combined'],
        startup_sources=identity['startup_sources'],startup_results=identity['startup_retained'],
        reason_no_full_startup_rerun='All retained B startup test/harness identities and final 468-case raw logs/socket results match their receipts. C SCAFFOLD changes do not modify the startup implementation/test contract; complementary runtime review owns broader shared checkpoint/base-runtime behavior. No all-suite pass is inferred from retained author evidence.'),
    primary_source=dict(url='https://arxiv.org/pdf/1910.06378v4',revision='v4, 9 April 2021',
        independent_read='Opened and inspected Algorithm 1 and Eq 3-5 in the versioned primary PDF through web; independently downloaded exact bytes into owned scratch.',
        retained=receipt(S/'primary-paper-1910.06378v4.pdf'),
        matches_accepted_design_review_hash=identity['primary_source']['sha256']==identity['primary_source']['expected_design_review_sha256'],
        authoritative_locations=['PDF page 4: Algorithm 1 lines 10/12/16-17, Eq 3','PDF page 5: Eq 4-5'],
        equations=dict(local='y -= eta*(g-ci+c)',option_II='ci_new=ci-c+(x-y)/(K*eta)',population_control='c += sum(delta_ci)/N'),
        independent_derivation='Summing constant-rate vanilla SGD local updates yields (x-y)/(K*eta)=mean(g)-ci+c; substituting gives ci_new=mean(g). Appendix Eq19 has the apparent reversed c/ci sign and fails the independent g=0,c=2,ci=1 displacement counterexample; main equations take priority.',
        limits='No paper convergence or mean-gradient claim for sample-weighted unequal-count global models or nonvanilla optimizers.'),
    accepted_contract_review=contracts,
    independently_executed=dict(focused_suites=dict(python313=dict(passed=106,warnings=2,skipped=0,command=read('focused313.command.json')),
            python314=dict(passed=106,warnings=2,skipped=0,command=read('focused314.command.json'))),
        numerical_and_live_results=positive,actual_spawn_results=spawn,
        extensions_skipped_steps_fedprox_and_environment=boundary,baseline_and_exact_oracle=oracle),
    command_records=commands,
    reviewer_probe_attempts=dict(retained=True,
        initial_failures='Early scratch-only attempts had CLI/bootstrap/root-directory errors. A list sampler randomized the first accumulation oracle and was replaced with an explicit SequentialSampler; initial client 2 was mistakenly seeded 2 instead of oracle ci=3 and corrected. An initial baseline theta name exercised the legacy name-filter defect; the final requested sign reproduction uses weight. These are reviewer harness corrections, not candidate findings. Raw failed attempt logs and exit statuses remain alongside final passing commands.',
        preliminary_negative_probe='The first malformed-model probe used a short synthetic report and encountered an unrelated processing_time error after committing. The authoritative server_reproducer instead obtains an actual successful complete report and verifies full report processing returns without an exception in all three malformed-model cases.',
        final_labels=['independent313-v5','independent314-v5','spawn313-v4','spawn314-v4',
            'boundary313','boundary314','server313','server314','workerfailure313-v2',
            'workerfailure314-v2','baseline313-v2','baseline314-v2']),
    preservation_of_b=dict(model_sample_weights='Real uneven 2/6 and 2/4 rounds preserve inherited B sample-weighted aggregation. Population control remains unsampleweighted sum/N.',
        source_boundaries='FedAvg algorithm/server/aggregation and optimizer factory, client composable bridge and SCAFFOLD entrypoint bytes remain exactly B. Shared C changes consumed for optimizer/state/path handoff were inspected within SCAFFOLD boundaries; no general B validation was weakened.',
        shipped_config_values_unchanged=identity['shipped_toml_values_unchanged_from_b'],
        fedprox='Independent nonzero legacy unsquared L2 example d=(3,4),mu=2 gives loss=5,gradient=(.6,.8), l1 gives loss=14,gradient=(2,2); zero-distance gradients finite and mu=0 unmodified base gradient. No squared-norm migration.'),
    exact_scope=dict(in_scope='SCAFFOLD F27 strategy/V2, example client/trainer/callback/processor/server/config integration, optimizer LR/update accounting, logical client control persistence and current worker handoff at their shared trainer/checkpoint boundaries.',
        out_of_scope=['Root FedDyn 2C-11 primary-source design disposition remains OPEN; not duplicated or accepted here.',
            'Independent prose review on branch commit 95c7218fc9801099cd7ffa3afc1be227384d8500; no failure for absent README/public prose in this immutable training worktree.',
            'Complementary broad trainer/DP/GAN/personalization/scheduler/runtime/transport/security/metadata/backend reviews and phase gate.',
            'Full mandatory suite, all 48 startup cases rerun, dataset downloads, actual network SCAFFOLD sockets, GPU/CUDA/MPS training, complete server/optimizer/RNG restart and convergence benchmarks.'],
        actual_boundary='CPU float64 independent calculations and in-process real default client/server payload pipeline; actual max_concurrency multiprocessing spawn workers and default server._process_reports. No external network or hardware claim.'),
    workflow=dict(herdr=dict(workspace_id='w1C',pane_id='w1C:p1',label='plato-scaffold-review',
        check='HERDR_ENV=1 and herdr pane current --current/workspace list verified; existing root-assigned workspace retained.'),
        agents_spawned=0,shell='Every shell invocation uses zsh -lc.',
        edits='Only owned scratch scripts/logs and this explicitly assigned root evidence JSON. No source, tests, commits, other worktrees or environments modified. Existing author interpreters executed with PYTHONPATH and cwd pinned to immutable candidate and bytecode writes disabled.',
        cleanup=0,pushes=0,root_writes=[str(DEST)],owned_scratch=str(S),resources_retained=True),
    retained_artifacts=[receipt(S/name) for name in artifact_names])
assert report['immutable_candidate']['final_status']==''
assert report['immutable_candidate']['final_head']==report['immutable_candidate']['commit']
assert report['author_evidence_receipts']['all_match']
assert report['primary_source']['matches_accepted_design_review_hash']
assert len(contracts)==10
DEST.write_text(json.dumps(safe(report),indent=2,allow_nan=False)+'\n')
print(json.dumps(dict(decision=report['decision'],findings=report['finding_counts'],
    report=receipt(DEST),scratch=str(S),candidate_clean=True),indent=2))
