import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('/tmp/plato-phase2c-scaffold-code-review')
CANDIDATE = '/private/tmp/plato-refresh-worktrees/training'
label, command = sys.argv[1:3]
start = time.time()
env = os.environ.copy()
env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=CANDIDATE,
           OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
           PYTEST_ADDOPTS='', RUFF_CACHE_DIR=str(ROOT / 'ruff-cache'))
with (ROOT / (label + '.log')).open('wb') as output:
    try:
        result = subprocess.run(['zsh', '-lc', command], cwd=CANDIDATE,
                                env=env, stdout=output, stderr=subprocess.STDOUT,
                                timeout=240)
        code=result.returncode
    except subprocess.TimeoutExpired:
        code=124
data = (ROOT / (label + '.log')).read_bytes()
record = dict(label=label, command=command, shell=['zsh', '-lc'],
              cwd=CANDIDATE, env_overrides={k: env[k] for k in
              ('PYTHONDONTWRITEBYTECODE', 'PYTHONPATH', 'OMP_NUM_THREADS',
               'MKL_NUM_THREADS', 'PYTEST_ADDOPTS', 'RUFF_CACHE_DIR')},
              exit_code=code, deadline_seconds=240, duration_seconds=time.time()-start,
              raw_log=str(ROOT/(label+'.log')), raw_bytes=len(data),
              raw_sha256=hashlib.sha256(data).hexdigest())
(ROOT / (label + '.command.json')).write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record, indent=2))
print(data.decode(errors='replace')[-2500:])
sys.exit(code)
