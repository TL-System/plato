import hashlib
import json
import subprocess
import tomllib
from pathlib import Path

C = Path('/private/tmp/plato-refresh-worktrees/training')
R = Path('/Users/bli/Playground/plato/evidence/2026-refresh')
S = Path('/tmp/plato-phase2c-scaffold-code-review')
B = '00eeb9dcdd2b513e64db9408969356037e09bb8e'
I = '0dc34dd1d79d90071a0babfa6aa89f33d72a976f'
H = '62d7b7d8ef75be779149a96f567779c86699edb4'
def git(*args):
    import shlex
    return subprocess.check_output(['zsh', '-lc', shlex.join(['git', *args])], cwd=C)
def receipt(path, expected=None):
    p = Path(path)
    raw = p.read_bytes()
    d = dict(path=str(p), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
    if expected is not None:
        d.update(expected_sha256=expected, matches=d['sha256']==expected)
    return d
v = json.loads((C/'evidence/2026-refresh/phase2c-validation.json').read_text())
checks = [receipt(x['path'], x['sha256']) for x in v['owned_source_and_test_receipts']]
checks += [receipt(x['path'], x['sha256']) for x in v['authorization']]
checks += [receipt(x['log'], x['sha256']) for x in v['validation']['final_combined']]
for records in v['validation']['final_auxiliary'].values():
    for x in records:
        if x.get('log') and x.get('sha256'):
            checks.append(receipt(x['log'],x['sha256']))
startup_sources=[]
for x in v['validation']['startup_sources']:
    raw = git('show', f'{B}:{x["path"]}')
    current = receipt(C/x['path'])
    current['accepted_b_sha256']=hashlib.sha256(raw).hexdigest()
    current['matches_b']=current['sha256']==current['accepted_b_sha256']
    startup_sources.append(current)
for version,x in v['validation']['startup'].items():
    for name in ('socket',):
        q=x[name]
        checks.append(receipt(q['path'],q['sha256']))
diff = git('diff', '--binary', B, H)
(S/'candidate-vs-B.diff').write_bytes(diff)
source_diff = git('diff', '--binary', B, I)
(S/'implementation-vs-B.diff').write_bytes(source_diff)
own = Path(v['identities']['implementation_owned_diff']['path'])
checks.append(receipt(own, v['identities']['implementation_owned_diff']['sha256']))
config_path='examples/customized_client_training/scaffold/scaffold_MNIST_lenet5.toml'
config_equal=tomllib.loads(git('show',f'{B}:{config_path}').decode())==tomllib.loads((C/config_path).read_text())
result = dict(head=git('rev-parse','HEAD').decode().strip(),status=git('status','--porcelain').decode(),
              candidate_tree=git('rev-parse',f'{H}^{{tree}}').decode().strip(),
              implementation_tree=git('rev-parse',f'{I}^{{tree}}').decode().strip(),
              post_implementation_files=git('diff','--name-status',I,H).decode(),
              accepted_b_is_ancestor=subprocess.run(['zsh','-lc',f'git merge-base --is-ancestor {B} {H}'],cwd=C).returncode==0,
              candidate_vs_b=receipt(S/'candidate-vs-B.diff'),
              implementation_vs_b=receipt(S/'implementation-vs-B.diff'),
              input_receipts=[receipt(R/name) for name in ('plan.md','plan-addendum.json','phase2c-scaffold-design.json','phase2c-scaffold-design-review.json','phase2c-scaffold-acceptance.json','scaffold-equation-probe.json','trainer-lifecycle-probes.json','phase2b-acceptance.json')],
              receipts=checks, startup_sources=startup_sources,
              startup_retained=v['validation']['startup'],
              shipped_toml_values_unchanged_from_b=config_equal)
(S/'identities.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(head=result['head'],status=result['status'],receipt_count=len(checks),
    mismatches=[x for x in checks if x.get('matches') is False],
    post_implementation_files=result['post_implementation_files'],
    b_ancestor=result['accepted_b_is_ancestor'],
    startup_sources_unchanged=all(x['matches_b'] for x in startup_sources),
    config_equal=config_equal),indent=2))
