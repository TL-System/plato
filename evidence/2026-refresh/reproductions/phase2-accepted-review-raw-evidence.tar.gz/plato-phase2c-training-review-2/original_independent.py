import copy
import hashlib
import importlib.metadata
import inspect
import json
import math
import sys
from pathlib import Path

import torch
from torch.utils.data import TensorDataset
from timm.scheduler.cosine_lr import CosineLRScheduler

from plato.config import Config
from plato.trainers.composable import ComposableTrainer
from plato.trainers.strategies.algorithms.fedala_strategy import FedALAUpdateStrategy
from plato.trainers.strategies.algorithms.feddyn_strategy import FedDynUpdateStrategy
from plato.trainers.strategies.algorithms.fedprox_strategy import FedProxLossStrategy
from plato.trainers.strategies.base import TrainingContext
from plato.trainers.strategies.lr_scheduler import TimmLRSchedulerStrategy
from plato.trainers.strategies.optimizer import GradientClippingOptimizerStrategy, DefaultOptimizerStrategy
from plato.trainers.strategies.training_step import GradientAccumulationStepStrategy, MixedPrecisionStepStrategy
from plato.utils.checkpoint_paths import checkpoint_name
from tests.integration.utils import build_minimal_config, configure_environment as _configure_environment

def configure_environment(config, *, runtime_root):
    runtime_root.mkdir(parents=True, exist_ok=True)
    return _configure_environment(config, runtime_root=runtime_root)

scratch = Path('/tmp/plato-phase2c-training-review')
suffix = f'{sys.version_info.major}{sys.version_info.minor}'
records = {}
torch.set_num_threads(1)

records['identity'] = {
    'python': sys.version, 'executable': sys.executable, 'cwd': str(Path.cwd()),
    'packages': {n: importlib.metadata.version(n) for n in ['torch', 'opacus', 'pytest', 'timm', 'numpy']},
    'source_files': {str(Path(inspect.getfile(c)).resolve()): hashlib.sha256(Path(inspect.getfile(c)).read_bytes()).hexdigest()
                     for c in [ComposableTrainer, GradientClippingOptimizerStrategy, MixedPrecisionStepStrategy, FedDynUpdateStrategy]},
}

# The derivative of mean squared error of a scalar model is known analytically.
# Average microbatch means, preserving accepted full-window equal weighting.
accum = []
for xs, window in [([[1., 2.], [3., 4.], [5.]], 2), ([[1., 2.], [3.]], 4), ([[1.], [2.]], 2)]:
    model = torch.nn.Linear(1, 1, bias=False).double()
    model.weight.data.fill_(1.)
    opt = torch.optim.SGD(model.parameters(), lr=.01)
    context = TrainingContext(); context.model = model
    step = GradientAccumulationStepStrategy(window); step.on_train_start(context)
    expected = 1.
    for start in range(0, len(xs), window):
        chunk = xs[start:start+window]
        derivative = sum(2 * expected * sum(x*x for x in b)/len(b) for b in chunk)/len(chunk)
        expected -= .01 * derivative
    flags = []
    for b in xs:
        x = torch.tensor(b, dtype=torch.double).reshape(-1, 1)
        step.training_step(model, opt, x, torch.zeros_like(x), torch.nn.functional.mse_loss, context)
        flags.append(context.state['optimizer_step_completed'])
    step.finalize(model, opt, context)
    final_flag = context.state['optimizer_step_completed']
    step.finalize(model, opt, context)
    assert abs(model.weight.item()-expected)<1e-12
    assert not context.state['optimizer_step_completed'] and model.weight.grad is None
    accum.append({'microbatches':xs,'window':window,'expected':expected,'actual':model.weight.item(),'flags':flags,'tail_update':final_flag})
records['accumulation_analytical'] = accum

fedprox = []
for mu, norm in [(0., 'l2'), (.1, 'l2'), (.1, 'l1')]:
    m = torch.nn.Linear(2, 1, bias=False).double(); m.weight.data.zero_()
    ctx = TrainingContext(); ctx.model = m
    s = FedProxLossStrategy(mu, torch.nn.functional.mse_loss, norm_type=norm); s.setup(ctx)
    m.weight.data.fill_(2.); s.on_train_start(ctx)
    x = torch.zeros(1, 2).double(); y = torch.zeros(1, 1).double()
    initial_loss = s.compute_loss(m(x), y, ctx); initial_loss.backward()
    assert initial_loss.item()==0 and torch.isfinite(m.weight.grad).all() and m.weight.grad.eq(0).all()
    m.zero_grad(); m.weight.data.add_(torch.tensor([[3.,4.]], dtype=torch.double))
    loss = s.compute_loss(m(x), y, ctx); loss.backward()
    expected = [mu/2*3/5,mu/2*4/5] if norm=='l2' else [mu,mu]
    assert torch.allclose(m.weight.grad, torch.tensor([expected], dtype=torch.double))
    fedprox.append({'mu':mu,'norm':norm,'initial_loss':initial_loss.item(),'nonzero_loss':loss.item(),'expected_gradient':expected,'actual_gradient':m.weight.grad.tolist()})
records['fedprox_analytical'] = fedprox

config = build_minimal_config(model_name='x'*240)
config['trainer']['max_concurrency'] = 1
with configure_environment(config, runtime_root=scratch/f'long-cleanup-{suffix}'):
    trainer = ComposableTrainer(model=torch.nn.Linear(1, 1)); trainer.set_client_id(7)
    data = TensorDataset(torch.ones(2, 1), torch.zeros(2, dtype=torch.long))
    run = {**config['trainer'], 'run_id':Config.params['run_id']}
    trainer.train_process(run, data, [0,1]); trainer.test_process(run, data)
    root = Path(Config.params['model_path'])
    before = sorted(p.name for p in root.iterdir())
    exception = None
    try: trainer.pause_training()
    except Exception as e: exception = type(e).__name__+': '+str(e)
    records['long_worker_cleanup'] = {'name_len':240,'run_id':run['run_id'],'writer_name':checkpoint_name('x'*240,7,run['run_id'],suffix='.safetensors'),'before':before,'after':sorted(p.name for p in root.iterdir()),'exception':exception,'expected_remaining':[]}

config=build_minimal_config(model_name='toy')
with configure_environment(config, runtime_root=scratch/f'feddyn-legacy-{suffix}'):
    root=Path(Config.params['model_path']); legacy=Path(str(root)+'_feddyn_grad_1.pth')
    legacy_state={'weight':torch.tensor([[7.]]),'bias':torch.tensor([8.])}
    torch.save(legacy_state, legacy)
    strategy=FedDynUpdateStrategy()
    trainer=ComposableTrainer(model=torch.nn.Linear(1,1),model_update_strategy=strategy); trainer.set_client_id(1)
    strategy.on_train_start(trainer.context)
    records['feddyn_legacy_writer_to_reader'] = {'legacy_writer_path':str(legacy),'canonical_path':strategy.grad_vector_path,'expected':{k:v.tolist() for k,v in legacy_state.items()},'actual':{k:v.tolist() for k,v in strategy.cumulative_grad_vector.items()},'legacy_still_exists':legacy.exists()}

# Actual enabled CPU GradScaler uses the same fused/unfused step contract. This
# probes optimizer math and does not claim CUDA autocast/hardware qualification.
clip_records=[]
for fused in [False,True]:
    with configure_environment(build_minimal_config(), runtime_root=scratch/f'amp-clip-{suffix}-{fused}'):
        model=torch.nn.Linear(1,1,bias=False); model.weight.data.fill_(1.)
        context=TrainingContext(); context.model=model
        clipping=GradientClippingOptimizerStrategy(DefaultOptimizerStrategy(optimizer_fn=lambda m:torch.optim.SGD(m.parameters(),lr=.1,fused=fused)),max_norm=1.)
        optimizer=clipping.create_optimizer(model,context)
        step=MixedPrecisionStepStrategy(enabled=False); step.enabled=True; step.scaler=torch.amp.GradScaler('cpu',init_scale=8.)
        x=torch.ones(1,1); y=torch.zeros(1,1)
        step.training_step(model,optimizer,x,y,torch.nn.functional.mse_loss,context)
        expected=1.-.1*(2./(2.+1e-6))
        clip_records.append({'fused':fused,'scale':8.,'expected_weight':expected,'actual_weight':model.weight.item(),'optimizer_step_completed':context.state['optimizer_step_completed']})
records['amp_clipping'] = clip_records

# A save_state=False FedALA strategy keeps state on dedicated workers; the same
# logical client should regain that state after a physical worker reassignment.
with configure_environment(build_minimal_config(model_name='toy'), runtime_root=scratch/f'ala-{suffix}'):
    s=FedALAUpdateStrategy(save_state=False, max_ala_epochs=2, rand_percent=0)
    t=ComposableTrainer(model=torch.nn.Linear(1,2),model_update_strategy=s); t.set_client_id(1)
    data=TensorDataset(torch.tensor([[1.],[2.]]), torch.tensor([0,1]))
    run={**Config().trainer._asdict(),'run_id':'ala'}
    t.train_model(run,data,[0,1])
    expected=copy.deepcopy(s.local_model_state)
    t.set_client_id(2); t.train_model(run,data,[0,1]); t.set_client_id(1)
    s.on_train_start(t.context)
    records['fedala_memory_return']={'save_state':False,'expected_local_model_state':{k:v.tolist() for k,v in expected.items()},'actual_local_model_state':None if s.local_model_state is None else {k:v.tolist() for k,v in s.local_model_state.items()}}

# Direct real timm state restore and closed-form cosine reference are independent
# of Plato's increment logic and factory. Verify epochs, accumulated update
# offsets and continuing from a library scheduler state_dict.
from unittest.mock import patch
timm=[]
with configure_environment(build_minimal_config(), runtime_root=scratch/f'timm-{suffix}'):
    for round_id in [1,3]:
        ctx=TrainingContext(); ctx.model=torch.nn.Linear(1,1); ctx.current_round=round_id
        ctx.config={'lr_scheduler':'timm','epochs':2,'global_lr_scheduler':True}
        ctx.state.update(train_loader=[0]*10,optimizer_updates_per_epoch=3)
        opt=torch.optim.SGD(ctx.model.parameters(),lr=.1); st=TimmLRSchedulerStrategy()
        with patch('plato.trainers.lr_schedulers.get',side_effect=lambda opt,n:CosineLRScheduler(opt,t_initial=100,t_in_epochs=False)):
            scheduler=st.create_scheduler(opt,ctx)
        offset=(round_id-1)*2*3
        lrs=[]
        for epoch in [1,2]:
            ctx.current_epoch=epoch; st.on_epoch_start(scheduler,ctx)
            for _ in range(3):
                opt.step(); st.on_step(scheduler,ctx); n=st.num_updates
                expected=.05*(1+math.cos(math.pi*n/100))
                assert abs(opt.param_groups[0]['lr']-expected)<1e-12
                lrs.append([n,opt.param_groups[0]['lr']])
            st.step(scheduler,ctx)
        assert [n for n,lr in lrs]==list(range(offset+1,offset+7))
        saved=scheduler.state_dict(); restored=CosineLRScheduler(opt,t_initial=100,t_in_epochs=False); restored.load_state_dict(saved)
        st.on_step(restored,ctx)
        assert abs(opt.param_groups[0]['lr']-.05*(1+math.cos(math.pi*(offset+7)/100)))<1e-12
        timm.append({'round':round_id,'expected_offset':offset,'updates_and_lr':lrs,'library_resume_next_update':st.num_updates})
records['timm_analytical'] = timm

path=scratch/f'independent-{suffix}.json'
path.write_text(json.dumps(records,indent=2)); print(json.dumps(records,indent=2))
