import copy
import importlib.metadata
import json
import sys
from pathlib import Path

import torch
from opacus import PrivacyEngine
from opacus.utils.batch_memory_manager import BatchMemoryManager
from torch.utils.data import DataLoader, TensorDataset

from plato.config import Config
from plato.trainers.composable import ComposableTrainer
from plato.trainers.diff_privacy import DPTrainingStepStrategy, Trainer as DPTrainer
from plato.trainers.strategies.algorithms.apfl_strategy import APFLStepStrategy, APFLUpdateStrategy
from plato.trainers.strategies.algorithms.fedala_strategy import FedALAUpdateStrategy
from plato.trainers.strategies.base import TrainingContext
from plato.trainers.strategies.loss_criterion import MSELossStrategy
from tests.integration.utils import build_minimal_config, configure_environment as _configure_environment, isolated_config_state

scratch=Path('/tmp/plato-phase2c-training-review-2')
version=f'{sys.version_info.major}{sys.version_info.minor}'
if len(sys.argv)>1:version+='-'+sys.argv[1]
def config_env(config,label):
    root=scratch/f'{label}-{version}';root.mkdir(parents=True,exist_ok=True)
    return _configure_environment(config,runtime_root=root)

results={}
torch.set_num_threads(1)
torch.manual_seed(101)

# Use a mathematical per-sample softmax gradient, not another Plato/Opacus
# training loop. Clipping/noise=0/fixed sampling isolates batch splitting.
initial=torch.tensor([[.4],[-.2]])
data=TensorDataset(torch.arange(1.,9.).reshape(-1,1),torch.arange(8)%2)
expected=initial.clone()
for start in (0,4):
    sample_grads=[]
    for idx in range(start,start+4):
        x,y=data[idx]
        probs=torch.softmax(expected[:,0]*x.item(),dim=0)
        target=torch.zeros(2);target[y]=1.
        grad=(probs-target).reshape(2,1)*x.item()
        coefficient=min(1.,1./(grad.norm().item()+1e-6))
        sample_grads.append(grad*coefficient)
    expected-=.1*sum(sample_grads)/4
actuals=[]
for physical in [2,4]:
    model=torch.nn.Linear(1,2,bias=False);model.weight.data.copy_(initial)
    engine=PrivacyEngine(accountant='rdp',secure_mode=False)
    private,opt,loader=engine.make_private(module=model,optimizer=torch.optim.SGD(model.parameters(),lr=.1),data_loader=DataLoader(data,batch_size=4),noise_multiplier=0.,max_grad_norm=1.,poisson_sampling=False)
    ctx=TrainingContext();ctx.model=private;flags=[]
    actual_updates=[];opt.original_optimizer.register_step_post_hook(lambda *_:actual_updates.append(True))
    with BatchMemoryManager(data_loader=loader,max_physical_batch_size=physical,optimizer=opt) as batches:
        for x,y in batches:
            DPTrainingStepStrategy().training_step(private,opt,x,y,torch.nn.functional.cross_entropy,ctx)
            flags.append(ctx.state['optimizer_step_completed'])
    assert torch.allclose(model.weight,expected,atol=1e-7,rtol=1e-6)
    count=sum(e[2] for e in engine.accountant.history)
    assert len(actual_updates)==sum(flags)==count==2
    actuals.append({'physical_cap':physical,'expected':expected.tolist(),'actual':model.weight.tolist(),'flags':flags,'base_optimizer_updates':len(actual_updates),'accountant_updates':count})
    private.to_standard_module()
results['dp_manual_per_sample_reference']=actuals

# Actual normal calibration and hook lifecycle, including an interrupted run.
from plato.callbacks.trainer import TrainerCallback
class Observe(TrainerCallback):
    def __init__(self):self.physical=0;self.updates=0;self.base_updates=0;self.fail=False
    def on_train_epoch_start(self,t,config,**kwargs):
        t.optimizer.original_optimizer.register_step_post_hook(self.base_step)
    def base_step(self,*_):self.base_updates+=1
    def on_train_step_start(self,*_,**kwargs):self.physical+=1
    def on_train_step_end(self,*_,**kwargs):
        self.updates+=1
        if self.fail:raise RuntimeError('independent DP interrupted after one update')
config=build_minimal_config(trainer_type='diff_privacy',model_name='org/model')
config['trainer'].update(batch_size=4,max_physical_batch_size=2)
with config_env(config,'dp-reuse'):
    observer=Observe();t=DPTrainer(model=torch.nn.Linear(2,2),callbacks=[observer]);t.set_client_id(1)
    samples=TensorDataset(torch.randn(16,2),torch.arange(16)%2);counts=[]
    run={**config['trainer'],'run_id':'reuse'}
    for i in [1,2]:
        before=copy.deepcopy(t.model.state_dict());t.train_model(run,samples,list(range(16)))
        assert t.model is t.context.model and not hasattr(t.model,'autograd_grad_sample_hooks')
        assert set(t.model.state_dict())=={'weight','bias'}
        assert any(not torch.equal(v,before[k]) for k,v in t.model.state_dict().items())
        trained=copy.deepcopy(t.model.state_dict());t.save_model();t.model.weight.data.add_(100.);t.load_model()
        assert all(torch.equal(v,trained[k]) for k,v in t.model.state_dict().items())
        counts.append(sum(e[2] for e in t.optimizer_strategy.privacy_engine.accountant.history))
    observer.fail=True
    try:t.train_model(run,samples,list(range(16)))
    except RuntimeError as e:assert 'independent DP interrupted' in str(e)
    else:raise AssertionError('missing DP interrupt')
    counts.append(sum(e[2] for e in t.optimizer_strategy.privacy_engine.accountant.history))
    assert counts==[4,8,9] and observer.base_updates==observer.updates==9 and not hasattr(t.model,'autograd_grad_sample_hooks')
    results['dp_real_reuse_and_interrupt']={'counts':counts,'physical_batches':observer.physical,'callbacks':observer.updates,'base_updates':observer.base_updates,'plain_keys':list(t.model.state_dict()),'no_hooks':True,'save_load_exact':True}

# A fixed-alpha scalar APFL run allows an analytical recurrence for private SGD
# momentum across a 1->2->1 assignment. The base optimizer resets each run.
def scalar_model():
    m=torch.nn.Linear(1,1,bias=False);m.weight.data.fill_(2.);return m
config=build_minimal_config(model_name='toy');config['parameters']['optimizer'].update(lr=.2,momentum=.9)
with config_env(config,'apfl-analytic'):
    update=APFLUpdateStrategy(alpha=.5,adaptive_alpha=False,model_fn=scalar_model)
    t=ComposableTrainer(model=scalar_model,model_update_strategy=update,training_step_strategy=APFLStepStrategy(),loss_strategy=MSELossStrategy());t.set_client_id(1)
    data=TensorDataset(torch.ones(1,1),torch.zeros(1,1));run={**config['trainer'],'run_id':'apfl'}
    expected_private=2.;momentum=0.;observations=[]
    for round_id,global_weight in [(1,1.),(2,3.)]:
        t.current_round=round_id;t.model.weight.data.fill_(global_weight)
        global_after=global_weight-.2*(2*global_weight)
        derivative=.5*2*(.5*expected_private+.5*global_after)
        momentum=.9*momentum+derivative;expected_private-=.2*momentum
        t.train_model(run.copy(),data,[0])
        actual=update.personalized_model.weight.item()
        buffer=next(iter(t.context.state['apfl_personalized_optimizer'].state.values()))['momentum_buffer'].item()
        assert abs(actual-expected_private)<1e-6 and abs(buffer-momentum)<1e-6
        observations.append({'round':round_id,'expected_private':expected_private,'actual_private':actual,'expected_momentum':momentum,'actual_momentum':buffer})
        if round_id==1:
            t.set_client_id(2);t.model.weight.data.fill_(5.);t.train_model(run.copy(),data,[0]);t.set_client_id(1)
    results['apfl_1_2_1_scalar_reference']=observations

# Both trainers have seeded identical parameters. One logical client keeps a
# dedicated worker; the other uses 1->2->1. Compare actual two-round training.
config=build_minimal_config(model_name='toy');config['parameters']['optimizer'].update(lr=.1,momentum=0.)
config['clients']['random_seed']=17
with config_env(config,'fedala-return-numeric'):
    def make():
        m=torch.nn.Linear(1,2,bias=False);m.weight.data.copy_(torch.tensor([[1.],[-1.]]))
        s=FedALAUpdateStrategy(save_state=False,eta=1.,max_ala_epochs=2,rand_percent=100)
        t=ComposableTrainer(model=m,model_update_strategy=s);t.set_client_id(1);return t,s
    reused,rs=make();dedicated,ds=make()
    data=TensorDataset(torch.tensor([[1.],[2.]]),torch.tensor([1,1]));run={**config['trainer'],'run_id':'ala'}
    for t in [reused,dedicated]:t.current_round=1;t.train_model(run.copy(),data,[0,1])
    state_before=copy.deepcopy(rs.local_model_state)
    reused.set_client_id(2);reused.train_model(run.copy(),data,[0,1]);reused.set_client_id(1)
    state_restored=rs.local_model_state
    for t in [reused,dedicated]:
        t.current_round=2;t.model.weight.data.copy_(torch.tensor([[2.],[-1.]]));t.train_model(run.copy(),data,[0,1])
    error=(reused.model.weight-dedicated.model.weight).abs().max().item()
    results['fedala_reassignment_numerical']={'save_state':False,'expected_returned_local_state':{k:v.tolist() for k,v in state_before.items()},'actual_returned_local_state':None if state_restored is None else {k:v.tolist() for k,v in state_restored.items()},'dedicated_weight':dedicated.model.weight.tolist(),'reassigned_weight':reused.model.weight.tolist(),'max_abs_error':error,'dedicated_has_ala_weights':ds.weights is not None,'reassigned_has_ala_weights':rs.weights is not None}
    assert error<1e-7

# Parse the actual included TOML and run two batches through its actual registry
# trainer, observing zero received-baseline penalty and nonzero next-step loss.
import os
from plato.trainers import registry
root=scratch/f'fedprox-reference-{version}';root.mkdir(parents=True,exist_ok=True)
with isolated_config_state():
    previous=os.environ.get('config_file');argv=sys.argv[:]
    os.environ['config_file']=str(Path.cwd()/'configs/MNIST/fedprox_lenet5.toml');sys.argv=['review','-b',str(root),'--cpu']
    try:
        c=Config();t=registry.get();t.set_client_id(1)
        penalties=[];original=t.loss_strategy.compute_loss
        def observed(output,labels,context):
            total=original(output,labels,context);base=torch.nn.functional.cross_entropy(output,labels)
            penalties.append((total-base).item());return total
        t.loss_strategy.compute_loss=observed
        before=copy.deepcopy(t.model.state_dict());torch.manual_seed(11)
        data=TensorDataset(torch.randn(64,1,28,28),torch.arange(64)%10)
        t.train_model({**c.trainer._asdict(),'run_id':'reference'},data,list(range(64)))
        assert penalties[0]==0. and penalties[1]>0 and all(torch.isfinite(p).all() for p in t.model.parameters())
        results['fedprox_actual_reference_toml']={'trainer_class':type(t).__module__+'.'+type(t).__name__,'optimizer':c.trainer.optimizer,'mu':t.loss_strategy.mu,'proximal_penalties':penalties,'model_changed':any(not torch.equal(before[k],v) for k,v in t.model.state_dict().items()),'finite':True}
    finally:
        sys.argv=argv
        if previous is None:os.environ.pop('config_file',None)
        else:os.environ['config_file']=previous

# Device/mode ownership of the urgent reader on available real MPS hardware.
if torch.backends.mps.is_available():
    with config_env(build_minimal_config(model_name='org/model'),'urgent-mps'):
        t=ComposableTrainer(model=torch.nn.Linear(1,1));t.set_client_id(7)
        t.device=t.context.device=torch.device('mps');t.model.to('mps');t.model.eval()
        for epoch in [9,10]:t.model.weight.data.fill_(epoch);t.save_model(f'7_{epoch}_{epoch}.0.safetensors')
        before=t.model.weight.clone();historical=t.obtain_model_at_time(7,11.)
        assert historical.weight.item()==10 and str(historical.weight.device)=='mps:0' and not historical.training
        assert torch.equal(t.model.weight,before) and not t.model.training
        results['urgent_mps']={'device':str(historical.weight.device),'weight':historical.weight.item(),'mode':'eval','current_model_unchanged':True}

path=scratch/f'behavior-{version}.json';path.write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
