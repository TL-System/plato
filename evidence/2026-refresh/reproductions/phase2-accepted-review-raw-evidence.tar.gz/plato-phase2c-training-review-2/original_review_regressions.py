"""Independent review expectations; four known failures on immutable C."""
import copy
import subprocess
import types
from pathlib import Path

import pytest
import torch
from torch.utils.data import TensorDataset

from plato.config import Config
from plato.trainers.composable import ComposableTrainer
from plato.trainers.strategies.algorithms.fedala_strategy import FedALAUpdateStrategy
from plato.trainers.strategies.algorithms.feddyn_strategy import FedDynUpdateStrategy
from plato.trainers.strategies.base import TrainingContext
from plato.trainers.strategies.optimizer import DefaultOptimizerStrategy, GradientClippingOptimizerStrategy
from plato.trainers.strategies.training_step import MixedPrecisionStepStrategy
from tests.integration.utils import build_minimal_config, configure_environment


def test_long_name_cleanup_matches_actual_writer(tmp_path):
    config=build_minimal_config(model_name='x'*240)
    config['trainer']['max_concurrency']=1
    with configure_environment(config,runtime_root=tmp_path):
        t=ComposableTrainer(model=torch.nn.Linear(1,2));t.set_client_id(7)
        data=TensorDataset(torch.ones(2,1),torch.zeros(2,dtype=torch.long))
        run={**config['trainer'],'run_id':Config.params['run_id']}
        t.train_process(run,data,[0,1]);t.test_process(run,data)
        t.pause_training()
        assert list(Path(Config.params['model_path']).iterdir())==[]


def test_feddyn_reads_actual_accepted_b_writer(tmp_path):
    config=build_minimal_config(model_name='toy')
    with configure_environment(config,runtime_root=tmp_path):
        # Run the exact accepted-B writer class in memory. No checkout or edits.
        command="git show 00eeb9dcdd2b513e64db9408969356037e09bb8e:plato/trainers/strategies/algorithms/feddyn_strategy.py"
        source=subprocess.check_output(['zsh','-lc',command],text=True,cwd='/private/tmp/plato-refresh-worktrees/training')
        old=types.ModuleType('accepted_b_feddyn');exec(compile(source,'accepted_b_feddyn','exec'),old.__dict__)
        m=torch.nn.Linear(1,1,bias=False);m.weight.data.zero_()
        ctx=TrainingContext();ctx.model=m;ctx.client_id=1
        previous=old.FedDynUpdateStrategy();previous.setup(ctx);previous.on_train_start(ctx)
        m.weight.data.fill_(7.);previous.on_train_end(ctx)
        expected=torch.load(previous.grad_vector_path,weights_only=True)['weight']
        assert expected.item()==7.
        update=FedDynUpdateStrategy();update.setup(ctx);update.on_train_start(ctx)
        torch.testing.assert_close(update.cumulative_grad_vector['weight'],expected)


@pytest.mark.parametrize('fused',[False,True])
def test_amp_clip_uses_unscaled_gradient(tmp_path,fused):
    config=build_minimal_config()
    config['parameters']['optimizer'].update(lr=.1,fused=fused)
    with configure_environment(config,runtime_root=tmp_path):
        m=torch.nn.Linear(1,1,bias=False);m.weight.data.fill_(1.)
        ctx=TrainingContext();ctx.model=m
        opt=GradientClippingOptimizerStrategy(DefaultOptimizerStrategy(),max_norm=1.).create_optimizer(m,ctx)
        step=MixedPrecisionStepStrategy(enabled=False)
        step.enabled=True;step.scaler=torch.amp.GradScaler('cpu',init_scale=8.)
        step.training_step(m,opt,torch.ones(1,1),torch.zeros(1,1),torch.nn.functional.mse_loss,ctx)
        expected=1.-.1*2./(2.+1e-6)
        assert m.weight.item()==pytest.approx(expected,abs=1e-7)


def test_fedala_return_matches_dedicated_client_without_disk_state(tmp_path):
    config=build_minimal_config(model_name='toy')
    config['parameters']['optimizer'].update(lr=.1,momentum=0.)
    config['clients']['random_seed']=17
    with configure_environment(config,runtime_root=tmp_path):
        def make():
            m=torch.nn.Linear(1,2,bias=False);m.weight.data.copy_(torch.tensor([[1.],[-1.]]))
            s=FedALAUpdateStrategy(save_state=False,eta=1.,max_ala_epochs=2,rand_percent=100)
            t=ComposableTrainer(model=m,model_update_strategy=s);t.set_client_id(1);return t
        reused,dedicated=make(),make()
        data=TensorDataset(torch.tensor([[1.],[2.]]),torch.tensor([1,1]))
        run={**config['trainer'],'run_id':'ala'}
        for t in [reused,dedicated]:t.current_round=1;t.train_model(run.copy(),data,[0,1])
        reused.set_client_id(2);reused.train_model(run.copy(),data,[0,1]);reused.set_client_id(1)
        for t in [reused,dedicated]:
            t.current_round=2;t.model.weight.data.copy_(torch.tensor([[2.],[-1.]]));t.train_model(run.copy(),data,[0,1])
        torch.testing.assert_close(reused.model.weight,dedicated.model.weight)
