import hashlib
import json
from pathlib import Path
import subprocess

scratch = Path('/tmp/plato-phase2c-training-review-2')
source = Path('/private/tmp/plato-refresh-worktrees/training-review2')
root = Path('/Users/bli/Playground/plato/evidence/2026-refresh')
base = '62d7b7d8ef75be779149a96f567779c86699edb4'
candidate = json.loads((source / 'evidence/2026-refresh/phase2c-validation.json').read_text())
prior = json.loads((root / 'phase2c-training-review.json').read_text())


def git(*args):
    return subprocess.check_output(['/bin/zsh', '-lc',
        'git ' + ' '.join(args)], cwd=source)


def sha(data):
    return hashlib.sha256(data).hexdigest()


receipt_results = []
seen = set()


def receipt(item, path, historical=False):
    identity = (item['path'], item['sha256'], historical)
    if identity in seen:
        return
    seen.add(identity)
    original = item['path']
    result = dict(receipt_path=path, recorded_path=original,
        expected=item['sha256'])
    if original.startswith('/private/tmp/plato-refresh-worktrees/training/'):
        relative = original.split('/training/', 1)[1]
        data = git('show', base + ':' + relative) if historical else (source / relative).read_bytes()
        result.update(read_from=('git show ' + base + ':' + relative) if historical
            else str(source / relative), historical=historical)
    elif original.startswith('/tmp/') or original.startswith('/private/tmp/'):
        # Inspect scratch logs/receipts only; never use evolving worktree files.
        if '/plato-refresh-worktrees/' in original:
            result['status'] = 'EXCLUDED_EVOLVING_SOURCE'
            receipt_results.append(result)
            return
        actual = Path(original)
        if not actual.is_file():
            result['status'] = 'MISSING'
            receipt_results.append(result)
            return
        data = actual.read_bytes()
        result['read_from'] = str(actual)
    else:
        return
    result.update(actual=sha(data), bytes=len(data),
        status='MATCH' if sha(data) == item['sha256'] else 'MISMATCH')
    receipt_results.append(result)


def walk(obj, path='', historical=False):
    if isinstance(obj, dict):
        if isinstance(obj.get('path'), str) and isinstance(obj.get('sha256'), str):
            receipt(obj, path, historical)
        if 'log' in obj and 'sha256' in obj:
            receipt(dict(path=obj['log'], sha256=obj['sha256']), path + '/log', historical)
        for key, value in obj.items():
            walk(value, path + '/' + key, historical or key == 'historical_reviewed_candidate')
    elif isinstance(obj, list):
        for index, value in enumerate(obj):
            walk(value, path + '/' + str(index), historical)


walk(candidate, 'candidate')
walk(prior['reviewer_executions'], 'prior_reviewer_executions', True)
walk(prior['reviewer_results'].get('socket', {}), 'prior_socket', True)
walk(prior.get('author_and_root_evidence_audited_not_claimed_as_reviewer_reruns', {}).get(
    'root_fresh_full_base', {}), 'historical_root_base', True)

paths = git('ls-files', 'plato', 'tests', 'examples/customized_client_training/scaffold',
    'configs/MNIST/fedprox_lenet5.toml', 'examples/async/port').decode().splitlines()
equivalence = []
for relative in paths:
    actual = source / relative
    if not actual.is_file():
        continue
    before = git('show', base + ':' + relative) if relative != 'tests/trainers/test_review_training_boundaries.py' else None
    current = actual.read_bytes()
    equivalence.append(dict(path=relative, before_sha256=sha(before) if before is not None else None,
        current_sha256=sha(current), unchanged=before == current))

artifact = dict(
    receipt_results=receipt_results,
    summary={label: sum(x['status'] == label for x in receipt_results)
        for label in ['MATCH', 'MISMATCH', 'MISSING', 'EXCLUDED_EVOLVING_SOURCE']},
    source_test_equivalence=equivalence,
    unchanged_count=sum(x['unchanged'] for x in equivalence),
    changed=[x for x in equivalence if not x['unchanged']],
    commit=git('rev-parse', 'HEAD').decode().strip(),
    tree=git('rev-parse', 'HEAD^{tree}').decode().strip(),
    implementation_tree=git('rev-parse', 'e65241c19448b74dcb57fc48bfe388152f3a3e58^{tree}').decode().strip(),
    status=git('status', '--porcelain=v1', '--untracked-files=all').decode(),
    implementation_delta=git('diff', '--name-status',
        'e65241c19448b74dcb57fc48bfe388152f3a3e58', 'HEAD').decode().splitlines(),
)
(scratch / 'receipt-audit.json').write_text(json.dumps(artifact, indent=2) + '\n')
print(json.dumps({k: v for k, v in artifact.items() if k not in
    ['receipt_results', 'source_test_equivalence']}, indent=2))
