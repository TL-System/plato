import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

scratch = Path('/tmp/plato-phase2c-training-review-2')
source = Path('/private/tmp/plato-refresh-worktrees/training-review2')
label, command = sys.argv[1:3]
env = os.environ.copy()
env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(source))
for key in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
            'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS']:
    env[key] = '1'
for key in ['TMPDIR', 'XDG_CACHE_HOME', 'MPLCONFIGDIR', 'TORCH_HOME']:
    location = scratch / label / key.lower()
    location.mkdir(parents=True, exist_ok=True)
    env[key] = str(location)
record = dict(label=label, command=command, shell='zsh -lc', cwd=str(source),
              environment={k: env[k] for k in ['PYTHONDONTWRITEBYTECODE',
              'PYTHONPATH', 'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS',
              'MKL_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS',
              'TMPDIR', 'XDG_CACHE_HOME', 'MPLCONFIGDIR', 'TORCH_HOME']})
log = scratch / (label + '.log')
start = time.monotonic()
with log.open('wb') as output:
    result = subprocess.run(['/bin/zsh', '-lc', command], cwd=source, env=env,
                            stdout=output, stderr=subprocess.STDOUT)
record.update(exit_code=result.returncode, seconds=time.monotonic()-start,
              log=str(log), sha256=hashlib.sha256(log.read_bytes()).hexdigest())
(scratch / (label + '.command.json')).write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record))
print('\n'.join(log.read_text(errors='replace').splitlines()[-8:]))
sys.exit(result.returncode)
