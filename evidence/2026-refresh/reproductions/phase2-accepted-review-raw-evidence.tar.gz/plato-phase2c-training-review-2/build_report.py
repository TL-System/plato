import datetime
import hashlib
import json
from pathlib import Path
import platform
import re
import subprocess

SCRATCH = Path('/tmp/plato-phase2c-training-review-2')
SOURCE = Path('/private/tmp/plato-refresh-worktrees/training-review2')
ROOT = Path('/Users/bli/Playground/plato')
EVIDENCE = ROOT / 'evidence/2026-refresh'
OUTPUT = EVIDENCE / 'phase2c-training-review-2.json'
BASE = '62d7b7d8ef75be779149a96f567779c86699edb4'


def read(path):
    return json.loads(Path(path).read_text())


def receipt(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def git(command):
    return subprocess.check_output(['/bin/zsh', '-lc', 'git ' + command],
        cwd=SOURCE, text=True).strip()


audit = read(SCRATCH / 'receipt-audit.json')
prior = read(EVIDENCE / 'phase2c-training-review.json')
candidate = read(SOURCE / 'evidence/2026-refresh/phase2c-validation.json')
scaffold = read(EVIDENCE / 'phase2c-scaffold-code-review-2.json')
archive = read(EVIDENCE / 'phase2c-root-source-archive-validation.json')
adaptations = read(SCRATCH / 'adaptations.json')
initial = read(SCRATCH / 'initial-identities.json')
assert git('rev-parse HEAD') == 'f9772f61d52dfe0f4a3281252d23b8303ec237d2'
assert git('status --porcelain=v1 --untracked-files=all') == ''
assert audit['summary']['MISMATCH'] == audit['summary']['MISSING'] == 0
for adaptation in adaptations:
    assert receipt(adaptation['original'])['sha256'] == adaptation['original_sha256']

commands = []
for path in sorted(SCRATCH.glob('*.command.json')):
    command = read(path)
    log = Path(command['log']).read_text()
    summaries = re.findall(r'^.*\d+ (?:passed|failed).* in .*$', log, re.MULTILINE)
    command['summary'] = summaries[-1] if summaries else 'Script exit status; numerical records retained separately.'
    command['receipt'] = receipt(path)
    commands.append(command)

results = {}
for version in ['313', '314']:
    results[version] = dict(
        identity=read(SCRATCH / f'independent-{version}.json')['identity'],
        independent=read(SCRATCH / f'independent-{version}.json'),
        behavior=read(SCRATCH / f'behavior-{version}.json'),
        root_amp=read(SCRATCH / f'rootamp-{int(version[1:])}.json'),
        edges=read(SCRATCH / f'edge-results-{int(version[1:])}.json'),
    )

def location(path, line):
    return dict(file=path, line=line)


closed = [
    dict(id='ROOT-2C-01', original_severity='medium', status='CLOSED_IN_BOUNDED_REVIEW',
        title='Fused AMP clipping now receives unscaled gradients.',
        locations=[location('plato/trainers/strategies/training_step.py', 235),
            location('plato/trainers/strategies/training_step.py', 244)],
        repro='Actual CPU torch.amp.GradScaler with public clipping wrapper and registry SGD, fused/nonfused; scales8/65536; quadratic gradient2 and linear gradient10; real inf/NaN skips followed by finite recovery.',
        expected=dict(root_weight=0.900000009999999,
            scale8_quadratic_weight=0.900000049999975,
            order=['unscale', 'clip', 'optimizer update']),
        actual_each_python=dict(root_weight=0.8999999761581421,
            root_max_error=3.384185687238528e-8,
            scale8_quadratic_weight=0.9000000357627869,
            finite_recovery_weight=0.8000000715255737,
            nonfinite_update_completed=False, nonfinite_parameters_unchanged=True,
            scale_backoff='65536 -> 32768', avoidable_autocast_warnings=0),
        independent_evidence=['original-regressions-313/314', 'rootamp-313/314',
            'independent-313/314', 'edges-final-313/314'],
        repository_regressions=['tests/trainers/test_review_training_boundaries.py::test_real_amp_clipping_unscaled_success_and_overflow',
            'tests/trainers/test_training_update_contract.py'],
        interpretation='Fresh spy observes exactly one public unscale per attempt before clipping and sees gradient2 at the clipping call. GradScaler controls step dispatch. Nonfused overflow never enters optimizer.step; fused SGD is entered and internally skips, so a posthook invocation is not treated as a completed parameter update. Finite and overflow trainer callback counts remain1/0. Accumulation short/tail/divisible references and clipping-at-tail regressions also pass. No double-unscale or unconditional optimizer call introduced.',
        limits='Real CPU scaler/optimizer contract; CPU examples use FP32 with CUDA autocast disabled explicitly. No CUDA hardware/autocast qualification or new combined AMP+accumulation strategy claimed.'),
    dict(id='TRAINING-2C-01', original_severity='medium', status='CLOSED_IN_BOUNDED_REVIEW',
        title='Worker writers and pause_training agree on complete-suffix names.',
        locations=[location('plato/trainers/base.py', 87), location('plato/trainers/base.py', 88),
            location('plato/trainers/base.py', 91)],
        repro='Actual train_process/test_process and actual token-qualified FedALA .train.pkl writer; client7/run123456, logical lengths223,224,225,226,230,231,232,233,234,240,255,300; repository ordinary/slash/240 cases also executed.',
        expected='Remove owned model, history, accuracy, evaluation and training-state artifacts; retain other client/run/persistent artifacts byte-for-byte.',
        actual_each_python='All five actual writer artifacts are removed at every tested boundary. Other-client safetensors, other-run strategy sidecar, and persistent personalization bytes remain unchanged. Original240-character train/test leak reproducer now leaves no files.',
        independent_evidence=['original-regressions-313/314', 'independent-313/314', 'edges-final-313/314'],
        repository_regression='tests/trainers/test_review_training_boundaries.py::test_actual_worker_cleanup_full_names_and_unrelated_owners',
        interpretation='Cleanup passes the complete suffix to checkpoint_name for every independently named artifact; history is actual encoded primary + .pkl. The251-byte primary reserve and255-byte auxiliary boundary now use the writer contract. No broad glob deletion or codec change.'),
    dict(id='TRAINING-2C-02', original_severity='medium', status='CLOSED_PRODUCTION_MIGRATION_ONLY',
        title='The actual accepted B FedDyn historical writer spelling is recognized.',
        locations=[location('plato/trainers/strategies/algorithms/feddyn_strategy.py', 397)],
        historical_writer=dict(commit='00eeb9dcdd2b513e64db9408969356037e09bb8e',
            file='plato/trainers/strategies/algorithms/feddyn_strategy.py', line=342,
            expression='f"{base_path}_feddyn_grad_{context.client_id}.pth"'),
        repro='Execute the exact old class from immutable-source git show in memory, call its actual setup/start/end writer, then candidate reader; default/custom roots with and without trailing slash; exact nonzero IDs1 and12, absent IDs2/13/123 and client0 exclusion.',
        expected=dict(legacy_vector=7.0, canonical_precedence_vector=8.0,
            different_client_vector=0.0, original_bytes_preserved=True),
        actual_each_python=dict(legacy_vector=7.0, canonical_precedence_vector=8.0,
            different_client_vector=0.0, original_bytes_preserved=True,
            loaded_vector_does_not_alias_model=True),
        corruption='Existing corrupt canonical state is not treated as missing: it emits Failed to load cumulative gradient vector, keeps the existing zero-vector fallback, does not adopt the valid legacy7 vector, and leaves canonical/legacy bytes intact. This checks preserved historical degradation, not a new fail-hard contract. Corrupt state is not claimed to have migrated successfully.',
        independent_evidence=['original-regressions-313/314', 'edges-final-313/314'],
        repository_regression='tests/trainers/test_review_training_boundaries.py::test_actual_accepted_b_feddyn_writer_migration',
        interpretation='Corrective production diff is exactly the missing underscore. Canonical writes remain contained in the selected root; historical read is same-client and read-only. Mathematical FedDyn code is unchanged and not accepted by this review.',
        required_separate_handoff='ROOT-2C-02 test portability remains OPEN onf977. Later accepted FedDyn reader migration must retain byte-exact actual-writer coverage and provenance.'),
    dict(id='TRAINING-2C-03', original_severity='medium', status='CLOSED_IN_BOUNDED_REVIEW',
        title='FedALA preserves returning logical-client memory state.',
        locations=[location('plato/trainers/strategies/algorithms/fedala_strategy.py', 118),
            location('plato/trainers/strategies/algorithms/fedala_strategy.py', 171),
            location('plato/trainers/strategies/algorithms/fedala_strategy.py', 180)],
        repro='Original1->2->1 numerical case; fresh two dedicated clients versus reusable worker1,2,1,2 over two deterministic rounds, actual direct and spawn, save_stateFalse/True, slash model name and distinct custom runtime roots. Full local-model/ALA-weight/start-phase/RNG state compared before return and after training.',
        expected=dict(max_parameter_error=0.0, local_model_restored=True,
            learned_weights_restored=True, start_phase_restored=True, rng_restored=True),
        original_error=1.1351019144058228,
        actual_each_python=dict(max_parameter_error=0.0, local_model_restored=True,
            learned_weights_restored=True, start_phase_restored=True, rng_restored=True,
            own_identity_preserved=True, disk_persistence_enabled_still_works=True,
            disk_persistence_disabled_creates_no_personal_files=True),
        independent_evidence=['original-regressions-313/314', 'behavior-313/314', 'edges-final-313/314'],
        repository_regression='tests/trainers/test_review_training_boundaries.py::test_fedala_memory_only_return_matches_dedicated_rounds',
        interpretation='Snapshot outgoing owner with existing deep-copied worker-state contract; restore memory state on return before normal optional disk load. Existing ALA equations, lower/upper layer policy, seed formula, incoming-global initialization, and canonical save-state behavior are unchanged.',
        limits='Successful direct/spawn memory ownership and existing optional checkpoint behavior. No durable restart protocol for save_stateFalse or new research semantics claimed.'),
]

contracts = [
    dict(contract='DP reuse/accounting and physical versus logical updates',
        source_paths=['plato/trainers/diff_privacy.py', 'tests/trainers/test_dp_data_loader_strategy.py'],
        evidence='Both unchanged byte-for-byte from62d; rerun focused and own real Opacus probes on both versions. Canonical weight/bias keys, plain model/context identity, hooks removed on success/interruption, exact model save/load. Calibrated histories4/8/9 match9 base updates and9 callbacks over20 physical batches. Manual per-sample clipped softmax reference with noise0 has identical cap2/cap4 weights(.3588939309,-.1588939130), two optimizer/accountant updates and flags[F,T,F,T]/[T,T].'),
    dict(contract='Accumulation, update callbacks, and Timm offsets',
        source_paths=['plato/trainers/strategies/training_step.py', 'plato/trainers/strategies/lr_scheduler.py',
            'tests/trainers/test_training_update_contract.py'],
        evidence='Accumulation/Timm blocks and test file unchanged; changed AMP branch separately closed above. Float64 analytical full-window, short and tail references retained and rerun. Finalize is idempotent, no extra divisible update, no residual gradients. Repository callback/scheduler/optimizer counts pass. Real timm cosine closed form round1 updates1..6, round3 updates13..18 and library state restore next7/19 pass.'),
    dict(contract='FedProx current baseline and finite-zero UNSQUARED legacy objective',
        source_paths=['plato/trainers/strategies/algorithms/fedprox_strategy.py', 'plato/trainers/fedprox.py',
            'configs/MNIST/fedprox_lenet5.toml'],
        evidence='Source and reference TOML unchanged. Rerun independent zero-gradient baseline and mu0 exactbase, L2 offset[3,4] penalty.25 gradient[.03,.04], L1 penalty.7 gradient[.1,.1]. Actual TOML selects FedProx trainer/SGD/mu.1, two synthetic LeNet batches have proximal penalties0/.00015282630920410156 and finite changed weights. No squared-paper-objective acceptance or MNIST accuracy benchmark.'),
    dict(contract='FedMos parameter identity and optimizer wrappers/loss tracking',
        source_paths=['plato/trainers/strategies/algorithms/fedmos_strategy.py',
            'plato/trainers/strategies/optimizer.py', 'plato/trainers/tracking.py'],
        evidence='Source and existing tests unchanged; focused suite rerun preserves same-shaped identitypair reference5.95/11.45, detached numerical loss history, validation-wrapper delegation and full/tail clipping. Shared completed-step dispatch remains qualified by actual counts.'),
    dict(contract='GAN updates/exchange/serialization and urgent snapshots',
        source_paths=['plato/models/dcgan.py', 'plato/algorithms/fedavg_gan.py', 'plato/trainers/gan.py',
            'tests/trainers/test_gan_runtime.py', 'tests/integration/test_checkpoint_runtime_agreement.py'],
        evidence='Source/tests unchanged from62d; focused suite rerun includes actual registered DCGAN G/D updates, owned CPU snapshots, bool/int buffer exchange, combined worker/urgent safetensors tree/history, paired historical fallback, companion containment, sampling/tail/rectangular pad. No pretrained FID quality claim.'),
    dict(contract='SSL model/mode/flags/private head',
        source_paths=['plato/trainers/self_supervised_learning.py', 'tests/trainers/test_ssl_personalized_state.py'],
        evidence='Source/tests unchanged; focused suite rerun covers instance construction, empty data and KNN reference/partition boundary, encoder/head gradients and mode/flag restoration, isolated canonical private heads and successful spawn handoff. Prior independent real Lightly multiview executions on3.13/3.14 and hash-checked retained logs remain the unchanged optional-library evidence; not counted as fresh reruns or a new SSL mathematical reference.'),
    dict(contract='Split test before train/empty; LG multiupdates and personalization flags',
        source_paths=['plato/trainers/split_learning.py', 'plato/trainers/strategies/algorithms/lgfedavg_strategy.py',
            'plato/trainers/strategies/algorithms/personalized_fl_strategy.py'],
        evidence='Source/tests unchanged; actual split test-before-train and empty partition, feature/gradient behavior and restored context pass focused rerun. LG per-update callback/scheduler dispatch and parameter reference pass; FedPer/FedRep/LG restore prior requires_grad flags including frozen and exceptional cases.'),
    dict(contract='APFL state/checkpoint paths and urgent epoch ordering',
        source_paths=['plato/trainers/strategies/algorithms/apfl_strategy.py', 'tests/trainers/test_apfl_optimizer_ownership.py',
            'tests/trainers/test_checkpointing.py', 'tests/trainers/test_checkpoint_path_contract.py'],
        evidence='Source/tests unchanged; focused actual ownership/spawn/path and urgent cases pass. Independent APFL1->2->1 recurrence yields private1.74/1.152 and momentum1.3/2.94. Historical primitive/NumPy alpha behavior retained. Own real MPS reader selects epoch10 over9 under cutoff11, preserves eval mode/device/current model. No durable optimizer/RNG restart claim.'),
    dict(contract='Accepted B naming/runtime/startup preservation',
        source_paths=['plato/client.py', 'plato/clients/base.py', 'plato/clients/strategies/defaults.py',
            'plato/servers/base.py', 'plato/servers/strategies/aggregation/port.py',
            'tests/integration/test_event_loop_startup.py', 'tests/integration/utils.py', 'tests/conftest.py'],
        evidence='All listed sources/test fixtures byte-identical from62d and covered by exact current/source and historical receipts. PORT/checkpoint agreement tests rerun. Prior independent two-client socket rounds on both versions retained with weighted error1.49e-8, IDs1/2, samples2/6, exit0/no survivors. Author current523 includes all48startup; their raw receipts checked. No repeated complete48startup suite or F28 selection-RNG probe performed. Final combined runtime qualification remains required.'),
]

external_open = []
for finding in scaffold['findings']:
    external_open.append(dict(id=finding['id'], severity=finding['severity'], status='OPEN_EXTERNALLY_OWNED',
        title=finding['title'], location=finding['primary_location'],
        report=receipt(EVIDENCE / 'phase2c-scaffold-code-review-2.json'),
        ownership='Original C author corrects; a fresh independent SCAFFOLD review closes it.',
        review2_action='Read report and changed source; did not duplicate its detailed equations/worker-transaction/callback probes.'))
external_open.append(dict(id='ROOT-2C-02', severity='medium', status='OPEN_EXTERNALLY_OWNED_ON_F977',
    title='Historical git-show migration fixture is not portable to source archives/shallow history.',
    location=location('tests/trainers/test_review_training_boundaries.py', 132),
    expected='Byte-exact historical writer fixture with provenance executes without repository history.',
    actual='Root exactf977 git archive:4 actual migration cases fail with CalledProcessError exit128 because gitshow00e is unavailable. Fresh general runs have history and therefore pass; they do not qualify portability.',
    assessment='Independent code inspection confirms an unconditional subprocess gitshow of the historical commit. Raw root four-case failure log hash verified. Source production filename correction is valid, while the test dependency remains a separate material portability defect.',
    report=receipt(EVIDENCE / 'phase2c-root-source-archive-probe.json'),
    supplemental_report=receipt(EVIDENCE / 'phase2c-root-source-archive-validation.json'),
    ownership='Original C author already authorized byte-exact historical fixture/provenance correction and later explicit FedDyn reader migration; fresh final-source review required.',
    review2_action='No duplicate broad archive run and no CI full-history workaround accepted.'))

inputs = [ROOT / 'AGENTS.md', EVIDENCE / 'plan.md', EVIDENCE / 'plan-addendum.json',
    EVIDENCE / 'plan-addendum-acceptance.json', EVIDENCE / 'phase2c-training-review.json',
    EVIDENCE / 'phase2c-root-amp-clipping-probe.json', EVIDENCE / 'phase2c-root-source-archive-probe.json',
    EVIDENCE / 'phase2c-root-source-archive-validation.json', EVIDENCE / 'phase2c-scaffold-code-review-2.json',
    SOURCE / 'evidence/2026-refresh/phase2c-validation.json']
assert receipt(EVIDENCE / 'phase2c-training-review.json')['sha256'] == 'efa4427422c1d0c12d1020e22f7fc8dd9afc1c25f0e5369fa0d4f5a2df44eea1'
assert receipt(EVIDENCE / 'phase2c-scaffold-code-review-2.json')['sha256'] == 'aa00c76f5e3fbe3eb2f419ed277620c32f382b8dabb99f4a3e5c190308162eb1'
historical_root = prior['author_and_root_evidence_audited_not_claimed_as_reviewer_reruns']['root_base']
artifact = dict(
    schema_version=1,
    review='Fresh independent general Phase2C four-correction and changed-shared-hook review',
    written_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    verdict='PASS',
    verdict_scope='Original ROOT-2C-01/TRAINING-2C-01/02/03 production corrections and preservation of affected general C contracts; known external SCAFFOLD/portability failures remain open.',
    conclusion='All four original defects close in this bounded immutable-source review. No new material finding in owned corrections. Final C acceptance, final integrated/root full suite and phase gate remain required after externally owned corrections and accepted dependency/FedDyn implementation.',
    material_findings=[],
    source=dict(requested_path='/tmp/plato-refresh-worktrees/training-review2', actual_path=str(SOURCE),
        commit=git('rev-parse HEAD'), tree=git('rev-parse HEAD^{tree}'),
        original_reviewed_candidate=BASE, original_reviewed_tree=git('rev-parse ' + BASE + '^{tree}'),
        implementation_commit='e65241c19448b74dcb57fc48bfe388152f3a3e58',
        implementation_tree=audit['implementation_tree'],
        accepted_b='00eeb9dcdd2b513e64db9408969356037e09bb8e',
        accepted_b_ancestor=subprocess.run(['/bin/zsh', '-lc',
            'git merge-base --is-ancestor 00eeb9dcdd2b513e64db9408969356037e09bb8e HEAD'], cwd=SOURCE).returncode == 0,
        clean_before=initial['status'], clean_after=git('status --porcelain=v1 --untracked-files=all'),
        implementation_to_candidate_delta=audit['implementation_delta'],
        corrective_production_and_test_diff=receipt(SCRATCH / 'corrective.diff'),
        implementation_evidence_diff=receipt(SCRATCH / 'evidence.diff'),
        corrective_changed_source_and_test_hashes=audit['changed'],
        changed_paths=git('diff --name-only ' + BASE + ' HEAD').splitlines()),
    scope=dict(included='Four original material corrections; entire corrective code/test diff inspected; shared ComposableTrainer, ModelUpdateStrategy and CompositeUpdateStrategy lifecycle propagation; affected general preservation suite and independent analytical/numerical checks.',
        excluded=['Exact F27R01/R02 equations and detailed SCAFFOLD worker/callback transaction suite are owned by the separate completed reviewer.',
            'FedDyn mathematical design/code acceptance and later explicit legacy-reader migration are separate; candidate math intentionally unchanged.',
            'F28 startup/selection RNG, broad protocol/security/redesign/format/type work, reserved MLX/HF/LeRobot/ViT paths, final wholeC combined acceptance.'],
        requested_execution='gpt-6.1-sol xhigh; no nested agents', agents_spawned=0),
    closed_findings=closed,
    shared_hook_assessment=dict(status='NO_NEW_OWNED_MATERIAL_FINDING_WITH_KNOWN_EXTERNAL_F27_R2_02',
        changed_locations=[location('plato/trainers/composable.py', 411),
            location('plato/trainers/composable.py', 426), location('plato/trainers/composable.py', 449),
            location('plato/trainers/composable.py', 865), location('plato/trainers/strategies/base.py', 428),
            location('plato/trainers/strategies/model_update.py', 136)],
        analysis='Base acceptance hook is a no-op for existing general algorithms. Composite propagates once to components. train_process defers commit until model/history and optional strategy handoff save; token-qualified children export state, parent accepts after model/state load. Fresh generic composite spy checks direct train_model, direct train_process and real spawn, one acceptance, after on_train_end/model handoff, and no acceptance on model-save failure. Ordinary callbacks/model-update counts and personalized spawned state in the389-case suite pass.',
        external_limit='Direct train_model currently accepts before the fallible training_step.on_train_end in its finally block. F27-R2-02 already reports and owns this boundary; this review does not waive or duplicate it. SCAFFOLD server callback atomicity remains F27-R2-01.'),
    preserved_contracts=contracts,
    low_recommendations=[dict(id='TRAINING-LOW-01', severity='low', status='RETAINED',
        location=location('plato/trainers/diff_privacy.py', 133),
        recommendation='Reuse a stable equivalent logical Subset identity when practical, preserving notices for genuinely changed partitions.',
        evidence='Three repeated-dataset-identity warnings in each focused run; same classes recur in own real reuse probe. Independently checked parameter/accountant results pass; no material accounting defect or global privacy guarantee inferred.')],
    resolved_low_observations=[dict(id='TRAINING-LOW-02', status='CLOSED',
        evidence='CPU GradScaler references now use explicitly disabled CUDA autocast for non-CUDA examples. Current actualCPU/root/reference checks emit no avoidable autocast warnings; no blanket filter.')],
    warning_audit=dict(focused_count_each=17,
        classes=candidate['validation']['warning_audit']['visible_classes'],
        reviewer_verification='Read both raw focused warning summaries and standalone behavior logs.17 comprise secure-RNG5, alpha-bound3, expected backward-hook4, repeated-budget2, equivalent-dataset3. Standalone logs use normal once-per-location warning behavior; their emitted lines are not added to pytest totals.',
        limits='Existing secure_modeFalse experimental policy; cumulative budget exceeds a per-run target; alpha grid may yield looser epsilon. These boundaries stay visible. MacOS torch elastic redirect log is separate from pytest warning counts. No CUDA/Linux or production privacy qualification.',
        suppression='No blanket/global warning suppression or weakened source assertions introduced.'),
    reviewer_execution_receipts=commands,
    reviewer_test_counts=dict(
        per_python=dict(focused='389 passed,17 warnings', original_regressions='5 passed,no warnings',
            fresh_boundaries='17 passed,no warnings', independent_script='exit0',
            behavior_script='exit0, visible Opacus notices', root_amp_script='exit0,no warnings'),
        accounting='Separate executions with overlapping coverage; no sum of tests or unique-case total claimed. Tracked17boundary tests are already inside focused389. Fresh scratch17 add boundary conditions and are reported separately. First scratch construction attempts10failed/7passed each are retained, not counted as passing qualification.'),
    reviewer_results=results,
    harness_construction_attempts=dict(first_each='10 failed,7 passed',
        cause='8 fixtures incorrectly passed keyword arguments to no-argument TrainingContext;2 spawn comparisons supplied index lists, which intentionally become randomized SubsetRandomSampler and do not supply identical direct/child order.',
        correction='Use actual TrainingContext assignment API and explicit SequentialSampler for deterministic identical inputs. Numerical/state/RNG equality thresholds unchanged. Original attempt source, logs and results retained; corrected final17cases pass each.',
        source=receipt(SCRATCH / 'edge_cases_attempt1.py'),
        final_source=receipt(SCRATCH / 'edge_cases.py')),
    original_reproducer_adaptations=adaptations,
    author_and_root_receipts_not_claimed_as_fresh_reviewer_runs=dict(
        current_author_implementation='e65241c19448b74dcb57fc48bfe388152f3a3e58',
        current_author_scoped=candidate['validation']['final_combined'],
        current_author_startup=candidate['validation']['startup'],
        current_author_count_disposition='523 scoped passes and17notices each include48startup; this differs from historical root62d BASE523passes/4skips/48deselected/2warnings. Same523number does not mean identical selection/profile.',
        historical_author=candidate['historical_reviewed_candidate']['validation']['final_combined'],
        historical_root_base=historical_root,
        exact_f977_archive=archive,
        exact_archive_disposition='Root574passes/4expectedskips/52deselected/no warnings exit1 is intentional profile-guard rejection of4known migration exclusions; the other48runtime omissions are allowedbase.959tracked blobs unchanged as root attests. Not fullprofilePASS and not combined with author/reviewer totals.',
        prior_independent_lightly_and_socket=[x for x in prior['reviewer_executions']
            if x['label'].startswith(('ssl-', 'socket-'))]),
    receipt_and_unchanged_source_audit=dict(
        current_and_historical_receipt_tuple_count=audit['summary']['MATCH'],
        mismatches=audit['summary']['MISMATCH'], missing=audit['summary']['MISSING'],
        tuple_definition='Unique recorded path/hash/historicalflag tuples; historical source receipts checked against gitshow62d, current source paths remapped to immutablef977. No evolving training/runtime checkout read.',
        unchanged_source_test_count=audit['unchanged_count'],
        proof=receipt(SCRATCH / 'receipt-audit.json'),
        additional_external_receipts=receipt(SCRATCH / 'external-receipt-checks.json'),
        exact_unchanged_files=[x for x in audit['source_test_equivalence'] if x['unchanged']]),
    external_open_handoffs=external_open,
    required_final_handoffs=['Original C author corrects F27-R2-01/F27-R2-02 and ROOT-2C-02; fresh independent reviews required.',
        'Retain actual accepted B writer coverage/provenance through the separately accepted FedDyn explicit-reader implementation and dependency integration.',
        'Final exact combined C acceptance, root full unfiltered supported-profile suite and phase gate remain required. Unchanged48startup receipts are reuse evidence for this bounded review, not waiver of final integration qualification.',
        'F28 startup/selection-RNG work remains separately root/B-owned; no closure claim here.'],
    environment_and_limits=dict(platform=platform.platform(), machine=platform.machine(),
        interpreters='Existing author313/314 reused read-only; no installs/sync/environment edits.',
        versions={v: results[v]['identity'] for v in results},
        device='ActualCPU AMP/Opacus/personalization and actualMPS urgent reader. CUDA unavailable and untested.',
        limits='No whole-stack3.14, Linux/CI/GPU/multihost, full dataset/accuracy/FID-quality, durable killed-worker restart, or new research-equation certification.'),
    input_receipts=[receipt(p) for p in inputs],
    workflow=dict(shell='Every shell uses zsh -lc including subprocess git and runner.',
        source_edits=0, commits=0, agents_spawned=0, environment_modifications=0,
        root_write=str(OUTPUT), scratch=str(SCRATCH), scratch_retained=True,
        cleanup='No source/worktree/environment/original-artifact cleanup. Only intrinsic owned-scratch fixture and production cleanup exercised by regression tests; original root TemporaryDirectory probe adapted to preserve its new runtime directories.',
        pinning='cwd/PYTHONPATH immutablef977; PYTHONDONTWRITEBYTECODE1, pytest cache disabled, unique owned basetemps/TMPDIR/caches. Explicit original git-show cwd adapted away from evolving training checkout.'),
    retained_artifacts=[receipt(p) for p in sorted(SCRATCH.iterdir()) if p.is_file()],
)
OUTPUT.write_text(json.dumps(artifact, indent=2) + '\n')
output_receipt = receipt(OUTPUT)
(SCRATCH / 'final-report-receipt.json').write_text(json.dumps(output_receipt, indent=2) + '\n')
print(json.dumps(output_receipt, indent=2))
print('PASS bounded four corrections; clean immutable source; external findings remain open.')
