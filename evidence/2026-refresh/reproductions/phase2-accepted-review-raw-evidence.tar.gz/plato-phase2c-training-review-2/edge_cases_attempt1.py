"""Fresh boundary checks; all runtime state lives in review2 scratch."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import types
from unittest.mock import patch

import pytest
import torch
from torch.utils.data import TensorDataset

from plato.config import Config
from plato.trainers.composable import ComposableTrainer
from plato.trainers.strategies.algorithms.fedala_strategy import FedALAUpdateStrategy
from plato.trainers.strategies.algorithms.feddyn_strategy import FedDynUpdateStrategy
from plato.trainers.strategies.base import ModelUpdateStrategy, TrainingContext
from plato.trainers.strategies.model_update import CompositeUpdateStrategy
from plato.trainers.strategies.optimizer import (
    DefaultOptimizerStrategy, GradientClippingOptimizerStrategy,
)
from plato.trainers.strategies.training_step import MixedPrecisionStepStrategy
from plato.utils.checkpoint_paths import checkpoint_name
from tests.integration.utils import build_minimal_config, configure_environment

SCRATCH = Path('/tmp/plato-phase2c-training-review-2')
RECORDS = {}


@pytest.fixture(scope='session', autouse=True)
def retain_results():
    yield
    (SCRATCH / f'edge-results-{sys.version_info.minor}.json').write_text(
        json.dumps(RECORDS, indent=2) + '\n'
    )


@pytest.mark.parametrize('fused', [False, True])
@pytest.mark.parametrize('bad_gradient', [float('inf'), float('nan')])
def test_real_unscale_clip_update_order_and_recovery(tmp_path, fused, bad_gradient):
    with configure_environment(build_minimal_config(), runtime_root=tmp_path):
        model = torch.nn.Linear(1, 1, bias=False)
        model.weight.data.fill_(1.)
        context = TrainingContext(model=model)
        optimizer = GradientClippingOptimizerStrategy(
            DefaultOptimizerStrategy(optimizer_fn=lambda m: torch.optim.SGD(
                m.parameters(), lr=.1, fused=fused)), max_norm=1.
        ).create_optimizer(model, context)
        step = MixedPrecisionStepStrategy(enabled=False)
        step.enabled = True
        scaler = step.scaler = torch.amp.GradScaler('cpu', init_scale=65536.)
        observed, events = [], []
        real_unscale = scaler.unscale_
        real_clip = torch.nn.utils.clip_grad_norm_

        def unscale(opt):
            events.append('unscale')
            real_unscale(opt)

        def clip(parameters, *args, **kwargs):
            parameters = list(parameters)
            observed.append(parameters[0].grad.item())
            events.append('clip')
            return real_clip(parameters, *args, **kwargs)

        optimizer.register_step_post_hook(lambda *_: events.append('optimizer-call'))
        runs = []
        with patch.object(scaler, 'unscale_', side_effect=unscale) as spy:
            with patch('torch.nn.utils.clip_grad_norm_', side_effect=clip):
                for multiplier in [2., bad_gradient, 2.]:
                    before = model.weight.item()
                    begin = len(events)
                    step.training_step(model, optimizer, torch.ones(1, 1),
                        torch.zeros(1, 1),
                        lambda outputs, labels: multiplier * outputs.mean(), context)
                    finite = multiplier == 2.
                    expected = before - .1 * 2 / (2 + 1e-6) if finite else before
                    assert model.weight.item() == pytest.approx(expected, abs=1e-7)
                    assert context.state['optimizer_step_completed'] is finite
                    current = events[begin:]
                    assert current[0] == 'unscale'
                    if finite:
                        assert current == ['unscale', 'clip', 'optimizer-call']
                        assert observed[-1] == pytest.approx(2.)
                    else:
                        # Fused SGD is entered by GradScaler and internally skips;
                        # nonfused SGD is never entered. Neither updates parameters.
                        assert current == (['unscale', 'clip', 'optimizer-call']
                            if fused else ['unscale'])
                    runs.append(dict(before=before, expected=expected,
                        actual=model.weight.item(), completed=finite,
                        events=current, scale=scaler.get_scale()))
            assert spy.call_count == 3
        assert scaler.get_scale() == 32768.
        assert not hasattr(optimizer, 'grad_scale')
        assert not hasattr(optimizer, 'found_inf')
        RECORDS[f'amp-{fused}-{bad_gradient}'] = runs


class HandoffObserver(ModelUpdateStrategy):
    def __init__(self):
        self.events = []

    def on_train_end(self, context):
        self.events.append('end')

    @property
    def requires_worker_state(self):
        return True

    def get_worker_state(self, context):
        return list(self.events)

    def load_worker_state(self, state, context):
        self.events = list(state) + ['load']

    def on_train_result_accepted(self, context):
        self.events.append('accepted')

    def on_train_cleanup(self, context, successful):
        self.events.append('cleanup-' + str(successful))


@pytest.mark.parametrize('entry', ['train_model', 'train_process', 'spawn'])
def test_shared_composite_acceptance_is_once_after_model_handoff(tmp_path, entry):
    config = build_minimal_config()
    if entry == 'spawn':
        config['trainer']['max_concurrency'] = 1
    with configure_environment(config, runtime_root=tmp_path):
        observe = HandoffObserver()
        trainer = ComposableTrainer(model=torch.nn.Linear(1, 2),
            model_update_strategy=CompositeUpdateStrategy([observe]))
        trainer.device = trainer.context.device = torch.device('cpu')
        data = TensorDataset(torch.ones(2, 1), torch.zeros(2, dtype=torch.long))
        config_run = {**config['trainer'], 'run_id': Config.params['run_id']}
        if entry == 'spawn':
            trainer.train(data, [0, 1])
            assert observe.events[-2:] == ['load', 'accepted']
        else:
            getattr(trainer, entry)(config_run, data, [0, 1])
        assert observe.events.count('accepted') == 1
        assert observe.events.index('end') < observe.events.index('accepted')
        RECORDS['hook-' + entry] = list(observe.events)


def test_model_save_failure_does_not_accept_generic_composite(tmp_path):
    config = build_minimal_config()
    with configure_environment(config, runtime_root=tmp_path):
        observe = HandoffObserver()
        trainer = ComposableTrainer(model=torch.nn.Linear(1, 2),
            model_update_strategy=CompositeUpdateStrategy([observe]))
        trainer.device = trainer.context.device = torch.device('cpu')
        data = TensorDataset(torch.ones(2, 1), torch.zeros(2, dtype=torch.long))
        with patch.object(trainer, 'save_model', side_effect=OSError('review save')):
            with pytest.raises(OSError, match='review save'):
                trainer.train_process({**config['trainer'], 'run_id': 'failure'},
                    data, [0, 1])
        assert 'accepted' not in observe.events
        assert observe.events[-1] == 'cleanup-False'
        RECORDS['generic-save-failure'] = list(observe.events)


def test_actual_cleanup_at_complete_suffix_filename_bounds(tmp_path):
    results = []
    # Fixed six-character run ID makes the 251-byte primary boundary exact.
    for length in [223, 224, 225, 226, 230, 231, 232, 233, 234, 240, 255, 300]:
        config = build_minimal_config(model_name='x' * length)
        config['trainer']['max_concurrency'] = 1
        runtime = tmp_path / str(length)
        runtime.mkdir()
        with configure_environment(config, runtime_root=runtime):
            Config.params['run_id'] = '123456'
            strategy = FedALAUpdateStrategy(save_state=False, rand_percent=0)
            trainer = ComposableTrainer(model=torch.nn.Linear(1, 2),
                model_update_strategy=strategy)
            trainer.set_client_id(7)
            trainer.device = trainer.context.device = torch.device('cpu')
            data = TensorDataset(torch.ones(2, 1), torch.zeros(2, dtype=torch.long))
            run = {**config['trainer'], 'run_id': '123456', 'worker_state_token': 'own'}
            trainer.train_process(run, data, [0, 1])
            trainer.test_process(run, data)
            root = Path(Config.params['model_path'])
            before = sorted(p.name for p in root.iterdir())
            assert len(before) == 5  # Real model/history/acc/eval/train writers.
            preserved = {}
            for owner, run_id, suffix in [(8, '123456', '.safetensors'),
                (7, '654321', '.train.pkl'), (7, 'personal', '.pth')]:
                filename = checkpoint_name('x' * length, owner, run_id, suffix=suffix)
                preserved[filename] = b'other owner or persistent'
                (root / filename).write_bytes(preserved[filename])
            trainer.pause_training()
            assert {p.name for p in root.iterdir()} == set(preserved)
            assert all((root / name).read_bytes() == value
                for name, value in preserved.items())
            results.append(dict(length=length, before=before,
                after=sorted(preserved)))
    RECORDS['cleanup-bounds'] = results


@pytest.mark.parametrize('custom', [False, True])
@pytest.mark.parametrize('slash', [False, True])
def test_actual_old_writer_exact_id_precedence_and_visible_corruption(
    tmp_path, custom, slash, caplog
):
    source = subprocess.check_output(['/bin/zsh', '-lc',
        'git show 00eeb9dcdd2b513e64db9408969356037e09bb8e:'
        'plato/trainers/strategies/algorithms/feddyn_strategy.py'], text=True)
    historical = types.ModuleType('exact_accepted_b_feddyn')
    exec(compile(source, 'exact_accepted_b_feddyn', 'exec'), historical.__dict__)
    with configure_environment(build_minimal_config(), runtime_root=tmp_path):
        root = str(tmp_path / 'personal') if custom else Config.params['model_path']
        root = root.rstrip('/') + ('/' if slash else '')
        Path(root).mkdir(exist_ok=True)
        if not custom:
            Config.params['model_path'] = root
        option = dict(save_path=root if custom else None)
        model = torch.nn.Linear(1, 1, bias=False)
        model.weight.data.zero_()
        context = TrainingContext(model=model, client_id=12)
        writer = historical.FedDynUpdateStrategy(**option)
        writer.setup(context)
        writer.on_train_start(context)
        model.weight.data.fill_(7.)
        writer.on_train_end(context)
        legacy = Path(writer.grad_vector_path)
        old_bytes = legacy.read_bytes()
        reader = FedDynUpdateStrategy(**option)
        reader.setup(context)
        reader.on_train_start(context)
        assert reader.cumulative_grad_vector['weight'].item() == 7.
        assert reader.cumulative_grad_vector['weight'].data_ptr() != model.weight.data_ptr()
        canonical = Path(reader.grad_vector_path)
        torch.save({'weight': torch.tensor([[8.]])}, canonical)
        canonical_bytes = canonical.read_bytes()
        reader.on_train_start(context)
        assert reader.cumulative_grad_vector['weight'].item() == 8.
        assert legacy.read_bytes() == old_bytes
        assert canonical.read_bytes() == canonical_bytes
        canonical.write_bytes(b'corrupt canonical stays authoritative')
        caplog.clear()
        reader.on_train_start(context)
        # Preserve the existing explicit load-failure fallback; do not reinterpret
        # corrupt canonical state as absent and import the historical vector.
        assert reader.cumulative_grad_vector['weight'].item() == 0.
        assert 'Failed to load cumulative gradient vector' in caplog.text
        assert 'No previous gradient vector' not in caplog.text
        assert canonical.read_bytes() == b'corrupt canonical stays authoritative'
        context.client_id = 123
        reader.on_client_id_changed(context)
        reader.on_train_start(context)
        assert reader.cumulative_grad_vector['weight'].item() == 0.
        # A client0 checkpoint does not become another client's state.
        context.client_id = 0
        writer.setup(context)
        torch.save({'weight': torch.tensor([[99.]])}, writer.grad_vector_path)
        context.client_id = 13
        reader.on_client_id_changed(context)
        reader.on_train_start(context)
        assert reader.cumulative_grad_vector['weight'].item() == 0.
        assert legacy.read_bytes() == old_bytes
        RECORDS[f'feddyn-{custom}-{slash}'] = dict(legacy=str(legacy),
            exact_writer_sha256=hashlib.sha256(source.encode()).hexdigest(),
            old_bytes_sha256=hashlib.sha256(old_bytes).hexdigest(),
            canonical_precedence=True, corruption_warns_and_does_not_migrate=True,
            legacy_preserved=True, client0_excluded=True, exact_id_only=True)


def deterministic_model():
    model = torch.nn.Linear(1, 2, bias=False)
    model.weight.data.copy_(torch.tensor([[1.], [-1.]]))
    return model


def assert_tree_equal(actual, expected):
    if isinstance(actual, torch.Tensor):
        torch.testing.assert_close(actual, expected, atol=1e-7, rtol=0)
    elif isinstance(actual, dict):
        assert actual.keys() == expected.keys()
        for key in actual:
            assert_tree_equal(actual[key], expected[key])
    elif isinstance(actual, (tuple, list)):
        assert type(actual) is type(expected) and len(actual) == len(expected)
        for value, reference in zip(actual, expected):
            assert_tree_equal(value, reference)
    else:
        assert actual == expected


@pytest.mark.parametrize('spawn', [False, True])
@pytest.mark.parametrize('save_state', [False, True])
def test_fedala_two_dedicated_clients_match_reuse_state_rng_and_custom_roots(
    tmp_path, spawn, save_state
):
    config = build_minimal_config(model_name='org/model')
    config['parameters']['optimizer'].update(lr=.1, momentum=0.)
    config['clients']['random_seed'] = 17
    if spawn:
        config['trainer']['max_concurrency'] = 1
    roots = {name: tmp_path / name for name in ['reuse', 'dedicated1', 'dedicated2']}
    workers = {}
    for name, root in roots.items():
        root.mkdir()
        with configure_environment(config, runtime_root=root):
            trainer = ComposableTrainer(model=deterministic_model(),
                model_update_strategy=FedALAUpdateStrategy(save_state=save_state,
                    eta=1., max_ala_epochs=2, rand_percent=50))
            trainer.device = trainer.context.device = torch.device('cpu')
            trainer.set_client_id(2 if name == 'dedicated2' else 1)
            workers[name] = trainer
    samples = TensorDataset(torch.tensor([[1.], [2.], [3.], [4.]]),
        torch.tensor([1, 1, 0, 1]))
    snapshots, checks = {}, []
    for client, round_id in [(1, 1), (2, 1), (1, 2), (2, 2)]:
        for name in ['reuse', f'dedicated{client}']:
            trainer = workers[name]
            with configure_environment(config, runtime_root=roots[name]):
                trainer.set_client_id(client)
                if name == 'reuse' and client in snapshots:
                    assert_tree_equal(trainer.model_update_strategy.get_worker_state(
                        trainer.context), snapshots[client])
                trainer.current_round = round_id
                trainer.model.weight.data.copy_(torch.tensor([
                    [float(client + round_id)], [-float(client)]]))
                torch.manual_seed(700 + client * 10 + round_id)
                if name == 'reuse' and spawn:
                    trainer.train(samples, [0, 1, 2, 3])
                else:
                    trainer.train_model({**config['trainer'], 'run_id': 'direct'},
                        samples, [0, 1, 2, 3])
                strategy = trainer.model_update_strategy
                own = strategy.get_worker_state(trainer.context)
                trainer.set_client_id(client)
                assert_tree_equal(strategy.get_worker_state(trainer.context), own)
        actual, expected = workers['reuse'], workers[f'dedicated{client}']
        assert_tree_equal(actual.model.state_dict(), expected.model.state_dict())
        state = actual.model_update_strategy.get_worker_state(actual.context)
        assert_tree_equal(state, expected.model_update_strategy.get_worker_state(
            expected.context))
        snapshots[client] = copy.deepcopy(state)
        error = (actual.model.weight - expected.model.weight).abs().max().item()
        checks.append(dict(client=client, round=round_id, max_abs_error=error,
            has_weights=state['weights'] is not None, start_phase=state['start_phase'],
            rng_equal=True))
    assert snapshots[1]['weights'] is not None and snapshots[2]['weights'] is not None
    for root in roots.values():
        files = list((root / 'models').glob('*fedala_*.pth'))
        # Special-name component digest retains the fedala suffix.
        assert bool(files) is save_state
    RECORDS[f'fedala-{spawn}-{save_state}'] = checks
