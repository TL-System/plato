import importlib.util
import json
import subprocess
from pathlib import Path
import numpy as np
scratch = Path('/tmp/plato-phase2a-lZqbqj')
results = []
for name in ['purchase', 'texas']:
    path = scratch / ('baseline-' + name + '.py')
    path.write_bytes(subprocess.check_output(['git', 'show', 'fda60bec:plato/datasources/' + name + '.py']))
    spec = importlib.util.spec_from_file_location('baseline_' + name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    root = scratch / ('baseline-' + name + '-data')
    root.mkdir(exist_ok=True)
    np.savez(root / (name + '_numpy.npz'), X=np.arange(40001).reshape(-1,1), Y=np.arange(40001) % 100)
    np.random.seed(123)
    before = np.random.get_state()
    source = module.DataSource.__new__(module.DataSource)
    train, test = source.extract_data(str(root))
    after = np.random.get_state()
    results.append({'datasource': name, 'global_rng_changed': not np.array_equal(before[1], after[1]) or before[2:] != after[2:],
                    'first_train_rows': [int(train[i][0].item()) for i in range(5)], 'train_count': len(train), 'test_count': len(test)})
source = subprocess.check_output(['git', 'show', 'fda60bec:plato/samplers/sampler_utils.py'], text=True)
ns = {}
exec(source, ns)
labels = np.tile(np.arange(4), 20)
parts = ns['assign_sub_classes'](labels, [0,1,2,3], 2, 2, anchor_classes=[0,1], consistent_clients=[0], keep_anchor_classes_size=0)
results.append({'anchor_pool': {'actual_client_2_labels': sorted(set(labels[parts[1]])), 'expected': [2,3]}})
print(json.dumps(results, indent=2, default=int))
