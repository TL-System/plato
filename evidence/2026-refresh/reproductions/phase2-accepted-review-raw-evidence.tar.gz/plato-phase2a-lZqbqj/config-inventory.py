import json
import subprocess
from pathlib import Path
from plato.config import TomlConfigLoader
from plato.datasources import registry as datasources
from plato.samplers import registry as samplers

paths = subprocess.check_output(['git', 'ls-files', 'configs', 'examples', 'tests/config.toml'], text=True).splitlines()
results = []
for path in paths:
    if not path.endswith('.toml') or path.endswith('pyproject.toml'):
        continue
    try:
        config = TomlConfigLoader(Path(path)).load()
        data = config.get('data', {})
        datasource = data.get('datasource')
        sampler = data.get('sampler')
        results.append({'path': path, 'loaded': True, 'datasource': datasource,
                        'sampler': sampler, 'sampler_known': sampler in samplers.registered_samplers if sampler else None,
                        'datasource_known': datasource in datasources.registered_datasources or datasource in datasources.registered_partitioned_datasources or datasource in datasources._datasource_aliases if datasource else None})
    except Exception as exc:
        results.append({'path': path, 'loaded': False, 'error': type(exc).__name__, 'message': str(exc)})
print(json.dumps(results, indent=2))
assert all(result['loaded'] for result in results)
