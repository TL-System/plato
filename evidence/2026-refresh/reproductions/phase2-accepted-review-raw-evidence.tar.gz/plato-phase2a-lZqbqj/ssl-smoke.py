import json
import sys
from pathlib import Path

import torch
from PIL import Image
from plato.config import Config
from plato.datasources.self_supervised_learning import get_transforms

base_root = sys.argv[1]
results = []
for name in ('simclr', 'simsiam', 'byol', 'fedema', 'mocov2', 'smog', 'swav', 'calibre'):
    path = Path('examples/ssl/configs') / (name + '_CIFAR10_resnet18.toml')
    sys.argv = ['ssl-smoke', '-c', str(path), '--base', base_root]
    Config.reset()
    config = Config()
    transform = get_transforms()['train_transform']
    torch.manual_seed(19)
    views = transform(Image.new('RGB', (64, 64), (20, 50, 90)))
    assert len(views) >= 2
    assert all(view.shape == (3, 32, 32) and torch.isfinite(view).all() for view in views)
    results.append({'config': str(path), 'transform': type(transform).__name__, 'views': len(views), 'finite': True})
print(json.dumps(results, indent=2))
