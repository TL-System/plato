"""Numerical utility checks beyond the focused regressions, without network I/O."""
import json
import asyncio
from types import SimpleNamespace

import numpy as np

import torch

from plato.processors import model_deepcopy
from plato.utils import count_parameters, decorators, homo_enc, trainer_utils
from plato.config import Config
from tests.integration.utils import configure_environment, build_minimal_config

class Table:
    def __init__(self, _columns):
        self.rows = []

    def add_row(self, row):
        self.rows.append(row)

    def __str__(self):
        return str(self.rows)

count_parameters.PrettyTable = Table  # isolate only the optional formatter
model = torch.nn.Linear(2, 3)
model.bias.requires_grad = False
assert count_parameters.count_parameters(model) == 6

model = torch.nn.Sequential(torch.nn.Linear(2, 3), torch.nn.Linear(3, 1))
trainer_utils.freeze_model(model, ["0."])
assert not model[0].weight.requires_grad and model[1].weight.requires_grad
trainer_utils.activate_model(model, ["0."])
assert model[0].weight.requires_grad

source = {"w": torch.tensor([1.0, 2.0]), "count": torch.tensor(3)}
copied = model_deepcopy.Processor(client_id=1).process(source)
copied["w"].add_(1)
assert torch.equal(source["w"], torch.tensor([1.0, 2.0]))
assert copied["count"].dtype == torch.int64

@decorators.timeit
def value():
    return 8

result, elapsed = value()
assert result == 8 and elapsed >= 0
assert value.__name__ == "value"

for indices in [[], [0, 7, 10]]:
    assert homo_enc.bitmap_to_indices(homo_enc.indices_to_bitmap(indices)) == indices

config = build_minimal_config()
config["algorithm"].update(n_features=2, discrete_action_space=False, min_action=-1,
                           max_action=1, mode="test", test_step=2)
with configure_environment(config):
    from plato.utils.reinforcement_learning.rl_agent import RLAgent
    from plato.utils.reinforcement_learning.rl_server import RLServer

    class Agent(RLAgent):
        def process_experience(self):
            raise AssertionError("Test mode must not train")

        def update_policy(self):
            raise AssertionError("Test mode must not update a policy")

    class Server(RLServer):
        def prep_state(self):
            return np.array([0.1, 0.2, 0.3, 0.4])

        def apply_action(self):
            self.smart_weighting = self.agent.action

    server = Server.__new__(Server)
    server.trainer = SimpleNamespace(zeros=torch.zeros)
    server.agent = Agent()
    server.agent.policy = SimpleNamespace(select_action=lambda _state: np.array([0.25, 0.75]))
    updates = [SimpleNamespace(report=SimpleNamespace(num_samples=count)) for count in [2, 6]]
    deltas = [{"w": torch.tensor([1.0, 2.0])}, {"w": torch.tensor([5.0, 8.0])}]
    result = asyncio.run(server.aggregate_deltas(updates, deltas))
    torch.testing.assert_close(result["w"], torch.tensor([4.0, 6.5]))
    assert server.total_samples == 8
    assert server.agent.current_step == 1
    assert not server.agent.action_updated.is_set()
print(json.dumps({"parameter_count": 6, "freeze_activate": "passed",
                  "model_deepcopy_no_alias": "passed", "timeit": "passed",
                  "he_bitmap_roundtrip": "passed", "optional_formatter": "stubbed",
                  "rl_agent_server_adaptive_aggregation": "passed"}))
