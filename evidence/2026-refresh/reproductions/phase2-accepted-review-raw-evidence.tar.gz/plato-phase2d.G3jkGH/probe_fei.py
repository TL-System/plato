"""Owned bounded FEI audit; no downloads, sockets, or example source edits."""
import importlib.util
import json
import pathlib
import tomllib

import numpy as np
import torch

from plato.config import Config
from tests.integration.utils import configure_environment

ROOT = pathlib.Path.cwd()
SCRATCH = pathlib.Path("/tmp/plato-phase2d.G3jkGH")

def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

with (ROOT / "examples/reinforcement_learning/fei/fei_FashionMNIST_lenet5.toml").open("rb") as handle:
    config = tomllib.load(handle)
config["clients"].update(total_clients=3, per_round=3)
config["algorithm"].update(batch_size=2, hidden_size=8, replay_size=16)
runtime = SCRATCH / "fei-runtime"
runtime.mkdir(exist_ok=True)

with configure_environment(config, runtime_root=runtime):
    np.random.seed(17)
    torch.manual_seed(17)
    agent_module = load("phase2d_fei_agent", "examples/reinforcement_learning/fei/fei_agent.py")
    server_module = load("phase2d_fei_server", "examples/reinforcement_learning/fei/fei_server.py")
    agent = agent_module.RLAgent()
    agent.total_steps = config["algorithm"]["start_steps"] + 1
    for length in [1, 2, 3, 2]:
        agent.state = np.arange(length * 4).reshape(length, 4) / 10
        agent.next_state = agent.state + 0.05
        agent.prep_action()
        assert np.isfinite(agent.action).all()
        assert abs(agent.action.sum() - 1) < 1e-6
        agent.process_experience()
    losses = agent.policy.update()
    assert all(np.isfinite(loss) for loss in losses)
    with np.errstate(invalid="ignore", divide="ignore"):
        zero_normalization = server_module.RLServer.normalize_state([0.0, 0.0])
    from plato.utils.reinforcement_learning import rl_server
    forwarded = {}
    original_init = rl_server.RLServer.__init__
    agent_arg, model_arg, algorithm_arg, trainer_arg = (object() for _ in range(4))

    def observe_init(self, agent, model=None, datasource=None, algorithm=None, trainer=None):
        forwarded.update(agent=agent, model=model, datasource=datasource,
                         algorithm=algorithm, trainer=trainer)

    try:
        rl_server.RLServer.__init__ = observe_init
        server_module.RLServer(agent_arg, model_arg, algorithm_arg, trainer_arg)
    finally:
        rl_server.RLServer.__init__ = original_init
    constructor_correct = (forwarded["algorithm"] is algorithm_arg
                           and forwarded["trainer"] is trainer_arg)
    print(json.dumps({
        "fei_agent_replay_and_policy_update": "passed",
        "replay_transitions": len(agent.policy.replay_buffer),
        "losses": list(losses),
        "server_zero_feature_normalization_finite": bool(np.isfinite(zero_normalization).all()),
        "zero_feature_output": [str(value) for value in zero_normalization],
        "server_constructor_dependency_forwarding_correct": constructor_correct,
        "algorithm_received_as_datasource": forwarded["datasource"] is algorithm_arg,
        "trainer_received_as_algorithm": forwarded["algorithm"] is trainer_arg,
        "trainer_received_as_none": forwarded["trainer"] is None,
        "followup": "Phase 4 FEI owner: zero feature norms yield NaN; constructor misroutes algorithm/trainer dependencies."
    }, indent=2))
