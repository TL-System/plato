"""Record ROOT-2D-01 with immutable source identities and retained raw results."""

import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/private/tmp/plato-refresh-worktrees/payloads')
SCRATCH = Path('/tmp/plato-phase2d.G3jkGH')
BASELINE = 'aa232791f04d93eb9de09ed6c596ac714db5b605'
TESTED = '15c79d0c81ffd0e5e4873db869a2863f97fe8279'
EVIDENCE = ROOT / 'evidence/2026-refresh/phase2d-validation.json'
REPORT = Path('/Users/bli/Playground/plato/evidence/2026-refresh/phase2d-root-base-probe.json')


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()


def artifact(path):
    path = Path(path)
    return {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def summary(label, outcome, xml=False):
    record = json.loads((SCRATCH / f'{label}.json').read_text())
    assert record['source_commit'] == TESTED and record['exit_code'] == 0
    item = {key: record[key] for key in
            ('source_commit', 'command', 'exit_code', 'elapsed_seconds')}
    item['result'] = outcome
    item['log'] = artifact(record['raw_log'])
    item['run_record'] = artifact(SCRATCH / f'{label}.json')
    if xml:
        path = SCRATCH / f'{label}.xml'
        suites = list(ET.parse(path).getroot().iter('testsuite'))
        assert len(suites) == 1
        item['junit'] = {key: int(suites[0].attrib[key]) for key in
                         ('tests', 'failures', 'errors', 'skipped')}
        item['junit']['passed'] = (item['junit']['tests'] -
                                  item['junit']['skipped'])
        assert item['junit']['errors'] == item['junit']['failures'] == 0
        item['junit_artifact'] = artifact(path)
    return item


def base_environment(suffix):
    record = json.loads((SCRATCH / f'base-green-suite{suffix}.json').read_text())
    assert not any(record['optional_presence'].values())
    item = {key: record[key] for key in
            ('python', 'optional_presence', 'installed_distribution_count',
             'installed_distributions_sha256')}
    if suffix == '313':
        item.update(
            path='/tmp/plato-phase2-root/base-313',
            ownership='Root-owned; explicitly authorized read-only reuse. Never synced, removed or reconfigured by this author; package bytecode writes disabled.',
            provision_command='uv sync --project /tmp/plato-refresh-worktrees/payloads --locked --python 3.13 --no-default-groups --group test-base',
            provision_source='Root report environment.profile; provisioned by root before this correction.',
        )
    else:
        item.update(
            path='/tmp/plato-phase2d.G3jkGH/base314',
            ownership='Task-owned isolated environment retained in owned scratch.',
            provision_command='UV_PROJECT_ENVIRONMENT=/tmp/plato-phase2d.G3jkGH/base314 uv sync --locked --python 3.14 --no-default-groups --group test-base',
            provision_log=artifact(SCRATCH / 'base-sync314.log'),
        )
    return item


assert git('rev-parse', 'HEAD') == TESTED
assert git('diff', BASELINE, TESTED, '--', 'plato', 'cleanup.py') == ''
assert git('status', '--porcelain') == ''
data = json.loads(EVIDENCE.read_text())
assert data['commit_identity']['final_tested_implementation_commit'] == '639ca69bf4eaeff868462d0b30a5fcc72218f061'
assert hashlib.sha256((ROOT / 'uv.lock').read_bytes()).hexdigest() == data['environment']['uv_lock_sha256']
assert json.loads(REPORT.read_text())['candidate_commit'] == BASELINE

identity = data['commit_identity']
identity['final_tested_implementation_commit'] = TESTED
identity['final_tested_implementation_tree'] = git('rev-parse', f'{TESTED}^{{tree}}')
identity['implementation_commits'].append(TESTED)
identity['root_base_probe_candidate_commit'] = BASELINE
identity['source_status_before_evidence'] = (
    'Clean tracked tree at 15c79d0c. Clean locked base collection and the entire base '
    'non-runtime suite ran on both Python versions at this exact source; the two '
    'corrected test modules also ran in mandatory with actual Kazoo/Gymnasium. '
    'Prior 95-case correction suites remain attributed to 639ca69b and original '
    'full mandatory suites to e7c0d595; no unchanged startup rerun is claimed.'
)

envs = [base_environment(suffix) for suffix in ('313', '314')]
data['environment']['locked_base_profile_environments'] = envs

test_files = ['tests/mpc/test_round_store_contracts.py',
              'tests/utils/test_rl_payload_utilities.py']
manifest = []
for path in test_files:
    manifest.append({
        'path': path,
        'git_blob': git('rev-parse', f'{TESTED}:{path}'),
        'sha256': hashlib.sha256((ROOT / path).read_bytes()).hexdigest(),
        'red_git_blob': git('rev-parse', f'{BASELINE}:{path}'),
    })

red = []
for suffix, env in zip(('313', '314'), envs):
    log = SCRATCH / f'base-red-collection{suffix}.log'
    text = log.read_text()
    assert "No module named 'kazoo'" in text and "No module named 'gymnasium'" in text
    assert '373/421 tests collected (48 deselected), 2 errors' in text
    red.append({
        'source_commit': BASELINE,
        'python': env['python'],
        'command': [str(Path(env['path']) / 'bin/python'), '-m', 'pytest',
                    'tests', '--collect-only', '--test-profile=base',
                    '-m', 'not runtime', '-q'],
        'exit_code': 2,
        'result': '373/421 tests collected, 48 runtime cases deselected; two collection errors from top-level Kazoo/Gymnasium imports. Neither test body ran.',
        'log': artifact(log),
    })

green_collection = [summary(f'base-green-collection{suffix}',
                           '386/434 tests collected, 48 runtime cases deselected; no collection errors.')
                    for suffix in ('313', '314')]
green_base = [summary(f'base-green-suite{suffix}',
                     '383 passed, four existing allowed profile skips, 48 runtime cases deselected; no new failures or skips.', xml=True)
              for suffix in ('313', '314')]
green_mandatory = [summary(f'base-correction-mandatory{suffix}',
                          '13 passed, no skips; actual Kazoo LockTimeout and Gymnasium Box used, UserWarning treated as error.', xml=True)
                   for suffix in ('313', '314')]

skip_records = []
for case in ET.parse(SCRATCH / 'base-green-suite313.xml').getroot().iter('testcase'):
    skipped = case.find('skipped')
    if skipped is not None:
        skip_records.append({
            'test': '.'.join(filter(None, [case.attrib.get('classname'),
                                         case.attrib['name']])),
            'reason': (skipped.text or skipped.attrib['message']).strip(),
        })
assert len(skip_records) == 4

data['base_profile_correction'] = {
    'id': 'ROOT-2D-01',
    'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
    'root_report': artifact(REPORT),
    'root_report_handling': 'Read-only reference; root report and root raw log were not edited.',
    'reviewed_candidate': BASELINE,
    'implementation_commit': TESTED,
    'status': 'Corrected and source-attributed red/green validated; fresh independent review pending.',
    'finding': 'Two new optional-library imports blocked clean test-base collection. Removing only the Kazoo exception import would also leave RoundInfoStore construction blocked because KazooClient and Lock are both None without Kazoo.',
    'correction': [
        'Patch both fake KazooClient and fake acquired Lock before constructing the remote RoundInfoStore; retain the failed-lock, finite-wait, stop/release and no-write/service-error assertions.',
        'Use TimeoutError as the fake timeout contract in base and import actual kazoo.exceptions.LockTimeout inside the mandatory fixture.',
        'Use the numeric shape/float32 bounds action-space contract in base and actual gymnasium.spaces.Box in mandatory. Preserve all five active policy finite-update/checkpoint variants and every other RL assertion.',
        'No production code, metadata, shared conftest, new skips or optional-package prerequisites changed.',
    ],
    'source_identity_manifest': manifest,
    'red': red,
    'green_collection': green_collection,
    'green_base_non_runtime': green_base,
    'green_mandatory_affected': green_mandatory,
    'source_tests_ran': {
        'base_both_interpreters': 'pytest tests --test-profile=base -m "not runtime" at 15c79d0c: entire selected non-runtime test tree, including all unchanged 2D-R01..R04 regressions, MPC lifecycle/registry/store/weighted reconstruction, processors, Unicode TOML, HE, active RL, S3 and existing config smokes. Hashed JUnit artifacts identify every executed case.',
        'mandatory_both_interpreters': test_files,
        'mandatory_actual_library_contracts': 'Real Kazoo 2.11.0 LockTimeout propagation via fake service lock; real Gymnasium 1.3.0 Box passed through actual SAC stochastic/deterministic updates and checkpoints. All 13 cases execute, no profile-based skips.',
        'existing_base_skips_both_interpreters': skip_records,
    },
    'execution_environment': {
        'cwd': str(ROOT),
        'shell': 'zsh -lc for every shell invocation.',
        'thread_limits': data['environment']['thread_limits_for_tests_and_probes'],
        'additional_environment': {'PYTHONDONTWRITEBYTECODE': '1',
                                   'HF_HUB_OFFLINE': '1',
                                   'HF_DATASETS_OFFLINE': '1',
                                   'TOKENIZERS_PARALLELISM': 'false'},
        'command_note': 'Commands are exact normalized child argv; bounded runner used for green runs, with source HEAD asserted identical before/after. Raw runner JSON/logs retained. Red collection ran before any correction at aa232791.',
        'uv_lock_sha256': data['environment']['uv_lock_sha256'],
        'base_environments': 'environment.locked_base_profile_environments records fingerprints, optional-library absence and ownership.',
        'mandatory_environments': 'Existing task-owned locked dev venv313/venv314; fingerprints unchanged from environment.isolated_locked_dev_environments. Both contain actual Kazoo/Gymnasium.',
        'runner': artifact(SCRATCH / 'run_profile_validation.py'),
    },
    'static_checks': [
        {'command': ['/tmp/plato-phase2d.G3jkGH/venv313/bin/ruff', 'check',
                     *test_files, '--select', 'I'],
         'result': 'All checks passed.',
         'log': artifact(SCRATCH / 'base-correction-ruff.log')},
        {'command': f'git diff --check {BASELINE} {TESTED}', 'result': 'Passed.'},
        {'command': f'git diff --exit-code {BASELINE} {TESTED} -- plato cleanup.py',
         'result': 'Passed; all production implementation source, including the four prior accepted corrections and S3 interface, is byte-identical.'},
    ],
    'limitations': [
        'Base clean collection and full non-runtime execution were newly run on both interpreters. The 48 runtime/startup cases were explicitly deselected as authorized for test-only changes; retained historical full mandatory results remain at e7c0d595, not claimed at this candidate.',
        'Mandatory execution here covers the two corrected modules only; prior 95-case review-correction checks remain attributed to 639ca69b. No new full mandatory or type-check rerun is claimed.',
        'Kazoo behavior remains a realistic fake backend plus the real exception type, with no live ZooKeeper deployment. Gymnasium qualification uses real Box, with no complete Gym/FEI example deployment.',
        'B-owned S3 transport normalization is untouched. Root still verifies the accepted combined utility/runtime candidate and orchestrates fresh independent review.',
    ],
}
data['owned_temporary_resources']['contents'].extend([
    'Task-owned base314 locked test-base environment and provisioning log',
    'Source-attributed base red/green collection, full base non-runtime and mandatory affected logs/run records/JUnit artifacts; profile runner and evidence updater',
])
data['owned_temporary_resources']['borrowed_read_only_resources'] = [
    {'path': '/tmp/plato-phase2-root/base-313',
     'owner': 'Root',
     'handling': 'Explicitly authorized read-only reuse; never synced or removed; package bytecode writes disabled.'},
    {'path': str(REPORT), 'owner': 'Root', 'handling': 'Read-only report reference.'},
]

EVIDENCE.write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps({'tested_commit': TESTED,
                  'base_green_each': green_base[0]['junit'],
                  'mandatory_green_each': green_mandatory[0]['junit'],
                  'evidence': str(EVIDENCE)}))
