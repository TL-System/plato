"""Append exact author correction evidence without changing retained artifacts."""
import datetime
import hashlib
import json
import pathlib
import subprocess
import xml.etree.ElementTree as ET

ROOT = pathlib.Path('/private/tmp/plato-refresh-worktrees/payloads')
SCRATCH = pathlib.Path('/tmp/plato-phase2d.G3jkGH')
PREVIOUS = 'a4a4733e96cf248a73db76e6b2182536b9f592ea'
FULL_MATRIX = 'e7c0d59571d88efd7eb1fdbf4fc63ac2a7b81395'
FINAL = '639ca69bf4eaeff868462d0b30a5fcc72218f061'
REVIEW = pathlib.Path('/Users/bli/Playground/plato/evidence/2026-refresh/phase2d-review.json')
DESTINATION = ROOT / 'evidence/2026-refresh/phase2d-validation.json'

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()

def artifact(path):
    path = pathlib.Path(path)
    return {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def invocation(label):
    record = json.loads((SCRATCH / f'{label}.json').read_text())
    result = {key: record[key] for key in ('command', 'exit_code', 'elapsed_seconds')}
    result['log'] = artifact(SCRATCH / f'{label}.log')
    xml = SCRATCH / f'{label}.xml'
    if xml.exists():
        suites = ET.parse(xml).getroot()
        counts = {key: sum(int(s.attrib[key]) for s in suites)
                  for key in ('tests', 'failures', 'errors', 'skipped')}
        counts['passed'] = counts['tests'] - sum(counts[key] for key in ('failures', 'errors', 'skipped'))
        result['junit'] = counts
    return result

assert git('rev-parse', 'HEAD') == FINAL
evidence = json.loads(subprocess.check_output([
    'git', '-C', str(ROOT), 'show',
    f'{PREVIOUS}:evidence/2026-refresh/phase2d-validation.json',
], text=True))
assert evidence['commit_identity']['final_tested_implementation_commit'] == FULL_MATRIX
review = json.loads(REVIEW.read_text())
assert review['identity']['candidate_commit'] == PREVIOUS
assert [finding['id'] for finding in review['findings']] == ['2D-R01', '2D-R02', '2D-R03', '2D-R04']
for label in ('review-green313', 'review-green314'):
    assert invocation(label)['exit_code'] == 0
    assert invocation(label)['junit'] == {'tests': 95, 'failures': 0, 'errors': 0, 'skipped': 0, 'passed': 95}
    record = json.loads((SCRATCH / f'{label}.json').read_text())
    assert record['packages'] == evidence['environment']['relevant_versions_shared_by_both']
    assert record['thread_limits'] == evidence['environment']['thread_limits_for_tests_and_probes']

identity = evidence['commit_identity']
identity['previous_reviewed_candidate_commit'] = PREVIOUS
identity['retained_full_matrix_commit'] = FULL_MATRIX
identity['final_tested_implementation_commit'] = FINAL
identity['final_tested_implementation_tree'] = git('rev-parse', f'{FINAL}^{{tree}}')
identity['evidence_carrier'] = 'A following documentation-only commit updates this sole evidence file. Its exact identity is reported in the root handoff, avoiding a self-hash; runtime and test source are unchanged from the tested implementation commit above.'
identity['implementation_commits'].append(FINAL)
identity['source_status_before_evidence'] = 'Clean tracked tree at 639ca69b; both scoped correction suites run at this exact implementation commit. Original full suites are retained explicitly at e7c0d595 and are not claimed as rerun at the correction commit.'
evidence['validation_date_local'] = datetime.datetime.now().date().isoformat()

validation = evidence['validation']
full = validation.pop('final_full_results_at_exact_implementation_commit')
validation['retained_full_runtime_matrix'] = {'source_commit': FULL_MATRIX, **full,
    'retention_basis': 'Four bounded corrections touch MPC lifecycle protocol kwargs, QSGD, Shamir coefficient selection and TOML; general socket/event-loop/transport/startup source is unchanged. The changed MPC wiring is broadened through actual lifecycle/registry/store/server reconstruction, all client lifecycle variants and all existing config smokes below. User explicitly permits retaining the unchanged full runtime matrix. No full suite, real socket matrix, HE/RL matrix or coverage rerun at 639ca69b.'}
validation['focused_green']['source_identity_note'] = 'Retained original delivery focused run; not rerun at the review-correction commit.'
validation['initial_full_results']['explanation'] = validation['initial_full_results']['explanation'].replace('Final commit replaces', 'Historical e7c0d595 commit replaces').replace('justified final full reruns below', 'justified retained full reruns at e7c0d595')
validation['coverage']['result'] = '1909/2413 executable lines (79.11%) at dba6f85b across processors/serialization/mpc/utils. Includes reserved third_party and Nanochat; not an owned-only or acceptance percentage. Runtime was identical to e7c0d595; the review correction changes four runtime files and three tests, without rerunning this historical coverage measurement. Standalone utility/FEI probes are not part of measured pytest coverage.'

source_tests = [
    'tests/mpc/test_mpc.py', 'tests/mpc/test_mpc_regressions.py',
    'tests/mpc/test_round_store_contracts.py',
    'tests/processors/test_processing_pipeline.py',
    'tests/processors/test_payload_regressions.py',
    'tests/utils/test_shared_payload_utilities.py',
    'tests/clients/test_client_lifecycle_variants.py',
    'tests/integration/test_smoke_configs.py',
]
changed_runtime = ['plato/clients/strategies/mpc.py',
                   'plato/processors/model_dequantize_qsgd.py',
                   'plato/processors/mpc_model_encrypt_shamir.py',
                   'plato/utils/toml_writer.py']
manifest = []
for filename in changed_runtime + source_tests:
    contents = subprocess.check_output(['git', '-C', str(ROOT), 'show', f'{FINAL}:{filename}'])
    assert (ROOT / filename).read_bytes() == contents
    manifest.append({'path': filename, 'git_blob': git('rev-parse', f'{FINAL}:{filename}'),
                     'sha256': hashlib.sha256(contents).hexdigest()})
assert git('rev-parse', f'{PREVIOUS}:plato/utils/s3.py') == git('rev-parse', f'{FINAL}:plato/utils/s3.py')

evidence['review_corrections'] = {
    'corrected_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'review': artifact(REVIEW),
    'reviewed_candidate': PREVIOUS,
    'implementation_commit': FINAL,
    'status': 'All four findings corrected and green locally; fresh independent review and root merged acceptance remain pending.',
    'findings': [
        {'id': '2D-R01', 'correction': 'MPCLifecycleStrategy.configure binds Shamir threshold from server.mpc_shamir_threshold before DefaultLifecycleStrategy instantiates the registry pipeline. Server protocol kwargs override explicit per-processor threshold entries, including None for the existing max(n-2,1) default; unrelated processor kwargs preserved. Direct processor/strategy constructors still retain their explicit threshold API.',
         'red': 'Configured 1 and 2 with five clients produced independent weighted-reference errors 0.00393 and 0.00101157; explicit conflicting threshold 4 produced error 0.02264186. Default/no-override control passed. Fourth red case checks the newly defined default-authoritative kwargs policy rather than a separate numerical defect.',
         'green': 'Five actual config-driven cases use fractional counts [0.5,0,2.5,1,3], a real configured RoundInfoStore, actual MPCLifecycleStrategy.configure -> default lifecycle -> registry -> Shamir/Safetensors pipeline, actual server wrapper and weighted strategy, reversed report order and independent plaintext sums; abs tolerance 2e-6.',
         'test': 'tests/mpc/test_mpc_regressions.py::test_configured_shamir_client_lifecycle_matches_server_reconstruction',
         'limit': 'Only general FedAvg parent server initialization is replaced with the existing round-lock field to isolate startup; MPC wrapper construction, from_config store, client lifecycle/registry and aggregation execute unchanged actual methods. No sockets or distributed MPC deployment claim.'},
        {'id': '2D-R02', 'correction': 'Divide bounded QSGD codes by tuning_param before multiplying the finite header scale. Existing max-norm equation, sign/magnitude wire and float32 result preserved.',
         'red': 'Finite +/-1e38 and +/-3e38 endpoints reconstructed as infinities at levels 16/64/128 on both interpreters. Ordinary scale 3.75 and level-2 controls passed.',
         'green': 'Twelve cases cover scales 3.75/1e38/3e38 and levels 2/16/64/128, finite endpoints against independent source float64 reference and max-norm error bound with two float32 eps of scale tolerance. Existing seeded ordinary/empty/zero/malformed tests also pass.',
         'test': 'tests/processors/test_payload_regressions.py::test_qsgd_finite_endpoints_and_error_bound_at_large_scales'},
        {'id': '2D-R03', 'correction': 'Quoted keys/string values emit supplementary characters intact using ensure_ascii=False; DEL explicitly remains escaped. Existing mixed-array/null/comment conventions retained.',
         'red': 'Stdlib tomllib rejected surrogate escapes for non-BMP key, string value, nested array-table key/value, and a DEL-plus-emoji value. Pure DEL control passed.',
         'green': 'Five cases roundtrip through actual dumps and UTF-8 dump files with stdlib tomllib.loads/load; rocket/supplementary CJK/lightbulb, dotted nested names, comment text and DEL all preserved. Existing BMP/nested/mixed-array tests remain green.',
         'test': 'tests/utils/test_shared_payload_utilities.py::test_toml_supplementary_unicode_and_control_escapes_roundtrip'},
        {'id': '2D-R04', 'correction': 'Check pool capacity after excluding the scaled secret and sample without replacement; no rejection-sampling loop. Existing 1..999 distinct coefficient pool, real-valued polynomial scaling, coordinate wire and declared/default threshold retained.',
         'red': 'Public process with 1000 selected clients, threshold 1000 and scalar 0.000010 entered processing but exceeded a contained 12-second subprocess deadline on both interpreters. Scaled constant 10 consumes one of 999 pool entries, leaving 998 for 999 requested coefficients.',
         'green': 'Same public call raises useful coefficient-pool ValueError within the enforced two-second processing bound; real persisted round_info bytes and directory contents unchanged. Parent subprocess deadline remains 12 seconds and contains the historical loop. Matched ordinary/default/higher-threshold reconstruction stays green.',
         'test': 'tests/mpc/test_mpc_regressions.py::test_impossible_shamir_coefficient_pool_is_bounded_before_persistence'},
    ],
    'red_source_identity': 'Production source exactly a4a4733e. New regression tests were uncommitted before runtime fixes; the pool harness was refined only to assert its entered marker, then rerun independently before fixes. Reviewer scratch/scripts were read-only references and remain untouched.',
    'red': {'python313': invocation('review-red313'), 'python314': invocation('review-red314'),
            'result_both': '15 failed, 8 passed; all four concrete findings reproduced, with passing controls and one explicit-kwargs policy expectation identified above.'},
    'refined_pool_red': {'python313': invocation('review-red-bound313'), 'python314': invocation('review-red-bound314'),
                         'result_both': '1 failed: public process entered, then exceeded 12-second deadline; subprocess.run killed/waited the owned worker.'},
    'green': {'python313': invocation('review-green313'), 'python314': invocation('review-green314'),
              'result_both': '95 passed, zero failures/errors/skips; UserWarning treated as errors. Python 3.13 reported 2.22s, 3.14 reported 2.23s (wrapper wall timings recorded separately).'},
    'source_test_files_executed_at_implementation_commit': source_tests,
    'source_identity_manifest': manifest,
    'static_checks': [
        {'command': f'{SCRATCH}/venv313/bin/ruff check ' + ' '.join(changed_runtime + ['tests/mpc/test_mpc_regressions.py', 'tests/processors/test_payload_regressions.py', 'tests/utils/test_shared_payload_utilities.py']) + ' --select I', 'result': 'All checks passed', 'log': artifact(SCRATCH / 'review-ruff.log')},
        {'command': f'{SCRATCH}/venv313/bin/ty check --python {SCRATCH}/venv313/bin/python ' + ' '.join(changed_runtime), 'result': 'All checks passed', 'log': artifact(SCRATCH / 'review-ty.log')},
        {'command': f'git diff --check {PREVIOUS} {FINAL}', 'result': 'Passed'},
    ],
    'environment': 'Reused only the existing owned locked venv313/venv314; package versions and four thread limits match original evidence. No provisioning/upgrades, other-worktree/environment writes, metadata/CI edits or shared-overlap test edits in this correction.',
    'retained_unchanged_boundaries': {'S3_git_blob_both_candidates': git('rev-parse', f'{FINAL}:plato/utils/s3.py'),
        'runtime_transport': 'B-owned runtime/transport untouched. B original author is correcting historical 2D-17/T2B-S3-PREFIX concurrently; latest combined root integration was not rerun here.',
        'general_runtime_matrix': 'Retained only at e7c0d595 as identified above. Fresh independent exact-candidate review and root merged gate required; no new phase-wide/full-suite PASS claimed.'},
    'primary_documentation': ['https://toml.io/en/v1.0.0#string', 'https://docs.python.org/3.13/library/random.html#random.sample'],
    'resources': 'All review-fix logs/XML/JSON, pytest runtimes, commit messages and this evidence updater retained within original owned scratch. No reviewer scratch changes or cleanup.',
}
evidence['limitations'][2] += ' Coefficient requests must also fit the distinct 1..999 pool excluding the scaled constant; impossible capacity now fails promptly. Bounded sampling preserves that prototype distribution, with a different RNG draw sequence from rejection sampling.'
evidence['root_followups'][0]['coordination_update'] = 'B original author concurrently fixes this known interface handoff using the unchanged 2D S3 utility as provisional reference. Historical combined probe remains explicitly at b3b038e/e7c0d595. Root revalidates the accepted final combination; no B-owned runtime edits by 2D.'
evidence['root_followups'][-1]['action'] = 'Fresh independent review of the corrected exact evidence-carrier commit, root-owned archive index update, and root merged validation including corrected B transport.'
DESTINATION.write_text(json.dumps(evidence, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'implementation_commit': FINAL, 'green_each': 95, 'evidence': str(DESTINATION)}))
