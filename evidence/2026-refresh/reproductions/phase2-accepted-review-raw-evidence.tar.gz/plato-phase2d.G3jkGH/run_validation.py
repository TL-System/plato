"""Record bounded validation invocations and exit statuses in owned scratch."""
import json
import os
import pathlib
import platform
import subprocess
import sys
import time
from importlib import metadata

scratch = pathlib.Path("/tmp/plato-phase2d.G3jkGH")
label = sys.argv[1]
command = [sys.executable, *sys.argv[2:]]
environment = dict(os.environ)
limits = {name: "1" for name in (
    "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"
)}
environment.update(limits)
start = time.monotonic()
with (scratch / f"{label}.log").open("w") as handle:
    result = subprocess.run(command, env=environment, stdout=handle,
                            stderr=subprocess.STDOUT, timeout=1200)
summary = {
    "command": command, "cwd": str(pathlib.Path.cwd()), "thread_limits": limits,
    "exit_code": result.returncode, "elapsed_seconds": round(time.monotonic() - start, 2),
    "python": sys.version, "platform": platform.platform(),
    "packages": {name: metadata.version(name) for name in (
        "torch", "numpy", "safetensors", "boto3", "botocore", "requests", "urllib3",
        "tenseal", "kazoo", "gymnasium", "zstd", "pytest", "ruff", "ty"
    )},
    "raw_log": str(scratch / f"{label}.log")
}
(scratch / f"{label}.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary))
raise SystemExit(result.returncode)
