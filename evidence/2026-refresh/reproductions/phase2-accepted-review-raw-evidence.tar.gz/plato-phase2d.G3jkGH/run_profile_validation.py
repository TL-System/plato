"""Record bounded profile checks without installing or altering dependencies."""
import hashlib
import importlib.util
import json
import os
import pathlib
import platform
import subprocess
import sys
import time
from importlib import metadata

SCRATCH = pathlib.Path('/tmp/plato-phase2d.G3jkGH')
ROOT = pathlib.Path.cwd()
label = sys.argv[1]
command = [sys.executable, *sys.argv[2:]]
environment = dict(os.environ)
limits = {name: '1' for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS',
                               'MKL_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')}
environment.update(limits)
environment.update(PYTHONDONTWRITEBYTECODE='1', HF_HUB_OFFLINE='1',
                   HF_DATASETS_OFFLINE='1', TOKENIZERS_PARALLELISM='false')

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()

before = git('rev-parse', 'HEAD')
start = time.monotonic()
with (SCRATCH / f'{label}.log').open('w') as handle:
    result = subprocess.run(command, env=environment, stdout=handle,
                            stderr=subprocess.STDOUT, timeout=1200)
after = git('rev-parse', 'HEAD')
assert after == before
packages = sorted((item.metadata['Name'], item.version)
                  for item in metadata.distributions())
versions = {}
for name in ('torch', 'numpy', 'safetensors', 'tenseal', 'pytest', 'boto3',
             'botocore', 'requests', 'urllib3', 'kazoo', 'gymnasium',
             'opacus', 'tiktoken'):
    try:
        versions[name] = metadata.version(name)
    except metadata.PackageNotFoundError:
        versions[name] = None
summary = {
    'command': command, 'cwd': str(ROOT), 'source_commit': before,
    'thread_limits': limits, 'no_package_bytecode_writes': True,
    'offline_huggingface': True, 'exit_code': result.returncode,
    'elapsed_seconds': round(time.monotonic() - start, 2),
    'python': sys.version, 'platform': platform.platform(),
    'optional_presence': {name: importlib.util.find_spec(name) is not None
                          for name in ('kazoo', 'gymnasium', 'opacus', 'tiktoken')},
    'relevant_versions': versions, 'installed_distribution_count': len(packages),
    'installed_distributions_sha256': hashlib.sha256(
        json.dumps(packages, separators=(',', ':')).encode()).hexdigest(),
    'raw_log': str(SCRATCH / f'{label}.log'),
}
(SCRATCH / f'{label}.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: summary[key] for key in ('source_commit', 'exit_code',
                                               'elapsed_seconds', 'optional_presence',
                                               'raw_log')}))
raise SystemExit(result.returncode)
