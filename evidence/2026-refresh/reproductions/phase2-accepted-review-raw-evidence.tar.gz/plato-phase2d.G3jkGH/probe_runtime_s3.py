"""Read-only integration probe of pinned 2B ingress and fixed 2D S3 methods."""
import asyncio
import importlib.util
import json
import pathlib
import sys

import pytest

ROOT = pathlib.Path.cwd()
SCRATCH = pathlib.Path('/tmp/plato-phase2d.G3jkGH')

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

contract = load('phase2d_http_contract', ROOT / 'tests/utils/test_s3.py')
transport = load('phase2b_transport_snapshot', SCRATCH / 'phase2b_transport_b3b038e.py')
results = []
for prefix in ['', 'namespace', 'namespace/rounds', 'namespace/rounds/']:
    patch = pytest.MonkeyPatch()
    fixture = contract.service.__wrapped__(patch)
    service = next(fixture)
    try:
        storage = contract.storage(service, prefix)
        key = 'client_payload_7_ABC123'
        payload = {'weight': [1, 2], 'client': 7}
        storage.send_to_s3(key, payload)
        assert storage.receive_from_s3(key) == payload
        before = service.calls.copy()

        async def receive():
            transfer = transport.InboundTransfer(
                transport.TransportLimits(max_payload_bytes=1024, payload_timeout=2),
                lambda: None,
            )
            try:
                value = await transport.receive_s3_payload(
                    storage, key, transfer, transfer.reserve,
                )
                assert value == payload
                return {'result': 'passed', 'reserved_bytes': transfer.byte_count}
            except ValueError as error:
                return {'result': 'failed', 'error': str(error)}
            finally:
                transfer.close()

        outcome = asyncio.run(receive())
        actual_gets = [key for (method, key), count in service.calls.items()
                       if method == 'GET' and count > before[(method, key)]]
        results.append({'configured_prefix': prefix, 'normalized_key_prefix': storage.key_prefix,
                        'utility_stored_keys': list(service.objects),
                        'actual_runtime_get_keys': actual_gets, **outcome})
    finally:
        fixture.close()
        patch.undo()

assert results[0]['result'] == 'failed'
assert results[0]['utility_stored_keys'] == ['client_payload_7_ABC123']
assert results[0]['actual_runtime_get_keys'] == ['/client_payload_7_ABC123']
assert all(result['result'] == 'passed' for result in results[1:])
print(json.dumps({'runtime_candidate': 'b3b038efa376b060e1c01f1da39173240768a019',
                  'utility_commit': 'e7c0d59571d88efd7eb1fdbf4fc63ac2a7b81395',
                  'results': results,
                  'root_integration_need': 'After 2B acceptance, align object_key construction with S3._object_key(key): empty prefix uses key, nonempty prefix uses prefix/key once. B currently prepends a slash for empty prefix. Already-qualified keys also require exactly-once normalization.'}, indent=2))
