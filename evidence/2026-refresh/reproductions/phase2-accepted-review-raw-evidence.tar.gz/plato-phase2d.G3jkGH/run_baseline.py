"""Run committed regression tests against one exact baseline module snapshot."""
import importlib
import importlib.util
import sys

import pytest

target, path = sys.argv[1:3]
parent = importlib.import_module(target.rpartition(".")[0])
spec = importlib.util.spec_from_file_location(target, path)
module = importlib.util.module_from_spec(spec)
sys.modules[target] = module
spec.loader.exec_module(module)
setattr(parent, target.rpartition(".")[2], module)
if target == "plato.mpc.round_store":
    parent.RoundInfoStore = module.RoundInfoStore
    parent.RoundInfoState = module.RoundInfoState
raise SystemExit(pytest.main(sys.argv[3:]))
