"""Condense task-local validation into the sole durable Phase 2D evidence file."""
import hashlib
import json
import pathlib
import subprocess
import xml.etree.ElementTree as ET

ROOT = pathlib.Path('/private/tmp/plato-refresh-worktrees/payloads')
SCRATCH = pathlib.Path('/tmp/plato-phase2d.G3jkGH')
BASELINE = 'fda60becedfa6236c11d415b87a868b52789a41e'
FINAL = 'e7c0d59571d88efd7eb1fdbf4fc63ac2a7b81395'
THREADS = {name: '1' for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()

def raw(name):
    path = SCRATCH / name
    return {'path': str(path), 'sha256': sha(path)}

def invocation(label):
    data = json.loads((SCRATCH / f'{label}.json').read_text())
    result = {key: data[key] for key in ('command', 'exit_code', 'elapsed_seconds')}
    result['log'] = raw(f'{label}.log')
    if (SCRATCH / f'{label}.xml').exists():
        suites = ET.parse(SCRATCH / f'{label}.xml').getroot()
        result['junit'] = {'tests': sum(int(s.attrib['tests']) for s in suites),
                           'failures': sum(int(s.attrib['failures']) for s in suites),
                           'errors': sum(int(s.attrib['errors']) for s in suites),
                           'skipped': sum(int(s.attrib['skipped']) for s in suites),
                           'skips': [{'test': case.attrib['name'], 'reason': skip.attrib.get('message', '')}
                                     for case in suites.iter('testcase') for skip in case.findall('skipped')]}
        result['junit']['passed'] = result['junit']['tests'] - sum(result['junit'][key] for key in ('failures', 'errors', 'skipped'))
    return result

def red(log, targets, result, stage, caveat=None, snapshot=None):
    command = [str(SCRATCH / 'venv313/bin/python')]
    if snapshot:
        module, filename = snapshot
        command += [str(SCRATCH / 'run_baseline.py'), module, str(SCRATCH / filename)]
    else:
        command += ['-m', 'pytest']
    command += targets + ['-q']
    entry = {'command': command, 'stage': stage, 'result': result, 'log': raw(log)}
    if caveat:
        entry['interpretation'] = caveat
    if snapshot:
        entry['baseline_snapshot'] = {'source': module, 'baseline': BASELINE, 'sha256': sha(SCRATCH / filename)}
    return entry

assert git('rev-parse', 'HEAD') == FINAL
full313 = invocation('final-full313')
full314 = invocation('final-full314')
assert full313['exit_code'] == full314['exit_code'] == 0
assert full313['junit']['failures'] == full314['junit']['failures'] == 0

packages = json.loads((SCRATCH / 'final-full313.json').read_text())['packages']
envs = []
fingerprint_code = 'import hashlib,json,sys;from importlib import metadata; items=sorted((d.metadata["Name"],d.version) for d in metadata.distributions());print(json.dumps({"python":sys.version,"installed_distribution_count":len(items),"installed_distributions_sha256":hashlib.sha256(json.dumps(items,separators=(",",":")).encode()).hexdigest()}))'
for version in ('313', '314'):
    env = SCRATCH / f'venv{version}'
    info = json.loads(subprocess.check_output([str(env / 'bin/python'), '-c', fingerprint_code], text=True))
    info.update(path=str(env), provision_command=f'UV_PROJECT_ENVIRONMENT={env} uv sync --locked --group dev --python 3.{version[-2:]}', provision_log=raw(f'sync{version}.log'))
    envs.append(info)

evidence = {
    'schema_version': 1,
    'task': '2D: payloads, serialization, shared utilities, HE/MPC and cleanup',
    'validation_date_local': '2026-10-02',
    'worktree': str(ROOT),
    'branch': git('branch', '--show-current'),
    'commit_identity': {
        'baseline': BASELINE,
        'final_tested_implementation_commit': FINAL,
        'implementation_commits': [
            'af695c0f0dea3032116522b0c7131393e724f30d',
            '264b422d8b96420ff3c361e69f888a656fe8f512',
            '939d93cc289c0fb12a1c4084a1bc3dd72df293a7',
            'dba6f85b8140d0159d593ad14b371ecb2caa9ee2',
            FINAL,
        ],
        'evidence_carrier': 'A following documentation-only commit adds this file. Its exact identity is reported in the root handoff, avoiding a self-hash. The tested implementation tree is the commit above.',
        'source_status_before_evidence': 'Clean tracked tree; final full suites run at the exact final_tested_implementation_commit.',
    },
    'scope': {
        'owned': ['plato/processors/** except nanochat_tokenizer.py', 'plato/serialization/**', 'plato/mpc/**', 'plato/utils/** except third_party.py and reserved new archive.py', 'cleanup.py', 'plato/servers/fedavg_he.py', 'plato/servers/fedavg_mpc_additive.py', 'plato/servers/fedavg_mpc_shamir.py', 'plato/servers/strategies/mpc.py', 'plato/servers/strategies/aggregation/he.py', 'plato/clients/mpc.py', 'plato/clients/strategies/mpc.py', 'focused tests', 'accepted legacy_rl_env archive'],
        'untouched': ['pyproject.toml', 'uv.lock', 'CI', 'general client/server orchestration', 'trainers/algorithms', 'MLX implementations', 'shared conftest', 'Nanochat tokenizer', 'third_party.py', 'archive.py', 'active FEI example source'],
        'coordination': 'No nested agents, questions, cloud credentials, pushes, merges or PR edits. Extra findings use 2D IDs; F21-F24 remain reserved for trainer findings.',
        'accepted_addendum_sha256': sha(ROOT / 'evidence/2026-refresh/plan-addendum.json'),
    },
    'environment': {
        'platform': json.loads((SCRATCH / 'final-full313.json').read_text())['platform'],
        'uv': '0.12.22',
        'python_default_and_minimum': '3.13, unchanged',
        'python_version_file_sha256': sha(ROOT / '.python-version'),
        'uv_lock_sha256': sha(ROOT / 'uv.lock'),
        'isolated_locked_dev_environments': envs,
        'relevant_versions_shared_by_both': packages,
        'thread_limits_for_tests_and_probes': THREADS,
        'shell': 'zsh -lc for every shell invocation; commands below are normalized inner argv, with cwd and thread environment shared here.',
        'pinned_submodule': {'path': 'external/nanochat', 'commit': 'c75fe54aa7c1fa881701c246f9427bcbe4eee5a4', 'command': 'git submodule update --init external/nanochat', 'result': 'Initialized pinned revision only. DViT/T2TViT remain uninitialized and untouched.'},
    },
    'mandatory_findings': [
        {'id': 'F02', 'status': 'fixed', 'before': 'Configured prefixes were absent or applied inconsistently to storage operations.', 'after': 'put/send/receive/delete/list share one namespace helper, including physical keys returned by list; nested/trailing-slash prefixes applied exactly once.', 'tests': 'tests/utils/test_s3.py::test_put_send_receive_list_delete_use_one_namespace'},
        {'id': 'F03', 'status': 'fixed', 'before': 'An empty successful listing without Contents raised an error.', 'after': 'Empty successful pages produce []; real service failures still propagate.', 'tests': 'tests/utils/test_s3.py::test_empty_listing_succeeds_without_contents'},
        {'id': 'F04', 'status': 'fixed', 'before': 'Only a page was returned, without the configured namespace constraint.', 'after': 'ListObjectsV2 paginator consumes every page with Prefix namespace/; five matching objects over three pages and two unrelated objects independently checked.', 'tests': 'tests/utils/test_s3.py::test_all_pages_stay_in_namespace'},
        {'id': 'F05', 'status': 'fixed', 'before': 'Stalled real HTTP transfers exceeded the regression deadline; some errors were hidden.', 'after': 'Botocore connect/read 5/30 seconds, standard total_max_attempts=3; presigned GET/PUT use the same timeouts and at most three attempts, bounded backoff and disabled Retry-After delays. Error/timeout propagation and transient recovery verified on actual network paths.', 'tests': 'tests/utils/test_s3.py: ten stalled/error probes across PUT, GET, list, delete and initialization; successful GET/PUT/list recovery; 403, missing object and truncated pickle negatives', 'probe_limits': 'Tests reduce timeouts to 0.1/0.1 seconds and attempts to two, impose a 2.5-second public-method deadline and check actual HTTP request counts.'},
        {'id': 'F12', 'status': 'fixed', 'before': 'Flattened dotted/bracketed paths and reserved _tree_metadata could silently overwrite data.', 'after': 'Actual duplicate metadata paths and reserved tensor path rejected before Safetensors save. Literal dotted PyTorch state_dict names remain supported; existing wire layout preserved.', 'tests': 'tests/utils/test_safetensor_serialization.py: both collision insertion orders, bracket/nested collisions, empty keys, string-coerced duplicate keys, reserved tensor path; independent valid dotted/nested/dtype roundtrips'},
    ],
    'additional_findings': [
        {'id': '2D-01', 'status': 'fixed', 'finding': 'Strided Safetensors leaves serialized storage order with the original logical shape; native scalar metadata returned zero-dimensional arrays.', 'outcome': 'C-contiguous leaf serialization and native scalar restoration preserve transpose values and HE indices metadata.'},
        {'id': '2D-02', 'status': 'fixed', 'finding': 'Quantization changed integer/bool buffers; QSGD mishandled empty tensors, reset caller RNG and accepted invalid levels/trailing bytes.', 'outcome': 'Exact buffer dtype/value preservation, finite/shape/header validation, seeded stochastic rounding and explicit levels 2..128; independent error bound max(abs(x))/(levels-1)+1e-6.'},
        {'id': '2D-03', 'status': 'fixed', 'finding': 'Feature compression failed empty batches/noncontiguous arrays and lost empty target dtype; shared headers could corrupt heterogeneous batches.', 'outcome': 'Empty/strided/homogeneous arrays roundtrip exactly; incompatible feature shapes/dtypes fail explicitly before compression while retaining the existing shared-header wire.'},
        {'id': '2D-04', 'status': 'fixed', 'finding': 'CPU torch.device detection converted float32 feature tensors to float16 unnecessarily; randomized response mutated source tensors through a NumPy view.', 'outcome': 'Zero-noise CPU precision and targets preserved; randomized response works on a copy.'},
        {'id': '2D-05', 'status': 'fixed', 'finding': 'Unstructured pruning reused inferred modules after trainer.model was replaced.', 'outcome': 'Infer current model targets for each call; independent magnitude reference zeros 1..4 and retains 5..8 after replacement.'},
        {'id': '2D-06', 'status': 'fixed', 'finding': 'cleanup runtime fallback could follow a directory symlink and delete external checkpoints.', 'outcome': 'External resolved runtime and directory symlinks excluded; clean_directory refuses symlink targets; ordinary owned runtime/cache cleanup still executes.'},
        {'id': '2D-07', 'status': 'fixed', 'finding': 'Importing count_parameters executed model downloads; empty compound loaders failed; unary epsilon=2000 overflowed.', 'outcome': 'Demos guarded by main, loaders terminate with len=0, stable negative-exponent probabilities with finite nonnegative epsilon checks.'},
        {'id': '2D-08', 'status': 'fixed', 'finding': 'TOML Unicode keys and nested array-table paths produced invalid or misplaced output.', 'outcome': 'Independent stdlib tomllib roundtrip validates Unicode/literal dotted keys and nested array tables; historical mixed-type-array wrapper convention retained.'},
        {'id': '2D-09', 'status': 'fixed', 'finding': 'HE accepted invalid sample accounting/masks/vector lengths, reordered caller masks and replaced model state before successful reconstruction.', 'outcome': 'Cardinality/finite nonnegative counts, positive total, mask and vector contracts checked; zero-sample rounds return baseline, failed decode leaves encrypted_model intact; native CKKS matches independent plaintext at abs 2e-5.'},
        {'id': '2D-10', 'status': 'fixed', 'finding': 'Shamir reconstructed the wrong peer polynomial and single-client output retained sample scaling; floating polynomial arithmetic lost accuracy.', 'outcome': 'Correct sender/target share orientation, uniform normalization, integer coefficients/float64 exact-range checks and Fraction interpolation; thresholds 1/2/4 match independent weighted sums at abs 2e-6.'},
        {'id': '2D-11', 'status': 'fixed', 'finding': 'Incomplete additive participants and inconsistent reports/shares could bias aggregates; stale writers could contaminate a later round; zero sample counts were dropped.', 'outcome': 'Participant/contributor accounting, sample/key/shape/finiteness checks and round fences under the store lock; asynchronous training captures expected round and persists zero counts; failures leave baseline/next round untouched.'},
        {'id': '2D-12', 'status': 'fixed', 'finding': 'Interrupted local state saves destroyed the previous round; remote errors were misreported as missing rounds; failed/unbounded ZooKeeper lock acquisition leaked clients or allowed unlocked writes.', 'outcome': 'Atomic temporary-file replacement, missing-object-only fallback, finite start/lock waits and unconditional client stop; acquire false or errors prevent writes.'},
        {'id': '2D-13', 'status': 'fixed', 'finding': 'Active DDPG/SAC/TD3 replay dimensions broadcast incorrectly; SAC Box shape construction failed; loaded target networks remained stale.', 'outcome': 'Finite parameter-changing updates for DDPG, SAC stochastic/deterministic, TD3 plain/recurrent; detached SAC alpha, deterministic alpha zero and loaded target snapshots synchronized.'},
        {'id': '2D-14', 'status': 'fixed', 'finding': 'TD3 reused one transition target action and normalized across samples; asynchronous recurrent batch=1 failed and padding/source mutation coupled transitions.', 'outcome': 'Every target row used; per-transition normalization, length masking and masked critic averages preserve batch isolation and source sequences.'},
        {'id': '2D-15', 'status': 'handoff_phase4', 'location': 'examples/reinforcement_learning/fei/fei_server.py::RLServer.normalize_state', 'finding': 'Actual normalize_state([0.0, 0.0]) returns [NaN, NaN] on Python 3.13 and 3.14.', 'outcome': 'Concrete FEI probe retained; active example unchanged per root instruction.'},
        {'id': '2D-16', 'status': 'handoff_phase4', 'location': 'examples/reinforcement_learning/fei/fei_server.py::RLServer.__init__', 'finding': 'Actual subclass constructor forwards algorithm as datasource and trainer as algorithm; superclass trainer receives None.', 'outcome': 'Only superclass constructor capture instrumented, explicit agent/model/algorithm/trainer objects forwarded through actual subclass on both interpreters; active example unchanged.'},
        {'id': '2D-17', 'status': 'handoff_root_integration', 'location': '2B candidate plato/clients/transport.py::receive_s3_payload', 'finding': 'Combining fixed S3 with exact 2B candidate succeeds for nonempty/nested/trailing-slash prefixes; with empty prefix, utility writes client_payload_7_ABC123 but bounded reader requests /client_payload_7_ABC123 and gets 404.', 'outcome': 'Concrete actual local HTTP integration reproduced on both interpreters. Root must align bounded reader object-key composition with S3._object_key(key) after 2B acceptance; candidate under review remains unchanged.'},
    ],
    'audit_inventory': [
        {'files': 'processors/{base,model,pipeline,registry,model_deepcopy,safetensor_encode,safetensor_decode}.py', 'outcome': 'Production pipelines/registry order exercised, deep copies preserve dtype without aliasing, Safetensors encode/decode preserves nested metadata and default HE wire; initialization/export modules reviewed.'},
        {'files': 'processors/{compress,decompress,model_compress,model_decompress,model_quantize,model_dequantize,model_quantize_qsgd,model_dequantize_qsgd}.py; utils/zstd_helpers.py', 'outcome': 'Exact lossless and bounded lossy roundtrips, buffer dtype preservation and invalid QSGD wire/level negatives. Locked zstd backend exercised; trusted pickle boundary inventoried. No stdlib compression.zstd change: it would retain the 3.13 dependency/wire burden without demonstrated reduction.'},
        {'files': 'processors/{feature,feature_additive_noise,model_randomized_response,structured_pruning,unstructured_pruning}.py; utils/unary_encoding.py', 'outcome': 'CPU zero-noise precision, source immutability, zero/half pruning references, replacement-model pruning, probability stability and existing seeded unary stochastic expectations executed.'},
        {'files': 'serialization/safetensor.py; utils/tree.py', 'outcome': 'F12 adversarial rejection, ordinary dotted state_dict compatibility, independent NumPy/Torch bool/int/float64/bfloat16/scalar/strided/empty nested roundtrips, historical wire intact. Native MLX restoration remains outside this task qualification.'},
        {'files': 'processors/{model_encrypt,model_decrypt}.py; utils/homo_enc.py; servers/fedavg_he.py; servers/strategies/aggregation/he.py', 'outcome': 'Actual native CKKS partial/all/no-mask weighted aggregation and default registry Safetensors wire roundtrip; malformed/mutating masks, sample counts, lengths, zero total and model publication negatives; bitmap exact roundtrips.'},
        {'files': 'mpc/{__init__,round_store}.py; processors/mpc_model_encrypt_{additive,shamir}.py; servers/strategies/mpc.py', 'outcome': 'Real isolated local store, processors and aggregators independently weighted numerics, higher thresholds, single participant, zero samples, reversed reports, missing/duplicate/stale/malformed round contracts, race and atomic save failures. Kazoo startup/acquire/release cleanup and remote error contracts mocked at service boundary.'},
        {'files': 'servers/fedavg_mpc_{additive,shamir}.py; clients/mpc.py; clients/strategies/mpc.py', 'outcome': 'Wrapper/store/debug/threshold wiring reviewed; actual train strategy, zero samples and delayed-round fencing exercised; existing lifecycle and synthetic training smoke now use real persisted round state. Full distributed HE/MPC deployments remain Phase 4.'},
        {'files': 'utils/s3.py; cleanup.py', 'outcome': 'Public methods on real credential-free local HTTP service cover F02-F05, namespace ownership, all pages, stalls/status errors, successful transfers and retries; missing vs service failure distinction. Owned ordinary runtime/cache cleanup and external symlink preservation tested.'},
        {'files': 'utils/{count_parameters,data_loaders,trainer_utils,decorators,fonts,csv_processor,toml_writer}.py', 'outcome': 'Offline import, known trainable count=6, named-layer freeze/activate, wrapped timeit result/name, empty and normal compound loaders, invalid font selection, CSV schema growth/quoted newlines and stdlib-parsed TOML structure executed. Count table formatter alone stubbed in standalone probe.'},
        {'files': 'utils/reinforcement_learning/{rl_agent,rl_server}.py; policies/{base,registry,ddpg,sac,td3}.py', 'outcome': 'Actual registry FEI agent creates four variable-length replay transitions and trains; parameter-changing finite policy updates/save/load and numerical TD3 isolation references. Actual agent action event and server aggregate_deltas produce independent [4,6.5], total samples=8; action event consumed. FEI server defects 2D-15/16 deferred. Package exports reviewed.'},
        {'files': 'former utils/rl_env.py', 'outcome': 'No active tracked import/config closure; only this accepted unused placeholder archived unchanged, with provenance/license/local README. Active RL family and FEI retained.'},
    ],
    'validation': {
        'cwd': str(ROOT),
        'red_command_note': 'Normalized test invocations for captured red stages. Initial regressions were added uncommitted before their behavior fixes; snapshot invocations reproduce the exact baseline individual module against final tests. Red aggregate counts include explicitly identified early fixture/expectation issues and are not all claimed as confirmed defects.',
        'red': [
            red('red-s3-tree313.log', ['tests/utils/test_s3.py', 'tests/utils/test_safetensor_serialization.py'], '24 failed, 10 passed; 43.62s', 'Baseline S3/tree implementation before repairs', 'Includes namespace, empty listing, actual stalls/errors, collision and strided tensor failures. Pagination was separated afterward.'),
            red('red-pagination313.log', ['tests/utils/test_s3.py::test_all_pages_stay_in_namespace'], '1 failed; 0.59s', 'Baseline list implementation before paginator repair'),
            red('red-processors-cleanup313.log', ['tests/processors/test_payload_regressions.py', 'tests/utils/test_cleanup.py'], '15 failed, 3 passed; 0.14s', 'Baseline processors/cleanup before repairs', 'Initial randomized-response fixture lacked Config.algorithm; corrected fixture reproduced actual mutation separately. Some malformed QSGD cases already raised struct.error; explicit ValueError is a contract improvement, not proof of prior unbounded allocation.'),
            red('red-randomized313.log', ['tests/processors/test_payload_regressions.py::test_randomized_response_does_not_modify_source_model'], '1 failed; 0.09s', 'Exact baseline randomized-response module', 'Observed source [-2,0.2,4] become [0,1,1].', ('plato.processors.model_randomized_response', 'baseline_randomized_response.py')),
            red('red-feature-toml313.log', ['tests/processors/test_payload_regressions.py::test_zero_noise_feature_processor_keeps_cpu_precision_and_targets', 'tests/utils/test_shared_payload_utilities.py::test_toml_nested_array_tables_and_literal_keys_keep_structure'], '2 failed; 0.09s', 'Feature CPU fix not yet applied; TOML before Unicode/nested-array repair'),
            red('red-toml-baseline313.log', ['tests/utils/test_shared_payload_utilities.py::test_toml_nested_array_tables_and_literal_keys_keep_structure'], '1 failed; 0.08s', 'Exact baseline TOML module', None, ('plato.utils.toml_writer', 'baseline_toml_writer.py')),
            red('red-shared313.log', ['tests/utils/test_shared_payload_utilities.py'], '5 failed, 3 passed; 0.11s', 'Shared utility implementation before repairs'),
            red('red-he313.log', ['tests/servers/test_he_payload_regressions.py'], '13 failed, 2 passed; 0.30s', 'Baseline HE before repairs', 'One plain valid test initially compared different floating dtypes; corrected to double and not counted as a numerical defect. Confirmed failures are invalid counts/masks/lengths, zero-total behavior and caller mask mutation.'),
            red('red-he-wire313.log', ['tests/utils/test_safetensor_serialization.py::test_native_scalar_types_roundtrip_in_hybrid_payload_metadata', 'tests/servers/test_he_payload_regressions.py::test_default_he_processor_wire_pipeline_roundtrip'], '2 failed; 0.12s', 'Intermediate stricter HE validation exposed historical native scalar restoration', 'Compatibility probe prompted native scalar restoration; not an additional baseline HE defect.'),
            red('red-mpc313.log', ['tests/mpc/test_mpc_regressions.py'], '21 failed, 3 passed; 0.28s', 'Baseline MPC before repairs', 'Initial stale-round test used an unsupported expected-round keyword, so it was replaced by the captured real public-processor race below.'),
            red('red-mpc-race313.log', ['tests/mpc/test_mpc_regressions.py::test_stale_round_writer_cannot_contaminate_next_round'], '1 failed; 0.10s', 'Store already repaired; processor still lacked round fence', 'A real round advance during split accepted stale shares instead of raising.'),
            red('red-atomic313.log', ['tests/mpc/test_mpc_regressions.py::test_failed_state_save_keeps_last_complete_round'], '1 failed; 0.08s', 'Exact baseline round_store', 'Injected partial write destroyed prior complete state; subsequent public load raised UnpicklingError.', ('plato.mpc.round_store', 'baseline_round_store.py')),
            red('red-zk313.log', ['tests/mpc/test_round_store_contracts.py'], '2 failed, 1 passed; 0.10s', 'Before finite lock waits/cleanup; remote read already repaired'),
            red('red-remote-errors313.log', ['tests/mpc/test_round_store_contracts.py::test_s3_read_error_is_not_reported_as_an_uninitialized_round'], '1 failed; 0.09s', 'Exact baseline round_store', 'Injected service failure swallowed and converted to uninitialized-round error.', ('plato.mpc.round_store', 'baseline_round_store.py')),
            red('red-rl313.log', ['tests/utils/test_rl_payload_utilities.py'], '7 failed, 1 passed, 1 broadcast warning; 0.33s', 'Baseline active RL before repairs'),
            red('red-rl-numerical313.log', ['tests/utils/test_rl_payload_utilities.py::test_td3_target_actions_use_every_transition', 'tests/utils/test_rl_payload_utilities.py::test_async_actor_ignores_padding_and_other_transitions'], '2 failed; 0.12s', 'Exact baseline TD3', 'Independent per-transition action references and padding checks.', ('plato.utils.reinforcement_learning.policies.td3', 'baseline_td3.py')),
        ],
        'focused_green': {'command': [str(SCRATCH / 'venv313/bin/python'), '-m', 'pytest', 'tests/utils', 'tests/processors', 'tests/mpc', 'tests/servers/test_he_payload_regressions.py', 'tests/servers/test_fedavg_he_aggregation_strategy.py', 'tests/datasources/test_data_loaders.py', 'tests/integration/test_smoke_configs.py::test_mpc_training_smoke', '-q', '-W', 'error::UserWarning'], 'result': '133 passed in 17.07s; no skips; user warnings treated as errors', 'log': raw('green-owned313.log')},
        'initial_full_results': {'commit': 'dba6f85b8140d0159d593ad14b371ecb2caa9ee2', 'python313': invocation('full313'), 'python314': invocation('full314'), 'explanation': 'Both 411 passed / 1 failed / 1 allowed skip. Sole failure: old DummyRoundStore lacked load_state in existing MPC client lifecycle test. Final commit replaces only that MPC fixture with a real initialized isolated store and asserts persisted samples; runtime source unchanged. Focused correction passes both versions; justified final full reruns below.'},
        'lifecycle_correction': [invocation('lifecycle-fix313'), invocation('lifecycle-fix314')],
        'final_full_results_at_exact_implementation_commit': {'python313': full313, 'python314': full314},
        'standalone_probes': [
            {'script': raw('probe_utilities.py'), 'commands': [f'{SCRATCH}/venv313/bin/python {SCRATCH}/probe_utilities.py', f'{SCRATCH}/venv314/bin/python {SCRATCH}/probe_utilities.py'], 'results': 'Both passed: count=6, freeze/activate, deepcopy alias/dtype, timeit, HE bitmap, actual RL agent/server weighted delta/event behavior; formatter alone stubbed.', 'logs': [raw('utilities313.log'), raw('utilities314.log')]},
            {'script': raw('probe_fei.py'), 'commands': [f'{SCRATCH}/venv313/bin/python {SCRATCH}/probe_fei.py', f'{SCRATCH}/venv314/bin/python {SCRATCH}/probe_fei.py'], 'results': {'replay_transitions': 4, 'finite_policy_update_both_versions': True, 'losses_both_versions': [0.23115581274032593, 0.23115581274032593], 'zero_norm_output_both_versions': ['NaN', 'NaN'], 'constructor_algorithm_received_as_datasource': True, 'constructor_trainer_received_as_algorithm': True, 'constructor_trainer_received_as_none': True}, 'logs': [raw('fei313.log'), raw('fei314.log')], 'limitation': 'Actual FEI agent/policy and actual subclass normalization/constructor methods; superclass constructor instrumented solely to observe argument forwarding. No datasource downloads, sockets or example edits.'},
            {'script': raw('probe_runtime_s3.py'), 'commands': [f'{SCRATCH}/venv313/bin/python {SCRATCH}/probe_runtime_s3.py', f'{SCRATCH}/venv314/bin/python {SCRATCH}/probe_runtime_s3.py'], 'results': 'Both probes completed with expected mismatch: nonempty/nested/trailing-slash prefixes transfer successfully, 44 bytes reserved by actual 2B reader; empty prefix requests an extra leading slash and receives 404. Utility send and standalone receive succeed in all four cases.', 'logs': [raw('runtime-s3-integration313.log'), raw('runtime-s3-integration314.log')], 'runtime_snapshot': raw('phase2b_transport_b3b038e.py'), 'runtime_candidate': 'b3b038efa376b060e1c01f1da39173240768a019', 'limitation': 'Pinned actual 2B source loaded read-only from scratch with the fixed utility and existing realistic local HTTP contract. No runtime worktree edits. Root integration change remains pending.'},
        ],
        'static_checks': [
            {'command': f'{SCRATCH}/venv313/bin/ruff check plato/processors plato/serialization plato/mpc plato/utils plato/servers/fedavg_he.py plato/servers/fedavg_mpc_additive.py plato/servers/fedavg_mpc_shamir.py plato/servers/strategies/mpc.py plato/servers/strategies/aggregation/he.py plato/clients/mpc.py plato/clients/strategies/mpc.py cleanup.py tests/utils tests/processors tests/mpc tests/servers/test_he_payload_regressions.py tests/clients/test_client_lifecycle_variants.py tests/integration/test_smoke_configs.py --select I', 'result': 'All checks passed', 'log': raw('ruff-final.log')},
            {'command': f'{SCRATCH}/venv313/bin/ty check --python {SCRATCH}/venv313/bin/python plato/processors plato/serialization plato/mpc plato/utils/s3.py plato/utils/tree.py plato/utils/homo_enc.py plato/utils/reinforcement_learning plato/servers/fedavg_he.py plato/servers/strategies/mpc.py plato/servers/strategies/aggregation/he.py plato/clients/strategies/mpc.py cleanup.py', 'result': 'All checks passed', 'log': raw('ty-final.log')},
            {'command': f'git diff --check {BASELINE} {FINAL}', 'result': 'Passed'},
        ],
        'coverage': {'source_commit': 'dba6f85b8140d0159d593ad14b371ecb2caa9ee2', 'result': '1909/2413 executable lines (79.11%) across processors/serialization/mpc/utils in the initial full 3.13 run. Includes reserved third_party and Nanochat; not an owned-only or acceptance percentage. Runtime source identical to final commit; subsequent change only an existing lifecycle test fixture. Standalone utility/FEI probes are not part of measured pytest coverage.', 'artifact': raw('coverage313.json')},
    },
    'archive': {
        'selection': 'Only unused plato/utils/rl_env.py -> archives/legacy_rl_env/rl_env.py',
        'original_code_sha256': sha(ROOT / 'archives/legacy_rl_env/rl_env.py'),
        'license_sha256': sha(ROOT / 'archives/legacy_rl_env/LICENSE'),
        'baseline_provenance': BASELINE,
        'last_source_modification': 'da8869512e417002975a16f818bcad7e91224279',
        'closure_search': 'rg -n "rl_env|from plato.utils import.*env|plato.utils.rl_env" plato examples configs tests pyproject.toml; tracked source/config review found no active imports/entrypoints. Only original module internal reset reference.',
        'preserved_limitations': ['Historical four-value Gym step', 'Extra state dimension', 'Synchronous event-loop driving', 'Infinite episode-limit wait'],
        'documentation': 'Local README records provenance, exact source/license hashes and historical checkout instructions. Active reinforcement_learning and FEI kept; shared archive index remains root-owned.',
    },
    'trusted_pickle_inventory': {
        'owned_reads': ['utils/s3.py receive_from_s3: pickle.loads on fetched object bytes', 'processors/model_decompress.py: pickle.loads after zstd', 'utils/homo_enc.py bitmap_to_indices: pickle.loads after zlib', 'mpc/round_store.py: local pickle.load and S3 round-state pickle'],
        'owned_writes': ['S3.put_to_s3', 'model_compress', 'model.Processor size accounting', 'HE bitmap encoding', 'round_store state'],
        'local_torch_checkpoints': 'Active RL policy base load_model loads locally saved model/optimizer state_dict checkpoints using the locked PyTorch default; save/load roundtrips tested. No blanket torch.load modernization.',
        'cross_component': 'General server/client socket report/payload and checkpoint pickle paths remain in servers/base.py and clients/strategies/defaults.py (2B/general ownership); Nanochat tokenizer local pickle belongs to its assigned owner. Factual inventory only; no changes outside ownership.',
        'boundary': 'Pickles require trusted participating peers, storage writers and local files. Safetensors inside an outer pickle, compression and payload limits do not establish arbitrary untrusted-input safety. No new authentication/protocol design or questionnaire.',
    },
    'primary_documentation_consulted': [
        'https://docs.aws.amazon.com/botocore/latest/reference/config.html',
        'https://docs.aws.amazon.com/AmazonS3/latest/API/API_ListObjectsV2.html',
        'https://requests.readthedocs.io/en/latest/user/advanced/#timeouts',
        'https://kazoo.readthedocs.io/en/latest/api/recipe/lock.html',
        'https://kazoo.readthedocs.io/en/latest/api/client.html',
    ],
    'limitations': [
        'S3 tested through actual botocore/Requests against a local S3-compatible HTTP contract, without live cloud credentials. Timeout/retry tests shorten constants; defaults are finite 5/30 seconds and three attempts. Read timeouts bound inactivity, not an absolute deadline for indefinitely trickling bodies.',
        'ZooKeeper tests exercise real RoundInfoStore code with mocked Kazoo service contracts; no live distributed ZooKeeper or cloud deployment. HE uses native TenSEAL CKKS CPU with ephemeral n_threads=1 context; full federated HE/MPC sockets/deployments belong to later qualification.',
        'Existing Shamir prototype uses real-valued scaled model shares, not a newly designed finite-field protocol. Exact integer interpolation inputs limited to abs <=2**53 and thresholds <=min(participants,1000), with explicit errors instead of inaccurate results. No cryptographic protocol redesign or broader security claim.',
        'Native MLX behavior is not qualified by these PyTorch/NumPy payload tests; leave platform/backend qualification to its owner.',
        'Shared feature compression header continues to require homogeneous feature shapes/dtypes. Heterogeneous inputs now fail explicitly; no wire format redesign.',
        'Parameter counting numerical probe stubs only optional table formatting. CLI demo downloads were not executed; runtime import is offline.',
        'FEI agent replay/update and inherited adaptive aggregation run in isolation; complete FEI example remains Phase 4, with concrete zero-norm and constructor findings retained. Archived placeholder is historical unsupported code.',
    ],
    'root_followups': [
        {'id': '2D-17 / T2B-S3-PREFIX', 'owner': 'root after 2B acceptance', 'action': '2D canonical key_prefix strips leading/trailing slashes; logical key K maps to P/K when P is nonempty and K when empty, and already-qualified P/K stays unchanged. Replace 2B receive_s3_payload object_key = storage.key_prefix + "/" + key with equivalent exactly-once normalization (reuse storage._object_key(key)). Current actual 2B/2D integration works for configured s3://bucket/prefix and nested/trailing slash variants but empty prefix fails with 404. Verify the combined actual bounded reader, fixed send/put and prefixed/unprefixed roundtrips; preserve B deadlines/byte caps. Historical malformed double-prefixed objects are not migrated.'},
        {'id': '2D-15', 'owner': 'Phase 4 FEI', 'action': 'Bounded zero-norm normalization regression/fix; concrete [NaN,NaN] evidence retained.'},
        {'id': '2D-16', 'owner': 'Phase 4 FEI', 'action': 'Constructor keyword/dependency handoff regression/fix; concrete argument capture retained.'},
        {'owner': 'root', 'action': 'Fresh independent review of the exact evidence-carrier commit and root-owned archive index update.'},
    ],
    'owned_temporary_resources': {
        'root': str(SCRATCH),
        'contents': ['venv313 and venv314 locked dev environments', 'raw validation/probe/red logs with hashes above', 'pytest basetemp runtime trees and XML/JSON/coverage artifacts', 'exact baseline module snapshots and bounded probe/validation/evidence builder scripts', 'FEI scratch runtime'],
        'worktree_resources': ['Pinned external/nanochat checkout initialized', 'Ignored pytest/Python/coverage cache files owned in this worktree'],
        'retention': 'Retained until root acceptance; no scratch/evidence/workspace cleanup, no root .venv or other agents environments mutated.',
    },
}
destination = ROOT / 'evidence/2026-refresh/phase2d-validation.json'
destination.write_text(json.dumps(evidence, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'evidence': str(destination), 'bytes': destination.stat().st_size,
                  'implementation_commit': FINAL, '313': full313['junit'], '314': full314['junit']}))
