"""Independent read-only identity, revision, receipt and rational audit."""
import ast
import hashlib
import json
from fractions import Fraction as F
from pathlib import Path
import subprocess

ROOT = Path('/Users/bli/Playground/plato/evidence/2026-refresh')
CODE = Path('/private/tmp/plato-refresh-worktrees/feddyn-design')
OUT = Path('/tmp/plato-phase2c-feddyn-design-review-2')
new_path = ROOT / 'phase2c-feddyn-design.json'
old_path = Path('/tmp/plato-phase2c-feddyn-design/phase2c-feddyn-design.original-455d1447.json')
first_path = ROOT / 'phase2c-feddyn-design-review.json'


def receipt(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def differences(a, b, path=''):
    if type(a) is not type(b):
        return [path]
    if isinstance(a, dict):
        result = []
        for key in sorted(set(a) | set(b)):
            sub = path + '/' + key
            if key not in a or key not in b:
                result.append(sub)
            else:
                result += differences(a[key], b[key], sub)
        return result
    if isinstance(a, list):
        if len(a) != len(b):
            return [path]
        return sum((differences(x, y, path + '/' + str(i))
                    for i, (x, y) in enumerate(zip(a, b))), [])
    return [] if a == b else [path]


new = json.loads(new_path.read_text())
old = json.loads(old_path.read_text())
first = json.loads(first_path.read_text())
assert receipt(new_path)['sha256'] == '62c5d61805c49ccc06f99776d0da820c5b27cffeb5916754ddb16bb3135c1d5b'
assert receipt(old_path)['sha256'] == '455d144736f6318246c834d679e2ca8d371160dd654bfea6bab96b7abc9c4d60'
assert receipt(first_path)['sha256'] == 'e2b46a83c1a098e4b9d19e123b4c8c92fb1298f0a41515c4663e523aaae3522a'
changed = differences(old, new)
assert sorted(changed) == sorted(new['revision']['bounded_changed_fields']), changed
assert len(new['testacceptance']) == 15
assert [x['id'] for x in new['testacceptance']] == [x['id'] for x in old['testacceptance']]
assert new['oracle'] == old['oracle']

declared = []


def walk(value, path=''):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            actual = receipt(value['path'])
            declared.append(dict(field=path, declared={k: value[k] for k in actual},
                                 actual=actual, matches=all(actual[k] == value[k] for k in actual)))
        for k, v in value.items():
            walk(v, path + '/' + k)
    elif isinstance(value, list):
        for i, v in enumerate(value):
            walk(v, path + '/' + str(i))


walk(new)
assert all(x['matches'] for x in declared)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=CODE, text=True).strip()
tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=CODE, text=True).strip()
status = subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=CODE, text=True)
assert head == new['sourceidentities']['candidate_commit']
assert not status
sources = []
for entry in new['sourceidentities']['inspected_flow_receipts'] + new['revision']['additional_source_receipts']:
    relative = str(Path(entry['path']).relative_to(CODE))
    blob = subprocess.check_output(['git', 'show', f'{head}:{relative}'], cwd=CODE)
    actual = receipt(entry['path'])
    assert hashlib.sha256(blob).hexdigest() == actual['sha256']
    sources.append(dict(relative_path=relative, **actual, matches_git_blob=True))
for relative in ['AGENTS.md', 'plato/trainers/strategies/training_step.py',
                 'plato/trainers/strategies/optimizer.py', 'plato/callbacks/trainer.py',
                 'plato/clients/composable.py', 'plato/utils/checkpoint_paths.py']:
    sources.append(dict(relative_path=relative, **receipt(CODE / relative)))


def trajectory(mode):
    x = F(2)
    g = [F(0), F(0)]  # paper signed state for the common-alpha scaled objective
    rows = []
    for t, idx in enumerate([0, 1, 0], 1):
        h = -g[idx] / F(1, 10)
        a = F(1, 10) if mode == 'uniform' else [F(1, 5), F(1, 15)][idx]
        target = [F(0), F(4)][idx]
        factor = 1 - F(1, 10) * (1 + a)
        intercept = F(1, 10) * (target + a * (x - h))
        y = factor**2 * x + intercept * (1 + factor)
        g[idx] -= F(1, 10) * (y - x)
        h_all = [-v / F(1, 10) for v in g]
        mean_h = sum(h_all) / 2
        cloud = y - sum(g) / 2 / F(1, 10)
        values = dict(round=t, client=idx+1, baseline=x, alpha=a, history_before=h,
                      local=y, delta=y-x, h1=h_all[0], h2=h_all[1],
                      history_mean=mean_h, global_next=cloud)
        expected = new['oracle']['trajectory'][mode][t-1]
        for key, val in values.items():
            if isinstance(val, F):
                assert F(expected[key]['exact']) == val, (mode, t, key, val)
                assert expected[key]['decimal'] == float(val)
            else:
                assert expected[key] == val
        rows.append({k: str(v) for k, v in values.items()})
        x = cloud
    return rows


rationals = {mode: trajectory(mode) for mode in ['uniform', 'sample']}
scalar = dict(zero_shift='2', shifted='201/200', new_baseline='599/200',
              new_history='99/200', accumulation_y='39801/20000', accumulation_h='9801/20000')
assert F(1) - F(1, 10) * F(1, 10) * (F(1)-2+F(1, 2)) == F(scalar['shifted'])
assert F(3) - F(1, 10) * F(1, 10) * F(1, 2) == F(scalar['new_baseline'])
w = F(2)
for _ in range(2):
    w -= F(1, 10)*F(1, 10)*(w-2+F(1, 2))
assert w == F(scalar['accumulation_y'])
assert F(1, 2)+w-2 == F(scalar['accumulation_h'])
partial_history = [F(2,5)+1-2, F(-1,5), F(3,5)+4-2]
assert sum(partial_history)/3 == F(3,5)
assert (F(1)+4)/2+sum(partial_history)/3 == F(31,10)

required_files = ['utils_general.py', 'utils_methods.py', 'README.md', '2111.04263v1.pdf']
primary = []
for name in required_files:
    r = receipt(Path('/tmp/plato-phase2-root/feddyn-primary') / name)
    author = receipt(Path('/tmp/plato-phase2c-feddyn-design') / name)
    assert r['sha256'] == author['sha256']
    primary.append(dict(root=r, author=author))

paper = OUT / '2111.04263v1.pdf'
if paper.exists():
    assert receipt(paper)['sha256'] == primary[-1]['root']['sha256']

report = dict(reviewed_artifact=receipt(new_path), previous_artifact=receipt(old_path),
              first_review=receipt(first_path), code=dict(head=head, tree=tree, status=status),
              exact_changed_fields=changed, all_other_fields_equal=True,
              original_review_verdict=first['verdict'], declared_receipts=declared,
              immutable_source_receipts=sources, primary_retained_identity=primary,
              exact_oracle_independent=rationals, extra_rational_checks=scalar,
              criteria_ids=[x['id'] for x in new['testacceptance']])
(OUT / 'input-audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(status='PASS', code=head, declared_receipts=len(declared),
                      all_receipts_match=True, exact_changed_fields=changed,
                      all_other_fields_equal=True, exact_rational_oracles='PASS'), indent=2))
