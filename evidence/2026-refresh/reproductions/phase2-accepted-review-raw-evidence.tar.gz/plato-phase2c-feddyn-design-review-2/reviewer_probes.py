"""Independent scratch feasibility only; imports exclusively immutable Plato."""
import ast
import copy
import hashlib
import inspect
import json
import os
from pathlib import Path
import random
import sys
from types import SimpleNamespace
from unittest.mock import patch

HERE = Path('/tmp/plato-phase2c-feddyn-design-review-2')
CODE = Path('/private/tmp/plato-refresh-worktrees/feddyn-design')
TAG = str(sys.version_info.minor)
RUNTIME = HERE / ('runtime-' + TAG)
os.environ['config_file'] = str(CODE / 'examples/customized_client_training/feddyn/feddyn_MNIST_lenet5.toml')
sys.argv = [sys.argv[0], '-b', str(RUNTIME), '--cpu']

import numpy as np
import torch
from fractions import Fraction as F
from plato.config import Config
from plato.servers import base
from plato.servers.strategies.base import ServerContext
from plato.servers.strategies.client_selection.random_selection import RandomSelectionStrategy
from plato.trainers.composable import ComposableTrainer
from plato.trainers.strategies.base import LossCriterionStrategy, ModelUpdateStrategy
from plato.trainers.strategies.optimizer import SGDOptimizerStrategy
from plato.trainers.strategies.lr_scheduler import DefaultLRSchedulerStrategy
from plato.trainers.strategies.training_step import GradientAccumulationStepStrategy
from plato.callbacks.trainer import TrainerCallback


def cpu_rng():
    return dict(python=random.getstate(), numpy=np.random.get_state(),
                torch=torch.get_rng_state().clone())


def equal(a, b):
    if isinstance(a, torch.Tensor):
        return isinstance(b, torch.Tensor) and torch.equal(a, b)
    if isinstance(a, np.ndarray):
        return isinstance(b, np.ndarray) and np.array_equal(a, b)
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(equal(a[k], b[k]) for k in a)
    if isinstance(a, (tuple, list)):
        return type(a) is type(b) and len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b))
    return a == b


def apply_rng(value):
    random.setstate(value['python'])
    np.random.set_state(value['numpy'])
    torch.set_rng_state(value['torch'])


def private_validate(value):
    random.Random().setstate(value['selection'])
    random.Random().setstate(value['python'])
    np.random.RandomState().set_state(value['numpy'])
    torch.Generator(device='cpu').set_state(value['torch'])


def encode_rng(value):
    value = copy.deepcopy(value)
    state = value['numpy']
    value['numpy'] = [state[0], [int(x) for x in state[1]], *state[2:]]
    return value


def decode_rng(value):
    value = copy.deepcopy(value)
    value['numpy'] = (value['numpy'][0], np.asarray(value['numpy'][1], dtype=np.uint32),
                      *value['numpy'][2:])
    return value


def initial_states():
    n = np.random.RandomState(29)
    n.normal()  # preserve a populated Gaussian cache, not just the array
    return dict(python=random.Random(43).getstate(), numpy=n.get_state(),
                torch=torch.Generator(device='cpu').manual_seed(31).get_state())


class ProbeServer(base.Server):
    """Saved scratch tensor bundle with the proposed local handoff; no production code."""
    def __init__(self, mode='uniform', end_round=4, repaired=True, path=None):
        self.mode, self.end_round, self.repaired = mode, end_round, repaired
        self.path = path or HERE / f'bundle-{TAG}-{mode}.pt'
        self.disable_clients, self.periodic_interval = True, 1
        self.ping_interval = self.ping_timeout = 100
        self.context = ServerContext()
        self.current_round = self.context.current_round = 0
        self.resumed_session = False
        self.prng_state = random.Random(991).getstate()
        self.context.state['prng_state'] = self.prng_state
        self.client_selection_strategy = RandomSelectionStrategy()
        self._pending_resume_rng = None
        self.run_id = 'scratch-owned-run'
        self.model = torch.tensor(2., dtype=torch.float64)
        self.histories = torch.zeros(10, dtype=torch.float64)
        self.counts = list(range(1, 11))
        self.committed_round = 0
        self.trace = []
        self.events = []
        self.fail_install = False
        self.fail_handoff = False

    def __str__(self):
        return 'IndependentFedDynDesignProbe'

    def configure(self):
        self.events.append('configure')

    async def _periodic(self, interval):
        self.events.append('periodic_serviced')

    def saved_bundle(self):
        # Python-global intentionally differs from selector at the saved boundary.
        states = dict(initial_states(), selection=copy.deepcopy(self.prng_state),
                      context_selection=copy.deepcopy(self.context.state['prng_state']),
                      run_id=self.run_id, round=self.committed_round)
        return dict(version=1, mode=self.mode, N=10, counts=self.counts[:],
                    alpha=.1, schema='scalar-float64', model=self.model.clone(),
                    histories=self.histories.clone(), committed_round=self.committed_round,
                    run_id=self.run_id, rng=encode_rng(states))

    def save_to_checkpoint(self):
        torch.save(self.saved_bundle(), self.path)

    def state(self):
        return dict(model=self.model.clone(), histories=self.histories.clone(),
                    current=self.current_round, context_round=self.context.current_round,
                    committed=self.committed_round, resumed=self.resumed_session,
                    run_id=self.run_id, selection=self.prng_state,
                    context_selection=self.context.state['prng_state'], rng=cpu_rng())

    def _resume_from_checkpoint(self):
        self.events.append('resume')
        staged = torch.load(self.path, map_location='cpu', weights_only=True)
        assert staged['version'] == 1 and staged['mode'] == self.mode
        assert staged['N'] == 10 and staged['counts'] == self.counts
        assert staged['alpha'] == .1 and staged['schema'] == 'scalar-float64'
        assert staged['model'].shape == () and staged['model'].dtype == torch.float64
        assert staged['histories'].shape == (10,) and staged['histories'].dtype == torch.float64
        assert torch.isfinite(staged['model']).all() and torch.isfinite(staged['histories']).all()
        rng = decode_rng(staged['rng'])
        private_validate(rng)
        assert equal(rng['selection'], rng['context_selection'])
        assert rng['run_id'] == staged['run_id'] and rng['round'] == staged['committed_round']
        old = self.state()
        old_pending = self._pending_resume_rng
        try:
            self.model.copy_(staged['model'])
            self.histories.copy_(staged['histories'])
            if self.fail_install:
                raise RuntimeError('injected whole-bundle install failure')
            self.run_id = staged['run_id']
            self.committed_round = self.current_round = staged['committed_round']
            self.context.current_round = self.current_round
            self.resumed_session = True
            # publish owned pending data only after entire bundle installation
            self._pending_resume_rng = copy.deepcopy(rng)
        except BaseException:
            self.model.copy_(old['model'])
            self.histories.copy_(old['histories'])
            self.run_id = old['run_id']
            self.committed_round, self.current_round = old['committed'], old['current']
            self.context.current_round = old['context_round']
            self.resumed_session = old['resumed']
            self._pending_resume_rng = old_pending
            raise

    def start(self, *args, **kwargs):
        self.events.append('local_start_after_inherited_seed')
        self.seed_at_start = self.prng_state
        pending = self._pending_resume_rng
        if pending is not None and self.repaired:
            assert pending['run_id'] == self.run_id and pending['round'] == self.committed_round
            private_validate(pending)
            old = self.state()
            try:
                self.prng_state = copy.deepcopy(pending['selection'])
                self.context.state['prng_state'] = copy.deepcopy(pending['selection'])
                random.setstate(pending['python'])
                np.random.set_state(pending['numpy'])
                if self.fail_handoff:
                    raise RuntimeError('injected handoff failure after partial RNG installation')
                torch.set_rng_state(pending['torch'])
            except BaseException:
                self.prng_state = old['selection']
                self.context.state['prng_state'] = old['context_selection']
                apply_rng(old['rng'])
                raise
            self._pending_resume_rng = None
        self.boundary = self.state()
        self.events.append('delegate_base_start')
        return super().start(*args, **kwargs)

    def train_remaining(self):
        while self.current_round < self.end_round:
            selected = self._select_clients_with_strategy(list(range(1, 11)), 2)
            x = self.model.clone()
            staged_h = self.histories.clone()
            endpoints = []
            for client_id in selected:
                i = client_id - 1
                a = .1 if self.mode == 'uniform' else .1*55/(10*client_id)
                w = torch.nn.Parameter(x.clone())
                optimizer = torch.optim.SGD([w], lr=.1)
                for _ in range(2):
                    optimizer.zero_grad()
                    loss = (w-client_id).square()/2 + a*self.histories[i]*w + a*(w-x).square()/2
                    loss.backward()
                    optimizer.step()
                endpoints.append(w.detach().clone())
                staged_h[i] += w.detach()-x
            self.model = torch.stack(endpoints).mean() + staged_h.mean()
            self.histories = staged_h
            self.current_round += 1
            self.context.current_round = self.current_round
            self.committed_round = self.current_round
            self.trace.append(dict(round=self.current_round, selected=selected,
                                   cloud=self.model.item(), histories=self.histories.tolist()))


def run_actual(server, resume, port=None):
    cfg = SimpleNamespace(args=SimpleNamespace(resume=resume),
                          clients=SimpleNamespace(type='simple'),
                          server=SimpleNamespace(random_seed=17, address='127.0.0.1'),
                          is_central_server=lambda: False)
    sockets = []

    class SocketProbe:
        def __init__(self, **kwargs):
            sockets.append(kwargs)
            server.events.append('socket_constructed')
            if server.repaired and resume:
                expected = decode_rng(torch.load(server.path, weights_only=True)['rng'])
                assert equal(cpu_rng(), {k: expected[k] for k in ['python', 'numpy', 'torch']})
                assert server.prng_state == server.context.state['prng_state'] == expected['selection']
                assert server._pending_resume_rng is None

        def register_namespace(self, namespace):
            server.events.append('namespace_registered')

        def attach(self, app):
            server.events.append('socket_attached')

    def app_probe(app, **kwargs):
        server.events.append('run_app_intercepted')
        if port is not None:
            assert kwargs['port'] == port
        server.train_remaining()

    with patch.object(base, 'Config', lambda: cfg), \
         patch.object(base.socketio, 'AsyncServer', SocketProbe), \
         patch.object(base.web, 'run_app', app_probe):
        if port is None:
            server.run()
        else:
            server.start(port=port)
    return dict(sockets_created=len(sockets), events=server.events[:])


def expected_four(mode):
    x = F(2)
    h = [F(0)]*10
    rows = []
    for selected in [[9,7],[5,6],[5,3],[9,5]]:
        ys = []
        for client_id in selected:
            a = F(1,10) if mode == 'uniform' else F(11,20*client_id)
            factor = 1 - F(1,10)*(1+a)
            constant = F(1,10)*(client_id+a*(x-h[client_id-1]))
            y = factor**2*x + (1+factor)*constant
            ys.append(y)
        for client_id, y in zip(selected, ys):
            h[client_id-1] += y-x
        x = sum(ys)/2 + sum(h)/10
        rows.append(dict(selected=selected, cloud=str(x), histories=[str(v) for v in h]))
    return rows


def startup_tests():
    output = {}
    for mode in ['uniform', 'sample']:
        control = ProbeServer(mode)
        apply_rng(initial_states())
        full_run = run_actual(control, False)
        split = ProbeServer(mode, end_round=2)
        apply_rng(initial_states())
        run_actual(split, False)
        split.save_to_checkpoint()
        saved = torch.load(split.path, weights_only=True)
        expected_rng = decode_rng(saved['rng'])
        split_rows = copy.deepcopy(split.trace)
        del split
        restored = ProbeServer(mode)
        rng_before = cpu_rng()
        resumed_run = run_actual(restored, True)
        assert restored.seed_at_start == random.Random(17).getstate()
        assert restored.trace == control.trace[2:]
        assert split_rows == control.trace[:2]
        exact = expected_four(mode)
        for actual, expected in zip(control.trace, exact):
            assert actual['selected'] == expected['selected']
            assert abs(actual['cloud']-float(F(expected['cloud']))) < 1e-12
            assert all(abs(a-float(F(e))) < 1e-12 for a, e in zip(actual['histories'], expected['histories']))
        assert equal(restored.prng_state, control.prng_state)
        assert restored._pending_resume_rng is None
        broken = ProbeServer(mode, repaired=False, end_round=3)
        run_actual(broken, True)
        assert broken.trace[0]['selected'] == [9,7]
        assert broken.trace[0]['cloud'] != control.trace[2]['cloud']
        output[mode] = dict(uninterrupted=control.trace, resumed=restored.trace,
                            independent_exact=exact, unrepaired_next=broken.trace[0],
                            full_start=full_run, resumed_start=resumed_run,
                            all_cpu_rng_restored_before_socket=True,
                            distinct_python_and_selection=expected_rng['python'] != expected_rng['selection'],
                            numpy_gaussian_cache_saved=bool(expected_rng['numpy'][3]),
                            consumed_once=True,
                            checkpoint_sha256=hashlib.sha256(restored.path.read_bytes()).hexdigest())
        # Repeated start forwards optional port and does not replay consumed state.
        now = cpu_rng()
        selection_now = restored.prng_state
        restored.end_round = restored.current_round
        run_actual(restored, False, port=18717)
        assert equal(now, cpu_rng()) and restored.prng_state == selection_now

    good = torch.load(HERE / f'bundle-{TAG}-uniform.pt', weights_only=True)
    rejection = []
    cases = ['selection','context_selection','python','numpy','torch','model','histories','alpha','version','identity','install']
    for case in cases:
        value = copy.deepcopy(good)
        if case in ['selection','context_selection','python']:
            value['rng'][case] = ()
        elif case == 'numpy':
            value['rng']['numpy'][0] = 'invalid-algorithm'
        elif case == 'torch':
            value['rng']['torch'] = torch.zeros(1, dtype=torch.uint8)
        elif case in ['model','histories']:
            value[case] = torch.full_like(value[case], float('nan'))
        elif case in ['alpha','version']:
            value[case] = -1
        elif case == 'identity':
            value['rng']['round'] += 1
        path = HERE / f'reject-{TAG}-{case}.pt'
        torch.save(value, path)
        s = ProbeServer(path=path)
        s.fail_install = case == 'install'
        s._pending_resume_rng = sentinel = object()
        before = s.state()
        try:
            run_actual(s, True)
        except (AssertionError, ValueError, TypeError, IndexError, RuntimeError):
            pass
        else:
            raise AssertionError(f'{case} accepted')
        assert equal(s.state(), before) and s._pending_resume_rng is sentinel
        assert 'socket_constructed' not in s.events
        rejection.append(case)
    s = ProbeServer()
    s._resume_from_checkpoint()
    assert s.resumed_session and s.current_round == s.context.current_round == 2
    assert s.committed_round == 2
    s.fail_handoff = True
    old_state, pending = s.state(), s._pending_resume_rng
    try:
        s.start()
    except RuntimeError:
        pass
    else:
        raise AssertionError('handoff failure accepted')
    assert equal(s.state(), old_state) and s._pending_resume_rng is pending
    assert 'delegate_base_start' not in s.events
    # Fresh run affects only Python global and selection, using inherited seed.
    fresh = ProbeServer(end_round=0)
    before = cpu_rng()
    run_actual(fresh, False)
    after = cpu_rng()
    assert after['python'] == random.Random(17).getstate()
    assert equal(after['numpy'], before['numpy']) and equal(after['torch'], before['torch'])
    assert fresh._pending_resume_rng is None
    return dict(modes=output, rejected_whole_bundle_cases=rejection,
                rejected_handoff_restored_live_rng_and_pending=True,
                fresh_seed_behavior_preserved=True,
                base_signatures=dict(run=str(inspect.signature(base.Server.run)),
                                     start=str(inspect.signature(base.Server.start))),
                limitation='Scratch tensor-bundle/subclass and scalar training only. Actual inherited run, start body and selector execute; AsyncServer and run_app are intercepted. No production FedDyn, real registration/network/spawn acceptance or generic B fix is tested.')


class ScalarModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.weight = torch.nn.Parameter(torch.tensor(2., dtype=torch.float64))

    def forward(self, examples):
        return self.weight.expand(len(examples), 1)


class ProbeLoss(LossCriterionStrategy):
    def compute_loss(self, outputs, labels, context):
        w = context.model.weight
        return outputs.sum()*0 + .1*.5*w + .1*(w-2).square()/2


def accumulation_test(batches):
    events = []
    class OptimizerSpy(SGDOptimizerStrategy):
        def create_optimizer(self, model, context):
            opt = super().create_optimizer(model, context)
            opt.register_step_post_hook(lambda *_: events.append(['actual_optimizer_step', model.weight.item()]))
            return opt

        def on_optimizer_step(self, optimizer, context):
            events.append(['optimizer_strategy.on_optimizer_step', context.model.weight.item()])

    class UpdateSpy(ModelUpdateStrategy):
        def after_step(self, context):
            events.append(['model_update_strategy.after_step', context.model.weight.item()])

        def on_train_end(self, context):
            events.append(['history_staging', (.5+context.model.weight-2).item()])

    class CallbackSpy(TrainerCallback):
        def on_train_step_end(self, trainer, config, batch, loss, **kwargs):
            events.append(['callback.on_train_step_end', batch])

    class SchedulerSpy(DefaultLRSchedulerStrategy):
        def create_scheduler(self, optimizer, context):
            value = super().create_scheduler(optimizer, context)
            assert value is None
            events.append(['scheduler_strategy.create_returned_None', None])
            return value

        def step(self, scheduler, context):
            assert scheduler is None
            events.append(['scheduler_strategy.epoch_noop', context.current_epoch])
            return super().step(scheduler, context)

    model = ScalarModel()
    trainer = ComposableTrainer(model=model, loss_strategy=ProbeLoss(),
                               optimizer_strategy=OptimizerSpy(lr=.1),
                               training_step_strategy=GradientAccumulationStepStrategy(2),
                               lr_scheduler_strategy=SchedulerSpy(),
                               model_update_strategy=UpdateSpy(), callbacks=[CallbackSpy])
    dataset = torch.utils.data.TensorDataset(torch.ones(batches, 1, dtype=torch.float64), torch.zeros(batches, dtype=torch.long))
    trainer.train_model(dict(batch_size=1, epochs=1), dataset, None)
    count = lambda name: sum(row[0] == name for row in events)
    steps = (batches+1)//2
    for name in ['actual_optimizer_step', 'optimizer_strategy.on_optimizer_step',
                 'model_update_strategy.after_step','callback.on_train_step_end']:
        assert count(name) == steps, events
    assert count('history_staging') == 1 and trainer.lr_scheduler is None
    assert count('scheduler_strategy.epoch_noop') == count('scheduler_strategy.create_returned_None') == 1
    expected = F(2)
    for _ in range(steps):
        expected -= F(1,100)*(expected-2+F(1,2))
    assert abs(model.weight.item()-float(expected)) < 1e-12
    assert model.weight.grad is None
    return dict(batches=batches, updates=steps, y=model.weight.item(),
                h=.5+model.weight.item()-2, events=events,
                real_scheduler_objects=0, real_scheduler_steps=0)


def author_function_test():
    source = Path('/tmp/plato-phase2-root/feddyn-primary/utils_general.py').read_text()
    fn = next(x for x in ast.parse(source).body if isinstance(x, ast.FunctionDef) and x.name == 'train_feddyn_mdl')
    class ZeroLoss(torch.nn.Module):
        def __init__(self, **kwargs):
            super().__init__()

        def forward(self, outputs, labels):
            return outputs.sum()*0

    def dataset(x,y,**kwargs):
        return torch.utils.data.TensorDataset(torch.as_tensor(x), torch.as_tensor(y))

    def params(models):
        return np.asarray([[p.item() for p in m.parameters()] for m in models])

    scope = dict(torch=torch, np=np, data=torch.utils.data, Dataset=dataset,
                 device=torch.device('cpu'), max_norm=1e6, get_mdl_params=params)
    exec(compile(ast.Module(body=[fn], type_ignores=[]), '<pinned-primary-function>', 'exec'), scope)
    outputs=[]
    for hist in [0., .5]:
        with patch.object(torch.nn, 'CrossEntropyLoss', ZeroLoss):
            mdl = scope['train_feddyn_mdl'](ScalarModel(), ScalarModel, .1,
                torch.tensor([2.],dtype=torch.float64), torch.tensor([hist],dtype=torch.float64),
                np.ones((1,1)), np.zeros(1), .1, 1, 2, 100, 0., 'scratch')
        want=2. if hist == 0 else 1.99005
        assert abs(mdl.weight.item()-want) < 1e-12
        outputs.append(dict(history=hist, endpoint=mdl.weight.item()))
    return dict(source_commit='48a19fac440ef079ce563da8e0c2896f8256fef9',
                source_sha256=hashlib.sha256(source.encode()).hexdigest(),
                scalar_execution=outputs,
                limitation='Extracted exact primary function with controlled dataset/zero-loss globals, inactive clipping, no full historical experiment.')


initial = cpu_rng()
try:
    result = dict(python=sys.version, torch=torch.__version__, numpy=np.__version__,
                  immutable_module_paths=dict(server=base.__file__, trainer=inspect.getfile(ComposableTrainer)),
                  startup=startup_tests(),
                  accumulation=[accumulation_test(n) for n in [3,4,1]],
                  primary_function=author_function_test())
    print(json.dumps(result, indent=2))
finally:
    apply_rng(initial)
