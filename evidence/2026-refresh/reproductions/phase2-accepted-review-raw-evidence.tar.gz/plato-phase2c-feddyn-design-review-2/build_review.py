"""Write only the requested ROOT report and own scratch receipts."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/bli/Playground/plato/evidence/2026-refresh')
HERE = Path('/tmp/plato-phase2c-feddyn-design-review-2')
CODE = Path('/private/tmp/plato-refresh-worktrees/feddyn-design')
OUTPUT = ROOT / 'phase2c-feddyn-design-review-2.json'


def receipt(path):
    p = Path(path)
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


audit = json.loads((HERE / 'input-audit.json').read_text())
design = json.loads((ROOT / 'phase2c-feddyn-design.json').read_text())
probes = {version: json.loads((HERE / f'probes-{version}.json').read_text())
          for version in ['313', '314']}
assert receipt(ROOT / 'phase2c-feddyn-design.json') == audit['reviewed_artifact']
assert not subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=CODE, text=True)

commands = []
for version in ['313', '314']:
    commands.append(dict(
        command=f'zsh -lc \'PYTHONDONTWRITEBYTECODE=1 PYTHONPATH={CODE} TMPDIR={HERE} '
                f'XDG_CACHE_HOME={HERE}/cache-{version} MPLCONFIGDIR={HERE}/mpl-{version} '
                f'OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /tmp/plato-phase2c-{version}/bin/python '
                f'{HERE}/reviewer_probes.py > {HERE}/probes-{version}.json '
                f'2> {HERE}/probes-{version}.stderr.log\'',
        cwd=str(CODE), exit_code=0, stdout=receipt(HERE / f'probes-{version}.json'),
        stderr=receipt(HERE / f'probes-{version}.stderr.log'),
        python=probes[version]['python'], torch=probes[version]['torch'],
        numpy=probes[version]['numpy']))
commands.append(dict(
    command=f'zsh -lc \'PYTHONDONTWRITEBYTECODE=1 /tmp/plato-phase2c-313/bin/python '
            f'{HERE}/audit_inputs.py > {HERE}/input-audit.stdout.json '
            f'2> {HERE}/input-audit.stderr.log\'',
    cwd=str(CODE), exit_code=0, stdout=receipt(HERE / 'input-audit.stdout.json'),
    stderr=receipt(HERE / 'input-audit.stderr.log'), result=receipt(HERE / 'input-audit.json')))
(HERE / 'command-records.json').write_text(json.dumps(commands, indent=2) + '\n')


def location(path, line, meaning):
    return dict(path=path, line=line, meaning=meaning)


criterion_data = [
    ('FD-A01', 'Correct zero-shift and detached-history objective. Independent derivatives give y=2, 1.005 and 2.995; alpha=0 is task-only locally and invalid end to end.',
     'Independent rational audit and exact pinned author function execution; retain the immutable 2.02 red evidence.',
     'Production loss, dtype fidelity and zero-alpha rejection tests remain required.'),
    ('FD-A02', 'All three uniform rounds and every exact endpoint/cloud/history field agree with a separately derived affine two-update formula and paper signed-state recurrence.',
     'input-audit.json exact_oracle_independent.uniform; original oracle unchanged.',
     'Actual client/accepted worker/server._process_reports/downlink path must match at every boundary.'),
    ('FD-A03', 'Counts [1,3] give q=[1/2,3/2] and alpha=[1/5,1/15]. Exact unequal-count trajectory agrees. Equal counts reduce to uniform; uniform ignores unequal counts for model weighting.',
     'Independent rational audit; pinned train_FedDyn normalization and alpha statements at lines296-297 and387.',
     'Actual realized counts and full population vector must be verified on the accepted-A merged candidate.'),
    ('FD-A04', 'N3 histories[-.6,-.2,2.6], selected mean2.5 and population mean.6 give cloud3.1 in both modes. N stays3 and inactive history persists.',
     'Independent Fraction arithmetic and pinned population correction at utils_methods.py:393-397.',
     'Production aggregation and full-participation checks must retain unweighted endpoint averaging.'),
    ('FD-A05', 'Label values cannot enter alpha or history. A matching label/output permutation preserves the task objective. Count authority is finite realized loader cardinality, not global backing trainset.',
     'Equations omit labels; actual loader/report fallbacks inspected in composable.py:525-543 and defaults.py. Metadata paragraph correctly distinguishes immutable pre-A from accepted Phase2A.',
     'Wrong, missing, unknown or later-changed cardinality must fail before optimization/commit; label tests remain required.'),
    ('FD-A06', 'Finite positive end-to-end alpha and explicit uniform/sample configuration are coherent with plain fixed-rate SGD, zero decay/momentum, no scheduler/clipping/AMP/DP/async.',
     'Pinned author function has separate alpha SGD decay; corrected full-loss form must use zero optimizer decay. Independent extracted function gives2 and1.99005 with inactive clipping.',
     'Validate actual optimizer/configuration and negative paths without silently coercing settings.'),
    ('FD-A07', 'Fixed trainable names Q and exact identity ownership prevent positional or shape-based pairing. Full model schema checks and unchanged static/frozen state preserve bounded scope.',
     'Source supports named parameters/state_dict and local strategies; no shared aggregation or buffer policy edit is needed. Existing LeNet remains feasible.',
     'Actual reversed/missing/duplicate/foreign ownership, schema, aliases and mutable-buffer cases remain required.'),
    ('FD-A08', 'Revised wording exactly matches the real trainer hooks. Three microbatches with a two-batch window give two actual SGD updates, y1.99005/h.49005, two optimizer/update/callback notifications and one history staging.',
     'Both versions execute actual ComposableTrainer and GradientAccumulationStepStrategy; actual SGD post-hooks count2. No scheduler object; one create-returning-None call and one epoch no-op. Divisible4 and short1 probes also pass.',
     'Production FedDyn zero-completed/all-skipped rejection and successful-only state staging remain required; no scheduler change is authorized.'),
    ('FD-A09', 'Server authority and dispatch replacement preserve logical1->2->1, same-client new baseline and process-independent history. Existing worker-state hooks can carry provisional accepted state.',
     'Inspected trainer worker save/load and composable payload route, plus unchanged design ownership contract.',
     'Actual reuse/dedicated-client/fresh-process/spawn equivalence remains required; no legacy file adoption.'),
    ('FD-A10', 'Transactional local Trainer.train wrapper can contain model-before-worker-state loading and later handoff exceptions. No child canonical history writes eliminates the recorded contamination route.',
     'composable.py:806-880 supplies real token/client validation and loads model before load_worker_state; local wrapper can snapshot and restore known tensor/strategy/context state.',
     'Real spawned nonzero-after-save, absent/corrupt/stale sidecar, bad pair and callback failure must send no update, roll back and retry correctly.'),
    ('FD-A11', 'Full original-model and metadata validation before arithmetic, revalidation after callback transformation, fixed dispatched-set membership and staged commit are coherent.',
     'fedavg.py:181-248 exposes weights_received -> callback -> aggregate_weights -> model load -> weights_aggregated. Generic ingress validates report counts only, so it does not reject the local envelope before unpacking. The local weight-preference override prevents bypass.',
     'Every malformed later participant, alias/callback mutation, load/staging failure and immediate valid retry must preserve all committed model/history/count/token/checkpoint state.'),
    ('FD-A12', 'Revised criterion explicitly demands a real saved bundle/run/--resume fixture, rounds3 and4 selection/model/all-history comparison in both modes, all CPU RNG fields, fresh seed behavior and transactional pending-state rejection.',
     'Both independent scratch probes serialize weights-only tensor bundles, execute inherited run and actual base start body with intercepted network, and compare later scalar training against uninterrupted and independent exact controls.11 whole-bundle rejection cases and a partial handoff failure preserve state/pending.',
     'Scratch is feasibility only. Final production bundle, actual CLI/example wiring, serialization failure/atomic replace, static/frozen state and required FD-A02 continuation remain unexecuted acceptance obligations.'),
    ('FD-A13', 'Real default payload path, shipped wiring, local socket, real spawn, bounded successful shutdown and shared actual-entrypoint resume case remain explicit. No weakened transport requirement or duplicate counting was introduced.',
     'DefaultPayloadStrategy invokes training.load_payload/train directly. Real start signature/registration ordering permits the example-local handoff; scratch socket constructor observes restored states before namespace registration.',
     'Run actual shipped CPU3.13/3.14 integration and later combined accepted-B/F28 regressions; these probes do not establish network/spawn/CLI acceptance.'),
    ('FD-A14', 'Exact receipt, independent equation, scoped diff, explicit migration and separate public-prose/code review gate remain meaningful.',
     'All55 declared receipts match; source identity is clean62d with matching tracked blobs; changed-field set is exact and all remaining original fields unchanged.',
     'Final code/prose and root integration must still be implemented, re-pinned, tested and independently reviewed. Design PASS closes no implementation finding or phase.'),
    ('FD-A15', 'Explicit read-only exact legacy reader preserves accepted-B spelling/custom roots/canonical precedence/client0 exclusion/original bytes without falsely importing an incoherent old history into new training.',
     'Migration fields are byte-for-byte structurally unchanged from original; immutable first review retains actual accepted-B writer proof and exact7/8 fixture.',
     'New reader and explicit fresh model-only warm start/migration failures remain required production tests; separate filename correction is not waived or claimed implemented by this review.')
]
criteria = [dict(id=id_, design_assessment='ADEQUATE', assessment=assessment,
                 evidence=evidence, remaining_implementation_acceptance=remaining,
                 production_test_status='REQUIRED_NOT_PASSED_BY_THIS_DESIGN_REVIEW')
            for id_, assessment, evidence, remaining in criterion_data]
assert [x['id'] for x in criteria] == audit['criteria_ids']

probe_summaries = {}
for version, data in probes.items():
    startup = data['startup']
    modes = {}
    for mode, result in startup['modes'].items():
        modes[mode] = dict(
            uninterrupted_rounds=[dict(round=row['round'], selected=row['selected'], cloud=row['cloud'])
                                  for row in result['uninterrupted']],
            resumed_rounds=[dict(round=row['round'], selected=row['selected'], cloud=row['cloud'])
                            for row in result['resumed']],
            all_ten_histories_equal_uninterrupted=True,
            independent_fraction_reference_passed=True,
            unrepaired_next=result['unrepaired_next']['selected'],
            all_promised_rng_at_socket_constructor=True,
            distinct_python_and_selection=result['distinct_python_and_selection'],
            numpy_gaussian_cache_saved=result['numpy_gaussian_cache_saved'],
            pending_consumed_before_socket_once=True,
            event_order=result['resumed_start']['events'],
            checkpoint_sha256=result['checkpoint_sha256'])
    probe_summaries[version] = dict(
        python=data['python'], torch=data['torch'], numpy=data['numpy'],
        module_paths=data['immutable_module_paths'], base_signatures=startup['base_signatures'],
        resume_modes=modes, rejected_whole_bundle_cases=startup['rejected_whole_bundle_cases'],
        rejected_handoff_rolled_back=True, fresh_run_seed_preserved=True,
        repeated_start_no_reapply_and_port_forwarding=True,
        accumulation=data['accumulation'], pinned_author_function=data['primary_function'],
        limitation=startup['limitation'])

report = dict(
    schema_version=1, date='2026-10-03',
    written_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    role='Fresh independent Sol xhigh design reviewer; no nested agents, read-only immutable code context.',
    verdict='PASS', design_acceptance='REVISED_DESIGN_ONLY',
    finding_counts=dict(critical=0, high=0, medium=0, low=0), findings=[], low_findings=[],
    summary='The narrow revision resolves FD-D-R01 and FD-D-L01. The example-local validated pending-RNG/start handshake is feasible against unchanged immutable62d, restores every promised CPU/selection field after inherited seeding, preserves fresh seeding and rejects without leaking staged state. The revised update-notification criterion matches real trainer behavior. Algebra, rational oracles,15criteria, bounded server ownership and explicit migration remain sound. No production implementation or final integration is accepted.',
    reviewed_artifact=audit['reviewed_artifact'],
    requested_sha256='62c5d61805c49ccc06f99776d0da820c5b27cffeb5916754ddb16bb3135c1d5b',
    immutable_code_context=dict(path=str(CODE), alias='/tmp/plato-refresh-worktrees/feddyn-design',
                                commit=audit['code']['head'], tree=audit['code']['tree'],
                                status='CLEAN_BEFORE_AND_AFTER_PROBES',
                                module_source_verified=True, evolving_worktrees_read=False),
    original_design=audit['previous_artifact'], immutable_first_review=audit['first_review'],
    previous_review_verdict_preserved='REQUEST_CHANGES; immutable first review is unchanged. This independent report accepts only the revised design.',
    dispositions=[
        dict(id='FD-D-R01', original_severity='medium', status='RESOLVED_IN_DESIGN',
             artifact_fields=['/stateflow/checkpoint/owner','/stateflow/checkpoint/read',
                              '/stateflow/checkpoint/scope','/stateflow/checkpoint/startup_handoff',
                              '/files/exact_owned_implementation/4/change',
                              '/testacceptance/11','/testacceptance/12'],
             assessment='Whole-bundle/private-generator validation precedes owned pending publication. Successful installation sets current/context/committed round and resumed_session. The compatible synchronous start override rechecks identity, validates without live draws, installs separate Python-global and selector states, NumPy cache and Torch CPU state, then consumes pending before base start. Rejection snapshots/rollback and no-delegation rule are explicit; fresh runs directly forward.',
             source_evidence=[location('plato/servers/base.py',346,'Inherited run signature and synchronous ordering.'),
                              location('plato/servers/base.py',353,'Resume precedes client launch and seed.'),
                              location('plato/servers/base.py',398,'Seed17 replaces live Python RNG and server selection state.'),
                              location('plato/servers/base.py',402,'start(port=Config().server.port) is an available local override.'),
                              location('plato/servers/base.py',414,'Socket creation follows entry to inherited start.'),
                              location('plato/servers/base.py',419,'Namespace registration follows socket creation.'),
                              location('plato/servers/base.py',462,'resumed_session triggers round selection after registration.'),
                              location('plato/servers/base.py',841,'Selection copies server state into context, then updates server from context.'),
                              location('plato/servers/strategies/client_selection/random_selection.py',27,'Selector consumes saved context PRNG state.')],
             independent_probe='CPU3.13.16 and3.14.8 execute inherited run and real base.start body; scratch socket/run_app interception sees restored live/context fields. Actual serialized scratch bundle resumes[5,3],[9,5], all model/history states match uninterrupted control and exact reference; unrepaired path restarts[9,7].11 rejected bundle cases, injected post-model-install exception and partial RNG-install exception leave model/history/round/live RNG/pending unchanged.',
             production_acceptance='FD-A12/13 still require actual production bundle and shipped run/--resume, later model/all-history state, local sockets and real spawn; direct resume/selection and intercepted scratch do not replace them.'),
        dict(id='FD-D-L01', original_severity='low', status='RESOLVED_IN_DESIGN',
             artifact_fields=['/testacceptance/7/expected'],
             assessment='The criterion names two calls each to optimizer_strategy.on_optimizer_step, model_update_strategy.after_step and on_train_step_end. It correctly distinguishes no real scheduler object/steps from create_scheduler returningNone and the epoch-boundary step(None,context) no-op.',
             source_evidence=[location('plato/trainers/composable.py',626,'Normal successful update dispatches optimizer/update/callback hooks.'),
                              location('plato/trainers/composable.py',698,'Finalized tail dispatches the same hooks.'),
                              location('plato/trainers/composable.py',742,'LR strategy step occurs once per epoch.'),
                              location('plato/trainers/strategies/lr_scheduler.py',51,'Unconfigured default scheduler returnsNone.')],
             independent_probe='Both versions run actual trainer/accumulation strategy with real SGD post-hooks:3batches=>2updates, y1.99005/h.49005, each named notification2, one history stage, zero real scheduler objects/steps, one epoch no-op.4divisible and1short batch cases also agree.')],
    revision_integrity=dict(
        exact_changed_fields=design['revision']['bounded_changed_fields'],
        independently_computed_fields=audit['exact_changed_fields'],
        exact_set_matches=True, comparison_order_note='JSON-pointer set is exact; list order is not a semantic diff.',
        all_other_original_fields_equal=True, algebra_oracles_migration_unchanged=True,
        all15criterion_ids_preserved=True,
        available_a_metadata_delta='Narrow factual update explicitly identifies accepted-A as a later dependency, not code already in62d.',
        verified_declared_receipts=55, all_declared_receipts_match=True,
        source_blobs_match_commit=True, detailed_receipt_audit=receipt(HERE / 'input-audit.json'),
        author_probe_limitations_accurate='Author probe uses actual inherited run/selector with intercepted base start and an in-memory RNG-only bundle. It does not claim full serialized/model/history/network acceptance.',
        initial_reviewer_harness_issue='First input-audit invocation incorrectly compared pointer order instead of pointer set and exited1 before any ROOT report write. Corrected only own scratch assertion; final audit passes. Original log retained.'),
    scientific_assessment=dict(
        status='PRESERVED_AND_INDEPENDENTLY_CONFIRMED',
        local='J_i=F_i+alpha_i<h_i,w>+(alpha_i/2)||w-x||^2; gradient gradF_i+alpha_i*(w-x+h_i). Shifted and author linear-plus-decay forms differ only by a parameter-independent constant when clipping is inactive.',
        paper_mapping='For the common-alpha scaled objective, paper signed local state g_i=-alpha*h_i and server state=-alpha*mean_population(h_i). Algorithm1 therefore gives selected unweighted endpoint mean plus full-population displacement-history mean.',
        weighting='Uniform default q=1. Sample q_i=N*n_i/sum(n), alpha_i=alpha/q_i. Scaled-loss/learning-rate interpretation is an algebraic inference, not a new finite-SGD convergence theorem. No sample weighting of selected endpoints, no selected-only count normalization, no label-derived coefficient.',
        primary_paper=dict(url='https://arxiv.org/pdf/2111.04263v1', version='arXiv2111.04263v1,8November2021',
                           root_receipt=audit['primary_retained_identity'][3]['root'],
                           author_receipt=audit['primary_retained_identity'][3]['author'],
                           read_evidence='Web-opened primary PDF text:Section2/Algorithm1, printed pages3-4. Retained primary and author PDF bytes/hash match. Web screenshot attempt failed because tool did not expose a PDF screenshot; no screenshot or PDF-rendering success is claimed.'),
        pinned_author_sources=[dict(commit='48a19fac440ef079ce563da8e0c2896f8256fef9',
                                    url=design['sourceidentities']['primary_code'][i]['url'],
                                    root_receipt=audit['primary_retained_identity'][i]['root'],
                                    author_receipt=audit['primary_retained_identity'][i]['author']) for i in range(3)],
        source_locations=[location('utils_general.py@48a19fac',185,'Exact train_feddyn_mdl function.'),
                          location('utils_general.py@48a19fac',190,'SGD quadratic alpha term is optimizer decay.'),
                          location('utils_general.py@48a19fac',219,'Linear coefficient alpha*(-cloud+history).'),
                          location('utils_general.py@48a19fac',224,'Gradient clipping precedes SGD decay; active clipping equivalence is not claimed.'),
                          location('utils_methods.py@48a19fac',296,'Real label-array lengths normalized across population.'),
                          location('utils_methods.py@48a19fac',387,'alpha is divided by normalized sample count.'),
                          location('utils_methods.py@48a19fac',393,'History increments by endpoint minus cloud.'),
                          location('utils_methods.py@48a19fac',396,'Uniform selected endpoint mean plus all-client history mean.')],
        exact_oracle_audit=audit['exact_oracle_independent'],
        extra_scalar_population_audit=audit['extra_rational_checks'],
        independence='Reviewer uses an affine closed-form two-step update and paper signed state with Fraction arithmetic, imports no Plato oracle/aggregation helper for expected values, and compares every retained exact trajectory field. Independent scratch4round oracle includes all10clients. Pinned local function is executed separately on both interpreters.',
        limits='Finite SGD, CPUfloat32/float64 qualification, inactive clipping comparison, no benchmark/convergence/exact author experiment claim remain unchanged.'),
    feasibility_and_boundedness=dict(
        status='EXAMPLE_LOCAL_IMPLEMENTATION_IS_FEASIBLE',
        hooks='Existing response/payload, composable training, worker state, weight-validation/aggregation/commit, checkpoint and synchronous start override hooks suffice. No base loop copy or generic protocol edit is required.',
        count_policy='Realized finite sampler/loader count before optimization plus authoritative full vector in sample mode and accepted-count consistency remain necessary; accepted-A integration does not replace example-boundary validation.',
        server_commit='Round dispatch and committed round stay distinct. Full fixed selected set must validate before commit; histories/counts/tokens/RNG checkpoint snapshot commit only with accepted cloud. Inactive and never-selected histories retain population denominator.',
        worker_commit='Parent wrapper validates model/state pairing and restores known snapshots on every rejected handoff. Child writes remain provisional; no canonical per-client history authority.',
        integration_cautions='Implementation must enforce the existing unsupported dropout/retry contract, including immutable generic debug=false disconnect recovery; keep the selected set through max_concurrency batches. This is an existing limitation/enforcement obligation, not an invented new blocker.',
        migration='Retained public class names coexist with deliberate validated-round-state training requirement. Explicit exact legacy read-only inspection remains useful; unversioned client vectors cannot constitute coherent corrected FedDyn resume. Full atomic server bundle is proportionate to selected authority; O(Nd) state/history downlink cost is disclosed.',
        ownership='Only listed strategy and example-local adapters/config/tests are assigned after root accepts design. Separate original-C fixes and SCAFFOLD/F20/B work remain outside this revision. No production source or prose changed.',
        excluded_expansions='No paper-scale qualification, generic lifecycle/checkpoint/protocol framework, mid-round recovery, dynamic populations/counts/trainability, GPU/AMP/DP or arbitrary external datasource RNG expansion.'),
    accepted_dependencies=dict(
        phase2a=dict(receipt=receipt(ROOT / 'phase2a-acceptance.json'),
                     commit='79da1f97d8a12fe97402750cc32c7b3e8f5cdf6e',
                     status='ACCEPTED_COMPONENT_AVAILABLE_LATER',
                     reviewer_scope='Acceptance receipt verified; no evolving A source read or requalification claim. Root integrates and verifies actual sampler counts in final candidate.'),
        F28=dict(root_probe=receipt(ROOT / 'server-resume-rng-probe.json'),
                 status='ROOT_CONFIRMED_GENERIC_DEFECT; separate B correction remains unreviewed for this design input.',
                 independence='No runtime worktree or proposed B fix was read. Local pending/start handshake is valid against immutable62d without relying on generic correction.',
                 later_requirement='Later accepted B integration must preserve local one-time checkpoint RNG installation and fresh-run behavior; root reruns FD-A12/13 plus accepted B startup/resume tests on combined exact candidate. Immutable-source probes establish no such integration result.')),
    criterion_reviews=criteria,
    reviewer_executions=commands,
    reviewer_probe_results=probe_summaries,
    evidence_receipts=[receipt(HERE / name) for name in
                       ['audit_inputs.py','input-audit.json','input-audit.stdout.json','input-audit.stderr.log',
                        'input-audit.initial.stderr.log','reviewer_probes.py','probes-313.json',
                        'probes-313.stderr.log','probes-314.json','probes-314.stderr.log',
                        'command-records.json','build_review.py']],
    immutable_source_receipts=audit['immutable_source_receipts'],
    accepted_plan_inputs=[entry for entry in audit['declared_receipts']
                          if entry['declared']['path'].endswith(('/AGENTS.md','/plan.md','/plan-addendum.json'))],
    limitations=[
        'Design acceptance only. No production FedDyn implementation, corrected public prose, accepted-A merged counts or later B integration is passed or claimed.',
        'Existing locked author environments used read-only:macOS ARM64 CPU, CPython3.13.16/3.14.8,Torch2.14.1,NumPy2.5.3. No provisioning, package isolation, Linux/GPU or whole-stack requalification.',
        'Independent startup probes execute actual inherited run, actual inherited start body and real selector. Scratch subclass implements a synthetic scalar/tensor bundle; disable_clients avoids processes, AsyncServer/run_app interception avoids networking. Config.args.resume is a controlled flag fixture; actual CLI parser and shipped FedDyn wiring are not exercised.',
        'Independent scratch scalar optimizer/model/all-history continuation demonstrates feasibility and test discrimination; it is not production FD-A12/13 acceptance. Production full-bundle atomic write failures, actual socket registration, spawned handoffs and full malformed model/count/schema cases remain required.',
        'Trainer probes execute actual update/tail/callback code with a reviewer-written analytical loss/update spy. They do not implement or accept the future FedDyn loss/history strategies or all-skipped rejection behavior.',
        'Pinned primary local function extraction uses controlled dataset/zero-loss globals and inactive clipping; no full historical experiment or communication-budget/convergence claim.',
        'Preserved legacy7/8 writer evidence remains in immutable first review; reviewer did not independently repeat that unchanged legacy writer test or inspect evolving C repairs.',
        'No nested agents, source/design/other-report edits, commits, push or cleanup. Only requested ROOT report and own retained scratch are written.'
    ],
    root_next_action='Root may accept this revised design at the exact reviewed hash and assign bounded implementation to the original C author. Final code,15criteria including actual run/--resume/socket/spawn, independent code/numerical/failure/prose review and later accepted B/A combined integration remain necessary before closing2C-11 or Phase2.')

OUTPUT.write_text(json.dumps(report, indent=2) + '\n')
out_receipt = receipt(OUTPUT)
(HERE / 'review-receipt.json').write_text(json.dumps(dict(output=out_receipt,
    reviewed_artifact=audit['reviewed_artifact'], code=audit['code'], verdict='PASS'), indent=2) + '\n')
print(json.dumps(out_receipt, indent=2))
