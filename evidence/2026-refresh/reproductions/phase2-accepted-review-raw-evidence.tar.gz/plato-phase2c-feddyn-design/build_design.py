"""Materialize the independently authored design, with retained source receipts."""
import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path('/Users/bli/Playground/plato')
CANDIDATE = Path('/private/tmp/plato-refresh-worktrees/feddyn-design')
SCRATCH = Path('/tmp/plato-phase2c-feddyn-design')
PRIMARY = Path('/tmp/plato-phase2-root/feddyn-primary')
PIN = '48a19fac440ef079ce563da8e0c2896f8256fef9'


def receipt(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


sources = []
for filename, expected in (
    ('utils_general.py', '6e79b259456475934b71cddc797b8dcf1e66818bd543465ad02225b6e506eca5'),
    ('utils_methods.py', '87026e71e3826893f3176359ce45bedfde858919f304b40e4ba564e214892d4d'),
    ('README.md', 'd04e9fe2e8d64dd7ec28ef785e8e428563354c32fc240fab8f2a09bb2dff2766'),
):
    source = PRIMARY / filename
    assert receipt(source)['sha256'] == expected
    destination = SCRATCH / filename
    shutil.copyfile(source, destination)
    record = receipt(destination)
    record.update(url=f'https://github.com/alpemreacar/FedDyn/blob/{PIN}/{filename}',
                  original_receipt=receipt(source), commit=PIN)
    sources.append(record)
assert receipt('/tmp/plato-phase2c-scratch/feddyn-author-utils_general.py')['sha256'] == sources[0]['sha256']

d = {
 'schema_version': 1,
 'date': '2026-10-03',
 'role': 'Fresh independent Astra design/planning author; no implementation or review acceptance claimed.',
 'finding': 'internal 2C-11',
 'verdict': 'RETAIN_AND_REPAIR; READY_FOR_FRESH_SOL_DESIGN_REVIEW; FINDING_REMAINS_OPEN',
 'decision': {
  'recommendation': 'Retain FedDyn and repair its advertised end-to-end synchronous example. Correct the local objective and replace label-derived alpha, add the missing server history correction, and make the server the authoritative owner of logical-client histories. Do not archive this maintainable example, rename the incorrect algorithm, or close the finding with a local-loss-only patch.',
  'supported_contract': 'Fixed population of positive logical client IDs; synchronous uniform selection without replacement; every selected client succeeds before the round commits; ordinary PyTorch model with a fixed trainable parameter set; plain SGD, no momentum, no optimizer weight decay, no clipping or AMP; CPU float32/float64 qualification. Full participation and proper partial participation are supported. Equal-client weighting is the default; explicitly configured fixed sample weighting follows the pinned author code.',
  'scope_reason': 'LeNet, the existing example entrypoint, and composable trainer hooks are usable. The defects are algebra, missing aggregation, and state ownership, not obsolete dependencies. An example-local server/client/trainer adapter and the already owned FedDyn strategy suffice. No accepted B runtime changes or generic federated protocol redesign are required.',
  'zero_alpha': 'The reusable local loss accepts finite alpha >= 0, with alpha=0 exactly the base loss. The end-to-end FedDyn example requires alpha > 0 and rejects zero before dispatch: Algorithm 1 is not defined at zero, and adding the cumulative correction to zero-regularization local SGD would not be FedAvg. Do not silently select another algorithm.',
  'closure': 'Fresh Sol review of this exact artifact, root acceptance, original C author implementation, fresh independent code/numerical/failure-path review, standalone Astra FedDyn prose and prose review, then root integrated acceptance before Phase 2 closes. This design alone closes nothing.'
 },
 'rationale': [
  'At w=x=2, h=0, alpha=.1, lr=.1 and zero task gradient, the candidate steps to 2.02. The correct regularizer gradient is zero, so the expected weight is 2.0. The global shift is counted twice in the current loss.',
  'Numeric label values contain no sample-size information. The all-zero fallback made the bug finite but did not repair its semantics. Relabeling otherwise identical data must not change alpha or the regularizer.',
  'feddyn.py creates simple.Client with a custom trainer and plain fedavg.Server. Default aggregation weights models by report.num_samples. Neither the client payload nor that server supplies the population history correction. Fixing only feddyn_strategy.py would still misrepresent the example.',
  'Central authoritative histories make logical client reuse, rejection, and coherent round-boundary restart tractable without changing accepted runtime files. This deliberately adds one trainable-history vector to each downlink and O(Nd) server state; no claim of original communication cost is allowed.',
  'The accepted F20 legacy UNSQUARED FedProx policy remains untouched. ROOT-2C-01 AMP clipping and the SCAFFOLD fixes are separate work. F27-R01/R02 supply failure cases to avoid, not a working implementation to copy.'
 ],
 'sourceidentities': {
  'candidate_commit': '62d7b7d8ef75be779149a96f567779c86699edb4',
  'implementation_commit': '0dc34dd1d79d90071a0babfa6aa89f33d72a976f',
  'candidate_root': str(CANDIDATE),
  'primary_code': sources,
  'author_earlier_retained_copy_verified': receipt('/tmp/plato-phase2c-scratch/feddyn-author-utils_general.py'),
  'primary_paper': {
   **receipt(SCRATCH/'2111.04263v1.pdf'),
   'title': 'Federated Learning Based on Dynamic Regularization',
   'version': 'arXiv:2111.04263v1, 8 November 2021; ICLR 2021 paper, 42 pages',
   'url': 'https://arxiv.org/pdf/2111.04263v1',
   'canonical': 'https://openreview.net/forum?id=B7v4QMR6Z9w',
   'retrieval': 'OpenReview returned a browser challenge. Read the primary arXiv PDF via web.open; subsequently curl --fail --location with normal TLS verification succeeded into owned scratch. No verification bypass.',
   'relevant_locations': 'Section 2 and Algorithm 1, printed pages 3-4; experimental clipping/reporting distinctions in Appendix A.4, printed pages 14-16. The example comment citing Appendix C.2 for fixed learning rate is not a verified citation in this version.'
  },
  'code_locations': {
   'utils_general.py': 'train_feddyn_mdl: SGD decay alpha_coef+weight_decay; batch-mean task loss; linear alpha_coef<w,-avg_mdl_param+local_grad_vector>; clipping before optimizer.step. Use pinned function anchors, not the stale public-doc line spans.',
   'utils_methods.py': 'train_FedDyn: len(clnt_y[i]) normalized to population-mean-one weights; alpha_coef/weight_list[clnt]; warm start from cld_model; local_param_list += curr_model_par-cld_mdl_param; avg selected models + mean history over all clients; separate selected/all/cloud evaluation models.'
  },
  'inputs': [receipt(p) for p in [
   ROOT/'AGENTS.md', ROOT/'evidence/2026-refresh/plan.md', ROOT/'evidence/2026-refresh/plan-addendum.json',
   CANDIDATE/'evidence/2026-refresh/phase2c-feddyn-disposition.json',
   CANDIDATE/'evidence/2026-refresh/phase2c-validation.json',
   ROOT/'evidence/2026-refresh/phase2c-scaffold-code-review.json',
   ROOT/'evidence/2026-refresh/phase2c-training-review.json']],
  'input_reconciliation': 'The FedDyn disposition and C validation inventory are in the candidate worktree, not ROOT. They explicitly leave 2C-11 open; the inventory records finite-only 2C-16 and local F23 persistence tests. Those passes do not establish the correct objective or a FedDyn server. Current FedDyn disk-ownership tests require an explicit migration under this design, not a claim that their old ownership model proves the new flow.'
 },
 'algorithm': {
  'notation': 'N is total fixed population; S_t is the nonempty selected set; x_t is the cloud model received at the beginning of round t; y_i is the successful local endpoint; h_i is an unscaled cumulative displacement, initially zero. h_i is not a measured gradient and is not the paper server variable h. Every vector below contains only the fixed trainable parameter names Q.',
  'uniform': {'objective': 'F(w)=(1/N) sum_i F_i(w), where F_i is a local mean task loss.', 'q_i': '1', 'alpha_i': 'alpha'},
  'sample': {
   'objective': 'F(w)=sum_i n_i F_i(w)/sum_i n_i for fixed positive realized per-client sample counts.',
   'q_i': 'N*n_i/sum_j n_j',
   'alpha_i': 'alpha/q_i = alpha*sum_j n_j/(N*n_i)',
   'derivation': 'Multiplying the local objective by q_i gives q_i F_i + alpha<h_i,w> + alpha/2||w-x_t||^2. Thus the common-alpha algorithm acts on scaled local losses q_i F_i. SGD on the unscaled local loss corresponds to learning rate eta/q_i on that scaled loss, matching the pinned code. This is our algebraic interpretation; do not claim a new convergence theorem for finite local steps.'
  },
  'local_loss': 'J_i(w)=F_i(w)+alpha_i<h_i,w>+(alpha_i/2)||w-x_t||^2.',
  'local_gradient': 'grad F_i(w)+alpha_i*(w-x_t+h_i). x_t, h_i and alpha_i are detached, fixed throughout all epochs/microbatches of this attempt. Construct scalar accumulators/coefficient tensors in the parameter computation dtype/device; do not downcast alpha through a default float32 tensor during a float64 oracle or derive its dtype from integer labels.',
  'equivalent_author_form': 'F_i(w)+alpha_i<w,-x_t+h_i>+(alpha_i/2)||w||^2 differs only by a w-independent constant. Use the shifted form with linear h_i alone; never add a second -x_t linear term. Do not additionally put alpha_i into optimizer weight_decay.',
  'successful_round': [
   'Train each selected client from the same immutable x_t, with its own committed h_i.',
   'For selected i, stage h_i_next=h_i+y_i-x_t exactly once per accepted round. For inactive i, retain h_i exactly.',
   'm_t=(1/|S_t|) sum_{i in S_t} y_i. This is an unweighted selected mean in BOTH weighting modes.',
   'H_next=(1/N) sum_{i=1..N} h_i_next, including inactive and never-selected zero histories.',
   'x_next=m_t+H_next. Broadcast and evaluate this corrected cloud model. Do not conflate it with the separate selected/all-client models reported by the reference experiment.'
  ],
  'paper_mapping': 'For the scaled objective, the paper local gradient-state variable is g_i=-alpha*h_i and its server state is g_bar=-alpha*mean(h_i). The server rule mean(y)-g_bar/alpha therefore equals mean(y)+mean(h_i). The implementation stores h_i to avoid sign/scaling ambiguity.',
  'optimizer_policy': 'The supported example uses ordinary torch.optim.SGD with momentum=0, dampening=0, nesterov=false, maximize=false, weight_decay=0, finite positive fixed local learning rate, no scheduler or clipping, and default or accepted gradient accumulation steps. Reject Adam/AdamW, momentum, weight decay, AMP, DP, and custom multi-optimizer/update combinations early with an actionable unsupported-mode error. Do not quietly coerce them to SGD. The local loss remains a differentiable reusable objective, but arbitrary optimizers are not a qualified end-to-end FedDyn mode.',
  'reference_limit': 'The authors split the quadratic gradient into SGD weight decay and clip the remaining gradient first. Explicit full-loss differentiation matches their unclipped SGD update when clipping is inactive; it does not reproduce their active clipping order. No exact experiment/step-for-step claim, momentum equivalence claim, or benchmark reproduction claim is allowed.',
  'parameter_policy': {
   'Q': 'Names with requires_grad=True at setup; fixed for the session and fingerprinted with exact shapes/dtypes. Supported trainable dtypes float32 and float64, dense finite tensors. Reject empty Q, complex/sparse parameters, changing trainability/schema, and ambiguous shared parameter aliases in this bounded mode.',
   'optimizer_ownership': 'Require the actual optimizer parameter groups to own each member of Q exactly once and no frozen/foreign parameter. Match by object identity, not tensor equality or shape. Group order is irrelevant. Filter frozen parameters when constructing the example optimizer, then validate. Missing trainables, duplicates and foreign parameters fail before a step.',
   'nontrainables': 'Frozen parameters and every model buffer are excluded from loss/history/correction. Exchange a full state_dict and retain the server baseline for those keys. Require uploaded nontrainable entries to equal that baseline; reject mutations rather than silently average integer/bool buffers or change frozen values. Static float/int/bool buffers are supported. BatchNorm running-stat updates and other mutable-buffer training are outside this bounded mode and must fail explicitly.',
   'model_validation': 'At each incoming boundary require the exact full state_dict key set, tensor types, exact shapes (no broadcasting), exact supported dtypes and finite floating values. Histories require the exact Q key set, shapes/dtypes and finite entries. Make independent CPU clones; no payload alias may mutate committed state.'
  }
 },
 'stateflow': {
  'authority': 'Only the example Server commits h_i, cloud model, observed counts and round generation. Keep committed_round separate from the runtime current_round, which advances for dispatch before training succeeds. Clients/workers receive a snapshot and produce provisional results. No worker or client writes canonical per-client history files. A newly created process and a reused physical process therefore obtain the same logical history from the server.',
  'server_dispatch': 'Use existing customize_server_response/customize_server_payload hooks; selected_client_id is already assigned and the two hooks run without an intervening await in the inspected synchronous loop. Bind a unique dispatch token to run UUID, round, logical client ID, schema, baseline and its history. Store these immutable dispatch records for validation. Do not infer identity from physical worker ID or an unbound payload field.',
  'downlink_schema_v1': '[full_model_state, {version: 1, run_id, round, client_id, dispatch_token, weighting, base_alpha, effective_alpha, expected_count_or_null, history: Q_tensor_mapping}]',
  'uplink_schema_v1': '[full_local_model_state, {version: 1, run_id, round, client_id, dispatch_token, num_samples, completed_steps}]',
  'uplink_history': 'No client history tensor is needed on the wire: the server computes h_i_next from its own committed history and the validated endpoint. Validate every resulting history before commit. Worker result state does include provisional history and baseline so the parent can reject a mismatched model/state pair.',
  'client_adapter': 'Install an example-local subclass of DefaultTrainingStrategy through _configure_composable while retaining default lifecycle/payload/reporting/communication strategies. The actual DefaultPayloadStrategy calls training_strategy.load_payload/train directly; overriding simple.Client._load_payload or _train alone is insufficient. In load_payload validate the ENTIRE model plus history/metadata/count contract before changing model or trainer state. In train call the actual trainer and package a result only after successful acceptance. DefaultTrainingStrategy can catch ValueError and continue building a report, so explicitly clear stale training_error at attempt start and rethrow/suppress outbound on any failure; never send a failed attempt as a successful baseline model.',
  'same_client_and_reuse': 'set_client_id changes clear all pending state; every new dispatch also replaces the snapshot even if the logical ID is unchanged. Client 1 -> 2 -> 1 must load h_1 from the server, never h_2, client 0 or a stale disk file. New global baselines replace the prior x even for consecutive rounds on the same client.',
  'worker_handoff': 'FedDynUpdateStrategy.on_train_end only stages h_next and actual completed step/count metadata. get_worker_state returns owned copies with dispatch/schema identity. Parent acceptance must validate model AND worker state, confirm h_next=h_before+(y-x), and only then expose a successful local result. feddyn_trainer.Trainer.train wraps the existing composable train call transactionally: snapshot model/strategy/context before the attempt, verify the accepted pair before returning, and restore snapshots plus clear provisional state on ANY exception, nonzero child exit, missing/stale/corrupt sidecar, or post-child callback failure. The generic loader currently loads the model before load_worker_state; use the local rollback wrapper to contain that ordering. No child canonical history writes, including after the child has saved model artifacts. A finally path must release owned temporary handles; checkpoint files outside the attempt remain byte-identical.',
  'step_semantics': 'Accumulate the full J_i using the accepted F08 mean-of-microbatch-means convention, including the correctly normalized tail. Regularizer history updates once at local run end, not once per microbatch/epoch/step. Count completed updates in FedDynUpdateStrategy.after_step, which the inspected composable trainer dispatches for normal and tail updates; no extra callback class is needed. A skipped step does not advance history; endpoint displacement already captures the successful steps. Zero completed updates, empty loaders, zero-count partitions or zero epochs produce a failed attempt and no round commit, not a baseline pseudo-update that adds old H again.',
  'server_aggregation_adapter': 'Subclass fedavg.Server in the example. Route direct weight aggregation to the subclass aggregate_weights (override _should_prefer_weight_aggregation to false so the default FedAvg strategy cannot bypass it). weights_received validates/unpacks the whole batch. aggregate_weights revalidates the whole batch after on_weights_received callbacks, checks exact dispatched set/identities, then computes finite staged histories and corrected model. weights_aggregated commits the already validated histories after model load. A local _process_reports wrapper snapshots model/history and rolls back any exception before that commit, clears pending state in finally, and rejects duplicate consumption. Restore known tensor snapshots without re-entering an injected failing loader during rollback. Do not copy/rewrite the base orchestration loop. Exceptions in evaluation after the round commit are not a second update or a rollback of an already committed algorithm round.',
  'batch_atomicity': 'For every participating report validate both metadata and every original model key/tensor before arithmetic, including the second/later payload. Enforce unique client IDs in 1..N, report.client_id/update identity/dispatch agreement, matching run/round/token, positive integer counts, completed_steps>0, count-vector agreement, full dispatched-set membership, finite baseline/history/result. Reject empty, duplicate, stale, extra, missing and mixed-generation batches. Failure leaves cloud model, all h_i, observed counts, round checkpoint, and accepted-token ledger unchanged; no residual staged history may leak into a later batch.',
  'participation': 'Uniformly sampled subsets may vary between rounds. N never becomes len(reports), number of seen clients, or sum of active sample weights. Inactive history persists, including across many skipped rounds. Within a selected round every dispatched member must return successfully; dropout/retry/asynchronous/buffered/urgent/cross-silo behavior is not supported by this example. Abort a failed round without accepting a smaller effective S_t. Restart from a committed round if needed.',
  'checkpoint': {
   'owner': 'Example Server overrides save_to_checkpoint and _resume_from_checkpoint; no changes to plato/servers/base.py.',
   'canonical': 'One versioned FedDyn round-boundary bundle under configured checkpoint_path, named with checkpoint_name/checkpoint_path (including slash-containing model names). Contents: full cloud model, all nonzero h_i keyed by logical ID with omitted never-selected entries defined as zero, N, Q/full-state schema, base alpha, weighting and full sample count vector or observed-count map, committed round, run UUID, deterministic selection RNG state (including server.prng_state/context selection state) and necessary CPU Torch/Python/NumPy RNG states. Tensors and primitive containers only; encode NumPy RNG arrays without arbitrary object loading.',
   'write': 'Capture a coherent committed snapshot including RNG at the round commit. Serialize that snapshot, not a mixture of current_round or RNG already advanced by a failed next dispatch. Write a complete temporary bundle in the same directory and atomically replace the canonical bundle only after serialization succeeds. A standalone model export may also be written, but it is never the resume authority. Save failures propagate; never publish a newer round marker with older histories. Do not delegate to the base multi-file checkpoint marker as the FedDyn resume contract.',
   'read': 'Load on CPU with weights_only=True where torch.save is used; validate the entire bundle and model/history/count/schema/config compatibility into temporary structures before mutating live model, histories, round or RNG. No history reset on load error. Changed alpha, weighting, population, sample vector or trainable schema requires an explicit fresh run, not an automatic history rescale.',
   'scope': 'Resume only at completed synchronous rounds; optimizer state is intentionally fresh each local run because supported SGD has no momentum. Reproduce uninterrupted results on the deterministic CPU toy data/sampler and selection sequence. Arbitrary external datasource RNG, in-flight recovery and exact GPU replay are not promised.'
  }
 },
 'configuration_and_metadata': {
  'existing_keys': 'Keep the existing entrypoint, TOML path, [algorithm].type="fedavg" as the underlying model-exchange algorithm, and alpha_coef precedence over feddyn_alpha with default .01. The dedicated Server is selected by feddyn.py, not by changing the global server registry. The shipped example remains SGD/lr .03/momentum 0/weight_decay 0.',
  'new_keys': {
   'algorithm.feddyn_weighting': '"uniform" (default) or "sample". Explicitly write uniform in the shipped TOML.',
   'algorithm.feddyn_sample_counts': 'Required only for sample mode: a list of length total_clients, index i-1 for client i, containing positive integers excluding bool. Full population counts must be available before the first dispatch. Reject the key in uniform mode to avoid an ignored configuration. No selected-only normalization.',
   'trainer.gradient_accumulation_steps': 'Example-local optional positive integer, default 1. Construct DefaultTrainingStepStrategy for 1 or the existing GradientAccumulationStepStrategy for a larger window. Do not assume the generic basic trainer automatically consumes the HuggingFace-style key.',
   'adaptive_alpha_API': 'Retain the Python argument name. FedDynLossStrategy defaults to false: explicit false means uniform; explicit true requires validated population/count metadata and computes alpha/q_i. Missing metadata is an error, never labels or a fabricated uniform fallback. FedDynLossStrategyFromConfig uses an omitted/None sentinel to resolve feddyn_weighting (uniform if absent); conflicting explicit bool choices raise. Preserve alpha_coef/feddyn_alpha precedence and document the corrected default.'
  },
  'actual_available_metadata': 'TrainingContext receives num_samples only after on_train_start, and its generic fallback can use len(trainset). Default client reports call sampler.num_samples and may fall back to whole trainset length. Neither supplies complete population counts; the MNIST trainset is shared backing data and is not a client partition. In the inspected candidate Dirichlet.num_samples can still redraw with partition_distribution (F15 belongs to 2A); do not assume that fix has landed here.',
  'count_binding': 'Use an example-local data-loader wrapper to obtain the realized loader sampler cardinality once after loader creation and before optimization; keep drop_last=false so that it matches the local sample set. Require an authoritative finite positive integer count; compare the selected client against configured n_i in sample mode. Cross-check any declared sampler.num_samples without using a later redraw for normalization. Return this validated count in worker state and override the outgoing report count, bypassing generic whole-dataset fallbacks. Reject unknown-length/streaming/changing-cardinality samplers in this mode. For uniform mode, sample counts only identify a valid local dataset and metrics; never weight model averaging. Cache each accepted client count and reject a later cardinality change for the fixed-data contract.',
  'compatibility': 'The current fixed-size MNIST sampler yields 600 per client, so q_i=1; uniform and sample modes with all 600 are numerically identical. Do not construct a 1000-entry vector by summing labels or enumerating all datasets as a side effect. User-supplied unequal counts must describe actual realized client partitions, not batch sizes, epochs*count, unique class counts or global backing-dataset length.',
  'validation': 'Reject bool/non-real/NaN/+Inf/-Inf/negative alpha, nonfinite effective alpha, nonpositive/noninteger N or per_round, per_round>N, zero/nonintegral/bool/missing counts, overflowed sums, unknown weighting strings and conflicting flags before any state mutation. Positive finite alpha is required in the full example. Enforce supported optimizer and synchronous configuration rather than silently changing them.'
 },
 'files': {
  'implementation_owner': 'Original C Sol author after fresh independent design review and root acceptance.',
  'exact_owned_implementation': [
   {'path': 'plato/trainers/strategies/algorithms/feddyn_strategy.py', 'change': 'Correct objective/count-derived alpha; exact Q/history validation; dispatch-scoped staged local state and worker validation; remove canonical client-file authority; retain public class names and provide explicit migration errors.'},
   {'path': 'examples/customized_client_training/feddyn/feddyn.py', 'change': 'Instantiate the FedDyn example client and server, preserving the documented invocation.'},
   {'path': 'examples/customized_client_training/feddyn/feddyn_trainer.py', 'change': 'Bounded optimizer/data-loader validation, explicit accumulation strategy selection, transactional parent handoff wrapper and correct trainer docstring.'},
   {'path': 'examples/customized_client_training/feddyn/feddyn_client.py', 'change': 'New example-local training strategy and factory; install through the actual composable payload path, validate full downlink, fail closed on local training errors, return result metadata.'},
   {'path': 'examples/customized_client_training/feddyn/feddyn_server.py', 'change': 'New synchronous aggregation/history/dispatch/checkpoint subclass using existing hooks.'},
   {'path': 'examples/customized_client_training/feddyn/feddyn_MNIST_lenet5.toml', 'change': 'Declare uniform weighting and explain positive alpha/SGD limitations; remove unverified Appendix C.2 comment.'}
  ],
  'new_tests': ['tests/trainers/test_feddyn_strategy.py', 'tests/integration/test_feddyn_round_flow.py'],
  'minimal_shared_handoffs': [
   'tests/trainers/test_personalized_state_ownership.py: change only FedDyn training branches from implicit client-file restore to explicit server-owned round state; preserve equivalent or stronger same-client, client1->2->1 and real-spawn assertions. Retain actual accepted-B-writer/new-reader coverage for the explicit read-only legacy reader, including custom save_path/canonical precedence/client0 exclusion. Other family coverage remains unchanged.',
   'tests/trainers/test_training_update_contract.py: replace the FedDyn label-zero fallback test with zero/all-label invariance and correct scalar expectations. Leave F08/F20 and other algorithms unchanged.',
   'evidence/2026-refresh/phase2c-feddyn-disposition.json and phase2c-validation.json: original author/root updates statuses and superseded F23 assumptions after implementation/review, with exact commit/receipts.',
   'docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md: ROOT assigns only the FedDyn section to a fresh Astra writer after implementation; serialize with SCAFFOLD writer. No concurrent prose edit and no SCAFFOLD section change.'
  ],
  'forbidden_incidental_changes': 'No accepted B runtime files, general aggregation strategy, generic client protocol, Config/sampler implementation, optimizer registry, base serialization, shared trainer loop, FedProx, SCAFFOLD, AMP, lockfile or manifests need changing. If an actual missing hook prevents the local adapters, stop that implementation choice and give root the exact missing handoff for review instead of expanding scope.'
 },
 'migration': {
  'old_results': 'The legacy double-shift/label-weighted/FedAvg-server trajectory was incorrect. Preserve evidence and old artifacts for historical reproduction; do not promise numerical compatibility with it. The corrected algorithm retains the FedDyn name because it repairs the advertised method; do not present a rename as remediation.',
  'old_history_files': 'Old feddyn_grad_<client>.pth files lack algorithm/version/global-history coherence. The corrected end-to-end example never auto-loads them. Preserve their bytes. Do not adopt client0 or infer a global history from a subset of old files. An explicit fresh run may use old model weights as a warm start, with all histories zero and a new run UUID; that is not continuation.',
  'proven_legacy_spelling': 'TRAINING-2C-02 independently executed the accepted-B writer at 00eeb9dcdd2b513e64db9408969356037e09bb8e: f"{base_path}_feddyn_grad_{client_id}.pth". The candidate omitted the underscore. Root has assigned that independent compatibility repair to the original author before this equation work. Do not erase the repair or repeat the incorrect handcrafted-reader test.',
  'legacy_reader_contract': 'Retain save_path and expose an explicit read_legacy_history(context) migration/inspection operation on FedDynUpdateStrategy. It returns a validated detached history without adopting it as live state or writing anything. Canonical <root>/feddyn_grad_ID.pth wins; if absent, read exactly <root>_feddyn_grad_ID.pth for nonzero same-client IDs. The unproven no-underscore spelling is not the accepted-B format; do not use fuzzy prefix search. Missing files are distinguishable from corrupt files; no corruption-to-zero fallback. Never read client0 for another ID. Preserve custom save_path and originals. Validate all old entries, and project only explicitly recognized frozen-parameter extras if necessary; do not broadly ignore unknown keys.',
  'public_strategy_API': 'Keep FedDynLossStrategy, FedDynLossStrategyFromConfig and FedDynUpdateStrategy exported. FedDynUpdateStrategy requires explicit validated round state for training; a plain generic ComposableTrainer lacking it fails with instructions to use the dedicated FedDyn example. save_path remains meaningful for explicit read-only legacy inspection; if supplied for new training, raise a migration error directing the caller to server checkpoint_path rather than silently ignoring it. Recognizing a legacy file is not authorization to continue the old numerical trajectory under new equations. This intentional training-state interface change must be reviewed and documented.',
  'tests_and_inventory': 'Update the old FedDyn training-file-persistence assertions explicitly under this decision. Replace automatic training adoption with no-file-mutation, server persistence and worker-failure isolation checks; preserve the exact old-writer/new-reader test through the explicit reader. Leave other F23 family migrations intact. Record that compatibility recovery was repaired before numerical migration, rather than labeling the old spelling defect waived.'
 },
 'testacceptance': [],
 'docs_requirements': {
  'writer': 'Fresh Astra writer after original C implementation; fresh independent prose/source reconciliation before closure.',
  'must_cover': [
   'State the corrected local equation, displacement-history sign, and full server correction, with defined x/y/h/N/S and trainable scope.',
   'State uniform default, sample-count vector requirement, alpha_i=alpha*sum(n)/(N*n_i), and unweighted selected model averaging in both modes. Labels never determine weights.',
   'Describe dedicated example server/client wiring; composing a loss with plain FedAvg is not a complete FedDyn implementation.',
   'Explain server-owned history transmission and coherent round-boundary restart, old-checkpoint incompatibility, positive-alpha restriction, and preserved historical artifacts.',
   'Describe plain SGD/zero decay/no clipping qualified contract, mean-microbatch accumulation, empty/failure rejection, static buffers/frozen parameters and unsupported modes. Do not claim optimizer/AMP/GPU/convergence coverage beyond executed evidence.',
   'Distinguish evaluated cloud model from the authors selected/all-model metrics and disclose extra downlink/history storage cost.',
   'Replace exact-reference, step-for-step and label-weighted bookkeeping claims; cite pinned author function links and primary paper Algorithm 1. Avoid stale line-number prose and the false Appendix C.2 learning-rate attribution.',
   'Give a working existing example command with --cpu and the new explicit config keys. Retain attribution. Change only FedDyn prose; SCAFFOLD remains under its separate owner.'
  ],
  'not_written_now': 'This JSON is a design artifact, not the required standalone public prose. The candidate documentation remains knowingly incorrect until the writer implements the reviewed replacement.'
 },
 'limits': [
  'Design and independent arithmetic are complete; production implementation, green acceptance tests and independent approval remain pending.',
  'No paper-scale accuracy or convergence experiment is required or claimed for this bounded repair. Finite local SGD is an inexact solver.',
  'Qualification is CPU float32/float64 on Python 3.13 and 3.14. GPU/AMP/DP, asynchronous/partial-failure rounds, dynamic populations/counts/trainability and mutable-buffer training are outside the supported example; reject incompatible requested modes.',
  'Central state changes communication/storage placement while preserving the defined update equations. It cannot be marketed as the paper communication budget.',
  'Full mid-round or arbitrary datasource/accelerator RNG recovery is out of scope. Only coherent round-boundary continuation with the declared fixed dataset/sampler contract is promised.',
  'No source, tests, candidate docs or other evidence edited by this author; no nested agents, commits, pushes or cleanup of others artifacts.'
 ],
 'workflow': {
  'authorized_writes': [str(ROOT/'evidence/2026-refresh/phase2c-feddyn-design.json'), str(SCRATCH)],
  'shell': 'All shell invocations use zsh -lc.',
  'next': 'Root sends the exact output hash to a fresh Sol design reviewer, resolves findings, then assigns original C implementation. Do not present this independently authored plan as independently reviewed.'
 }
}

tests = [
 ('FD-A01', 'Independent scalar loss oracle',
  'Use float64 scalar w=x=2,h=0,alpha=.1,eta=.1, differentiable zero task loss. Compute the analytical gradient without importing the implementation and compare both the strategy and one SGD step.',
  'regularizer gradient=0; local y=2.0; h_next=0. Candidate result 2.02 must fail. Also w=1,x=2,h=.5 gives gradient=-.05 and y=1.005. With same-client new x=w=3,h=.5: gradient=.05,y=2.995,h_next=.495. Alpha zero gives exactly the base task gradient locally, while the full example rejects alpha zero.'),
 ('FD-A02', 'Three-round partial-participation oracle',
  'N=2, x0=2, h=[0,0], alpha=.1, eta=.1; F1=.5*w^2,F2=.5*(w-4)^2; two SGD steps per visit; S1={1},S2={2},S3={1}. Compare actual client train -> accepted worker state -> actual server._process_reports -> next downlink against the retained Fraction oracle at every boundary.',
  'Uniform local endpoints [1.622,1.918163,1.6062289895], cloud models [1.433,1.9717445,1.47705273425], final h=[-.7435155105,.485163]. Inactive h2 stays zero in round1; h1 stays -.378 in round2. Never accept FedAvg local endpoints as cloud answers.'),
 ('FD-A03', 'Unequal counts and equal-count reduction',
  'Repeat FD-A02 with counts [1,3], sample mode. Each local dataset repeats the same scalar loss, so only alpha weighting changes. Then sample counts [2,2] must reproduce uniform exactly; uniform counts [17,93] must leave the uniform sequence unchanged.',
  'Sample alpha1=.2, alpha2=1/15. Local endpoints [1.624,1.9214506666666666,1.618792512]; cloud [1.436,1.976176,1.4948261013333333]; final h=[-.733383488,.48545066666666664]. Exact rational values are in oracle-results.json. Uniform vs sample quadratic objective optima are 2 vs 3, respectively; do not infer weighting from a selected-only denominator.'),
 ('FD-A04', 'Multiple participants, inactive history and population denominator',
  'Aggregation-only independent algebra test: N=3, x=2, h=[.4,-.2,.6], S={1,3}, valid y1=1,y3=4, actual counts [1,3,2]. Run both modes. Also exercise a real two-client full-participation first round using FD-A02 losses.',
  'Staged h=[-.6,-.2,2.6], H=.6, selected mean=2.5, cloud=3.1 in both modes. Assert inactive -.2 preserved. From x2 with h0 and both real clients: uniform cloud=2; sample counts[1,3] cloud=2.0026666666666667. Model averaging never uses counts.'),
 ('FD-A05', 'Label permutation and count provenance',
  'Hold logits/task gradients/partition cardinalities fixed; compare labels all-zero, [0,1], [1,1], and permuted arbitrary class IDs for regularizer-only gradient. For a classification-loss test permute output columns with labels so the task objective is unchanged. Exercise actual loader sampler cardinality, report count and supplied full count vector.',
  'Identical alpha and regularizer gradients under every relabeling and label batch composition; finite all-zero result. Complete objective gradients agree after the matching class permutation. Wrong/missing count metadata, counts taken from global trainset or changed partitions fail before a step/commit. Equal-cardinality class imbalance never changes alpha.'),
 ('FD-A06', 'Finite inputs and supported configuration',
  'Parameterize alpha=-1,NaN,+Inf,-Inf,bool,string and valid 0,.1; N/per_round invalid types/ranges; missing/zero/negative/nonintegral/bool sample counts, wrong vector length, overflow/nonfinite effective alpha, bad mode/conflict. Exercise optimizer momentum/weight_decay/nonSGD/clipping/AMP and async configuration.',
  'Invalid settings raise useful errors without modifying model/history/files or creating an outbound success. Local alpha0 equals task-only; example alpha0 rejected. Valid uniform/sample and all-equal vector pass. Unsupported optimizer choices fail explicitly and no alpha decay is injected into SGD.'),
 ('FD-A07', 'Parameter identity and full-state scope',
  'Toy model with two same-shaped trainables, frozen float parameter, static floating buffer, integer buffer and bool buffer. Reverse optimizer group order, omit one trainable, duplicate a param, add a foreign param, change flags/shape mid-run, inject buffer mutation.',
  'Loss and h use exactly Q matched by names and actual optimizer identity. Reversed group order gives identical output. Frozen/static buffers are byte-identical across correct aggregation/checkpoint and absent from history. Invalid ownership/schema or changed nontrainables reject before any commit; no shape-based pairing or integer history arithmetic.'),
 ('FD-A08', 'Accumulation, empty and skipped updates',
  'At w=x=2,h=.5,alpha=.1, zero task gradient, eta=.1, train three equal mean-loss microbatches with accumulation_steps=2. Repeat divisible/tail/short windows and one explicitly skipped step. Exercise empty loader, zero epochs and all skipped updates.',
  'Three microbatches cause two real SGD updates: y=1.99005, h_next=.49005, exactly two optimizer/scheduler/after-step notifications and one history staging. A single successful step after a skipped one yields y=1.995,h_next=.495. All-empty/all-skipped attempts fail with no canonical state change and no accepted result; rerun starts without leaked gradients.'),
 ('FD-A09', 'Logical identity and real spawn persistence',
  'Run FD-A02 through one reused physical client 1->2->1; compare a dedicated-client run and fresh process per visit. Repeat actual max_concurrency spawn, including changed global baseline for consecutive same-client dispatches. Parent state must reflect each successful child before packaging its report.',
  'All intermediate model/h/count/step values match the oracle. No client0 or per-client disk history is adopted; forged old files remain byte-identical. Every history comes from the corresponding current server dispatch; changing physical worker has no numerical effect.'),
 ('FD-A10', 'Worker rejection transaction',
  'Let a real spawned child finish/save its candidate result, then inject failure before parent acceptance: nonzero exit after save, missing/corrupt state file, token/client/round mismatch, missing key/shape mismatch/NaN history, inconsistent h_next, corrupt model, or a parent handoff exception. Test each then retry client1, reuse as client2, and return to client1.',
  'The failed attempt sends no update; parent model/strategy/history/dispatch state roll back; server state and canonical checkpoint bytes do not advance. A valid retry reproduces the pre-failure oracle exactly. No child-written history artifact can contaminate reuse. This must reproduce the F27-R02 failure pattern as a FedDyn regression, not merely compare successful child states.'),
 ('FD-A11', 'Whole-batch malformed payload rejection',
  'Run actual example client inbound path and server._process_reports. First participant valid; later one has missing/extra model key, scalar-for-[1] broadcastable shape, wrong dtype, NaN/Inf, non-tensor, changed buffer or invalid metadata. Also malformed downlink history/model and corrupt worker history; duplicate/stale/unknown IDs, token mismatch, count mismatch, missing selected member, empty batch; inject mutation in on_weights_received callback. Test a valid payload immediately after every failure.',
  'The ENTIRE batch validates before model/history arithmetic or live load. No model key, any h_i, observed count, checkpoint bytes or accepted-token state changes on rejection; pending fields clear. Check each original model, not just final aggregate shape. Valid follow-up consumes each dispatch exactly once and matches oracle. Also inject load/aggregation failure after staging and require precommit rollback. This is the explicit F27-R01 analogue.'),
 ('FD-A12', 'Round-boundary checkpoint continuation and atomic rejection',
  'Commit FD-A02 round2, save, destroy server and all clients, restore into fresh objects and run round3 with a new physical client. Repeat sample mode. Include deterministic selection-RNG continuation, slash model name, static buffers/frozen parameters. Corrupt/mismatch model or h/schema/count/alpha/round/version; inject serialization failure before replace.',
  'Resumed round3 equals uninterrupted float64 oracle to atol=1e-12,rtol=0; float32 integration uses atol=1e-6,rtol=1e-6. Missing legacy history bundle yields a migration error, not zeros. Rejected load leaves all live state and RNG unchanged. Failed write leaves the previous canonical bundle byte-identical. Full model export alone cannot resume FedDyn.'),
 ('FD-A13', 'Shipped entrypoint and transport integration',
  'Load the actual shipped TOML and invoke its main wiring with bounded synthetic MNIST-shaped data/LeNet and explicit overrides N=2, per_round=1, epochs=1, three rounds, --cpu; no download. Exercise the actual default client payload strategy, full example server flow and real spawn. Add a deadline-bounded comm_simulation=false local socket smoke with isolated ports/runtime directories on the accepted integration harness.',
  'Finite parameter-changing local training, corrected cloud model verified from captured successful endpoints and independently maintained h table, intended custom server/client instantiated, state serialization round-trip works, no failed reports sent, normal bounded shutdown with no surviving task children. Record exact overrides: a synthetic smoke is not MNIST benchmark accuracy. Run CPU 3.13 and 3.14; existing F20 and B lifecycle regressions remain green.'),
 ('FD-A14', 'Source, migration and documentation gate',
  'Fresh reviewer checks primary bytes/hash, equations against independent scalar/rational oracle, corrected public prose against final implementation, and diff ownership. Run scoped Ruff import checks and appropriate type checks plus focused and integration regression suite on Python 3.13/3.14.',
  'No accepted B runtime modification; no changes to F20 unsquared equation or SCAFFOLD section; explicit documented API/state migration and retained old artifacts. No tests weakened to preserve incorrect scalar/label behavior. Evidence records commands/interpreter/lock/source hashes, results, skips and limits; 2C-11 closes only after fresh independent review and root acceptance.'),
 ('FD-A15', 'Actual legacy writer and explicit numerical migration',
  'Use accepted-B writer bytes at commit 00eeb9dcdd2b513e64db9408969356037e09bb8e to produce client1 history at root+"_feddyn_grad_1.pth". Invoke the new explicit read-only legacy reader with default and custom save_path. Add canonical and client0 decoys, malformed legacy state, and then attempt corrected training/resume without a versioned round state.',
  'Read the exact same-client vector (review fixture weight=7,bias=8), canonical wins when present, client0 never adopted, originals unchanged. Corruption is a visible error. Training/resume refuses to turn an unversioned vector into a coherent FedDyn continuation; explicit fresh model-only warm start has h_i=0 and a new run UUID. This preserves the independently repaired filename contract while documenting the numerical migration.')
]
for test_id, title, setup, expected in tests:
    d['testacceptance'].append(dict(id=test_id,title=title,setup=setup,expected=expected,status='REQUIRED_NOT_YET_IMPLEMENTED'))
d['testacceptance_execution_policy'] = {
 'independence': 'The acceptance oracle imports no Plato helper and uses Fraction arithmetic. Implementation tests must derive expectations from the retained equations/constants, not call the new aggregation/history helper to calculate expected output. Compare per-round intermediate state as well as final model.',
 'existing_red_evidence': 'Author scalar probe replayed against the exact candidate, with PYTHONDONTWRITEBYTECODE=1 and TMPDIR restricted to owned scratch. Replaying an author probe confirms reproducibility but is not an independently authored production test. The retained Fraction oracle is independently authored.',
 'numeric_tolerances': 'Pure loss/local/server float64 checks atol=1e-12,rtol=0 when inputs are representable within that precision; use rational expected values converted once. Real float32 LeNet flow atol=1e-6,rtol=1e-6 for oracle arithmetic from received endpoints, with justified scaling if multi-tensor accumulation requires it. NaNs never pass equal_nan.',
 'suggested_commands_after_implementation': [
  'zsh -lc "uv run pytest tests/trainers/test_feddyn_strategy.py tests/integration/test_feddyn_round_flow.py tests/trainers/test_personalized_state_ownership.py tests/trainers/test_training_update_contract.py"',
  'Run the same selected suite with the root-qualified Python 3.13 and 3.14 locked environments; retain real spawn and local-socket test logs, bounded deadlines and cleanup evidence.',
  'zsh -lc "uv run ruff check <owned changed Python paths> --select I"; appropriate owned-source type check; then root runs integrated B/C regression profile.'
 ],
 'not_claimed': 'No proposed green production tests or independent design review have run yet.'
}
d['oracle'] = {
 'script': receipt(SCRATCH/'oracle.py'),
 'results': receipt(SCRATCH/'oracle-results.json'),
 'trajectory': json.loads((SCRATCH/'oracle-results.json').read_text()),
 'command': 'zsh -lc \'PYTHONDONTWRITEBYTECODE=1 python3 /tmp/plato-phase2c-feddyn-design/oracle.py\'',
 'result': 'PASSED independent exact Fraction assertions for both modes and equal-count/uniform invariance.'
}
d['workflow']['immutable_worktree_handoff'] = 'Initial source inspection used the original training worktree while it was pinned and clean. On root steering, switched all further source reads and replay to the new detached /tmp/plato-refresh-worktrees/feddyn-design worktree; verified HEAD=62d7b7d8ef75be779149a96f567779c86699edb4 and clean status. All final source receipts below are from that immutable worktree. No claim is made about the evolving original C worktree.'
d['sourceidentities']['inspected_flow_receipts'] = [receipt(CANDIDATE/path) for path in (
 'examples/customized_client_training/feddyn/feddyn.py',
 'examples/customized_client_training/feddyn/feddyn_trainer.py',
 'examples/customized_client_training/feddyn/feddyn_MNIST_lenet5.toml',
 'plato/trainers/strategies/algorithms/feddyn_strategy.py',
 'plato/trainers/composable.py','plato/trainers/strategies/base.py',
 'plato/clients/simple.py','plato/clients/strategies/defaults.py',
 'plato/servers/fedavg.py','plato/servers/base.py',
 'plato/servers/strategies/aggregation/fedavg.py','plato/algorithms/fedavg.py',
 'plato/samplers/dirichlet.py','plato/samplers/iid.py',
 'tests/trainers/test_personalized_state_ownership.py',
 'tests/trainers/test_training_update_contract.py',
 'docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md')]
if (SCRATCH/'candidate-scalar-replay.json').exists():
    replay = json.loads((SCRATCH/'candidate-scalar-replay.json').read_text())
    assert abs(replay['records'][0]['actual_next_weight'] - 2.02) < 1e-8
    assert replay['records'][0]['author_next_weight'] == 2.0
    d['candidate_scalar_replay'] = {
      'result': 'REPRODUCED known red scalar; not a new independent probe implementation.',
      'script': receipt('/tmp/plato-phase2c-scratch/feddyn_disposition_probe.py'),
      'output': receipt(SCRATCH/'candidate-scalar-replay.json'),
      'stderr': receipt(SCRATCH/'candidate-scalar-replay.stderr.log'),
      'command': 'zsh -lc \'PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/private/tmp/plato-refresh-worktrees/feddyn-design TMPDIR=/tmp/plato-phase2c-feddyn-design OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /tmp/plato-phase2c-313/bin/python /tmp/plato-phase2c-scratch/feddyn_disposition_probe.py\'',
      'cwd': str(CANDIDATE),
      'records': replay['records']}

destination = ROOT/'evidence/2026-refresh/phase2c-feddyn-design.json'
destination.write_text(json.dumps(d, indent=2, ensure_ascii=False)+'\n')
json.loads(destination.read_text())
print(json.dumps(receipt(destination), indent=2))
