"""Independent rational FedDyn acceptance oracle; imports no Plato code."""
from fractions import Fraction as F
import json


def trajectory(mode, counts=(1, 3)):
    x, histories = F(2), [F(0), F(0)]
    rows = []
    for round_number, client in enumerate((0, 1, 0), 1):
        alpha = F(1, 10)
        if mode == "sample":
            alpha *= F(sum(counts), len(counts) * counts[client])
        baseline, history_before, w = x, histories[client], x
        for _ in range(2):
            task_gradient = w - (0, 4)[client]
            w -= F(1, 10) * (task_gradient + alpha * (w - x + history_before))
        histories[client] += w - baseline
        x = w + sum(histories) / 2
        rows.append(dict(round=round_number, client=client + 1,
                         baseline=baseline, alpha=alpha, history_before=history_before,
                         local=w, delta=w-baseline, h1=histories[0], h2=histories[1],
                         history_mean=sum(histories)/2, global_next=x))
    return rows


def encode(value):
    if isinstance(value, F):
        return {"exact": str(value), "decimal": float(value)}
    if isinstance(value, dict):
        return {key: encode(item) for key, item in value.items()}
    if isinstance(value, list):
        return [encode(item) for item in value]
    return value


def main():
    uniform, sample = trajectory("uniform"), trajectory("sample")
    assert uniform[0]["global_next"] == F(1433, 1000)
    assert uniform[-1]["global_next"] == F(5908210937, 4000000000)
    assert sample[-1]["global_next"] == F(140139947, 93750000)
    assert trajectory("sample", (2, 2)) == uniform
    assert trajectory("uniform", (17, 93)) == uniform
    report = {"uniform": uniform, "sample": sample}
    print(json.dumps(encode(report), indent=2))


if __name__ == "__main__":
    main()
