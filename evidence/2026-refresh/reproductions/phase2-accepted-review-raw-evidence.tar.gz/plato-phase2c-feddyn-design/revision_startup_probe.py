"""Scratch-only resume-order feasibility; no FedDyn implementation or sockets."""
import copy
import json
import os
from pathlib import Path
import random
import sys
from types import SimpleNamespace
from unittest.mock import patch

SCRATCH = Path('/tmp/plato-phase2c-feddyn-design')
SNAPSHOT = Path('/private/tmp/plato-refresh-worktrees/feddyn-design')
config_path = SCRATCH / 'revision-probe-config.toml'
config_path.write_bytes((SNAPSHOT / 'examples/customized_client_training/feddyn/feddyn_MNIST_lenet5.toml').read_bytes())
os.environ['config_file'] = str(config_path)
sys.argv = [sys.argv[0], '-b', str(SCRATCH / 'revision-runtime'), '--cpu']

import numpy as np
import torch
from plato.servers import base
from plato.servers.strategies.client_selection.random_selection import RandomSelectionStrategy


def capture():
    return dict(python=random.getstate(), numpy=np.random.get_state(),
                torch=torch.get_rng_state().clone())


def equal_rng(a, b):
    return (a['python'] == b['python'] and a['numpy'][0] == b['numpy'][0]
            and np.array_equal(a['numpy'][1], b['numpy'][1])
            and a['numpy'][2:] == b['numpy'][2:]
            and torch.equal(a['torch'], b['torch']))


def restore(states):
    random.setstate(states['python'])
    np.random.set_state(states['numpy'])
    torch.set_rng_state(states['torch'])


selection_rng = random.Random(17)
prior = [selection_rng.sample(list(range(1, 11)), 2) for _ in range(2)]
selection_state = selection_rng.getstate()
expected = [selection_rng.sample(list(range(1, 11)), 2) for _ in range(2)]
bundle = dict(selection=selection_state, python=random.Random(43).getstate(),
              numpy=np.random.RandomState(29).get_state(),
              torch=torch.Generator(device='cpu').manual_seed(31).get_state())


class ScratchServer(base.Server):
    def __init__(self, supplied, repair=True):
        self.disable_clients = True
        self.periodic_interval = 1
        self.current_round = 2
        self.context = SimpleNamespace(state={}, current_round=2)
        self.client_selection_strategy = RandomSelectionStrategy()
        self.prng_state = random.Random(991).getstate()
        self.context.state['prng_state'] = self.prng_state
        self.supplied = supplied
        self.repair = repair
        self._pending_resume_rng = None

    def configure(self):
        pass

    def _resume_from_checkpoint(self):
        # Validate in private generators; never modify global RNG on rejection.
        staged = copy.deepcopy(self.supplied)
        random.Random().setstate(staged['selection'])
        random.Random().setstate(staged['python'])
        np.random.RandomState().set_state(staged['numpy'])
        torch.Generator(device='cpu').set_state(staged['torch'])
        self._pending_resume_rng = staged

    async def _periodic(self, interval):
        pass

    def start(self, *args, **kwargs):
        pending = self._pending_resume_rng
        if self.repair and pending is not None:
            restore(pending)
            self.prng_state = pending['selection']
            self.context.state['prng_state'] = pending['selection']
            self._pending_resume_rng = None
        return super().start(*args, **kwargs)

    def __str__(self):
        return 'FedDynDesignRevisionScratch'


def boundary(self, *args, **kwargs):
    self.boundary_rng = capture()
    self.boundary_selection = self.prng_state
    self.boundary_context = self.context.state['prng_state']
    self.pending_at_boundary = self._pending_resume_rng
    self.selections = [self._select_clients_with_strategy(list(range(1, 11)), 2)
                       for _ in range(2)]


def run(server, resume):
    cfg = SimpleNamespace(args=SimpleNamespace(resume=resume),
                          clients=SimpleNamespace(type='simple'),
                          server=SimpleNamespace(random_seed=17),
                          is_central_server=lambda: False)
    with patch.object(base, 'Config', lambda: cfg), patch.object(base.Server, 'start', boundary):
        server.run()


initial = capture()
try:
    broken = ScratchServer(bundle, repair=False)
    run(broken, True)
    assert broken.selections[0] == [9, 7]
    fixed = ScratchServer(bundle)
    run(fixed, True)
    assert fixed.selections == expected
    assert equal_rng(fixed.boundary_rng, bundle)
    assert fixed.boundary_selection == fixed.boundary_context == selection_state
    assert fixed.pending_at_boundary is None

    restore(initial)
    fresh = ScratchServer(bundle)
    run(fresh, False)
    assert fresh.selections == prior
    fresh_expected = dict(initial, python=random.Random(17).getstate())
    assert equal_rng(fresh.boundary_rng, fresh_expected)
    assert fresh.pending_at_boundary is None

    rejected = []
    for key, value in [('selection', ()), ('python', ()), ('numpy', ()),
                       ('torch', torch.zeros(1, dtype=torch.uint8))]:
        bad = copy.deepcopy(bundle)
        bad[key] = value
        instance = ScratchServer(bad)
        instance._pending_resume_rng = sentinel = object()
        before = capture()
        old_selection = instance.prng_state
        old_context = instance.context.state['prng_state']
        try:
            run(instance, True)
        except (ValueError, TypeError, IndexError, RuntimeError):
            pass
        else:
            raise AssertionError(f'{key} malformed state accepted')
        assert equal_rng(before, capture())
        assert instance.prng_state == old_selection
        assert instance.context.state['prng_state'] == old_context
        assert instance._pending_resume_rng is sentinel
        rejected.append(key)

    print(json.dumps(dict(
        python=sys.version, torch=torch.__version__, seed=17,
        committed_selections=prior, expected_later_selections=expected,
        uncorrected_first=broken.selections[0], corrected_later=fixed.selections,
        live_python_numpy_torch_cpu_restored_before_base_start=True,
        server_and_context_selection_state_restored=True,
        pending_consumed_before_base_start=True, fresh_seed_behavior_preserved=True,
        rejection_unchanged_rng_and_pending=rejected,
        limitation='Actual inherited Server.run and selection strategy; base start intercepted before socket creation. In-memory RNG-only bundle and scratch subclass, no production FedDyn implementation, model/history training, checkpoint serialization or network. These remain required acceptance tests.'
    ), indent=2))
finally:
    restore(initial)
