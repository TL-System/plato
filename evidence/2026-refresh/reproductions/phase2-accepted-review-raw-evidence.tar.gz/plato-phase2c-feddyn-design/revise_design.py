"""Bounded FD-D-R01/FD-D-L01 revision of the retained original design."""
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path('/Users/bli/Playground/plato/evidence/2026-refresh')
SCRATCH = Path('/tmp/plato-phase2c-feddyn-design')
SNAPSHOT = Path('/private/tmp/plato-refresh-worktrees/feddyn-design')
ORIGINAL_SHA = '455d144736f6318246c834d679e2ca8d371160dd654bfea6bab96b7abc9c4d60'
REVIEW_SHA = 'e2b46a83c1a098e4b9d19e123b4c8c92fb1298f0a41515c4663e523aaae3522a'


def receipt(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


original_path = SCRATCH / 'phase2c-feddyn-design.original-455d1447.json'
review_path = ROOT / 'phase2c-feddyn-design-review.json'
assert receipt(original_path)['sha256'] == ORIGINAL_SHA
assert receipt(review_path)['sha256'] == REVIEW_SHA
original = json.loads(original_path.read_text())
d = copy.deepcopy(original)
review = json.loads(review_path.read_text())
assert review['verdict'] == 'REQUEST_CHANGES'
assert review['reviewed_artifact']['sha256'] == ORIGINAL_SHA

# Preserve all equations, original numerical records, identities and test IDs.
d['verdict'] = 'RETAIN_AND_REPAIR; REVISED_FOR_FRESH_SOL_DESIGN_REVIEW; FINDING_REMAINS_OPEN'
cp = d['stateflow']['checkpoint']
cp['owner'] = (
    'Example Server overrides save_to_checkpoint, _resume_from_checkpoint and start; '
    'the start override performs the validated pending RNG handoff after inherited '
    'Server.run reseeding and before delegating to inherited start. No changes to '
    'plato/servers/base.py or generic runtime/selection strategies.'
)
cp['read'] = (
    'Load on CPU with weights_only=True where torch.save is used; validate the entire '
    'bundle and model/history/count/schema/config compatibility into temporary structures '
    'before mutating live model, histories, round, RNG or existing pending resume state. '
    'Validate selection/Python RNG with private random.Random instances, NumPy state with '
    'a private numpy.random.RandomState, and Torch CPU state with a private '
    'torch.Generator(device="cpu"); validation must not seed, draw from, or set any live '
    'generator. Check duplicated serialized selection fields agree. After successful '
    'whole-bundle validation/installation, establish the normal successful-resume '
    'metadata (current_round, context.current_round and resumed_session=True) and '
    'publish an owned copy of the RNG snapshot as self._pending_resume_rng, bound '
    'to this committed run/round. Defer its live '
    'application to the local start hook, because inherited run restores first and '
    'then reseeds/replaces self.prng_state. Rejected loads leave all live state, RNG '
    'and any prior pending snapshot unchanged; do not clear pending state before '
    'validation or reset history on error. Changed alpha, weighting, population, sample '
    'vector or trainable schema requires an explicit fresh run, not an automatic history rescale.'
)
cp['startup_handoff'] = {
    'ordering_in_immutable_62d': (
        'Server.run calls configure, _resume_from_checkpoint when args.resume is true, '
        'launches clients, then random.seed(server.random_seed) and replaces '
        'self.prng_state before calling self.start. _select_clients_with_strategy later '
        'copies self.prng_state into context.state["prng_state"]. Restoring only in '
        '_resume_from_checkpoint or only in context is therefore insufficient.'
    ),
    'local_hook': (
        'Initialize _pending_resume_rng=None on the example Server. Override start with '
        'compatible forwarding of its arguments; before calling super().start, consume '
        'a successfully validated pending snapshot for the current committed run/round. '
        'Recheck its identity/schema without changing live state. In one synchronous '
        'block with no await, set self.prng_state and context.state["prng_state"] to '
        'the saved selection state, set Python random global state to its separately '
        'saved value, set numpy.random global state including its Gaussian cache, and '
        'restore the saved Torch default CPU generator state. Do not conflate Python '
        'global RNG with selection RNG if their saved states differ. Restore each '
        'already-promised serialized CPU RNG field, not merely the client selector.'
    ),
    'commit_and_rejection': (
        'Validate all RNG values using private generators before applying any of them. '
        'Snapshot the live RNGs, server/context selection fields and pending object at '
        'this boundary; if restoration fails, restore those snapshots and leave the '
        'pending snapshot unconsumed. Do not delegate to inherited start after a '
        'rejected handoff. Clear _pending_resume_rng only after all promised states '
        'are successfully installed, before super().start can register sockets or '
        'service client registration/selection. Subsequent start calls without a '
        'new successful resume load must not reapply an already consumed snapshot.'
    ),
    'fresh_run': (
        'With no pending snapshot, forward directly to super().start without setting '
        'or consuming RNG state. Preserve inherited fresh-run server.random_seed '
        'behavior exactly. Do not remove seeding, reset it after restored state is '
        'installed, move checkpoint loading into generic run, or alter accepted B.'
    ),
    'boundary': (
        'The handoff runs after inherited client-launch/reseed work but before '
        'inherited start opens/services the registration and selection path. Child '
        'process launch does not imply registration has been serviced. Keep this '
        'hook synchronous and exercise the actual run ordering. Cross-silo remains '
        'unsupported; this adds no GPU, in-flight or arbitrary datasource RNG promise.'
    ),
    'later_accepted_B_integration': (
        'Root has assigned generic startup defect F28 to the original B author in '
        'a separate worktree with fresh review required. This design does not '
        'depend on that unaccepted change and assigns no generic runtime edits. '
        'Later accepted B integration must preserve the explicit example-local '
        'checkpoint/pending-RNG/start handshake and fresh-run behavior. If shared '
        'startup no longer overwrites restored selection state, the local hook '
        'still installs the validated checkpoint snapshot once and consumes it '
        'without drawing or reseeding; it must not be removed merely because '
        'generic reseeding was corrected. Root reruns FD-A12/13 and the accepted '
        'B startup/resume regressions on the combined candidate before acceptance.'
    ),
    'concrete_reproducer': {
        'seed': 17, 'total_clients': 10, 'per_round': 2,
        'ordered_pool': list(range(1, 11)),
        'committed_selections': [[9, 7], [5, 6]],
        'expected_next': [5, 3], 'uncorrected_next': [9, 7],
        'expected_following': [9, 5]
    }
}
cp['scope'] = (
    'Resume only at completed synchronous rounds; optimizer state is intentionally '
    'fresh each local run because supported SGD has no momentum. Prove continuation '
    'through actual Server.run/--resume startup and the example-local start handoff, '
    'not only direct _resume_from_checkpoint calls. Compare later selections, cloud '
    'models and all-client histories with uninterrupted deterministic CPU training. '
    'Arbitrary external datasource RNG, in-flight recovery and exact GPU replay '
    'are not promised.'
)

metadata = d['configuration_and_metadata']
metadata['actual_available_metadata'] = (
    'TrainingContext receives num_samples only after on_train_start, and its generic '
    'fallback can use len(trainset). Default client reports call sampler.num_samples '
    'and may fall back to whole trainset length. Neither supplies complete population '
    'counts; the MNIST trainset is shared backing data and is not a client partition. '
    'In immutable 62d, Dirichlet.num_samples can still redraw with '
    'partition_distribution. Accepted Phase2A commit '
    '79da1f97d8a12fe97402750cc32c7b3e8f5cdf6e is now available as the realized-count '
    'dependency; root must integrate/verify it in the implementation candidate. '
    'Do not assume that accepted sampler behavior is already present in immutable '
    '62d or weaken the existing realized-loader/count cross-checks.'
)
metadata['available_sampler_dependency'] = {
    'commit': '79da1f97d8a12fe97402750cc32c7b3e8f5cdf6e',
    'status': 'Root-accepted Phase2A component; available dependency, not part of the inspected immutable source claim.',
    'acceptance_receipt': receipt(ROOT / 'phase2a-acceptance.json'),
    'integration_requirement': 'Retain the count_binding contract and verify the final merged sampler/loader/report agreement; no sampler edit is assigned to this revision.'
}

tests = {entry['id']: entry for entry in d['testacceptance']}
tests['FD-A08']['expected'] = (
    'Three microbatches cause two real SGD updates: y=1.99005, h_next=.49005. '
    'There are exactly two calls each to optimizer_strategy.on_optimizer_step, '
    'model_update_strategy.after_step, and callback on_train_step_end, and one '
    'history staging. No scheduler object is created or actually stepped in the '
    'supported no-scheduler mode; a strategy create_scheduler call returning None '
    'and a no-op lr_scheduler_strategy.step(None, context) epoch callback are '
    'distinct from optimizer-update notifications and must not be asserted to '
    'occur twice. A single successful step after a skipped one yields '
    'y=1.995,h_next=.495. All-empty/all-skipped attempts fail with no canonical '
    'state change and no accepted result; rerun starts without leaked gradients.'
)
tests['FD-A12']['setup'] = (
    original['testacceptance'][11]['setup'] + ' Additionally run a focused actual '
    'Server.run/--resume continuation fixture through the example start override '
    'and inherited startup, with server.random_seed=17, N=10, per_round=2 and '
    'ordered pool 1..10. Let F_i(w)=.5*(w-i)^2, x0=2, all h_i=0, alpha=.1, '
    'eta=.1 and two local SGD updates per selected client; use fixed positive '
    'realized counts (e.g. n_i=i, repeated identical local loss, batch_size=10, '
    'epochs=2), in both uniform and sample modes. Commit rounds selecting [9,7] '
    'then [5,6], save the real bundle, destroy/recreate server and clients, and '
    'resume via the real run entrypoint for at least rounds 3 and 4. Derive model '
    'and every client history expectation independently with the existing '
    'equations, compare uninterrupted/resumed runs, and observe all promised '
    'live/context RNG states at entry to inherited start before registration. '
    'Retain a separate fresh-run seed check and malformed RNG/model/bundle cases '
    'that assert prior pending state is unchanged. Calling _resume_from_checkpoint '
    'followed directly by selection is insufficient.'
)
tests['FD-A12']['expected'] = (
    original['testacceptance'][11]['expected'] + ' In the actual run/--resume '
    'fixture, the next selections are [5,3] then [9,5], never a restart at '
    '[9,7]. Later-round cloud models, every selected/inactive history, committed '
    'round, and subsequent RNG progression equal uninterrupted training in each '
    'weighting mode at the stated tolerances. Verify saved Python global, NumPy '
    'global and Torch default CPU RNGs as well as server.prng_state and '
    'context.state["prng_state"] before inherited start; use distinct saved '
    'Python-global/selection states so restoring only one cannot pass. A fresh '
    'run still selects [9,7] then [5,6] under seed17 and the hook does not '
    'otherwise alter fresh RNG state. Rejected whole-bundle/RNG validation '
    'preserves all live RNGs, both selection fields, model/history and prior '
    'pending snapshot. Successful handoff consumes pending state exactly once; '
    'a rejected handoff never starts registration/selection. These production '
    'continuation assertions remain required beyond the retained scratch probes.'
)
tests['FD-A13']['setup'] = (
    original['testacceptance'][12]['setup'] + ' Include or share FD-A12\'s '
    'seed17 actual Server.run/--resume continuation case through the shipped '
    'example wiring: exercise the restore -> inherited reseed -> local start '
    'handoff -> registration/selection ordering and later-round model/history '
    'equivalence. Do not substitute direct resume-method/selection calls or '
    'the scratch-only intercepted-start probe for this entrypoint acceptance.'
)
tests['FD-A13']['expected'] = (
    original['testacceptance'][12]['expected'] + ' The shared actual-entrypoint '
    'resume case must preserve saved live/context CPU RNG state before '
    'registration, select the later rounds expected by FD-A12, and produce '
    'the same cloud model and all-client histories as its uninterrupted control. '
    'Record the shared test identity/log once rather than claiming two separate '
    'executions. Retain the required local-socket and spawn smoke coverage. '
    'After any later accepted B/F28 supplement is integrated, rerun this '
    'checkpoint/start handshake plus fresh-run behavior and the accepted B '
    'startup/resume regressions on the combined candidate; no result from '
    'immutable 62d alone establishes that integration.'
)

server = next(e for e in d['files']['exact_owned_implementation'] if e['path'].endswith('/feddyn_server.py'))
server['change'] = (
    'New synchronous aggregation/history/dispatch/checkpoint subclass using existing '
    'hooks, including example-local start to apply validated pending CPU RNG state '
    'after inherited reseeding and before registration/selection; preserve fresh '
    'seeding and leave accepted B base.py unchanged.'
)


def changed_fields(a, b, prefix=''):
    if isinstance(a, dict) and isinstance(b, dict):
        result = []
        for key in sorted(a.keys() | b.keys()):
            path = prefix + '/' + key.replace('~', '~0').replace('/', '~1')
            if key not in a or key not in b:
                result.append(path)
            else:
                result.extend(changed_fields(a[key], b[key], path))
        return result
    if isinstance(a, list) and isinstance(b, list) and len(a) == len(b):
        return [p for i, (x, y) in enumerate(zip(a, b, strict=True))
                for p in changed_fields(x, y, prefix + '/' + str(i))]
    return [] if a == b else [prefix]


expected_changed = {
    '/verdict', '/stateflow/checkpoint/owner', '/stateflow/checkpoint/read',
    '/stateflow/checkpoint/scope', '/stateflow/checkpoint/startup_handoff',
    '/configuration_and_metadata/actual_available_metadata',
    '/configuration_and_metadata/available_sampler_dependency',
    '/files/exact_owned_implementation/4/change', '/testacceptance/7/expected',
    '/testacceptance/11/setup', '/testacceptance/11/expected',
    '/testacceptance/12/setup', '/testacceptance/12/expected'
}
changes = changed_fields(original, d)
assert set(changes) == expected_changed, changes
assert d['algorithm'] == original['algorithm']
assert d['oracle'] == original['oracle']
assert d['candidate_scalar_replay'] == original['candidate_scalar_replay']
assert d['migration'] == original['migration']
assert len(d['testacceptance']) == 15
assert [t['id'] for t in d['testacceptance']] == [t['id'] for t in original['testacceptance']]

verification = []
for version in ('313', '314'):
    path = SCRATCH / f'revision-startup-{version}.json'
    result = json.loads(path.read_text())
    assert result['corrected_later'] == [[5, 3], [9, 5]]
    assert result['fresh_seed_behavior_preserved']
    assert result['rejection_unchanged_rng_and_pending'] == ['selection', 'python', 'numpy', 'torch']
    verification.append({
        'command': f'zsh -lc \'PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/private/tmp/plato-refresh-worktrees/feddyn-design TMPDIR=/tmp/plato-phase2c-feddyn-design OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 MPLCONFIGDIR=/tmp/plato-phase2c-feddyn-design/revision-matplotlib /tmp/plato-phase2c-{version}/bin/python /tmp/plato-phase2c-feddyn-design/revision_startup_probe.py > /tmp/plato-phase2c-feddyn-design/revision-startup-{version}.json 2> /tmp/plato-phase2c-feddyn-design/revision-startup-{version}.stderr.log\'',
        'cwd': str(SNAPSHOT), 'exit_code': 0,
        'stdout': receipt(path),
        'stderr': receipt(SCRATCH / f'revision-startup-{version}.stderr.log'),
        'result': result
    })

d['revision'] = {
    'number': 2,
    'authorization': 'Root accepted FD-D-R01 and FD-D-L01 for this bounded author revision; root will obtain another fresh review before implementation.',
    'previous_design': receipt(original_path),
    'review_receipt': receipt(review_path),
    'review_verdict_preserved': 'REQUEST_CHANGES; immutable review was read, not edited or reinterpreted as acceptance.',
    'dispositions': [
        {'id': 'FD-D-R01', 'disposition': 'ADDRESSED_IN_REVISED_DESIGN_PENDING_FRESH_REVIEW',
         'change': 'Specified the example-local deferred RNG handoff at start after inherited reseeding, all promised live/context CPU RNG fields, preserved fresh seed behavior and transactional rejection; strengthened FD-A12/13 with real run/--resume later-round selection/model/history continuation.'},
        {'id': 'FD-D-L01', 'disposition': 'ADDRESSED_IN_REVISED_DESIGN_PENDING_FRESH_REVIEW',
         'change': 'FD-A08 names two optimizer_strategy.on_optimizer_step, model_update_strategy.after_step and on_train_step_end notifications; no real scheduler creation/steps, separate no-op epoch callback; unchanged scalar and zero-completed expectations.'}
    ],
    'bounded_changed_fields': changes + ['/revision'],
    'preserved': 'All algebra, original exact oracle/numerical records, parameter/weighting/state ownership contracts, API/history migration, 15 criterion IDs, existing tolerance/negative-path/socket/spawn requirements and all other fields compare unchanged except the enumerated bounded paths.',
    'review_probe_inputs': [receipt(Path('/tmp/plato-phase2c-feddyn-design-review') / name)
                            for name in ('review_probes.py', 'probes-313.json', 'probes-314.json', 'command-records.json')],
    'related_F28_handoff': {
        'root_probe': receipt(ROOT / 'server-resume-rng-probe.json'),
        'status_at_revision': 'OPEN_CONFIRMED generic defect; original B author owns a separate proposed narrow startup fix, still requiring fresh review. No unaccepted B code was inspected or used.',
        'disposition': 'Retain local pending-RNG/start contract on immutable62d; later accepted B integration must preserve that handshake and fresh-run behavior and pass combined regressions.'
    },
    'own_probe': receipt(SCRATCH / 'revision_startup_probe.py'),
    'own_verification': verification,
    'additional_source_receipts': [receipt(SNAPSHOT / name) for name in (
        'plato/servers/base.py',
        'plato/servers/strategies/client_selection/random_selection.py',
        'plato/trainers/composable.py',
        'plato/trainers/strategies/lr_scheduler.py')],
    'structural_verification': {
        'command': 'zsh -lc \'PYTHONDONTWRITEBYTECODE=1 /tmp/plato-phase2c-313/bin/python /tmp/plato-phase2c-feddyn-design/revise_design.py\'',
        'script': receipt(SCRATCH / 'revise_design.py'),
        'checks': 'Exact original/review SHA verified; JSON parses; precisely enumerated changed fields; all other original fields, algebra/oracle/migration and 15 test IDs preserved; startup probe assertions passed on CPU Python3.13/3.14; final output receipt written in owned scratch.',
        'status': 'PASSED',
        'initial_attempt': 'The first invocation used system python3 and exited 1 because its zip() lacks the strict keyword. It failed during in-memory field-diff validation before writing the ROOT artifact. Re-ran with the qualified Python3.13 interpreter; no production test failure is implied.'
    },
    'limitations': 'Scratch feasibility uses real inherited run and selector but intercepts base start before sockets, with an in-memory RNG-only bundle. It is not production FedDyn implementation, serialized full-checkpoint continuation, model/history training or socket acceptance. FD-A12/13 remain required and no review verdict/phase closure is changed.',
    'write_scope': 'Only ROOT phase2c-feddyn-design.json and own /tmp/plato-phase2c-feddyn-design scratch. No evolving training worktree reads, source/test edits, other report edits or agents.',
    'final_sha256_receipt': str(SCRATCH / 'revision-receipt.json')
}
assert set(changed_fields(original, d)) == expected_changed | {'/revision'}
destination = ROOT / 'phase2c-feddyn-design.json'
destination.write_text(json.dumps(d, indent=2, ensure_ascii=False) + '\n')
assert json.loads(destination.read_text()) == d
assert receipt(review_path)['sha256'] == REVIEW_SHA
final_receipt = dict(output=receipt(destination), original=receipt(original_path),
                     review=receipt(review_path), changed_fields=changes + ['/revision'])
(SCRATCH / 'revision-receipt.json').write_text(json.dumps(final_receipt, indent=2) + '\n')
print(json.dumps(final_receipt, indent=2))
