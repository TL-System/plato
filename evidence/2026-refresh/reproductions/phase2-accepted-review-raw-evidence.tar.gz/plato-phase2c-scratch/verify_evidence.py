"""Check JSON receipts against retained bytes; no mutations."""
import hashlib
import json
from pathlib import Path

root = Path("/private/tmp/plato-refresh-worktrees/training/evidence/2026-refresh")
checked = set()


def check(path, expected):
    path = Path(path)
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    assert actual == expected, (str(path), expected, actual)
    checked.add(str(path))


def inspect(value):
    if isinstance(value, list):
        for item in value:
            inspect(item)
    elif isinstance(value, dict):
        if "sha256" in value:
            if "path" in value and Path(value["path"]).is_file():
                check(value["path"], value["sha256"])
            elif "log" in value and isinstance(value["log"], str):
                check(value["log"], value["sha256"])
        if "stderr_sha256" in value:
            check(value["stderr"], value["stderr_sha256"])
        for item in value.values():
            inspect(item)


for name in ("phase2c-validation.json", "phase2c-scaffold-facts.json", "phase2c-feddyn-disposition.json"):
    inspect(json.loads((root / name).read_text()))
print(f"Verified {len(checked)} unique source/log/result/authority receipts.")
