"""Independent author-equation comparison; no production equation rewriting."""
import hashlib
import json
import tempfile
from pathlib import Path

import torch

from plato.trainers.strategies.algorithms.feddyn_strategy import FedDynLossStrategy
from plato.trainers.strategies.base import TrainingContext
from tests.integration.utils import build_minimal_config, configure_environment

records = []
with tempfile.TemporaryDirectory(prefix="plato-phase2c-feddyn-disposition-") as directory:
    with configure_environment(build_minimal_config(), runtime_root=Path(directory)):
        for adaptive, labels in ((False, [0, 0]), (True, [0, 0]), (True, [0, 1]), (True, [1, 1])):
            model = torch.nn.Linear(1, 1, bias=False).double()
            model.weight.data.fill_(2.)
            context = TrainingContext()
            context.model = model
            strategy = FedDynLossStrategy(
                alpha=0.1, adaptive_alpha=adaptive,
                base_loss_fn=lambda output, target: output.sum() * 0,
            )
            strategy.setup(context)
            batch_labels = torch.tensor(labels)
            loss = strategy.compute_loss(model(torch.ones(2, 1).double()), batch_labels, context)
            loss.backward()
            gradient = model.weight.grad.item()
            torch.optim.SGD(model.parameters(), lr=0.1).step()
            # Author's actual scalar optimizer contract, independent of our
            # strategy: linear alpha*(-global+history), unshifted decay alpha.
            reference = torch.nn.Parameter(torch.tensor([2.], dtype=torch.float64))
            author_optimizer = torch.optim.SGD([reference], lr=0.1, weight_decay=0.1)
            author_linear_loss = 0.1 * (reference * torch.tensor([-2.])).sum()
            author_linear_loss.backward()
            author_optimizer.step()
            records.append({
                "adaptive_alpha": adaptive, "labels": labels, "samples": 2,
                "actual_alpha": strategy._get_alpha_coefficient(batch_labels, context).item(),
                "actual_regularizer_gradient": gradient,
                "actual_next_weight": model.weight.item(),
                "author_next_weight": reference.item(),
                "author_effective_regularizer_gradient": (2 - reference.item()) / 0.1,
            })
source = Path("/tmp/plato-phase2c-scratch/feddyn-author-utils_general.py")
report = {
    "finding_id": "2C-11", "status": "OPEN_INTERNAL_RESEARCH_DESIGN_DISPOSITION",
    "scope": "FedDyn shifted quadratic plus linear global penalty, and label-ID-based adaptive alpha",
    "primary_source": "https://raw.githubusercontent.com/alpemreacar/FedDyn/master/utils_general.py",
    "retained_source": str(source), "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "source_lines": {"optimizer_decay": 190, "linear_regularizer": 219},
    "initial_weight": 2.0, "global_weight": 2.0, "history": 0.0,
    "alpha": 0.1, "lr": 0.1, "records": records,
    "current_equations_preserved": True,
    "bounded_fix_applied": "All-zero labels now reach the existing zero-weight fallback, avoiding 0/0 NaN. Nonzero behavior and the objective remain unchanged.",
    "requested_root_disposition": "Independent primary-source design and review before changing the equation or replacing label-based alpha with actual client sample weighting; not waived or classified as an external prerequisite.",
}
print(json.dumps(report, indent=2))
