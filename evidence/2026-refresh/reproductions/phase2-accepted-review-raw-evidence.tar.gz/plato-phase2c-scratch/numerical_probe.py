"""Retained numerical audit probes; no network/downloads or external mutations."""
import copy
import json
import math
import os
import tempfile
from pathlib import Path

import torch
from torch.utils.data import TensorDataset

from plato.trainers.composable import ComposableTrainer
from plato.trainers.strategies.algorithms.feddyn_strategy import FedDynLossStrategy
from plato.trainers.strategies.algorithms.fedmos_strategy import FedMosOptimizer
from plato.trainers.strategies.algorithms.fedprox_strategy import FedProxLossStrategy
from plato.trainers.strategies.base import TrainingContext
from plato.trainers.strategies.training_step import (
    GradientAccumulationStepStrategy, ValidateBeforeStepStrategy,
)
from tests.integration.utils import build_minimal_config, configure_environment

result = {"python": os.sys.version, "torch": torch.__version__, "mode": os.environ.get("AUDIT_MODE")}
for sizes, window in (([2, 2, 1], 2), ([2, 1], 4), ([2, 2], 2)):
    torch.manual_seed(12)
    model = torch.nn.Linear(2, 1).double()
    reference = copy.deepcopy(model)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.1)
    ref_optimizer = torch.optim.SGD(reference.parameters(), lr=0.1)
    context = TrainingContext()
    context.model = model
    strategy = GradientAccumulationStepStrategy(window)
    strategy.setup(context)
    data = [(torch.randn(n, 2).double(), torch.randn(n, 1).double()) for n in sizes]
    for start in range(0, len(data), window):
        chunk = data[start:start+window]
        ref_optimizer.zero_grad()
        loss = sum(torch.nn.functional.mse_loss(reference(x), y) for x, y in chunk) / len(chunk)
        loss.backward()
        ref_optimizer.step()
    flags = []
    for x, y in data:
        strategy.training_step(model, optimizer, x, y, torch.nn.functional.mse_loss, context)
        flags.append(context.state.get("optimizer_step_completed"))
    if hasattr(strategy, "finalize"):
        strategy.finalize(model, optimizer, context)
    result[f"accumulation_{sizes}_{window}"] = {
        "max_parameter_error": max((a-b).abs().max().item() for a,b in zip(model.parameters(), reference.parameters())),
        "microbatch_flags": flags,
        "actual_parameters": [p.tolist() for p in model.parameters()],
        "reference_parameters": [p.tolist() for p in reference.parameters()],
    }

for mu in (0., 0.1):
    model = torch.nn.Linear(2, 1, bias=False).double()
    context = TrainingContext()
    context.model = model
    strategy = FedProxLossStrategy(mu, base_loss_fn=torch.nn.functional.mse_loss)
    strategy.setup(context)
    x = torch.tensor([[1., 2.]], dtype=torch.double)
    y = torch.zeros(1, 1).double()
    base_grad = torch.autograd.grad(torch.nn.functional.mse_loss(model(x), y), model.weight)[0]
    grad = torch.autograd.grad(strategy.compute_loss(model(x), y, context), model.weight)[0]
    result[f"fedprox_mu_{mu}"] = {"finite": torch.isfinite(grad).all().item(),
                                  "gradient": grad.tolist(), "base_gradient": base_grad.tolist()}

with tempfile.TemporaryDirectory(prefix="plato-phase2c-probe-runtime-") as directory:
    with configure_environment(build_minimal_config(), runtime_root=Path(directory)):
        model = torch.nn.Linear(1, 1, bias=False).double()
        model.weight.data.fill_(2.)
        context = TrainingContext()
        context.model = model
        strategy = FedDynLossStrategy(alpha=0.1, adaptive_alpha=False,
                                     base_loss_fn=lambda output, target: output.sum()*0)
        strategy.setup(context)
        value = strategy.compute_loss(model(torch.ones(1,1).double()), torch.zeros(1).long(), context)
        grad = torch.autograd.grad(value, model.weight)[0].item()
        # Author's implementation: alpha*(-global+history) linear term plus
        # SGD weight_decay=alpha, hence alpha*(w-global+history).
        result["feddyn_research_disposition_pending"] = {
            "weight": 2., "global_weight": 2., "history": 0., "alpha": 0.1,
            "actual_regularizer_gradient": grad,
            "primary_author_reference_gradient": 0.1 * (2.-2.+0.),
            "source": "https://raw.githubusercontent.com/alpemreacar/FedDyn/master/utils_general.py",
            "source_lines": [190, 219], "equations_unchanged": True,
        }


from plato.trainers.strategies.algorithms.scaffold_strategy import SCAFFOLDUpdateStrategy
from plato.trainers.tracking import LossTracker
for gradients in ([0.], [3., 1.]):
    with tempfile.TemporaryDirectory(prefix="plato-phase2c-equations-") as directory:
        with configure_environment(build_minimal_config(), runtime_root=Path(directory)):
            model = torch.nn.Linear(1, 1, bias=False).double()
            model.weight.data.fill_(1.)
            context = TrainingContext()
            context.model, context.client_id = model, 1
            context.state["server_control_variate"] = {"weight": torch.tensor([[2.]], dtype=torch.double)}
            context.state["learning_rate"] = .1  # Isolates the historical math defect.
            optimizer = torch.optim.SGD(model.parameters(), lr=.1)
            context.state["optimizer"] = optimizer
            strategy = SCAFFOLDUpdateStrategy(save_path=directory + "/")
            strategy.setup(context)
            strategy.client_control_variate = {"weight": torch.tensor([[1.]], dtype=torch.double)}
            strategy.on_train_start(context)
            strategy.before_step(context)
            for gradient in gradients:
                model.weight.grad = torch.full_like(model.weight, gradient)
                optimizer.step()
                context.state["optimizer_step_completed"] = True
                strategy.after_step(context)
            strategy.on_train_end(context)
            result[f"scaffold_gradients_{gradients}"] = {
                "actual_y": model.weight.item(),
                "actual_ci": strategy.client_control_variate["weight"].item(),
                "actual_delta": strategy.get_update_payload(context)["control_variate_delta"]["weight"].item(),
                "reference_y": .9 if len(gradients)==1 else .4,
                "reference_ci": sum(gradients)/len(gradients),
                "completed_updates": strategy.local_steps,
            }
            if hasattr(strategy, "on_train_cleanup"):
                strategy.on_train_cleanup(context, successful=True)
tracker = LossTracker()
parameter = torch.nn.Parameter(torch.tensor(2.))
for _ in range(16):
    loss = parameter.square()
    tracker.update(loss)
    loss.backward()
def graph_nodes(tensor):
    pending, visited = [tensor.grad_fn], set()
    while pending:
        node = pending.pop()
        if node is None or node in visited:
            continue
        visited.add(node)
        pending.extend(child for child, _ in node.next_functions)
    return len(visited)
result["metrics_graph_retention"] = {"batches": 16, "average": tracker.average,
                                    "retained_graph_nodes": graph_nodes(tracker.total_loss)}

class Twin(torch.nn.Module):
    def __init__(self, a, b):
        super().__init__()
        self.first = torch.nn.Parameter(torch.tensor([a]))
        self.second = torch.nn.Parameter(torch.tensor([b]))

model, global_model = Twin(2., 3.), Twin(10., 20.)
optimizer = FedMosOptimizer(model.parameters(), lr=0.1, a=0.9, mu=0.5)
for parameter in model.parameters():
    parameter.grad = torch.ones_like(parameter)
optimizer.update_momentum()
optimizer.step(global_model_params=global_model)
result["fedmos_same_shape_association"] = {
    "actual": [p.item() for p in model.parameters()],
    "same_legacy_equation_with_corresponding_parameters": [5.95, 11.45],
    "equations_unchanged": True,
}

model = torch.nn.Linear(1, 1, bias=False)
model.weight.data.fill_(1.)
context = TrainingContext()
context.model = model
optimizer = torch.optim.SGD(model.parameters(), lr=0.1)
actual_updates = []
optimizer.register_step_post_hook(lambda *args: actual_updates.append(1))
wrapped = ValidateBeforeStepStrategy(base_strategy=GradientAccumulationStepStrategy(2))
wrapped.setup(context)
for _ in range(2):
    wrapped.training_step(model, optimizer, torch.ones(1, 1), torch.zeros(1, 1),
                          torch.nn.functional.mse_loss, context)
result["validation_wrapper_ignores_base_pending"] = {
    "actual_updates": len(actual_updates), "expected_accumulated_updates": 1,
    "actual_weight": model.weight.item(), "expected_weight": 0.8,
}

if os.environ.get("AUDIT_MODE") == "green" and torch.backends.mps.is_available():
    with tempfile.TemporaryDirectory(prefix="plato-phase2c-mps-runtime-") as directory:
        with configure_environment(build_minimal_config(), runtime_root=Path(directory)):
            trainer = ComposableTrainer(model=torch.nn.Linear(2, 2))
            trainer.device = trainer.context.device = torch.device("mps")
            initial = {k: v.clone() for k,v in trainer.model.state_dict().items()}
            identities = [id(p) for p in trainer.model.parameters()]
            data = TensorDataset(torch.eye(2).repeat(2,1), torch.tensor([0,1,0,1]))
            trainer.train_model({"epochs": 1, "batch_size": 2, "run_id": "mps"}, data, [0,1,2,3])
            torch.mps.synchronize()
            result["native_mps"] = {
                "actual_device": str(next(trainer.model.parameters()).device),
                "parameter_identity_preserved": identities == [id(p) for p in trainer.model.parameters()],
                "optimizer_references_model": all(any(p is candidate for candidate in trainer.model.parameters())
                                                  for group in trainer.optimizer.param_groups for p in group["params"]),
                "parameter_changed": any(not torch.equal(v.cpu(), initial[k]) for k,v in trainer.model.state_dict().items()),
                "finite": all(torch.isfinite(p).all().item() for p in trainer.model.parameters()),
            }
else:
    result["native_mps"] = {"executed": False, "available": torch.backends.mps.is_available()}
def json_finite(value):
    if isinstance(value, dict):
        return {key: json_finite(item) for key, item in value.items()}
    if isinstance(value, list):
        return [json_finite(item) for item in value]
    if isinstance(value, float) and not math.isfinite(value):
        return str(value)
    return value

print(json.dumps(json_finite(result), indent=2, allow_nan=False))
