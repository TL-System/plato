"""Assemble review receipts only after both exact implementation runs finish."""
import hashlib
import json
import math
import re
import subprocess
import tomllib
from pathlib import Path

root = Path("/private/tmp/plato-refresh-worktrees/training")
external = Path("/Users/bli/Playground/plato/evidence/2026-refresh")
scratch = Path("/tmp/plato-phase2c-scratch")
evidence = root / "evidence/2026-refresh"
initial = "fda60becedfa6236c11d415b87a868b52789a41e"
premerge = "c1e23fa7c5e25240b3d18461a8d63fe541c183b1"
merge = "4f826a79f8c1ee1f6219a55527c4c7ee18cd321d"
accepted_b = "00eeb9dcdd2b513e64db9408969356037e09bb8e"
implementation = "0dc34dd1d79d90071a0babfa6aa89f33d72a976f"


def git(command):
    return subprocess.check_output(["zsh", "-lc", command], cwd=root)


def digest(content):
    return hashlib.sha256(content).hexdigest()


def artifact(path):
    path = Path(path)
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": digest(path.read_bytes())}


def read_json(path):
    path = Path(path)
    text = path.read_text()
    if path.name == "numerical-red.json":
        # The original captured stdout retains two INFO lines before its JSON.
        # Preserve those raw bytes/hash; extract only the structured probe body.
        text = text[text.index("\n{") + 1:]
    return json.loads(text)


def write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")


assert git("git rev-parse HEAD").decode().strip() == implementation
assert not git("git status --porcelain --untracked-files=no").decode().strip()
commands = [read_json(scratch / f"qualified-validation-{version}.json") for version in ("313", "314")]
for command in commands:
    assert command["implementation_commit"] == implementation
    assert command["exit_code"] == 0
    assert command["counts"]["passed"] == 468
    assert not command["counts"].get("skipped")
auxiliary = {version: read_json(scratch / f"qualified-auxiliary-{version}.json") for version in ("313", "314")}
assert all(record["exit_code"] == 0 and record["implementation_commit"] == implementation for records in auxiliary.values() for record in records)
for version in ("313", "314"):
    assert read_json(scratch / f"qualified-types-{version}.log") == []

authorities = [
    (evidence / "plan.md", "edb9a58cc7915a940854f16d5029fe97434703bf2f75eca0dcb96de2d0f0eb15"),
    (evidence / "plan-addendum.json", "5b51b0fb7ed6f68d9fce7176335b3e7be5e5f178a2788590912aa2396a487709"),
    (evidence / "plan-addendum-acceptance.json", "5f5d5a8e22e14072b5d031c19a27be14bda9bdbc2a157d14af78845daac6c56b"),
    (external / "phase2b-acceptance.json", "3be220078302a05189c07c32220a86e966ff919bc4ef11e5d342a6c39135396d"),
    (external / "phase2b-review-3.json", "83eaf2c44ffb1316e9d6643e23c3ea9b977d5b083bf4427e86a75dcac7720fd6"),
    (external / "phase2c-scaffold-design.json", "f323f3aa9d824df44a1043b2d6aff9c8a963c42964f6e6685108c59b25fc3a89"),
    (external / "phase2c-scaffold-design-review.json", "8eb83f21091827d03534db1b8c4e23a6f239b5df4f82363b4c9ead5a60b3258d"),
    (external / "phase2c-scaffold-acceptance.json", "40b202708a4cfdbe6f299e75249c1a19921e410ec4ab7b5e3c6323f536ca8d37"),
]
authority_receipts = []
for path, expected in authorities:
    receipt = artifact(path)
    assert receipt["sha256"] == expected, receipt
    receipt["expected_sha256"] = expected
    receipt["identity_matches"] = True
    authority_receipts.append(receipt)
root_probes = [artifact(external / name) for name in ("dp-reuse-probe.json", "dp-step-probe.json", "trainer-lifecycle-probes.json", "scaffold-equation-probe.json")]

c_paths = sorted(set(git(f"git diff --name-only {initial} {premerge}").decode().splitlines() + git(f"git diff --name-only {merge} {implementation}").decode().splitlines()))
source_receipts = [{**artifact(root / path), "relative_path": path} for path in c_paths]
diff = git(f"git diff --binary {initial} {premerge}") + git(f"git diff --binary {merge} {implementation}")
(scratch / "implementation-owned.diff").write_bytes(diff)
startup_paths = ["tests/integration/test_event_loop_startup.py", "tests/integration/startup_harness.py", "tests/integration/startup_probe.py"]
startup_sources = []
for path in startup_paths:
    current = (root / path).read_bytes()
    accepted = git(f"git show {accepted_b}:{path}")
    assert current == accepted
    startup_sources.append({"path": path, "accepted_b_sha256": digest(accepted), "candidate_sha256": digest(current), "unchanged": True})
# The provided-filename decoder belongs to B; C's writers pass its exact safe path.
assert (root / "plato/clients/composable.py").read_bytes() == git(f"git show {accepted_b}:plato/clients/composable.py")


def socket_error(result):
    events = result["events"]
    baseline = next(e["weights"] for e in events if e["event"] == "server_baseline")
    final = next(e["weights"] for e in events if e["event"] == "server_aggregate")
    received = [e for e in events if e["event"] == "server_received"]
    trained = [e for e in events if e["event"] == "client_trained"]
    assert sorted(e["samples"] for e in received) == [2, 6]
    assert {e["client_id"] for e in received} == {1, 2}
    assert len({e["pid"] for e in trained}) == 2
    assert {e["device"] for e in trained} == {"cpu"}
    errors = []

    def flattened(value):
        if isinstance(value, list):
            return [x for item in value for x in flattened(item)]
        return [value]

    for key in baseline:
        base = flattened(baseline[key])
        actual = flattened(final[key])
        first, second = [flattened(e["weights"][key]) for e in received]
        a, b = [e["samples"] for e in received]
        expected = [x + (a * (y - x) + b * (z - x)) / 8 for x, y, z in zip(base, first, second)]
        errors.extend(abs(x - y) for x, y in zip(actual, expected))
    return {"actual_client_ids": sorted(e["client_id"] for e in received), "samples": sorted(e["samples"] for e in received), "trainer_processes": sorted(e["pid"] for e in trained), "devices": [e["device"] for e in trained], "independent_sample_weighted_max_abs_error": max(errors), "uniform_client_weights_not_used": True}


startup_results, scaffold_results = {}, {}
for version in ("313", "314"):
    runtime = Path(f"/tmp/plato-phase2c-qualified-{version}")
    # Pytest's '*current' symlinks point at cases already retained numerically.
    paths = sorted(path for path in runtime.glob("test_*/**/result.json") if not path.relative_to(runtime).parts[0].endswith("current"))
    startup = [(path, read_json(path)) for path in paths if "case" in read_json(path)]
    assert len(startup) == 48, len(startup)
    assert all(not result["survivors"] for _, result in startup)
    natural = [(path, result) for path, result in startup if not result["forced"]]
    forced = [(path, result) for path, result in startup if result["forced"]]
    assert len(natural) == 43 and len(forced) == 5
    assert all(not result["timed_out"] for _, result in natural)
    socket_path, socket = next((path, result) for path, result in startup if result["case"] == "socket_round")
    startup_results[version] = {"actual_cases": len(startup), "natural_cases": len(natural), "expected_forced_containment_cases": len(forced), "survivors": [], "all_source_unchanged_from_accepted_b": True, "socket": {**artifact(socket_path), **socket_error(socket), "natural_returncode": socket["returncode"], "forced": socket["forced"], "elapsed_seconds": socket["elapsed"]}, "results": [artifact(path) for path, _ in startup]}
    scaffold = [(path, read_json(path)) for path in paths if read_json(path).get("spawn") is True and "rounds" in read_json(path)]
    assert len(scaffold) == 1
    path, actual = scaffold[0]
    scaffold_results[version] = {"artifact": artifact(path), "actual_spawn_result": actual}

scaffold_config = "examples/customized_client_training/scaffold/scaffold_MNIST_lenet5.toml"
assert tomllib.loads((root / scaffold_config).read_text()) == tomllib.loads(git(f"git show {initial}:{scaffold_config}").decode())
numerical = {v: read_json(scratch / f"qualified-numerical-{v}.log") for v in ("313", "314")}
ssl = {v: read_json(scratch / f"qualified-ssl-{v}.log") for v in ("313", "314")}
history_runs = [read_json(scratch / f"{label}-validation-{version}.json") for label in ("final", "candidate") for version in ("313", "314")]

main = {
    "schema_version": 1, "phase": "2C", "date": "2026-10-03",
    "status": "INTERMEDIATE_CLEAN_IMPLEMENTATION_HANDOFF_PENDING_INTERNAL_FEDDyn_DESIGN_DISPOSITION_AND_FRESH_REVIEWS",
    "claim": "Owned fixes implemented and qualified; not Phase 2/project completion or independent acceptance. F27 code/test contracts are implemented; mandatory standalone prose remains root-assigned and must be reviewed before closure. 2C-11 is an internal research-design finding, not waived or treated as an external prerequisite.",
    "identities": {"initial_base": initial, "branch": "maintenance/2026-phase2-training", "premerge_c_commit": premerge, "accepted_b_commit": accepted_b, "accepted_b_tree": "39b6b554e833aeb5e8916e40fbc38a2fa46f6671", "dependency_merge_commit": merge, "dependency_merge_parents": git(f"git show -s --format=%P {merge}").decode().strip().split(), "dependency_merge_tree": git(f"git show -s --format=%T {merge}").decode().strip(), "implementation_commit": implementation, "implementation_tree": git(f"git rev-parse {implementation}^{{tree}}").decode().strip(), "evidence_body_commit": None, "evidence_commit_receipt": "The next receipt commit records the exact body commit; resolve the final receipt with git log -1 --format=%H -- evidence/2026-refresh/phase2c-validation.json. A commit cannot embed its own hash.", "implementation_owned_diff": artifact(scratch / "implementation-owned.diff"), "implementation_commits": git(f"git log --format='%H %s' {accepted_b}..{implementation}").decode().splitlines()},
    "authorization": authority_receipts, "root_original_probe_receipts": root_probes,
    "ownership": {"primary": ["nonreserved plato/trainers/**", "plato/algorithms/**", "plato/models/**", "focused tests", "plato/utils/checkpoint_paths.py"], "shared_after_exact_b_merge": ["plato/clients/base.py", "plato/clients/strategies/defaults.py", "plato/servers/base.py", "plato/servers/strategies/aggregation/port.py", "examples/async/port/port_server.py"], "provided_filename_reader": "plato/clients/composable.py unchanged from accepted B; supplied filename decoded as supplied", "excluded": ["MLX", "HuggingFace/PEFT/LoRA", "LeRobot/SmolVLA", "Nanochat", "reserved adapter tests", "vendor submodules", "ViT repair/retirements", "other utils/processors/serialization/mpc/config/datasources/samplers/metadata/CI/conftest", "other worktrees/environments", "push/merge to root/PR mutations"], "delegation": "None", "shell": "Every shell/subprocess shell invocation uses zsh -lc"},
    "environment": {"uv": "0.12.22 (70fe1196a, 2026-10-01, aarch64-apple-darwin)", "metadata": {v: read_json(scratch / f"environment-{v}.json") for v in ("313", "314", "ssl", "ssl314")}, "provisioning": [{"command": f"UV_PROJECT_ENVIRONMENT=/tmp/plato-phase2c-{env} uv sync --locked --group dev --python {python}" + (" --extra ssl" if env.startswith("ssl") else ""), "exit_code": 0, "log": artifact(Path("/tmp") / filename)} for env, python, filename in (("313", "3.13.16", "plato-phase2c-sync313.log"), ("314", "3.14.8", "plato-phase2c-sync314.log"), ("ssl", "3.13.16", "plato-phase2c-syncssl.log"), ("ssl314", "3.14.8", "plato-phase2c-sync-ssl314.log"))], "runtime_minimum": "Repository metadata already requires >=3.13; no metadata edits were authorized or needed here.", "isolated_environments_only": True},
    "validation": {"final_combined": commands, "final_auxiliary": auxiliary, "startup": startup_results, "startup_sources": startup_sources, "scope": "Affected C+B trainers/algorithms/models/clients/servers/callbacks, smoke configs, all48 startup cases, SCAFFOLD pipeline and checkpoint writer/reader agreement. This is the full relevant selection, not the whole mandatory test profile.", "excluded_reserved_modules": ["tests/trainers/test_huggingface_trainer.py", "tests/trainers/test_lerobot_trainer.py", "tests/trainers/test_nanochat_trainer.py", "tests/models/test_smolvla_model.py"], "guard_integrity": "DP regressions extend existing test_dp_data_loader_strategy.py; precise absence allowance/conftest/test-profile mandatory counts untouched. No new DP module or skip allowance. No blanket warning filters.", "earlier_runs": history_runs, "earlier_run_failure_disposition": "The first postmerge combined runs each had 5 failures/455 passes: own SCAFFOLD negative fixtures omitted update.report, so accepted B report validation failed before the intended control check. Fixtures now supply real reports with counts2/6; B validators/startup helpers were not weakened. The next exact96c6bd90 runs each passed463; final0dc34dd1 adds five meaningful boundary cases.", "focused_boundary_green": [artifact(Path(f"/tmp/plato-phase2c-last-boundary-green{v}-dp.log")) for v in ("313", "314")], "focused_boundary_summary": "57 passed on each version, 19 warnings retained", "ruff_import_policy": "Repository-wide . --select I: PASS on both interpreters", "scoped_ty": "38 changed source files including shared codec/runtime: empty JSON diagnostic lists on3.13 and3.14; the classified404 project baseline is not represented as globally clean", "scoped_ty_paths": read_json(scratch / "type-all-source-files.json")},
    "red_green": {"original_baseline_commands": read_json(scratch / "baseline-red-commands.json"), "original_baseline_summary": "86 failed,7 passed,8 warnings on scoped93 regressions; numerical-red separately executed successfully and recorded wrong outputs/NaNs rather than asserting green behavior", "original_baseline": initial, "original_numeric_red": read_json(scratch / "numerical-red.json"), "numeric_red_line_reference_correction": "The older numerical-red source_lines179/208 were inaccurate prose metadata; authoritative retained author source and disposition probe use actual190/219. No numerical result was changed.", "dependency_and_late_boundary_replays": read_json(scratch / "dependency-red-commands.json"), "latest_identity_red_artifacts": {"source_commit": "96c6bd90f3c49eb077d79a99454babc309a32c65", "APFL": artifact(scratch / "apfl-optimizer-owner-red.log"), "AMP_fused_CPU": artifact(scratch / "amp-fused-red.log"), "SSL_head_and_frozen_buffers": artifact(scratch / "ssl-state-red.log"), "SSL_red_source_commit": "3755330dcd4eab5feaa83a6c9dcc96ed14b67bee"}, "numeric_green": numerical, "actual_optional_SSL": ssl},
    "root_findings": [
        {"id": "F07", "disposition": "Single shared collision-resistant logical-component codec; all owned/default/worker/history/personal/GAN/split and handed runtime/PORT writers/readers agree. root-contained explicit paths and separately checked sidecars. Ordinary names/layouts preserved; slash underscore names distinct. Exact B merge before shared edits.", "tests": ["tests/trainers/test_checkpoint_path_contract.py", "tests/integration/test_checkpoint_runtime_agreement.py", "tests/trainers/test_gan_runtime.py", "tests/trainers/test_personalized_state_ownership.py"]},
        {"id": "F08", "disposition": "Equal weighting of mean microbatch losses preserves full-window behavior; partial window uses its actual microbatch count. Independent float64 reference including small/final batches, exactly once tail/idempotence, divisible no extra update, hooks/schedulers count completed optimizations, exception/reset cleanup.", "tests": ["tests/trainers/test_training_update_contract.py", "tests/trainers/test_scaffold_strategy.py"]},
        {"id": "F14", "disposition": "Real timm CosineLRScheduler first epoch updates1..10, epoch offsets1,2; local round restart and explicit global/resume offsets; accumulated tail counts only completed updates; LG second pass follows real update dispatcher.", "tests": ["tests/trainers/test_training_update_contract.py"]},
        {"id": "F20", "disposition": "Accepted legacy UNSQUARED L2/L1 objective remains. torch.linalg.vector_norm finite at origin, mu0 exact base, finite nonnegative mu and norm validation. Reference TOML activates core trainer.type=fedprox with SGD and clients.proximal_term_penalty_constant=.1, not FedAvg.", "tests": ["tests/trainers/test_training_update_contract.py", "tests/integration/test_smoke_configs.py"]},
        {"id": "F21", "disposition": "Supported reusable Opacus wrapper cleanup, plain exchange/save/load keys including live epoch snapshots, consecutive changed-parameter runs and exception cleanup. Successful child accountant state returns via supported state_dict/load_state_dict; per-logical-client ledgers retained in parent memory. No global federated privacy guarantee.", "tests": ["tests/trainers/test_dp_data_loader_strategy.py"]},
        {"id": "F22", "disposition": "BatchMemoryManager preserves physical splitting and sampling. DPOptimizer _is_last_step_skipped suppresses false after-step completion; real optimizer/accountant4 actual updates (not8 physical callbacks), fixed-sample/no-noise clipped reference equivalent across logical/physical batching.", "tests": ["tests/trainers/test_dp_data_loader_strategy.py"]},
        {"id": "F23", "disposition": "Logical-client path and in-memory state ownership for Ditto/APFL/FedDyn/SCAFFOLD/FedALA; same-client reload/custom save_path retained, client0 never adopted. Successful spawned private state returns to parent. Returning APFL momentum now matches dedicated trainer; SSL head and DP ledgers also isolated.", "tests": ["tests/trainers/test_personalized_state_ownership.py", "tests/trainers/test_personalized_worker_state.py", "tests/trainers/test_apfl_optimizer_ownership.py", "tests/trainers/test_ssl_personalized_state.py", "tests/integration/test_scaffold_round_flow.py"]},
        {"id": "F24", "disposition": "FedProx snapshots received global model each run, held fixed within run; first proximal loss zero/finite in first and second runs.", "tests": ["tests/trainers/test_training_update_contract.py"]},
        {"id": "F25", "disposition": "Fresh public split evaluation needs no training-installed context; empty partition returns0 consistently. Training context and feature/gradient autograd paths retained.", "tests": ["tests/trainers/test_split_learning_testing_strategy.py"]},
        {"id": "F26", "disposition": "Urgent reader uses matching deserialize_tree, numerical timestamp then epoch ordering, same client only, strict finish_time<cutoff; injected architecture copied and current model/device/mode preserved. No eligible snapshot raises ValueError. Actual epochs9/10 and DP/GAN writers round-trip.", "tests": ["tests/trainers/test_checkpoint_path_contract.py", "tests/trainers/test_gan_runtime.py", "tests/trainers/test_dp_data_loader_strategy.py"]},
        {"id": "F27", "disposition": "Accepted A01-A10 code/test contracts implemented; independent acceptance not claimed. Standalone prose is still mandatory root/Astra writing work, and F27 remains open until implementation/writing reviews and integrated phasegate.", "facts": "evidence/2026-refresh/phase2c-scaffold-facts.json"},
    ],
    "additional_findings": [
        {"id": "2C-01", "subject": "FedMos same-shaped parameter association", "result": "Fixed identity-based pairing; retained legacy equation gives5.95/11.45 instead of5.95/6.45."},
        {"id": "2C-02", "subject": "Loss tracker retains autograd graphs", "result": "Detached metrics;16 batches retain0 rather than49 graph nodes; weighted numerical average unchanged."},
        {"id": "2C-03", "subject": "Gradient clipping after optimizer step", "result": "Public prehook clips before actual update including final accumulation; independent parameter/norm reference."},
        {"id": "2C-04", "subject": "Validation wrapper bypasses selected step strategy", "result": "Delegates accumulation/AMP and checks gradients at actual pre-step incltail;2microbatches now1 correct update rather than2."},
        {"id": "2C-05", "subject": "DCGAN public model is not nn.Module", "result": "Registered generator/discriminator modules, inherited mode/device APIs and actual training changes both nets."},
        {"id": "2C-06", "subject": "GAN exchange aliases/moves source and mishandles bool buffers", "result": "Owned CPU clones; integer/bool buffer delta semantics match ordinary Torch contracts."},
        {"id": "2C-07", "subject": "GAN auxiliary/worker/time checkpoints disagree", "result": "Explicit .safetensors combined tree with history for workers/urgent; ordinary .pth pairs/historical Torch-paired .safetensors supported only in existing GAN path."},
        {"id": "2C-08", "subject": "SSL instance constructor, empty data and KNN sampler mismatch", "result": "Existing model instances preserved; explicit empty dataset honored; full train reference and test sampler applied to proper partitions; emptytest0 and missingreference useful error."},
        {"id": "2C-09", "subject": "Personalization overwrites trainability flags", "result": "FedPer/FedRep/LG restore actual previous flags including frozen params and exceptions."},
        {"id": "2C-10", "subject": "LG multi-update callbacks and scheduler", "result": "Two primary updates dispatch separately; independent actual LR/parameter reference verifies4 real updates."},
        {"id": "2C-11", "subject": "FedDyn mathematical objective and label-based alpha", "result": "OPEN_INTERNAL_RESEARCH_DESIGN_DISPOSITION. See separate primary-source scalar comparison; no arbitrary equation rewrite or waiver."},
        {"id": "2C-12", "subject": "Personalization child state lost in parent", "result": "Actual four spawned algorithm comparisons red4fail -> green4pass, dedicated direct parameter/private optimizer/state reference."},
        {"id": "2C-13", "subject": "APFL historical NumPy scalar alpha", "result": "Scoped weights_only allowlist for NumPy scalar/dtype aliases, new alpha saved as primitivefloat. Trustedhistorical reader only."},
        {"id": "2C-14", "subject": "AMP overflow reported as optimizer update", "result": "Actual GradScaler skip observed; public posthook plus scale-backoff handles fused CPU SGD internal skip. Both CPU fused/nonfused inf leaveweight1 and completionFalse; no CUDA claim."},
        {"id": "2C-15", "subject": "GAN FID sampling, tail and rectangular pad", "result": "Real partition selected; generated batches match actual tail; rectangular padding correct; >=2covariancesamples required. Scalar covariance reference uses controlled feature extractor, not a pretrained FID quality benchmark."},
        {"id": "2C-16", "subject": "FedDyn all-zero labels produce NaN", "result": "Bounded existing zero-weight fallback restored, finite gradient-.2; nonzero alpha behavior/equation intentionally preserved pending2C-11."},
        {"id": "2C-17", "subject": "DP successful child accountant discarded", "result": "Real3workerrounds logical1/1/2 return4/8/4 accountant steps; return1 restores8; plain model keys/nohooks. No durable/global privacy guarantee."},
        {"id": "2C-18", "subject": "Long logical checkpoint names exceed sidecar filename limit", "result": "Shared tuple digest reserves4bytes for history; actual long ordinary/slash/defaultsave/load pass."},
        {"id": "2C-19", "subject": "SSL private head lost across workers/client identity", "result": "Separate canonical head tree and successful worker return;1->2->1 and fresh reconstruction match owned head parameters."},
        {"id": "2C-20", "subject": "Frozen SSL encoder mutates BN/dropout/grad state", "result": "Temporary eval/no_grad per-module mode restoration; no inference_mode on tensors reentering head autograd; buffers unchanged and stale encoder grads cleared including exception paths."},
        {"id": "2C-21", "subject": "Returning APFL client loses private momentum", "result": "Per-owner in-memory optimizer cache nowmatches dedicated2round reference; original maxerror.0219376087. Disk restart momentum protocol not introduced."},
        {"id": "2C-22", "subject": "Explicit GAN paths alias pairs or write before rejection", "result": "Validate/normalize explicit anchor before companion prefixes; actual nested/../pair produces distinctpair, outside path rejects before writes; ordinarynested layout preserved."},
        {"id": "2C-23", "subject": "Live DP epoch snapshot writes _module keys", "result": "Plain wrapped-module state snapshot without dropping hooks,2actualepochs/8accountantsteps and urgentreader strictmodel match."},
        {"id": "2C-24", "subject": "Safe checkpoint primary bypasses history symlink containment", "result": "Single shared sidecar path check before weight write/load/model mutation; independent red replay confirms prior escape."},
    ],
    "checkpoint_contract": {"codec": "plato/utils/checkpoint_paths.py", "ordinary_names": "ASCII A-Za-z0-9_.- other than empty/dot/dotdot preserve spelling and historical underscore layouts", "special_names": "reserved ~ + SHA256 UTF8 logical component; literal ~ names are themselves encoded; org/model and org_model distinct. Overlong tuple uses ~t + SHA256 canonical logical JSON list, reserving history suffix space.", "collision_limit": "Cryptographic collision resistance, not mathematical injectivity. Historical ordinary underscore joining is preserved; no claim of arbitrary-arity underscore tuple injectivity. Actual known writer/reader frames tested.", "explicit_paths": "Relative filename/subdirectories within explicit location or configured root. Absolute filenames and resolving paths/symlinks outside root rejected. Normalize before GAN companion prefixes; independently validate histories. No security/auth/protocol redesign.", "worker_names": "model_client_run.safetensors + .safetensors.pkl history; matching .acc/.eval.pkl/.train.pkl and successful-state token/client envelope. Pause cleans only same worker/client files.", "simulated_transport": "server model_logicalid.pkl supplied to accepted client decoder; outbound model_client_logicalid.pkl uses assigned logical ID in both default and urgent paths; accepted server ingress matches.", "server_resume": "safe logical model_round.safetensors via same codec; current_round/RNG/history coordination semantics retained (fixed single-session metadata names unchanged)", "personalization": "All state writers/readers share helper; custom save_path honored. Personalized outbound's existing default raw-name interface recognized narrowly in algorithm.save_local_layers before encoding.", "urgent": "client_epoch_finish_time.safetensors decoded by tree codec; numerical (finish_time,epoch) maximum among same-client snapshots with finish_time strictly less than cutoff. No current-model/device/mode mutation; no eligible raisesValueError. Cleanup recognizes same-client historical.pth andsidecars; urgent reader not broadened to arbitrary.pth.", "PORT": "Historical fixed model_round.safetensors writer and round-2 reader both use samecodec; accepted B Safetensors tree and existing legacy.pth fallback/numerical similarity=.6 andsample2/6 weighting retained.", "GAN": "Default Generator_model.pth/Discriminator_model.pth and history preserved; explicit relative anchor prefixlayout preserved except bugfix normalization; explicit .safetensors combinedmodeltree currentworker/urgent contract, historical paired torchdata fallback onlywhencombinedanchorabsent.", "historical_state": "Recognized exact nonzero-client FedDyn/SCAFFOLD root-prefix-concatenation files read only if canonical absent; exact SCAFFOLD example control file and legacy knownbufferextras projected; originals retained. Client0 neveradopted. APFL NumPyalpha trusted reader scoped. No ambiguous old slash->underscore name fallback.", "tree_decoding": "Matching serialize_tree/deserialize_tree for ordinary/SF snapshot and PORT; no torch.load with _tree_metadata into strict model. torch.load weights_only/map_locationCPU for supported tensor .pth contracts; picklehistory/workerstate unchanged trusted local boundary."},
    "audit_unchanged": {"trainers": ["plato/trainers/basic.py", "plato/trainers/loss_criterion.py", "plato/trainers/lr_schedulers.py", "plato/trainers/optimizers.py", "plato/trainers/pfedgraph.py", "plato/trainers/strategies/data_loader.py", "plato/trainers/strategies/testing.py", "plato/trainers/strategies/algorithms/pfedgraph_strategy.py"], "algorithms": ["plato/algorithms/base.py", "plato/algorithms/fedavg.py", "plato/algorithms/pfedgraph.py", "plato/algorithms/registry.py", "plato/algorithms/split_learning.py"], "models": ["plato/models/cnn_encoder.py", "plato/models/general_multilayer.py", "plato/models/lenet5.py", "plato/models/multilayer.py", "plato/models/registry.py", "plato/models/resnet.py", "plato/models/torch_hub.py", "plato/models/vgg.py"], "method": "Source ownership/math/lifecycle inspection and relevant registry/strategy/model tests; ordinary clone/dtype/optimizer/scheduler behavior retained. PFedGraph supplied graph/neighbor detach policy and split feature autograd inspected without changing research equations. Torch-hub existing upstream download behavior retained; not claimed as a network-free external-hub benchmark."},
    "hardware_and_optimizations": {"CPU": "Real SGD/Adam/Opacus/GradScaler fused CPU, Lightly/DCGAN, multiprocessing worker and socket qualification.", "native_MPS": {v: numerical[v]["native_mps"] for v in ("313", "314")}, "native_MPS_limit": "Real local model transfer/update only; parameter identity and optimizer references preserved. Optimizer-before-to was not claimed as a proven MPS bug; no federated GPU, DP/MPS or CUDA qualification claim.", "CUDA": "Unavailable/unsupported in this machine; not qualified", "compile": "No compile changes", "measured_optimization": "16-batch tracker retained autograd nodes49->0; inference_mode restricted to pure evaluation whose tensors do not reenter autograd"},
    "future_handoffs": {"root_internal_FedDyn": "2C-11 needs independently reviewed primary-source bounded design before changing objective or replacing label weighting. Do not close as waived/external dependency.", "root_SCAFFOLD_writing": "Fresh Astra/root standalone README and SCAFFOLD-only public-doc prose from phase2c-scaffold-facts.json; mandatory beforePhase2closure. No standalone prose edited by implementer.", "fresh_implementation_review": "Root assigns fresh Sol xhigh, original author fixes material findings then fresh review; Astra phasegate/root combined validation/push.", "phase4_FedProx_exact_paths": ["configs/MNIST/fedprox_lenet5.toml", "examples/customized_client_training/fedprox/fedprox_trainer.py"], "phase4_SCAFFOLD_reserved_paths": ["examples/customized_client_training/scaffold/scaffold_callback.py", "examples/customized_client_training/scaffold/scaffold_client.py", "examples/customized_client_training/scaffold/scaffold_trainer.py", "examples/customized_client_training/scaffold/scaffold_server.py", scaffold_config], "archive": "ViT remains ARCHIVE later, no repair; reserved Phase3 adapters/vendor/Nanochat untouched. No archive relocation performed here.", "root_combined_checks": "Full mandatory Nanochat/MPC/Linux/runtime profile and B+D actual tracked S3 writer->boundedreader integration remain root-owned. All48 startup cases andreal2/6CPUround qualified here without weakened source/counts/skips."},
    "limitations": ["FedDyn objective and label-basedalpha inconsistency is still open internally pendingdesign disposition.", "F27 standaloneprose and independent implementation/writing acceptance outstanding.", "APFL per-client momentum and DP per-client privacyaccounting caches are in-memory; no complete durable server/optimizer/RNG restart guarantee or global federated privacybudget guarantee.", "Interrupted private child work cannot be reconstructed from a successful-result-only handoff; no privacy-accounting guarantee for killed workers.", "SCAFFOLD requires one positive finite scalar executed LR constant within a nonempty localrun; generic optimizer poststep correction and sampleweighted unequal-count modelaverage are documented extensions, no paper convergence guarantee.", "SCAFFOLD persisted pre-fix controls structurally load but correctedcontinuation is numerically discontinuous; recommend consistent new server/client-control initialization, never silent one-clientreset.", "Historical ordinary filename compatibility intentionally avoids arbitrary-arity tuple-injectivity promises; no migration of ambiguous old slash-sanitized names.", "Focused relevant selection excludes reservedPhase3modules; fullwholeprojectmandatoryprofile is notclaimed."],
    "owned_source_and_test_receipts": source_receipts,
}

facts = {
    "schema_version": 1, "finding": "F27", "role": "Implementation facts for root-assigned fresh Astra standalone documentation writer",
    "implementation_commit": implementation, "accepted_design_sha256": "f323f3aa9d824df44a1043b2d6aff9c8a963c42964f6e6685108c59b25fc3a89",
    "writing_scope": ["examples/customized_client_training/scaffold/README.md", "docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md: SCAFFOLD section only"],
    "unchanged_sections": "FedProx remains accepted legacy unsquared norm; do not alter its prose/equation or any TOML values.",
    "primary_source": "https://arxiv.org/pdf/1910.06378v4 (Algorithm1 andEq4)",
    "code_paths": [path for path in c_paths if "scaffold" in path],
    "equations": {"local_plain_SGD": "y_next=y-eta*(g-ci+c)", "implemented_correction_after_raw_optimizer": "y=raw_optimizer_result-eta*(c-ci)", "option_II": "ci_new=ci_old-c+(x-y)/(K*eta)", "delta": "ci_new-ci_old", "server_control": "c_new=c_old+sum(participating delta_ci)/N", "shipped_model": "x_new=sum(n_i*y_i)/sum(n_i), eta_global=1", "paper_model_for_comparison": "x_new=x+eta_global*sum(y_i-x)/len(S)"},
    "rates": "Public optimizer step prehook captures actual parameter-group LR before normal/tailstep, by parameter identity. Positive finite equal scalar participating-group LR, constant across completed updates in localrun; can change next round. Reordered equal-rate groups supported. Unequal/zero/negative/nonfinite/missingoptimizer/withinrun ratechange fails before affectedstep; no trainer.lr or fallbackrate.",
    "parameters": "Trainable parametercontrols, not suffix-basedweight/bias heuristics. Includedno-gradient param gets additivecorrection; optimizer-excluded/frozen param notcorrected, excludedci unchanged/zero delta. Known historicalbuffer/frozen extras projected; missingrequired/unknown/wrongshape/nonfinite controls reject. Floating/integerbuffers go through inherited model payload/aggregation only. Inboundcontrol tensors detached/cloned.",
    "completed_updates": "K counts actual successful optimizer updates only, accumulationtail exactlyonce. K0 retainsci and emits freshzerodelta with nodivision/staledelta. V2 exportedconstructor is compatibilitysubclass ofcorrectedOptionII; doesnotimplementpaperOptionI gradientpass.",
    "actual_dataflow": "Realexample configure assignsID beforeprocessors; each lateinbound [weights,c] immediately installs detachedcurrent c in activetrainercontext. Reusedprocessorstrainer/id rebound. Missingmalformedexamplec clearsstalec andfails. Successfulcurrent childreturnsci/delta/K/rate beforeparentoutbound; UUIDtoken/clientownership preventsstaleorabsentresult. Outboundrequirescurrent successfuldelta, refusesNone/priorround. Standalonecoremissingc warns andinitializeszero onlyoutsidefederatedexamplecontract.",
    "server_mutation": "Allrequiredparticipatingdeltas validated andnextcontrols staged beforemodel/controlcommit; malformedmissingdelta leavesboth unchanged. ControlpopulationdenominatorN, unsampleweighted sum; sampleweightedmodel retains acceptedruntime behavior.",
    "generic_optimizers": "Warning once/run for momentum/decay/maximize/Adam composition. Rawoptimizer followed by subtractiveeta*(c-ci), correctedOptionIIdisplacement equation; notmean-usedgradients or provedpaperoptimizer guarantee. Actualshipped momentum=.9 remains unchanged and isqualified; constantLRAdam composition alsotested.",
    "fixed_rate_default": "RealTOMLoptimizer.lr=.01 andmomentum=.9; actualdefaultreadfromcommittedTOML below. Only explanatorycommentsadded.",
    "actual_shipped_config": tomllib.loads((root / scaffold_config).read_text()),
    "legacy_and_restart": "Canonicalper-clientcontainedcontrolfile wins; exactmatching legacy strategyroot-prefix .pth or examplemodel_ID_control_variate.pth imported onlyifabsentcanonical, client0neverforotherID. Originalfilesretained. Pre-fixcontrols structurallyloadbutcorrectednumericalcontinuation differs; newexperimentwithallserver/clientcontrolstate consistentlyinitialized recommended. No fullserveroptimizerRNGrestart support claim, no silentoneclientreset.",
    "numerical_oracles": {"scalar_float64": "x1,c2,ci1,eta.1,g0 -> y.9,ci~0,delta~-1; gradients3,1 -> y.4,ci2,delta1 (atol1e-12)", "two_round_partial_unequal_samples": "N3,selected(1,2) then(1,3),samples(2,6,4),eta.1,2epochs/batchsize6 actualK2. Round1localy(.62,1.38),ci(.9,-.9),delta(-.1,-3.9),weightedx1.19,populationc2/3; uniformclientpaperx1.0 distinct. Round2weightedx10209/10000,c896/1125; inactiveci unchanged,cmeanallci. Equalcountcase reducesuniformreference.", "actual_successful_spawn_results": scaffold_results},
    "acceptance_code_test_contracts": {"A01": "test_independent_main_equations", "A02": "test_actual_shipped_optimizer_lr_and_next_round_rate; test_invalid_executed_rate_fails_before_update; test_missing_optimizer_and_post_step_rate_capture_then_tail_rejection; test_final_tail_denominator_uses_executed_rate_before_post_hook", "A03": "test_parameter_identity_reordered_equal_groups_buffers_and_exclusions; test_invalid_controls_fail_before_mutation", "A04": "test_real_accumulation_updates_tail_and_empty_round; test_skipped_update_is_not_corrected; parametrizedV2", "A05": "test_reused_and_reconstructed_clients_match_dedicated_two_round_controls; test_exact_legacy_load_canonical_precedence_and_client_zero_isolation; test_persistence_and_worker_state_failures_cannot_emit_old_delta", "A06": "test_shipped_spawn_pipeline_parent_control_return_with_deadline; test_actual_failed_worker_handoff_refuses_previous_delta; test_reused_processors_rebind_and_missing_inbound_c_clears_previous_round", "A07": "test_shipped_configuration_two_round_independent_rational_oracle; test_equal_count_model_update_reduces_to_uniform_reference", "A08": "test_all_server_deltas_validated_before_model_or_control_commit; test_server_buffer_payloads_keep_inherited_aggregation_policy", "A09": "test_generic_optimizer_composition_matches_independent_raw_updates; test_unmodified_shipped_momentum_optimizer_composition", "A10": "Both final468-case relevantsuites inclworkers on3.13.16/3.14.8; RuffI andscopedty38sourcefilespass; rawhashes/configoverrides retained. Standaloneprose independentwriter/review outstanding, so F27closure notclaimed."},
    "validation_reference": "evidence/2026-refresh/phase2c-validation.json",
    "do_not_claim": ["Uniform-clientpaperaggregation for unequal samplecounts", "Mean-gradientidentity orconvergence proof for momentum/Adam", "TruepaperOptionI in V2", "VariableLR/unequalLRgroups supported", "Numericallyequivalentcontinuation of pre-fixruns", "Fullserveroptimizerrestart", "Freshindependent acceptance orPhase2closure alreadyachieved"],
}
disposition = read_json(scratch / "feddyn-disposition.json")
disposition["implementation_commit"] = implementation
disposition["probe_command"] = "PYTHONPATH=. OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /tmp/plato-phase2c-313/bin/python /tmp/plato-phase2c-scratch/feddyn_disposition_probe.py"
disposition["probe_source"] = artifact(scratch / "feddyn_disposition_probe.py")
disposition["equation_fix_not_authorized_or_implemented"] = True
disposition["closure_requirement"] = "Root bounded independent primary-source design+review, then explicit original-author implementation/review if selected; this is an open internal finding and cannot be counted as complete/waived/external. F20 accepted unsquared norm policy unchanged."

write_json(evidence / "phase2c-scaffold-facts.json", facts)
write_json(evidence / "phase2c-feddyn-disposition.json", disposition)
main["facts_receipts"] = [artifact(evidence / "phase2c-scaffold-facts.json"), artifact(evidence / "phase2c-feddyn-disposition.json")]
main["audit_unchanged"]["source_receipts"] = [artifact(root / path) for category in ("trainers", "algorithms", "models") for path in main["audit_unchanged"][category]]
main["future_handoffs"]["root_SCAFFOLD_writer_coordination"] = "Root confirmed fresh Astra high writer in isolated docs worktree based on exact0dc34dd1 implementation. No later public SCAFFOLD constraint/state-path/semantic changes occurred in this handoff; code/tests unchanged since that snapshot. Writer must claim only executed qualification facts and docs require fresh review against final accepted code."
owned_dirs = [Path(f"/tmp/plato-phase2c-{name}") for name in ("313", "314", "ssl", "ssl314", "scratch", "final-313", "final-314", "candidate-313", "candidate-314", "qualified-313", "qualified-314")]
main["owned_scratch_inventory"] = {"environments": [f"/tmp/plato-phase2c-{v}" for v in ("313", "314", "ssl", "ssl314")], "directories": [str(path) for path in owned_dirs], "raw_scratch": str(scratch), "retention": "All owned scratch/rawresults/sourcebackups/logs retained for root/freshreview. No otheragentenv/worktree borrowed ormutated. Earlier pytest runtime directories produced by these own runs remain in /private/var/folders/.../pytest-of-bli; no sharedtmp cleanup performed. Generator stdout evidence-build.log is retained but excluded from its own in-flight hash inventory.", "scratch_artifacts": [artifact(path) for path in sorted(scratch.rglob("*")) if path.is_file() and "__pycache__" not in path.parts and path.name != "evidence-build.log"], "task_logs_in_tmp": [artifact(path) for path in sorted(Path("/tmp").glob("plato-phase2c-*")) if path.is_file()]}
write_json(evidence / "phase2c-validation.json", main)
print(json.dumps({"implementation": implementation, "tests": [command["counts"] for command in commands], "startup_cases": {v: result["actual_cases"] for v, result in startup_results.items()}, "evidence": [str(evidence / name) for name in ("phase2c-validation.json", "phase2c-scaffold-facts.json", "phase2c-feddyn-disposition.json")]}, indent=2))
