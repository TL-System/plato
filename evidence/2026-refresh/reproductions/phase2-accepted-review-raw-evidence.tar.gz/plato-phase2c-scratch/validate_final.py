"""Record exact commands, elapsed time, source and raw logs for root review."""
import hashlib
import json
import re
import subprocess
import sys
import time
from pathlib import Path

root = Path("/private/tmp/plato-refresh-worktrees/training")
scratch = Path("/tmp/plato-phase2c-scratch")
version = sys.argv[1]
label = sys.argv[2] if len(sys.argv) > 2 else "final"
environment = Path(f"/tmp/plato-phase2c-{version}")
runtime = Path(f"/tmp/plato-phase2c-{label}-{version}")
targets = (
    "tests/trainers tests/algorithms tests/models tests/clients tests/servers "
    "tests/callbacks tests/integration/test_smoke_configs.py "
    "tests/integration/test_event_loop_startup.py "
    "tests/integration/test_scaffold_round_flow.py "
    "tests/integration/test_checkpoint_runtime_agreement.py "
    "--ignore=tests/trainers/test_huggingface_trainer.py "
    "--ignore=tests/trainers/test_lerobot_trainer.py "
    "--ignore=tests/trainers/test_nanochat_trainer.py "
    "--ignore=tests/models/test_smolvla_model.py"
)
command = (
    "OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 "
    "VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 "
    f"{environment}/bin/python -m pytest {targets} -q --basetemp {runtime}"
)
commit = subprocess.check_output(["zsh", "-lc", "git rev-parse HEAD"], cwd=root, text=True).strip()
logfile = scratch / f"{label}-validation-{version}.log"
start = time.monotonic()
with logfile.open("w") as log:
    result = subprocess.run(["zsh", "-lc", command], cwd=root, stdout=log, stderr=subprocess.STDOUT)
text = logfile.read_text()
record = {
    "implementation_commit": commit, "python_environment": str(environment),
    "command": command, "shell": "zsh -lc", "exit_code": result.returncode,
    "seconds": time.monotonic() - start, "log": str(logfile),
    "sha256": hashlib.sha256(logfile.read_bytes()).hexdigest(),
    "summary": text.splitlines()[-1] if text else "empty output",
    "counts": {kind: int(count) for count, kind in re.findall(
        r"(\d+) (passed|failed|skipped|xfailed|xpassed|warnings)", text.splitlines()[-1] if text else ""
    )},
}
(scratch / f"{label}-validation-{version}.json").write_text(json.dumps(record, indent=2))
print(json.dumps(record, indent=2))
sys.exit(result.returncode)
