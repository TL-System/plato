"""Replay new checkpoints/overflow checks without retaining baseline mutations."""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

root = Path("/private/tmp/plato-refresh-worktrees/training")
scratch = Path("/tmp/plato-phase2c-scratch")
groups = [
    ("sidecar", "96c6bd90f3c49eb077d79a99454babc309a32c65", [
        "plato/trainers/composable.py",
    ], "tests/trainers/test_checkpoint_path_contract.py -k sidecar"),
    ("gan-explicit", "96c6bd90f3c49eb077d79a99454babc309a32c65", [
        "plato/trainers/gan.py",
    ], "tests/trainers/test_gan_runtime.py -k explicit_normalized"),
    ("dp-snapshot", "96c6bd90f3c49eb077d79a99454babc309a32c65", [
        "plato/trainers/diff_privacy.py",
    ], "tests/trainers/test_dp_data_loader_strategy.py -k actual_time_snapshot"),
    ("shared", "00eeb9dcdd2b513e64db9408969356037e09bb8e", [
        "plato/clients/base.py", "plato/clients/strategies/defaults.py",
        "plato/servers/base.py", "plato/servers/strategies/aggregation/port.py",
        "examples/async/port/port_server.py",
    ], "tests/integration/test_checkpoint_runtime_agreement.py"),
    ("personalized-checkpoint", "c1e23fa7c5e25240b3d18461a8d63fe541c183b1", [
        "plato/algorithms/fedavg_personalized.py",
    ], "tests/integration/test_checkpoint_runtime_agreement.py -k personalized_outbound"),
    ("amp", "c1e23fa7c5e25240b3d18461a8d63fe541c183b1", [
        "plato/trainers/strategies/training_step.py",
    ], "tests/trainers/test_training_update_contract.py -k grad_scaler"),
    ("fid", "c1e23fa7c5e25240b3d18461a8d63fe541c183b1", [
        "plato/trainers/gan.py",
    ], "tests/trainers/test_gan_runtime.py -k fid_actual"),
    ("feddyn-origin", "c1e23fa7c5e25240b3d18461a8d63fe541c183b1", [
        "plato/trainers/strategies/algorithms/feddyn_strategy.py",
    ], "tests/trainers/test_training_update_contract.py -k all_zero_labels"),
    ("dp-worker", "c1e23fa7c5e25240b3d18461a8d63fe541c183b1", [
        "plato/trainers/diff_privacy.py",
    ], "tests/trainers/test_dp_data_loader_strategy.py -k actual_spawned"),
]
if len(sys.argv) > 1:
    groups = [group for group in groups if group[0] in sys.argv[1:]]
record_path = scratch / "dependency-red-commands.json"
records = json.loads(record_path.read_text()) if record_path.exists() else []
records = [record for record in records if record["label"] not in {group[0] for group in groups}]
for label, commit, files, targets in groups:
    backup = {name: (root / name).read_bytes() for name in files}
    originals = {}
    try:
        for name in files:
            original = subprocess.check_output(["zsh", "-lc", f"git show {commit}:{name}"], cwd=root)
            originals[name] = hashlib.sha256(original).hexdigest()
            (root / name).write_bytes(original)
        command = f"OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /tmp/plato-phase2c-313/bin/python -m pytest {targets} -q"
        logfile = scratch / f"{label}-red.log"
        start = time.monotonic()
        with logfile.open("w") as log:
            result = subprocess.run(["zsh", "-lc", command], cwd=root, stdout=log, stderr=subprocess.STDOUT)
        records.append({"label": label, "base": commit, "command": command,
                        "exit_code": result.returncode, "seconds": time.monotonic() - start,
                        "original_sources": originals, "log": str(logfile),
                        "sha256": hashlib.sha256(logfile.read_bytes()).hexdigest()})
    finally:
        for name, content in backup.items():
            (root / name).write_bytes(content)
        assert all((root / name).read_bytes() == content for name, content in backup.items())
record_path.write_text(json.dumps(records, indent=2))
print(json.dumps(records, indent=2))
