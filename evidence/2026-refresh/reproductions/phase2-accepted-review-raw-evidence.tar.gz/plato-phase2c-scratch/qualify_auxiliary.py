"""Record final scoped types, real native probes, and optional SSL execution."""
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time
from pathlib import Path

root = Path("/private/tmp/plato-refresh-worktrees/training")
scratch = Path("/tmp/plato-phase2c-scratch")
version = sys.argv[1]
environment = Path(f"/tmp/plato-phase2c-{version}")
ssl_environment = Path("/tmp/plato-phase2c-ssl" if version == "313" else "/tmp/plato-phase2c-ssl314")
files = json.loads((scratch / "type-all-source-files.json").read_text())
commands = [
    ("imports", f"{environment}/bin/ruff check . --select I"),
    ("types", shlex.join([str(environment / "bin/ty"), "check", "--python", str(environment / "bin/python"), "--python-version", "3.13" if version == "313" else "3.14", "--output-format", "gitlab", *files])),
    ("numerical", f"PYTHONPATH=. AUDIT_MODE=green OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 {environment}/bin/python {scratch}/numerical_probe.py"),
    ("ssl", f"PYTHONPATH=. OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 {ssl_environment}/bin/python {scratch}/ssl_actual_probe.py"),
]
commit = subprocess.check_output(["zsh", "-lc", "git rev-parse HEAD"], cwd=root, text=True).strip()
records = []
for label, command in commands:
    logfile = scratch / f"qualified-{label}-{version}.log"
    stderr = scratch / f"qualified-{label}-{version}.stderr.log"
    start = time.monotonic()
    with logfile.open("w") as log, stderr.open("w") as err:
        result = subprocess.run(["zsh", "-lc", command], cwd=root, stdout=log, stderr=err)
    record = {"label": label, "implementation_commit": commit, "command": command, "shell": "zsh -lc", "exit_code": result.returncode, "seconds": time.monotonic() - start, "log": str(logfile), "sha256": hashlib.sha256(logfile.read_bytes()).hexdigest(), "stderr": str(stderr), "stderr_sha256": hashlib.sha256(stderr.read_bytes()).hexdigest()}
    records.append(record)
    print(json.dumps(record), flush=True)
    if result.returncode:
        print(logfile.read_text()[-6000:])
        print(stderr.read_text()[-6000:])
        break
(scratch / f"qualified-auxiliary-{version}.json").write_text(json.dumps(records, indent=2))
sys.exit(int(any(record["exit_code"] for record in records)))
