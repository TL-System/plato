"""Run final focused tests against original owned source, restoring in finally."""
import hashlib
import json
import os
import subprocess
from pathlib import Path

root = Path("/private/tmp/plato-refresh-worktrees/training")
os.chdir(root)
scratch = Path("/tmp/plato-phase2c-scratch")
base = "fda60becedfa6236c11d415b87a868b52789a41e"
changed = subprocess.check_output(["zsh", "-lc", "git diff --name-only"], text=True).splitlines()
owned = [name for name in changed if name.startswith(("plato/trainers/", "plato/algorithms/", "plato/models/", "configs/MNIST/fedprox_", "examples/customized_client_training/fedprox/", "examples/customized_client_training/scaffold/"))]
backups = {name: (root/name).read_bytes() for name in owned}
for name, data in backups.items():
    path = scratch / "green_source_backup" / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
commands = [
    "OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /tmp/plato-phase2c-313/bin/python -m pytest tests/trainers/test_training_update_contract.py tests/trainers/test_checkpoint_path_contract.py tests/trainers/test_personalized_state_ownership.py tests/trainers/test_dp_data_loader_strategy.py tests/trainers/test_split_learning_testing_strategy.py tests/trainers/test_gan_runtime.py tests/trainers/test_ssl_training_contract.py tests/trainers/test_scaffold_strategy.py -q",
    "PYTHONPATH=. AUDIT_MODE=red OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /tmp/plato-phase2c-313/bin/python /tmp/plato-phase2c-scratch/numerical_probe.py",
]
records = []
try:
    for name in owned:
        original = subprocess.check_output(["zsh", "-lc", f"git show {base}:{name}"])
        (root/name).write_bytes(original)
    for index, command in enumerate(commands):
        path = scratch / ("final-baseline-red.log" if index == 0 else "numerical-red.json")
        with path.open("w") as log:
            process = subprocess.run(["zsh", "-lc", command], stdout=log, stderr=subprocess.STDOUT)
        records.append({"command": command, "exit_code": process.returncode,
                        "log": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
finally:
    for name, data in backups.items():
        (root/name).write_bytes(data)
    assert all((root/name).read_bytes() == data for name,data in backups.items())
(scratch / "baseline-red-commands.json").write_text(json.dumps(records, indent=2))
print(json.dumps(records, indent=2))
