import copy,json,tempfile
from pathlib import Path
import torch
from plato.trainers.self_supervised_learning import Trainer
from tests.integration.utils import build_minimal_config,configure_environment
from tests.trainers.test_ssl_training_contract import EncoderModel
class ContrastiveModel(EncoderModel):
    def forward(self,samples):
        return tuple(self.encoder(view) for view in samples)
config=build_minimal_config(trainer_type="self_supervised_learning")
config["trainer"].update(batch_size=2,loss_criterion="NTXentLoss",lr_scheduler="ConstantLR")
config["parameters"]["learning_rate"]={"factor":1.,"total_iters":1}
config["algorithm"]["personalization"]={"model_name":"linear_mlp","model_type":"general_multilayer","batch_size":2,"epochs":1,"optimizer":"SGD","lr_scheduler":"ConstantLR","loss_criterion":"CrossEntropyLoss"}
config["parameters"]["personalization"]={"model":{"num_classes":2},"optimizer":{"lr":.1},"learning_rate":{"factor":1.,"total_iters":1}}
with tempfile.TemporaryDirectory(prefix="plato-phase2c-ssl-probe-") as directory:
 with configure_environment(config,runtime_root=Path(directory)):
  torch.manual_seed(17)
  trainer=Trainer(model=ContrastiveModel())
  trainer.set_client_id(1)
  trainer.current_round=1
  before=copy.deepcopy(trainer.model.encoder.state_dict())
  head=copy.deepcopy(trainer.local_layers.state_dict())
  data=[([torch.tensor([float(i),1.]),torch.tensor([float(i)+.1,1.1])],i%2) for i in range(4)]
  trainer.train_model({**config["trainer"],"run_id":"ssl-actual"},data,[0,1,2,3])
  result={"python":__import__("sys").version,"lightly":__import__("importlib.metadata").metadata.version("lightly"),"actual_multiview_batches":len(trainer.train_loader),"loss":trainer.run_history.get_latest_metric("train_loss"),"encoder_changed":any(not torch.equal(before[k],v) for k,v in trainer.model.encoder.state_dict().items()),"head_unchanged":all(torch.equal(head[k],v) for k,v in trainer.local_layers.state_dict().items()),"finite_parameters":all(torch.isfinite(p).all().item() for p in trainer.model.parameters())}
  assert result["encoder_changed"] and result["head_unchanged"] and result["finite_parameters"]
  print(json.dumps(result,indent=2))
