"""Read only the interpreter/dependencies in owned environments."""
import hashlib
import importlib.metadata
import json
import platform
import sys
from pathlib import Path

import torch

packages = {}
for name in ("torch", "torchvision", "timm", "opacus", "safetensors", "numpy", "pytest", "ruff", "ty", "lightly"):
    try:
        packages[name] = importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        packages[name] = None
sources = {}
if packages["opacus"]:
    import opacus
    base = Path(opacus.__file__).parent
    for name in ("grad_sample/grad_sample_module.py", "grad_sample/gsm_base.py", "privacy_engine.py", "optimizers/optimizer.py", "utils/batch_memory_manager.py", "accountants/accountant.py"):
        path = base / name
        sources[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
print(json.dumps({"executable": sys.executable, "python": sys.version, "platform": platform.platform(), "machine": platform.machine(), "packages": packages, "native_mps_available": torch.backends.mps.is_available(), "cuda_available": torch.cuda.is_available(), "opacus_inspected_installed_sources": sources}, indent=2))
