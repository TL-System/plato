import hashlib
import json
import tarfile
from pathlib import Path

root = Path("/Users/bli/Playground/plato/evidence/2026-refresh")
reports = sorted(p for p in root.glob("phase2*review*.json") if p.name not in {"phase2c-feddyn-code-review-2.json", "phase2c-algorithm-docs-final-review.json"})
allowed = {".py", ".json", ".log", ".xml", ".txt", ".diff", ".patch",
           ".stderr", ".stdout", ".toml", ".csv", ".md"}
files = {}
missing = []
def add(value):
    if not value.startswith(("/tmp/plato", "/private/tmp/plato")) or len(value) > 800:
        return
    p = Path(value)
    if p.suffix not in allowed or any(x in p.parts for x in ("site-packages", "__pycache__", "plato-refresh-worktrees", "candidate")):
        return
    if not p.is_file():
        if "bin/" in value and " " in value:
            return
        missing.append(value)
        return
    files[p.resolve()] = hashlib.sha256(p.read_bytes()).hexdigest()
def walk(obj):
    if isinstance(obj, str):
        add(obj)
    elif isinstance(obj, list):
        for v in obj:
            walk(v)
    elif isinstance(obj, dict):
        for k, v in obj.items():
            walk(k)
            walk(v)
for report in reports:
    walk(json.loads(report.read_text()))
for scratch in {Path("/private/tmp") / p.parts[3] for p in files if len(p.parts)>3}:
    if scratch.is_dir():
        for p in scratch.glob("*.py"):
            add(str(p))
dest = root/"reproductions/phase2-accepted-review-raw-evidence.tar.gz"
records = []
with tarfile.open(dest, "w:gz") as archive:
    for path, digest in sorted(files.items()):
        member = str(path.relative_to("/private/tmp"))
        archive.add(path, arcname=member, recursive=False)
        records.append(dict(original=str(path), member=member, sha256=digest, bytes=path.stat().st_size))
manifest = dict(scope="Directly referenced review raw receipts and reviewer helper scripts. Existing dedicated final C review bundles may overlap. Excludes interpreter environments and source files recoverable from named Git commits. Missing paths remain explicitly reported; no new execution claim.",
    reports=[dict(path=str(p), sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in reports],
    files=records, missing_referenced_paths=sorted(set(missing)),
    archive_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),
    archive_bytes=dest.stat().st_size)
dest.with_name("phase2-accepted-review-raw-evidence-manifest.json").write_text(json.dumps(manifest, indent=2)+"\n")
print(json.dumps(dict(files=len(records), archive_bytes=dest.stat().st_size, missing=len(set(missing)))))
