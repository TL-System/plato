import hashlib
import json
import os
from pathlib import Path
import random
import sys
import warnings

import numpy as np
import pytest
import torch

from plato.config import Config

ROWS = []
SETUP_PATHS = {}

@pytest.hookimpl(hookwrapper=True)
def pytest_fixture_setup(fixturedef, request):
    if fixturedef.argname == 'isolate_test_state':
        SETUP_PATHS[request.node.nodeid] = sys.path[:]
    yield

def snapshot(config):
    profile = config.pluginmanager.get_plugin('plato-profile-checks')
    return {
        'cwd': os.getcwd(),
        'path': sys.path[:],
        'meta_path': [id(x) for x in sys.meta_path],
        'warnings': repr(warnings.filters),
        'environment': dict(os.environ),
        'config_state': {k: id(v) for k, v in vars(Config).items()},
        'python_rng': repr(random.getstate()),
        'numpy_rng': repr(np.random.get_state()),
        'torch_rng': hashlib.sha256(torch.get_rng_state().numpy().tobytes()).hexdigest(),
        'outer_plugin': [id(profile), profile.full, profile.qualify, profile.base],
    }

@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_protocol(item, nextitem):
    if 'follows_effective_pytest_profile' not in item.name:
        yield
        return
    before = snapshot(item.config)
    modules = {k: id(v) for k,v in sys.modules.items()}
    yield
    after = snapshot(item.config)
    changed = [k for k in before if before[k] != after[k]]
    replaced = [k for k,v in modules.items()
                if k not in sys.modules or id(sys.modules[k]) != v]
    added = sorted(set(sys.modules) - set(modules))
    ROWS.append({'nodeid':item.nodeid, 'changed_global_state':changed,
                 'removed_or_replaced_modules':replaced,
                 'global_state_differences': {k:{'before':before[k],'after':after[k]} for k in changed},
                 'autouse_setup_path': SETUP_PATHS.get(item.nodeid),
                 'added_modules': added})

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_call(item):
    selected = {}
    for name in ('lock_timeout_type', 'action_space'):
        if name in item.funcargs:
            value = item.funcargs[name]
            cls = value if isinstance(value, type) else type(value)
            selected[name] = cls.__module__ + '.' + cls.__name__
    if selected:
        ROWS.append({'nodeid':item.nodeid, 'actual_fixture_types':selected})
    yield

def pytest_sessionfinish(session, exitstatus):
    prefix = Path(sys.prefix).name
    target = Path('/tmp/plato-phase2d-review-3') / ('isolation-' + prefix + '.json')
    target.write_text(json.dumps(ROWS, indent=2) + '\n')
