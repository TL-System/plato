import ast
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import xml.etree.ElementTree as ET

repo = Path('/private/tmp/plato-refresh-worktrees/payloads')
root = Path('/Users/bli/Playground/plato/evidence/2026-refresh')
scratch = Path('/tmp/plato-phase2d-review-3')
candidate = '96323afa094a37584844275cc04bf1e1eedfaa0d'
previous = '09b9b941bc4a816b62d8ed33ad993455f6f05da5'
base = 'fda60becedfa6236c11d415b87a868b52789a41e'
def git(*args):
    return subprocess.check_output(['zsh', '-lc', shlex.join(['git', *args])],cwd=repo)
def blob(commit, path):
    return git('rev-parse', commit+':'+path).decode().strip()
documents = {}
for name in ('phase2d-review.json', 'phase2d-root-base-probe.json',
             'phase2d-review-2.json', 'phase2b-acceptance.json',
             'phase2bd-root-source-validation.json', 'phase2b-review-3.json',
             'plan-addendum-acceptance.json'):
    documents[name] = json.loads((root/name).read_text())
evidence = json.loads((repo/'evidence/2026-refresh/phase2d-validation.json').read_text())
documents['phase2d-validation.json'] = evidence
result = {'read_documents': {name:hashlib.sha256((
    repo/'evidence/2026-refresh'/name if name=='phase2d-validation.json'
    else root/name).read_bytes()).hexdigest() for name in documents}}
result['review2_to_candidate_changes'] = git('diff','--name-only',previous,candidate).decode().splitlines()
result['latest_source_to_candidate_changes'] = git('diff','--name-only','65e71329',candidate).decode().splitlines()
result['merge_parents'] = git('show','-s','--format=%P','ccb31017').decode().strip().split()
result['ancestry'] = {}
for ancestor in (base,previous,'65e71329','00eeb9dc','f8aa0e98','ccb31017'):
    p=subprocess.run(['zsh','-lc',shlex.join(['git','merge-base','--is-ancestor',ancestor,candidate])],cwd=repo)
    result['ancestry'][ancestor] = p.returncode == 0
preserved = {}
for group,data in documents['phase2bd-root-source-validation.json']['production_preservation'].items():
    preserved[group] = {path: blob(candidate,path)==record['before']==record['combined']
                       for path,record in data['blobs'].items()}
result['production_preservation'] = preserved
paths = ['tests/servers/test_runtime_s3_contract.py',
         'tests/clients/test_client_lifecycle_variants.py',
         'tests/conftest.py','tests/integration/utils.py','pyproject.toml','uv.lock']
result['unchanged_review2_paths'] = {p:blob(candidate,p)==blob(previous,p) for p in paths}
result['source_manifests'] = {}
result['red_source_checks'] = []
red_manifest=json.loads(Path(evidence['review2_test_policy_correction']['red_source']['path']).read_text())
for record in red_manifest['files']:
    p=record['path'];snapshot=Path(record['snapshot']).read_bytes()
    old=ast.parse(git('show',previous+':'+p).decode())
    red=ast.parse(snapshot.decode());new=ast.parse((repo/p).read_text())
    old_functions={n.name:ast.dump(n) for n in old.body if isinstance(n,ast.FunctionDef)}
    red_functions={n.name:ast.dump(n) for n in red.body if isinstance(n,ast.FunctionDef)}
    new_functions={n.name:ast.dump(n) for n in new.body if isinstance(n,ast.FunctionDef)}
    result['red_source_checks'].append({'path':p,
        'snapshot_hash_matches':hashlib.sha256(snapshot).hexdigest()==record['sha256'],
        'original_blob_matches':blob(previous,p)==record['original_git_blob'],
        'all_original_functions_AST_match_prior_candidate': all(red_functions.get(n)==v for n,v in old_functions.items()),
        'added_regression_AST_matches_candidate': all(new_functions.get(n)==v for n,v in red_functions.items() if n not in old_functions)})
result['historical_source_manifest_checks'] = []
for section,commit in [('review_corrections','639ca69b'),
                       ('base_profile_correction','15c79d0c'),
                       ('combined_b_d_validation','53aa72c3'),
                       ('review2_test_policy_correction','65e71329')]:
    for record in evidence[section].get('source_identity_manifest',[]):
        path=record['path']
        contents=git('show',commit+':'+path)
        check={'section':section,'source_commit':commit,'path':path,
               'sha256_matches':hashlib.sha256(contents).hexdigest()==record['sha256'],
               'git_blob_matches':blob(commit,path)==record['git_blob']}
        result['historical_source_manifest_checks'].append(check)
for p in ['tests/mpc/test_round_store_contracts.py','tests/utils/test_rl_payload_utilities.py']:
    old=ast.parse(git('show',previous+':'+p).decode())
    new=ast.parse((repo/p).read_text())
    old_tests={n.name:ast.dump(n) for n in old.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
    new_tests={n.name:ast.dump(n) for n in new.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
    result['source_manifests'][p]={'unchanged_original_test_AST': {n:v==new_tests.get(n) for n,v in old_tests.items()},
        'added_functions':sorted(set(new_tests)-set(old_tests)),
        'blob':blob(candidate,p),'sha256':hashlib.sha256((repo/p).read_bytes()).hexdigest()}

descriptors = {}
def walk(value):
    if isinstance(value,dict):
        if isinstance(value.get('path'),str) and isinstance(value.get('sha256'),str):
            p=Path(value['path'])
            if p.is_absolute(): descriptors[(str(p),value['sha256'])] = None
        for v in value.values(): walk(v)
    elif isinstance(value,list):
        for v in value: walk(v)
for doc in documents.values(): walk(doc)
checks=[]
for path,expected in sorted(descriptors):
    p=Path(path)
    actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
    check={'path':path,'expected':expected,'actual':actual,'match':expected==actual}
    if not check['match'] and p == repo/'evidence/2026-refresh/phase2d-validation.json':
        history=git('log','--format=%H',candidate,'--','evidence/2026-refresh/phase2d-validation.json').decode().splitlines()
        for commit in history:
            data=git('show',commit+':evidence/2026-refresh/phase2d-validation.json')
            if hashlib.sha256(data).hexdigest()==expected:
                check['historical_exact_commit']=commit
                check['match']=True
                break
    checks.append(check)
result['artifact_checks'] = checks
result['artifact_mismatches'] = [c for c in checks if not c['match']]
result['historical_JUnit'] = []
for section,keys in [('validation',['initial_full_results']),
                     ('review_corrections',['green']),
                     ('base_profile_correction',['green_base_non_runtime']),
                     ('combined_b_d_validation',['green_full_base_non_runtime','green_mandatory_affected']),
                     ('review2_test_policy_correction',['red','green_affected_with_new_regressions'])]:
    for key in keys:
        data=evidence[section][key]
        entries=data if isinstance(data,list) else data.values()
        for entry in entries:
            if not isinstance(entry,dict):continue
            artifact=entry.get('junit_artifact')
            if not artifact:continue
            path=Path(artifact['path']); cases=ET.parse(path).findall('.//testcase')
            counts={'tests':len(cases),'failed':sum(x.find('failure') is not None for x in cases),
                    'errors':sum(x.find('error') is not None for x in cases),
                    'skipped':sum(x.find('skipped') is not None for x in cases)}
            counts['passed']=counts['tests']-counts['failed']-counts['errors']-counts['skipped']
            result['historical_JUnit'].append({'section':section,'key':key,'path':str(path),
                'source_commit':entry.get('source_commit'), 'counts':counts})
for commit,label,prefix in [('e7c0d595','initial_corrected_full','final-full'),
                            ('639ca69b','production_corrections','review-green')]:
    for version in ('313','314'):
        path=Path('/tmp/plato-phase2d.G3jkGH')/(prefix+version+'.xml')
        cases=ET.parse(path).findall('.//testcase')
        counts={'tests':len(cases),'failed':sum(x.find('failure') is not None for x in cases),
                'errors':sum(x.find('error') is not None for x in cases),
                'skipped':sum(x.find('skipped') is not None for x in cases)}
        counts['passed']=counts['tests']-counts['failed']-counts['errors']-counts['skipped']
        result['historical_JUnit'].append({'section':label,'path':str(path),
                                         'source_commit':commit,'counts':counts})
plan=repo/'evidence/2026-refresh/plan.md';addendum=repo/'evidence/2026-refresh/plan-addendum.json'
result['plan_sha256']=hashlib.sha256(plan.read_bytes()).hexdigest()
result['addendum_sha256']=hashlib.sha256(addendum.read_bytes()).hexdigest()
result['archived_source_matches_base']=git('show',base+':plato/utils/rl_env.py')==(repo/'archives/legacy_rl_env/rl_env.py').read_bytes()
(scratch/'source-evidence-audit.json').write_text(json.dumps(result,indent=2)+'\n')
assert all(all(v.values()) for v in preserved.values())
assert all(result['unchanged_review2_paths'].values())
assert all(all(v['unchanged_original_test_AST'].values()) for v in result['source_manifests'].values())
assert all(c['sha256_matches'] and c['git_blob_matches'] for c in result['historical_source_manifest_checks'])
assert all(all(v for k,v in c.items() if k!='path') for c in result['red_source_checks'])
assert not result['artifact_mismatches'], result['artifact_mismatches']
print(json.dumps({k:v for k,v in result.items() if k not in ('artifact_checks','historical_JUnit')},indent=2))
print('Verified artifact hashes:',len(checks))
print('Historical JUnit:',json.dumps(result['historical_JUnit'],indent=2))
