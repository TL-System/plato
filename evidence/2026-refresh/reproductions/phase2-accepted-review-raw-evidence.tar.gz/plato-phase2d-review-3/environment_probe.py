import hashlib
import importlib.metadata as metadata
import importlib.util
import json
from pathlib import Path
import platform
import sys

import pytest
from tests.mpc import test_round_store_contracts
from tests.utils import test_rl_payload_utilities
from plato.utils import s3, tree, toml_writer
from plato.clients.strategies import mpc
from plato.clients import transport
from plato.serialization import safetensor
from plato.processors import model_dequantize_qsgd, mpc_model_encrypt_shamir

repo = Path('/private/tmp/plato-refresh-worktrees/payloads')
distributions = sorted((d.metadata['Name'], d.version) for d in metadata.distributions())
distribution_text = '\n'.join(f'{n}=={v}' for n,v in distributions)+'\n'
origins = {n:m.__file__ for n,m in sys.modules.items()
           if (n.startswith('plato.') or n == 'plato' or n.startswith('tests.'))
           and getattr(m,'__file__',None)}
assert all(Path(p).resolve().is_relative_to(repo) for p in origins.values()), origins
lock=json.loads((repo/'evidence/2026-refresh/phase2d-validation.json').read_text())
result={'python':sys.version,'executable':sys.executable,'prefix':sys.prefix,
        'platform':platform.platform(), 'distributions':distributions,
        'distribution_fingerprint':hashlib.sha256(distribution_text.encode()).hexdigest(),
        'optional_presence':{n:importlib.util.find_spec(n) is not None for n in
                             ('kazoo','gymnasium','opacus','tiktoken')},
        'uv_lock_sha256':hashlib.sha256((repo/'uv.lock').read_bytes()).hexdigest(),
        'source_origins':origins,'all_source_origins_current_candidate':True}
print(json.dumps(result,indent=2))
