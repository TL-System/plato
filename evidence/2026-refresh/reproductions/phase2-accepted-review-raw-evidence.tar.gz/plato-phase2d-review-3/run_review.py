import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import time

ROOT = Path('/private/tmp/plato-refresh-worktrees/payloads')
SCRATCH = Path('/tmp/plato-phase2d-review-3')
SCRATCH.mkdir(exist_ok=True)
(SCRATCH / 'tmp').mkdir(exist_ok=True)
ENVS = {
    'base313': '/tmp/plato-phase2b-review-3/base313/bin/python',
    'base314': '/private/tmp/plato-phase2b-review-3/base314/bin/python',
    'mandatory313': '/tmp/plato-phase2d-review/venv313/bin/python',
    'mandatory314': '/private/tmp/plato-phase2d-review/venv314/bin/python',
}
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE='1',
           PYTHONPATH=str(ROOT) + ':' + str(SCRATCH),
           TMPDIR=str(SCRATCH / 'tmp'), HF_HUB_OFFLINE='1',
           HF_DATASETS_OFFLINE='1', TOKENIZERS_PARALLELISM='false',
           OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
           MKL_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1',
           MPLCONFIGDIR=str(SCRATCH / 'matplotlib'),
           XDG_CACHE_HOME=str(SCRATCH / 'cache'))
ENV.pop('PYTEST_ADDOPTS', None)
ENV.pop('PYTEST_PLUGINS', None)

def run(label, argv, timeout=90):
    command = shlex.join(argv)
    start = time.monotonic()
    p = subprocess.run(['zsh', '-lc', command], cwd=ROOT, env=ENV,
                       text=True, stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT, timeout=timeout)
    log = SCRATCH / (label + '.log')
    log.write_text(p.stdout)
    record = {'label': label, 'command': ['zsh', '-lc', command],
              'cwd': str(ROOT), 'exit_code': p.returncode,
              'seconds': round(time.monotonic() - start, 3),
              'log': {'path': str(log),
                      'sha256': hashlib.sha256(log.read_bytes()).hexdigest()},
              'summary': p.stdout[-2200:]}
    (SCRATCH / (label + '.json')).write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps(record), flush=True)
    return p

if __name__ == '__main__':
    import sys
    label = sys.argv[1]
    mode = sys.argv[2]
    py = ENVS[label]
    modules = ['tests/mpc/test_round_store_contracts.py',
               'tests/utils/test_rl_payload_utilities.py']
    if mode == 'targeted':
        profile = 'base' if label.startswith('base') else 'mandatory'
        run(label+'-targeted', [py, '-B', '-m', 'pytest', *modules,
            '--test-profile='+profile, '-q', '-W', 'error::UserWarning',
            '-p', 'no:cacheprovider', '--basetemp='+str(SCRATCH/(label+'-pytest')),
            '--junitxml='+str(SCRATCH/(label+'-targeted.xml'))])
    elif mode == 'scoped':
        run(label+'-scoped', [py, '-B', '-m', 'pytest', *modules, '-q',
            '-p', 'no:cacheprovider', '-W', 'error::UserWarning',
            '--basetemp='+str(SCRATCH/(label+'-scoped-pytest')),
            '--junitxml='+str(SCRATCH/(label+'-scoped.xml'))])
    elif mode == 'collection':
        run(label+'-collection', [py, '-B', '-m', 'pytest', 'tests',
            '--collect-only', '--test-profile=base', '-m', 'not runtime', '-q',
            '-p', 'no:cacheprovider'])
    elif mode == 'probe':
        run(label+'-profiles-v2', [py, '-B', str(SCRATCH/'profile_probe.py')])
    elif mode == 'environment':
        run(label+'-environment', [py, '-B', str(SCRATCH/'environment_probe.py')])
    elif mode == 'isolation':
        profile = 'base' if label.startswith('base') else 'mandatory'
        run(label+'-isolation-v3', [py, '-B', '-m', 'pytest', *modules,
            '--test-profile='+profile, '-q', '-p', 'no:cacheprovider',
            '-p', 'isolation_probe', '-W', 'error::UserWarning',
            '--basetemp='+str(SCRATCH/(label+'-isolation-pytest'))])
