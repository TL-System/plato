import datetime as dt
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

S = Path('/tmp/plato-phase2d-review-3')
DEST = Path('/Users/bli/Playground/plato/evidence/2026-refresh/phase2d-review-3.json')
ROOT_EVIDENCE = DEST.parent
REPO = Path('/private/tmp/plato-refresh-worktrees/payloads')

def read(path):
    return json.loads(Path(path).read_text())

def artifact(path):
    path = Path(path)
    return {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

audit = read(S/'source-evidence-audit.json')
final = read(S/'final-immutability.json')
prior = read(ROOT_EVIDENCE/'phase2d-review-2.json')
candidate_evidence = read(REPO/'evidence/2026-refresh/phase2d-validation.json')
b_acceptance = read(ROOT_EVIDENCE/'phase2b-acceptance.json')
b_review_hash_valid = artifact(ROOT_EVIDENCE/b_acceptance['review'])['sha256'] == b_acceptance['review_sha256']
assert b_review_hash_valid and b_acceptance['decision'] == 'ACCEPTED_COMPONENT'

environments = []
profile_results = []
runs = []
for label in ('base313', 'base314', 'mandatory313', 'mandatory314'):
    env = read(S/(label+'-environment.log'))
    versions = dict(env['distributions'])
    environments.append({
        'label': label, 'python': env['python'], 'executable': env['executable'],
        'prefix': env['prefix'], 'platform': env['platform'],
        'distribution_count': len(env['distributions']),
        'distribution_fingerprint': env['distribution_fingerprint'],
        'fingerprint_definition': 'SHA256 of sorted distribution Name==version lines, each ending in newline.',
        'optional_presence': env['optional_presence'],
        'uv_lock_sha256': env['uv_lock_sha256'],
        'relevant_versions': {k: versions[k] for k in (
            'pytest','numpy','torch','boto3','botocore','requests','safetensors',
            'kazoo','gymnasium','opacus','tiktoken') if k in versions},
        'all_imported_Plato_and_test_source_origins_are_current_candidate': env['all_source_origins_current_candidate'],
        'inventory_and_origins': artifact(S/(label+'-environment.log')),
        'reuse': 'Existing locked reviewer environment borrowed read-only; no install, sync, reconfiguration, or deletion.',
    })
    raw = (S/(label+'-profiles-v2.log')).read_text()
    probe = json.loads(raw[raw.index('{\n  "python"'):])
    profile_results.append({'environment':label,'cases':probe['rows'],
                            'artifact':artifact(S/(label+'-profiles-v2.log'))})
    for suffix in ('targeted', 'profiles-v2', 'environment'):
        record = read(S/(label+'-'+suffix+'.json'))
        assert record['exit_code'] == 0
        if suffix == 'targeted':
            path = S/(label+'-targeted.xml')
            cases = ET.parse(path).findall('.//testcase')
            record['junit'] = {'tests': len(cases),
                              'failures': sum(c.find('failure') is not None for c in cases),
                              'errors': sum(c.find('error') is not None for c in cases),
                              'skipped':sum(c.find('skipped') is not None for c in cases)}
            assert record['junit'] == {'tests':21,'failures':0,'errors':0,'skipped':0}
            record['junit_artifact'] = artifact(path)
            record['source_commit'] = final['head']
        runs.append(record)

for label in ('base313','base314'):
    record = read(S/(label+'-collection.json'))
    assert record['exit_code'] == 0
    record['result'] = '568/616 collected, 48 runtime cases deselected; no collection errors.'
    record['source_commit'] = final['head']
    runs.append(record)
for name in ('ruff-final','diff-check-final'):
    record = read(S/(name+'.json'))
    assert record['exit_code'] == 0
    runs.append(record)

isolation = []
for label, file, suffix in (
    ('base313','isolation-base313.json','isolation-v2'),
    ('mandatory313','isolation-venv313.json','isolation-v2'),
    ('base314','isolation-base314.json','isolation-v3'),
    ('mandatory314','isolation-venv314.json','isolation-v3'),
):
    rows = read(S/file)
    checks = [r for r in rows if 'changed_global_state' in r]
    assert len(checks) == 8
    assert all(not r['removed_or_replaced_modules'] for r in checks)
    assert all(not r['added_modules'] for r in checks)
    assert checks[0]['changed_global_state'] == ['path']
    assert all(not r['changed_global_state'] for r in checks[1:])
    if label.endswith('314'):
        assert checks[0]['autouse_setup_path'] == checks[0]['global_state_differences']['path']['after']
    run = read(S/(label+'-'+suffix+'.json'))
    assert run['exit_code'] == 0
    isolation.append({'environment':label,'details':artifact(S/file),
                      'command_and_result':run,
                      'regressions_observed':len(checks),
                      'actual_behavioral_fixture_types':[r for r in rows if 'actual_fixture_types' in r]})

historical = [
    {'source_commit':'e7c0d59571d88efd7eb1fdbf4fc63ac2a7b81395',
     'result_each_interpreter':'412 passed, one permitted native-tokenizer skip.',
     'attribution':'Original D implementation after its lifecycle-test correction; not current candidate validation.'},
    {'source_commit':'639ca69bf4eaeff868462d0b30a5fcc72218f061',
     'result_each_interpreter':'95 production-correction cases passed; no skips.'},
    {'source_commit':'15c79d0c81ffd0e5e4873db869a2863f97fe8279',
     'result_each_interpreter':'383 base cases passed, four permitted skips; 13 explicit mandatory affected cases passed.'},
    {'source_commit':'53aa72c3c578b1a32d8f83d64a98d6a543cdfb9a',
     'result_each_interpreter':'60 affected explicit mandatory cases passed; 557 base cases passed with four permitted skips; 48 startup/runtime cases deselected from base non-runtime runs.',
     'attribution':'Combined B+D source, unchanged production/S3/lifecycle bodies; retained, not newly rerun.'},
    {'source_commit':'09b9b941bc4a816b62d8ed33ad993455f6f05da5',
     'result_each_of_four_environments':'Two failed / 19 passed.',
     'attribution':'Author added the eight current regressions to exact prior fixtures and unchanged original behaviors. Red snapshots independently match original function ASTs and blobs; added regression ASTs match current source.'},
    {'source_commit':'65e71329da1b4e1aa4f445991f4aaa38db119d3e',
     'result_each_of_four_environments':'21 passed; clean base collection on both interpreters collected 568/616, 48 deselected.',
     'attribution':'Latest author source validation. Candidate 96323afa adds only evidence.'},
]

report = {
    'schema_version':1,
    'reviewed_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
    'review_role':'Fresh independent Phase 2D reviewer 3; no nested agents.',
    'requested_profile':{'model':'gpt-6.1-sol','reasoning_effort':'xhigh',
                         'note':'Requested execution profile recorded; no runtime model identity API is available to this reviewer.'},
    'decision':'PASS', 'candidate_local_acceptance':True,
    'phase_integration_acceptance':'PENDING_ROOT_FINAL_COMBINED_PHASE_QUALIFICATION',
    'summary':'2D-R05 is resolved on Python 3.13 and 3.14. Effective implicit and explicit mandatory fixtures use actual Kazoo and Gymnasium; clean base and unprofiled scoped contracts remain meaningful. No critical/high/medium findings remain. Previously accepted production and durable S3/lifecycle regressions are byte-identical.',
    'identity':{
        'worktree':str(REPO),'requested_worktree':'/tmp/plato-refresh-worktrees/payloads',
        'base_commit':'fda60becedfa6236c11d415b87a868b52789a41e',
        'base_tree':final['base_tree'],
        'candidate_commit':final['head'],'candidate_tree':final['tree'],
        'previous_reviewed_candidate':'09b9b941bc4a816b62d8ed33ad993455f6f05da5',
        'previous_candidate_tree':final['previous_candidate_tree'],
        'latest_source_commit':'65e71329da1b4e1aa4f445991f4aaa38db119d3e',
        'latest_source_tree':final['latest_source_tree'],
        'candidate_changes_from_latest_source':audit['latest_source_to_candidate_changes'],
        'changes_since_review2':audit['review2_to_candidate_changes'],
        'accepted_B_commit':'00eeb9dcdd2b513e64db9408969356037e09bb8e',
        'B_D_merge_commit':'ccb310177273f5cfa2ce7f1c0203f55ddaa68397',
        'merge_parents':audit['merge_parents'],'ancestry_checks':audit['ancestry'],
        'initial_clean':True,'final_clean':not final['status'],
        'immutability':final,
        'initial_manifest':artifact(S/'initial-identity.json'),
        'final_verification':artifact(S/'final-immutability.json'),
    },
    'review_inputs':{
        'AGENTS_md':artifact(REPO/'AGENTS.md'),
        'plan_sha256':audit['plan_sha256'],'accepted_addendum_sha256':audit['addendum_sha256'],
        'reports_and_evidence_read':audit['read_documents'],
        'accepted_B_review_hash_verified':b_review_hash_valid,
        'accepted_addendum_hash_matches_ROOT_acceptance':audit['addendum_sha256']==read(ROOT_EVIDENCE/'plan-addendum-acceptance.json')['artifact_sha256'],
    },
    'findings':[], 'low_or_cosmetic_observations':[],
    'resolved_2D_R05':{
        'locations':[{'path':'tests/mpc/test_round_store_contracts.py','line':18},
                     {'path':'tests/utils/test_rl_payload_utilities.py','line':18}],
        'correction':'Both fixtures read the authoritative registered plato-profile-checks object and use actual library types for qualify=True, base=False. Shared scope/filter/default policy is unchanged and is not duplicated in the fixtures.',
        'real_configuration_probe':'pytest.Config.fromdictargs parses the current project, Config._do_configure executes real hooks, registered profile state is inspected, and pytest_sessionstart executes all existing mandatory prerequisites. Session.perform_collect selects two bounded behavioral items for this reviewer probe; actual pytest_runtest_protocol executes their fixture setup, call, and teardown. No full-suite/session-finish qualification is claimed for these limited probes.',
        'actual_implicit_execution':'In both mandatory interpreters, raw test_profile=None, full=True, qualify=True, base=False yields kazoo.exceptions.LockTimeout and gymnasium.spaces.box.Box; both actual behavioral item calls and teardowns pass.',
        'missing_extra_behavior':'Both clean base interpreters lack Kazoo/Gymnasium/Opacus/Tiktoken. Implicit and explicit mandatory direct fixture calls raise ModuleNotFoundError for their actual libraries, and real sessionstart raises UsageError for missing Opacus. No base substitution, broad skip, or weakened prerequisite occurs in mandatory.',
        'optional_behavior':'Explicit base and unprofiled scoped configurations use builtins.TimeoutError and types.SimpleNamespace even when actual libraries are installed. The additional unprofiled full-but-filtered probe follows authoritative qualify=False state.',
        'original_contracts':'All eight original test function ASTs, including parametrization, are unchanged and still represent 13 cases. Three RoundInfoStore error/cleanup cases and ten actual RL numerical/training/persistence cases execute in all four targeted environments.',
        'new_regressions':'Two new functions each have four selection cases: implicit mandatory, explicit mandatory, explicit base, and scoped unprofiled; eight cases total. Optional-library absence is asserted as an import failure, not skipped.',
        'profiles':profile_results,
    },
    'isolation_and_import_effects':{
        'runs':isolation,
        'result':'All eight regression cases retain outer profile identity/state, cwd, environment, Config class state, Python/NumPy/Torch RNGs, warning filters, assertion/import hooks, and preexisting module identities. No module substitution/removal or additional imports were observed in the new regression bodies in these four environments.',
        'path_observation':'The first protocol snapshot observes pytest prepending the repository root before the autouse fixture begins; the instrumented Python 3.14 setup snapshots exactly equal final paths. This is normal outer pytest setup/import processing, not a leaked nested-config mutation. The other seven regression protocols have no path change. Shared isolate_test_state continues restoring the path captured at fixture setup.',
        'configuration_cleanup':'New configs disable cacheprovider and use _ensure_unconfigure in finally. Parsed configs may share already-imported real modules; no replacement/fake optional library is installed into sys.modules.',
    },
    'production_and_test_preservation':{
        'root_recorded_40_production_paths_rechecked':audit['production_preservation'],
        'all_production_since_review2_unchanged':True,
        'S3_lifecycle_shared_policy_and_metadata':audit['unchanged_review2_paths'],
        'changed_test_source':audit['source_manifests'],
        'archive_rl_env_matches_phase_base_bytes':audit['archived_source_matches_base'],
        'durable_S3_test_sha256':hashlib.sha256((REPO/'tests/servers/test_runtime_s3_contract.py').read_bytes()).hexdigest(),
        'durable_S3_assessment':'Tracked test imports current plato.utils.s3.S3, plato.clients.transport.receive_s3_payload and actual DefaultPayloadStrategy. The 24 localhost writer/reader valid/oversize/total-deadline cases cover four prefixes and native/minimal adapters with actual botocore writer/presigner; four actual-client failure cases assert cleanup before test finally. Prior eight minimal-prefix and two buffer-cap cases remain. No absolute scratch production imports. These unchanged 38 cases retain review2 passing evidence on both interpreters and are not mechanically rerun.',
        'merged_lifecycle_assessment':'The nine-case lifecycle module, including accepted B payload-size rejection and D persisted-MPC sample accounting, is byte-identical to review2.',
    },
    'retained_prior_contracts':{
        'original_four_findings':prior['resolved_original_findings'],
        'attribution':'Source and retained logs/manifests verified in this review; the numerical probes below were independently executed by review2, not rerun or reattributed to review3.',
        'R01':'Configured threshold is authoritative through real lifecycle/registry/server wiring; review2 five-client fractional weights [.5,0,2.5,1,3], thresholds 1/2/default and override cases match independent plaintext references within 2e-6.',
        'R02':'Decoder normalizes QSGD codes before finite float32 scaling. Retained levels 2/16/64/128 and +/-3e38 probes and shipped malformed/zero/empty contracts pass.',
        'R03':'Scalar-preserving Unicode quoting and explicit DEL escaping retained; stdlib TOML roundtrips non-BMP keys/values and nested array tables, including U+10FFFF.',
        'R04':'Distinct coefficient pool capacity validation precedes bounded sampling; retained public threshold1000 probe fails promptly before pairwise store mutation, with unchanged store bytes.',
        'F02_F05':'Exactly-once S3 keys, omitted Contents handling, complete paginator consumption, and finite default 5/30-second inactivity limits with three attempts retain prior actual localhost HTTP/botocore/Requests evidence. Runtime reader separately enforces a total deadline.',
        'F12_bf16':'Tree path collisions and reserved metadata reject before overwrite/encoding; ordinary dotted keys and normal Torch bfloat16 transport retain prior passed tests and unchanged source.',
        'HE_MPC_RL_processors_cleanup':'Touched HE/MPC, processors, active RL utilities and cleanup retain review2 accepted source/evidence. No cryptographic protocol or research-equation redesign.',
    },
    'independent_validation':{
        'environments':environments,'commands_and_results':runs,
        'environment_policy':'All shell commands use zsh -lc. Candidate selected by cwd and PYTHONPATH; actual source origins checked. Bytecode/cache writes disabled or directed to reviewer scratch. HF offline and CPU thread limits enabled; UserWarning treated as errors for targeted runs. Normal pytest plugin autoload retained.',
        'environment_overrides':{
            'PYTHONDONTWRITEBYTECODE':'1','PYTHONPATH':str(REPO)+':'+str(S),
            'TMPDIR':str(S/'tmp'),'HF_HUB_OFFLINE':'1','HF_DATASETS_OFFLINE':'1',
            'TOKENIZERS_PARALLELISM':'false','OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1',
            'MKL_NUM_THREADS':'1','VECLIB_MAXIMUM_THREADS':'1',
            'MPLCONFIGDIR':str(S/'matplotlib'),'XDG_CACHE_HOME':str(S/'cache'),
        },
        'warning_disposition':'Mandatory session prerequisite imports emit Torch MacOS elastic redirect informational messages; targeted runs otherwise pass with UserWarning as errors.',
        'probe_limits':'Profile probes run actual sessionstart and two actual behavioral items per successful parsed mode, not an unfiltered whole suite or final phase gate. No plugin prerequisite/selection policy is edited.',
        'exploratory_harness_results':{
            'profiles_v1':'Both reviewer probes exited 1 because direct setupstate teardown omitted the pytest tmp_path report bookkeeping. Replaced with actual runtest protocol in v2; both interpreters and both profiles pass. This was a reviewer harness defect, not a candidate finding; original logs retained.',
            'isolation_v1':'An overly strict pre-setup sys.path assertion caused reviewer-plugin exit 3. Detailed v2/v3 snapshots identify the first prepend before autouse setup, with no nested-test state leakage; final instrumented runs pass. Original log retained.',
            'historical_descriptor_audit':'Two old reports reference historical phase2d-validation.json hashes at the reused worktree path. Verified them against exact a4a4733 and 09b9b941 blobs; current file is correctly different. No artifact discrepancy remains.',
        },
    },
    'retained_evidence_audit':{
        'artifact_descriptors_verified':len(audit['artifact_checks']),
        'artifact_hash_mismatches':audit['artifact_mismatches'],
        'historical_source_manifest_entries_verified':len(audit['historical_source_manifest_checks']),
        'red_snapshot_verification':audit['red_source_checks'],
        'historical_JUnit_counts':audit['historical_JUnit'],
        'historical_attribution':historical,
        'count_policy':'All counts overlap. Do not sum historical suites, targeted/profile/isolation repeats, or interpreters into new coverage totals. Current reviewer 21-case results belong to exact 96323afa source; author latest 21-case/collection evidence stays at 65e71329.',
        'audit_artifact':artifact(S/'source-evidence-audit.json'),
    },
    'handoffs_and_practical_limits':[
        'PASS is local acceptance of this exact D candidate; root retains the final combined Phase 2 gate and complete local/Linux validation.',
        'No unchanged eight-minute startup matrix or all source-identical passing production/S3 suites were rerun. Prior full 48-startup evidence remains at its historical D/accepted B source.',
        'C checkpoint/F26/training/SCAFFOLD integration remains assigned elsewhere; Phase 3 native MLX/HF/LeRobot/Nanochat and Phase 4 FEI zero-norm/constructor fixes are not new D failures.',
        'No live cloud S3, ZooKeeper cluster, full distributed HE/MPC deployment, native MLX/GPU, cryptographic proof, benchmark, or whole-stack Python 3.14 qualification is claimed.',
        'Synchronous S3 utility timeouts bound inactivity/retries, not total duration of an indefinitely trickling body; bounded runtime ingress supplies its distinct total deadline. Existing trusted-peer/storage pickle contract is retained.',
        'No candidate edits, commits, pushes, shared metadata/fixture changes, security questions, or nested agents. Only requested ROOT report and reviewer scratch written; all resources retained.',
    ],
    'resources':{
        'report':str(DEST),'scratch':str(S),'retained':True,
        'runner':artifact(S/'run_review.py'),
        'profile_probe':artifact(S/'profile_probe.py'),
        'isolation_probe':artifact(S/'isolation_probe.py'),
        'source_auditor':artifact(S/'source_audit.py'),
        'borrowed_environments':[env['prefix'] for env in environments],
    },
}
assert report['review_inputs']['accepted_addendum_hash_matches_ROOT_acceptance']
assert not report['findings']
DEST.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'decision':report['decision'],'report':str(DEST),
                  'report_sha256':hashlib.sha256(DEST.read_bytes()).hexdigest(),
                  'candidate_commit':final['head'],'candidate_tree':final['tree'],
                  'clean':not final['status'],'findings':report['findings']},indent=2))
