import importlib.metadata as metadata
import importlib.util
import json
from pathlib import Path
import platform
import sys
from types import SimpleNamespace

import pytest
from tests.mpc import test_round_store_contracts as locks
from tests.utils import test_rl_payload_utilities as rl

repo = Path('/private/tmp/plato-refresh-worktrees/payloads')
rows = []
for name, args in [
    ('implicit-mandatory', ['tests']),
    ('explicit-mandatory', ['tests', '--test-profile=mandatory']),
    ('explicit-base', ['tests', '--test-profile=base']),
    ('unprofiled-scoped', ['tests/mpc/test_round_store_contracts.py']),
    ('filtered-full-unprofiled', ['tests', '-m', 'not runtime']),
]:
    config = pytest.Config.fromdictargs({}, [*args, '-p', 'no:cacheprovider',
        '--basetemp=/tmp/plato-phase2d-review-3/config-fixtures'])
    try:
        config._do_configure()
        checks = config.pluginmanager.get_plugin('plato-profile-checks')
        assert checks is not None
        row = {'case': name, 'raw_option': config.getoption('test_profile'),
               'full': checks.full, 'qualify': checks.qualify,
               'base': checks.base, 'registration_count': sum(
                   n == 'plato-profile-checks'
                   for n, _ in config.pluginmanager.list_name_plugin())}
        request = SimpleNamespace(config=config)
        for key, fixture, module_name in [
            ('lock', locks.lock_timeout_type, 'kazoo'),
            ('space', rl.action_space, 'gymnasium')]:
            try:
                value = fixture.__wrapped__(request)
                cls = value if isinstance(value, type) else type(value)
                row[key] = cls.__module__ + '.' + cls.__name__
            except ModuleNotFoundError as exc:
                row[key] = 'ModuleNotFoundError:' + str(exc.name)
        expected_required = name in ('implicit-mandatory', 'explicit-mandatory')
        if expected_required:
            assert row['lock'] == ('kazoo.exceptions.LockTimeout' if
                importlib.util.find_spec('kazoo') else 'ModuleNotFoundError:kazoo')
            assert row['space'] == ('gymnasium.spaces.box.Box' if
                importlib.util.find_spec('gymnasium') else 'ModuleNotFoundError:gymnasium')
        else:
            assert row['lock'] == 'builtins.TimeoutError'
            assert row['space'] == 'types.SimpleNamespace'
        session = pytest.Session.from_config(config)
        try:
            config.hook.pytest_sessionstart(session=session)
        except pytest.UsageError as exc:
            row['sessionstart'] = str(exc)
            assert expected_required and importlib.util.find_spec('opacus') is None
            assert 'mandatory prerequisite failed' in str(exc)
        else:
            row['sessionstart'] = 'passed'
            items = session.perform_collect([
                str(repo/'tests/mpc/test_round_store_contracts.py') +
                '::test_lock_failure_stops_client_and_never_writes',
                str(repo/'tests/utils/test_rl_payload_utilities.py') +
                '::test_active_policy_finite_update_and_saved_weight_roundtrip[sac]'])
            actual = {}
            reports = []
            class Observer:
                @pytest.hookimpl(hookwrapper=True)
                def pytest_runtest_setup(self, item):
                    yield
                    for fixture_name in ('lock_timeout_type', 'action_space'):
                        if fixture_name in item.funcargs:
                            value = item.funcargs[fixture_name]
                            cls = value if isinstance(value, type) else type(value)
                            actual[fixture_name] = cls.__module__ + '.' + cls.__name__
                def pytest_runtest_logreport(self, report):
                    reports.append((report.when, report.outcome))
            config.pluginmanager.register(Observer(), 'review3-fixture-observer')
            for item in items:
                config.hook.pytest_runtest_protocol(item=item, nextitem=None)
            assert reports == [('setup', 'passed'), ('call', 'passed'),
                               ('teardown', 'passed')] * 2, reports
            assert actual['lock_timeout_type'] == row['lock']
            assert actual['action_space'] == row['space']
            row['actual_pytest_fixture_execution'] = actual
            row['targeted_behavioral_reports'] = reports
        rows.append(row)
    finally:
        config._ensure_unconfigure()
print(json.dumps({'python': sys.version, 'platform': platform.platform(),
                  'source_modules': [locks.__file__, rl.__file__],
                  'rows': rows}, indent=2))
