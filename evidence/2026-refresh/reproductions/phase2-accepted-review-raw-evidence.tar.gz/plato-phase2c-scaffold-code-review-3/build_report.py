from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import shlex
import subprocess

S = Path('/tmp/plato-phase2c-scaffold-code-review-3')
C = Path('/private/tmp/plato-refresh-worktrees/scaffold-review3')
DEST = Path('/Users/bli/Playground/plato/evidence/2026-refresh/phase2c-scaffold-code-review-3.json')

def read(name):
    return json.loads((S / name).read_text())

def artifact(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def git(*args):
    return subprocess.check_output(['zsh', '-lc', shlex.join(['git', *args])], cwd=C).decode().strip()

audit = read('receipt-audit.json')
commands = [read(path.name) for path in sorted(S.glob('*.command.json'))]
labels = {item['label']: item for item in commands}
for item in commands:
    assert artifact(item['raw_log'])['sha256'] == item['raw_sha256']
    assert item['exit_code'] == (1 if item['label'].startswith(('regression', 'replay')) else 0), item
assert git('rev-parse', 'HEAD') == '15e0cebd78ec6752b9aae1e922b33e22e168387f'
assert git('rev-parse', 'HEAD^{tree}') == '9c9ce313f88552968b487388d681eda82384abfc'
assert git('status', '--short', '--ignored') == ''
manifest = read('source-manifest.json')
assert all(hashlib.sha256((C / item['path']).read_bytes()).hexdigest() == item['sha256'] for item in manifest)

regressions = {version: read(f'cleanup-replay-{version}.json') for version in ['313', '314']}
for result in regressions.values():
    assert result['failed'] == 2 and result['passed'] == 2
    for case in result['cases']:
        assert case['error'] == 'RuntimeError: Secondary cleanup failure'
        if case['interface'] == 'train_model':
            assert case['outbound_eligible'] and not case['canonical_preserved']
            assert abs(case['ci'] - .9) < 1e-12
            assert abs(case['retry']['y'] - .601) < 1e-12
        else:
            assert not case['outbound_eligible'] and case['canonical_preserved']
            assert case['ci'] == 1.

finding = {
    'id': 'F27-R3-01', 'severity': 'medium', 'status': 'OPEN',
    'title': 'Direct train_model still accepts canonical controls before fallible model-update cleanup completes.',
    'related_previous_finding': 'F27-R2-02: the original training-step end-hook failure is fixed; a successful end hook followed by failing model-update cleanup still produces the same rejected-call persistence/retry defect.',
    'acceptance_contracts': ['A05', 'A06', 'A10'],
    'primary_location': {'file': 'plato/trainers/composable.py', 'line': 454},
    'supporting_locations': [
        {'file': 'plato/trainers/composable.py', 'line': 455},
        {'file': 'plato/trainers/composable.py', 'line': 463},
        {'file': 'plato/trainers/composable.py', 'line': 428},
        {'file': 'plato/trainers/strategies/algorithms/scaffold_strategy.py', 'line': 311},
        {'file': 'plato/trainers/strategies/algorithms/scaffold_strategy.py', 'line': 330},
        {'file': 'tests/integration/test_scaffold_callback_lifecycle.py', 'line': 170},
    ],
    'cause': 'After the training-step end hook succeeds, train_model invokes on_train_result_accepted, atomically replaces the canonical ci file and marks successful=True. Its finally then invokes on_train_cleanup(context, True). A public cleanup hook which runs the real cleanup and then raises makes the public call fail after acceptance. There is no rejection handler at this direct boundary. The same failure under train_process is caught by its outer rejection handler while acceptance remains deferred.',
    'test_gap': 'The delivered cleanup_failure cases always install InterruptEnd, so the end hook has already failed and successful remains False. They verify rejection when a secondary cleanup exception follows an end failure, but omit cleanup failure after otherwise successful training/end hooks.',
    'reproduction': {
        'probe': artifact(S / 'reproduce_cleanup_failure.py'),
        'helper': artifact(S / 'cleanup_acceptance_probe.py'),
        'source_and_numeric_helper': artifact(S / 'independent_checks.py'),
        'commands': [labels['replay313'], labels['replay314']],
        'exact_standalone_commands': [
            'cd /private/tmp/plato-refresh-worktrees/scaffold-review3 && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/private/tmp/plato-refresh-worktrees/scaffold-review3 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /tmp/plato-phase2c-313/bin/python -B /tmp/plato-phase2c-scaffold-code-review-3/reproduce_cleanup_failure.py',
            'cd /private/tmp/plato-refresh-worktrees/scaffold-review3 && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/private/tmp/plato-refresh-worktrees/scaffold-review3 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /tmp/plato-phase2c-314/bin/python -B /tmp/plato-phase2c-scaffold-code-review-3/reproduce_cleanup_failure.py',
        ],
        'shell': 'Run each command with zsh -lc. The recorded commands include isolated TMPDIR/cache paths. The reusable reproduce_cleanup_failure.py creates a fresh UUID runtime directory under owned scratch on every invocation; prior results remain retained.',
        'steps': [
            'Load the shipped TOML through Config, overriding CPU scalar float64 quadratic model, real SGD momentum=0, lr=.1, epochs=2, two actual samples, N=3, and contained slash model-name paths. Start x=1,c=2,ci=1. Test both an existing canonical ci=1 file and absent canonical state.',
            'Instrument only on_train_cleanup: invoke the actual SCAFFOLD cleanup first, then raise RuntimeError after a real successful training-step end hook. Initialization cleanup is allowed to complete normally. Execute actual train_model and comparison train_process.',
            'Inspect memory ci, canonical bytes/absence, get_update_payload, optimizer pre-hook registration and context flags after the raised exception.',
            'Run actual configure-based 1->2->1 reuse and fresh client-1 reconstruction, then the actual successful client inbound/train/outbound pipeline. Where no canonical file was accepted in the process comparison, explicitly restore the original manually injected ci=1 for the retry; no persistence of unaccepted manual state is assumed.',
        ],
        'expected': 'A call rejected by a fallible local end/cleanup hook must retain ci=1 and the exact previous canonical bytes or absence, refuse outbound success, and permit reuse/reconstruction plus explicit ci=1 retry y=.62,ci=.9,delta=-.1.',
        'actual_direct': 'Both canonical-present and canonical-absent train_model calls raise Secondary cleanup failure, but memory ci and canonical ci are .8999999999999995, get_update_payload succeeds, and the file has been replaced/created. Routine reuse and fresh reconstruction adopt .9. Successful retry yields y=.6009999999999999,ci=.895,delta=-.004999999999999449.',
        'actual_process_comparison': 'The same cleanup failure under train_process rejects the pending result, retains memory ci=1 and prior canonical bytes/absence, refuses outbound and retries at .62/.9/-.1.',
        'current_failure_result': 'The independent rejection-asserting regression returns exit 1 on each interpreter: two direct failures and two passing process comparisons. The observational 12-case probe returns zero only after recording observations; its zero exit is not acceptance.',
        'python_versions': ['3.13.16', '3.14.8'],
        'results': regressions,
        'population_consequence': {'inactive_ci': [3, 2], 'initial_c': 2, 'retry_only_server_c': 2 - .005/3, 'mean_retained_ci': (.895+3+2)/3, 'interpretation': 'Ordinary retry after a caller-visible failure loses the failed attempt delta. This is not a full training-round, external-side-effect or restart rollback requirement.'},
    },
    'impact': 'A failed public direct call becomes durable and outbound-eligible, and routine logical-client reuse changes the next successful local update. The direct/process acceptance inconsistency remains material within the requested lifecycle scope.',
    'bounded_correction': 'Complete fallible local lifecycle cleanup before direct canonical acceptance, or provide an equivalent bounded rejection boundary preserving the last accepted controls on this error. Keep child controls provisional through model saving/current-token handoff and accept in the parent only after successful loading. Preserve the existing server commit boundary and general accepted fixes. Add this otherwise-successful cleanup failure with canonical-present/absent direct/process comparison and successful reuse/retry. No generic FedAvg redesign or transaction for external side effects is requested.',
}

contracts = [
    {'id': 'A01', 'status': 'PASS', 'evidence': 'Independent real float64 SGD hooks for core and V2: g=0 yields y=.9,ci≈0,delta≈-1; gradients [3,1] yield y=.4,ci≈2,delta≈1, agreeing with independent mean gradients to 1e-12. Prior baseline-red evidence is retained in the hash-verified first review; baseline was not rerun here.'},
    {'id': 'A02', 'status': 'PASS', 'evidence': 'Actual shipped Config/optimizer-factory tests cover lr .1/.025 and later .05, equal reordered groups, missing optimizer, nonpositive/nonfinite/unequal and within-round changed rates, captured executed LR before post-step changes and accumulation tail. Actual optimizer publication and pre-hook capture audited; strategy/optimizer source unchanged from f977.'},
    {'id': 'A03', 'status': 'PASS', 'evidence': 'Focused parameter-identity, theta/weight/bias, missing-gradient, frozen/excluded, floating/integer buffer, known historical extras and detached-input cases pass. Independent transport adds model/control cast overflow and integer-control rejection at either client position with zero or positive sample weight, plus compatible bool/integer/frozen buffer aggregation.'},
    {'id': 'A04', 'status': 'PASS', 'evidence': 'Independent core/V2 accumulation window 2 with 1/3/4 microbatches gives K=1/2/2, normalized tail once and later empty delta=0. Actual CPU GradScaler overflow gives y=1,K=0,ci=1,delta=0; next successful step y=.8,K=1. No CUDA claim.'},
    {'id': 'A05', 'status': 'FAIL_BOUNDARY', 'finding': 'F27-R3-01', 'evidence': 'Normal logical-client 1->2->1/dedicated/fresh reconstruction, canonical precedence/exact supported legacy paths, buffer projection, custom/slash paths and callback/save/replace rejections pass. Direct successful-end cleanup failure still replaces/creates canonical ci for a rejected call.'},
    {'id': 'A06', 'status': 'FAIL_BOUNDARY', 'finding': 'F27-R3-01', 'evidence': 'Actual inbound/outbound processors refresh current c, rebind reused processors and clear stale/malformed inbound state. Positive spawn, missing/stale current-token handoff, model-save and parent-commit rejections pass. Original missing-worker reuse/retry probe passes. New spawned end/cleanup failures with present/absent canonical state also reject and retry correctly. Direct train_model cleanup failure remains accepted.'},
    {'id': 'A07', 'status': 'PASS', 'evidence': 'Independent Fraction oracle and actual autograd gradients through shipped example pipeline/full _process_reports agree for unequal/equal direct two-round cases and real spawn. N=3, selected (1,2) then (1,3), sample counts (2,6,4), batch 6, epochs 2, real K=2. Round 1 weighted x=1.19 vs uniform 1,c=2/3; round 2 x=10209/10000,c=896/1125. Inactive ci unchanged and c=mean(all ci).'},
    {'id': 'A08', 'status': 'PASS', 'evidence': 'Raw malformed models/controls and invalid report metadata reject before staging at both client positions including zero weights. Original actual callback rejection probe passes: receive exception, metadata mutation, NaN model mutation, aggregate exception preserve x=1,c=2 and clear staging. Tracked 12 server lifecycle cases include partially failing load, arithmetic failure, pending/delta/committed-control and post-aggregation model/control mutation, stale-stage later ingress and successful retry. Additional finite control-sum/delta-arithmetic overflow and NaN receive callbacks on either zero-weight client pass. Postcommit reporting failure retains accepted x=8,c=13/3 as intended.'},
    {'id': 'A09', 'status': 'PASS', 'evidence': 'Unmodified shipped SGD momentum=.9/lr=.01 and constant-rate Adam match independent raw optimizer updates followed by subtractive correction; one visible extension warning per run. V2 is the shared corrected Option II subclass. No mean-gradient/convergence equivalence claimed for optimizer extensions.'},
    {'id': 'A10', 'status': 'FAIL_MATERIAL_FINDING', 'finding': 'F27-R3-01', 'evidence': '282 affected tests pass each on Python 3.13.16/3.14.8, zero skips, 17 visible notices; Ruff I and scoped ty pass. Exact source/tree, source receipts, old/new evidence and root archive receipts verified. Direct cleanup regression fails each interpreter. Whole C, FedDyn final math, B supplement and final prose remain separate.'},
]

execution_counts = [
    {'run': 'affected313 / affected314', 'each': {'passed': 282, 'warnings': 17, 'skips': 0}, 'scope': 'One coherent union per interpreter, including the author 174-test selection and additional ComposableTrainer/base/loss, checkpoint/path, APFL/FedRep/SSL/GAN/pFedGraph regressions. No counts from overlapping selections are added.'},
    {'run': 'archive313 / archive314', 'each': {'passed': 4, 'deselected': 13, 'warnings': 0}, 'scope': 'Actual historical-writer migration tests from independently extracted exact candidate archive without .git; these four are already in the 282-test selection.'},
    {'run': 'callback313 / callback314', 'each': {'server_scenarios': 4, 'trainer_scenarios': 4}, 'scope': 'Adapted original reviewer callback probe; corrected expectations, not the old defect-asserting assertions.'},
    {'run': 'numerical313 / numerical314', 'each': {'core_and_v2_equation_cases': 4, 'core_and_v2_accumulation_cases': 6, 'raw_model_rejection_cases': 3, 'direct_two_round_scenarios': 2}, 'scope': 'Independent numerical checks and unequal/equal configured direct flow. These are probe scenarios, not an additional pytest unique-test total.'},
    {'run': 'spawn313 / spawn314', 'each': {'two_round_spawn_scenarios': 1, 'trained_client_updates': 4}, 'scope': 'Actual max_concurrency child-to-parent flow with independently recorded gradients, ci/delta/K/executed LR and current token.'},
    {'run': 'worker313 / worker314', 'each': {'failed_handoff_reuse_retry_scenarios': 1}, 'scope': 'Adapted original missing-state worker probe, canonical ci=1 preserved and successful retry .62/.9/-.1.'},
    {'run': 'acceptance313 / acceptance314', 'each': {'direct_process_rejection_retry_cases': 10}, 'scope': 'Original direct callback/save/atomic-replace probe with source/scratch adaptations only.'},
    {'run': 'transport313 / transport314', 'each': {'rejection_cases': 12, 'compatible_buffer_case': 1}, 'scope': 'Original transport probe with source/scratch adaptations only; existing float32 tolerance preserved.'},
    {'run': 'boundary313 / boundary314', 'scope': 'Independent momentum/Adam composition, real skipped CPU GradScaler update/retry and unchanged legacy unsquared-L2/L1 FedProx checks.'},
    {'run': 'arithmetic313 / arithmetic314', 'each': {'passed_scenarios': 4}, 'scope': 'Finite-input control sum overflow, finite-input model delta arithmetic overflow through supported inherited fallback, and callback NaN on either zero-weight client.'},
    {'run': 'spawnend313 / spawnend314', 'each': {'passed_failure_reuse_retry_scenarios': 4}, 'scope': 'Actual spawn end and cleanup hook failures, canonical present/absent, fresh reconstruction and successful explicit ci=1 retry.'},
    {'run': 'cleanup313 / cleanup314', 'each': {'observational_scenarios': 12}, 'scope': 'End-only/cleanup-only/combined faults, direct/process, canonical present/absent. Zero observational exit is not an acceptance result.'},
    {'run': 'regression313 / regression314; reusable replay313 / replay314', 'each': {'assertion_cases': 4, 'failed': 2, 'passed': 2, 'inner_exit_code': 1}, 'scope': 'Rejection assertions expose the direct-only material defect. These four overlap the observational probe. The fresh-UUID replay repeats the same four assertions to verify a reusable reproducer; neither execution is counted again as unique cases.'},
]

report = {
    'schema_version': 1, 'date': datetime.now(timezone.utc).isoformat(),
    'role': 'Fresh independent SCAFFOLD correction review 3; no nested agents or source edits.',
    'decision': 'CHANGES_REQUIRED', 'acceptance': 'FAIL', 'finding': 'F27',
    'summary': 'Server callback batch atomicity and the original direct training-step end failure are corrected. Successful math/direct/spawn/ownership contracts remain intact, and ROOT-2C-02 portable historical-writer correction passes independent archive review. One medium lifecycle finding remains: direct train_model persists and exposes accepted controls before a fallible model-update cleanup completes. Reproduced on both interpreters despite 282 passing affected tests each.',
    'finding_counts': {'critical': 0, 'high': 0, 'medium': 1, 'low_recommendations': 1},
    'findings': [finding],
    'low_recommendations': [{
        'id': 'F27-R3-L01', 'severity': 'low',
        'location': {'file': 'plato/trainers/composable.py', 'line': 429},
        'title': 'Avoid a second post-run rejection cleanup for failures already cleaned by train_model.',
        'observation': 'On a training-step end failure, train_model invokes on_train_cleanup(False), then train_process invokes the same hook again in its catch. The probe excludes the separate initialization cleanup and records two post-run False calls. A combined failure raises the secondary cleanup error again; Python exception context still retains the original end error.',
        'recommendation': 'While correcting the acceptance boundary, give rejection cleanup one clear owner per failed stage and preserve useful primary/secondary exception visibility. Built-in SCAFFOLD cleanup is idempotent here; this observation is not an additional demonstrated model/control corruption finding or a demand for transactions across arbitrary composed plugins.',
    }],
    'immutable_candidate': {
        'path': str(C), 'requested_alias': '/tmp/plato-refresh-worktrees/scaffold-review3',
        'commit': audit['head'], 'tree': audit['tree'],
        'implementation': '0f17708afefde13eeba1fd71578258b68c5911ee',
        'implementation_tree': '77ad0245765227716f6fca5335bba6b67a6c0fbb',
        'initial_status': '', 'final_status_including_ignored': '', 'detached': True,
        'tracked_files_checked_against_git_blob_and_root_archive': 979,
        'tracked_files_unchanged': True, 'own_no_git_archive_unchanged': True,
        'only_post_implementation_files': audit['only_post_implementation_files'],
        'source_manifest': artifact(S / 'source-manifest.json'),
        'receipt_audit': artifact(S / 'receipt-audit.json'),
        'candidate_vs_f977': artifact(S / 'candidate-vs-f977.diff'),
        'candidate_vs_implementation': artifact(S / 'candidate-vs-implementation.diff'),
    },
    'authorization_inputs': audit['inputs'],
    'reviewed_source_identities': audit['author_source_receipts'],
    'primary_source': {
        'title': 'SCAFFOLD: Stochastic Controlled Averaging for Federated Learning',
        'url': 'https://arxiv.org/pdf/1910.06378v4',
        'authority': 'Main Algorithm 1 and equations (3)-(5), PDF pages 4-5; independently re-opened primary PDF. Appendix displacement sign typo is not the implementation authority.',
        'retained_pdf': artifact(S / 'primary-paper-1910.06378v4.pdf'),
        'equations_checked': 'y_next=y-eta*(g-ci+c); ci_new=ci-c+(x-y)/(K*eta); c_new=c+sum(delta_ci)/N. Constant vanilla SGD gives ci_new equal to the mean actually used gradients. Shipped unequal-sample model averaging and optimizer extensions remain explicitly bounded implementation choices.',
    },
    'accepted_contract_review': contracts,
    'previous_review_disposition': [
        {'id': 'F27-R01', 'status': 'ORIGINAL_REPRODUCTION_FIXED', 'evidence': 'Original raw NaN/missing/broadcast cases reject with x=1,c=2 and cleared stage, both versions; delivered raw/zero-weight cases also pass.'},
        {'id': 'F27-R02', 'status': 'ORIGINAL_REPRODUCTION_FIXED', 'evidence': 'Adapted original missing current-worker handoff probe preserves canonical and memory ci=1 through 1->2->1/fresh construction and retry .62/.9/-.1, both versions.'},
        {'id': 'F27-R2-01', 'status': 'PASS_BOUNDED_CORRECTION', 'evidence': 'Actual callback/full-report rejections, state rollback, finite overflow, zero weights, stage cleanup, successful retry and intended postcommit retention pass. No material server issue found.'},
        {'id': 'F27-R2-02', 'status': 'ORIGINAL_END_HOOK_REPRODUCTION_FIXED_WITH_REMAINING_RELATED_BOUNDARY', 'remaining': 'F27-R3-01', 'evidence': 'Actual direct/process end failure now precedes acceptance, preserves canonical bytes/absence, refuses outbound and removes pre-hook; same fault through actual spawn also passes. Otherwise successful direct cleanup exception still accepts.'},
        {'id': 'ROOT-2C-02', 'status': 'PASS_PORTABLE_HISTORICAL_WRITER_CORRECTION', 'evidence': 'Tracked full historical source/license bytes and provenance match accepted B00e exactly. Four actual writer/migration/canonical-precedence/client-zero-isolation cases pass without .git on both versions. No test runtime git show/archive/fetch dependency remains.', 'fixture': read('portable-fixture.json'), 'future_limit': 'This accepts fixture correctness and portability with the candidate old automatic reader only. Future explicit readonly reader and final FedDyn mathematics require their separate owner/review.'},
    ],
    'independently_executed': execution_counts,
    'command_records': commands,
    'command_wrapper_note': 'run_command.py captures and hashes the inner zsh -lc exit code, log and duration. Its outer bookkeeping process can return zero while a recorded regression inner exit is 1; no wrapper zero or observational defect assertion is counted as PASS.',
    'environment': {version: {key: read(f'environment-{version}.json')[key] for key in ['python', 'executable', 'platform', 'versions']} for version in ['313', '314']},
    'warnings': {
        'affected_each': 17, 'skips_each': 0,
        'categories': {'Opacus experimental nonsecure RNG': 5, 'RDP largest-order notice': 3, 'PyTorch full backward hook inputs without gradients': 4, 'Repeated privacy budget spending notice': 2, 'Subset dataset object accounting notice': 3},
        'policy': 'Visible and unsuppressed; no warning filters or global policy edits. CPU GradScaler qualification is not CUDA/AMP device qualification or a global privacy guarantee.',
    },
    'author_evidence_audit': {
        'new_evidence_log_receipts': audit['author_logs'],
        'new_source_receipts_match_candidate': True,
        'new_evidence_body_and_receipt_hashes_match': True,
        'author_green_each': '174 passed,17 warnings,zero skips at exact0f177; overlap with independent282, not an additional unique total.',
        'author_red_each': '16 failed,4 passed on immutablef977;20 tracked lifecycle cases. Raw log hashes checked; not independently repeated in this review.',
        'historical_f977_logs_and_socket_receipts': audit['historical_author_logs'],
        'historical_limit': '523-case f977 and48 startup receipts retained and hashed as historical evidence. Startup test/harness/probe and servers/base.py blobs are unchanged in this candidate. The48 startup cases were not rerun here; final combined qualification remains root-owned.',
    },
    'root_additional_archive_receipt': {
        'report': next(item for item in audit['inputs'] if item['path'].endswith('phase2c-root-intermediate-base-validation.json')),
        'log_and_junit_receipts': audit['root_archive_logs'],
        'audited_result': {'python': '3.13.16', 'passed': 797, 'expected_optional_skips': 4, 'allowed_runtime_deselections': 48, 'warnings': 0, 'exit_code': 0, 'seconds': 204.36},
        'verification': 'Root log/JUnit hashes match. JUnit has801 tests,4 skips,zero failure/error entries. All979 tracked archive files match pinned candidate blobs; no .git. Four portable migration cases are included.',
        'attribution': 'Root-owned run audited, not independently rerun or added to282. No whole source-profile failure is hidden: this base profile passes, but the independent direct lifecycle boundary regression fails. No3.14 broad-base, final B/D/FedDyn/prose or whole Phase2 acceptance inferred.',
    },
    'preservation': {
        'accepted_A': {'commit': '79da1f97d8a12fe97402750cc32c7b3e8f5cdf6e', 'merge': 'abf27a34db3e40fc743f329d40bed5dae4dc70f7', 'all_48_owned_entries_unchanged': True, 'method': 'Compared exact accepted A vs candidate ls-tree entries for every changed/deleted path relative to fda60bec. This is blob preservation, not a new A audit.'},
        'accepted_general_f977': 'AMP/clipping, long owned-worker cleanup, FedALA memory ownership and legacy underscore lookup fixes remain accepted by their separate root general acceptance. Their core source blobs are unchanged; actual affected AMP/general cleanup/FedALA/ownership tests were rerun within282.',
        'preserved_source_paths': audit['preserved_from_f977'],
        'SCAFFOLD_TOML_values_equal_accepted_B': True,
        'F20': 'Legacy unsquared L2 and L1 source/config preserved. Independent d=(3,4),mu=2 yields L2 loss5,gradient(.6,.8), L1 loss14,gradient(2,2); zero distance and mu=0 remain finite. No squared-norm migration.',
        'B_resume_supplement': 'Accepted a058 is not in this candidate and is not accepted or re-audited here. Original B00e remains the runtime base; later integration must preserve these checks.',
    },
    'public_facts_for_astra_reconciliation': {
        'input_used': 'Candidate phase2c-scaffold-review2-fixes-validation.json.public_facts_for_astra_reconciliation. Older phase2c-scaffold-facts.json is historical, not final current-source authority.',
        'server_validation': 'weights_received validates every raw model/control pair and stages c+sum(delta)/N. After receive callbacks, all returned model halves, current server controls, delta membership/validity and staged control consistency are checked. Model/control snapshots restore on any failure before successful aggregate callbacks and resulting model/control validation. Stage and callback wrapper are cleared/restored in finally.',
        'server_commit': 'The successful on_weights_aggregated callback boundary plus model/control validation marks acceptance. Later evaluation/reporting failure keeps the accepted model/control state. External callback side effects and arbitrary network/in-flight state are outside this bounded rollback.',
        'client_acceptance': 'SCAFFOLD on_train_end computes provisional ci/delta without canonical write. Direct train_model now runs the training-step end hook before canonical acceptance, but still accepts before model-update cleanup; F27-R3-01 prevents claiming all failed direct calls leave canonical state unchanged.',
        'client_persistence': 'Canonical scaffold_cv_<client>.pkl atomically replaces the file only at on_train_result_accepted. Workers do not accept canonical state; train_process saves the model and current-token strategy handoff, and the parent checks token/client, loads both parts and accepts. Failed save/load/handoff/end paths checked here retain prior canonical state. Parent/current-token and direct control acceptance do not promise optimizer/RNG/full-server restart.',
        'ownership': 'Routine logical-client1->2->1 and fresh reconstruction adopt accepted canonical state. A manually injected in-memory ci with no accepted canonical file is not persisted by a rejected call; reconstruction may correctly have no ci and later zero initialization.',
        'math_and_configuration': 'No equation, TOML value, rate/K accounting, control filename or F20 objective changes since f977. Existing momentum/sample weighting extension boundaries and V2 Option II compatibility remain.',
        'prose_status': 'Standalone README/public prose is separately provisional/root-Astra-owned and was not edited or accepted by this review. Reconcile final facts after the remaining lifecycle correction and later integration.',
    },
    'original_probe_adaptations': {
        'receipt': artifact(S / 'adaptation-receipt.json'),
        'notes': artifact(S / 'harness-notes.json'),
        'original_callback': artifact(S / 'originals/callback_lifecycle_probe.py'),
        'adapted_callback': artifact(S / 'callback_lifecycle_probe.py'),
        'callback_adaptation_diff': artifact(S / 'callback_lifecycle_probe.py.adaptation.diff'),
        'policy': 'Original reviewer sources remain byte-for-byte untouched. All copied helpers pin this candidate/owned scratch. Callback expected outcomes alone were adapted from defect assertions to rejection/state-preservation assertions, with absent-file zero-init retry distinguished from explicit manual-ci retry. Other worker/direct/transport/numerical helper adaptations only change candidate/scratch locations.',
    },
    'reviewer_harness_limits': read('harness-notes.json'),
    'scope_limits': [
        'macOS ARM64 CPU PyTorch3.13.16/3.14.8, synthetic scalar/quadratic and actual configured direct/spawn processor/report flows. No dataset download, CUDA/MPS/native GPU, SCAFFOLD network transport or convergence benchmark.',
        'No generic FedAvg redesign, rollback of callback external effects/network state, or full round/evaluation rollback after an accepted server commit.',
        'FedDyn final implementation/math, accepted B resume supplement, D integration, whole Phase2C/Phase2 and final prose are outside acceptance scope.',
        'Broad mandatory profiles, native adapter stacks, fresh environment provisioning and full48 startup cases remain final combined root qualification. Existing author environments used read only.',
        'No universal transaction guarantee for arbitrary composed strategies or custom callbacks. The medium finding is a concrete public direct-call canonical persistence/reuse failure through the actual SCAFFOLD cleanup and acceptance code.',
    ],
    'required_next_step': 'Return F27-R3-01 to the original C author for the bounded lifecycle correction and regression, preserving accepted server/general/portable-fixture/math behavior; then obtain another fresh independent code review. Keep scratch through root integration and delivery.',
    'workflow': {'shell': 'All shell invocations zsh -lc, including subprocess commands.', 'agents_spawned': 0, 'source_edits': 0, 'commits': 0, 'cleanup': 0, 'environment_mutations': 0, 'only_root_write': str(DEST), 'owned_scratch': str(S), 'scratch_retained': True, 'source_clean_and_immutable': True},
    'retained_artifacts': [artifact(path) for path in sorted(S.iterdir()) if path.is_file() and path.name not in ['build_report.py', 'delivery-receipt.json']],
}
DEST.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
json.loads(DEST.read_text())
delivery = dict(report=artifact(DEST), decision=report['decision'],
                findings=[finding['id']], candidate=audit['head'], tree=audit['tree'],
                source_clean=git('status', '--short', '--ignored') == '',
                completed_at=datetime.now(timezone.utc).isoformat())
(S / 'delivery-receipt.json').write_text(json.dumps(delivery, indent=2) + '\n')
print(json.dumps(delivery, indent=2))
