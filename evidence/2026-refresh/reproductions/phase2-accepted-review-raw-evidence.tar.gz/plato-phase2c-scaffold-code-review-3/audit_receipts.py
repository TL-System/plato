from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import tomllib
import xml.etree.ElementTree as ET

SCRATCH = Path('/tmp/plato-phase2c-scaffold-code-review-3')
SOURCE = Path('/private/tmp/plato-refresh-worktrees/scaffold-review3')
ROOT = Path('/Users/bli/Playground/plato')
EVIDENCE = ROOT / 'evidence/2026-refresh'

def git(*args):
    return subprocess.check_output(['zsh', '-lc', shlex.join(['git', *args])], cwd=SOURCE).decode().strip()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def receipt(path):
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))

inputs = [receipt(ROOT / name) for name in [
    'AGENTS.md', 'evidence/2026-refresh/plan.md',
    'evidence/2026-refresh/plan-addendum.json',
    'evidence/2026-refresh/plan-addendum-acceptance.json',
    'evidence/2026-refresh/phase2c-scaffold-design.json',
    'evidence/2026-refresh/phase2c-scaffold-acceptance.json',
    'evidence/2026-refresh/phase2c-scaffold-code-review.json',
    'evidence/2026-refresh/phase2c-scaffold-code-review-2.json',
    'evidence/2026-refresh/phase2c-general-acceptance.json',
    'evidence/2026-refresh/phase2a-acceptance.json',
    'evidence/2026-refresh/phase2c-root-source-archive-probe.json',
    'evidence/2026-refresh/phase2c-root-intermediate-base-validation.json',
]]
for name in ['phase2c-scaffold-review2-fixes-validation.json',
             'phase2c-scaffold-review2-fixes-receipt.json',
             'phase2c-validation.json', 'phase2c-scaffold-facts.json']:
    inputs.append(receipt(SOURCE / 'evidence/2026-refresh' / name))
assert inputs[4]['sha256'] == 'f323f3aa9d824df44a1043b2d6aff9c8a963c42964f6e6685108c59b25fc3a89'
assert inputs[7]['sha256'] == 'aa00c76f5e3fbe3eb2f419ed277620c32f382b8dabb99f4a3e5c190308162eb1'

author = json.loads((SOURCE / 'evidence/2026-refresh/phase2c-scaffold-review2-fixes-validation.json').read_text())
body_receipt = json.loads((SOURCE / 'evidence/2026-refresh/phase2c-scaffold-review2-fixes-receipt.json').read_text())
body = SOURCE / body_receipt['evidence_file']
assert sha(body) == body_receipt['evidence_sha256']
assert git('rev-parse', body_receipt['evidence_body_commit'] + '^{tree}') == body_receipt['evidence_body_tree']
assert git('show', body_receipt['evidence_body_commit'] + ':' + body_receipt['evidence_file']) == body.read_text().strip()
source_receipts = []
for item in author['source_and_test_identities']:
    rel = item['path'].split('/training/', 1)[1]
    path = SOURCE / rel
    assert sha(path) == item['sha256']
    source_receipts.append(dict(relative_path=rel, **receipt(path), matches_author=True))

author_logs = []
for item in author['qualification']['commands'] + author['retained_failed_harness_attempts']['receipts']:
    path = Path(item['log'])
    actual = receipt(path)
    assert actual['sha256'] == item['sha256']
    actual.update(exit_code=item['exit_code'], summary=path.read_text().splitlines()[-1])
    author_logs.append(actual)
earlier = json.loads((EVIDENCE / 'phase2c-scaffold-code-review-2.json').read_text())
historical_logs = []
for item in earlier['author_evidence']['log_verification']:
    path = Path(item['path'])
    assert sha(path) == item['sha256']
    historical_logs.append(receipt(path))
for version in ['313', '314']:
    item = earlier['author_evidence']['startup'][version]['socket']
    path = Path(item['path'])
    assert sha(path) == item['sha256']
    historical_logs.append(receipt(path))

root_receipt = json.loads((EVIDENCE / 'phase2c-root-intermediate-base-validation.json').read_text())
root_logs = []
for item in root_receipt['receipts']:
    path = Path(item['path'])
    assert sha(path) == item['sha256']
    root_logs.append(receipt(path))
suites = ET.parse(root_receipt['receipts'][1]['path']).getroot().findall('.//testsuite')
assert sum(int(suite.get('tests')) for suite in suites) == 801
assert sum(int(suite.get('skipped')) for suite in suites) == 4
assert all(int(suite.get('failures')) == 0 and int(suite.get('errors')) == 0 for suite in suites)
archive = Path(root_receipt['source_archive'])
assert not (archive / '.git').exists()

manifest = []
for entry in git('ls-files', '--stage').splitlines():
    metadata, rel = entry.split('\t')
    mode, blob, stage = metadata.split()
    if mode == '160000':
        continue
    path = SOURCE / rel
    raw = str(path.readlink()).encode() if mode == '120000' else path.read_bytes()
    actual_blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    assert actual_blob == blob, rel
    assert (archive / rel).read_bytes() == raw, rel
    manifest.append(dict(path=rel, git_blob=blob, sha256=hashlib.sha256(raw).hexdigest()))

a_paths = git('diff', '--name-only', 'fda60becedfa6236c11d415b87a868b52789a41e', '79da1f97d8a12fe97402750cc32c7b3e8f5cdf6e').splitlines()
a_blobs = []
for rel in a_paths:
    original = git('ls-tree', '79da1f97d8a12fe97402750cc32c7b3e8f5cdf6e', '--', rel)
    candidate = git('ls-tree', 'HEAD', '--', rel)
    assert original == candidate, rel
    a_blobs.append(dict(path=rel, entry=original or 'deleted in both'))
assert len(a_blobs) == 48

config = 'examples/customized_client_training/scaffold/scaffold_MNIST_lenet5.toml'
assert tomllib.loads(git('show', '00eeb9dcdd2b513e64db9408969356037e09bb8e:' + config)) == tomllib.loads((SOURCE / config).read_text())
post = git('diff', '--name-only', '0f17708afefde13eeba1fd71578258b68c5911ee', 'HEAD').splitlines()
assert len(post) == 2 and all(path.startswith('evidence/') for path in post)
preserved_paths = [
    'plato/servers/base.py', 'tests/integration/test_event_loop_startup.py',
    'tests/integration/startup_harness.py', 'tests/integration/startup_probe.py',
    'plato/trainers/strategies/algorithms/scaffold_strategy.py',
    'plato/trainers/strategies/algorithms/fedprox_strategy.py',
    'plato/trainers/strategies/algorithms/fedala_strategy.py',
    'plato/trainers/strategies/algorithms/feddyn_strategy.py',
    'plato/trainers/strategies/training_step.py',
    'plato/trainers/strategies/optimizer.py', 'plato/trainers/base.py',
]
for rel in preserved_paths:
    assert git('rev-parse', 'f9772f61d52dfe0f4a3281252d23b8303ec237d2:' + rel) == git('rev-parse', 'HEAD:' + rel), rel

result = dict(inputs=inputs, author_source_receipts=source_receipts,
              author_logs=author_logs, historical_author_logs=historical_logs,
              root_archive_logs=root_logs, root_archive_source_files=len(manifest),
              tracked_source_files=len(manifest), all_tracked_match_git=True,
              a_blobs=a_blobs, a_blobs_unchanged=len(a_blobs),
              preserved_from_f977=preserved_paths, only_post_implementation_files=post,
              shipped_TOML_values_unchanged=True, status=git('status', '--short', '--ignored'),
              head=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'),
              detached=not bool(git('branch', '--show-current')))
assert result['status'] == ''
(SCRATCH / 'source-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(SCRATCH / 'receipt-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key not in [
    'inputs', 'author_source_receipts', 'author_logs', 'historical_author_logs',
    'root_archive_logs', 'a_blobs', 'preserved_from_f977']}, indent=2))
