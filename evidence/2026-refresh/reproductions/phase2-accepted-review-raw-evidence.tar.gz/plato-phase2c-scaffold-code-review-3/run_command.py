import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time

scratch = Path('/tmp/plato-phase2c-scaffold-code-review-3')
source = Path('/private/tmp/plato-refresh-worktrees/scaffold-review3')
label, *command = sys.argv[1:]
env = dict(os.environ)
env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(source),
           OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTEST_ADDOPTS='',
           TMPDIR=str(scratch/'tmp'), XDG_CACHE_HOME=str(scratch/'cache'),
           MPLCONFIGDIR=str(scratch/'mpl'),
           RUFF_CACHE_DIR=str(scratch/'ruff-cache'))
log = scratch/f'{label}.log'
started = time.time()
with log.open('w') as output:
    try:
        result = subprocess.run(['zsh', '-lc', shlex.join(command)],
                                cwd=source, env=env, stdout=output,
                                stderr=subprocess.STDOUT, timeout=600)
        status = result.returncode
    except subprocess.TimeoutExpired:
        status = 'TIMEOUT'
record = dict(label=label, command=shlex.join(command), shell=['zsh', '-lc'],
              cwd=str(source), env_overrides={k:env[k] for k in
                ['PYTHONDONTWRITEBYTECODE', 'PYTHONPATH', 'OMP_NUM_THREADS',
                 'MKL_NUM_THREADS', 'PYTEST_ADDOPTS', 'TMPDIR',
                 'XDG_CACHE_HOME', 'MPLCONFIGDIR', 'RUFF_CACHE_DIR']},
              exit_code=status, duration_seconds=time.time()-started,
              deadline_seconds=600, raw_log=str(log),
              raw_bytes=log.stat().st_size,
              raw_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
(scratch/f'{label}.command.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record, indent=2))
print('\n'.join(log.read_text().splitlines()[-10:]))
