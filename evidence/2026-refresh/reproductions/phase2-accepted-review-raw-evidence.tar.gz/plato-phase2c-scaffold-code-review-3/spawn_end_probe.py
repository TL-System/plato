"""Spawned fallible end/cleanup with existing and absent accepted controls."""
import json,pickle,sys
from pathlib import Path
import independent_checks as p
from plato.trainers.strategies.training_step import GradientAccumulationStepStrategy

class EndFailure(GradientAccumulationStepStrategy):
    def on_train_end(self,ctx):
        super().on_train_end(ctx)
        raise RuntimeError('Independent spawned training-step end failure')

class CleanupFailure(p.SCAFFOLDUpdateStrategy):
    def on_train_cleanup(self,ctx,successful):
        super().on_train_cleanup(ctx,successful)
        if successful:raise RuntimeError('Independent spawned cleanup failure')

if __name__=='__main__':
    v=f'{sys.version_info.major}{sys.version_info.minor}';records=[]
    for mode in ['end','cleanup']:
        for existing in [False,True]:
            root=p.SCRATCH/f'spawn-end-{v}'/f'{mode}-{existing}';root.mkdir(parents=True,exist_ok=True)
            with p.configure_environment(p.config(spawn=True),runtime_root=root):
                client=p.client(1);tr=client.trainer;st=tr.model_update_strategy
                st.client_control_variate=p.controls(1)
                canonical=Path(st.client_control_variate_path)
                if existing:canonical.write_bytes(pickle.dumps(p.controls(1)))
                before=canonical.read_bytes() if canonical.exists() else None
                if mode=='end':tr.training_step_strategy=EndFailure(1)
                else:st.__class__=CleanupFailure
                error=None
                try:p.train_round(client,[p.controls(1),p.controls(2)],1,0.,2)
                except RuntimeError as exc:error=str(exc)
                assert error and 'successful current-round' in error
                assert client._context.state.get('training_error') is not None
                p.close(st.client_control_variate['theta'].item(),1)
                assert (canonical.read_bytes() if canonical.exists() else None)==before
                assert tr.context.state.get('client_control_variate_delta') is None
                for cid in [2,1]:
                    client.client_id=client._context.client_id=cid;client.configure()
                fresh=p.client(1).trainer.model_update_strategy.client_control_variate
                if existing:p.close(fresh['theta'].item(),1)
                else:
                    assert fresh is None
                    st.client_control_variate=p.controls(1)
                tr.training_step_strategy=GradientAccumulationStepStrategy(1);st.__class__=p.SCAFFOLDUpdateStrategy
                retry=p.train_round(client,[p.controls(1),p.controls(2)],2,0.,2)
                p.close(tr.model.theta.item(),.62);p.close(st.client_control_variate['theta'].item(),.9);p.close(retry.payload[1]['theta'].item(),-.1)
                records.append(dict(mode=mode,existing_canonical=existing,canonical_preserved=True,outbound_refused=True,parent_ci_after_failure=1,reconstructed_ci=1 if existing else None,retry=dict(y=tr.model.theta.item(),ci=st.client_control_variate['theta'].item(),delta=retry.payload[1]['theta'].item())))
    result=dict(python=sys.version,cases=records,count=len(records))
    (p.SCRATCH/f'spawn-end-{v}.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
