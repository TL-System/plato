"""Real finite-input arithmetic overflow and callback zero-weight rejection."""
import asyncio,copy,json,sys
from types import SimpleNamespace
import independent_checks as p
import torch
from plato.callbacks.server import ServerCallback
from plato.servers.strategies.aggregation.fedavg import FedAvgAggregationStrategy

class DeltasOnly(FedAvgAggregationStrategy):
    async def aggregate_weights(self,*args,**kwargs):
        return None

class Mutate(ServerCallback):
    def __init__(self,position):self.position=position
    def on_weights_received(self,server,weights):weights[self.position]['theta'].fill_(float('nan'))

v=f'{sys.version_info.major}{sys.version_info.minor}'
records=[]
for mode in ['control-sum-overflow','model-delta-overflow','zero-weight-callback-first','zero-weight-callback-second']:
    root=p.SCRATCH/f'arithmetic-{v}'/mode;root.mkdir(parents=True,exist_ok=True)
    with p.configure_environment(p.config(),runtime_root=root):
        client=p.client(1);client.trainer.model_update_strategy.client_control_variate=p.controls(1)
        report=p.train_round(client,[p.controls(1),p.controls(2)],1,0.,2).report
        server=p.server();server.server_control_variate=p.controls(2)
        if mode=='model-delta-overflow':
            server.trainer.model.theta.data.fill_(1e308)
            server.aggregation_strategy=DeltasOnly()
        before=copy.deepcopy(server.trainer.model.state_dict());before_c=copy.deepcopy(server.server_control_variate)
        server.updates=[SimpleNamespace(report=copy.copy(report),payload=[p.controls(y),p.controls(dc)]) for y,dc in [(7,3),(9,4)]]
        if mode=='control-sum-overflow':
            for u in server.updates:u.payload[1]=p.controls(1e308)
        if mode=='model-delta-overflow':
            for u in server.updates:u.payload[0]=p.controls(-1e308)
        handler=server.callback_handler
        if mode.startswith('zero-weight'):
            pos=0 if mode.endswith('first') else 1
            server.updates[pos].report.num_samples=0
            handler.add_callback(Mutate(pos))
        raw=[p.serialize_tree(u.payload) for u in server.updates]
        assert all(torch.isfinite(t).all() for u in server.updates for d in u.payload for t in d.values())
        error=None
        try:asyncio.run(server._process_reports())
        except ValueError as exc:error=str(exc)
        assert error is not None
        assert server.callback_handler is handler
        torch.testing.assert_close(server.trainer.model.state_dict(),before)
        torch.testing.assert_close(server.server_control_variate,before_c)
        assert server._pending_control_variate is None and server.received_client_control_variates is None
        assert raw==[p.serialize_tree(u.payload) for u in server.updates]
        records.append(dict(mode=mode,error=error,state_preserved=True,stage_cleared=True,raw_unchanged=True))
result=dict(python=sys.version,cases=records,count=len(records))
(p.SCRATCH/f'arithmetic-{v}.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
