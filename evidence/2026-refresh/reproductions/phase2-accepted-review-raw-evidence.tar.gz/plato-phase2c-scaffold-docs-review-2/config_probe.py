import hashlib
import json
import os
import pathlib
import sys

import plato.config as config_module
from plato.config import Config

SOURCE = pathlib.Path('/private/tmp/plato-refresh-worktrees/scaffold-docs-review2')
SCRATCH = pathlib.Path('/tmp/plato-phase2c-scaffold-docs-review-2').resolve()
assert pathlib.Path(config_module.__file__).resolve() == SOURCE / 'plato/config.py'
assert pathlib.Path.cwd() in (SOURCE, SOURCE / 'examples/customized_client_training')
config = Config()
base = pathlib.Path(config.args.base).resolve()
assert base.is_relative_to(SCRATCH)
expected = SOURCE / 'examples/customized_client_training/scaffold/scaffold_MNIST_lenet5.toml'
assert config.config_path.resolve() == expected
assert config.clients.total_clients == 5 and config.clients.per_round == 2
assert config.trainer.epochs == 3 and config.trainer.rounds == 5
assert config.trainer.max_concurrency == 2
assert config.trainer.model_name == 'lenet5' and config.trainer.optimizer == 'SGD'
assert config.parameters.optimizer._asdict() == {'lr': 0.01, 'momentum': 0.9, 'weight_decay': 0.0}
assert config.data.datasource == 'Torchvision' and config.data.dataset_name == 'MNIST'
assert config.data.download is True
paths = {k: v for k, v in config.params.items() if k.endswith('_path')}
for value in paths.values():
    assert pathlib.Path(value).resolve().is_relative_to(base), (value, base)
assert 'torchvision' not in sys.modules and 'plato.datasources.registry' not in sys.modules
print(json.dumps({
    'argv': sys.argv, 'cwd': os.getcwd(), 'python': sys.version,
    'source_module': config_module.__file__, 'config': str(config.config_path.resolve()),
    'config_sha256': hashlib.sha256(expected.read_bytes()).hexdigest(),
    'cpu': config.args.cpu, 'base': str(base), 'runtime_paths': paths,
    'settings': config.config._asdict(), 'scope': 'Config parsing only; no dataset or trainer invoked',
}, indent=2))
