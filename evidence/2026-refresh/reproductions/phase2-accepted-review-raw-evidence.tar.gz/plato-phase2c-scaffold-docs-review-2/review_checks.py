import hashlib
import html.parser
import importlib.metadata
import io
import json
import os
import pathlib
import re
import shlex
import subprocess
import sys
import tarfile
import time
from fractions import Fraction

import markdown
import yaml

SOURCE = pathlib.Path('/private/tmp/plato-refresh-worktrees/scaffold-docs-review2')
SCRATCH = pathlib.Path('/tmp/plato-phase2c-scaffold-docs-review-2')
BASE = '15e0cebd78ec6752b9aae1e922b33e22e168387f'
CANDIDATE = 'eed4bfa23edc37cf41b598fc976b281e141756c4'
TREE = 'cb7625432aa785598d89343d78e4f518449d2061'
PRIOR = '95c7218fc9801099cd7ffa3afc1be227384d8500'
MERGE = '1c5a5893f446a4208ffe44c083c248a9bcd38ad3'
README = 'examples/customized_client_training/scaffold/README.md'
DOC = 'docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md'
EVIDENCE = 'evidence/2026-refresh/phase2c-scaffold-docs-validation.json'
PYTHON = '/tmp/plato-phase2c-scaffold-docs/venv/bin/python'
records = []
env = dict(os.environ)
env.pop('config_file', None)
env.update({
    'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPATH': str(SOURCE),
    'XDG_CACHE_HOME': str(SCRATCH/'cache'), 'UV_CACHE_DIR': str(SCRATCH/'uv-cache'),
    'TMPDIR': str(SCRATCH/'tmp'), 'MPLCONFIGDIR': str(SCRATCH/'mpl'),
    'RUFF_CACHE_DIR': str(SCRATCH/'ruff-cache'), 'GIT_OPTIONAL_LOCKS': '0',
})
for name in ('tmp', 'cache', 'uv-cache', 'mpl', 'ruff-cache'):
    (SCRATCH/name).mkdir(exist_ok=True)

def run(label, args, cwd=SOURCE, expected=0, binary=False, timeout=60):
    command = 'env -u config_file ' + ' '.join(shlex.quote(k+'='+v) for k,v in env.items()
        if k in ('PYTHONDONTWRITEBYTECODE','PYTHONPATH','XDG_CACHE_HOME','UV_CACHE_DIR',
            'TMPDIR','MPLCONFIGDIR','RUFF_CACHE_DIR','GIT_OPTIONAL_LOCKS'))
    command += ' ' + shlex.join(args)
    start = time.monotonic()
    result = subprocess.run(['zsh', '-lc', command], cwd=cwd, env=env,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
    suffix = '.bin' if binary else '.log'
    stdout = SCRATCH/(label+suffix)
    stderr = SCRATCH/(label+'.stderr.log')
    stdout.write_bytes(result.stdout)
    stderr.write_bytes(result.stderr)
    records.append({'label':label, 'command': command, 'shell':['zsh','-lc'],
        'cwd':str(cwd), 'exit_code':result.returncode,
        'seconds':round(time.monotonic()-start,3), 'timeout_seconds':timeout,
        'stdout':str(stdout), 'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),
        'stderr':str(stderr), 'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()})
    (SCRATCH/'command-records.json').write_text(json.dumps(records,indent=2)+'\n')
    assert result.returncode == expected, (label, result.returncode, result.stderr.decode())
    return result.stdout if binary else (result.stdout+result.stderr).decode()

def git(label, *args, binary=False):
    return run(label, ['git', *args], binary=binary)

def tree(revision):
    result = {}
    for entry in git('tree-'+revision[:7], 'ls-tree','-rz',revision,binary=True).split(b'\0'):
        if entry:
            metadata, path = entry.split(b'\t',1)
            mode, kind, blob = metadata.decode().split()
            result[path.decode()] = {'mode':mode,'kind':kind,'blob':blob}
    return result

assert pathlib.Path.cwd() == SOURCE
assert git('identity', 'rev-parse','HEAD','HEAD^{tree}').splitlines() == [CANDIDATE,TREE]
assert git('status-before','status','--porcelain=v1') == ''
assert git('merge-parents','show','-s','--format=%P',MERGE).strip().split() == [PRIOR,BASE]
git('merge-is-ancestor','merge-base','--is-ancestor',MERGE,CANDIDATE)
baseline = tree(BASE)
candidate = tree(CANDIDATE)
changed = sorted(p for p in baseline.keys() | candidate.keys() if baseline.get(p) != candidate.get(p))
assert changed == sorted([README,DOC,EVIDENCE]), changed
mismatches = []
manifest = {}
for name,item in candidate.items():
    path = SOURCE/name
    if item['kind'] != 'blob': continue
    data = os.readlink(path).encode() if item['mode']=='120000' else path.read_bytes()
    blob = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    if blob != item['blob']: mismatches.append(name)
    manifest[name] = {**item, 'sha256':hashlib.sha256(data).hexdigest(), 'bytes':len(data)}
assert not mismatches, mismatches
(SCRATCH/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
git('diff-check','diff','--check',BASE,CANDIDATE)
git('diff-from-code-base','diff',BASE,CANDIDATE,'--',README,DOC,EVIDENCE)
git('diff-from-prior-prose','diff',PRIOR,CANDIDATE,'--',README,DOC)
current_doc = (SOURCE/DOC).read_text()
prior_doc = git('prior-public-doc','show',PRIOR+':'+DOC)
base_doc = git('base-public-doc','show',BASE+':'+DOC)
suffix = '\n---\n\n### FedProx'
assert current_doc.split(suffix,1)[1] == prior_doc.split(suffix,1)[1] == base_doc.split(suffix,1)[1]
suffix_data=current_doc.split(suffix,1)[1].encode()
non_doc_unchanged=[p for p in candidate if p not in (README,DOC,EVIDENCE)]
code_count=sum(p.startswith('plato/') for p in non_doc_unchanged)
test_count=sum(p.startswith('tests/') for p in non_doc_unchanged)

extensions=[]; configs={}
for item in yaml.safe_load((SOURCE/'docs/mkdocs.yml').read_text())['markdown_extensions']:
    if isinstance(item,str): extensions.append(item)
    else:
        for name,cfg in item.items(): extensions.append(name); configs[name]=cfg or {}
extensions.extend(['fenced_code'])

class Inspector(html.parser.HTMLParser):
    def __init__(self): super().__init__(); self.math=0; self.block_math=0; self.code=0; self.links=[]; self.admonition=0
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs); classes=attrs.get('class','').split()
        if 'arithmatex' in classes:
            self.math+=1; self.block_math+=int(tag=='div')
        if tag=='code': self.code+=1
        if tag=='a': self.links.append(attrs.get('href'))
        if 'admonition' in classes: self.admonition+=1

rendered={}
for label,prose in [('readme',(SOURCE/README).read_text()),('scaffold-section',current_doc.split(suffix,1)[0])]:
    html=markdown.markdown(prose,extensions=extensions,extension_configs=configs)
    (SCRATCH/(label+'.html')).write_text(html)
    inspector=Inspector(); inspector.feed(html)
    assert inspector.math>0 and inspector.code>0
    assert 'https://arxiv.org/pdf/1910.06378v4' in inspector.links
    assert '$' not in html and '!!!' not in html
    assert inspector.admonition == (1 if label=='scaffold-section' else 0)
    if label=='readme': assert inspector.block_math==3
    rendered[label]={'math_elements':inspector.math,'display_math_elements':inspector.block_math,
        'code_elements':inspector.code,'admonitions':inspector.admonition,
        'links':inspector.links,'html_sha256':hashlib.sha256(html.encode()).hexdigest()}

commands=[]
for label,text,cwd in [('readme',(SOURCE/README).read_text(),SOURCE),
        ('public-doc',current_doc.split(suffix,1)[0],SOURCE/'examples/customized_client_training')]:
    block=re.search(r'```bash\n(.*?)```',text,re.S)[1].replace('\\\n',' ')
    command=next(line for line in block.splitlines() if line.startswith('uv run '))
    tokens=shlex.split(command); assert tokens[:3]==['uv','run','python']
    entrypoint=(cwd/tokens[3]).resolve(); config_path=(cwd/tokens[tokens.index('-c')+1]).resolve()
    assert entrypoint==SOURCE/'examples/customized_client_training/scaffold/scaffold.py'
    assert config_path==SOURCE/'examples/customized_client_training/scaffold/scaffold_MNIST_lenet5.toml'
    assert entrypoint.is_file() and config_path.is_file()
    commands.append({'location':label,'command':command,'cwd':str(cwd),
        'entrypoint':str(entrypoint),'configuration':str(config_path)})
    for cpu in (False,True):
        probe_label='config-'+label+('-cpu' if cpu else '-default-device')
        args=[PYTHON,str(SCRATCH/'config_probe.py'),'-c',tokens[tokens.index('-c')+1],
            '-b',str(SCRATCH/probe_label)]
        if cpu: args.append('--cpu')
        result=json.loads(run(probe_label,args,cwd=cwd))
        assert result['cpu'] is cpu

# Independent exact arithmetic checks the prose's telescope identity, not production execution.
oracle=[]
for gradients in ((0,),(3,1)):
    x=Fraction(1); y=x; ci=Fraction(1); c=Fraction(2); eta=Fraction(1,10)
    for g in gradients: y-=eta*(g-ci+c)
    new=ci-c+(x-y)/(len(gradients)*eta)
    assert new==sum(gradients)/len(gradients)
    oracle.append({'gradients':gradients,'y':str(y),'ci_new':str(new),'delta':str(new-ci)})

archive=git('baseline-docs-archive','archive',BASE,'docs',binary=True)
baseline_dir=SCRATCH/'baseline'
baseline_dir.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(archive)) as tar: tar.extractall(baseline_dir,filter='data')
base_log=run('mkdocs-baseline',[PYTHON,'-m','mkdocs','build','--strict','-f',
    str(baseline_dir/'docs/mkdocs.yml'),'-d',str(SCRATCH/'baseline-site')],expected=1)
current_log=run('mkdocs-candidate',[PYTHON,'-m','mkdocs','build','--strict',
    '-f','docs/mkdocs.yml','-d',str(SCRATCH/'candidate-site')],expected=1)
def warnings(log): return [line for line in log.splitlines() if line.startswith('WARNING')]
assert warnings(base_log)==warnings(current_log), (warnings(base_log),warnings(current_log))
assert len(warnings(current_log))==2 and all('Nanochat' in line for line in warnings(current_log))
assert not any('scaffold' in line.lower() for line in warnings(current_log))
run('primary-paper-fetch',['curl','--fail','--location','--silent','--show-error','--max-time','45',
    'https://arxiv.org/pdf/1910.06378v4','-o',str(SCRATCH/'primary-paper.pdf')])
paper_hash=hashlib.sha256((SCRATCH/'primary-paper.pdf').read_bytes()).hexdigest()
assert paper_hash=='efe06c86acc7a06116e372a7ab6386c300f4d0dc9c7ba2dd5c82e95111a1d694'
assert git('status-after','status','--porcelain=v1')==''
result={
    'environment':{'python':sys.version,'executable':sys.executable,
        'packages':{p:importlib.metadata.version(p) for p in ('mkdocs','mkdocs-material','Markdown','pymdown-extensions','numpy','munch')},
        'env_overrides':{k:env[k] for k in ('PYTHONDONTWRITEBYTECODE','PYTHONPATH','XDG_CACHE_HOME','UV_CACHE_DIR','TMPDIR','MPLCONFIGDIR','RUFF_CACHE_DIR','GIT_OPTIONAL_LOCKS')}},
    'identity':{'commit':CANDIDATE,'tree':TREE,'baseline':BASE,'changed_paths':changed,
        'candidate_blobs_verified':len(manifest),'unchanged_paths_from_baseline':len(non_doc_unchanged),
        'plato_files_unchanged':code_count,'test_files_unchanged':test_count,'working_tree_mismatches':mismatches,
        'non_scaffold_suffix_sha256':hashlib.sha256(suffix_data).hexdigest()},
    'rendering':rendered,'documented_commands':commands,'config_probes':4,
    'arithmetic_oracle':oracle,'strict_mkdocs':{'baseline_exit':1,'candidate_exit':1,
        'warnings':warnings(current_log),'new_scaffold_warnings':0,'strict_build_pass':False},
    'primary_paper_sha256':paper_hash,'executions':records,
}
(SCRATCH/'checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('executions','environment')},indent=2))
