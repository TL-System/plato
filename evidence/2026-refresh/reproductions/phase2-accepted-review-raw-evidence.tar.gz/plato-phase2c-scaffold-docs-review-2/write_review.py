import datetime
import hashlib
import json
import pathlib
import shlex
import subprocess

S = pathlib.Path('/tmp/plato-phase2c-scaffold-docs-review-2')
SOURCE = pathlib.Path('/private/tmp/plato-refresh-worktrees/scaffold-docs-review2')
ROOT = pathlib.Path('/Users/bli/Playground/plato')
OUT = ROOT/'evidence/2026-refresh/phase2c-scaffold-docs-review-2.json'
CANDIDATE = 'eed4bfa23edc37cf41b598fc976b281e141756c4'
TREE = 'cb7625432aa785598d89343d78e4f518449d2061'
BASE = '15e0cebd78ec6752b9aae1e922b33e22e168387f'
README = 'examples/customized_client_training/scaffold/README.md'
DOC = 'docs/docs/examples/algorithms/5. Algorithms with Customized Client Training Loops.md'
checks = json.loads((S/'checks.json').read_text())
manifest = json.loads((S/'source-manifest.json').read_text())
writer = json.loads((S/'phase2c-scaffold-docs-validation.json').read_text())
author = json.loads((S/'phase2c-scaffold-review2-fixes-validation.json').read_text())
root_receipt = json.loads((S/'phase2c-root-intermediate-base-validation.json').read_text())
code_review3 = json.loads((S/'phase2c-scaffold-code-review-3.json').read_text())

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(S/'phase2c-scaffold-code-review-3.json') == '63d4969b6bff08e51bde979eb3d8ac61289ca539e1332b3ac96a8ceeda6010dd'
def ref(path,line,end=None):
    value={'path':path,'line':line}
    if end is not None: value['end_line']=end
    return value
def assessment(subject,docs,source,basis):
    return {'subject':subject,'result':'PASS','documentation':docs,'pinned_source':source,'basis':basis}

review = {
    'schema_version':1,
    'date':'2026-10-03',
    'written_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'role':'Fresh independent SCAFFOLD writing reviewer; requested Sol xhigh; no nested agents.',
    'review_type':'Writing accuracy, clarity, scope and bounded documentation validation against immutable implementation.',
    'decision':'PASS',
    'acceptance':'PROVISIONAL_WRITING_PASS_ONLY',
    'final_documentation_acceptance':False,
    'code_acceptance':False,
    'finding':'F27',
    'summary':
        'No material writing findings on exact candidate eed4bfa23edc37cf41b598fc976b281e141756c4. '
        'Both public SCAFFOLD documents express the intended accepted contract, including provisional '
        'client controls, acceptance after all end hooks, and the bounded server callback commit boundary. '
        'Fresh code review3 confirms server callback corrections but identifies one remaining medium direct-cleanup '
        'acceptance gap in 15e (F27-R3-01), explicitly retained below; complete failure-atomic runtime behavior is not claimed. '
        'Commands, equations, defaults, filenames and unrelated algorithm sections are preserved. '
        'This provisional writing PASS does not close prior code findings, accept C or the combined phase candidate, '
        'or override completed code-review3 failure. Corrected-source fresh code review and final-source reconciliation remain required.',
    'finding_counts':{'critical':0,'high':0,'medium':0,'low':0},
    'findings':[],
    'low_priority_suggestions':[],
    'identities':{
        'candidate_commit':CANDIDATE,'candidate_tree':TREE,'detached_worktree':str(SOURCE),
        'implementation_base_commit':BASE,'implementation_base_tree':'9c9ce313f88552968b487388d681eda82384abfc',
        'writer_dependency_merge':'1c5a5893f446a4208ffe44c083c248a9bcd38ad3',
        'writer_merge_parents':['95c7218fc9801099cd7ffa3afc1be227384d8500',BASE],
        'initial_prose_commit':'95c7218fc9801099cd7ffa3afc1be227384d8500',
        'initial_prose_review_code_base':'0dc34dd1d79d90071a0babfa6aa89f33d72a976f',
        'author_executed_implementation':'0f17708afefde13eeba1fd71578258b68c5911ee',
        'accepted_A_ancestor':'79da1f97d8a12fe97402750cc32c7b3e8f5cdf6e',
        'accepted_B_ancestor':'00eeb9dcdd2b513e64db9408969356037e09bb8e',
        'all_identities_and_ancestry_verified':True,
    },
    'scope_and_unchanged_code_proof':{
        'candidate_diff_from_15e':checks['identity']['changed_paths'],
        'exactly_three_paths_changed':True,
        'candidate_tree_entries':984,'candidate_blobs_verified_against_worktree':981,
        'unchanged_entries_from_15e':981,'unchanged_blobs_from_15e':978,'unchanged_gitlinks_from_15e':3,
        'baseline_blobs':979,
        'production_plato_paths_identical':220,'test_paths_identical':97,
        'all_other_example_config_manifest_and_source_paths_identical':True,
        'worktree_blob_mismatches':[],
        'unrelated_sections':{
            'comparison':'Suffix beginning at the separator before ### FedProx matches both immutable 15e and 95c byte-for-byte.',
            'candidate_public_doc_boundary':ref(DOC,86),
            'preserved_sections':['FedProx','FedDyn','MOON','FedMoS'],
            'suffix_sha256':checks['identity']['non_scaffold_suffix_sha256'],
            'FedDyn_correctness_reviewed':False,
        },
        'prior_prose_delta':'Only the direct/spawn acceptance paragraph and new bounded server-validation/commit paragraph change in each document. Commands, formulas and the other prose match 95c.',
        'author_execution_identity':'git diff --name-status 0f17708afefde13eeba1fd71578258b68c5911ee 15e0cebd78ec6752b9aae1e922b33e22e168387f contains only the two new author evidence JSON files; production and tests unchanged.',
        'git_diff_check_exit_code':0,'git_status_before_and_after':'clean',
        'source_manifest':{'path':str(S/'source-manifest.json'),'sha256':digest(S/'source-manifest.json')},
        'diffs_retained':[str(S/'diff-from-code-base.log'),str(S/'diff-from-prior-prose.log'),str(S/'impl-to-base-proof.log')],
    },
    'documentation_identities':{name:manifest[name] for name in (README,DOC,'evidence/2026-refresh/phase2c-scaffold-docs-validation.json')},
    'inputs':[
        {'path':str(ROOT/'AGENTS.md'),'sha256':digest(S/'ROOT-AGENTS.md'),'retained_copy':str(S/'ROOT-AGENTS.md')},
        *[{'path':str(ROOT/'evidence/2026-refresh'/name),'sha256':digest(S/name),'retained_copy':str(S/name)}
            for name in ('phase2c-scaffold-design.json','phase2c-scaffold-design-review.json',
                'phase2c-scaffold-acceptance.json','phase2c-scaffold-docs-review.json',
                'phase2c-scaffold-code-review.json','phase2c-scaffold-code-review-2.json',
                'phase2c-root-intermediate-base-validation.json','phase2c-scaffold-code-review-3.json')],
        *[{'path':name,'revision':CANDIDATE,'sha256':manifest[name]['sha256'],'retained_copy':str(S/pathlib.Path(name).name)}
            for name in ('evidence/2026-refresh/phase2c-scaffold-docs-validation.json',
                'evidence/2026-refresh/phase2c-scaffold-review2-fixes-validation.json',
                'evidence/2026-refresh/phase2c-scaffold-review2-fixes-receipt.json')],
    ],
    'writer_evidence_verification':{
        'all_consulted_source_git_blobs_and_sha256_matched':True,
        'all_documentation_sha256_matched':True,'all_listed_input_sha256_matched':True,
        'status_is_honest':'At its authored snapshot candidate evidence says provisional reconciliation to exact 15e and pending review3/final acceptance; it does not claim reviewer or code acceptance. Review3 is now completed CHANGES_REQUIRED/FAIL, superseding that pending status.',
        'root_receipts_and_author_counts_are_explicitly_external':True,
    },
    'primary_source':{
        'title':'Karimireddy et al., SCAFFOLD: Stochastic Controlled Averaging for Federated Learning',
        'url':'https://arxiv.org/pdf/1910.06378v4','revision':'v4, 9 April 2021',
        'method':'Independently opened official PDF with web tool and read Algorithm 1 and equations 3-5; independently fetched exact PDF bytes with curl.',
        'locations':['PDF page 4: Algorithm 1 lines 10,12,16-17 and equation 3','PDF page 5: equations 4-5','PDF page 26: appendix E equation 19, checked as sign discrepancy only'],
        'retained_pdf':str(S/'primary-paper.pdf'),'sha256':checks['primary_paper_sha256'],
        'interpretation':'Main algorithm gives the subtractive local correction and ci-c displacement formula; population c uses 1/N, whereas model averaging uses 1/|S| with global rate. Appendix 19 reverses the two control terms. The algebraic telescope and counterexample identify that discrepancy independently; it is not adopted as the implementation oracle.',
        'independent_arithmetic':checks['arithmetic_oracle'],
        'oracle_limit':'Exact Fraction arithmetic validates the writing equations only; no production trainer/strategy or research experiment executed by this writing reviewer.',
    },
    'claim_assessment':[
        assessment('Correct Option II equations, sign and gradient-average identity',
            [ref(README,24,44),ref(DOC,25,35)],
            [ref('plato/trainers/strategies/algorithms/scaffold_strategy.py',258,309)],
            'after_step adds correction with alpha=-executed_rate; on_train_end uses old ci minus c plus displacement/(local_steps*rate), then subtracts old ci for delta. The main paper and independent telescope agree. The mean-gradient claim is explicitly bounded to constant-rate vanilla SGD.'),
        assessment('V2 compatibility and Option I boundary',
            [ref(README,45,47),ref(DOC,34,35)],
            [ref('plato/trainers/strategies/algorithms/scaffold_strategy.py',415,421)],
            'V2 inherits corrected Option II without a separate accumulator or extra gradient pass. The prose retains the public name and does not promise true Option I or improved accuracy.'),
        assessment('Actual optimizer rate constraints and timing',
            [ref(README,49,54),ref(DOC,37,43)],
            [ref('plato/trainers/strategies/algorithms/scaffold_strategy.py',186,256),ref('plato/trainers/composable.py',563,571)],
            'The actual optimizer is published in context; a step pre-hook captures finite positive non-tensor scalar rates for groups owning trainable model parameters. Equal rates and constant rate within a local round are enforced before the affected step, with a new round reset. The correction uses the captured executed rate after later optimizer hooks.'),
        assessment('Actual K, accumulation tail, skipped/zero updates and trainable ownership',
            [ref(README,56,62),ref(DOC,41,44)],
            [ref('plato/trainers/strategies/algorithms/scaffold_strategy.py',211,309),ref('plato/trainers/composable.py',629,673),ref('plato/trainers/composable.py',699,729),ref('plato/trainers/strategies/training_step.py',158,185)],
            'Only completed optimizer updates increment local_steps. A partial accumulation window normalizes its actual microbatch count and steps once; skipped steps do not correct/count. K=0 clones retained controls and generates fresh zeros. Parameter identity includes optimizer-owned trainables with no gradient; excluded trainables retain controls and have zero delta; frozen parameters and buffers receive no SCAFFOLD correction.'),
        assessment('Population control update and separate sample-weighted model extension',
            [ref(README,75,89),ref(DOC,46,53)],
            [ref('examples/customized_client_training/scaffold/scaffold_server.py',70,98),ref('plato/servers/strategies/aggregation/fedavg.py',97,132)],
            'Server sums unweighted control deltas over the total client population. FedAvg separately weights models by positive total sample counts. The README conditions its explicit model formula on positive total count. Unequal counts and shipped momentum .9 are described as extensions with no imported paper convergence guarantee.'),
        assessment('Momentum/Adam and other non-vanilla optimizer caveat; independent oracle attribution',
            [ref(README,26,27),ref(README,86,89),ref(DOC,50,53)],
            [ref('plato/trainers/strategies/algorithms/scaffold_strategy.py',199,209),ref('tests/trainers/test_scaffold_strategy.py',59,87),ref('tests/trainers/test_scaffold_strategy.py',343,381),ref('tests/integration/test_scaffold_round_flow.py',166,247)],
            'The post-optimizer additive correction does not enter momentum/Adam gradient history and warns for non-vanilla optimizers. Delivered tests use independent fixed scalar expectations, raw optimizer plus explicit correction, and retained rational multiround expectations. Those test assertions were inspected, not run here. No public prose exposes test counts or calls the shipped configuration paper-equivalent.'),
        assessment('Current inbound payload and direct/spawn client result acceptance',
            [ref(README,64,73),ref(DOC,73,80)],
            [ref('examples/customized_client_training/scaffold/scaffold_callback.py',27,39),ref('examples/customized_client_training/scaffold/scaffold_callback.py',54,61),ref('plato/trainers/composable.py',408,467),ref('plato/trainers/composable.py',797,902),ref('plato/trainers/strategies/algorithms/scaffold_strategy.py',282,408)],
            'Inbound extraction clears stale controls/delta and installs the current validated server control. _train_model stages controls then runs training callbacks; train_model runs the fallible training-step end hook before direct acceptance. train_process defers acceptance through model save and exports provisional ci/delta/K/rate when spawned. Parent checks current token and client, loads model and validates control state before acceptance. Only acceptance atomically replaces canonical ci. Rejection restores pending prior controls and refuses outbound delta. No promise of independent child canonical writes or broader whole-experiment rollback is made.'),
        assessment('Server raw validation, post-receive-callback state, aggregation commit and failure bounds',
            [ref(README,91,97),ref(DOC,55,60)],
            [ref('examples/customized_client_training/scaffold/scaffold_server.py',70,120),ref('examples/customized_client_training/scaffold/scaffold_server.py',122,196),ref('plato/servers/fedavg.py',181,261),ref('tests/integration/test_scaffold_callback_lifecycle.py',74,145)],
            'Raw model and control halves validate before staging. The callback wrapper forwards callbacks then revalidates the model/control state used, and checks resulting model/control values after aggregation callbacks. committed becomes true only after those callbacks and final checks. Precommit exception restores known model/control tensors; finally clears staging and restores handler. Evaluation/reporting happen afterward and retain a completed commit. External callback side effects are explicitly excluded. This writing assessment is source inspection, not independent closure of F27-R2-01.'),
        assessment('Logical-client ownership, canonical state, exact historical structural imports',
            [ref(README,99,119),ref(DOC,62,71)],
            [ref('plato/trainers/strategies/algorithms/scaffold_strategy.py',32,68),ref('plato/trainers/strategies/algorithms/scaffold_strategy.py',105,149),ref('plato/utils/checkpoint_paths.py',44,58)],
            'The strategy owns ci and resolves scaffold_cv_ID.pkl under model_path or save_path. Canonical file wins; absent canonical permits exact same-client contained model_name_ID_control_variate.pth then historical root-prefix-concatenated pkl. Load failure does not fall through. Validation requires finite floating trainable tensors and correct shapes, ignores known frozen/buffer extras, and rejects unknown keys. Logical identity change clears old state; client 0 is not substituted. Saves leave distinct legacy files unchanged.'),
        assessment('Legacy numerical discontinuity, fresh consistent controls, bounded restart scope',
            [ref(README,121,127),ref(DOC,79,84)],
            [ref('plato/trainers/strategies/algorithms/scaffold_strategy.py',1,12),ref('examples/customized_client_training/scaffold/scaffold_server.py',59,68)],
            'Structural import is not numerical continuation of the old wrong-sign trajectory. The prose recommends a separate base directory and consistently initialized server/client controls, initially zero; no one-client reset, server-control restoration, optimizer/RNG/privacy checkpoint or full restart protocol is promised.'),
        assessment('Standalone usefulness, documented paths, flags and defaults',
            [ref(README,8,22),ref(DOC,7,18)],
            [ref('examples/customized_client_training/scaffold/scaffold.py',12,30),ref('examples/customized_client_training/scaffold/scaffold_MNIST_lenet5.toml',1,63),ref('plato/config.py',184,224),ref('plato/config.py',286,410)],
            'Both commands resolve the real entrypoint and TOML from their stated working directories. Config confirms five total/two selected clients, three local epochs/up to five rounds, LeNet-5/MNIST download=true, SGD .01/.9/0 and max_concurrency=2, with --cpu and scratch -b paths. Install/full entrypoint execution was not run. Public prose contains no commit hashes, reviewer workflow or execution-count concepts.'),
    ],
    'independently_executed':{
        'environment':checks['environment'],
        'top_level_command':'zsh -lc: env -u config_file PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/private/tmp/plato-refresh-worktrees/scaffold-docs-review2 XDG_CACHE_HOME=/tmp/plato-phase2c-scaffold-docs-review-2/cache UV_CACHE_DIR=/tmp/plato-phase2c-scaffold-docs-review-2/uv-cache /tmp/plato-phase2c-scaffold-docs/venv/bin/python /tmp/plato-phase2c-scaffold-docs-review-2/review_checks.py > /tmp/plato-phase2c-scaffold-docs-review-2/checks-run.log 2>&1',
        'top_level_exit_code':0,
        'borrowed_environment':'Existing writer docs interpreter used read-only. No install, sync, dependency or environment mutation; source cwd/PYTHONPATH pinned, bytecode disabled and reviewer-owned caches/runtime paths.',
        'config':{'probes':4,'result':'PASS','documented_commands':checks['documented_commands'],
            'cases':'Each documented cwd/path pair with and without --cpu, always with an owned scratch -b. Config module origin, config SHA256/settings and all base/model/checkpoint/result/MPC paths asserted.',
            'limit':'Actual Config only. No uv sync, full scaffold.py run, MNIST download, datasource, trainer, GPU, full experiment or convergence claim.'},
        'rendering':{'result':'PASS','extension_source':'Exact candidate docs/mkdocs.yml; Markdown, admonition, details, superfences and generic arithmatex, with fenced code.',
            'results':checks['rendering'],'limit':'Rendered HTML structure inspected; no browser/KaTeX visual layout inspection or full external link crawl.'},
        'strict_mkdocs':{**checks['strict_mkdocs'],
            'baseline':'Exact 15e docs archive extracted only into owned scratch.',
            'disposition':'Both strict builds fail solely on the same two existing Nanochat relative links. Phase5 ownership, no unrelated repair, suppression or strict-build PASS.'},
        'executions':checks['executions'],
        'raw_checks_json':{'path':str(S/'checks.json'),'sha256':digest(S/'checks.json')},
        'reviewer_harness_attempt':{'path':str(S/'attempt1'),
            'failure':'Config probe used unresolved /tmp SCRATCH against a resolved /private/tmp base; its assertion failed although supplied base/config parsing was correct.',
            'correction':'Normalize only reviewer-owned SCRATCH with resolve(); remove irrelevant empty assertion. Four probes then pass.',
            'interpretation':'Reviewer harness failure, not a candidate finding; original scripts and logs retained without cleanup. Initial outer shell used cat after the runner and returned zero while raw Python traceback showed failure; no PASS inferred from that shell status.'},
    },
    'external_execution_receipts_not_my_runs':{
        'root':{
            'receipt':'phase2c-root-intermediate-base-validation.json','sha256':digest(S/'phase2c-root-intermediate-base-validation.json'),
            'candidate':BASE,'profile':'Exact no-.git source archive, Python 3.13.16 base profile',
            'passed':797,'expected_optional_skips':4,'allowed_runtime_omissions':48,'exit_code':0,
            'source_blobs_verified_unchanged':979,'result':root_receipt['result'],
            'command':root_receipt['command'],'limit':'Intermediate base receipt only; not final combined phase qualification.',
        },
        'author':{
            'receipts':['phase2c-scaffold-review2-fixes-validation.json','phase2c-scaffold-review2-fixes-receipt.json'],
            'executed_commit':'0f17708afefde13eeba1fd71578258b68c5911ee',
            'production_tests_identical_to_15e_verified':True,
            'environments':author['qualification']['environments'],
            'focused_passed_each':174,'skipped_each':0,'visible_warnings_each':17,
            'warning_disclosure':author['qualification']['warnings'],
            'limit':'Author qualification and test assertions inspected as attributed evidence; not independently rerun by this writing reviewer.',
        },
        'fresh_code_review3':{
            'receipt':'phase2c-scaffold-code-review-3.json',
            'sha256':digest(S/'phase2c-scaffold-code-review-3.json'),
            'candidate':BASE,'decision':'CHANGES_REQUIRED','acceptance':'FAIL',
            'findings':{'medium':1,'low_code_recommendations':1},
            'runtime_execution_attribution':'Fresh code reviewer reports 282 affected tests passing each on Python 3.13.16 and 3.14.8, 17 warnings each. A separate independent rejection regression has two failing direct cases and two passing process cases each; repeated replay is not an additional unique-case count.',
            'counts_and_scope':code_review3['independently_executed'],
            'limit':'External fresh code review, not this writing reviewer runtime execution or code acceptance. Its 282 selection includes the author 174 and the four archive cases; do not sum them.',
        },
        'counts':'Root and author coverage overlaps. Counts are not summed, and arithmetic/config/render checks are not runtime-suite passes.',
    },
    'review_history_and_final_handoff':{
        'initial_prose_review':'Provisional writing PASS at 95c/0dc with no writing findings; its narrower lifecycle facts are superseded by this exact candidate.',
        'prior_code_review_1':'Historical CHANGES_REQUIRED: malformed raw model halves and durable child ci after failed handoff. Review3 records both corrected; this writing review consumes its explicit disposition without claiming independent runtime execution.',
        'prior_code_review_2':'CHANGES_REQUIRED: F27-R2-01 report callback failure/commit boundary and F27-R2-02 direct fallible end-hook acceptance.',
        'author_disposition':'Original issues corrected by author on implementation 0f177; exact 15e preserves production/tests. Fresh review3 closes server callback and original training-step end failure, but direct model-update cleanup can still fail after acceptance.',
        'code_review3':{
            'target':str(ROOT/'evidence/2026-refresh/phase2c-scaffold-code-review-3.json'),
            'source':BASE,'status':'COMPLETE: CHANGES_REQUIRED; acceptance FAIL; one medium F27-R3-01 remains.',
            'sha256':digest(S/'phase2c-scaffold-code-review-3.json'),
            'provided_sha256_verified':True,
            'closed_boundaries':'Raw model/control, server callback commit/staging, original training-step end failure and portable fixture pass in the fresh code review.',
            'affected_claims':[ref(README,64,73),ref(README,91,97),ref(DOC,55,60),ref(DOC,73,80)],
            'required_reconciliation':'Original C author must move all fallible cleanup before direct canonical acceptance and add the otherwise-successful-cleanup-failure axis. Root must reconcile the corrected immutable source and fresh code review against both affected prose paragraphs before final documentation acceptance. Keep the intended prose contract; do not weaken it to accommodate the defect.',
        },
        'final_combined_source':'C/FedDyn/B/D integration still pending. Reconcile all relevant strategy/trainer/server/callback/config/test hashes and claims against the exact final tree before final documentation acceptance.',
        'correction_ownership':'Any required prose correction goes to the original Astra writer, followed by a fresh writing review; this reviewer made no source or prose edits.',
    },
    'limits_and_write_scope':[
        'No source, docs, tests, commits, refs, cleanup, other environment mutation, evolving training/writer branch reads, nested agents or broader FedDyn correctness/prose work.',
        'Only output is the assigned ROOT JSON and this reviewer scratch directory; raw scratch preserved.',
        'No independent code test suite, spawned runtime, experiment, dataset download, training dependency installation or convergence execution.',
        'Model/control rollback covers the bounded inspected tensor state and staging. External callback side effects and coordinated experiment restart are explicitly excluded.',
        'Provisional writing PASS only. Completed code review3 requests the direct cleanup correction. Original author correction plus fresh code qualification, final combined-source reconciliation, integrated validation and root phase acceptance remain required.',
    ],
}

# Keep the intended documentation contract while explicitly distinguishing its
# remaining implementation prerequisite from a new writing defect.
for item in review['claim_assessment']:
    if item['subject']=='Current inbound payload and direct/spawn client result acceptance':
        item['result']='PROVISIONAL_INTENDED_CONTRACT_WITH_OPEN_CODE_GAP'
        item['basis'] += (
            ' Fresh review3 F27-R3-01 shows the remaining direct-only cleanup gap: '
            'train_model accepts at line 454 and sets successful at 455 before fallible '
            'model-update cleanup at 463. An otherwise-successful cleanup exception can '
            'leave canonical controls advanced and outbound eligible. The documented '
            'after-all-end-hooks contract is required and must not be weakened. '
            'Client-control failure atomicity is conditional on the author correction '
            'and fresh final code/source reconciliation; it is not fully implemented '
            'on this pinned 15e candidate.'
        )
review['known_implementation_dependency_not_new_writing_finding']={
    'id':'F27-R3-01','severity_in_code_review':'medium','status':'OPEN',
    'source':BASE,'receipt':'phase2c-scaffold-code-review-3.json',
    'receipt_sha256':digest(S/'phase2c-scaffold-code-review-3.json'),
    'source_locations':[ref('plato/trainers/composable.py',454,463),ref('plato/trainers/strategies/algorithms/scaffold_strategy.py',311,339)],
    'affected_documentation':[ref(README,66,73),ref(DOC,73,78)],
    'precise_claim_mismatch':
        'The intended prose says direct controls are accepted/saved only after training callbacks and end hooks succeed, '
        'and rejected end hooks retain previously accepted controls and refuse an outbound delta. '
        'The training-step end hook is now correctly before acceptance, but model-update cleanup still executes '
        'after direct acceptance. If otherwise-successful cleanup raises, direct train_model fails after '
        'the canonical file and outbound eligibility have already advanced; this is the material code prerequisite.',
    'independent_code_reviewer_reproduction':{
        key:code_review3['findings'][0]['reproduction'][key]
        for key in ('probe','helper','source_and_numeric_helper','exact_standalone_commands',
            'shell','steps','expected','actual_direct','actual_process_comparison',
            'current_failure_result','python_versions','population_consequence')
    },
    'missing_regression_axis':code_review3['findings'][0]['test_gap'],
    'writing_disposition':'No new writing defect: public prose expresses the accepted intended contract. Keep it; do not substitute weaker behavior to match the defect. Provisional writing PASS is explicitly conditioned on closing this code gap.',
    'required_next_step':'Original C author moves all fallible cleanup before direct acceptance and adds otherwise-successful-cleanup-failure tests, canonical-present/absent direct/process comparison and reuse/retry; fresh independent code review, then exact corrected/final combined source reconciliation of affected prose.',
    'not_claimed':'No complete failure-atomic runtime acceptance on 15e, no closure of F27, no external side-effect rollback, no complete experiment restart.',
}

# Recheck immutable source and clean worktree at report issuance.
command='env GIT_OPTIONAL_LOCKS=0 '+shlex.join(['git','rev-parse','HEAD','HEAD^{tree}'])
r=subprocess.run(['zsh','-lc',command],cwd=SOURCE,capture_output=True,check=True)
assert r.stdout.decode().splitlines()==[CANDIDATE,TREE]
command='env GIT_OPTIONAL_LOCKS=0 '+shlex.join(['git','status','--porcelain=v1'])
r=subprocess.run(['zsh','-lc',command],cwd=SOURCE,capture_output=True,check=True)
assert not r.stdout
for name,data in manifest.items():
    assert digest(SOURCE/name)==data['sha256'],name
review['issuance_source_recheck']={'HEAD':CANDIDATE,'tree':TREE,'tracked_blob_sha256_verified':len(manifest),'git_status':'clean'}
review['retained_scripts']=[{'path':str(S/name),'sha256':digest(S/name)} for name in ('review_checks.py','config_probe.py','write_review.py')]
if OUT.exists():
    assert OUT.read_bytes()==(S/'issued-review.json').read_bytes(),OUT
    (S/('issued-review-'+digest(OUT)+'.json')).write_bytes(OUT.read_bytes())
payload=json.dumps(review,indent=2,ensure_ascii=False)+'\n'
(S/'issued-review.json').write_text(payload)
OUT.write_text(payload)
assert json.loads(OUT.read_text())['acceptance']=='PROVISIONAL_WRITING_PASS_ONLY'
print(json.dumps({'path':str(OUT),'decision':review['decision'],'acceptance':review['acceptance'],
    'sha256':digest(OUT),'bytes':OUT.stat().st_size,'material_findings':0},indent=2))
