"""Independent bounded checks; owned review scratch only."""

import asyncio
import heapq
import importlib.util
import math
import pickle
import time
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
import torch

from plato.callbacks.handler import CallbackHandler
from plato.clients.simple import Client
from plato.clients.composable import ComposableClientEvents
from plato.clients.strategies.base import ClientContext
from plato.clients.strategies.defaults import DefaultPayloadStrategy
from plato.config import Config
from plato.servers.strategies.aggregation.port import PortAggregationStrategy
from plato.servers.strategies.base import ServerContext
from plato.trainers.composable import ComposableTrainer
from tests.servers.test_fedavg_strategy import DeltaOnlyStrategy, _dispatch_server


def report(client_id, training_time=1, update_response=False):
    return SimpleNamespace(
        client_id=client_id, num_samples=1, accuracy=0,
        comm_time=time.time(), training_time=training_time,
        processing_time=0, update_response=update_response,
    )


def assign(server, sid, client_id):
    server.training_clients[client_id] = {
        "id": client_id, "starting_round": 1,
        "start_time": 0, "update_requested": False,
    }
    server.training_sids.append(sid)
    server._assign_client(sid, client_id)


async def complete(server, sid, client_id, report_value=None):
    await server._client_report_arrived(
        sid, client_id, pickle.dumps(report_value or report(client_id))
    )
    await server._client_chunk_arrived(sid, pickle.dumps({"w": client_id}))
    await server._client_payload_arrived(sid, client_id)
    await server._client_payload_done(sid, client_id)


def test_f10_cleanup_uses_reassigned_current_identity(temp_config, tmp_path):
    tmp_path = tmp_path / "owned_models"
    tmp_path.mkdir()
    Config.params["model_path"] = str(tmp_path)
    Config().clients.shutdown_delay = 0
    client = Client()
    client.client_id = 17
    own = ["17_2_0.25.pth", "17_2_0.25.pth.pkl", "17_3_1.5.safetensors"]
    keep = ["3_2_0.25.pth", "18_2_0.25.pth.pkl", "current_round.pkl",
            "checkpoint_toy_2.safetensors", "17_2_0.25.pth.extra"]
    for filename in own + keep:
        (tmp_path / filename).write_bytes(b"sentinel")
    (tmp_path / "17_8_5.0.pth").mkdir()
    events = ComposableClientEvents("/", client._require_composable())
    asyncio.run(events.on_disconnect())
    assert {p.name for p in tmp_path.iterdir()} == set(keep + ["17_8_5.0.pth"])


@pytest.mark.parametrize("legacy", [False, True])
def test_f11_key_alignment_eval_state_and_storage_unchanged(temp_config, tmp_path, legacy):
    path = Path(__file__).parents[1] / "examples/async/port/port_server.py"
    spec = importlib.util.spec_from_file_location("review_port", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    Config.params["model_path"] = str(tmp_path)
    trainer = ComposableTrainer(model=lambda: torch.nn.Linear(2, 1))
    trainer.set_client_id(0)
    model = trainer.require_model()
    with torch.no_grad():
        model.weight.copy_(torch.tensor([[1., 0.]]))
        model.bias.zero_()
    server = module.Server()
    server.trainer = trainer
    server.current_round = 3
    server.weights_aggregated([])
    if legacy:
        torch.save(model.state_dict(), tmp_path / "model_3.pth")
        (tmp_path / "model_3.safetensors").unlink()
    with torch.no_grad():
        model.weight.copy_(torch.tensor([[3., 1.]]))
        model.bias.fill_(1.)
    model.eval()
    before = {k: (v.clone(), v.device, v.data_ptr()) for k, v in model.state_dict().items()}
    context = ServerContext()
    context.trainer = trainer
    context.current_round = 5
    # Deliberately reversed key insertion order.
    delta = {"bias": torch.tensor([-1.]), "weight": torch.tensor([[2., -1.]])}
    result = asyncio.run(PortAggregationStrategy()._cosine_similarity(delta, 2, context))
    assert result == pytest.approx(2 / (math.sqrt(6) * math.sqrt(6)))
    assert not model.training
    for k, v in model.state_dict().items():
        assert torch.equal(v, before[k][0])
        assert v.device == before[k][1] and v.data_ptr() == before[k][2]


@pytest.mark.parametrize("kind", ["ordinary", "legacy", "delta"])
@pytest.mark.parametrize("defect", ["negative", "infinite", "cardinality", "total"])
def test_f18_callback_transform_rejected_before_dispatch(temp_config, kind, defect):
    Config().server.do_test = False
    server = _dispatch_server(kind)

    class Transform:
        def on_weights_received(self, owner, weights):
            if defect == "cardinality":
                weights.pop()
            elif defect == "total":
                for update in owner.updates:
                    update.report.num_samples = 1e308
            else:
                owner.updates[0].report.num_samples = -2 if defect == "negative" else math.inf

    server.callback_handler = CallbackHandler([Transform()])
    with pytest.raises(ValueError):
        asyncio.run(server._process_reports())
    assert server.algorithm.current["weight"].item() == 10
    assert server.legacy_calls == 0
    if isinstance(server.aggregation_strategy, DeltaOnlyStrategy):
        assert server.aggregation_strategy.delta_calls == 0


@pytest.mark.parametrize("minimum", [3, 4])
def test_urgent_partial_removal_preserves_finish_time_order(temp_config, minimum):
    from plato.servers import fedavg
    async def scenario():
        server = fedavg.Server()
        server.comm_simulation = False
        server.asynchronous_mode = server.simulate_wall_time = server.request_update = True
        server.current_round = 20
        server.wall_time = 1
        server.staleness_bound = 10
        server.minimum_clients = minimum
        finishes = [9, 20, 58, 31, 28, 94]
        server.clients = {i: {"sid": f"s{i}", "client_id": i} for i in finishes}
        server.selected_clients = finishes[:]
        server.current_reported_clients = {i: True for i in finishes}
        server.training_clients = {}
        server.training_sids = []
        server.reported_clients = [
            (i, i, {"client_id": i, "sid": f"s{i}", "starting_round": 1 if i == 20 else 20,
                    "start_time": 0, "report": report(i, i), "payload": {"w": i}})
            for i in finishes
        ]
        assert all(server.reported_clients[(i - 1) // 2] <= server.reported_clients[i]
                   for i in range(1, len(finishes)))
        server.sio = SimpleNamespace(emit=AsyncMock())
        server._process_reports = AsyncMock()
        server.wrap_up = AsyncMock()
        server._select_clients = AsyncMock()
        await server._process_clients(server.reported_clients[0])
        await complete(server, "s20", 20, report(20, 1, True))
        actual = [u.client_id for u in server.updates]
        print("urgent aggregation order", actual, "wall_time", server.wall_time)
        assert actual == [20, 9, 28, 31][:minimum]
        assert server.wall_time == {3: 28, 4: 31}[minimum]
    asyncio.run(scenario())


def test_repeated_logical_client_keeps_distinct_retained_wire_accounting(temp_config):
    from plato.servers import fedavg
    async def scenario():
        Config().server.max_buffered_bytes = 400
        server = fedavg.Server()
        server.comm_simulation = False
        server.asynchronous_mode = True
        server.simulate_wall_time = False
        server.clients_per_round = 3
        server.total_clients = 10
        server.clients = {i: {"sid": sid, "client_id": cid}
                          for i, sid, cid in [(1, "first", 1), (2, "second", 7), (3, "third", 3)]}
        server.training_clients = {}
        server.training_sids = []
        server._process_clients = AsyncMock()
        assign(server, "first", 1)
        await complete(server, "first", 1)
        assign(server, "second", 7)
        await complete(server, "second", 7)
        assign(server, "third", 3)
        server.updates = [SimpleNamespace(client_id=i) for i in (1, 7)]
        server._release_processed_payloads()
        assert server._buffered_inbound_bytes() == 380
        server.choose_clients = lambda pool, count: [7, 8]
        server.sio = SimpleNamespace(emit=AsyncMock())
        server.algorithm = SimpleNamespace(extract_weights=lambda: {"w": 0})

        async def send(sid, payload, client_id):
            if sid == "first":
                # A fast first assignment reports while _select_clients is still
                # awaiting its send, before the second worker is reassigned.
                await complete(server, "first", 7)
                actual = server._buffered_inbound_bytes()
                retained = sum(count for _, count in server._completed_payload_bytes.values())
                print("wire ledger during actual selection", {
                    "actual": actual, "retained": retained,
                    "completed": server._completed_payload_bytes,
                    "queued": server._queued_payload_bytes,
                })
                assert len(server.reports) == 2 and len(server.client_payload) == 2
                with pytest.raises(ValueError, match="buffered"):
                    await server._client_report_arrived("third", 3, pickle.dumps(report(3)))

        server._send = send
        await server._select_clients()
    asyncio.run(scenario())


def test_client_honors_buffer_limit_below_payload_limit(temp_config):
    Config().server.max_buffered_bytes = 20
    Config().server.max_payload_bytes = 256
    Config().server.max_chunk_bytes = 256

    async def scenario():
        context = ClientContext()
        context.client_id = 7
        context.comm_simulation = False
        strategy = DefaultPayloadStrategy()
        strategy.reset_payload(context)
        try:
            raw = pickle.dumps({"w": "x" * 60})
            print("client buffer limit", {"limit": 20, "wire_bytes": len(raw)})
            with pytest.raises(ValueError, match="limit"):
                await strategy.accumulate_chunk(context, raw)
        finally:
            strategy.teardown(context)
    asyncio.run(scenario())
