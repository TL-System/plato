import hashlib
import json
from pathlib import Path

scratch = Path('/tmp/plato-phase2b-review')
audit = json.loads((scratch / 'evidence-audit.json').read_text())
target = Path('/Users/bli/Playground/plato/evidence/2026-refresh/phase2b-review.json')
assert not target.exists(), 'Do not overwrite an existing independent review.'


def identity(path):
    path = Path(path)
    return {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


report = {
    'schema_version': 1,
    'review': 'Fresh independent Phase 2B exact-candidate review',
    'reviewer': 'Root review agent; no nested agents or delegation',
    'completed_at_utc': '2026-10-03T02:09:04Z',
    'decision': 'CHANGES_REQUESTED',
    'decision_basis': [
        'Two concrete medium candidate-local runtime defects reproduced on Python 3.13.16 and 3.14.8.',
        'The confirmed empty-prefix S3 integration correction also remains required before phase integration; it is recorded separately as a cross-owner handoff.',
    ],
    'identities': {
        'candidate_commit': 'b3b038efa376b060e1c01f1da39173240768a019',
        'candidate_tree': '188ad9d6e7a76ef4da2e201d918fe1c0a63b7125',
        'implementation_commit': '759be841c2c9c6d92608c1ac7186a5e9ded42fe4',
        'implementation_tree': '6a61cbe3dc324185ad03eb06c9d13376d7a3362a',
        'base_commit': 'fda60becedfa6236c11d415b87a868b52789a41e',
        'candidate_worktree': '/private/tmp/plato-refresh-worktrees/runtime',
        'review_scratch': str(scratch),
        'candidate_read_only': True,
        'candidate_status_before_and_after': 'clean',
        'evidence_commit_boundary': 'Candidate differs from implementation only by evidence/2026-refresh/phase2b-validation.json.',
        'all_changed_source_and_test_files_in_review_copy_match_candidate': True,
        'review_environments': [
            {'python': '3.13.16', 'path': str(scratch / 'venv313')},
            {'python': '3.14.8', 'path': str(scratch / 'venv314')},
        ],
        'provision': 'git archive exact candidate into owned scratch; UV_PROJECT_ENVIRONMENT=<owned venv> uv sync --locked --group dev --python <version>; zsh -lc throughout. Author environments were not executed or mutated.',
        'source_and_authority_sha256': audit['files_sha256'],
    },
    'scope': {
        'authorities_read': ['AGENTS.md', 'accepted plan.md Phase 2B, F10/F11 and socket acceptance', 'accepted plan-addendum.json F18 and narrow 3A handoff', 'phase2b-validation.json', 'actual full base-to-candidate diff', 'latest root S3 cross-owner steering'],
        'included': ['Own-client checkpoint cleanup', 'Actual PORT writer/historical reader and stale weighting', 'Raw/transformed aggregation cardinality and finite nonnegative sample validation', 'Session assignment, reused workers, urgent reports, edge assignment and registration', 'Bounded reports/chunks/parts/completion/S3 ingress, expiry, malformed cleanup, queued/completed accounting', 'Callbacks, async partial selection, simulated-time stale enumeration, cross-silo and all-zero evaluation', 'Retained red/green evidence and actual runtime events/artifact hashes'],
        'excluded': ['Accepted Phase 1 package/design re-review', 'F07 global slash-name checkpoint repair, owned by 2C', 'MLX tree validation, owned by 3A', 'HE/MPC and unrelated S3 utility implementation, owned by 2D', 'Trainer F21-F24, confirmed in separate scope', 'Authentication, nonces, protocol redesign or arbitrary untrusted pickle protection'],
    },
    'findings': [
        {
            'id': 'R2B-01',
            'severity': 'medium',
            'blocking': True,
            'title': 'Removing selected urgent reports corrupts the finish-time heap.',
            'path': 'plato/servers/base.py',
            'line': 1278,
            'related_lines': [1249, 1309, 1319],
            'description': 'reported_clients is maintained with heapq, but list.remove() does not restore its heap invariant. When only some buffered reports require urgency, later heappush/heappop can select a later-finishing client ahead of an earlier one, or move simulated wall_time backward. Snapshot iteration fixes skipped requests but does not preserve the chronological selection contract.',
            'reproduction': {
                'probe': str(scratch / 'candidate/tests/test_phase2b_review_probes.py') + '::test_urgent_partial_removal_preserves_finish_time_order',
                'versions': ['3.13.16', '3.14.8'],
                'setup': 'Actual _process_clients and report/chunk/part/completion handlers. Valid initial heap finish times [9,20,58,31,28,94]; round 20, wall_time 1, staleness_bound 10. Only client 20 starts at round 1; the others start at round 20. The default should_request_update selects client 20. Its actual urgent response has update_response=True and finish near 1.',
                'minimum_three': {'expected_client_order': [20, 9, 28], 'actual_client_order': [20, 9, 31], 'expected_wall_time': 28, 'actual_wall_time': 31},
                'minimum_four': {'expected_client_order': [20, 9, 28, 31], 'actual_client_order': [20, 9, 31, 28], 'expected_wall_time': 31, 'actual_wall_time': 28},
                'stubs': 'Socket emit plus downstream aggregate/wrap/select are inert. Urgency decision, heap removal, re-registration of the urgent assignment, actual ingress and selection of updates execute.',
            },
            'required_correction': 'Restore the heap invariant after selective removal, before any concurrent response or subsequent heappush/heappop can use it. Keep snapshot enumeration. Add a partial-urgency regression that checks the selected client set/order and simulated-time progress, not only that all urgent requests were emitted.',
            'test_gap': 'The new all-buffered-stale test removes every entry and therefore cannot detect a corrupted remaining heap.',
            'baseline_boundary': 'The baseline indexed deletion also violated this invariant. This is a concrete latent defect in the revised, in-scope urgent path, not a claim that Phase 2B introduced the original ordering bug.',
        },
        {
            'id': 'R2B-02',
            'severity': 'medium',
            'blocking': True,
            'title': 'Logical-client deduplication omits a distinct retained completed transfer.',
            'path': 'plato/servers/base.py',
            'line': 1015,
            'related_lines': [962, 1209, 1211, 1021],
            'description': 'Queued wire accounting is keyed only by logical client ID. Every completed transfer carrying that ID is excluded when one queued entry exists, even when older completion-hook fields on another physical worker retain a different decoded report/payload. This undercounts retained buffers during normal asynchronous worker reassignment and permits ingress beyond max_buffered_bytes.',
            'reproduction': {
                'probe': str(scratch / 'candidate/tests/test_phase2b_review_probes.py') + '::test_repeated_logical_client_keeps_distinct_retained_wire_accounting',
                'versions': ['3.13.16', '3.14.8'],
                'setup': 'Three registered physical workers; asynchronous clients_per_round=3; third worker still trains logical client 3. First and second workers complete logical clients 1 and 7 through actual handlers, then processed queued accounting is released while legacy completion fields remain. Actual _select_clients chooses replacements [7,8]. While its first send awaits, the first worker completes the new logical client 7 before the second worker is reassigned.',
                'wire_sizes': {'report_bytes': 169, 'payload_bytes': 21, 'bytes_per_completed_transfer': 190, 'configured_server_budget': 400},
                'observed': {'completed_transfers': {'second': [7, 190], 'first': [7, 190]}, 'queued': {'7': 190}, 'reported_buffered_bytes': 190, 'actually_retained_wire_bytes': 380, 'next_valid_report_for_still_training_client_3': 'accepted', 'retained_wire_bytes_after_that_report': 549},
                'expected': 'Both distinct retained transfers count once. The third worker report must be rejected before parsing because 380+169 exceeds 400, without modifying its prior assignment or other workers.',
                'stubs': 'Payload sends are instrumented to deliver fast responses at the real await boundary; downstream report processing is inert. Actual assignment selection, completion hooks/ledger transition, report reservation and ingress execute.',
            },
            'required_correction': 'Deduplicate the queued/completed references by transfer identity or owning session, rather than excluding all completed values with the same logical client ID. Retain legacy report/payload visibility and preserve queued bytes when the worker is reused. Verify the real selection await boundary, repeated logical identities across workers, processed release and disconnect/close cleanup.',
            'test_gap': 'The existing completed-unaggregated budget test covers one completion only; the reused-worker test uses different logical IDs on the same worker. Neither exercises distinct retained completions for a repeated logical ID.',
            'baseline_boundary': 'Introduced by the new Phase 2B buffer ledger.',
        },
    ],
    'optional_low_observations': [
        {
            'id': 'R2B-L01',
            'severity': 'low',
            'blocking': False,
            'path': 'plato/clients/transport.py',
            'line': 90,
            'title': 'Client socket/S3 paths do not apply max_buffered_bytes when it is below max_payload_bytes.',
            'reproduction': 'DefaultPayloadStrategy accepts an 82-byte chunk with max_buffered_bytes=20 and max_payload_bytes=max_chunk_bytes=256 on both interpreters. InboundTransfer.reserve checks only the payload cap; client S3 uses the same reserve. Client simulated-file ingress applies min(payload, buffered).',
            'impact_and_limit': 'Client ingress still has a finite payload cap. The evidence specifically describes the global buffer budget as a server ledger, so this narrower client configuration inconsistency is not a separate blocking acceptance failure.',
            'optional_correction': 'Make the scope of max_buffered_bytes consistent and explicit. If it is shared with client ingress, apply it before retaining client socket/S3 bytes; otherwise document the server-only budget and the separate client payload cap.',
        },
    ],
    'mandatory_contract_results': {
        'F10': 'PASS: actual disconnect uses current logical identity 17, removes .pth/.pth.pkl/.safetensors snapshots, and preserves former/other clients, server resume files, unrelated suffixes and directories. Candidate full-match predicate is correct.',
        'F11': 'PASS: actual PORT weights_aggregated writer produces Safetensors plus sidecar; reader deserializes repository tree and falls back to CPU weights_only .pth. Shipped numerical stale similarity 0.6 and 2/6 weighting pass. Independent two-key reversed-insertion delta gives cosine 1/3 and preserves live values, storage pointers, device and eval mode for both formats.',
        'F18': 'PASS: code validates raw and transformed cardinality and finite nonnegative real sample weights before ordinary/legacy/delta dispatch, with finite eligible total. Independent callback mutations (negative, infinity, cardinality removal and overflowing finite total) reject before global or dispatch mutation in all three paths. Shipped fractional, zero, feature, reverse-order and cross-silo pre-mutation tests pass.',
        'identity': 'PASS for reviewed current assignment checks: registration cannot rebind another existing pid/session; wrong/unknown/stale identity rejects before pickle parsing or another client state mutation at report/chunk/part/completion/S3 stages. Reused worker, urgent reported identity, actual central-edge selection and urgent disconnect paths are covered. No authentication/nonces requested.',
        'bounded_ingress': 'Finite report/chunk/payload/count/deadline defaults and bounded malformed/trailing/truncated/incomplete cleanup execute. Real local HTTP S3 header/stream/timeout checks pass. Global retained accounting has the R2B-02 failure.',
        'callbacks_and_evaluation': 'PASS: registration-order iteration, callback-body AttributeError identity propagation, descriptive missing methods, cross-silo validation before trainer identity mutation and finite all-zero accuracy handling.',
        'async_selection': 'PASS for the final ordinary/batched partial-round replacement correction and relevant personalized/split strategy tests. Urgent simulated-time selection still has R2B-01.',
    },
    'checks_performed': [
        {
            'check': 'Independent candidate runtime suite in owned Python 3.13 environment',
            'command': '/tmp/plato-phase2b-review/venv313/bin/python -m pytest tests/clients tests/servers tests/callbacks tests/integration/test_smoke_configs.py -q --basetemp /tmp/plato-phase2b-review/pytest313',
            'result': '163 passed in 1.11s; zero skips or warnings.',
            'log': identity(scratch / 'pytest313.log'),
        },
        {
            'check': 'Independent bounded numerical/negative probes on final review-probe source',
            'commands': [f'/tmp/plato-phase2b-review/venv{v}/bin/python -m pytest tests/test_phase2b_review_probes.py -q -s --basetemp /tmp/plato-phase2b-review/final-probes{v}' for v in ['313', '314']],
            'result': 'Each interpreter: 15 positive cases passed and four negative assertions failed. Two failing heap cases establish R2B-01, one real-selection ledger case establishes R2B-02, and one client-budget case establishes the nonblocking low observation.',
            'source': identity(scratch / 'candidate/tests/test_phase2b_review_probes.py'),
            'logs': [identity(scratch / f'final-probes{v}.log') for v in ['313', '314']],
            'harness_boundary': 'Initial owned probe collection/configuration/signature mistakes were corrected in scratch. Final retained probe failures occur at the intended behavioral assertions, not setup errors. No candidate test/source was changed.',
        },
        {
            'check': 'Retained evidence integrity and independent weighted-round numerical recomputation',
            'source': identity(scratch / 'audit_evidence.py'),
            'audit_output': identity(scratch / 'evidence-audit.json'),
            'result': '96 final startup result records inspected; 48/interpreter, all durable event-file contents exactly match result events, no surviving owned processes. Five deliberate watchdog-containment records per interpreter kept distinct from normal success. Both socket rounds return naturally, train separate CPU child processes with 2/6 sample reports, and return both clients naturally. All client/final/checkpoint Safetensors values exactly match recorded events.',
            'maximum_weighted_reference_errors': {k: v['maximum_tensor_errors'] for k, v in audit['runs'].items()},
        },
        {
            'check': 'Retained red/green logs and evidence truthfulness',
            'result': 'Inspected actual writer .pth rejection, cleanup/session/limits failures, invalid-weight/all-zero/callback failures, baseline numerical probe and the async selection failures. Final logs match reported 209 broad passes/interpreter and 55 supplemental selection passes/interpreter. These runs overlap and add only two final async cases: 211 distinct cases, not 264. Broad logs predate that final selection source change; the 55-case supplemental run is the explicit affected-path boundary.',
            'log_identities': audit['logs'],
        },
        {
            'check': 'Static and immutable source boundaries',
            'result': 'Scoped production Ruff import-order check passed. git diff --check passed. Accepted startup test, startup_harness/probe/socket, shared conftest/utils are byte-for-byte unchanged from the baseline. Every changed tracked file tested in review scratch matches the exact candidate git object. Original worktree remains clean.',
        },
    ],
    'retained_runtime_evidence_identities': audit['runs'],
    'handoffs_and_pending_integration': [
        {
            'id': 'S3-2B-2D-EMPTY-PREFIX',
            'status': 'Confirmed pending correction; required before phase integration',
            'owner': 'Original 2B author, coordinated by root; fresh independent review of correction before integration',
            'runtime_path': 'plato/clients/transport.py',
            'line': 148,
            'delivered_2d_commit': 'a4a4733e96cf248a73db76e6b2182536b9f592ea',
            'delivered_2d_tree': '8f64fa760a4c1e5be3eb28956a3b22e0ba206f7c',
            'confirmed_behavior': 'Actual fixed S3 writer + exact candidate bounded reader works for nonempty/nested/trailing-slash prefixes. With empty prefix D writes client_payload_7_ABC123 while B requests /client_payload_7_ABC123 and gets HTTP 404.',
            'required_correction': 'Align bounded runtime key composition with D storage._object_key(key), which canonicalizes exactly once and returns bare K when prefix is empty. Preserve B byte reservations, total deadline, and session/S3-reference validation. Verify combined actual send/put -> bounded reader for prefixed and unprefixed storage. No unrelated S3 utility edit or protocol feature is requested here.',
            'evidence_checked': 'Read D _object_key implementation and both retained integration logs, verified their hashes and that the pinned B transport snapshot equals this candidate. Logs used D implementation e7c0d59571d88efd7eb1fdbf4fc63ac2a7b81395; git diff confirms plato/utils/s3.py is unchanged between it and delivered a4a4733e.',
            'logs': [identity('/tmp/plato-phase2d.G3jkGH/runtime-s3-integration313.log'), identity('/tmp/plato-phase2d.G3jkGH/runtime-s3-integration314.log')],
            'candidate_transport': identity('/private/tmp/plato-refresh-worktrees/runtime/plato/clients/transport.py'),
        },
        {'id': 'F07', 'owner': '2C', 'status': 'Explicitly deferred; not a new Phase 2B failure', 'requirement': 'Preserve the complete writer/reader and sidecar/resume path inventory in phase2b-validation.json. Coordinate slash-name handling across payload simulation, trainer time snapshots, server save/resume, PORT history, personalized local layers and worker artifacts after acceptance.'},
        {'id': 'MLX-F17', 'owner': '3A', 'status': 'Later narrow capability handoff', 'requirement': 'Extend Server._validate_aggregation_inputs for raw/transformed MLX tree validation, including zero-weight trees and both arrival orders, before direct/legacy/delta mutation. No MLX redesign required in 2B.'},
        {'id': 'PHASE-INTEGRATION', 'owner': 'Root', 'status': 'Pending after corrected exact candidate passes fresh review', 'requirement': 'Run full merged validation and phase gate. This report is a component review, not a merged-tree acceptance claim.'},
    ],
    'explicit_limits': [
        'No full eight-minute startup suite rerun: unchanged accepted sources, inspected 96 retained results and actual tensors/event hashes suffice for this bounded component review. Root merged validation follows the phase gate.',
        'No live S3 credentials/service, distributed GPU or production multi-silo execution. Candidate actual local HTTP negative reader cases and delivered 2D local integration evidence were inspected.',
        'Independent PORT checks preserve CPU device/storage/mode; accelerator non-mutation follows the inspected read-only detach().cpu() tensor copies, not an accelerator execution claim.',
        'Finite wire caps do not bound arbitrary decoded pickle expansion or CPU execution. Peers and object writers remain trusted, as disclosed in candidate evidence.',
        'Same-logical-ID replay across indistinguishable assignments is outside this existing protocol. No authentication/nonces/security redesign demanded.',
        'No package/design re-review, first-party typing quota, broad unchanged-suite repetition, code changes, branch changes, author-environment mutation, commits, pushes or nested agents.',
        'Review scratch and logs remain available. Only this report was written outside owned scratch; the exact candidate was kept unchanged.',
    ],
}
target.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'report': str(target), 'decision': report['decision'],
                  'candidate': report['identities']['candidate_commit'],
                  'blocking_candidate_findings': len(report['findings']),
                  'report_sha256': identity(target)['sha256']}))
