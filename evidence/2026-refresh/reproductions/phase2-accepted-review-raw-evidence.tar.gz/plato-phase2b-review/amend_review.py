import hashlib
import json
from pathlib import Path

scratch = Path('/tmp/plato-phase2b-review')
target = Path('/Users/bli/Playground/plato/evidence/2026-refresh/phase2b-review.json')
review = json.loads(target.read_text())


def identity(path):
    path = Path(path)
    return {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


# Preserve the exact source that produced the original 19-case logs.
probe_path = scratch / 'candidate/tests/test_phase2b_review_probes.py'
old_expected = review['checks_performed'][1]['source']['sha256']
prefix = probe_path.read_bytes().split(b'\n\n\ndef test_actual_batched_reuse_serializes_urgent_assignments_per_worker', 1)[0]
snapshot = scratch / 'initial_19_probes_snapshot.py'
for suffix in [b'\n', b'', b'\n\n']:
    data = prefix + suffix
    if hashlib.sha256(data).hexdigest() == old_expected:
        snapshot.write_bytes(data)
        break
else:
    raise AssertionError('Original 19-case source snapshot must match recorded hash.')
review['checks_performed'][1]['source'] = identity(snapshot)
review['checks_performed'][1]['source_boundary'] = 'Exact historical source snapshot preserved after root requested one additional independent probe. Candidate sources and the first 19 probe functions remain unchanged.'

review['completed_at_utc'] = '2026-10-03T02:15:56Z'
review['decision_basis'][0] = 'One high and two medium candidate-local runtime defects reproduced on Python 3.13.16 and 3.14.8. The new high finding independently confirms root steering and normal batched-worker reachability.'
review['findings'].insert(0, {
    'id': 'R2B-03',
    'severity': 'high',
    'blocking': True,
    'root_correspondence': 'ROOT-2B-01',
    'title': 'Urgent requests for stale reports sharing one physical worker overwrite the outstanding assignment and strand training.',
    'path': 'plato/servers/base.py',
    'line': 1289,
    'related_lines': [1249, 1281, 1291, 1293, 971, 977],
    'description': 'A reused worker can own several retained simulated-time reports. The urgent loop sends requests for all of them concurrently, but _session_assignments permits only one current logical assignment per sid. Each request overwrites the preceding assignment and appends the same sid to training_sids. The first valid requested report is then rejected. Completing the last request removes the sole assignment but leaves the earlier client marked update_requested with a duplicate sid reservation, so aggregation waits indefinitely.',
    'reachability': 'Independent probe constructs the retained reports through actual _select_clients batching and actual report/chunk/part/completion handlers, starting with clean assignments. With asynchronous=True, simulate_wall_time=True, request_update=True, max_concurrency=1, clients_per_round=3, minimum_clients=1 and staleness_bound=1, one worker reports clients 7,2,9 in round 1. Client 9 reports again in rounds 2 and 3, while clients 7 and 2 retain future finish times 100 and 101. At round 3 the default should_request_update rule requests both old clients from that same worker. No synthetic retained queue or forced staleness predicate is used. The shipped PORT config enables the corresponding combination and max_concurrency=5 with per_round=30.',
    'reproduction': {
        'probe': str(probe_path) + '::test_actual_batched_reuse_serializes_urgent_assignments_per_worker',
        'versions': ['3.13.16', '3.14.8'],
        'normal_round_reports': [[1, 7], [1, 2], [1, 9], [2, 9], [3, 9]],
        'urgent_requests_in_independent_run': [[2, 'worker'], [7, 'worker']],
        'assignment_after_requests': {'worker': 7},
        'training_sids_after_requests': ['worker', 'worker'],
        'training_clients_after_requests': [2, 7],
        'first_requested_response': 'ValueError: Session does not match a current logical client assignment.',
        'after_last_requested_response_completes': {'assignments': {}, 'training_sids': ['worker'], 'training_clients': [2]},
        'stubs': 'Physical payload sends deliver the reports through real ingress handlers. Aggregation and wrap-up are inert; client selection, batching, retained queues, simulated-time advance, default staleness predicate, urgent dispatch, assignment checks and last-response completion execute.',
        'root_probe_boundary': 'Root synthetic-queue probe requests 7 then 2 and observes the same overwrite. Independent actual-batching probe requests 2 then 7, confirming that failure does not depend on request order.',
    },
    'required_correction': 'Keep at most one outstanding urgent logical assignment per physical sid. Serialize or queue other urgent requests for that worker, preserve their report/byte accounting, and issue the next after the preceding response completes or cleanup releases it. Avoid duplicate training_sids. Preserve concurrent urgency for distinct workers, valid requested-response identities and rejection of wrong/stale sessions. Add a bounded reused-worker regression that finishes all requested responses and verifies round progress. No authentication, nonces or protocol redesign is required.',
    'test_gap': 'The all-buffered-stale regression uses distinct sids, and the existing reused-worker urgent test has only one urgent client. They do not cover multiple retained logical clients on one worker.',
    'baseline_boundary': 'The newly enforced single-current-assignment contract makes the previously concurrent same-worker urgent dispatch reject a response it just requested. This is a candidate-local interaction defect.',
})
review['mandatory_contract_results']['identity'] = 'Current assignment rejection guards, registration, wrong/unknown/stale ingress, ordinary reuse and edge assignment are correct in the reviewed cases. Urgent dispatch across multiple retained logical clients on one worker violates that current assignment contract and has high-severity R2B-03. This is a liveness failure, not a request to weaken identity checks or add authentication.'
review['mandatory_contract_results']['async_selection'] += ' Actual simulated-time batching also reproduces the shared-worker urgent liveness failure R2B-03.'
review['checks_performed'].append({
    'check': 'Root-steered shared-worker urgency independently confirmed through bounded actual batching',
    'commands': [f'/tmp/plato-phase2b-review/venv{v}/bin/python -m pytest tests/test_phase2b_review_probes.py -k actual_batched_reuse -q -s --basetemp /tmp/plato-phase2b-review/shared-worker-final{v}' for v in ['313', '314']],
    'result': 'Each interpreter: one selected probe fails at the intended first valid requested-response assertion; 19 unchanged cases deselected. Five ordinary actual round reports create the stale queue, both urgent requests are emitted to the same worker, and completing the last urgent response demonstrably leaves the earlier client stranded without an assignment.',
    'source': identity(probe_path),
    'logs': [identity(scratch / f'shared-worker-final{v}.log') for v in ['313', '314']],
    'root_evidence': identity('/Users/bli/Playground/plato/evidence/2026-refresh/phase2b-root-probe.json'),
    'root_source': identity('/tmp/plato-phase2-root/urgent_shared_sid.py'),
    'root_log': identity('/tmp/plato-phase2-root/urgent-shared-sid.log'),
    'root_log_name_boundary': 'Steering named urgent_shared_sid.log; the actual retained file is urgent-shared-sid.log and its SHA256 matches the root JSON c3a214f06a5d19cbe47faa077efa520ecb358a5527dd60dc312b620ef0ee3841.',
})
review['explicit_limits'].append('After the initial report was written, root supplied a new concrete urgent shared-worker issue. Only its new probe was executed on both interpreters; unchanged passing suites were not repeated. The report was amended, and the initial probe source snapshot was retained with its original exact hash.')
target.write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps({'decision': review['decision'], 'candidate': review['identities']['candidate_commit'],
                  'findings': [{'id': f['id'], 'severity': f['severity']} for f in review['findings']],
                  'report': str(target), 'report_sha256': identity(target)['sha256']}))
