"""Read-only integrity and numerical audit of retained Phase 2B evidence."""
import hashlib
import json
import subprocess
from pathlib import Path

import numpy as np

from plato.serialization.safetensor import deserialize_tree

SOURCE = Path('/private/tmp/plato-refresh-worktrees/runtime')
SCRATCH = Path('/tmp/plato-phase2b-review')
RETAINED = Path('/tmp/plato-phase2b-runtime')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=SOURCE)


report = {'candidate': git('rev-parse', 'HEAD').decode().strip(),
          'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
          'files_sha256': {}, 'logs': {}, 'runs': {}}
for name in ['AGENTS.md', 'uv.lock', 'pyproject.toml', '.python-version',
             'evidence/2026-refresh/plan.md',
             'evidence/2026-refresh/plan-addendum.json',
             'evidence/2026-refresh/phase2b-validation.json',
             'tests/conftest.py', 'tests/integration/test_event_loop_startup.py',
             'tests/integration/startup_harness.py',
             'tests/integration/startup_probe.py', 'tests/integration/startup_socket.py',
             'tests/integration/utils.py']:
    report['files_sha256'][name] = sha(SOURCE / name)
    assert (SCRATCH / 'candidate' / name).read_bytes() == git('show', 'b3b038efa376b060e1c01f1da39173240768a019:' + name)
    if name.startswith('tests/'):
        assert (SOURCE / name).read_bytes() == git('show', 'fda60becedfa6236c11d415b87a868b52789a41e:' + name)
evidence = json.loads((SOURCE / 'evidence/2026-refresh/phase2b-validation.json').read_text())
for name, digest in evidence['environment']['identities_sha256'].items():
    assert report['files_sha256'][name] == digest

for name in ['accepted313.log', 'accepted314.log', 'green-selection313.log',
             'green-selection314.log', 'red-port313.log',
             'red-transport-cleanup313.log', 'red-aggregation-callback313.log',
             'red-async-selection313.log', 'red-cross-silo313.log',
             'baseline-input-values.json', 's3-prefix-handoff.json']:
    path = RETAINED / name
    report['logs'][name] = {'sha256': sha(path), 'last_line': path.read_text().splitlines()[-1]}

canon = lambda event: json.dumps(event, sort_keys=True)
for run in ['accepted313', 'accepted314']:
    records = sorted((RETAINED / run).rglob('result.json'))
    assert len(records) == 48, (run, len(records))
    forced = []
    for path in records:
        record = json.loads(path.read_text())
        assert record['survivors'] == [], path
        durable_events = [json.loads(line)
                          for event_file in path.parent.glob('events-*.jsonl')
                          for line in event_file.read_text().splitlines()]
        assert sorted(map(canon, durable_events)) == sorted(map(canon, record['events'])), path
        if record['forced']:
            forced.append({'path': str(path), 'case': record['case'],
                           'options': record['options'], 'forced': record['forced']})
    assert len(forced) == 5
    socket_path = next(p for p in records if json.loads(p.read_text())['case'] == 'socket_round')
    record = json.loads(socket_path.read_text())
    assert record['returncode'] == 0 and not record['timed_out'] and not record['forced']
    events = record['events']
    trained = [e for e in events if e['event'] == 'client_trained']
    received = [e for e in events if e['event'] == 'server_received']
    final = next(e['weights'] for e in events if e['event'] == 'server_aggregate')
    baseline = next(e['weights'] for e in events if e['event'] == 'server_baseline')
    assert sorted(e['samples'] for e in trained) == [2, 6]
    assert len({e['pid'] for e in trained}) == 2
    assert {e['pid'] for e in trained} == {e['pid'] for e in events if e['event'] == 'child_returned'}
    errors = {}
    artifact_hashes = {}
    for key in final:
        independent = sum(e['samples'] * np.asarray(e['weights'][key]) for e in received) / 8
        errors[key] = float(np.max(np.abs(np.asarray(final[key]) - independent)))
        np.testing.assert_allclose(final[key], independent, atol=1e-6, rtol=1e-5)
    for client in trained:
        received_client = next(e for e in received if e['client_id'] == client['client_id'])
        assert client['samples'] == received_client['samples']
        assert client['weights'] == received_client['weights']
        assert client['weights'] != baseline
        path = socket_path.parent / 'models/pretrained' / f"startup_tiny_{client['client_id']}_{client['pid']}.safetensors"
        stored = deserialize_tree(path.read_bytes())
        for key in stored:
            np.testing.assert_array_equal(stored[key].numpy(), client['weights'][key])
        artifact_hashes[str(path)] = sha(path)
    for folder, filename in [('models/pretrained', 'startup_tiny.safetensors'),
                             ('checkpoints', 'checkpoint_startup_tiny_1.safetensors')]:
        path = socket_path.parent / folder / filename
        stored = deserialize_tree(path.read_bytes())
        for key in stored:
            np.testing.assert_array_equal(stored[key].numpy(), final[key])
        artifact_hashes[str(path)] = sha(path)
    report['runs'][run] = {'records': len(records), 'survivors': 0,
                           'deliberate_forced_records': forced,
                           'all_durable_events_match_results': True,
                           'socket_result_path': str(socket_path),
                           'socket_result_sha256': sha(socket_path),
                           'socket_elapsed': record['elapsed'],
                           'socket_event_sha256': {str(p): sha(p) for p in socket_path.parent.glob('events-*.jsonl')},
                           'trained': [{'id': c['client_id'], 'samples': c['samples'], 'pid': c['pid']} for c in trained],
                           'maximum_tensor_errors': errors,
                           'artifact_hashes': artifact_hashes}

# Compare every tracked changed source/test file in owned scratch to the exact
# commit, rather than silently testing a different source checkout.
changed = git('diff', '--name-only', 'fda60becedfa6236c11d415b87a868b52789a41e', 'HEAD').decode().splitlines()
for name in changed:
    assert (SCRATCH / 'candidate' / name).read_bytes() == git('show', 'HEAD:' + name)
report['all_changed_files_match_exact_candidate'] = True
report['candidate_status'] = git('status', '--porcelain').decode()
assert report['candidate_status'] == ''
(SCRATCH / 'evidence-audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'runs': {k: {'records': v['records'], 'survivors': v['survivors'],
                             'max_errors': v['maximum_tensor_errors']} for k, v in report['runs'].items()},
                  'all_changed_files_match_exact_candidate': True, 'candidate_status': report['candidate_status']}))
