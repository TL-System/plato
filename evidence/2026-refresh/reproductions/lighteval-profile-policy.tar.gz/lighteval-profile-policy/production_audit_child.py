
import importlib.abc, importlib.metadata, json, sys
from pathlib import Path
import pytest
events = []
class Audit(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname == "lighteval" or fullname.startswith("lighteval."):
            events.append(fullname)
            raise RuntimeError("real Lighteval import sentinel")
        return None
sys.meta_path.insert(0, Audit())
code = int(pytest.main(sys.argv[2:] +
    ["--collect-only", "-q", "-p", "no:cacheprovider"]))
try:
    version = importlib.metadata.version("lighteval")
except importlib.metadata.PackageNotFoundError:
    version = None
real_modules = {name: getattr(module, "__file__", None)
                for name, module in sys.modules.items()
                if name == "lighteval" or name.startswith("lighteval.")}
mandatory_packages = {}
for name in ("opacus", "kazoo", "gymnasium"):
    try:
        mandatory_packages[name] = importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        mandatory_packages[name] = None
Path(sys.argv[1]).write_text(json.dumps({"events": events, "version": version,
    "modules": real_modules, "production_conftest": "tests.conftest" in sys.modules,
    "runtime_modules": [n for n in sys.modules if "test_lighteval_runtime" in n],
    "mandatory_packages": mandatory_packages,
    "status": code}))
raise SystemExit(code)
