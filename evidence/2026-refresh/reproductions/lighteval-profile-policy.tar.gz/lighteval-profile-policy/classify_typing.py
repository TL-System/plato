import re
import sys
from pathlib import Path
owned = {
    "tests/conftest.py", "tests/integration/utils.py",
    "tests/test_retired_backends.py", "plato/utils/retired_backends.py",
    "tests/trainers/test_dp_data_loader_strategy.py",
    "tests/clients/test_feddf_strategy.py",
    "tests/servers/test_feddf_server_strategy.py",
    "tests/datasources/test_huggingface_datasource.py",
    "tests/integration/test_event_loop_startup.py",
    # Static native coverage also runs where MLX is unavailable.
    "plato/algorithms/mlx_fedavg.py",
    "plato/algorithms/registry.py",
    "plato/models/registry.py",
    "plato/servers/fedavg.py",
    "plato/trainers/mlx.py",
    "plato/trainers/registry.py",
    "plato/utils/tree.py",
    "tests/mlx_import_audit_runner.py",
    "tests/mlx_native/__init__.py",
    "tests/mlx_native/benchmark.py",
    "tests/mlx_native/helpers.py",
    "tests/mlx_native/seed_probe.py",
    "tests/mlx_native/socket_harness.py",
    "tests/mlx_native/socket_probe.py",
    "tests/mlx_native/test_phase3_controls.py",
    "tests/mlx_native/test_phase3_dispatch.py",
    "tests/mlx_native/test_phase3_rng.py",
    "tests/mlx_native/test_phase3_runtime.py",
    "tests/mlx_native/test_phase3_selection.py",
    "tests/mlx_native/test_phase3_socket.py",
    "tests/mlx_native/test_phase3_tree_contract.py",
    "tests/test_mlx_import_contract.py",
    "tests/test_mlx_profile_contract.py",
    "tests/test_model_search_retirement.py",
    "tests/integration/test_retained_model_search.py",
    "tests/integration/model_search_retention_worker.py",
    "examples/gradient_leakage_attacks/dlg_model.py",
    "examples/model_search/anycostfl/anycostfl.py",
    "examples/model_search/fedrolex/fedrolex.py",
    "examples/model_search/heterofl/heterofl.py",
    ".github/scripts/stage_ci_artifacts.py",
    "tests/test_model_search_profile_contract.py",
    "tests/test_llm_eval_profile_contract.py",
    "tests/llm_eval/__init__.py",
    "tests/llm_eval/helpers.py",
    "tests/llm_eval/test_lighteval_runtime.py",
    "plato/evaluators/lighteval.py",
    "plato/evaluators/lighteval_tasks.py",
    "tests/evaluators/test_lighteval.py",
    "tests/evaluators/test_lighteval_materialization.py",
}
allowed = {
    ("tests/datasources/test_huggingface_datasource.py", "99", "5", "invalid-assignment"),
    ("tests/datasources/test_huggingface_datasource.py", "100", "5", "invalid-assignment"),
}
log = Path("ci-artifacts/ty.log").read_text()
status = int(sys.argv[1])
assert status in (0, 1), f"ty exited with status {status}: {log}"
matches = list(re.finditer(r"^(.+?):(\d+):(\d+): (?:error|warning)\[([^]]+)\]", log, re.M))
if status == 0:
    assert log.strip() == "All checks passed!" and not matches, log
else:
    report = re.search(r"^Found ([1-9][0-9]*) diagnostics?$", log, re.M)
    assert report is not None and len(matches) == int(report[1]), log
for match in matches:
    assert match[1] not in owned or match.groups() in allowed, match[0]