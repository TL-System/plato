import hashlib,json,os,subprocess
from pathlib import Path
root=Path('/tmp/plato-refresh-worktrees/lighteval-profile');out=Path('/tmp/plato-lighteval-profile/logs')
cases=[
 ('base','/tmp/plato-lighteval-profile/base-env/bin/python',['tests','--test-profile=base','-m','not runtime']),
 ('mandatory','/tmp/plato-lighteval-profile/env/bin/python',['tests','--test-profile=mandatory','-m','not runtime']),
 ('runtime','/tmp/plato-lighteval-profile/env/bin/python',['tests','--test-profile=mandatory','-m','runtime and not retained_model_search']),
 ('retained','/tmp/plato-lighteval-profile/env/bin/python',['tests/integration/test_retained_model_search.py','--test-profile=mandatory','-m','retained_model_search']),
 ('combined','/tmp/plato-lighteval-profile/env/bin/python',['tests','--test-profile=llm-eval']),
 ('native','/tmp/plato-lighteval-profile/native-env/bin/python',['tests/mlx_native','--test-profile=mlx-native']),
]
env=os.environ.copy();env.update(OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',NLTK_DATA='/tmp/plato-lighteval-profile/nltk',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONDONTWRITEBYTECODE='1')
record=[]
for label,interpreter,args in cases:
 command=[interpreter,'-m','pytest',*args,'--collect-only','-q','-p','no:cacheprovider']
 r=subprocess.run(command,cwd=root,env=env,text=True,capture_output=True,timeout=120,check=False)
 log=r.stdout+r.stderr;(out/(label+'-collection.log')).write_text(log)
 nodes=[line for line in log.splitlines() if '.py::' in line and line.startswith('tests/')]
 record.append({'label':label,'command':command,'status':r.returncode,'nodes':len(nodes),
  'optional_nodes':sum(n.startswith('tests/llm_eval/') for n in nodes),
  'native_nodes':sum(n.startswith('tests/mlx_native/') for n in nodes),
  'profile_sha256':hashlib.sha256((root/'tests/conftest.py').read_bytes()).hexdigest()})
 assert r.returncode==0,(label,log)
 if label not in {'combined'}:assert not any(n.startswith('tests/llm_eval/') for n in nodes)
 if label!='native':assert not any(n.startswith('tests/mlx_native/') for n in nodes)
 if label=='native':assert len(nodes)==383
 if label=='runtime':assert len(nodes)==51
 if label=='retained':assert len(nodes)==19
 if label=='combined':assert sum(n.startswith('tests/llm_eval/') for n in nodes)==11
(out/'collection-partitions.json').write_text(json.dumps(record,indent=2)+'\n')
