set -eu
uv sync --locked --python 3.13 --no-default-groups --group dev --extra llm_eval
uv run --no-sync --python 3.13 python - <<'PY'
import json
import os
import sys
from pathlib import Path


def interpreter_identity() -> dict:
    configured = os.environ["UV_PROJECT_ENVIRONMENT"]
    expected = Path(configured).resolve()
    executable = Path(os.path.abspath(sys.executable))
    assert Path(sys.prefix).resolve() == expected, (sys.prefix, configured)
    assert Path(sys.exec_prefix).resolve() == expected, (sys.exec_prefix, configured)
    assert sys.version_info[:2] == (3, 13), sys.version
    assert sys.prefix != sys.base_prefix, "A separate venv is required."
    # Preserve lexical executable ownership: venv binaries can be symlinks.
    assert executable.parent.resolve() == expected / "bin", executable
    return {
        "configured_environment": configured, "executable": str(executable),
        "prefix": sys.prefix, "exec_prefix": sys.exec_prefix,
        "base_prefix": sys.base_prefix, "python": sys.version,
    }


def checked_identity() -> dict:
    observed = interpreter_identity()
    receipt = json.loads(Path("ci-artifacts/llm-eval-interpreter.json").read_text())
    assert receipt == observed, (receipt, observed)
    return observed

Path("ci-artifacts/llm-eval-interpreter.json").write_text(json.dumps(interpreter_identity(), indent=2) + "\n")
PY
uv pip freeze --python "$UV_PROJECT_ENVIRONMENT/bin/python" > ci-artifacts/llm-eval-packages.txt
uv run --no-sync --python 3.13 python - <<'PY'
import json
import os
import sys
from pathlib import Path


def interpreter_identity() -> dict:
    configured = os.environ["UV_PROJECT_ENVIRONMENT"]
    expected = Path(configured).resolve()
    executable = Path(os.path.abspath(sys.executable))
    assert Path(sys.prefix).resolve() == expected, (sys.prefix, configured)
    assert Path(sys.exec_prefix).resolve() == expected, (sys.exec_prefix, configured)
    assert sys.version_info[:2] == (3, 13), sys.version
    assert sys.prefix != sys.base_prefix, "A separate venv is required."
    # Preserve lexical executable ownership: venv binaries can be symlinks.
    assert executable.parent.resolve() == expected / "bin", executable
    return {
        "configured_environment": configured, "executable": str(executable),
        "prefix": sys.prefix, "exec_prefix": sys.exec_prefix,
        "base_prefix": sys.base_prefix, "python": sys.version,
    }


def checked_identity() -> dict:
    observed = interpreter_identity()
    receipt = json.loads(Path("ci-artifacts/llm-eval-interpreter.json").read_text())
    assert receipt == observed, (receipt, observed)
    return observed

import hashlib
import importlib.metadata
import subprocess

identity = checked_identity()
resources = {}
import nltk
for name in ("punkt", "punkt_tab"):
    target = Path(os.environ["NLTK_DATA"]).resolve()
    target.mkdir(parents=True, exist_ok=True)
    cached = (target / "tokenizers" / name).is_dir()
    assert nltk.download(name, download_dir=str(target), raise_on_error=True)
    resolved = Path(str(nltk.data.find("tokenizers/" + name))).resolve()
    assert resolved.is_relative_to(target.resolve()), resolved
    resources[name] = {
        "resolved": str(resolved), "cache_present_before": cached,
        "origin": "NLTK downloader official package index",
        "sha256": {str(p.relative_to(target)): hashlib.sha256(p.read_bytes()).hexdigest()
                   for p in sorted(resolved.rglob("*")) if p.is_file()},
    }
# Load the exact production module only after explicit resource provisioning.
import importlib.util
spec = importlib.util.spec_from_file_location("plato_profile_preflight", "tests/conftest.py")
assert spec is not None and spec.loader is not None
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module._eval_prerequisites()
versions = {name: importlib.metadata.version(name) for name in
            ("lighteval", "langdetect", "xxhash", "nltk", "transformers", "torch",
             "datasets", "tokenizers", "opacus", "kazoo", "gymnasium")}
record = {"interpreter": identity, "resources": resources,
          "nltk_data_path": nltk.data.path, "packages": versions,
          "preflight_passed": True,
          "pipeline_origin": sys.modules["lighteval.pipeline"].__file__}
Path("ci-artifacts/llm-eval-prerequisites.json").write_text(json.dumps(record, indent=2) + "\n")
owned = ["uv.lock", "pyproject.toml", "tests/conftest.py",
         "tests/llm_eval/cases.json", "tests/llm_eval/__init__.py",
         "tests/llm_eval/helpers.py", "tests/llm_eval/test_lighteval_runtime.py",
         "tests/test_llm_eval_profile_contract.py", "plato/evaluators/lighteval.py",
         "plato/evaluators/lighteval_tasks.py", "tests/evaluators/test_lighteval.py",
         "tests/evaluators/test_lighteval_materialization.py",
         ".github/workflows/pytorch_tests.yml", ".github/scripts/stage_ci_artifacts.py"]
source = {"interpreter": identity, "sha256": {
    name: hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in owned},
    "commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "uv": subprocess.check_output(["uv", "--version"], text=True).strip()}
Path("ci-artifacts/llm-eval-source-ledger.json").write_text(json.dumps(source, indent=2) + "\n")
PY
export HF_HUB_OFFLINE=1 HF_DATASETS_OFFLINE=1
uv run --no-sync --python 3.13 python -m pytest tests/llm_eval --test-profile=llm-eval --collect-only -q > ci-artifacts/llm-eval-collection.log 2>&1
uv run --no-sync --python 3.13 python - > ci-artifacts/llm-eval.log <<'PY'
import json
import os
import sys
from pathlib import Path


def interpreter_identity() -> dict:
    configured = os.environ["UV_PROJECT_ENVIRONMENT"]
    expected = Path(configured).resolve()
    executable = Path(os.path.abspath(sys.executable))
    assert Path(sys.prefix).resolve() == expected, (sys.prefix, configured)
    assert Path(sys.exec_prefix).resolve() == expected, (sys.exec_prefix, configured)
    assert sys.version_info[:2] == (3, 13), sys.version
    assert sys.prefix != sys.base_prefix, "A separate venv is required."
    # Preserve lexical executable ownership: venv binaries can be symlinks.
    assert executable.parent.resolve() == expected / "bin", executable
    return {
        "configured_environment": configured, "executable": str(executable),
        "prefix": sys.prefix, "exec_prefix": sys.exec_prefix,
        "base_prefix": sys.base_prefix, "python": sys.version,
    }


def checked_identity() -> dict:
    observed = interpreter_identity()
    receipt = json.loads(Path("ci-artifacts/llm-eval-interpreter.json").read_text())
    assert receipt == observed, (receipt, observed)
    return observed

print(json.dumps(checked_identity()))
PY
uv run --no-sync --python 3.13 python -m pytest tests/llm_eval --test-profile=llm-eval -ra -o junit_family=legacy --basetemp=ci-artifacts/llm-eval-tmp --junitxml=ci-artifacts/llm-eval.xml >> ci-artifacts/llm-eval.log 2>&1
uv run --no-sync --python 3.13 python - > ci-artifacts/llm-eval-ty.log <<'PY'
import json
import os
import sys
from pathlib import Path


def interpreter_identity() -> dict:
    configured = os.environ["UV_PROJECT_ENVIRONMENT"]
    expected = Path(configured).resolve()
    executable = Path(os.path.abspath(sys.executable))
    assert Path(sys.prefix).resolve() == expected, (sys.prefix, configured)
    assert Path(sys.exec_prefix).resolve() == expected, (sys.exec_prefix, configured)
    assert sys.version_info[:2] == (3, 13), sys.version
    assert sys.prefix != sys.base_prefix, "A separate venv is required."
    # Preserve lexical executable ownership: venv binaries can be symlinks.
    assert executable.parent.resolve() == expected / "bin", executable
    return {
        "configured_environment": configured, "executable": str(executable),
        "prefix": sys.prefix, "exec_prefix": sys.exec_prefix,
        "base_prefix": sys.base_prefix, "python": sys.version,
    }


def checked_identity() -> dict:
    observed = interpreter_identity()
    receipt = json.loads(Path("ci-artifacts/llm-eval-interpreter.json").read_text())
    assert receipt == observed, (receipt, observed)
    return observed

print(json.dumps(checked_identity()))
PY
uv run --no-sync --python 3.13 ty check tests/conftest.py tests/test_llm_eval_profile_contract.py tests/llm_eval/__init__.py tests/llm_eval/helpers.py tests/llm_eval/test_lighteval_runtime.py plato/evaluators/lighteval.py plato/evaluators/lighteval_tasks.py tests/evaluators/test_lighteval.py tests/evaluators/test_lighteval_materialization.py --error-on-warning --output-format concise >> ci-artifacts/llm-eval-ty.log 2>&1
uv run --no-sync --python 3.13 python - <<'PY'
import json
import os
import sys
from pathlib import Path


def interpreter_identity() -> dict:
    configured = os.environ["UV_PROJECT_ENVIRONMENT"]
    expected = Path(configured).resolve()
    executable = Path(os.path.abspath(sys.executable))
    assert Path(sys.prefix).resolve() == expected, (sys.prefix, configured)
    assert Path(sys.exec_prefix).resolve() == expected, (sys.exec_prefix, configured)
    assert sys.version_info[:2] == (3, 13), sys.version
    assert sys.prefix != sys.base_prefix, "A separate venv is required."
    # Preserve lexical executable ownership: venv binaries can be symlinks.
    assert executable.parent.resolve() == expected / "bin", executable
    return {
        "configured_environment": configured, "executable": str(executable),
        "prefix": sys.prefix, "exec_prefix": sys.exec_prefix,
        "base_prefix": sys.base_prefix, "python": sys.version,
    }


def checked_identity() -> dict:
    observed = interpreter_identity()
    receipt = json.loads(Path("ci-artifacts/llm-eval-interpreter.json").read_text())
    assert receipt == observed, (receipt, observed)
    return observed

import hashlib
import re
from collections import Counter
from xml.etree import ElementTree


def verify_llm_eval(root: Path) -> int:
    issues = []
    expected = Counter()
    collected = []
    junit_nodes = []
    outcomes = Counter()
    properties = []
    hashes = {}
    try:
        identity = checked_identity()
        ledger_path = Path("tests/llm_eval/cases.json")
        ledger = json.loads(ledger_path.read_text())
        assert ledger["schema_version"] == 1
        expected = Counter(case["nodeid"] for case in ledger["cases"])
        assert expected and all(count == 1 for count in expected.values())
        assert all(node.startswith("tests/llm_eval/") and "::" in node
                   and ".." not in Path(node.split("::", 1)[0]).parts
                   for node in expected)
        source = json.loads((root / "llm-eval-source-ledger.json").read_text())
        assert source["interpreter"] == identity
        for name, digest in source["sha256"].items():
            actual = hashlib.sha256(Path(name).read_bytes()).hexdigest()
            assert actual == digest, f"Source changed: {name}"
            hashes[name] = actual
        assert source["sha256"][str(ledger_path)] == hashlib.sha256(
            ledger_path.read_bytes()).hexdigest()
        prerequisites = json.loads((root / "llm-eval-prerequisites.json").read_text())
        assert prerequisites["interpreter"] == identity
        assert prerequisites["preflight_passed"] is True
        assert set(prerequisites["resources"]) == {"punkt", "punkt_tab"}
        for resource in prerequisites["resources"].values():
            assert Path(resource["resolved"]).resolve().is_relative_to(
                Path(os.environ["NLTK_DATA"]).resolve())
        collected = re.findall(r"^(\S+\.py::\S+)$",
                               (root / "llm-eval-collection.log").read_text(), re.M)
        if Counter(collected) != expected:
            issues.append("Collection must match the reviewed ledger exactly once.")
        tree = ElementTree.parse(root / "llm-eval.xml").getroot()
        cases = list(tree.iter("testcase"))
        for case in cases:
            classname = case.get("classname", "")
            name = case.get("name", "")
            junit_nodes.append(classname.replace(".", "/") + ".py::" + name)
            for property_record in case.iter("property"):
                properties.append({"nodeid": junit_nodes[-1],
                                   **property_record.attrib})
            if any(case.find(tag) is not None for tag in ("failure", "error", "skipped")):
                issues.append("JUnit has a nonpassing case.")
        if Counter(junit_nodes) != expected:
            issues.append("JUnit must match the reviewed ledger exactly once.")
        totals = {key: sum(int(suite.attrib[key]) for suite in tree.iter("testsuite"))
                  for key in ("tests", "failures", "errors", "skipped")}
        if totals != {"tests": sum(expected.values()), "failures": 0,
                      "errors": 0, "skipped": 0}:
            issues.append("JUnit suite totals must match all passing ledger cases.")
        runlog = (root / "llm-eval.log").read_text()
        assert json.loads(runlog.splitlines()[0]) == identity
        typing = (root / "llm-eval-ty.log").read_text().splitlines()
        assert json.loads(typing[0]) == identity
        assert "\n".join(typing[1:]).strip() == "All checks passed!"
        for count, outcome in re.findall(
            r"\b(\d+) (passed|failed|skipped|xfailed|xpassed|errors?)\b", runlog
        ):
            outcomes[outcome] += int(count)
        if outcomes != Counter({"passed": sum(expected.values())}):
            issues.append("Execution has missing passes or forbidden outcomes.")
        if "Lighteval complete qualification" not in runlog:
            issues.append("Production policy did not report complete qualification.")
    except (OSError, ValueError, KeyError, AssertionError, ElementTree.ParseError) as exc:
        issues.append(f"Missing or invalid qualification artifact: {exc}")
    record = {"schema_version": 1, "accepted": not issues, "issues": issues,
              "expected_nodes": list(expected), "collected_nodes": collected,
              "junit_nodes": junit_nodes, "outcomes": dict(outcomes),
              "sha256": hashes, "raw_runtime_properties": properties}
    (root / "llm-eval-acceptance.json").write_text(json.dumps(record, indent=2) + "\n")
    return int(bool(issues))


raise SystemExit(verify_llm_eval(Path("ci-artifacts")))
PY

