import hashlib, importlib.abc, importlib.metadata, importlib.util, json, sys
from pathlib import Path
root=Path('/tmp/plato-refresh-worktrees/lighteval-profile')
output,mode=sys.argv[1:]
events=[]
class Audit(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname=='lighteval' or fullname.startswith('lighteval.'):
   frame=sys._getframe(1);inside=False
   while frame is not None:
    if frame.f_code.co_name=='_eval_prerequisites': inside=True
    frame=frame.f_back
   events.append({'name':fullname,'inside_preflight':inside})
   if mode!='installed': raise AssertionError('Lighteval import before absent dependency rejection')
  return None
sys.meta_path.insert(0,Audit())
spec=importlib.util.spec_from_file_location('exact_production_profile',root/'tests/conftest.py')
assert spec and spec.loader
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
import pytest
try:
 module._eval_prerequisites()
except pytest.UsageError as exc:
 assert mode!='installed',str(exc)
 error=str(exc); assert 'llm-eval prerequisite failed' in error
 assert not events,events
else:
 assert mode=='installed'
 assert events and all(e['inside_preflight'] for e in events)
 error=None
packages={}
for n in ['lighteval','langdetect','xxhash','nltk','torch','transformers']:
 try:packages[n]=importlib.metadata.version(n)
 except importlib.metadata.PackageNotFoundError:packages[n]=None
record={'mode':mode,'executable':sys.executable,'prefix':sys.prefix,'packages':packages,
 'error':error,'events':events,
 'profile_sha256':hashlib.sha256((root/'tests/conftest.py').read_bytes()).hexdigest()}
Path(output).write_text(json.dumps(record,indent=2)+'\n')
