import hashlib,json,subprocess,xml.etree.ElementTree as ET
from pathlib import Path
s=Path('/tmp/plato-phase2c-count-collection-fix');base='f342a5a6021cee938e0b880eca5919e09ace1981'
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
def receipt(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
impl=git('rev-parse','HEAD');assert impl=='05468d5db1632c525f7f3dc9ac11ab12cf2cb0cd'
paths=git('diff','--name-only',base,impl).splitlines();assert paths==['tests/integration/feddyn_partition_worker.py','tests/integration/test_feddyn_count_boundaries.py']
runs={}
for name in ('red-313','red-314','green-313','green-314','ruff-313','ruff-314'):
 d=json.loads((s/(name+'.json')).read_text());log=Path(d['log']);assert receipt(log)['sha256']==d['log_sha256']
 assert d['exit_code']==(1 if name.startswith('red-') else 0)
 if (s/(name+'.xml')).exists():
  xml=s/(name+'.xml');d['junit']=receipt(xml);cases=list(ET.parse(xml).iter('testcase'))
  failed=sum(c.find('failure') is not None or c.find('error') is not None for c in cases);skipped=sum(c.find('skipped') is not None for c in cases)
  d['counts']={'tests':len(cases),'passed':len(cases)-failed-skipped,'failed':failed,'skipped':skipped}
  d['test_ids']=[c.attrib['classname']+'::'+c.attrib['name'] for c in cases]
  if name.startswith('red-'):assert d['counts']=={'tests':2,'passed':1,'failed':1,'skipped':0};assert 'PlainSGD' in log.read_text()
  else:
   assert d['head']==impl and d['counts']=={'tests':36,'passed':36,'failed':0,'skipped':0}
   assert sum('test_feddyn_count_boundaries' in n for n in d['test_ids'])==20
   assert sum('test_actual_spawned_rejection_retry_and_logical_reuse' in n for n in d['test_ids'])==13
   assert sum('test_actual_spawn_reused_client_matches_partial_oracle' in n for n in d['test_ids'])==2
   assert sum('test_actual_spawn_returns_personal_state_and_optimizer_across_rounds' in n for n in d['test_ids'])==1
 d['log_tail']=log.read_text().splitlines()[-5:];runs[name]=d
identity=json.loads((s/'collection-import-identities.json').read_text())
assert identity['tests.integration.test_feddyn_round_flow']['plain_sgd_is_current'] is False
assert identity['test_feddyn_round_flow']['plain_sgd_is_current'] is True
preservation=json.loads((s/'assertion-preservation.json').read_text());assert preservation['original_assertions']==preservation['original_assertions_retained_exact_ast']==18
for p,key in [('tests/trainers/test_dp_data_loader_strategy.py','frozen_dp_file_sha256'),('evidence/2026-refresh/phase2c-dp-typing-gate-validation.json','frozen_dp_receipt_sha256')]:
 assert Path(p).read_bytes()==subprocess.check_output(['git','show',base+':'+p]);assert receipt(p)['sha256']==preservation[key]
observations={}
for v in ('313','314'):
 basepath=s/('green-'+v)/'test_parent_realizes_partition1'
 p=basepath/'run/worker-partition.json';data=json.loads(p.read_text())
 assert len(data)==2 and all(e['start_method']=='spawn' and e['indices']==[7,13] and e['count']==2 and e['backing_items']==100 for e in data)
 result=basepath/'partition-result.json';payload=json.loads(result.read_text())
 assert payload['calls']==1 and payload['report_count']==payload['worker_count']==2 and abs(payload['endpoint']-1.622)<1e-12 and payload['no_active_children']
 observations[v]={'child_record':receipt(p),'epochs':data,'parent_result':receipt(result),'parent_observed':payload}
full_diff=(s/'full-correction.diff').read_text();assert full_diff==subprocess.check_output(['git','diff',base,impl],text=True)
report={
 'schema_version':1,'finding':'ROOT-2C-COLLECTION-01','status':'FIXED_FULL_COLLECTION_DUAL_VERSION_QUALIFIED_FRESH_REVIEW_PENDING',
 'starting_commit':base,'frozen_dp_correction_commit':base,'root_original_integrated_candidate':'2633f8394c142ec04db13743b54a427e04c2aed7',
 'implementation_commit':impl,'implementation_tree':git('rev-parse','HEAD^{tree}'),'implementation_parent':git('show','-s','--format=%P',impl),
 'evidence_commit_identity_note':'Exact final evidence commit/tree supplied in clean handoff and own scratch final-candidate.json to avoid self-reference.',
 'sources':{p:{**receipt(p),'git_blob':git('rev-parse',impl+':'+p)} for p in paths},
 'root_original_reproduction':{p:receipt(s/('root-'+p)) for p in ('count-isolation-313.log','count-isolation-313.xml','count-isolation-313-receipt.json')},
 'diagnosis':{'cause':'Full pytest collection imports the same round-flow source as both tests.integration.test_feddyn_round_flow and test_feddyn_round_flow. Its module loader replaces sys.modules[feddyn_trainer], leaving earlier PlainSGD class objects inconsistent with the canonical module attribute. Real spawn pickling fails before any optimizer run.','actual_collection_identity_probe':identity,'probe_command':'zsh -lc PYTHONPATH=/tmp/plato-phase2c-count-collection-fix OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 /tmp/plato-phase2c-313/bin/python -m pytest tests -k test_parent_realizes_partition_once_without_using_backing_length --collect-only -q -p collection_identity_probe','probe_receipts':[receipt(s/'collection_identity_probe.py'),receipt(s/'collection-import-identities.json'),receipt(s/'identity-collection.log')]},
 'fix':'Move the unchanged single-partition scenario/assertions into a private shared test function. The existing spawn=True case launches a guarded standalone interpreter, which runs that same function through actual trainer max_concurrency spawn; spawn=False still runs it directly under full collection. A real child epoch callback records actual sampler indices/count/backing size without fetching batches or changing sampling/model/optimizer. The subprocess retains a90second limit consistent with existing FedDyn count helpers and propagates nonzero exits.',
 'assertion_and_scope_preservation':preservation,
 'unchanged_production_DP_CI_and_other_existing_sources':True,
 'environments':{v:json.loads(Path('/tmp/plato-phase2c-dp-typing-fix/environment-'+v+'.json').read_text()) for v in ('313','314')},
 'executions':runs,
 'full_collection_contract':'All invocations use pytest tests plus -k; every test module is collected. No module-only invocation, import-order change, selected-case skip or mock replaces real multiprocessing. Both green runs select36existing cases:20count boundaries,13worker rejection/retry variants,2partial participation spawn references and1previously guarded FedDyn personalization spawn path.',
 'actual_parent_child_observations':observations,
 'numerical_and_sampling_preservation':'Parent get()==1; same actual subset[7,13] out of100 backing rows observed in both real worker epochs; report and accepted worker count2; original endpoint1.622 at absolute tolerance1e-12. Existing Fraction/control retry references and every prior count assertion remain unchanged.',
 'full_diff':full_diff,'diff_receipt':receipt(s/'full-correction.diff'),
 'warnings':'Actual log summaries retained. No global warning filter, no suppression or skip policy change.',
 'raw_scratch_inventory':[receipt(p) for p in sorted(s.iterdir()) if p.is_file()],
 'resource_ownership':{'own_scratch':str(s),'environments':['/tmp/plato-phase2c-313','/tmp/plato-phase2c-314'],'root':'Only provided failure artifacts read/copied. Root immutable checkout, environment and running full suite untouched.','retained_resources':'All previous owned scratch/environments retained; no push or cleanup.'},
 'limits':['CPU/macOS arm64 test-harness correction; no production bug or GPU claim inferred.','Full collection with selected execution is not a full-suite pass claim.','Frozen DP correction remains separate and untouched for independent review.','Fresh independent review of this separate correction and root integration acceptance remain pending.'],
 'whole_phase_acceptance_claimed':False,
}
p=Path('evidence/2026-refresh/phase2c-count-collection-validation.json');p.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'implementation_commit':impl,'tree':report['implementation_tree'],'green_counts':{v:runs['green-'+v]['counts'] for v in ('313','314')},'receipt':receipt(p)},indent=2))
