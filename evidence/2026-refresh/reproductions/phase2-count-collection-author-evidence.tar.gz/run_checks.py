import hashlib,json,shlex,subprocess,sys,time
from pathlib import Path
scratch=Path('/tmp/plato-phase2c-count-collection-fix')
name,version,kind=sys.argv[1:4];venv=Path('/tmp/plato-phase2c-'+version)
if kind in ('red','green'):
 selection='test_parent_realizes_partition_once_without_using_backing_length' if kind=='red' else 'test_feddyn_count_boundaries or test_actual_spawned_rejection_retry_and_logical_reuse or test_actual_spawn_reused_client_matches_partial_oracle or (test_actual_spawn_returns_personal_state_and_optimizer_across_rounds and feddyn)'
 args=[str(venv/'bin/python'),'-m','pytest','tests','-k',selection,'-q','--basetemp',str(scratch/name),'--junitxml',str(scratch/(name+'.xml'))]
elif kind=='ruff':args=[str(venv/'bin/ruff'),'check','tests/integration/test_feddyn_count_boundaries.py','tests/integration/feddyn_partition_worker.py','--select','I']
else:raise ValueError(kind)
command='OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1 '+shlex.join(args)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();t=time.monotonic()
with (scratch/(name+'.log')).open('w') as log:r=subprocess.run(['zsh','-lc',command],stdout=log,stderr=subprocess.STDOUT)
d={'name':name,'command':command,'shell':'zsh -lc','head':head,'python_environment':str(venv),'exit_code':r.returncode,'seconds':time.monotonic()-t,'log':str(scratch/(name+'.log')),'log_sha256':hashlib.sha256((scratch/(name+'.log')).read_bytes()).hexdigest()}
(scratch/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));sys.exit(r.returncode)
