import json
import sys
from pathlib import Path


def pytest_collection_modifyitems(session, config, items):
    names=('tests.integration.test_feddyn_round_flow','test_feddyn_round_flow')
    canonical=sys.modules['feddyn_trainer']
    observations={}
    for name in names:
        module=sys.modules.get(name)
        if module is not None:
            observations[name]={'path':module.__file__,'module_identity':id(module),'plain_sgd_is_current':module.feddyn_trainer.PlainSGD is canonical.PlainSGD}
    Path('/tmp/plato-phase2c-count-collection-fix/collection-import-identities.json').write_text(json.dumps(observations,indent=2)+'\n')
