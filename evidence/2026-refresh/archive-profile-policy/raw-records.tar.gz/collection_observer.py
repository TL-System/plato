"""Record selection and final status without changing collection or outcomes."""

import json
import os
from pathlib import Path

import pytest

_deselected = []


def pytest_deselected(items):
    _deselected.extend(item.nodeid for item in items)


@pytest.hookimpl(wrapper=True, tryfirst=True)
def pytest_sessionfinish(session, exitstatus):
    yield
    Path(os.environ["PLATO_COLLECTION_RECEIPT"]).write_text(
        json.dumps(
            {
                "selected": [item.nodeid for item in session.items],
                "deselected": _deselected,
                "exitstatus": int(session.exitstatus),
                "markers": {
                    item.nodeid: [marker.name for marker in item.iter_markers()]
                    for item in session.items
                },
            },
            indent=2,
        ) + "\n"
    )
