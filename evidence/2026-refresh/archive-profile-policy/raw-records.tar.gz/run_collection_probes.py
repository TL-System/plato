"""Execute the exact accepted partitions with bounded, inert observations."""

import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path("/tmp/plato-refresh-worktrees/archive-profile")
OUTPUT = Path("/tmp/plato-archive-profile-evidence")
CORE = "/tmp/plato-archive-integration/env/bin/python"
BASE = "/tmp/plato-llm-integration/base-313/bin/python"
TARGET = "tests/integration/test_retained_model_search.py"
EXPRESSION = "runtime and not retained_model_search"
CASES = [
    ("base-non-runtime", BASE, ["tests", "--collect-only", "--test-profile=base", "-m", "not runtime", "-ra"], 0, ""),
    ("mandatory-non-runtime", CORE, ["tests", "--collect-only", "--test-profile=mandatory", "-m", "not runtime", "-ra"], 0, ""),
    ("core-runtime", CORE, ["tests", "--collect-only", "--test-profile=mandatory", "-m", EXPRESSION, "-ra"], 0, ""),
    ("dedicated-retained", CORE, [TARGET, "--collect-only", "-q", "--test-profile=mandatory", "-m", "retained_model_search"], 0, ""),
    ("negative-expression", CORE, ["tests", "--collect-only", "--test-profile=mandatory", "-m", EXPRESSION + " and not startup_containment"], 4, "unapproved full-suite partition"),
    ("negative-runtime-keyword", CORE, ["tests", "--collect-only", "--test-profile=mandatory", "-m", EXPRESSION, "-k", "not test_real_two_client_cpu_socket_round"], 1, "unexpected deselection"),
    ("negative-runtime-deselect", CORE, ["tests", "--collect-only", "--test-profile=mandatory", "-m", EXPRESSION, "--deselect", "tests/integration/test_event_loop_startup.py::test_real_two_client_cpu_socket_round"], 1, "collection exclusions"),
    ("negative-runtime-ignore", CORE, ["tests", "--collect-only", "--test-profile=mandatory", "-m", EXPRESSION, "--ignore", "tests/integration/test_event_loop_startup.py"], 1, "collection exclusions"),
    ("negative-runtime-ignore-glob", CORE, ["tests", "--collect-only", "--test-profile=mandatory", "-m", EXPRESSION, "--ignore-glob", "*event_loop_startup*"], 1, "collection exclusions"),
    ("negative-dedicated-keyword", CORE, [TARGET, "--collect-only", "--test-profile=mandatory", "-m", "retained_model_search", "-k", "not anycostfl"], 4, "retained qualification does not permit filters"),
    ("missing-opacus", BASE, ["tests", "--collect-only", "--test-profile=mandatory"], 4, "mandatory prerequisite failed: No module named 'opacus'"),
    ("native-383-collection", CORE, ["tests/mlx_native", "--collect-only", "--test-profile=mlx-native", "-q"], 0, "native collection-only validation"),
]
results = []
for label, interpreter, arguments, expected, diagnostic in CASES:
    env = {
        **os.environ,
        "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1",
        "PYTEST_PLUGINS": "collection_observer",
        "PYTHONPATH": os.pathsep.join([str(ROOT), str(OUTPUT)]),
        "PLATO_COLLECTION_RECEIPT": str(OUTPUT / f"{label}.json"),
        "HF_HUB_OFFLINE": "1",
        "HF_DATASETS_OFFLINE": "1",
        "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
    }
    env.pop("PYTEST_ADDOPTS", None)
    command = [interpreter, "-m", "pytest", *arguments]
    run = subprocess.run(command, cwd=ROOT, env=env, text=True, capture_output=True, timeout=120)
    output = run.stdout + run.stderr
    (OUTPUT / f"{label}.log").write_text(output)
    record = {"label": label, "command": command, "timeout_seconds": 120, "exitstatus": run.returncode, "expected_exitstatus": expected, "diagnostic": diagnostic}
    results.append(record)
    assert run.returncode == expected and diagnostic in output, (record, output[-5000:])
    if expected == 0:
        selected = json.loads((OUTPUT / f"{label}.json").read_text())
        assert selected["exitstatus"] == 0
        nodes = selected["selected"]
        if label == "core-runtime":
            assert len(nodes) == 51
            assert sum(node.startswith("tests/integration/test_event_loop_startup.py::") for node in nodes) == 48
            assert not any(node.startswith(TARGET + "::") for node in nodes)
            assert sum(node.startswith(TARGET + "::") for node in selected["deselected"]) == 19
        elif label == "dedicated-retained":
            assert len(nodes) == 19 and len(set(nodes)) == 19
            assert not selected["deselected"]
            assert all({"runtime", "retained_model_search"} <= set(markers) for markers in selected["markers"].values())
        elif label == "native-383-collection":
            ledger = json.loads((ROOT / "tests/mlx_native/cases.json").read_text())
            assert set(nodes) == {case["nodeid"] for case in ledger["cases"]}
            assert len(nodes) == 383
        else:
            assert not any(node.startswith(TARGET + "::") or node.startswith("tests/mlx_native/") for node in nodes)
        record["selected_count"] = len(nodes)
        record["deselected_count"] = len(selected["deselected"])
    (OUTPUT / "collection-probes.json").write_text(json.dumps(results, indent=2) + "\n")
    print(f"{label}: exit{run.returncode}, selected{record.get('selected_count', 'n/a')}", flush=True)
print("All bounded real collection and negative probes passed.", flush=True)
